import sys, numpy as np, itertools, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
import os; sys.path.insert(0, os.environ.get('SSMSIM_PATH', '.'))  # folder containing the ssmsim package
plt.rcParams.update({'font.size':9})
BL='#1f4e79'; OR='#c55a11'; GR='#2e7d32'; GY='#9a9a9a'
def clean(ax,el=18,az=-60):
    ax.set_axis_off(); ax.view_init(elev=el,azim=az); ax.set_box_aspect((1,1,1))
def eqlim(ax,P,pad=0.3):
    c=P.mean(0); r=np.abs(P-c).max()+pad
    ax.set_xlim(c[0]-r,c[0]+r); ax.set_ylim(c[1]-r,c[1]+r); ax.set_zlim(c[2]-r,c[2]+r)
# ---------------- Figure: growth ----------------
fig=plt.figure(figsize=(11,3.8))
a=np.array([0,0,0.]); b=np.array([1,0,0.]); c=np.array([.5,np.sqrt(3)/2,0])
ax=fig.add_subplot(1,3,1)
x=a+b-c
ax.fill(*np.array([a,b,c]).T[:2],color='#d9e2ef'); ax.fill(*np.array([a,b,x]).T[:2],color='#fde3cf',alpha=.8)
for P,l in [(a,'a'),(b,'b'),(c,'c')]: ax.plot(*P[:2],'o',ms=13,color=BL); ax.text(P[0],P[1],l,color='w',ha='center',va='center',weight='bold')
ax.plot(*x[:2],'o',ms=13,color=OR); ax.text(x[0],x[1],'x',color='w',ha='center',va='center',weight='bold')
for P in (a,b): ax.plot([P[0],x[0]],[P[1],x[1]],'-',color=OR,lw=2)
ax.set_aspect('equal'); ax.axis('off'); ax.set_title('(a) Stitch: $x=a+b-c$\nnew node in the plane, 1 bond from $a$ and $b$',fontsize=9)
ax=fig.add_subplot(1,3,2,projection='3d')
apex=(a+b+c)/3+np.array([0,0,np.sqrt(2/3)])
ax.add_collection3d(Poly3DCollection([[a,b,c]],color='#d9e2ef',alpha=.9))
for P in (a,b,c): ax.scatter(*P,s=110,color=BL); ax.plot(*np.array([P,apex]).T,color=OR,lw=2)
ax.scatter(*apex,s=130,color=OR); ax.text(*(apex+[0,0,.12]),'apex',ha='center')
clean(ax,22,-70); eqlim(ax,np.array([a,b,c,apex]),0.15); ax.set_title('(b) Lift: tetrahedral apex\n1 bond from all three corners',fontsize=9)
from ssmsim.core import grow
g=grow(3000,seed=0,refine=True); P=g['pos']; deg=g['deg']
ax=fig.add_subplot(1,3,3,projection='3d')
col=np.where(deg>=12,GR,np.where(deg>=10,OR,'#c0392b'))
ax.scatter(*P.T,s=4,c=col,depthshade=False,alpha=.8)
clean(ax,15,-50); eqlim(ax,P,0); ax.set_title('(c) Grown network, 3000 nodes\ngreen: 12 bonds (FCC) · orange: 10–11 · red: fewer',fontsize=9)
plt.tight_layout(); plt.savefig('bg1_growth.pdf'); plt.savefig('bg1_growth.png',dpi=130)
# ---------------- Figure: code ----------------
V=np.array(sorted({p for v in [(1,1,0),(1,-1,0),(-1,-1,0)] for p in itertools.permutations(v)}),float)
fig=plt.figure(figsize=(12,3.4))
ax=fig.add_subplot(1,4,1,projection='3d')
for v in V: ax.plot(*np.array([[0,0,0],v]).T,color=BL,lw=2)
for u,w in itertools.combinations(V,2):
    if abs(np.linalg.norm(u-w)-np.sqrt(2))<1e-9: ax.plot(*np.array([u,w]).T,color=GY,lw=.6)
ax.scatter(*V.T,s=25,color=BL); ax.scatter(0,0,0,s=60,color='k')
clean(ax); eqlim(ax,V,0); ax.set_title('(a) Z check: the 12 bonds\nat a node',fontsize=9)
ax=fig.add_subplot(1,4,2,projection='3d')
E6=np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],float)
for u,w in itertools.combinations(E6,2):
    if abs(np.linalg.norm(u-w)-np.sqrt(2))<1e-9: ax.plot(*np.array([u,w]).T,color=OR,lw=2)
ax.scatter(*E6.T,s=30,color=BL); ax.scatter(0,0,0,s=50,marker='s',color=OR)
clean(ax); eqlim(ax,E6,0.2); ax.set_title('(b) X check: the 12 edges of an\noctahedron around a void (square)',fontsize=9)
t0=np.array([0,0,0.]); t1=np.array([1,1,0.]); t2=np.array([1,0,1.]); t3=np.array([0,1,1.])
ax=fig.add_subplot(1,4,3,projection='3d')
for p,q in itertools.combinations([t0,t1,t2,t3],2): ax.plot(*np.array([p,q]).T,color=GY,lw=.8,ls=':')
for p,q in [(t1,t2),(t2,t3),(t3,t1)]: ax.plot(*np.array([p,q]).T,color=GR,lw=3)
ax.scatter(*np.array([t0,t1,t2,t3]).T,s=40,color=BL)
clean(ax,20,-40); eqlim(ax,np.array([t0,t1,t2,t3]),0.2); ax.set_title('(c) Weight-3 X logical:\na bond triangle',fontsize=9)
ax=fig.add_subplot(1,4,4,projection='3d')
for p,q in itertools.combinations([t0,t1,t2,t3],2): ax.plot(*np.array([p,q]).T,color=GY,lw=.8,ls=':')
for q in (t1,t2,t3): ax.plot(*np.array([t0,q]).T,color=GR,lw=3)
ax.scatter(*np.array([t0,t1,t2,t3]).T,s=40,color=BL)
clean(ax,20,-40); eqlim(ax,np.array([t0,t1,t2,t3]),0.2); ax.set_title('(d) Weight-3 Z logical: the three\nbonds from a node to a triangle',fontsize=9)
plt.subplots_adjust(top=0.80,bottom=0.0,left=0.0,right=1.0,wspace=0.0); plt.savefig('bg2_code.pdf'); plt.savefig('bg2_code.png',dpi=130)
# ---------------- Figure: D4 history (schematic) ----------------
fig,ax=plt.subplots(figsize=(6.2,3.8))
X=np.arange(0,9); T=range(0,5)
for t in T:
    for x in X:
        node=(x+t)%2==0
        if t<4:
            for dx in (-1,1):
                if 0<=x+dx<=8: ax.plot([x,x+dx],[t,t+1],color='#8e7cc3',lw=1.2,zorder=1)
        if x+2<=8 and (x+t)%2==0: ax.plot([x,x+2],[t,t],color='k',lw=1,zorder=1)
        if (x+t)%2==1 and x+2<=8: ax.plot([x,x+2],[t,t],color='k',lw=1,zorder=1)
for t in T:
    for x in X:
        if (x+t)%2==0: ax.plot(x,t,'o',ms=9,color=BL,zorder=3)
        else: ax.plot(x,t,'s',ms=8,color=OR,zorder=3)
ax.set_yticks(list(T)); ax.set_yticklabels([f'$t_{i}$' for i in T]); ax.set_xticks([])
for s in ('top','right','bottom'): ax.spines[s].set_visible(False)
ax.set_xlabel('space (one spatial direction shown)'); ax.set_ylabel('tick')
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([],[],marker='o',ls='',color=BL,label='node (Z check)'),Line2D([],[],marker='s',ls='',color=OR,label='octahedral void (X check)'),
                   Line2D([],[],color='k',label='link within a slice (12 per site)'),Line2D([],[],color='#8e7cc3',label='link to the next or previous slice (6 + 6)')],
          loc='upper center',bbox_to_anchor=(0.5,-0.13),ncol=2,frameon=False,fontsize=8)
ax.set_title('The $D_4$ history: FCC slices of nodes and of voids, alternating in time',fontsize=9)
plt.tight_layout(); plt.savefig('bg3_history.pdf'); plt.savefig('bg3_history.png',dpi=130)
# ---------------- Figure: photon lattice and defect hops ----------------
fig=plt.figure(figsize=(9,4))
pts=np.array(list(itertools.product(range(3),repeat=3)),float)
nodes=pts[pts.sum(1)%2==0]; voids=pts[pts.sum(1)%2==1]
ax=fig.add_subplot(1,2,1,projection='3d')
for p in pts:
    for e in np.eye(3):
        q=p+e
        if (q<=2).all(): ax.plot(*np.array([p,q]).T,color='#8e7cc3',lw=1.2)
ax.scatter(*nodes.T,s=45,color=BL,depthshade=False); ax.scatter(*voids.T,s=40,marker='s',color=OR,depthshade=False)
clean(ax,18,-55); eqlim(ax,pts,0.1); ax.set_title('(a) Photon links: node (circle) to octahedral\nvoid (square) along the cube axes',fontsize=9)
ax=fig.add_subplot(1,2,2,projection='3d')
tv=np.array(list(itertools.product((0.5,1.5),repeat=3)))
for p in pts:
    for e in np.eye(3):
        q=p+e
        if (q<=2).all(): ax.plot(*np.array([p,q]).T,color=GY,lw=.4)
up=tv[(np.floor(tv).sum(1))%2==0]; dn=tv[(np.floor(tv).sum(1))%2==1]
ax.scatter(*up.T,s=60,marker='^',color=GR,depthshade=False); ax.scatter(*dn.T,s=60,marker='v',color='#c0392b',depthshade=False)
ax.plot(*np.array([[0.5,0.5,0.5],[1.5,0.5,0.5]]).T,color='k',lw=2.5)
ax.scatter(*nodes.T,s=12,color=BL,depthshade=False,alpha=.5)
clean(ax,18,-55); eqlim(ax,pts,0.1); ax.set_title('(b) Tetrahedral voids form a simple cubic lattice\n(two orientations); a defect hops along an axis',fontsize=9)
plt.tight_layout(); plt.savefig('bg4_lattices.pdf'); plt.savefig('bg4_lattices.png',dpi=130)
