#!/usr/bin/env python3
"""
Exact verification of Proposition (photon dispersion on D4*), hop-distance paper, Section 5.4 / Appendix A.
Every step uses exact rational (Gaussian-rational) arithmetic. Run:  python3 photon_exact.py  (sympy >= 1.12)
Writes all intermediate polynomials to photon_exact_log.txt.

Steps
 1. Lattice: 24 unit vectors of D4*, 12 link classes r (first nonzero component > 0).
 2. Triangular loops: ordered pairs (m1,m2) of unit vectors with m3=-(m1+m2) also a unit vector (192 per site).
    Flux of a loop = sum_i s_i A_{r_i}(c_i), with c_i the midpoint of edge i and s_i=+-1 its orientation.
    Quadratic Wilson kernel: M_ab(k) = sum_loops sum_{i in a, j in b} s_i s_j exp(i k.(c_j-c_i)).
 3. Light sector: B (12x4), rows r. Heavy sector: H = rational basis of ker B^T (orthogonal complement).
    The Schur complement S = B^T M B - B^T M H (H^T M H)^{-1} H^T M B depends only on span(H), and
    det[B H]^T M [B H] = det(H^T M H) det S, so the zeros of S are those of M (H^T M H is invertible near k=0).
 4. Expansion: all entries truncated at total degree 6; (H^T M H)^{-1} by Neumann series about k=0.
 5. On shell k=(p n, i p), gauge A_4=0; transverse projector Pi=1-n n^T; identities reduced modulo n.n-1.
"""
import itertools, sympy as sp
from fractions import Fraction as F
from sympy import QQ_I, Rational
from sympy.polys.rings import ring
log=open('photon_exact_log.txt','w')
def out(*a):
    s=' '.join(str(x) for x in a); print(s); log.write(s+'\n'); log.flush()
D=6
Rg,k1,k2,k3,k4=ring("k1 k2 k3 k4",QQ_I); K=[k1,k2,k3,k4]
tr=lambda p: Rg({m:c for m,c in p.items() if sum(m)<=D})
# 1. lattice
half=F(1,2)
N24=[tuple(F(s) if i==j else F(0) for i in range(4)) for j in range(4) for s in (1,-1)]
N24+=[tuple(half*s for s in sg) for sg in itertools.product((1,-1),repeat=4)]
S24=set(N24); R=[m for m in N24 if next(x for x in m if x!=0)>0]
def rep(m):
    return (R.index(m),1) if m in R else (R.index(tuple(-x for x in m)),-1)
out('Step 1: unit vectors',len(N24),' link classes',len(R)); out('  r =',[tuple(str(x) for x in r) for r in R])
# 2. loops and kernel weights
add=lambda u,v: tuple(a+b for a,b in zip(u,v)); W={}; nloop=0
for m1 in N24:
  for m2 in N24:
    m3=tuple(-(a+b) for a,b in zip(m1,m2))
    if m3 not in S24: continue
    nloop+=1; o=(F(0),)*4; ed=[]
    for m in (m1,m2,m3):
        i,s=rep(m); ed.append((i,s,add(o,tuple(x/2 for x in m)))); o=add(o,m)
    assert o==(0,0,0,0)
    for a,sa,ca in ed:
      for b,sb,cb in ed:
        d=tuple(y-x for x,y in zip(ca,cb)); W[(a,b,d)]=W.get((a,b,d),0)+sa*sb
W={key:w for key,w in W.items() if w}
out('Step 2: ordered triangular loops through the origin',nloop,'(each unoriented triangle of a site: 6 orderings)')
out('  distinct (a,b,displacement) terms in M:',len(W))
iu=QQ_I(0,1); cache={}
def expser(d):
    if d in cache: return cache[d]
    x=sum((Rg(QQ_I(Rational(d[i].numerator,d[i].denominator)))*K[i] for i in range(4)),Rg(0))
    o=Rg(1); t=Rg(1)
    for n in range(1,D+1): t=tr(t*x*Rg(iu))*Rg(QQ_I(Rational(1,n))); o+=t
    cache[d]=o; return o
M=[[Rg(0)]*12 for _ in range(12)]
for (a,b,d),w in W.items(): M[a][b]+=expser(d)*w
mul=lambda A,B:[[tr(sum((A[i][l]*B[l][j] for l in range(len(B))),Rg(0))) for j in range(len(B[0]))] for i in range(len(A))]
T=lambda A:[list(r) for r in zip(*A)]
toR=lambda x: Rg(QQ_I.from_sympy(sp.nsimplify(x)))
ks=sp.symbols('k1:5')
tosp=lambda p: sum((QQ_I.to_sympy(c)*sp.prod([ks[t]**m[t] for t in range(4)]) for m,c in p.items()),sp.S(0))
# gauge null vector check, exact through degree 6
g=[Rg(0)]*12
for a,r in enumerate(R):  # 2i sin(k.r/2) = e^{ik.r/2}-e^{-ik.r/2}
    g[a]=expser(tuple(x/2 for x in r))-expser(tuple(-x/2 for x in r))
Mg=[tr(sum((M[a][b]*g[b] for b in range(12)),Rg(0))) for a in range(12)]
out('Step 2 check: M g = 0 through degree 6:',all(x==0 for x in Mg))
# 3. light / heavy
Bs=sp.Matrix([[Rational(r[j].numerator,r[j].denominator) for j in range(4)] for r in R])
Hs=sp.Matrix.hstack(*(Bs.T).nullspace())
out('Step 3: B^T B =',list(Bs.T*Bs),' heavy basis dim',Hs.shape[1],' B^T H = 0:',(Bs.T*Hs)==sp.zeros(4,8))
out('  H columns (rational basis of ker B^T):'); [out('   ',list(Hs[:,j])) for j in range(8)]
Bm=[[toR(Bs[i,j]) for j in range(4)] for i in range(12)]; Hm=[[toR(Hs[i,j]) for j in range(8)] for i in range(12)]
MB=mul(M,Bm); MH=mul(M,Hm)
BMB=mul(T(Bm),MB); BMH=mul(T(Bm),MH); HMB=mul(T(Hm),MB); HMH=mul(T(Hm),MH)
c0=lambda p: p.get((0,0,0,0),QQ_I(0))
H0=sp.Matrix(8,8,lambda i,j: QQ_I.to_sympy(c0(HMH[i][j])))
out('  H^T M(0) H eigenvalues:',sp.Matrix(H0).eigenvals(), '(invertible)')
out('  B^T M(0) B = 0:',all(QQ_I.to_sympy(c0(BMB[i][j]))==0 for i in range(4) for j in range(4)), '  M(0) B = 0:', all(QQ_I.to_sympy(c0(MB[i][j]))==0 for i in range(12) for j in range(4)))
# 4. Schur complement through degree 6
H0i=H0.inv(); H0iR=[[toR(H0i[i,j]) for j in range(8)] for i in range(8)]
dH=[[HMH[i][j]-Rg(c0(HMH[i][j])) for j in range(8)] for i in range(8)]
A=[[-x for x in r] for r in mul(H0iR,dH)]; Hi=H0iR; term=H0iR
for n in range(D): term=mul(A,term); Hi=[[Hi[i][j]+term[i][j] for j in range(8)] for i in range(8)]
X=mul(BMH,mul(Hi,HMB)); S=sp.Matrix(4,4,lambda i,j: sp.expand(tosp(BMB[i][j]-X[i][j])))
def part(e,d):
    if e==0: return sp.S(0)
    return sum((c*sp.prod([ks[t]**m[t] for t in range(4)]) for m,c in sp.Poly(e,*ks).terms() if sum(m)==d),sp.S(0))
S2,S4,S6=[S.applyfunc(lambda e,d=d: part(e,d)) for d in (2,4,6)]
out('Step 4: constant and odd orders vanish:',all(part(S[i,j],d)==0 for i in range(4) for j in range(4) for d in (0,1,3,5)))
out('  S symmetric:',(S-S.T).applyfunc(sp.expand)==sp.zeros(4,4))
ksq=sum(x*x for x in ks)
c=S2[0,0].coeff(ks[1],2)
out('  S2 = c (k^2 delta - k k), c =',c,':',(S2-sp.Matrix(4,4,lambda i,j: c*(ksq*sp.KroneckerDelta(i,j)-ks[i]*ks[j]))).applyfunc(sp.expand)==sp.zeros(4,4))
for d,Sd in ((4,S4),(6,S6)):
    for (i,j) in ((0,0),(0,1)):
        out(f'  S{d}[{i+1},{j+1}] =',sp.factor(Sd[i,j]))
out('  (other entries follow by the W(F4) symmetry; full matrices in this log below)')
out('  S4 =',list(S4)); out('  S6 =',list(S6))
# 5. on shell
n=sp.symbols('n1:4'); u2=1-n[0]**2-n[1]**2
def redu(e):
    e=sp.expand(sp.together(e)); num,den=sp.fraction(e)
    r=lambda x: sp.expand(sp.rem(sp.Poly(sp.expand(x),n[2]),sp.Poly(n[2]**2-u2,n[2])).as_expr())
    return sp.simplify(r(num)/r(den))
on={ks[0]:n[0],ks[1]:n[1],ks[2]:n[2],ks[3]:sp.I}   # p=1, omega=p; homogeneous degrees restore p
sp3=lambda A: sp.Matrix(3,3,lambda i,j: sp.expand(A[i,j].subs(on)))
Q2,Q4,Q6=sp3(S2),sp3(S4),sp3(S6); nn=sp.Matrix(n); Pi=sp.eye(3)-nn*nn.T
T4=(Pi*Q4*Pi).applyfunc(redu); out('Step 5: (i)  Pi S4 Pi = 0 on shell:',T4==sp.zeros(3,3))
L=redu((nn.T*Q2*nn)[0]); out('  n^T S2 n on shell =',L)
mix=(Pi*Q4*nn).applyfunc(redu); out('  Pi S4 n on shell =',list(mix))
T6=(Pi*Q6*Pi-mix*mix.T/L).applyfunc(redu); q=redu(T6.trace()/2)
out('  (ii) Pi S6 Pi - (Pi S4 n)(n^T S4 Pi)/(n^T S2 n) = q Pi:',(T6-q*Pi).applyfunc(redu)==sp.zeros(3,3))
P=(n[0]**2+n[1]**2)*(n[1]**2+n[2]**2)*(n[2]**2+n[0]**2)
out('  q =',sp.factor(q)); out('  (iii) q/(2c) + P/640 = 0:',redu(q/(2*c)+P/640)==0)
out('Result: v_p/c - 1 = q (a p)^4/(2c) = -(a p)^4 P(n)/640 ; v_g/c - 1 = -(a p)^4 P(n)/128')
# hypercubic covariance: every entry follows from [1,1] and [1,2] by axis permutations
ok=True
for perm in itertools.permutations(range(4)):
    sub={ks[i]:ks[perm[i]] for i in range(4)}
    for (i,j) in ((0,0),(0,1)):
        for Sd in (S4,S6):
            ok &= sp.expand(Sd[i,j].subs(sub,simultaneous=True)-Sd[perm[i],perm[j]])==0
out('Covariance: all entries of S4, S6 obtained from [1,1], [1,2] by permuting axes:',ok)
out('S4 closed form -(k^2/12)(k^2 delta - k k):',(S4+ksq/12*sp.Matrix(4,4,lambda i,j: ksq*sp.KroneckerDelta(i,j)-ks[i]*ks[j])).applyfunc(sp.expand)==sp.zeros(4,4))
