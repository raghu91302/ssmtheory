import mpmath as mp, itertools, sys, json
from gauge import Meff, mp
mp.mp.dps=40
def e3(M):
    s=0
    for idx in itertools.combinations(range(4),3):
        sub=mp.matrix([[M[i,j] for j in idx] for i in idx]); s+=mp.det(sub)
    return s
def roots(p,n):
    n=[mp.mpf(x) for x in n]; nn=mp.sqrt(sum(x*x for x in n)); n=[x/nn for x in n]
    f=lambda s: e3(Meff([p*n[0],p*n[1],p*n[2],1j*mp.sqrt(p*p+s)]))
    S=p**6/20
    ts=[mp.mpf(j)/3 for j in range(-3,4)]; ys=[f(S*t) for t in ts]
    A=mp.matrix([[t**d for d in range(5)] for t in ts]); c=mp.lu_solve(A.T*A,A.T*mp.matrix(ys))
    rts=mp.polyroots([c[4],c[3],c[2],c[1],c[0]],maxsteps=400,extraprec=400)
    rts=[S*r for r in rts if abs(r)<3]
    out=[]
    for s in rts:
        om=mp.sqrt(p*p+s)
        Me=Meff([p*n[0],p*n[1],p*n[2],1j*om])
        E,ER=mp.eig(Me)
        # polarization: eigenvector of the eigenvalue closest to zero that is not the gauge direction
        kv=[p*n[0],p*n[1],p*n[2],1j*om]
        best=None
        for i in range(4):
            v=ER[:,i]; nv=mp.sqrt(sum(abs(v[j])**2 for j in range(4))); v=[v[j]/nv for j in range(4)]
            spatial_perp=abs(sum(v[j]*n[j] for j in range(3)))   # component along n
            cand=(abs(E[i]),i,v)
            if best is None or cand[0]<best[0]: pass
        # better: null space of Me is 2-dim at a root; take the eigenvectors with the two smallest |eigenvalue|
        order=sorted(range(4),key=lambda i: abs(E[i]))[:2]
        vecs=[[ER[j,i] for j in range(4)] for i in order]
        # remove gauge-like vector (closest to k); keep the other
        def frac_k(v):
            num=abs(sum(v[j]*kv[j].conjugate() for j in range(4))); return num/(mp.sqrt(sum(abs(x)**2 for x in v))*mp.sqrt(sum(abs(x)**2 for x in kv)))
        vecs.sort(key=frac_k); v=vecs[0]; nv=mp.sqrt(sum(abs(x)**2 for x in v)); v=[x/nv for x in v]
        along_n=abs(sum(v[j]*n[j] for j in range(3))); time=abs(v[3])
        out.append(dict(s=s, dv=om/p-1, along_n=along_n, time=time, pol=[complex(x) for x in v]))
    return out
if __name__=='__main__':
    for lab,n in [('[100]',(1,0,0)),('[110]',(1,1,0)),('[111]',(1,1,1)),('[210]',(2,1,0))]:
        for p in (mp.mpf('0.02'),mp.mpf('0.04')):
            res=roots(p,n)
            print(lab,'p=',float(p))
            for r in sorted(res,key=lambda r: float(mp.re(r['dv']))):
                print(f"   phase-1 = {complex(r['dv']).real:+.6e}   /p^4 = {complex(r['dv']).real/float(p)**4:+.6e}   /p^6 = {complex(r['dv']).real/float(p)**6:+.4e}   pol: along n {float(r['along_n']):.3f}, time {float(r['time']):.3f}")
