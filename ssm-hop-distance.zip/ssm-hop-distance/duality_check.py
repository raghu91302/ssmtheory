"""Check that one D4 time step (half-lattice shift) maps FCC-code star supports onto octahedron supports and back,
and triangle X logicals onto claw Z logicals, on a periodic box of even size L."""
import numpy as np
from fcc import FCC
from protect_util import tri_claw
L=8; F=FCC(L); P=np.array(F.nodes); mi=lambda x:(x+L/2)%L-L/2
def mid(b):
    a,c=F.bonds[b]; m=(P[a]+mi(P[c]-P[a])/2)%L; return tuple(np.round(m*2).astype(int)%(2*L))
M=[mid(b) for b in range(F.m)]; idx={m:i for i,m in enumerate(M)}
supp=lambda H: {frozenset(M[j] for j in H.indices[H.indptr[i]:H.indptr[i+1]]) for i in range(H.shape[0])}
Zs=supp(F.HZ.tocsr()); Xs=supp(F.HX.tocsr()); d=np.array([2,0,0])
shift=lambda S: frozenset(tuple((np.array(q)+d)%(2*L)) for q in S)
print('stars -> octahedra:',{shift(s) for s in Zs}==Xs,' octahedra -> stars:',{shift(s) for s in Xs}==Zs)
tri,claw=tri_claw(F)
print('triangles -> claws:',{frozenset(idx[tuple((np.array(M[b])+d)%(2*L))] for b in t) for t in tri}==set(claw))
