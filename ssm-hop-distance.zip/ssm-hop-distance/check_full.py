"""Independent check: zeros of det(M + xi g g^T) on the full 12 link fields (lattice Lorenz gauge fixing),
no light/heavy split. Expected roots near the light cone: the photon branches, and the gauge-fixing mode,
which follows the D4* scalar kernel (phase -1 = -P/240 p^4)."""
import mpmath as mp
import gauge
mp.mp.dps=50
def D(k,xi=mp.mpf(1)):
    Mk=gauge.M(k); g=gauge.gauge(k)
    G=mp.matrix(12,12)
    for a in range(12):
        for b in range(12): G[a,b]=g[a]*g[b]
    return mp.det(Mk-xi*G)
for lab,n in [('[210]',(2,1,0)),('[111]',(1,1,1)),('[110]',(1,1,0))]:
    p=mp.mpf('0.1'); n=[mp.mpf(x) for x in n]; nn=mp.sqrt(sum(x*x for x in n)); n=[x/nn for x in n]
    f=lambda s: D([p*n[0],p*n[1],p*n[2],1j*mp.sqrt(p*p+s)])
    S=p**6/5
    ts=[mp.mpf(j)/6 for j in range(-6,7)]; ys=[f(S*t) for t in ts]
    A=mp.matrix([[t**d for d in range(8)] for t in ts]); c=mp.lu_solve(A.T*A,A.T*mp.matrix(ys))
    rts=mp.polyroots([c[i] for i in range(7,-1,-1)],maxsteps=800,extraprec=800)
    rts=sorted([S*r for r in rts if abs(r)<1.5],key=lambda r: mp.re(r))
    P=(n[0]**2+n[1]**2)*(n[1]**2+n[2]**2)*(n[2]**2+n[0]**2)
    print(lab,' roots (phase-1)/(p^4 P):',[mp.nstr(mp.re(mp.sqrt(p*p+r)/p-1)/(p**4*P),7) for r in rts],'   expect photon -1/640 =',mp.nstr(-mp.mpf(1)/640,7),', gauge-fixing mode -1/240 =',mp.nstr(-mp.mpf(1)/240,7))
