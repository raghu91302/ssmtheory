"""Exact random-walk distribution on FCC (D3) and D4 by repeated convolution; operational distance
d_prop^2 = -(2 n L^2/d) log[P(x,n)/P(0,n)] compared with Euclidean |x| in different directions."""
import numpy as np, itertools, json
def roots(n):
    R=set()
    for i,j in itertools.combinations(range(n),2):
        for si,sj in itertools.product((1,-1),repeat=2):
            v=[0]*n; v[i]=si; v[j]=sj; R.add(tuple(v))
    return np.array(sorted(R))
out={}
for name,dim,nsteps,W in (('FCC',3,64,70),('D4',4,24,26)):
    R=roots(dim); S=2*W+1; P=np.zeros((S,)*dim); P[(W,)*dim]=1.0
    for _ in range(nsteps):
        Q=np.zeros_like(P)
        for r in R: Q+=np.roll(P,tuple(r),axis=tuple(range(dim)))
        P=Q/len(R)
    L2=2.0  # bond length^2 in integer units
    P0=P[(W,)*dim]
    dirs={'bond':(1,1)+(0,)*(dim-2),'axis':(1,)+(0,)*(dim-1),'diag3':(1,1,1)+(0,)*(dim-3)}
    if dim==4: dirs['diag4']=(1,1,1,1)
    res={}
    for lab,u in dirs.items():
        u=np.array(u); rows=[]
        for m in range(1,40):
            x=m*u
            if np.abs(x).max()>W-1 or x.sum()%2: continue
            px=P[tuple(x+W)]
            if px<=0: continue
            e2=(x@x)/L2                       # Euclidean distance^2 in bond lengths^2
            dp2=-(2*nsteps*L2/dim)*np.log(px/P0)/L2
            rows.append((round(float(np.sqrt(e2)),3),round(float(np.sqrt(dp2)/np.sqrt(e2)),4),round(float(np.sqrt(e2)/np.sqrt(nsteps)),3)))
        res[lab]=rows
    out[name]=dict(steps=nsteps,res=res)
    print(name,'n =',nsteps,' (columns: Euclidean distance in L, d_prop/Euclid, distance/sqrt(n))')
    for lab,rows in res.items(): print('  ',lab,rows[:10])
json.dump(out,open('dprop.json','w'),indent=1)
