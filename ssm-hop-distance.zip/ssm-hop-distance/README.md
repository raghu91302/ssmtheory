# Emergent spacetime from entanglement hops: code

Scripts for

> R. Kulkarni, *Emergent Spacetime from Entanglement Hops: Distance, Temporal Duality, and
> Quartic Photon Dispersion in the Selection–Stitch Vacuum* (2026).

Every number, table and figure in the paper comes from one of these scripts.

## Install

    pip install -r requirements.txt

The scripts for grown networks (`calc.py`, `figs.py`, `chains.py`, `bgfigs.py`) grow SSM networks
with the growth simulator `ssmsim` released with the Quantum Reports paper (doi:10.3390/quantum8040121).
Put the folder that contains `ssmsim` on the path with

    export SSMSIM_PATH=/path/to/folder/containing/ssmsim

All other scripts are self-contained.

## Scripts by section

| Section | What | Script |
|---|---|---|
| 3 | Shortest-hop formula, BFS check, grown-network hop ratios (Table 1, Fig. 1) | `calc.py`, `figs.py` |
| 4.1 | Random walks on a grown network (Table 2) | `calc.py` |
| 4.1 | Exact walk distribution and operational distance d_prop (Table 3) | `dprop.py` → `dprop.json` |
| 4.2 | Bond-direction moments, wave-speed spread (Fig. 2) | `calc.py`, `figs.py` |
| 5.1 | Sixth-order expansion of the D4 scalar kernel, J6 | `expand6.py` |
| 5.2 | Real-time phase and group speeds, axial dispersion (Table 4) | `lorentz6.py`, `vel.py` |
| 5.3 | W(F4) invariance of J6; D4* scalar | `universal.py` |
| 5.4 | Photon on D4*: exact proof of Proposition 3 (Appendix A) | `photon_exact.py` → `photon_exact_log.txt` |
| 5.4 | Photon: numerical checks (Table 5) | `gauge.py`, `disp.py`, `disp2.py`, `check_full.py` |
| 6.2–6.3 | Duality: stars ↔ octahedra, triangles ↔ claws (Fig. 3) | `duality_check.py` (uses `fcc.py`, `protect_util.py`), `figs.py` |
| 6.5 | Growth order vs. proper time (Table 6) | `chains.py` |
| 2 | Background figures | `bgfigs.py` |

`numbers.json`, `fig1_numbers.json` and `dprop.json` are the stored outputs used in the paper.

## Quick check of the main new result

    python photon_exact.py

This runs in about one minute and prints `True` for each identity of Proposition 3, ending with

    Result: v_p/c - 1 = -(a p)^4 P(n)/640 ; v_g/c - 1 = -(a p)^4 P(n)/128
