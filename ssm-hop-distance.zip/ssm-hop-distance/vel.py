import mpmath as mp, itertools
mp.mp.dps=50
def kern(k,a=1):
    b=a/mp.sqrt(2); return 4*sum(1-mp.cos(b*k[m])*mp.cos(b*k[n]) for m,n in itertools.combinations(range(4),2))
def omega(p,n):
    n=[mp.mpf(x) for x in n]; s=mp.sqrt(sum(x*x for x in n)); n=[x/s for x in n]
    f=lambda w: mp.re(kern([p*n[0],p*n[1],p*n[2],1j*w]))
    return mp.findroot(f,p)
for lab,n in [('[100]',(1,0,0)),('[110]',(1,1,0)),('[111]',(1,1,1))]:
    print(lab)
    for p in (mp.mpf('0.02'),mp.mpf('0.04'),mp.mpf('0.08')):
        w=omega(p,n); h=p*mp.mpf('1e-12')
        vg=(omega(p+h,n)-omega(p-h,n))/(2*h); vp=w/p
        print(f'  ap={float(p):.2f}  phase-1={float(vp-1):+.6e}  (phase-1)/(ap)^4={float((vp-1)/p**4):+.6e}  group-1={float(vg-1):+.6e}  (group-1)/(ap)^4={float((vg-1)/p**4):+.6e}  (group-1)/(ap)^6={float((vg-1)/p**6):+.6e}  (phase-1)/(ap)^6={float((vp-1)/p**6):+.6e}')
print('reference: 1/240=%.6e 1/960=%.6e 1/810=%.6e 1/48=%.6e 5/960=%.6e 5/810=%.6e 1/6912=%.6e'%(1/240,1/960,1/810,1/48,5/960,5/810,1/6912))
