import mpmath as mp, itertools, sys
import gauge
mp.mp.dps=60
from disp import e3
def three_roots(p,n,S=None):
    n=[mp.mpf(x) for x in n]; nn=mp.sqrt(sum(x*x for x in n)); n=[x/nn for x in n]
    f=lambda s: e3(gauge.Meff([p*n[0],p*n[1],p*n[2],1j*mp.sqrt(p*p+s)]))
    if S is None: S=p**6/20
    ts=[mp.mpf(j)/4 for j in range(-4,5)]; ys=[f(S*t) for t in ts]
    A=mp.matrix([[t**d for d in range(6)] for t in ts]); c=mp.lu_solve(A.T*A,A.T*mp.matrix(ys))
    rts=mp.polyroots([c[5],c[4],c[3],c[2],c[1],c[0]],maxsteps=600,extraprec=600)
    rts=sorted([S*r for r in rts if abs(r)<2],key=lambda r: mp.re(r))
    # polish each root with Newton on f
    out=[]
    for r in rts:
        try: r=mp.findroot(f,r,tol=mp.mpf(10)**(-50)*abs(S))
        except Exception: pass
        out.append(mp.sqrt(p*p+r)/p-1)
    return out
for lab,n in [('[100]',(1,0,0)),('[210]',(2,1,0)),('[321]',(3,2,1)),('[111]',(1,1,1))]:
    for p in (mp.mpf('0.05'),mp.mpf('0.1'),mp.mpf('0.2')):
        S=p**6/20 if lab!='[100]' else p**8/100
        if lab=='[100]': S=p**6/1000
        r=three_roots(p,n,S)
        print(lab,'p=',float(p),' (phase-1)/p^4:',[mp.nstr(mp.re(x)/p**4,12) for x in r],' (phase-1)/p^6:',[mp.nstr(mp.re(x)/p**6,8) for x in r])
