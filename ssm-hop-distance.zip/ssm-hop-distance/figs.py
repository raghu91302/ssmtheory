import sys, json, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import os; sys.path.insert(0, os.environ.get('SSMSIM_PATH', '.'))  # folder containing the ssmsim package
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
N=json.load(open('numbers.json'))
# ---------- Figure 1: hop anisotropy ----------
from scipy.sparse.csgraph import shortest_path
import scipy.sparse as sp
from ssmsim.core import grow
from quantum_lattice import depth
fig,ax=plt.subplots(1,2,figsize=(10,4.2))
th=np.linspace(0,2*np.pi,721); u=np.c_[np.cos(th),np.sin(th),0*th]
hc=lambda v: np.maximum(np.abs(v).max(1),np.abs(v).sum(1)/2)        # continuum FCC hop norm (integer coords)
r=hc(u)/(1/np.sqrt(2))                                                  # hops per bond length
a=ax[0]; a.plot(th*180/np.pi,r,color='#1f4e79',lw=2,label='FCC, exact')
a.axhline(1,color='gray',ls=':',lw=1)
for x,lab in [(45,'[110] bond'),(0,'[100]'),(90,'[010]'),(135,'[$\\bar1$10] bond')]:
    a.annotate(lab,(x,hc(np.array([[np.cos(np.radians(x)),np.sin(np.radians(x)),0]]))[0]*np.sqrt(2)),textcoords='offset points',xytext=(0,8),ha='center',fontsize=8)
a.set_xlabel('direction in the (001) plane (degrees)'); a.set_ylabel('hops per bond length of distance'); a.set_xlim(0,180); a.set_ylim(0.9,1.5)
a.set_title('(a) Shortest-hop distance, ideal FCC',fontsize=10)
g=grow(100000,seed=0,refine=True); pos=g['pos']; adj=g['adj']; deg=g['deg']; n=len(pos)
rows=np.repeat(np.arange(n),deg); cols=np.concatenate([adj[v,:deg[v]] for v in range(n)])
A=sp.csr_matrix((np.ones(len(cols)),(rows,cols)),shape=(n,n))
src=int(np.argmin(np.linalg.norm(pos-pos.mean(0),axis=1))); D=shortest_path(A,unweighted=True,indices=src)
d=depth(pos); vec=pos-pos[src]; e=np.linalg.norm(vec,axis=1); m=(d>=3)&(e>8)&np.isfinite(D)
b=pos[adj[src,:deg[src]]]-pos[src]; b/=np.linalg.norm(b,axis=1)[:,None]
ang=np.degrees(np.arccos(np.clip(np.abs((vec[m]/e[m][:,None])@b.T).max(1),0,1)))
a=ax[1]; a.scatter(ang,D[m]/e[m],s=2,alpha=.15,color='#1f4e79',rasterized=True)
bins=np.arange(0,56,5); c=0.5*(bins[1:]+bins[:-1]); med=[np.median((D[m]/e[m])[(ang>=lo)&(ang<hi)]) if ((ang>=lo)&(ang<hi)).sum()>20 else np.nan for lo,hi in zip(bins[:-1],bins[1:])]
a.plot(c,med,'o-',color='#c55a11',lw=2,label='median')
a.set_xlabel('angle to the nearest bond direction (degrees)'); a.set_ylabel('hops / Euclidean distance'); a.set_ylim(0.95,1.5)
a.set_title(f'(b) Grown network, {n:,} nodes',fontsize=10); a.legend(frameon=False,loc='lower right')
plt.tight_layout(); plt.savefig('fig1_hops.pdf'); plt.savefig('fig1_hops.png',dpi=150)
json.dump(dict(grown_points=int(m.sum()),median_by_angle=dict(zip([float(x) for x in c],[None if np.isnan(y) else round(float(y),3) for y in med]))),open('fig1_numbers.json','w'),indent=1)
# ---------- Figure 2: wave-speed anisotropy ----------
fig,a=plt.subplots(figsize=(5.2,4))
for name,col,mk in (('FCC','#1f4e79','o'),('D4','#c55a11','s')):
    rows=N[f'{name}_dispersion']; ka=np.array([r['ka'] for r in rows]); an=np.array([r['aniso'] for r in rows])
    a.loglog(ka,an,mk+'-',color=col,label=name+(' (12 neighbors)' if name=='FCC' else ' (24 neighbors)'))
x=np.array([0.05,0.8]); a.loglog(x,6.9e-3*x**2,':',color='gray'); a.loglog(x,1.72e-4*x**4,'--',color='gray')
a.text(0.12,2.2e-4,'slope 2',fontsize=9,color='gray'); a.text(0.12,9e-9,'slope 4',fontsize=9,color='gray')
a.set_xlabel('$ka$ (wavenumber × bond length)'); a.set_ylabel('direction spread of wave speed')
a.legend(frameon=False); a.set_title('Wave-speed anisotropy',fontsize=10)
plt.tight_layout(); plt.savefig('fig2_waves.pdf'); plt.savefig('fig2_waves.png',dpi=150)
# ---------- Figure 3: duality in the z=0 plane ----------
fig,a=plt.subplots(figsize=(5.6,5.6))
R=range(-2,3)
for x in R:
    for y in R:
        if (x+y)%2==0: a.plot(x,y,'o',ms=11,color='#1f4e79',zorder=3)
        else: a.plot(x,y,'o',ms=11,mfc='white',mec='#c55a11',mew=2,zorder=3)
for x in R:
    for y in R:
        for dx,dy in ((1,1),(1,-1)):
            if x+dx in R and y+dy in R:
                col,ls=('#1f4e79','-') if (x+y)%2==0 else ('#c55a11','--')
                a.plot([x,x+dx],[y,y+dy],ls,color=col,lw=0.8,alpha=.35,zorder=1)
v=(0,0); w=(1,0)
for dx,dy in ((1,1),(1,-1),(-1,1),(-1,-1)):
    a.plot([v[0],v[0]+dx],[v[1],v[1]+dy],'-',color='#1f4e79',lw=3,zorder=2)
sq=[(w[0]+1,w[1]),(w[0],w[1]+1),(w[0]-1,w[1]),(w[0],w[1]-1),(w[0]+1,w[1])]
for p,q in zip(sq[:-1],sq[1:]): a.plot([p[0],q[0]],[p[1],q[1]],'-',color='#1f4e79',lw=3,alpha=.0)
for dx,dy in ((1,1),(1,-1),(-1,1),(-1,-1)):
    a.plot([w[0],w[0]+dx],[w[1],w[1]+dy],'--',color='#c55a11',lw=3,zorder=2)
mids=set()
for dx,dy in ((1,1),(1,-1),(-1,1),(-1,-1)): mids.add((w[0]+dx/2,w[1]+dy/2))
for mx,my in mids: a.plot(mx,my,'D',ms=8,color='#2e7d32',zorder=4)
a.annotate('$v$',(v[0]-.12,v[1]+.18),fontsize=13); a.annotate('$w$',(w[0]+.1,w[1]+.15),fontsize=13)
a.set_aspect('equal'); a.axis('off'); a.set_xlim(-2.4,2.4); a.set_ylim(-2.4,2.4)
a.set_title('One plane of the lattice ($z=0$)\nfilled: nodes at time $t$ · open: nodes at time $t+1$ (octahedron centers at $t$)\ngreen: qubits (bond midpoints) shared by both times',fontsize=9)
plt.tight_layout(); plt.savefig('fig3_duality.pdf'); plt.savefig('fig3_duality.png',dpi=150)
print(json.load(open('fig1_numbers.json')))
