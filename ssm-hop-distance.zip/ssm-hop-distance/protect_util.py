import numpy as np, itertools
from fcc import V12
def tri_claw(F):
    tri=set(); claw=set()
    for p in F.nodes:
        p=np.array(p); nb=[p+v for v in V12]
        for a,b in itertools.combinations(nb,2):
            if np.abs(a-b).sum()==2 and np.count_nonzero(a-b)==2: tri.add(frozenset((F.b(p,a),F.b(p,b),F.b(a,b))))
        for a,b,c in itertools.combinations(nb,3):
            if all(np.abs(x-y).sum()==2 and np.count_nonzero(x-y)==2 for x,y in ((a,b),(a,c),(b,c))): claw.add(frozenset((F.b(p,a),F.b(p,b),F.b(p,c))))
    return tri,claw
