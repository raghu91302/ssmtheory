"""All numbers for the hop-distance paper."""
import sys, json, itertools, numpy as np
import os; sys.path.insert(0, os.environ.get('SSMSIM_PATH', '.'))  # folder containing the ssmsim package
OUT={}
def roots(n):
    R=set()
    for i,j in itertools.combinations(range(n),2):
        for si,sj in itertools.product((1,-1),repeat=2):
            v=[0]*n; v[i]=si; v[j]=sj; R.add(tuple(v))
    return np.array(sorted(R))
F,D=roots(3),roots(4)
# 1) BFS check of hop formula h(v)=max(max|v_i|, ceil(sum|v_i|/2)) for D3 (FCC) and D4
def bfs(R,rmax):
    dist={tuple([0]*R.shape[1]):0}; front=[np.zeros(R.shape[1],int)]
    for d in range(1,rmax+1):
        nf=[]
        for p in front:
            for r in R:
                q=tuple(p+r)
                if q not in dist: dist[q]=d; nf.append(np.array(q))
        front=nf
    return dist
h=lambda v: int(max(np.abs(v).max(), (np.abs(v).sum()+1)//2))
for name,R,rm in (('FCC',F,6),('D4',D,4)):
    dist=bfs(R,rm); ok=all(h(np.array(k))==d for k,d in dist.items() if d<rm)
    OUT[f'hop_formula_ok_{name}']=bool(ok); OUT[f'hop_formula_points_{name}']=sum(1 for d in dist.values() if d<rm)
# 2) hop anisotropy (ideal): hops per bond length by direction
def ratio(v): v=40*np.array(v); return h(v)/(np.linalg.norm(v)/np.sqrt(2))
OUT['FCC_ratio']={str(d):round(ratio(d),4) for d in [(1,1,0),(1,1,1),(1,0,0)]}
OUT['D4_ratio']={str(d):round(ratio(d),4) for d in [(1,1,0,0),(1,1,1,0),(1,0,0,0),(1,1,1,1),(0,0,0,1)]}
# 3) moments and Laplacian expansion: sum_j (k.n_j)^m with unit n_j, |k|=1
rng=np.random.default_rng(1)
for name,R in (('FCC',F),('D4',D)):
    n=R/np.linalg.norm(R,axis=1)[:,None]; U=rng.normal(size=(50000,R.shape[1])); U/=np.linalg.norm(U,axis=1)[:,None]
    for m in (2,4,6):
        s=((U@n.T)**m).sum(1); OUT[f'{name}_moment{m}']=dict(mean=round(float(s.mean()),5),min=round(float(s.min()),5),max=round(float(s.max()),5))
    # phase velocity anisotropy vs ka
    def lap(k): return np.sum(1-np.cos(n@k))
    dirs=U[:2000]; rows=[]
    for ka in (0.05,0.1,0.2,0.3,0.5,0.8):
        v=np.array([np.sqrt(2*lap(ka*u))/ka for u in dirs]); v0=np.sqrt(len(R)/R.shape[1])   # long-wavelength speed
        rows.append(dict(ka=ka,mean_slowdown=round(float(1-v.mean()/v0),8),aniso=float((v.max()-v.min())/v.mean())))
    OUT[f'{name}_dispersion']=rows
# 4) random walks: ideal lattices (exact covariance) and grown network
for name,R in (('FCC',F),('D4',D)):
    C=(R.T@R)/len(R)/2.0          # per-step covariance in units of bond length^2 (bond length sqrt2 in integer coords)
    OUT[f'{name}_step_cov_eigs']=np.round(np.linalg.eigvalsh(C),6).tolist()
from ssmsim.core import grow
from quantum_lattice import depth
g=grow(100000,seed=0,refine=True); pos=g['pos']; adj=g['adj']; deg=g['deg']; d=depth(pos)
cen=pos.mean(0); src=int(np.argmin(np.linalg.norm(pos-cen,axis=1)))
res=[]
for nsteps in (10,25,50,100):
    W=20000; cur=np.full(W,src)
    for s in range(nsteps):
        r=rng.random(W); cur=adj[cur,(r*deg[cur]).astype(int)]
    disp=pos[cur]-pos[src]; C=disp.T@disp/W; ev=np.linalg.eigvalsh(C)
    res.append(dict(steps=nsteps,msd_per_step=round(float(np.trace(C)/nsteps),4),eig_ratio_min_max=round(float(ev[0]/ev[-1]),4),max_depth_reached=int(np.percentile(np.linalg.norm(disp,axis=1),99))))
OUT['grown_random_walk']=res
OUT['grown_nodes']=int(len(pos))
json.dump(OUT,open('numbers.json','w'),indent=1); print(json.dumps(OUT,indent=1))
