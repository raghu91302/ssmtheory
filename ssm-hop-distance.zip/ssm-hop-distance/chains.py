"""Causal order of a grown SSM network: u precedes v if v descends from u through parent links.
For causally related pairs, compare the longest parent chain with (a) the generation gap, (b) a Lorentzian form."""
import sys, numpy as np, json
import os; sys.path.insert(0, os.environ.get('SSMSIM_PATH', '.'))  # folder containing the ssmsim package
from ssmsim.core import grow
from quantum_lattice import depth
N=int(sys.argv[1]); seed=int(sys.argv[2]); kw=dict(mode='step',p_step=0.0) if len(sys.argv)>3 and sys.argv[3]=='2d' else {}
g=grow(N,seed=seed,refine=False,**kw); pos=g['pos']; par=g['parent']; n=len(pos)
gen=np.zeros(n,int)
for m in range(3,n): gen[m]=1+gen[par[m]].max()
d=depth(pos)
children=[[] for _ in range(n)]
for m in range(3,n):
    for q in set(par[m].tolist()): children[q].append(m)
rng=np.random.default_rng(seed)
src=rng.choice(np.nonzero((gen>gen.max()*0.15)&(gen<gen.max()*0.35))[0],60,replace=False)
rows=[]
for u in src:
    L=np.full(n,-1); L[u]=0
    for m in range(u+1,n):      # parents have smaller index: index order is a topological order
        pm=par[m]; best=L[pm].max()
        if best>=0: L[m]=best+1
    desc=np.nonzero(L>0)[0]
    desc=desc[d[desc]>=2]
    if len(desc)>400: desc=rng.choice(desc,400,replace=False)
    for v in desc:
        rows.append((int(L[v]),int(gen[v]-gen[u]),float(np.linalg.norm(pos[v]-pos[u]))))
R=np.array(rows,float); Lc,dg,dx=R.T
print(f'N={n} seed={seed} {"2D sheet" if kw else "3D"}: causal pairs {len(R)}')
print('  longest chain == generation gap for fraction:',round(float(np.mean(Lc==dg)),4),' mean (gap - chain):',round(float(np.mean(dg-Lc)),3))
# how far can descendants be, per generation: speed of causal influence
v=dx/dg; print('  spatial reach per generation: median',round(float(np.median(v)),3),' 99th pct',round(float(np.percentile(v,99)),3),' max',round(float(v.max()),3))
# does chain length drop toward the edge of the future cone? bin by dx/dg relative to max reach
vmax=np.percentile(v,99.5); b=np.clip(v/vmax,0,1)
for lo,hi in [(0,.25),(.25,.5),(.5,.75),(.75,.9),(.9,1.01)]:
    s=(b>=lo)&(b<hi)
    if s.sum(): print(f'   reach {lo:.2f}-{hi:.2f} of max: n={s.sum():6d}  chain/gap = {np.mean(Lc[s]/dg[s]):.4f}   Lorentz sqrt(1-beta^2) would be {np.mean(np.sqrt(np.clip(1-b[s]**2,0,1))):.3f}')
json.dump(dict(N=n,seed=seed,frac_equal=float(np.mean(Lc==dg))),open(f'chains_{seed}.json','w'))
