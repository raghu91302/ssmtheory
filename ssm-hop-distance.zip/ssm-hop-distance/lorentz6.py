import sympy as sp, itertools
k=sp.symbols('k1:5'); a,p,w=sp.symbols('a p omega',positive=True)
k2=sum(x**2 for x in k)
P6=sum(x**6 for x in k); P42=sum(k[m]**4*k[n]**2 for m in range(4) for n in range(4) if m!=n)
t6=sp.Rational(1,480)*P6+sp.Rational(1,96)*P42
A=sp.expand(t6-sp.Rational(1,384)*k2**3)          # anisotropic part (from previous step)
# check: A averages to zero over directions (harmonic), using Gaussian moments
def gmean(expr):
    poly=sp.Poly(sp.expand(expr),*k); s=0
    for mon,cf in poly.terms():
        m=1
        for e in mon: m*= 0 if e%2 else (sp.factorial2(e-1) if e>0 else 1)
        s+=cf*m
    return s
print('direction average of A:',gmean(A))
# Lorentzian continuation, time = 4th axis: k4^2 -> -omega^2. Full kernel to a^6:
K=sp.symbols('K')   # K = p^2 - omega^2
n1,n2,n3=sp.symbols('n1 n2 n3',real=True)
sub={k[0]:p*n1,k[1]:p*n2,k[2]:p*n3}
AL=sp.expand(A.subs(sub).subs(k[3]**2,-w**2).subs({k[3]**6:-w**6,k[3]**4:w**4}))
AL=sp.expand(A.subs(sub).subs(k[3],sp.I*w))
# on-shell: 3a^2 K - a^4 K^2/8 + a^6[K^3/384 + A_L] = 0  ->  K = -(a^4/3) A_L(omega=p) + O(a^6)
AL_lc=sp.simplify(AL.subs(w,p).subs(n3**2,1-n1**2-n2**2))
print('A on the light cone (omega=p), as function of unit spatial direction n:',sp.factor(AL_lc))
# omega^2 = p^2 + (a^4/3) A_L  ->  v/c - 1 = (a^4/6) A_L / p^2 = (a p)^4 * Ahat/6
Ahat=sp.simplify(AL_lc/p**6)
dv=sp.simplify(Ahat/6)
print('fractional speed change dv/c = (a p)^4 * F(n),  F(n) =',sp.factor(dv))
vals={}
for lab,v in [('[100]',(1,0,0)),('[110]',(1,1,0)),('[111]',(1,1,1))]:
    nn=[sp.Integer(c)/sp.sqrt(sum(c*c for c in v)) for c in v]
    vals[lab]=sp.nsimplify(dv.subs({n1:nn[0],n2:nn[1]}))
    print('  F along',lab,'=',vals[lab],'=',float(vals[lab]))
# check the sign/size numerically by solving the exact kernel for omega at small ap
import numpy as np, mpmath as mp
def exact_kernel(kv,av=1.0):
    b=av/np.sqrt(2); return 4*sum(1-mp.cos(b*kv[m])*mp.cos(b*kv[n]) for m,n in itertools.combinations(range(4),2))
for lab,v in [('[100]',(1,0,0)),('[110]',(1,1,0)),('[111]',(1,1,1))]:
    nv=np.array(v,float); nv/=np.linalg.norm(nv); pp=mp.mpf('0.05')
    f=lambda om: exact_kernel([pp*nv[0],pp*nv[1],pp*nv[2],1j*om])
    om=mp.findroot(lambda x: mp.re(f(x)),pp)
    print(f'  exact kernel, ap=0.05, {lab}: dv/c = {float(om/pp-1):.4e}  vs  (ap)^4 F = {float(vals[lab])*0.05**4:.4e}')
