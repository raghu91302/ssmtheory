import sympy as sp, itertools
a=sp.symbols('a',positive=True); k=sp.symbols('k1:5',real=True)
b=a/sp.sqrt(2)
Delta=4*sum(1-sp.cos(b*k[m])*sp.cos(b*k[n]) for m,n in itertools.combinations(range(4),2))
eps=sp.symbols('eps')
ser=sp.series(Delta.subs(a,eps*a),eps,0,8).removeO()
terms={o:sp.expand(ser.coeff(eps,o)) for o in (2,4,6)}
k2=sum(x**2 for x in k)
print('order a^2:',sp.simplify(terms[2]-3*a**2*k2)==0)
print('order a^4 minus -(a^4/8)(k^2)^2:',sp.simplify(terms[4]+a**4*k2**2/8))
P6=sum(x**6 for x in k); P42=sum(k[m]**4*k[n]**2 for m in range(4) for n in range(4) if m!=n); P222=sum(k[m]**2*k[n]**2*k[p]**2 for m,n,p in itertools.combinations(range(4),3))
c1,c2,c3=sp.symbols('c1 c2 c3')
sol=sp.solve(sp.Poly(sp.expand(terms[6]-a**6*(c1*P6+c2*P42+c3*P222)),*k).coeffs(),[c1,c2,c3])
print('order a^6 = a^6 [ c1 sum k^6 + c2 sum_{mu!=nu} k_mu^4 k_nu^2 + c3 sum_{mu<nu<rho} k^2k^2k^2 ]:',sol)
user=a**6*(sp.Rational(1,480)*P6+sp.Rational(1,96)*P42)
print('user expression minus true a^6 term:',sp.factor(sp.expand(user-terms[6])))
# split true a^6 term into isotropic part (k^2)^3 times const + anisotropic invariant
x=sp.symbols('x'); 
iso=sp.symbols('iso'); 
# project: write term = alpha (k^2)^3 + beta * J6, choose J6 = sum k^6 - (something) traceless w.r.t. sphere average
# compute alpha via spherical average: avg over S^3 of k^6 etc.
def avg(expr):
    # average over unit 3-sphere using Gaussian moments: E[prod x^2n] for N(0,1) then divide by E[r^6]
    from sympy import factorial2
    poly=sp.Poly(sp.expand(expr),*k); tot=0
    for mon,cf in poly.terms():
        m=1
        for e in mon:
            m*= 0 if e%2 else sp.factorial2(e-1) if e>0 else 1
        tot+=cf*m
    r6=sp.expand(sum(x**2 for x in k)**3); poly2=sp.Poly(r6,*k); tr=0
    for mon,cf in poly2.terms():
        m=1
        for e in mon: m*= sp.factorial2(e-1) if e>0 else 1
        tr+=cf*m
    return sp.simplify(tot/tr)
t6=terms[6]/a**6; alpha=avg(t6); aniso=sp.expand(t6-alpha*k2**3)
print('a^6 term = a^6 [ alpha (k^2)^3 + A(k) ], alpha =',alpha)
print('anisotropic part A(k) =',sp.factor(aniso))
# value of A on unit vectors along axis, bond (1,1,0,0)/sqrt2, (1,1,1,1)/2, (1,1,1,0)/sqrt3
for lab,v in [('axis (1,0,0,0)',(1,0,0,0)),('bond (1,1,0,0)',(1,1,0,0)),('(1,1,1,0)',(1,1,1,0)),('(1,1,1,1)',(1,1,1,1))]:
    vv=[sp.Integer(c)/sp.sqrt(sum(c*c for c in v)) for c in v]
    print('  A on unit',lab,'=',sp.nsimplify(aniso.subs(dict(zip(k,vv)))))
