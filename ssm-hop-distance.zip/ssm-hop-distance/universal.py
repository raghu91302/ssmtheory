import sympy as sp, itertools
k=sp.symbols('k1:5'); e=sp.symbols('e')
k2=sum(x**2 for x in k)
P6=sum(x**6 for x in k); P42=sum(k[m]**4*k[n]**2 for m in range(4) for n in range(4) if m!=n); P222=sum(k[m]**2*k[n]**2*k[p]**2 for m,n,p in itertools.combinations(range(4),3))
J6=P6-5*P42+30*P222
# 1) J6 invariant under a W(F4) element that is not hypercubic (Hadamard-type)
H=sp.Matrix([[1,1,1,1],[1,1,-1,-1],[1,-1,1,-1],[1,-1,-1,1]])/2
kv=sp.Matrix(k); kh=H*kv
print('J6 invariant under the Hadamard-type element of W(F4):',sp.expand(J6.subs(dict(zip(k,kh)),simultaneous=True)-J6)==0)
# 2) D4* nearest neighbours: +-e_mu (8) and (+-1/2)^4 (16), all of length 1
N=[tuple(s*(1 if i==j else 0) for j in range(4)) for i in range(4) for s in (1,-1)]+[tuple(sp.Rational(s,2) for s in sg) for sg in itertools.product((1,-1),repeat=4)]
def sixth(vecs):
    tot=0
    for n in vecs:
        x=sum(ki*ni for ki,ni in zip(k,n))
        tot+= -x**6/720*(-1)   # 1-cos(x) = x^2/2 - x^4/24 + x^6/720 ...
    return sp.expand(tot)
s6=sixth(N)
# remove isotropic part: fit s6 = alpha (k^2)^3 + beta J6
al,be=sp.symbols('al be')
sol=sp.solve(sp.Poly(sp.expand(s6-al*k2**3-be*J6),*k).coeffs(),[al,be],dict=True)
print('D4* (photon lattice) sixth-order term = alpha (k^2)^3 + beta J6 :',sol)
D4=[tuple(v) for v in {tuple(x) for i,j in itertools.combinations(range(4),2) for si,sj in itertools.product((1,-1),repeat=2) for x in [[si if t==i else sj if t==j else 0 for t in range(4)]]}]
D4=[tuple(sp.Integer(c)/sp.sqrt(2) for c in v) for v in D4]   # unit length
sol4=sp.solve(sp.Poly(sp.expand(sixth(D4)-al*k2**3-be*J6),*k).coeffs(),[al,be],dict=True)
print('D4 (check field), unit bonds:',sol4)
