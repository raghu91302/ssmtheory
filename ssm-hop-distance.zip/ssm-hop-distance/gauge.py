"""Compact U(1) on D4* = Z^4 u (Z^4+h), Wilson action on elementary triangles. Quadratic form in link angles."""
import mpmath as mp, itertools
mp.mp.dps=40
half=mp.mpf(1)/2
N24=[tuple(mp.mpf(s) if i==j else mp.mpf(0) for j in range(4)) for i in range(4) for s in (1,-1)]+[tuple(half*s for s in sg) for sg in itertools.product((1,-1),repeat=4)]
def key(v): return tuple(int(mp.nint(4*x)) for x in v)
NK={key(v):v for v in N24}
# representatives: first nonzero component positive
R=[v for v in N24 if [x for x in v if x!=0][0]>0]; assert len(R)==12
RK={key(v):i for i,v in enumerate(R)}
def rep(m):
    k=key(m)
    if k in RK: return RK[k],1
    return RK[key(tuple(-x for x in m))],-1
add=lambda u,v: tuple(a+b for a,b in zip(u,v))
neg=lambda u: tuple(-a for a in u)
# triangles: ordered (m1,m2) with m3=-(m1+m2) in N24
TRI=[]
for m1 in N24:
    for m2 in N24:
        m3=neg(add(m1,m2))
        if key(m3) in NK and key(m1)!=key(neg(m2)): TRI.append((m1,m2,m3))
print('ordered triangles per site:',len(TRI))
dot=lambda k,v: sum(a*b for a,b in zip(k,v))
def M(k):
    """complex-symmetric (bilinear) quadratic form, analytic in k"""
    Mm=mp.zeros(12,12)
    for m1,m2,m3 in TRI:
        cp=[0]*12; cm=[0]*12
        o=(0,0,0,0)
        for m in (m1,m2,m3):
            i,s=rep(m); mid=add(o,tuple(x/2 for x in m))
            cp[i]+=s*mp.e**(1j*dot(k,mid)); cm[i]+=s*mp.e**(-1j*dot(k,mid))
            o=add(o,m)
        for a in range(12):
            if cm[a]==0: continue
            for b in range(12):
                if cp[b]!=0: Mm[a,b]+=cm[a]*cp[b]
    return Mm
def gauge(k):
    return mp.matrix([2j*mp.sin(dot(k,r)/2) for r in R])
B=mp.matrix([[r[mu] for mu in range(4)] for r in R])          # light basis: a_r = r.a
# orthonormal heavy complement (real, k-independent)
import numpy as np
Bn=np.array([[float(x) for x in r] for r in R]); U,S,Vt=np.linalg.svd(Bn,full_matrices=True); Hn=U[:,4:]
H=mp.matrix(Hn.tolist())
def Meff(k):
    Mk=M(k); BMB=B.T*Mk*B; BMH=B.T*Mk*H; HMB=H.T*Mk*B; HMH=H.T*Mk*H
    return BMB-BMH*mp.inverse(HMH)*HMB
if __name__=='__main__':
    k=[mp.mpf('0.013'),mp.mpf('0.007'),mp.mpf('-0.004'),mp.mpf('0.009')]
    Mk=M(k); g=gauge(k); print('gauge mode residual |M g|/|g|:',mp.nstr(mp.norm(Mk*g)/mp.norm(g),5))
    ev=sorted([abs(x) for x in mp.eig(Mk)[0]]); print('eigenvalue magnitudes of M (small k):',[mp.nstr(x,4) for x in ev])
    Me=Meff(k); k2=sum(x*x for x in k)
    # compare with c (k^2 delta - k k)
    K=mp.matrix(4,4)
    for i in range(4):
        for j in range(4): K[i,j]=(k2 if i==j else 0)-k[i]*k[j]
    c=Me[0,0]/K[0,0]; print('Meff / (k^2 d - kk): constant c =',mp.nstr(c,8),' max relative deviation',mp.nstr(max(abs(Me[i,j]-c*K[i,j]) for i in range(4) for j in range(4))/abs(c*k2),4))
