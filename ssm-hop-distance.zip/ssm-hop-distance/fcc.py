"""Periodic FCC code. Nodes: integer points x+y+z even, mod L. Bonds: 12 vectors (+-1,+-1,0) perms.
Z check per node (star); X check per octahedron (centered at x+y+z odd points, 6 vertices +-e_i, 12 edges)."""
import numpy as np, itertools
import scipy.sparse as sp
V12=[np.array(v) for v in set(itertools.permutations((1,1,0)))|set(itertools.permutations((1,-1,0)))|set(itertools.permutations((-1,-1,0)))]
V12=[v for v in {tuple(v) for v in V12}]; V12=[np.array(v) for v in sorted(V12)]
assert len(V12)==12
E6=[np.array(v) for v in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
class FCC:
    def __init__(s,L):
        s.L=L
        s.nodes=[p for p in itertools.product(range(L),repeat=3) if sum(p)%2==0]
        s.nid={p:i for i,p in enumerate(s.nodes)}; s.n=len(s.nodes)
        s.bid={}; s.bonds=[]
        for p in s.nodes:
            for v in V12:
                q=s.w(np.array(p)+v); k=frozenset((s.nid[p],s.nid[q]))
                if k not in s.bid: s.bid[k]=len(s.bonds); s.bonds.append(tuple(sorted(k)))
        s.m=len(s.bonds)
        s.octc=[p for p in itertools.product(range(L),repeat=3) if sum(p)%2==1]
        rows=[];cols=[]
        for o,c in enumerate(s.octc):
            for e in s.oct_edges(np.array(c),1): rows.append(o); cols.append(e)
        s.HX=sp.csr_matrix((np.ones(len(rows),np.uint8),(rows,cols)),shape=(len(s.octc),s.m))
        rows=[];cols=[]
        for i,p in enumerate(s.nodes):
            for v in V12: rows.append(i); cols.append(s.b(p,np.array(p)+v))
        s.HZ=sp.csr_matrix((np.ones(len(rows),np.uint8),(rows,cols)),shape=(s.n,s.m))
    def w(s,p): return tuple(int(x)%s.L for x in p)
    def b(s,p,q): return s.bid[frozenset((s.nid[s.w(p)],s.nid[s.w(q)]))]
    def oct_edges(s,c,scale):
        vs=[c+scale*e for e in E6]; out=[]
        for a,bb in itertools.combinations(vs,2):
            if np.abs(a-bb).sum()==2*scale and not np.array_equal(a+bb,2*c): out.append((a,bb))
        assert len(out)==12
        return [s.b(a,bb) for a,bb in out] if scale==1 else out
    def path(s,p,q):  # fine bonds along straight coarse bond p->q (q-p = 2v)
        mid=(p+q)//2; return [s.b(p,mid),s.b(mid,q)]
