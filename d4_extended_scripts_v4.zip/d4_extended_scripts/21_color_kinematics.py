#!/usr/bin/env python3
"""Color kinematics of the D3 code (the spatial slice of D4).

A. Parity theorem.  Every edge has two endpoints (H_Z column weight 2) and lies
   in exactly two octahedra (H_X column weight 2), so any Pauli operator
   anticommutes with an even number of vertex checks and an even number of
   void checks.  Verified exhaustively on the 4^6 - 1 = 4095 non-identity Pauli
   operators supported on a chordless {111} hexagon: no operator flips exactly
   one vertex check.
B. String cost law.  An open X-string along a straight <110> path of length l
   flips exactly its two endpoint vertex checks and disturbs exactly 2l void
   checks; consecutive <110> edges share no octahedron.
C. Minimized cost.  Over all simple lattice paths joining two sites at
   separation r along <110>, with length <= r + 4, the minimum number of
   disturbed void checks is 2 at r = 1, 2, 3 (flat), realized by staircase
   paths whose consecutive edges share an octahedron.
D. Color link template.  Exactly two X-supports on a hexagon are charged at an
   antipodal vertex pair with no void syndrome (the two half-hexagons); their
   sum, the hexagon loop, lies outside the X-stabilizer group; the three
   antipodal-pair strings pairwise overlap; composing one route per pair gives
   the alternating edge triple (charging all six vertices), never the loop.
Requires numpy only.
"""
import numpy as np
from itertools import product, combinations

failures = []
def check(cond, msg):
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond: failures.append(msg)

NN = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]

def build(L):
    nodes = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 0]
    nid = {p: i for i, p in enumerate(nodes)}
    add = lambda p, d: tuple((p[k] + d[k]) % L for k in range(3))
    edges = []; eid = {}
    for p in nodes:
        for d in NN:
            q = add(p, d)
            if q in nid and nid[p] < nid[q]:
                eid[(p, q)] = len(edges); edges.append((p, q))
    E = lambda p, q: eid[(p, q)] if (p, q) in eid else eid[(q, p)]
    voids = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 1]
    AX = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 1]
    HZ = np.zeros((len(nodes), len(edges)), np.uint8)
    for k, (p, q) in enumerate(edges): HZ[nid[p], k] = 1; HZ[nid[q], k] = 1
    HX = np.zeros((len(voids), len(edges)), np.uint8)
    for oi, o in enumerate(voids):
        nb = [add(o, a) for a in AX]
        for a, b in combinations(nb, 2):
            if (a, b) in eid or (b, a) in eid: HX[oi, E(a, b)] = 1
    return nodes, nid, edges, E, HZ, HX, add

def gf2rank(M):
    M = M.copy() % 2; r = 0; rows, cols = M.shape
    for c in range(cols):
        p = np.nonzero(M[r:, c])[0]
        if len(p) == 0: continue
        p = p[0] + r; M[[r, p]] = M[[p, r]]; m = np.nonzero(M[:, c])[0]; m = m[m != r]; M[m] ^= M[r]; r += 1
        if r == rows: break
    return r

# ------------------------------------------------------------------ A
print("A. PARITY THEOREM (L = 4)")
L = 4
nodes, nid, edges, E, HZ, HX, add = build(L)
check(HZ.shape == (32, 192) and HX.shape == (32, 192) and not (HX.astype(int) @ HZ.T.astype(int) % 2).any(),
      "D3 code rebuilt: 192 qubits, 32 vertex checks, 32 void checks, CSS")
check(set(HZ.sum(0)) == {2}, "every edge has exactly two endpoints (H_Z column weight 2)")
check(set(HX.sum(0)) == {2}, "every edge lies in exactly two octahedra (H_X column weight 2)")
# chordless {111} hexagon: the six in-plane neighbours of a site
o = (0, 0, 0)
hexv = [(1, -1, 0), (1, 0, -1), (0, 1, -1), (-1, 1, 0), (-1, 0, 1), (0, -1, 1)]   # cyclic order, 60 deg apart
hexv = [add(o, d) for d in hexv]
hexE = [E(hexv[i], hexv[(i + 1) % 6]) for i in range(6)]
chordless = all(not ((hexv[i], hexv[j]) in {(p, q) for p, q in edges} or (hexv[j], hexv[i]) in {(p, q) for p, q in edges})
                for i, j in combinations(range(6), 2) if (j - i) % 6 not in (1, 5))
check(len(set(hexE)) == 6 and chordless, "chordless hexagonal six-cycle located in a {111} plane")
n_even = 0; n_single = 0; n_tot = 0
for op in product(range(4), repeat=6):        # 0=I 1=X 2=Y 3=Z per hexagon edge
    if not any(op): continue
    n_tot += 1
    x = np.zeros(192, np.uint8); z = np.zeros(192, np.uint8)
    for k, t in enumerate(op):
        if t in (1, 2): x[hexE[k]] = 1
        if t in (2, 3): z[hexE[k]] = 1
    vflip = int((HZ.astype(int) @ x % 2).sum()); oflip = int((HX.astype(int) @ z % 2).sum())
    if vflip % 2 == 0 and oflip % 2 == 0: n_even += 1
    if vflip == 1: n_single += 1
print(f"  {n_tot} non-identity Pauli operators on the hexagon: {n_even} with even vertex and even void syndrome, {n_single} single-vertex-charged")
check(n_tot == 4095 and n_even == 4095 and n_single == 0, "no single-endpoint color-charged operator exists on the strong channel (0 of 4095)")

# ------------------------------------------------------------------ B
print("\nB. STRING COST LAW (straight <110> strings, L = 4)")
def string_support(start, step, l):
    x = np.zeros(len(edges), np.uint8); p = start
    for _ in range(l):
        q = add(p, step); x[E(p, q)] = 1; p = q
    return x, p
for l in (1, 2, 3):
    x, end = string_support((0, 0, 0), (1, 1, 0), l)
    v = int((HZ.astype(int) @ x % 2).sum()); c = int((HX.astype(int) @ x % 2).sum())
    print(f"  l = {l}: endpoint vertex flips = {v}, disturbed void checks = {c}")
    check(v == 2 and c == 2 * l, f"straight string of length {l}: 2 endpoint flips, 2l = {2*l} disturbed checks")
x4, end4 = string_support((0, 0, 0), (1, 1, 0), 4)
check(end4 == (0, 0, 0) and int((HZ.astype(int) @ x4 % 2).sum()) == 0, "l = 4 closes on the L = 4 torus: zero endpoint flips (finite-size control, excluded)")
shared = any(int((HX[:, E((k*1, k*1, 0), ((k+1), (k+1), 0))].astype(int) * HX[:, E(((k+1), (k+1), 0), ((k+2)%L, (k+2)%L, 0))].astype(int)).sum()) for k in range(2))
check(not shared, "consecutive <110> edges share no octahedron (linearity is exact)")
loop = np.zeros(len(edges), np.uint8); loop[hexE] = 1
check(int((HZ.astype(int) @ loop % 2).sum()) == 0, "closed hexagon loop flips zero vertex checks (control)")

# ------------------------------------------------------------------ C
print("\nC. MINIMIZED COST OVER CONNECTING PATHS (L = 6, detour budget 4)")
L6 = 6
nodes6, nid6, edges6, E6, HZ6, HX6, add6 = build(L6)
adj = {p: [] for p in nodes6}
for p, q in edges6: adj[p].append(q); adj[q].append(p)
HX6i = HX6.astype(int)
def enumerate_paths(src, dst, maxlen):
    out = []
    def dfs(p, path, visited):
        if len(path) - 1 > maxlen: return
        if p == dst and len(path) > 1: out.append(list(path)); return
        for q in adj[p]:
            if q not in visited:
                visited.add(q); path.append(q); dfs(q, path, visited); path.pop(); visited.discard(q)
    dfs(src, [src], {src})
    return out
for r in (1, 2, 3):
    src = (0, 0, 0); dst = (r, r, 0)
    paths = enumerate_paths(src, dst, r + 4)
    costs = []
    for pth in paths:
        x = np.zeros(len(edges6), np.uint8)
        for a, b in zip(pth[:-1], pth[1:]): x[E6(a, b)] = 1
        costs.append(int((HX6i @ x % 2).sum()))
    costs = np.array(costs); lens = np.array([len(p) - 1 for p in paths])
    cmin = costs.min(); frac = np.mean(costs < 2 * lens)
    best = paths[int(np.argmin(costs))]
    print(f"  r = {r}: {len(paths)} simple paths of length <= {r+4}; C_min = {cmin}; {100*frac:.1f}% of paths cost less than 2 x length; a minimizer: {best}")
    check(cmin == 2, f"minimized cost at separation {r} is 2 (bounded, not linear)")
    check(frac > 0.97, f"cancellation generic at r = {r}: > 97% of paths cost less than twice their length")
    # among the minimizers, a staircase exists: every consecutive edge pair shares an octahedron
    stair = None
    for idx in np.nonzero(costs == cmin)[0]:
        pth = paths[idx]
        if all(int((HX6[:, E6(a, b)].astype(int) * HX6[:, E6(b, c)].astype(int)).sum()) > 0 for a, b, c in zip(pth[:-2], pth[1:-1], pth[2:])):
            stair = pth; break
    print(f"         staircase minimizer (consecutive edges share an octahedron): {stair}")
    check(stair is not None, f"a staircase minimizer exists at r = {r}: consecutive edges share octahedra and interior syndromes cancel pairwise")

# ------------------------------------------------------------------ D
print("\nD. COLOR LINK TEMPLATE ON THE HEXAGON (L = 4)")
hexid = {hexv[i]: i for i in range(6)}
routes = {}
for mask in range(1, 64):
    x = np.zeros(192, np.uint8)
    for k in range(6):
        if mask >> k & 1: x[hexE[k]] = 1
    vs = HZ.astype(int) @ x % 2; os_ = HX.astype(int) @ x % 2
    if vs.sum() == 2:
        charged = tuple(sorted(hexid[nodes[i]] for i in np.nonzero(vs)[0] if nodes[i] in hexid))
        if len(charged) == 2 and (charged[1] - charged[0]) == 3:
            routes.setdefault(charged, []).append(mask); voids_disturbed = int(os_.sum())
print("  antipodal pairs and their charged X-supports (weights):", {k: [bin(m).count('1') for m in v] for k, v in routes.items()})
check(len(routes) == 3 and all(len(v) == 2 and all(bin(m).count('1') == 3 for m in v) for v in routes.values()),
      "each antipodal pair is connected by exactly two X-supports on the hexagon, the two half-hexagon routes of weight 3")
check(voids_disturbed == 6, "each route disturbs 6 void checks (2 per edge, none shared), consistent with the cost law")
rX = gf2rank(HX)
check(gf2rank(np.vstack([HX, loop[None, :]])) == rX + 1, "the hexagon loop (difference of the two routes) lies outside the X-stabilizer group: the phase between routes is physical")
pairs = list(routes.keys())
overlap = all(any((routes[a][i] & routes[b][j]) for i in range(2) for j in range(2)) for a, b in combinations(pairs, 2))
check(overlap, "the three color strings pairwise overlap on hexagon edges (phases not independently diagonalizable)")
loopmask = 63; n_loop = 0; n_alt = 0
for choice in product(range(2), repeat=3):
    comp = 0
    for pr, c in zip(pairs, choice): comp ^= routes[pr][c]
    if comp == loopmask: n_loop += 1
    if comp in (0b010101, 0b101010): n_alt += 1
print(f"  compositions of one route per pair: {n_loop} of 8 give the hexagon loop, {n_alt} of 8 give an alternating edge triple")
check(n_loop == 0 and n_alt == 8, "the three color strings compose to the alternating edge triple (a junction charging all six vertices), never to the neutral loop")

print()
if failures:
    print(f"{len(failures)} check(s) failed:"); [print("  -", f) for f in failures]; raise SystemExit(1)
print("All color-kinematics checks passed.")
