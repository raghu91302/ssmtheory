# Two chains of flipped bonds with the same end-checks: do they differ by Z-checks (stabilizers)?  If so, the state
# does not record the chain's length, and the code alone gives no string tension.
import numpy as np, itertools as it
R=range(-4,5); S=[p for p in it.product(R,R,R) if sum(p)%2==0]; Sset=set(S)
D=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
B=[]; 
for p in S:
    for d in D:
        q=tuple(np.add(p,d))
        if q in Sset: B.append(frozenset((p,q)))
bi={b:i for i,b in enumerate(B)}
def octs(b):
    a,c=[np.array(v) for v in b]; out=[]
    for o in it.product(*[range(min(a[i],c[i])-1,max(a[i],c[i])+2) for i in range(3)]):
        if sum(o)%2 and np.abs(a-o).sum()==1 and np.abs(c-o).sum()==1: out.append(o)
    return out
# short chain: oct (1,0,0) -> (3,0,0); long detour chain built by BFS avoiding the short one's bonds
from collections import deque
link={}
for b in B:
    oc=octs(b)
    if len(oc)==2:
        for i in (0,1): link.setdefault(oc[i],[]).append((oc[1-i],b))
def path(s,t,ban=set()):
    prev={s:None}; q=deque([s])
    while q:
        u=q.popleft()
        if u==t: break
        for v,b in link.get(u,[]):
            if v not in prev and b not in ban: prev[v]=(u,b); q.append(v)
    E=[];u=t
    while prev[u]: u,b=prev[u]; E.append(b)
    return E
p1=path((1,0,0),(3,0,0)); p2=path((1,0,0),(3,0,0),ban=set(p1))
print('chain lengths',len(p1),len(p2))
v=np.zeros(len(B),int)
for b in p1+p2: v[bi[b]]^=1
# Z-checks: vertex stars (interior vertices only)
inner=[p for p in S if max(map(abs,p))<=3]
M=np.zeros((len(inner),len(B)),int)
for i,p in enumerate(inner):
    for b in B:
        if p in b: M[i,bi[b]]=1
# solve M^T y = v over GF(2)
A=np.concatenate([M.T,v[:,None]],1)%2; r=0; piv=[]
for c in range(A.shape[1]-1):
    rows=[i for i in range(r,A.shape[0]) if A[i,c]]
    if not rows: continue
    A[[r,rows[0]]]=A[[rows[0],r]]
    for i in range(A.shape[0]):
        if i!=r and A[i,c]: A[i]^=A[r]
    r+=1
consistent=not any(A[i,-1] and not A[i,:-1].any() for i in range(A.shape[0]))
print('the two chains differ by a product of Z-checks:',consistent)
