#!/usr/bin/env python3
"""Lowest Maxwell mode of a cavity with perfectly conducting walls (n x E = 0), on a Yee (edge) grid with staircase
walls. The gluon bag condition (n.E = 0, n x B = 0) is the dual of this one (E <-> B), so it has the same spectrum.
Operator: A = C^T C + s G G^T on interior edges, C the discrete curl (edges -> faces), G the discrete gradient
(interior nodes -> edges); gradient modes are pushed to s * (scalar Dirichlet eigenvalues), above the physical ones.
Usage: python3 vector_cavity.py sphere|cubo n Rgrid"""
import numpy as np, scipy.sparse as sp, sys
from scipy.sparse.linalg import lobpcg
shape=sys.argv[1]; n=int(sys.argv[2]); Rg=float(sys.argv[3]); s=6.0
c=np.arange(n)-(n-1)/2
X,Y,Z=np.meshgrid(c,c,c,indexing='ij')
if shape=='sphere': node_in=X**2+Y**2+Z**2<Rg**2
else:
    a=Rg/np.sqrt(2); node_in=(np.abs(X)<a)&(np.abs(Y)<a)&(np.abs(Z)<a)&(np.abs(X)+np.abs(Y)+np.abs(Z)<2*a)
nid=-np.ones((n,n,n),int); Nn=int(node_in.sum()); nid[node_in]=np.arange(Nn)
# edges: (node, direction) with at least one endpoint interior; edges between two exterior nodes lie in the wall (E=0)
eid={}; elist=[]
for d in range(3):
    sh=[0,0,0]; sh[d]=1
    A=node_in[:n-sh[0],:n-sh[1],:n-sh[2]]|node_in[sh[0]:,sh[1]:,sh[2]:]
    for p in np.argwhere(A): eid[(p[0],p[1],p[2],d)]=len(elist); elist.append((p[0],p[1],p[2],d))
Ne=len(elist)
# gradient: edge (p,d) = phi(p+e_d) - phi(p)
r=[];cc=[];v=[]
for k,(i,j,l,d) in enumerate(elist):
    q=[i,j,l]; q[d]+=1
    for node,sg in ((nid[q[0],q[1],q[2]],1),(nid[i,j,l],-1)):
        if node>=0: r.append(k); cc.append(node); v.append(sg)
G=sp.csr_matrix((v,(r,cc)),shape=(Ne,Nn))
# curl: faces (p, normal) with circulation over its 4 edges; edges not interior are zero (PEC)
r=[];cc=[];v=[];nf=0
for i in range(n-1):
    for j in range(n-1):
        for l in range(n-1):
            for nrm in range(3):
                d1,d2=[d for d in range(3) if d!=nrm]
                p=[i,j,l]; p1=list(p); p1[d1]+=1; p2=list(p); p2[d2]+=1
                terms=[((p[0],p[1],p[2],d1),1),((p1[0],p1[1],p1[2],d2),1),((p2[0],p2[1],p2[2],d1),-1),((p[0],p[1],p[2],d2),-1)]
                row=[(eid[t],sg) for t,sg in terms if t in eid]
                if row:
                    for e,sg in row: r.append(nf); cc.append(e); v.append(sg)
                    nf+=1
C=sp.csr_matrix((v,(r,cc)),shape=(nf,Ne))
Aop=(C.T@C+s*(G@G.T)).tocsr()
w,_=lobpcg(Aop,np.random.default_rng(0).random((Ne,4)),largest=False,tol=1e-8,maxiter=4000)
k=np.sqrt(np.sort(w)[0]); print('%s n=%d R=%.1f  k=%.5f  x=k*R=%.4f  (next %s)'%(shape,n,Rg,k,k*Rg,np.round(np.sqrt(np.sort(w))*Rg,3)),flush=True)
