# Edge route out of the 13-site cluster, and how a single color would move.
import numpy as np, itertools as it
R=range(-5,6); S={p for p in it.product(R,R,R) if sum(p)%2==0}
def sub(v):  # FCC = 4 simple-cubic sublattices: A (all even) and three colour sublattices by the even coordinate
    e=[c%2==0 for c in v]; return 'A' if all(e) else ('xy' if e[2] else ('xz' if e[1] else 'yz'))
shell={p for p in S if sorted(map(abs,p))==[0,1,1]}; cl=shell|{(0,0,0)}
tets=[tuple(np.array(c)/2) for c in it.product(range(-7,8,2),repeat=3)]
def tv(c): return frozenset(v for v in S if np.allclose(np.abs(np.array(v)-c),0.5))
T={c:tv(c) for c in tets}; T={c:v for c,v in T.items() if len(v)==4}
print('every tet has one site of each sublattice:',all(sorted(sub(v) for v in vs)==['A','xy','xz','yz'] for vs in T.values()))
inner=[vs for vs in T.values() if (0,0,0) in vs]
edges=lambda vs:[frozenset(e) for e in it.combinations(vs,2)]
ie={e for vs in inner for e in edges(vs)}
outer=[vs for vs in T.values() if vs not in inner and any(e in ie for e in edges(vs))]
print('inner tets',len(inner),' tets sharing an edge with them but not in the cluster:',len(outer),
      ' their anchors (A sites):',sorted({next(v for v in vs if sub(v)=='A') for vs in outer})[:6],'...')
octc=[p for p in it.product(range(-3,4),repeat=3) if sum(p)%2==1]
def ov(c): return frozenset(v for v in S if sum(abs(np.array(v)-np.array(c)))==1)
O={c:ov(c) for c in octc}
print('colours present in each octahedral cell:',{tuple(sorted({sub(v) for v in vs})) for vs in O.values()})
# code: qubits on bonds, X-check on the 12 edges of each oct. Syndrome of Z on edges = octs containing an odd number.
def octs_of(e): return [c for c,vs in O.items() if e<=vs]
o,a,b,c=(0,0,0),(1,1,0),(1,0,1),(0,1,1)
def synd(E):
    cnt={}
    for e in E:
        for oc in octs_of(frozenset(e)): cnt[oc]=cnt.get(oc,0)+1
    return sorted(k for k,v in cnt.items() if v%2)
print('Z on one radial bond (one colour): violated X-checks',synd([(o,a)]))
print('Z on three radial bonds of one tet (singlet):',synd([(o,a),(o,b),(o,c)]))
# separate one colour along a straight path of bonds: syndrome stays at the ends
path=[(o,a),(a,(2,2,0)),((2,2,0),(3,3,0)),((3,3,0),(4,4,0))]
for n in range(1,5): print(' string of %d bonds: violated checks %d'%(n,len(synd(path[:n]))))
# Can a colour excitation be separated with violated checks only at the two ends?  Octs linked by shared bonds (qubits).
from collections import deque
bonds={frozenset((p,tuple(np.array(p)+d))) for p in S for d in [(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)] if tuple(np.array(p)+d) in S}
link={}
for b in bonds:
    oc=[c for c,vs in O.items() if b<=vs]
    if len(oc)==2: link.setdefault(oc[0],[]).append((oc[1],b)); link.setdefault(oc[1],[]).append((oc[0],b))
start=(1,0,0); prev={start:None}; q=deque([start])
while q:
    u=q.popleft()
    for v,b in link.get(u,[]):
        if v not in prev: prev[v]=(u,b); q.append(v)
for tgt in [(3,0,0),(3,2,0),(-3,0,0)]:
    E=[];u=tgt
    while prev[u]: u,b=prev[u]; E.append(tuple(b))
    print('separate to oct %s: %d bonds flipped, violated checks %s'%(tgt,len(E),synd(E)))
