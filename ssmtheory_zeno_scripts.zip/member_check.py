# Each of the lowest levels found by the sparse eigensolver on the original Hamiltonian (ed_check.py output)
# must appear in the pooled spectra of the dual blocks.
import numpy as np
exec(open('orbit_check.py').read().split("rng=np.random")[0])
orig={(0,0):[1.645427,1.649898,1.649898,1.64993,1.64993,1.650364,1.650364,1.650565,1.650565,1.651798],
      (1,0):[2.649202,2.649226,2.649226,2.649388,2.649388,2.649744,2.649744,2.65027,2.65027,2.650567],
      (1,1):[3.652955,3.652956,3.652977,3.652996,3.652999,3.653117,3.653131,3.653138,3.653235,3.653256]}
T8=np.array([bin(i).count('1') for i in range(256)],np.int64)
def popc(x): return T8[x&255]+T8[(x>>8)&255]+T8[(x>>16)&255]+T8[(x>>24)&255]
allc=np.arange(1<<nb,dtype=np.int64); pars=[popc(allc&m)%2 for m in octm]
for sec in orig:
    cfg=allc[(pars[0]==sec[0])&(pars[1]==sec[1])]; seen=np.zeros(len(cfg),bool); pool=[]
    for i in range(len(cfg)):
        if seen[i]: continue
        x0=int(cfg[i]); seen[np.searchsorted(cfg,np.array([x0^s for s in span]))]=True
        J=np.array([1-2*((x0>>e)&1) for e in range(nb)],float); pool.extend(np.linalg.eigvalsh(dual(J,sec))[:12])
    pool=np.array(pool)
    print(sec,'max distance from each original level to the nearest dual level: %.1e'%max(np.abs(pool-v).min() for v in orig[sec]))
