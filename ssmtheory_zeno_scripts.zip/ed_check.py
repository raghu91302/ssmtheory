#!/usr/bin/env python3
"""Exact check of the duality, Eq. (5), on a fragment of the FCC code.
Fragment: the 10 FCC nodes of two edge-sharing octahedral cells, centres (1,0,0) and (0,1,0), with the 23 bonds that
are edges of these cells. One qubit per bond. Checks: Z on the bonds of each node (stars), X on the 12 edges of each
of the two octahedral cells. Original Hamiltonian (Eq. 4):
    H = lam * sum_checks (1 - S)/2 + h * sum_e (1 - X_e)/2.
(1) Original: exact lowest eigenvalues in each sector of the two octahedral checks, in the X basis of the 25 qubits.
(2) Dual: in the same sector, every configuration is x_e = J_e s_u s_w for some J and node spins s. For each class of J
    (orbit under node flips) build the transverse-field Ising model
    H_J = (h/2) sum_e (1 - J_e s_u s_w) + (lam/2) sum_v (1 - sigma^x_v) + lam * (failed octahedral checks),
    restricted to the even sector of the global flip prod_v sigma^x_v = +1, and pool the spectra of all classes.
Every level of (1) must appear in (2). (A Lanczos solver may miss copies of degenerate levels; orbit_check.py checks
multiplicities exactly.)"""
import numpy as np, itertools as it, sys, time
import scipy.sparse as sp; from scipy.sparse.linalg import eigsh
lam=1.0; h=float(sys.argv[1]) if len(sys.argv)>1 else 0.15; nev=int(sys.argv[2]) if len(sys.argv)>2 else 12
def octv(c): c=np.array(c); return [tuple(c+s*np.array(e)) for e in [(1,0,0),(0,1,0),(0,0,1)] for s in (1,-1)]
C=[(1,0,0),(0,1,0)]
V=sorted({v for c in C for v in octv(c)}); vi={v:i for i,v in enumerate(V)}; N=len(V)
octset=[{v for v in octv(c)} for c in C]
B=[(vi[a],vi[b]) for a,b in it.combinations(V,2) if sum((np.array(a)-b)**2)==2 and any(a in o and b in o for o in octset)]; nb=len(B)
star=[sum(1<<e for e,(u,w) in enumerate(B) if v in (u,w)) for v in range(N)]
octm=[]
for c in C:
    vs={vi[v] for v in octv(c)}; octm.append(sum(1<<e for e,(u,w) in enumerate(B) if u in vs and w in vs))
assert all(bin(m).count('1')==12 for m in octm)
# commutation: every star overlaps every octahedral check on an even number of bonds
assert all(bin(s&o).count('1')%2==0 for s in star for o in octm)
print('fragment: %d nodes, %d bonds (qubits), %d octahedral checks, %d node checks; h/lam=%.3f'%(N,nb,len(octm),N,h))
from scipy.sparse.linalg import LinearOperator
T8=np.array([bin(i).count('1') for i in range(256)],np.uint8)
def popcount(x):
    x=x.astype(np.uint32); return (T8[x&255].astype(np.int32)+T8[(x>>8)&255]+T8[(x>>16)&255]+T8[(x>>24)&255])
allc=np.arange(1<<nb,dtype=np.uint32)
pars=[(popcount(allc&np.uint32(m))&1).astype(np.int8) for m in octm]
res={}
for sec in [(0,0),(1,0),(1,1)]:
    t=time.time()
    cfg=allc[(pars[0]==sec[0])&(pars[1]==sec[1])]; D=len(cfg)
    diag=lam*sum(sec)+lam*N/2+h*popcount(cfg).astype(float)
    rows=[];cols=[];vals=[]
    for m in star:
        jj=np.searchsorted(cfg,cfg^np.uint32(m)).astype(np.int32); rows.append(np.arange(D,dtype=np.int32)); cols.append(jj); vals.append(np.full(D,-lam/2))
    rows.append(np.arange(D,dtype=np.int32)); cols.append(np.arange(D,dtype=np.int32)); vals.append(diag)
    Hs=sp.csr_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(D,D)); del rows,cols,vals
    e=np.sort(eigsh(Hs,k=nev,which='SA',tol=1e-9,ncv=60)[0]); del Hs
    res[sec]=e; print('original, failed octahedral checks %s: dim %d  lowest %s  (%.0fs)'%(sec,D,np.round(e,6),time.time()-t),flush=True)
    del cfg,diag
del allc,pars
# dual
t=time.time()
# gauge: spanning tree of the node graph; J=+1 on tree edges, free elsewhere
import collections
adj=collections.defaultdict(list)
for e,(u,w) in enumerate(B): adj[u].append((w,e)); adj[w].append((u,e))
tree=set(); seen={0}; q=[0]
while q:
    u=q.pop()
    for w,e in adj[u]:
        if w not in seen: seen.add(w); tree.add(e); q.append(w)
free=[e for e in range(nb) if e not in tree]
print('node graph: %d tree bonds, %d free bonds -> %d classes of J'%(len(tree),len(free),2**len(free)))
# even-sector TFIM basis: s with s_0=+1
S=np.array([[1-2*((i>>v)&1) for v in range(N)] for i in range(1<<N)]); keep=S[:,0]==1; Se=S[keep]; idx={tuple(x):k for k,x in enumerate(Se)}
M=len(Se)
flip=np.zeros((N,M),int)
for v in range(N):
    for k,x in enumerate(Se):
        y=x.copy(); y[v]=-y[v]
        if y[0]==-1: y=-y
        flip[v,k]=idx[tuple(y)]
Hx=np.zeros((M,M))
for v in range(N):
    for k in range(M): Hx[flip[v,k],k]+=-lam/2
Hx+=np.eye(M)*lam*N/2
SS=np.array([Se[:,u]*Se[:,w] for (u,w) in B])   # bonds x states
pool={(0,0):[],(1,0):[],(1,1):[]}; best=[]
for bits in range(1<<len(free)):
    J=np.ones(nb); 
    for i,e in enumerate(free):
        if (bits>>i)&1: J[e]=-1
    # sector of this J: octahedral check value = product of J over its edges
    sec=tuple(int(np.prod([J[e] for e in range(nb) if (octm[o]>>e)&1])<0) for o in range(2))
    if sec not in pool: continue
    d=(h/2)*((1-J[:,None]*SS).sum(0))+lam*sum(sec)
    ev=np.linalg.eigvalsh(Hx+np.diag(d))[:nev]
    pool[sec].extend(ev)
    if sec==(1,1): best.append((ev[0],int((J<0).sum()),tuple(np.where(J<0)[0])))
for sec in pool:
    p=np.sort(pool[sec])[:nev]
    print('dual,     failed octahedral checks %s: lowest %s'%(sec,np.round(p,6)))
    print('          max |difference| = %.2e'%np.abs(p-res[sec]).max())
print('dual time %.0fs'%(time.time()-t))
shared=[e for e in range(nb) if all((octm[o]>>e)&1 for o in range(2))]
best.sort(); print('pair sector: lowest block E0=%.6f; shared-bond chain (J=-1 on bond %s only, up to gauge) E0='%(best[0][0],shared),
      [b[0] for b in best if set(b[2])==set(shared)])
print('five lowest pair blocks (E0, number of reversed couplings in the tree gauge):',[(round(b[0],6),b[1]) for b in best[:5]])
