# Ranks of the node checks and octahedral checks of the periodic FCC code; number of logical qubits k = B - r_Z - r_X.
# The number of J classes per sector of the octahedral checks is 2^(B - r_X) / 2^(N-1) = 2^k when r_Z = N-1.
import numpy as np, itertools as it, sys
def rank2(rows,n):
    piv={}; r=0
    for v in rows:
        x=v
        while x:
            hb=x.bit_length()-1
            if hb in piv: x^=piv[hb]
            else: piv[hb]=x; r+=1; break
    return r
for L in (2,3):
    P=2*L; nodes=[p for p in it.product(range(P),repeat=3) if sum(p)%2==0]; ni={p:i for i,p in enumerate(nodes)}
    D=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
    B=[]; 
    for p in nodes:
        for d in D: B.append(frozenset((p,tuple(np.add(p,d)%P))))
    bi={b:i for i,b in enumerate(B)}; nb=len(B); N=len(nodes)
    Z=[sum(1<<bi[b] for b in B if p in b) for p in nodes]
    octs=[p for p in it.product(range(P),repeat=3) if sum(p)%2==1]
    X=[]
    for c in octs:
        vs=[tuple(np.add(c,s*np.array(e))%P) for e in [(1,0,0),(0,1,0),(0,0,1)] for s in (1,-1)]
        X.append(sum(1<<bi[frozenset((a,b))] for a,b in it.combinations(vs,2) if frozenset((a,b)) in bi))
    rz,rx=rank2(Z,nb),rank2(X,nb)
    print('L=%d: N=%d nodes, B=%d qubits, rank(node checks)=%d, rank(oct checks)=%d, k=%d (4N+2=%d)'%(L,N,nb,rz,rx,nb-rz-rx,4*N+2))
