#!/usr/bin/env python3
"""Lowest mode of a massless Dirac field confined to a cavity with the MIT bag condition, implemented as the
infinite-mass limit: H = alpha.(-i grad) + beta [M(x) + (r/2) h (-Laplacian)], M = 0 inside the cavity and M_out outside.
Wilson term (r = 1) removes doublers. Periodic box. Returns x = |E_min| * R_ref for a chosen reference length.
Usage: python3 dirac_cavity.py sphere|cubo n Rgrid Mout"""
import numpy as np, scipy.sparse as sp, sys
from scipy.sparse.linalg import lobpcg, LinearOperator
shape=sys.argv[1]; n=int(sys.argv[2]); Rg=float(sys.argv[3]); Mout=float(sys.argv[4]); r=1.0
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); Z=np.zeros((2,2))
al=[np.block([[Z,s],[s,Z]]) for s in (s1,s2,s3)]; be=np.diag([1,1,-1,-1]).astype(complex)
c=(np.arange(n)-n/2+0.5)
X,Y,Zc=np.meshgrid(c,c,c,indexing='ij')
if shape=='sphere': inside=X**2+Y**2+Zc**2<Rg**2
elif shape=='tet':  # regular tetrahedron with circumradius Rg (edge = Rg*sqrt(8/3))
    s=Rg/np.sqrt(3); inside=(X+Y+Zc>-s)&(X-Y-Zc>-s)&(-X+Y-Zc>-s)&(-X-Y+Zc>-s)
else:  # cuboctahedron with circumradius Rg: |x_i|<Rg/sqrt2 and |x|+|y|+|z|<sqrt2*Rg
    a=Rg/np.sqrt(2); inside=(np.abs(X)<a)&(np.abs(Y)<a)&(np.abs(Zc)<a)&(np.abs(X)+np.abs(Y)+np.abs(Zc)<2*a)
M=np.where(inside,0.0,Mout).ravel(); N=n**3
I=sp.identity(N,format='csr')
def shift(d,s):
    idx=np.arange(N).reshape(n,n,n); j=np.roll(idx,-s,axis=d).ravel()
    return sp.csr_matrix((np.ones(N),(np.arange(N),j)),shape=(N,N))
D=[];Lap=-6*I
for d in range(3):
    Sp,Sm=shift(d,1),shift(d,-1); D.append((Sp-Sm)/2); Lap=Lap+Sp+Sm
H=sp.kron(sp.diags(M),be)  # careful ordering: site-major kron spinor
H=sp.kron(sp.diags(M),be)+sp.kron(-0.5*r*Lap,be)
for d in range(3): H=H+sp.kron(-1j*D[d],al[d])
H=H.tocsr()
H2=LinearOperator(H.shape,matvec=lambda v: H@(H@v),dtype=complex)
rng=np.random.default_rng(0); X0=rng.random((H.shape[0],4))+0j
w,V=lobpcg(H2,X0,largest=False,tol=1e-8,maxiter=3000)
k=np.argmin(w.real); E=np.sqrt(w.real[k])
deg=np.where(np.abs(w.real-w.real[k])<1e-4*abs(w.real[k]))[0]
rho=sum((np.abs(V[:,i].reshape(N,4))**2).sum(1) for i in deg); rho/=rho.sum()
r2=(X**2+Y**2+Zc**2).ravel()
rms=np.sqrt((rho*r2).sum())
print('%s n=%d R=%.1f Mout=%.1f  E=%.5f  x=E*R=%.4f  rms/R=%.4f'%(shape,n,Rg,Mout,E,E*Rg,rms/Rg),flush=True)
