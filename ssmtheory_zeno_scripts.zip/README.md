# Scripts for "The Quantum Zeno Effect Links an Error-Correcting Code to Confined Fields: The Selection–Stitch Lattice"

Section, table, figure and equation numbers refer to the paper.

| Script | Produces |
|---|---|
| `zeno_walls.py` | Fig. 2 and Sections 3, 5 and 6: (a) a particle checked at intervals for being inside an interval; (b) a massless quark with a verification mass outside, and the same strength on its charge density. Prints the fit E = πħc/2(L+ħc/K) of Eq. (5). |
| `zeno_law.py` | Table 5 and the Zeno law for walls (Section 6): lowest energy against wall strength K for a slow particle and a massless Dirac particle, against E∞[L/(L+2ħ/√(2mK))]² and E∞ L/(L+ħc/K). |
| `law_check.py` | Table 4 and the Zeno law for walls, part 1: strong penalties λ(β + a) and λσ_y on a massless Dirac particle; which hold the particle, the antiparticle, both or neither. |
| `proj_check.py` | Table 2: three penalties on a massless quark outside an interval (verification mass, projector, density). |
| `pulsed.py`, `dirac1d.py` | Section 5: pulsed position checks on a massless quark (`python3 pulsed.py 256`); `dirac1d.py` also compares the three walls. |
| `dirac_cavity.py` | Tables 1 and 3, Section 8: lowest quark mode and rms radius in the sphere, the 13-site cluster or the tetrahedral void. Usage: `python3 dirac_cavity.py sphere|cubo|tet n R Mout` (grid size, circumradius in sites, outside mass); KL/ħc = R·Mout. |
| `vector_cavity.py` | Table 1 and Section 8: lowest gluon mode with the bag wall in the sphere and the cluster. |
| `cubo.py` | Scalar hard-wall mode of the cluster (grid check). |
| `dirac_runs.log` | Output of `dirac_cavity.py` at Mout = 1, 2, 4 for the sphere and the cluster, and for the tetrahedral void at two grid sizes. |
| `fcc_cells.py`, `edge_route.py` | Section 7: which cells fit inside the cluster, the sublattice content of each cell, the edge route out of the cluster, and the singlet and single-color syndromes. |
| `fig_cells.py` | Fig. 3 and Section 7: the cells of the 13-site cluster, and the failed checks and flipped bonds when one color is pulled away. |
| `string_invisible.py` | Section 7: two chains with the same failed checks are different states, with the same check energy. |
| `fcc_code_qmc.py` | Section 7 and Fig. 4: path-integral quantum Monte Carlo of Eq. (7), the pair sector of Eq. (6). Usage: `python3 fcc_code_qmc.py L h k [beta dtau sweeps seed alt]` (box of L cubic cells, h/λ, separation k·√2 L_c; alt > 0 picks another shortest chain). |
| `scan.sh`, `analyze.py`, `fig_qmc.py` | Run scans; average over seeds and compute the string tension (`qmc_table.txt`); draw Fig. 4. All runs are in `qmc_runs.log`. |
| `cavity_modes.py` | Table 6, Eqs. (8)–(9) and Fig. 5: mode energies, cluster size from the charge radius, and the three-quark mass. |
| `ranks.py` | Appendix A: ranks of the node and octahedral checks of the periodic FCC code; k = 4N+2 logical qubits (130 for N = 32). |
| `ed_check.py` | Appendix A: exact lowest levels of the original Hamiltonian on a 23-qubit fragment (two octahedral cells), in each sector, against the pooled spectra of all dual blocks. |
| `orbit_check.py` | Appendix A: orbit counting, full spectra of 30 random orbits against Eq. (7) (multiplicities included), and Tr H, Tr H² over each sector. |
| `member_check.py` | Appendix A: every level found by `ed_check.py` lies in the pooled dual spectra. |

The values of x in Table 1 are the exact one-dimensional values (π/2 for the bag quark, π for the hard-wall scalar), the exact sphere values of the bag model (2.043 for the quark, 2.744 for the gluon), and the cluster value 2.60 from `dirac_cavity.py`.
