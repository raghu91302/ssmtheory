#!/usr/bin/env python3
"""Collect V(r) from all runs; mean and standard error over seeds; sigma_eff with errors. Writes qmc_table.txt."""
import re,numpy as np,collections
d=collections.defaultdict(list)
for f in ['L4.log','L4b.log','L6a.log','L6b.log','L6seeds.log','L8.log']:
    for l in open(f):
        L=int(re.search(r' L=(\d)',' '+l).group(1)); h=round(float(re.search(r'h=([\d.]+)',l).group(1)),3)
        k=int(re.search(r'k=(\d)',l).group(1)); d[(L,h,k)].append(float(re.search(r'V=([\d.]+)',l).group(1)))
r=np.sqrt(2); out=[]
def mv(L,h,k):
    v=np.array(d[(L,h,k)]); return v.mean(), (v.std(ddof=1)/np.sqrt(len(v)) if len(v)>1 else np.nan), len(v)
for L in (4,6,8):
    for h in sorted({h for (LL,h,k) in d if LL==L}):
        ks=sorted(k for (LL,hh,k) in d if LL==L and hh==h)
        Vs=[mv(L,h,k) for k in ks]
        line='L=%d nodes=%d h=%.2f  '%(L,4*L**3,h)+'  '.join('V(%.2f)=%.4f±%.4f[n=%d]'%(k*r,a,b,n) for k,(a,b,n) in zip(ks,Vs))
        sig=[]
        for i in range(len(ks)-1):
            a,ea,_=Vs[i]; b,eb,_=Vs[i+1]; s=(b-a)/r; e=np.sqrt(np.nan_to_num(ea)**2+np.nan_to_num(eb)**2)/r
            sig.append('sigma(%.1f-%.1f)=%.3f±%.3f'%(ks[i]*r,ks[i+1]*r,s,e))
        out.append(line+'\n    '+'  '.join(sig))
open('qmc_table.txt','w').write('\n'.join(out)+'\n'); print('\n'.join(out))
