# Stress test of the Zeno law for walls, part 1: which strong penalties hold a massless Dirac particle (and antiparticle)?
# 1D, H = sigma_x p (alpha = sigma_x, beta = sigma_z). Penalty outside: lam * (beta + a*1) [scalar + vector mix], or lam*sigma_y (pseudoscalar).
import numpy as np
Lb=4.0; N=512
x=(np.arange(N)+0.5)*Lb/N-1.5; k=2*np.pi*np.fft.fftfreq(N,Lb/N); k[N//2]=0
F=np.fft.fft(np.eye(N),axis=0); p=np.linalg.inv(F)@np.diag(k)@F; p=(p+p.conj().T)/2
sx=np.array([[0,1],[1,0]]); sy=np.array([[0,-1j],[1j,0]]); sz=np.diag([1.,-1.]); I2=np.eye(2)
out=np.diag(((x<0)|(x>1))*1.); idx=np.kron(((x>0)&(x<1)),[1,1]).astype(bool)
H0=np.kron(p,sx)
def low(M,lam):
    e,v=np.linalg.eigh(H0+lam*np.kron(out,M)); w=(np.abs(v[idx])**2).sum(0); m=w>0.85
    pos=e[m&(e>0)]; neg=e[m&(e<0)]
    return (round(pos.min(),3) if len(pos) else None, round(-neg.max(),3) if len(neg) else None)
cases=[('mass (scalar), a=0',sz),('scalar + 0.5 vector',sz+0.5*I2),('scalar + 0.9 vector',sz+0.9*I2),
       ('projector, a=1',sz+1.0*I2),('scalar + 1.5 vector',sz+1.5*I2),('pseudoscalar sigma_y',sy),('pure vector',I2)]
print('lowest confined particle energy / antiparticle energy (units hbar c/L); bag value pi/2 = 1.571')
for name,M in cases:
    print('%-22s'%name,[ (lam,low(M,lam)) for lam in (30,100,200)])
