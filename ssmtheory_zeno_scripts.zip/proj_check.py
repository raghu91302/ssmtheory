# Is the quark wall a genuine stabilizer penalty?  H = H_field + lam * sum_outside (1 - S)/2, with S a check whose
# "fail" projector is (1-S)/2.  Candidates: fail = P_+ = (1+beta)/2 (upper component present), fail = P_- , fail = 1 (any quark).
import numpy as np
Lb=4.0; N=512
x=(np.arange(N)+0.5)*Lb/N-1.5; k=2*np.pi*np.fft.fftfreq(N,Lb/N); k[N//2]=0
F=np.fft.fft(np.eye(N),axis=0); p=np.linalg.inv(F)@np.diag(k)@F; p=(p+p.conj().T)/2
sx=np.array([[0,1],[1,0]]); sz=np.diag([1.,-1.]); H0=np.kron(p,sx)
ins=(x>0)&(x<1); out=np.diag((~ins)*1.); idx=np.kron(ins,[1,1]).astype(bool)
def low(H):
    e,v=np.linalg.eigh(H); wt=(np.abs(v[idx])**2).sum(0); m=wt>0.85
    pos=e[m&(e>0)]; neg=e[m&(e<0)]
    return (round(pos.min(),3) if len(pos) else None, round(neg.max(),3) if len(neg) else None)
for name,Pf in [('P+ (upper present)',(np.eye(2)+sz)/2),('P- (lower present)',(np.eye(2)-sz)/2),('any quark',np.eye(2)),('beta (scalar)',sz)]:
    print(name,[ (lam,low(H0+lam*np.kron(out,Pf))) for lam in (20,50,100,200)])
