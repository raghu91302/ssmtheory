#!/usr/bin/env python3
"""Confinement by the carrying code: lowest cavity modes of the confined species in the 13-site FCC cluster
(a cuboctahedron whose edge and circumradius both equal the confinement bond length L_c), the cluster size fixed
by the proton charge radius, and the three-quark mass.

Inputs (from cubo.py, dirac_cavity.py, vector_cavity.py on the same grid as the sphere of radius L_c):
  shape factors x = E L_c / (hbar c)
    scalar (Dirichlet), computed directly:                        3.926
    quark (MIT bag): sphere exact 2.0428 x cubo/sphere ratio 1.271:  2.596
    gluon (bag = dual of conducting wall): 2.744 x 1.16-1.24:      3.18-3.40
  rms radius of the lowest quark density, in units of L_c
    sphere exact (bag model):                                     0.7290
    dirac_cavity.py, n=40, R=12, Mout=4: sphere 0.7157, cubo 0.5687
    cubo corrected by the sphere grid error: 0.5687 * 0.7290/0.7157 = 0.5793
L_c = r_p / rho.  E = x hbar c / L_c.  Three quarks with the center of mass removed: M = sqrt(6) E = sqrt(6) x rho hbar c / r_p.
Writes fig_cavity.pdf."""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
hbarc = 197.327; rp = 0.84075; mp = 938.272
rho_cubo = 0.5687 * 0.7290 / 0.7157
shapes = {'cuboctahedron': (2.596, rho_cubo), 'sphere': (2.0428, 0.7290)}
for k, (x, rho) in shapes.items():
    Lc = rp / rho; E = x * hbarc / Lc; M = np.sqrt(6) * E
    print('%-14s x=%.3f rho=%.4f  L_c=%.3f fm  E_q=%.1f MeV  3E=%.0f  M=%.0f MeV (%+.1f%%)  M r_p=%.3f hbar c  r_p(M=m_p)=%.3f fm'
          % (k, x, rho, Lc, E, 3 * E, M, 100 * (M / mp - 1), np.sqrt(6) * x * rho, np.sqrt(6) * x * rho * hbarc / mp))
Lc = rp / rho_cubo
for k, v in {'gluon low': 3.18, 'gluon high': 3.40, 'scalar': 3.926}.items():
    print('%-10s E = %.0f MeV at L_c = %.2f fm' % (k, v * hbarc / Lc, Lc))
print('setting L_c = r_p instead: M = %.0f MeV' % (np.sqrt(6) * 2.596 * hbarc / rp))
r = np.linspace(0.5, 1.2, 200)
fig, ax = plt.subplots(figsize=(5.2, 3.4))
for (k, (x, rho)), ls in zip(shapes.items(), ['-', '--']):
    ax.plot(r, np.sqrt(6) * x * rho * hbarc / r, color='C0', ls=ls, label=k)
ax.axhline(mp, color='k', lw=0.8, ls=':'); ax.text(1.05, mp + 30, 'proton', fontsize=8)
ax.axvline(rp, color='gray', lw=0.8); ax.text(rp + 0.01, 1350, r'$r_p$', fontsize=8, color='gray')
ax.set_xlabel('rms radius of the quark density (fm)'); ax.set_ylabel('three-quark mass (MeV)')
ax.set_ylim(400, 1500); ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig('fig_cavity.pdf')
