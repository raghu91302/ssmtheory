#!/usr/bin/env python3
"""Fig. 3 of the Zeno paper and the numbers of Section 6.
(a) The 13-site cluster: shell sites colored by sublattice (three color sublattices; the centre is an anchor site).
    One tetrahedral cell (inside the cluster) and one octahedral cell (reaching one site beyond the shell).
(b) Separating one color: violated checks and flipped bonds against separation.
Code: qubits on bonds; X-check on the 12 edges of each octahedral cell. A Z on a bond violates the two octahedral
checks that contain it; a chain of Z's that links octahedra through shared bonds leaves violations only at its ends."""
import numpy as np, itertools as it, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from collections import deque
R=range(-9,10); S={p for p in it.product(R,R,R) if sum(p)%2==0}
def sub(v):
    e=[c%2==0 for c in v]; return 'A' if all(e) else ('xy' if e[2] else ('xz' if e[1] else 'yz'))
D=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
bonds=[(p,tuple(np.add(p,d))) for p in S for d in D if tuple(np.add(p,d)) in S]
def octs(b):  # octahedral centres (odd coordinate sum) containing both ends
    a,c=np.array(b[0]),np.array(b[1]); m=(a+c)/2; out=[]
    for d in [(1,0,0),(0,1,0),(0,0,1)]:
        for s in (1,-1):
            o=np.round(m+s*np.array(d)/2*0) if False else None
    cand={tuple(int(x) for x in np.array(v)) for v in it.product(*[range(int(min(a[i],c[i]))-1,int(max(a[i],c[i]))+2) for i in range(3)]) if sum(v)%2}
    return [o for o in cand if np.abs(a-o).sum()==1 and np.abs(c-o).sum()==1]
link={}
for b in bonds:
    oc=octs(b)
    if len(oc)==2:
        for i in (0,1): link.setdefault(oc[i],[]).append((oc[1-i],b))
start=(1,0,0); prev={start:None}; q=deque([start])
while q:
    u=q.popleft()
    for v,b in link.get(u,[]):
        if v not in prev: prev[v]=(u,b); q.append(v)
def synd(E):
    cnt={}
    for b in E:
        for o in octs(b): cnt[o]=cnt.get(o,0)+1
    return [k for k,v in cnt.items() if v%2]
sep=[];nb=[];nv=[]
for k in range(0,5):
    tgt=(1+2*k,0,0); E=[];u=tgt
    while prev[u]: u,b=prev[u]; E.append(b)
    if k==0: E=[((0,0,0),(1,1,0))]
    sy=synd(E); dd=np.linalg.norm(np.subtract(sy[0],sy[1]))/np.sqrt(2)
    sep.append(dd); nb.append(len(E)); nv.append(len(sy))
    print('separation %.2f L: flipped bonds %d, violated checks %d'%(dd,len(E),len(sy)))
fig=plt.figure(figsize=(9.5,4))
ax=fig.add_subplot(1,2,1,projection='3d')
shell=[p for p in S if sorted(map(abs,p))==[0,1,1]]
col={'xy':'#c0392b','xz':'#16a085','yz':'#2c3e50','A':'#888'}
for p in shell:
    for q in shell:
        if p<q and np.sum((np.array(p)-q)**2)==2: ax.plot(*zip(p,q),color='#bbb',lw=0.6)
for p in shell: ax.scatter(*p,color=col[sub(p)],s=40,depthshade=False)
ax.scatter(0,0,0,color='k',s=50)
tet=[(0,0,0),(1,1,0),(1,0,1),(0,1,1)]
for a,b in it.combinations(tet,2): ax.plot(*zip(a,b),color='#e6a700',lw=2.2)
oct_=[(0,0,0),(2,0,0),(1,1,0),(1,-1,0),(1,0,1),(1,0,-1)]
for a,b in it.combinations(oct_,2):
    if np.sum((np.array(a)-b)**2)==2 and not (a in tet and b in tet): ax.plot(*zip(a,b),color='#8e44ad',lw=1.2,ls='--')
ax.scatter(2,0,0,color='#8e44ad',s=45,marker='s',depthshade=False)
ax.set_axis_off(); ax.view_init(20,-80); ax.set_xlim(-1.2,2.1); ax.set_ylim(-1.2,1.2); ax.set_zlim(-1.2,1.2); ax.set_box_aspect((3.3,2.4,2.4)); ax.set_box_aspect((1,1,1))
ax.set_title('(a) cells of the 13-site cluster',fontsize=10)
ax2=fig.add_subplot(1,2,2)
ax2.plot(sep,nb,'o-',color='C0',label='flipped bonds'); ax2.plot(sep,nv,'s--',color='C3',label='violated checks')
ax2.set_xlabel(r'distance between the violated checks ($L_c$)'); ax2.set_ylabel('count'); ax2.legend(fontsize=8)
ax2.set_title('(b) pulling one color away',fontsize=10)
plt.tight_layout(); plt.savefig('/home/claude/zeno/paper/fig_cells.pdf'); print('ok')
