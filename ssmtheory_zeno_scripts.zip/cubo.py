#!/usr/bin/env python3
"""Lowest Dirichlet eigenvalue of -Laplacian in a cuboctahedron of edge L (the 13-node cluster: a node and its 12 FCC
neighbors at distance L; circumradius = edge = L). Region: |x_i|<1 and |x|+|y|+|z|<2, edge sqrt(2). Reports sqrt(lambda1)*L."""
import numpy as np, scipy.sparse as sp, sys, time
from scipy.sparse.linalg import lobpcg
L=np.sqrt(2)
def lam1(n):
    xs=np.linspace(-1,1,n+2)[1:-1]; h=xs[1]-xs[0]
    X,Y,Z=np.meshgrid(xs,xs,xs,indexing='ij'); I=(np.abs(X)+np.abs(Y)+np.abs(Z))<2
    idx=-np.ones(I.shape,np.int64); N=int(I.sum()); idx[I]=np.arange(N)
    r=[];c=[]
    for d in range(3):
        a1=np.moveaxis(idx,d,0); u=a1[:-1].ravel(); v=a1[1:].ravel(); m=(u>=0)&(v>=0); r+=[u[m],v[m]]; c+=[v[m],u[m]]
    r=np.concatenate(r); c=np.concatenate(c)
    A=(sp.coo_matrix((-np.ones(len(r)),(r,c)),shape=(N,N))+6*sp.eye(N)).tocsr()/h**2
    w,_=lobpcg(A,np.random.default_rng(0).random((N,1)),largest=False,tol=1e-9,maxiter=4000)
    return w[0],h
out=[]
for n in map(int,sys.argv[1:]):
    l,h=lam1(n); out.append((h,np.sqrt(l)*L)); print('n=%d h=%.4f x=%.4f'%(n,h,np.sqrt(l)*L),flush=True)
H=np.array([o[0] for o in out]); Xv=np.array([o[1] for o in out]); print('extrapolated x = %.3f'%np.polyval(np.polyfit(H,Xv,2),0))
V=5*np.sqrt(2)/3*L**3/L**3; R=(3*V/(4*np.pi))**(1/3); print('equal-volume sphere: x = pi/R = %.3f'%(np.pi/R))
