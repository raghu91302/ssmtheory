#!/usr/bin/env python3
"""Verification as a wall, in one dimension. Region [0,1] in a periodic box of length 4.
(a) A free particle (H = p^2) checked for being inside every tau: effective ground energy -> Dirichlet value pi^2.
(b) A massless Dirac particle (H = sigma_x p) with a check of strength K on its scalar density outside the region
    (H_K = H + K beta chi_out, beta = sigma_z): ground energy -> MIT bag value pi/2 as K grows.
    The same strength on the charge density (K chi_out) confines no state (Klein).
Spectral (FFT) derivative, so the Dirac operator has no doublers. Writes fig_zeno.pdf and prints the numbers."""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.linalg import expm
Lb=4.0
def grid(N):
    x=(np.arange(N)+0.5)*Lb/N-1.5; k=2*np.pi*np.fft.fftfreq(N,Lb/N); k[N//2]=0
    F=np.fft.fft(np.eye(N),axis=0); p=np.linalg.inv(F)@np.diag(k)@F; return x,(p+p.conj().T)/2
# (a) scalar Zeno
x,_=grid(601); N=len(x); h=x[1]-x[0]
H=(2*np.eye(N)-np.eye(N,k=1)-np.eye(N,k=-1))/h**2; ins=(x>0)&(x<1)
taus=np.array([1e-3,5e-4,2e-4,1e-4,5e-5,3e-5]); Ea=[]
for t in taus:
    ev=np.linalg.eigvals(expm(-1j*H*t)[np.ix_(ins,ins)]); E=-np.angle(ev)/t
    Ea.append(E[(E>0)&(E<50)].min())
nD=ins.sum(); HD=(2*np.eye(nD)-np.eye(nD,k=1)-np.eye(nD,k=-1))/h**2; Dir=np.linalg.eigvalsh(HD)[0]
print('scalar Zeno: tau',taus,' E',np.round(Ea,3),' Dirichlet grid',round(Dir,3),' exact',round(np.pi**2,3))
# (b) Dirac walls
x,p=grid(512); ins=(x>0)&(x<1); out=~ins; idx=np.kron(ins,[1,1]).astype(bool)
sx=np.array([[0,1],[1,0]]); sz=np.diag([1.,-1.]); H0=np.kron(p,sx)
def ground(Hk):
    e,v=np.linalg.eigh(Hk); wt=(np.abs(v[idx])**2).sum(0); m=wt>0.9
    return np.abs(e[m]).min() if m.any() else np.nan
Ks=np.array([3,5,10,20,30,50,70,100,150]); Eb=[]; Ec=[]
for K in Ks:
    Eb.append(ground(H0+K*np.kron(np.diag(out*1.),sz))); Ec.append(ground(H0+K*np.kron(np.diag(out*1.),np.eye(2))))
print('Dirac scalar-density check: K',Ks,' E',np.round(Eb,3),' bag pi/2 =',round(np.pi/2,3))
print('Dirac charge-density check: E',np.round(Ec,3))
fig,ax=plt.subplots(1,2,figsize=(9,3.4))
ax[0].semilogx(taus,Ea,'o-',color='C0'); ax[0].axhline(Dir,color='k',ls=':',lw=0.8)
ax[0].text(9e-4,Dir-0.06,'hard wall (same grid)',fontsize=8); ax[0].set_ylim(None,Dir+0.08)
ax[0].set_xlabel(r'interval between checks, $\tau$'); ax[0].set_ylabel(r'lowest energy ($\hbar^2/2mL^2$ units)')
ax[0].set_title('(a) particle checked for being inside',fontsize=10); ax[0].invert_xaxis()
ax[1].semilogx(Ks,Eb,'o-',color='C3',label='check on scalar density')
ax[1].axhline(np.pi/2,color='k',ls=':',lw=0.8); ax[1].text(12,np.pi/2-0.012,r'bag wall, $\pi/2$',fontsize=8); ax[1].set_ylim(None,np.pi/2+0.02)
ax[1].set_xlabel(r'check strength $KL/\hbar c$'); ax[1].set_ylabel(r'lowest energy ($\hbar c/L$)')
ax[1].set_title('(b) massless quark, checked outside',fontsize=10); ax[1].legend(fontsize=8,loc='lower right')
plt.tight_layout(); plt.savefig('paper/fig_zeno.pdf'); print('ok')
