#!/bin/bash
# usage: scan.sh L beta sweeps "h list" "k list" logfile
cd /home/claude/qmc
for h in $4; do for k in $5; do python3 fcc_code_qmc.py $1 $h $k $2 0.1 $3 >> $6; done; done
