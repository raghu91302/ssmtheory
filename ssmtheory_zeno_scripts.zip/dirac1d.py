# 1D massless Dirac, H = sigma_x p, beta = sigma_z. Region [0,1] inside a periodic box. FFT (SLAC) derivative: no doublers.
# Compare: (A) pulsed position checks; (B) strong coupling K*beta outside ("mass wall"); (C) strong coupling K outside (electric wall).
# MIT bag reference in 1D: E = (n+1/2) pi / L  -> 1.571, 4.712 ; Dirichlet-like: n pi -> 3.142
import numpy as np, sys
N=int(sys.argv[1]) if len(sys.argv)>1 else 256; Lb=4.0
x=(np.arange(N)+0.5)*Lb/N-1.5; k=2*np.pi*np.fft.fftfreq(N,Lb/N); k[N//2]=0
F=np.fft.fft(np.eye(N),axis=0); p=np.linalg.inv(F)@np.diag(k)@F; p=(p+p.conj().T)/2   # momentum matrix
sx=np.array([[0,1],[1,0]]); sz=np.diag([1.,-1.])
H0=np.kron(p,sx); ins=((x>0)&(x<1)); out=~ins
I2=np.eye(2); Pin=np.kron(np.diag(ins*1.),I2); Bout=np.kron(np.diag(out*1.),sz); Vout=np.kron(np.diag(out*1.),I2)
def low(E): E=np.sort(np.abs(E)); return np.round(E[:4:2] if np.allclose(E[0],E[1],atol=1e-3) else E[:3],3)
print('N=%d  inside sites=%d'%(N,ins.sum()))
w,V=np.linalg.eigh(H0); idx=np.kron(ins,[1,1]).astype(bool)
for tau in [1e-2,3e-3,1e-3]:
    U=(V*np.exp(-1j*w*tau))@V.conj().T; ev=np.linalg.eigvals(U[np.ix_(idx,idx)])
    o=np.argsort(-np.abs(ev))[:6]; E=-np.angle(ev[o])/tau
    print('(A) pulsed tau=%g  E=%s  |w|=%s'%(tau,np.round(np.sort(np.abs(E)),3),np.round(np.abs(ev[o]),4)))
# only modes that are inside: weight inside > 0.9
def confined(H):
    e,v=np.linalg.eigh(H); wt=(np.abs(v[idx])**2).sum(0); m=(wt>0.9)
    ee=e[m]; return np.round(np.sort(np.abs(ee))[:4],3), m.sum()
for K in [10,30,100,300]:
    print('(B) mass wall K=%d  confined |E|=%s (n=%d)'%(K,*confined(H0+K*Bout)))
for K in [10,30,100,300]:
    print('(C) electric wall K=%d  confined |E|=%s (n=%d)'%(K,*confined(H0+K*Vout)))
