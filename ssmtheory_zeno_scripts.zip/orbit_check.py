#!/usr/bin/env python3
"""Second part of the duality check, on the 23-qubit fragment of ed_check.py: multiplicities.
(a) Every term of the original Hamiltonian is diagonal in the X basis or flips a node star, so each orbit of the node
    flips is closed under H. Count: sector dimension = (number of classes of J) x 2^(N-1).
(b) For random orbits, build the original Hamiltonian on the orbit from the 23-bit strings themselves, diagonalize it
    completely, and compare with the full spectrum of the dual model H_J in the even sector of the global flip.
(c) Moments over each whole sector: Tr H and Tr H^2 from the bit strings, against the sum over all classes of the dual."""
import numpy as np, itertools as it
lam=1.0; h=0.15
def octv(c): c=np.array(c); return [tuple(c+s*np.array(e)) for e in [(1,0,0),(0,1,0),(0,0,1)] for s in (1,-1)]
C=[(1,0,0),(0,1,0)]; V=sorted({v for c in C for v in octv(c)}); vi={v:i for i,v in enumerate(V)}; N=len(V)
octset=[set(octv(c)) for c in C]
B=[(vi[a],vi[b]) for a,b in it.combinations(V,2) if sum((np.array(a)-b)**2)==2 and any(a in o and b in o for o in octset)]; nb=len(B)
star=[sum(1<<e for e,(u,w) in enumerate(B) if v in (u,w)) for v in range(N)]
octm=[sum(1<<e for e,(u,w) in enumerate(B) if V[u] in o and V[w] in o) for o in octset]
pc=lambda x: bin(x).count('1')
def sec_of(x): return tuple(pc(x&m)%2 for m in octm)
span={0}
for m in star: span|={s^m for s in span}
span=sorted(span)
print('(a) orbit size %d = 2^(N-1) = %d; sector dimension 2^%d = %d classes x %d'%(len(span),2**(N-1),nb-2,2**(nb-2)//len(span),len(span)))
S=np.array([[1-2*((i>>v)&1) for v in range(N)] for i in range(1<<N)]); Se=S[S[:,0]==1]; idx={tuple(x):k for k,x in enumerate(Se)}; M=len(Se)
Hx=np.eye(M)*lam*N/2
for v in range(N):
    for k,x in enumerate(Se):
        y=x.copy(); y[v]=-y[v]
        if y[0]==-1: y=-y
        Hx[idx[tuple(y)],k]+=-lam/2
def dual(J,sec):
    d=(h/2)*sum((1-J[e]*Se[:,u]*Se[:,w]) for e,(u,w) in enumerate(B))+lam*sum(sec)
    return Hx+np.diag(d)
def orig_on_orbit(x0):
    cfg=sorted(x0^s for s in span); pos={c:i for i,c in enumerate(cfg)}; D=len(cfg); H=np.zeros((D,D)); sec=sec_of(x0)
    for i,c in enumerate(cfg):
        H[i,i]=lam*sum(sec)+lam*N/2+h*pc(c)
        for m in star: H[pos[c^m],i]+=-lam/2
    return H,sec
rng=np.random.default_rng(3); worst=0
for trial in range(30):
    x0=int(rng.integers(0,1<<nb)); H,sec=orig_on_orbit(x0)
    J=np.array([1-2*((x0>>e)&1) for e in range(nb)],float)
    worst=max(worst,np.abs(np.linalg.eigvalsh(H)-np.linalg.eigvalsh(dual(J,sec))).max())
print('(b) 30 random orbits: full spectra (512 levels each, multiplicities included) agree to %.1e'%worst)
# (c) moments. Original: Tr H = sum of diagonal; Tr H^2 = sum of squares of all matrix elements (H is symmetric).
T8=np.array([bin(i).count('1') for i in range(256)],np.int64)
def popc(x): return T8[x&255]+T8[(x>>8)&255]+T8[(x>>16)&255]+T8[(x>>24)&255]
allc=np.arange(1<<nb,dtype=np.int64); pars=[popc(allc&m)%2 for m in octm]
for sec in [(0,0),(1,0),(1,1)]:
    cfg=allc[(pars[0]==sec[0])&(pars[1]==sec[1])]
    d=lam*sum(sec)+lam*N/2+h*popc(cfg)
    t1=d.sum(); t2=(d**2).sum()+len(cfg)*N*(lam/2)**2
    # dual: sum over one representative per class
    seen=np.zeros(len(cfg),bool); pos=np.searchsorted
    d1=d2=0.0; reps=0
    for i in range(len(cfg)):
        if seen[i]: continue
        x0=int(cfg[i]); orb=np.array([x0^s for s in span]); seen[np.searchsorted(cfg,orb)]=True
        J=np.array([1-2*((x0>>e)&1) for e in range(nb)],float); Hd=dual(J,sec)
        d1+=np.trace(Hd); d2+=(Hd*Hd).sum(); reps+=1
    print('(c) sector %s: %d classes; Tr H original %.6f dual %.6f; Tr H^2 original %.6f dual %.6f'%(sec,reps,t1,d1,t2,d2))
