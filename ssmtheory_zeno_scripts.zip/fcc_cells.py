# Which cells of the FCC tet-oct honeycomb fit inside the 13-site cluster of a node?
import numpy as np, itertools as it
R=range(-4,5)
S=[np.array(p) for p in it.product(R,R,R) if sum(p)%2==0]        # FCC sites (bond length sqrt2)
Sset={tuple(p) for p in S}
shell={tuple(p) for p in S if sum(abs(np.array(p)))==2 and max(abs(np.array(p)))==1}
cluster=shell|{(0,0,0)}
print('cluster sites',len(cluster))
def nb(a,b): d=np.array(a)-np.array(b); return d@d==2
# tetrahedral cells: centres (odd/2 coords) -> 4 vertices
def tet(c): return [v for v in Sset if np.allclose(np.abs(np.array(v)-c),0.5)]
def octa(c): return [v for v in Sset if (np.abs(np.array(v)-c)).sum()==1]
tc=[np.array(p)/2 for p in it.product([-1,1],repeat=3)]
T=[tet(c) for c in tc]
print('tets touching node:',len(T),' all vertices in cluster:',all(set(t)<=cluster for t in T))
sheets=lambda v: 'xy' if v[2]==0 else ('xz' if v[1]==0 else 'yz')
print('shell vertices per tet, sheets:',[sorted(sheets(v) for v in t if v!=(0,0,0)) for t in T][:2])
oc=[np.array(p) for p in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
O=[octa(c) for c in oc]
print('octs touching node:',len(O),' vertices outside cluster per oct:',[len(set(o)-cluster) for o in O])
# face adjacency: every tet face shared with which cell type?
def cells_with_face(f):
    out=[]
    for c in it.product(*[np.arange(-3,3.5,0.5)]*3):
        c=np.array(c)
        if np.all(np.abs(c-np.round(c))==0.5): vs=tet(c); typ='tet'
        elif sum(np.round(c).astype(int))%2==1 and np.allclose(c,np.round(c)): vs=octa(c); typ='oct'
        else: continue
        if len(vs) and set(f)<=set(vs): out.append(typ)
    return out
t=T[0]; faces=list(it.combinations(t,3))
print('neighbours across the faces of one tet:',[cells_with_face(f) for f in faces])
