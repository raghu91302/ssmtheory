import numpy as np
exec(open('dirac1d.py').read().split("print('N=")[0])
w,V=np.linalg.eigh(H0); idx=np.kron(ins,[1,1]).astype(bool)
for tau in [1e-3]:
    U=(V*np.exp(-1j*w*tau))@V.conj().T; ev=np.linalg.eigvals(U[np.ix_(idx,idx)])
    E=-np.angle(ev)/tau; G=-np.log(np.abs(ev))/tau   # energy and decay rate per unit time
    o=np.argsort(np.abs(E))[:6]
    print('tau=%g'%tau, ' E=',np.round(E[o],3),' decay rate=',np.round(G[o],3))
