#!/usr/bin/env python3
"""Fig.: static potential between two colour charges in the SSM code, Eq. (4). Reads the logs of fcc_code_qmc.py.
(a) V(r) - 2 lam on 864 nodes (mean and standard error over three runs) and 2048 nodes (one run).
(b) effective string tension sigma_eff = dV/dr against h/lam. Filled: steps away from the largest separation the box
    allows; open: the step to it (half the box), which is larger in every box."""
import re,numpy as np,collections,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
d=collections.defaultdict(list)
for f in ['L4.log','L4b.log','L6a.log','L6b.log','L6seeds.log','L8.log']:
    for l in open(f):
        if 'alt=' in l and 'alt=0' not in l: continue
        L=int(re.search(r' L=(\d)',' '+l).group(1)); h=round(float(re.search(r'h=([\d.]+)',l).group(1)),3)
        k=int(re.search(r'k=(\d)',l).group(1)); d[(L,h,k)].append(float(re.search(r'V=([\d.]+)',l).group(1)))
def mv(L,h,k):
    v=np.array(d[(L,h,k)]); return v.mean(), (v.std(ddof=1)/np.sqrt(len(v)) if len(v)>1 else 0.0)
r=np.sqrt(2)
fig,ax=plt.subplots(1,2,figsize=(9.5,3.7))
for h,c in zip([0.09,0.11,0.15,0.2,0.3],['C0','C1','C2','C3','C4']):
    ks=[1,2,3]; m=[mv(6,h,k) for k in ks]
    ax[0].errorbar([k*r for k in ks],[a-2 for a,_ in m],yerr=[e for _,e in m],fmt='o-',color=c,ms=4,capsize=2,label=r'$h/\lambda=%.2f$'%h)
    if (8,h,4) in d:
        ks8=[2,3,4]; ax[0].plot([k*r for k in ks8],[mv(8,h,k)[0]-2 for k in ks8],'s--',color=c,ms=4,mfc='none')
ax[0].set_xlabel(r'separation of the failed checks, $r$ ($L_c$)'); ax[0].set_ylabel(r'$V(r)-2\lambda$ ($\lambda$)')
ax[0].set_title('(a) potential: 864 nodes (solid), 2048 (open)',fontsize=9); ax[0].legend(fontsize=7)
def sig(L,h,k): (a,ea),(b,eb)=mv(L,h,k),mv(L,h,k+1); return (b-a)/r, np.hypot(ea,eb)/r
for L,k,m,c,fill,lab in [(6,1,'o','C1','full','864 nodes, $r$=1.4–2.8'),(8,2,'^','C3','full','2048 nodes, $r$=2.8–4.2'),
                          (4,1,'s','C0','none','256 nodes, $r$=1.4–2.8 (to half box)'),(6,2,'o','C1','none','864 nodes, $r$=2.8–4.2 (to half box)'),(8,3,'^','C3','none','2048 nodes, $r$=4.2–5.7 (to half box)')]:
    hs=sorted({h for (LL,h,kk) in d if LL==L and (LL,h,k+1) in d and (LL,h,k) in d})
    S=[sig(L,h,k) for h in hs]
    ax[1].errorbar(hs,[s for s,_ in S],yerr=[e for _,e in S],fmt=m+('-' if fill=='full' else '--'),color=c,mfc=(c if fill=='full' else 'none'),ms=4,capsize=2,label=lab)
hh=np.linspace(0,0.3,50); ax[1].plot(hh,r*hh,'k:',lw=0.8,label=r'$\sqrt{2}\,h$ (bond term alone)')
ax[1].set_xlabel(r'$h/\lambda$'); ax[1].set_ylabel(r'$\sigma_{\rm eff}$ ($\lambda/L_c$)'); ax[1].legend(fontsize=6.5)
ax[1].set_title('(b) effective string tension',fontsize=9)
plt.tight_layout(); plt.savefig('fig_qmc.pdf'); print('ok')
