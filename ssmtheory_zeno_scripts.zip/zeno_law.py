# How fast does a strong-check wall approach the hard wall?  Nonrelativistic (H = p^2) vs massless Dirac (H = sigma_x p).
import numpy as np
Lb=4.0; N=1024
x=(np.arange(N)+0.5)*Lb/N-1.5; k=2*np.pi*np.fft.fftfreq(N,Lb/N); k[N//2]=0
F=np.fft.fft(np.eye(N),axis=0); Finv=np.linalg.inv(F)
p=Finv@np.diag(k)@F; p=(p+p.conj().T)/2; p2=Finv@np.diag(k**2)@F; p2=(p2+p2.conj().T)/2
out=np.diag(((x<0)|(x>1))*1.)
for K in [25,100,400,1600]:
    e=np.linalg.eigvalsh(p2+K*out)[0]
    print('nonrel  K=%5d  E=%.4f  hard wall pi^2=%.4f  formula pi^2/(1+2/sqrt(K))^2=%.4f'%(K,e,np.pi**2,np.pi**2/(1+2/np.sqrt(K))**2))
sx=np.array([[0,1],[1,0]]); sz=np.diag([1.,-1.]); idx=np.kron(((x>0)&(x<1)),[1,1]).astype(bool)
for K in [25,100,400]:
    e,v=np.linalg.eigh(np.kron(p,sx)+K*np.kron(out,sz)); w=(np.abs(v[idx])**2).sum(0); E=np.abs(e[w>0.9]).min()
    print('Dirac   K=%5d  E=%.4f  bag pi/2=%.4f     formula (pi/2)/(1+1/K)=%.4f'%(K,E,np.pi/2,np.pi/2/(1+1/K)))
