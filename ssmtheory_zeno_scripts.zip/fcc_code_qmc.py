#!/usr/bin/env python3
"""Static potential between two colour charges in the SSM code with bond verification, Eq. (4):
   H = lam * sum_a (1 - S_a)/2 + h * sum_e (1 - X_e)/2,
S_a = Z-checks on node stars and X-checks on octahedral cells (qubits on FCC bonds, periodic box of L cubic cells).
X-checks and all X_e commute with H, so the failed octahedral checks are conserved: a pair of failed checks is a pair
of static charges. Within a sector, write the X-basis configuration as x_e = J_e s_u s_w (s = +-1 on nodes, J fixed by
the sector). Then H is a transverse-field Ising model on the FCC nodes,
   H = (h/2) sum_e (1 - J_e s_u s_w) + (lam/2) sum_v (1 - sigma^x_v) + lam * (number of failed octahedral checks),
with no sign problem. We sample it by path-integral Monte Carlo and get
   V(r) = E_pair(r) - E_vac = 2 lam + h * int_0^1 dk sum_{e in chain} <s_u s_w>_k
by Hellmann-Feynman, with J_e = 1 - 2k on the shortest chain of bonds that links the two failed checks.
Usage: python3 fcc_code_qmc.py L h k [beta dtau sweeps seed alt]   (alt>0 picks another shortest chain)"""
import numpy as np, sys, itertools as it, numba
from collections import deque
L=int(sys.argv[1]); h=float(sys.argv[2]); ksep=int(sys.argv[3])
beta=float(sys.argv[4]) if len(sys.argv)>4 else 8.0; dtau=float(sys.argv[5]) if len(sys.argv)>5 else 0.1
sweeps=int(sys.argv[6]) if len(sys.argv)>6 else 4000; seed0=int(sys.argv[7]) if len(sys.argv)>7 else 0; alt=int(sys.argv[8]) if len(sys.argv)>8 else 0; lam=1.0
P=2*L
nodes=[p for p in it.product(range(P),repeat=3) if sum(p)%2==0]; ni={p:i for i,p in enumerate(nodes)}; N=len(nodes)
D=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
bonds=[]
for p in nodes:
    for d in D:
        q=tuple((np.add(p,d))%P); bonds.append((ni[p],ni[q],p,d))
octs=[p for p in it.product(range(P),repeat=3) if sum(p)%2==1]; oi={p:i for i,p in enumerate(octs)}
def bond_octs(p,d):
    a=np.array(p); c=a+np.array(d); out=[]
    for e in [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]:
        o=a+np.array(e)
        if np.abs(c-o).sum()==1: out.append(tuple(o%P))
    return out
B=len(bonds); bo=[bond_octs(p,d) for (_,_,p,d) in bonds]
assert all(len(x)==2 for x in bo)
# shortest chain between octs (1,0,0) and (1+2k,0,0) through shared bonds
link={}
for b,(o1,o2) in enumerate(bo): link.setdefault(o1,[]).append((o2,b)); link.setdefault(o2,[]).append((o1,b))
if alt:   # a different shortest chain: shuffle the order in which neighbours are explored
    rs=np.random.default_rng(alt)
    for o in link: rs.shuffle(link[o])
s0=(1,0,0); t0=((1+2*ksep)%P,0,0); prev={s0:None}; q=deque([s0])
while q:
    u=q.popleft()
    for v,b in link[u]:
        if v not in prev: prev[v]=(u,b); q.append(v)
chain=[];u=t0
while prev[u]: u,b=prev[u]; chain.append(b)
J=np.ones(B); J[chain]=-1
# check: failed octahedral checks are exactly the two ends
prod={}
for b,(o1,o2) in enumerate(bo):
    for o in (o1,o2): prod[o]=prod.get(o,1)*J[b]
failed=sorted(o for o,v in prod.items() if v<0); assert failed==sorted([s0,t0]),failed
# neighbour tables
nb=np.zeros((N,12),np.int64); nbb=np.zeros((N,12),np.int64); cnt=np.zeros(N,np.int64)
for b,(u,w,_,_) in enumerate(bonds):
    nb[u,cnt[u]]=w; nbb[u,cnt[u]]=b; cnt[u]+=1; nb[w,cnt[w]]=u; nbb[w,cnt[w]]=b; cnt[w]+=1
assert (cnt==12).all()
cu=np.array([bonds[b][0] for b in chain]); cw=np.array([bonds[b][1] for b in chain])
M=int(round(beta/dtau)); M+=M%2
Ks=-0.5*np.log(np.tanh(dtau*lam/2)); Kj=dtau*h/2
@numba.njit(cache=True)
def run(s,Jb,nb,nbb,Ks,Kj,nsw,ntherm,cu,cw,seed):
    np.random.seed(seed); N,M=s.shape[0],s.shape[1]; acc=0.0; n=0
    for sw in range(nsw):
        for v in range(N):
            for t in range(M):
                f=0.0
                for j in range(12): f+=Jb[nbb[v,j]]*s[nb[v,j],t]
                f=Kj*f+Ks*(s[v,(t-1)%M]+s[v,(t+1)%M])
                dE=2*s[v,t]*f
                if dE<=0 or np.random.random()<np.exp(-dE): s[v,t]=-s[v,t]
        if sw>=ntherm:
            c=0.0
            for i in range(cu.shape[0]):
                for t in range(M): c+=s[cu[i],t]*s[cw[i],t]
            acc+=c/M; n+=1
    return acc/n
xg,wg=np.polynomial.legendre.leggauss(6); kap=(xg+1)/2; wk=wg/2
s=np.ones((N,M))
vals=[]
for kk in kap:
    Jb=J.copy(); Jb[chain]=1-2*kk
    c=run(s,Jb,nb,nbb,Ks,Kj,sweeps,sweeps//4,cu,cw,int(1e6*kk)+7*L+1000003*seed0)
    vals.append(c)
V=2*lam+h*np.dot(wk,vals)
print('alt=%d seed=%d L=%d h=%.3f k=%d chain=%d bonds dist=%.3f Lc  beta=%.1f M=%d  V=%.4f  chainbonds=%s  <ss>(kappa)=%s'%(alt,seed0,L,h,ksep,len(chain),np.sqrt(2)*ksep,beta,M,V,sorted(chain),np.round(vals,3)),flush=True)
