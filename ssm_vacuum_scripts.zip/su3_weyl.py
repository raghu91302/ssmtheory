#!/usr/bin/env python3
"""
su3_weyl.py
-----------
Backs Section 4 (the Weyl group and the weight structure).

Establishes, from the geometry alone:
  (1) the tetrahedral symmetry S4 acts on the three skew-pair matchings as the
      full S3, with kernel the Klein four-group V4 (S4/V4 = S3);
  (2) equivalently, the proper cubic rotations permute the three coordinate-plane
      bond classes as the full S3;
  (3) S3 is the Weyl group of su(3): the three fundamental weights form an
      equilateral triangle summing to zero, and S3 permutes them.

This fixes the Weyl group and the weight (A2) structure WITHOUT assuming the
Lie algebra; su(3) closure on the resulting qutrit is automatic and is not
claimed as a result (see the manuscript, Section 5).

Requires: numpy.  Run:  python3 su3_weyl.py
"""
import numpy as np, itertools

# (1) S4 on the 3 perfect matchings of K4
V=[0,1,2,3]
matchings=[frozenset({frozenset({0,1}),frozenset({2,3})}),
           frozenset({frozenset({0,2}),frozenset({1,3})}),
           frozenset({frozenset({0,3}),frozenset({1,2})})]
def act(p,m): return frozenset(frozenset({p[i] for i in e}) for e in m)
induced=set()
kernel=[]
for p in itertools.permutations(V):
    perm=tuple(matchings.index(act(p,m)) for m in matchings)
    induced.add(perm)
    if perm==(0,1,2): kernel.append(p)
print(f"(1) S4 on the 3 matchings induces {len(induced)} permutations = S3; kernel size {len(kernel)} (V4).")

# (2) cubic rotations on the 3 coordinate-plane classes
realized=set()
for p in itertools.permutations(range(3)):
    for s in itertools.product([1,-1],repeat=3):
        M=np.zeros((3,3),int)
        for i in range(3): M[i,p[i]]=s[i]
        if round(np.linalg.det(M))==1: realized.add(tuple(p))
print(f"(2) proper cubic rotations permute the 3 classes as {len(realized)} perms = S3.")

# (3) the three su(3) fundamental weights: equilateral, sum zero, permuted by S3
w=[np.array([np.cos(a),np.sin(a)]) for a in (np.pi/2, np.pi/2+2*np.pi/3, np.pi/2+4*np.pi/3)]
print(f"(3) fundamental weights sum = {np.round(sum(w),6)}; pairwise |wi-wj|^2 = "
      f"{[round(float(np.dot(w[i]-w[j],w[i]-w[j])),3) for i,j in [(0,1),(1,2),(0,2)]]}")
print("    equilateral triangle, summing to zero -> the A2 weight triangle, permuted by S3=Weyl(SU(3)).")
