#!/usr/bin/env python3
"""
su3_emergence.py
----------------
Backs Section 3 (the color qutrit emerges from the kinetic term).

The six cage bonds of the trapped tetrahedral defect carry the XY (hopping)
kinetic term. Grouping the bonds by the three skew-pair matchings, the
single-excitation hopping matrix factorizes EXACTLY as

        T = (J3 - I3) (x) J2 ,

where J3, J2 are all-ones matrices and I3 is the identity. Consequences:
  - the symmetric combination |+>_i = (|e_i1> + |e_i2>)/sqrt2 within each matching
    is a single state; XY acts on the three |+> states as 2(J3 - I3) -- the six
    color transitions. This 3-state COLOR QUTRIT emerges from the dynamics.
  - the antisymmetric combinations |->_i are exact dark states (eigenvalue 0),
    with zero leakage to the symmetric sector.
The qutrit is therefore derived, not assumed.

Requires: numpy.  Run:  python3 su3_emergence.py
"""
import numpy as np
np.set_printoptions(precision=3, suppress=True)

# cage K4 on A,B,C,D=0,1,2,3; 6 edges grouped by the 3 skew-pair matchings
edges = [(0,1),(2,3), (0,2),(1,3), (0,3),(1,2)]   # M1 | M2 | M3
def shares(e1,e2): return (len(set(e1)&set(e2))>0 and e1!=e2)
T = np.array([[1.0 if shares(edges[i],edges[j]) else 0.0 for j in range(6)] for i in range(6)])

print("XY hopping on the 6 cage bonds (grouped M1|M2|M3):")
print(T)

# block structure
ok = True
for i in range(3):
    for j in range(3):
        blk = T[2*i:2*i+2, 2*j:2*j+2]
        if i==j and not np.allclose(blk,0): ok=False
        if i!=j and not np.allclose(blk,1): ok=False
print(f"\nT = (J3 - I3) (x) J2 exactly: {ok}")

# +/- sectors
plus, minus = np.array([1,1])/np.sqrt(2), np.array([1,-1])/np.sqrt(2)
Sp = np.zeros((6,3)); Sm = np.zeros((6,3))
for i in range(3): Sp[2*i:2*i+2,i]=plus; Sm[2*i:2*i+2,i]=minus
Tsym, Tdark, leak = Sp.T@T@Sp, Sm.T@T@Sm, Sm.T@T@Sp
print("\ncolor qutrit (symmetric sector), XY action:")
print(Tsym, " = 2*(off-diagonal ones): the six color transitions")
print("\ndark sector (antisymmetric):")
print(Tdark, " -> eigenvalue 0, decoupled")
print(f"\nsymmetric<->dark leakage (symmetric limit): max |elt| = {np.abs(leak).max():.3f}")
print("\n=> the three-state color qutrit emerges as the symmetric sector of the cage")
print("   hopping; the complementary states are exactly dark. Not assumed.")
