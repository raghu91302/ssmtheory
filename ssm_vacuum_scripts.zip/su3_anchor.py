#!/usr/bin/env python3
"""
su3_anchor.py
-------------
Backs Section 5 (the anchor tension).

The anchor selection that supplies the Weyl structure distinguishes the three
anchor-incident cage bonds from the three opposite bonds. Weighting the XY
coupling by gA for bond-pairs sharing the anchor vertex and g otherwise (or,
equivalently, giving the anchor-incident bonds an on-site shift delta), the
dark sector is no longer exactly decoupled: it leaks into the color qutrit
with amplitude (gA - g)/2 (resp. delta/2) per matching, vanishing only in the
symmetric limit. The clean qutrit is therefore exact only for the symmetric
defect; the anchored defect leaks in proportion to the anchor asymmetry.

Requires: numpy.  Run:  python3 su3_anchor.py
"""
import numpy as np
edges=[(0,1),(2,3),(0,2),(1,3),(0,3),(1,2)]; ANCHOR=0
def shared(e1,e2):
    s=set(e1)&set(e2); return list(s)[0] if (s and e1!=e2) else None
def hopping(gA,g):
    T=np.zeros((6,6))
    for i in range(6):
        for j in range(6):
            v=shared(edges[i],edges[j])
            if v is not None: T[i,j]= gA if v==ANCHOR else g
    return T
plus,minus=np.array([1,1])/np.sqrt(2),np.array([1,-1])/np.sqrt(2)
Sp=np.zeros((6,3)); Sm=np.zeros((6,3))
for i in range(3): Sp[2*i:2*i+2,i]=plus; Sm[2*i:2*i+2,i]=minus

print(f"{'gA/g':>8} {'color transition':>18} {'dark leakage':>14}")
for r in [1.0,1.2,1.5,2.0,3.0]:
    T=hopping(r,1.0)
    print(f"{r:8.2f} {(Sp.T@T@Sp)[0,1]:18.3f} {np.abs(Sm.T@T@Sp).max():14.3f}")
print("leakage = (gA - g)/2 per matching; zero only at gA = g.\n")

def onsite(delta,g=1.0):
    T=hopping(g,g); o=np.array([delta if ANCHOR in e else 0.0 for e in edges])
    return T+np.diag(o)
print(f"{'delta':>8} {'dark leakage':>14}")
for d in [0.0,0.2,0.5,1.0]:
    print(f"{d:8.2f} {np.abs(Sm.T@onsite(d)@Sp).max():14.3f}")
print("=> the clean qutrit is exact only in the symmetric limit; the anchor leaks it.")
