#!/usr/bin/env python3
"""
verify_gauss.py
---------------
Backs Section 4.1 (charge as a Gauss-law flux) and Figure 2a.

Demonstrates the three defining properties of a conserved Gauss-law charge,
realized as the net flux leaving a defect node on a lattice:
  (i)   surface independence  -- net flux is the same through every enclosing surface;
  (ii)  invariance under local flux-conserving surgery -- rerouting a flux line
        with fixed endpoints leaves the enclosed charge unchanged;
  (iii) integer-quantized change only by a boundary-crossing tear.

The topological content is dimension-independent; a cubic lattice suffices.
Requires: numpy.  Run:  python3 verify_gauss.py
"""
import numpy as np

L = 11; c = L // 2  # cubic grid, defect at the center

def enclosed_flux(lines, r):
    """Net signed crossings of the sphere |x - center| = r by a set of flux paths."""
    net = 0
    for path in lines:
        for k in range(len(path)-1):
            a = np.array(path[k]); b = np.array(path[k+1])
            ra = np.linalg.norm(a-c); rb = np.linalg.norm(b-c)
            net += int(ra <= r < rb) - int(rb <= r < ra)
    return net

# charge Q = 2 : two straight flux lines leaving the defect
straight = [[(c+i, c, c) for i in range(0, c+1)],
            [(c, c+i, c) for i in range(0, c+1)]]
print("(i) surface independence (charge Q = 2):")
for r in (0.5,1.5,2.5,3.5,4.5):
    print(f"     flux through sphere r={r}: {enclosed_flux(straight, r)}")
print("    -> identical at every radius: this is Gauss's law.\n")

# (ii) reroute one line through a local detour, endpoints fixed
wiggle = [[(c,c,c),(c+1,c,c),(c+1,c+1,c),(c+2,c+1,c),(c+2,c,c)] +
          [(c+i,c,c) for i in range(3,c+1)],
          [(c, c+i, c) for i in range(0, c+1)]]
print("(ii) invariance under local rerouting (endpoints fixed):")
for r in (2.5,3.5,4.5):
    print(f"     flux through sphere r={r}: {enclosed_flux(wiggle, r)}")
print("    -> unchanged: flux-conserving surgery cannot alter the charge.\n")

# (iii) tear: remove a whole flux line out to the boundary
torn = [straight[0]]
print("(iii) boundary-crossing tear (remove one whole flux line):")
for r in (2.5,3.5,4.5):
    print(f"     flux through sphere r={r}: {enclosed_flux(torn, r)}")
print("    -> charge changed 2 -> 1, by exactly one integer.")
print("\nConclusion: the winding/charge is a surface-independent, surgery-immune,")
print("integer-quantized Gauss-law invariant -- a genuine conserved quantum number.")
