#!/usr/bin/env python3
"""
su3_algebra.py
--------------
Completeness check referenced in Section 5.2: the six color transitions (root
generators E_ij) plus two Cartan generators span su(3) and close with the A2
structure constants. This closure is AUTOMATIC on any qutrit and is included for
reproducibility, not as evidence for the construction (see the manuscript).
Requires: numpy.  Run:  python3 su3_algebra.py
"""
import numpy as np, itertools
E={(i,j):np.zeros((3,3),complex) for i in range(3) for j in range(3) if i!=j}
for (i,j) in E: E[(i,j)][i,j]=1.0
H1=np.diag([1,-1,0]).astype(complex); H2=np.diag([1,1,-2]).astype(complex)/np.sqrt(3)
basis=[H1,H2]+[E[k] for k in sorted(E)]
def vec(M): return np.concatenate([M.real.ravel(),M.imag.ravel()])
B=np.array([vec(M) for M in basis])
print(f"generators: 2 Cartan + {len(E)} roots = {len(basis)}; span dim = "
      f"{np.linalg.matrix_rank(B,tol=1e-9)} (su(3) has dim 8)")
# all 28 commutators stay within the span
allgen=basis; closed=True
for A,Bm in itertools.combinations(allgen,2):
    C=A@Bm-Bm@A
    M=np.vstack([B,vec(C)])
    if np.linalg.matrix_rank(M,tol=1e-9)>np.linalg.matrix_rank(B,tol=1e-9): closed=False
print(f"all 28 commutators close within the span: {closed}")
print("Note: closure on a qutrit is automatic; this is a reproducibility check, not evidence.")
