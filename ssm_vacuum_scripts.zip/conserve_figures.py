#!/usr/bin/env python3
"""
make_figures.py
---------------
Regenerates the three figures used in the paper, as vector PDFs:
  fig_hops.pdf    (Figure 1, Section 3)  -- the two migration channels
  fig_gauss.pdf   (Figure 2, Section 4)  -- Gauss-law charge + confinement
  fig_string.pdf  (Figure 3, Section 6)  -- migration as a string operator
Requires: numpy, matplotlib.  Run:  python3 make_figures.py
"""

import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
from matplotlib.patches import FancyArrowPatch, Circle
from mpl_toolkits.mplot3d import proj3d

mpl.rcParams.update({
    "font.family": "serif",
    "mathtext.fontset": "cm",
    "font.size": 10,
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
})

INK="#1a1a1a"; GRAY="#8a8a8a"; LGRAY="#cfcfcf"
BLUE="#2c5f8a"; GREEN="#3a7d44"; RED="#b23b3b"; GOLD="#c8932a"

# ============================================================
# FIGURE 1 — the two migration channels on the FCC void sublattice (3D)
# ============================================================
class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kw):
        super().__init__((0,0),(0,0), *args, **kw); self._v=(xs,ys,zs)
    def do_3d_projection(self, renderer=None):
        xs,ys,zs=self._v; xp,yp,_=proj3d.proj_transform(xs,ys,zs,self.axes.M)
        self.set_positions((xp[0],yp[0]),(xp[1],yp[1])); return np.min(zs)

def tet_faces(v):
    return [[v[0],v[1],v[2]],[v[0],v[1],v[3]],[v[0],v[2],v[3]],[v[1],v[2],v[3]]]

ref =np.array([[0,0,0],[.5,.5,0],[.5,0,.5],[0,.5,.5]])           # reference P void
edgeN=np.array([[.5,0,.5],[0,.5,.5],[0,0,1],[.5,.5,1]])          # edge-adjacent N (shares 2)
trsP =np.array([[.5,.5,0],[1,1,0],[.5,1,.5],[1,.5,.5]])          # translational P (shares 1)
cR,cE,cT=ref.mean(0),edgeN.mean(0),trsP.mean(0)

fig=plt.figure(figsize=(6.2,4.6))
ax=fig.add_subplot(111,projection="3d")
for v,col,a in [(ref,GRAY,.10),(edgeN,BLUE,.13),(trsP,GREEN,.13)]:
    pc=Poly3DCollection(tet_faces(v),alpha=a,facecolor=col,edgecolor=col,linewidths=1.0)
    ax.add_collection3d(pc)
# vertices
allv=np.vstack([ref,edgeN,trsP])
ax.scatter(allv[:,0],allv[:,1],allv[:,2],s=14,color=INK,depthshade=False)
# shared vertices (ringed)
def shared(a,b):
    sa={tuple(np.round(x,6)) for x in a}; return np.array([x for x in b if tuple(np.round(x,6)) in sa])
sE=shared(ref,edgeN); sT=shared(ref,trsP)
ax.scatter(sE[:,0],sE[:,1],sE[:,2],s=90,facecolors="none",edgecolors=BLUE,linewidths=1.6,depthshade=False)
ax.scatter(sT[:,0],sT[:,1],sT[:,2],s=90,facecolors="none",edgecolors=GREEN,linewidths=1.6,depthshade=False)
# trapped nodes (centroids)
for c in (cR,cE,cT):
    ax.scatter(*c,s=42,color=GOLD,edgecolor=INK,linewidths=.6,depthshade=False,zorder=5)
# hop arrows
ax.add_artist(Arrow3D(*zip(cR,cE),mutation_scale=13,lw=1.6,arrowstyle="-|>",color=BLUE))
ax.add_artist(Arrow3D(*zip(cR,cT),mutation_scale=13,lw=1.6,arrowstyle="-|>",color=GREEN))
ax.text(*(cE+np.array([-0.34,-0.04,0.05])),
        "edge-adjacent\n$d=a/2$, flip\n4 bonds",color=BLUE,fontsize=8.5,ha="center")
ax.text(*((cR+cT)/2+np.array([0.05,0.05,0.02])),
        "translational\n$d=a/\\sqrt{2}$, keep\n6 bonds",color=GREEN,fontsize=8.5,ha="center")
ax.text(*(cR+np.array([0.02,0.02,-0.13])),"reference\nP-void",color=INK,fontsize=8.5,ha="center")
# cosmetics
ax.set_box_aspect((1,1,1))
ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_zlim(0,1)
ax.set_xticks([0,.5,1]); ax.set_yticks([0,.5,1]); ax.set_zticks([0,.5,1])
ax.set_xlabel("$x/a$",labelpad=-6,fontsize=8); ax.set_ylabel("$y/a$",labelpad=-6,fontsize=8)
ax.set_zlabel("$z/a$",labelpad=-6,fontsize=8)
ax.tick_params(labelsize=7,pad=-2)
ax.view_init(elev=18,azim=-58)
ax.grid(False)
for pane in (ax.xaxis,ax.yaxis,ax.zaxis):
    pane.pane.set_alpha(0.04); pane.pane.set_edgecolor(LGRAY)
plt.tight_layout()
plt.savefig("fig_hops.pdf",bbox_inches="tight",pad_inches=0.05)
plt.close()
print("fig_hops.pdf done")

# ============================================================
# FIGURE 2 — Gauss-law charge: surface independence + color-singlet confinement
# ============================================================
fig,(axa,axb)=plt.subplots(1,2,figsize=(6.6,3.25))

# panel (a): source + nested enclosing surfaces
axa.set_aspect("equal"); axa.axis("off")
axa.set_xlim(-3.2,3.2); axa.set_ylim(-3.0,3.0)
# flux lines radiating outward from the source
for ang in [30,100,168,238,312]:
    x=2.78*np.cos(np.radians(ang)); y=2.78*np.sin(np.radians(ang))
    axa.annotate("",xy=(x,y),xytext=(0,0),
        arrowprops=dict(arrowstyle="-|>",color=INK,lw=1.0,shrinkA=0,shrinkB=0))
for r in (1.1,1.9,2.6):
    axa.add_patch(Circle((0,0),r,fill=False,ec=BLUE,lw=1.0,alpha=0.85))
axa.scatter([0],[0],s=70,color=GOLD,edgecolor=INK,linewidths=.7,zorder=5)
axa.text(0.12,-0.50,"defect",fontsize=8,ha="left")
axa.text(0,2.80,"$\\Phi=Q$ on every surface",fontsize=8,color=BLUE,ha="center",va="bottom")
axa.set_title("(a) charge = enclosed flux",fontsize=9.5,pad=4)
axa.text(0,-3.05,"surface-independent",fontsize=8,ha="center",color=INK)

# panel (b): three colored fractional fluxes -> color-singlet integer escapes; single colored confined
axb.set_aspect("equal"); axb.axis("off")
axb.set_xlim(-3.4,3.7); axb.set_ylim(-3.2,3.2)
node=np.array([-1.7,0.0]); junc=np.array([0.5,0.0])
axb.scatter(*node,s=70,color=GOLD,edgecolor=INK,linewidths=.7,zorder=6)
for col,rad,lab,ly in [(RED,0.34,"$-\\frac{1}{3}$",0.92),(GREEN,0.0,"$-\\frac{1}{3}$",0.18),(BLUE,-0.34,"$+\\frac{2}{3}$",-0.92)]:
    axb.annotate("",xy=junc,xytext=node,
        arrowprops=dict(arrowstyle="-",color=col,lw=1.7,
            connectionstyle=f"arc3,rad={rad}"))
    axb.text((node[0]+junc[0])/2,ly,lab,color=col,fontsize=8.5,ha="center",va="center")
# integer color-singlet line escapes to the boundary
axb.annotate("",xy=(3.3,0.0),xytext=junc,
    arrowprops=dict(arrowstyle="-|>",color=INK,lw=1.9,shrinkA=2,shrinkB=0))
axb.scatter(*junc,s=22,color=INK,zorder=6)
axb.text(2.05,0.42,"$Q\\in\\mathbb{Z}$",fontsize=9,ha="center",va="bottom")
axb.text(2.05,-0.55,"color-singlet escapes",fontsize=7.8,ha="center",va="top",color=INK)
axb.text(-1.7,-1.55,"3 colored fractional\nfluxes (confined)",fontsize=7.8,ha="center",color=INK)
axb.set_title("(b) confinement of fractional charge",fontsize=9.5,pad=4)

plt.tight_layout()
plt.savefig("fig_gauss.pdf",bbox_inches="tight",pad_inches=0.05)
plt.close()
print("fig_gauss.pdf done")

# ============================================================
# FIGURE 3 — migration as a string operator: syndrome confined to endpoints
# ============================================================
fig,ax=plt.subplots(figsize=(6.2,2.9))
ax.set_aspect("equal"); ax.axis("off")
nx,ny=8,4
xs,ys=np.meshgrid(range(nx),range(ny))
# lattice edges (faint)
for i in range(nx):
    for j in range(ny):
        if i+1<nx: ax.plot([i,i+1],[j,j],color=LGRAY,lw=0.7,zorder=1)
        if j+1<ny: ax.plot([i,i],[j,j+1],color=LGRAY,lw=0.7,zorder=1)
ax.scatter(xs,ys,s=9,color=GRAY,zorder=2)
# the string (path of toggled bonds) from old endpoint to new endpoint
path=[(1,1),(2,1),(3,1),(3,2),(4,2),(5,2)]
for (x0,y0),(x1,y1) in zip(path[:-1],path[1:]):
    ax.plot([x0,x1],[y0,y1],color=BLUE,lw=2.6,zorder=3,solid_capstyle="round")
old=path[0]; new=path[-1]
# syndrome only at the two endpoints
for p,lab,dx in [(old,"origin",-0.0),(new,"defect",0.0)]:
    ax.scatter(*p,s=120,facecolors="none",edgecolors=RED,linewidths=1.8,zorder=4)
    ax.scatter(*p,s=34,color=GOLD,edgecolor=INK,linewidths=.5,zorder=5)
ax.text(old[0],old[1]+0.5,"syndrome",color=RED,fontsize=8,ha="center")
ax.text(new[0],new[1]+0.5,"syndrome",color=RED,fontsize=8,ha="center")
ax.text((old[0]+new[0])/2,-0.65,
        "string of toggled bonds: bulk stays in the codespace; syndrome only at the two endpoints",
        fontsize=8,ha="center",color=INK)
ax.text(2.0,1.0-0.55,"$X$-string",color=BLUE,fontsize=8.5,ha="center")
ax.set_xlim(-0.6,nx-0.4); ax.set_ylim(-1.1,ny-0.3)
plt.tight_layout()
plt.savefig("fig_string.pdf",bbox_inches="tight",pad_inches=0.05)
plt.close()
print("fig_string.pdf done")
