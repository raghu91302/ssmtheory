#!/usr/bin/env python3
"""
verify_color_assignment.py
--------------------------
Backs Section 4.3 (the color assignment is fixed by the coordination geometry).

Establishes:
  (1) the 12 FCC nearest-neighbor bonds split into 3 classes of 4 by the
      coordinate plane each bond lies in (its vanishing coordinate);
  (2) the proper cubic rotation group permutes these 3 classes as the full
      symmetric group S3 = Weyl group of SU(3) (all 6 permutations realized);
  (3) the 3 perfect matchings of a void's bounding cage coincide with the 3
      coordinate-plane classes (the two pictures are one structure);
  (4) the weight-12 vertex stabilizer factors over the 3 classes, so the
      codespace condition S_v = +1 enforces q0 (+) q1 (+) q2 = 0 -- the
      color-singlet condition at the Z2 (parity) level.

The full integer (weight-lattice) singlet requires flux beyond Z2 (a qutrit /
SU(3)-fundamental local space) and is NOT derived here.

Requires: numpy.  Run:  python3 verify_color_assignment.py
"""
import numpy as np, itertools

# (1) the 12 FCC nearest-neighbor directions and their 3x4 decomposition
nn = sorted(set(
    [(s1,s2,0) for s1,s2 in itertools.product([1,-1],repeat=2)] +
    [(s1,0,s2) for s1,s2 in itertools.product([1,-1],repeat=2)] +
    [(0,s1,s2) for s1,s2 in itertools.product([1,-1],repeat=2)]))
def color_class(v): return [i for i in range(3) if v[i]==0][0]
classes = {0:[],1:[],2:[]}
for v in nn: classes[color_class(v)].append(v)
print(f"(1) {len(nn)} nearest-neighbor bonds split into three coordinate-plane classes:")
for k in (0,1,2):
    print(f"    class {k} (plane perpendicular to axis {k}): {classes[k]}")

# (2) cubic rotations permute the classes as S3
realized = set()
for p in itertools.permutations(range(3)):
    for signs in itertools.product([1,-1],repeat=3):
        M = np.zeros((3,3),int)
        for i in range(3): M[i,p[i]] = signs[i]
        if round(np.linalg.det(M)) == 1:
            realized.add(tuple(p))
print(f"\n(2) proper cubic rotations realize {len(realized)} permutations of the 3 classes:")
print(f"    {sorted(realized)} = S3 = Weyl(SU(3)).")

# (3) cage matchings = coordinate-plane classes
Pv = [np.array(x) for x in [(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]]
matchings = [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def edge_dir(e):
    d = Pv[e[1]] - Pv[e[0]]; d = d / abs(d[abs(d)>1e-9]).min()
    return tuple(int(round(x)) for x in d)
print("\n(3) cage matchings vs coordinate-plane classes:")
for m in matchings:
    cls = [color_class(edge_dir(e)) for e in m]
    print(f"    matching {m}: classes {cls}  -> {'same class' if cls[0]==cls[1] else 'MIXED'}")
print("    each matching lies in one class: matchings = color classes.")

# (4) vertex stabilizer factorization -> Z2 singlet condition
print("\n(4) weight-12 vertex stabilizer  S_v = prod_{all 12} Z_e")
print("                                     = prod_{c=0,1,2} ( prod_{e in class c} Z_e ).")
print("    color charge q_c = parity of flux in class c.")
print("    codespace  S_v = +1  =>  q0 XOR q1 XOR q2 = 0   (color singlet, mod 2).")
print("\nDerived: the 3 classes, their S3=Weyl symmetry, and the singlet condition mod 2.")
print("Not derived: the full integer/SU(3) singlet -- needs flux beyond Z2 (a qutrit).")
