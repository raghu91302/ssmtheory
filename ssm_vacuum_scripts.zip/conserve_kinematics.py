#!/usr/bin/env python3
"""
verify_kinematics.py
--------------------
Backs Section 5 (relativistic kinematics of a stable defect).

Direct numerical integration of the moving-soliton Hamiltonian density for the
canonical sine-Gordon kink (kappa = m_s = a = 1, V_bind = 1 - cos u, E_rest = 8)
reproduces E(v) = gamma * E_rest across the full relativistic range.

The integration uses NO equipartition shortcut: it integrates the full energy
density of the Lorentz-contracted profile on a fine grid and compares to
gamma * E_rest.

Requires: numpy.  Run:  python3 verify_kinematics.py
"""
import numpy as np

# static sine-Gordon kink (width 1):  u(x) = 4 arctan(e^x),  u'(x) = 2 sech(x)
def u_static(s):  return 4*np.arctan(np.exp(s))
def du_static(s): return 2/np.cosh(s)

trapz = getattr(np, "trapezoid", getattr(np, "trapz", None))  # numpy>=2 renamed trapz
E_rest = 8.0
x = np.linspace(-60, 60, 1_200_001)   # fine, wide grid
t = 0.0

print(f"{'beta':>6} {'E(v) numeric':>16} {'gamma*E_rest':>14} {'E/E_rest':>12} {'gamma':>10}")
for beta in (0.1, 0.3, 0.5, 0.7, 0.9, 0.95):
    g = 1/np.sqrt(1 - beta**2)
    s = g*(x - beta*t)                 # Lorentz-contracted argument
    up = du_static(s)
    ux = g*up                          # d u / d x
    ut = -g*beta*up                    # d u / d t
    u = u_static(s)
    Hd = 0.5*ut**2 + 0.5*ux**2 + (1 - np.cos(u))   # full Hamiltonian density
    E = trapz(Hd, x)
    print(f"{beta:6.2f} {E:16.6f} {g*E_rest:14.6f} {E/E_rest:12.6f} {g:10.6f}")

print("\nE(v) = gamma * E_rest holds across the full relativistic range")
print("(agreement to ~6 decimal places), confirming E = M c^2 for the soliton.")
