#!/usr/bin/env python3
"""
verify_orientation.py
---------------------
Backs Section 3 (the negative result) and Table 1.

Establishes:
  (1) the up-defect and down-defect cages are graph-isomorphic (both K4) --
      so no internal graph invariant distinguishes void orientation;
  (2) the bond surgery needed to move a defect from a reference P-void to each
      neighboring void: bonds changed = 2*(4 - shared_vertices). The cheapest
      orientation-FLIPPING move (edge-adjacent, a/2, 4 bonds) is closer and
      cheaper than the cheapest orientation-PRESERVING move (a/sqrt2, 6 bonds).

Requires: numpy.  Run:  python3 verify_orientation.py
"""
import numpy as np

a = 1.0
basis = np.array([[0,0,0],[.5,.5,0],[.5,0,.5],[0,.5,.5]]) * a

def cage(center):
    """The 4 bounding FCC vertices of a tetrahedral void (distance a*sqrt(3)/4)."""
    out = []
    for dx in range(-2,3):
        for dy in range(-2,3):
            for dz in range(-2,3):
                for b in basis:
                    p = np.array([dx,dy,dz])*a + b
                    if abs(np.linalg.norm(p-center) - a*np.sqrt(3)/4) < 1e-6:
                        out.append(tuple(np.round(p,6)))
    return set(out)

# P (positive) and N (negative) tetrahedral voids in the conventional cell
P = [(.25,.25,.25),(.75,.75,.25),(.75,.25,.75),(.25,.75,.75)]
N = [(.75,.75,.75),(.25,.25,.75),(.25,.75,.25),(.75,.25,.25)]

# (1) isomorphism: each cage is K4 (4 mutually bonded vertices) -> identical as graphs
print("(1) Cage structure: each defect cage is K4 (a complete graph on 4 vertices).")
print("    Up-cage and down-cage are therefore graph-isomorphic; no internal")
print("    invariant distinguishes them. Orientation is an embedding label only.\n")

# build the full neighbor list around a reference P-void
voids = []
for cx in range(-1,2):
    for cy in range(-1,2):
        for cz in range(-1,2):
            sh = np.array([cx,cy,cz])*a
            for c in P: voids.append(('P', tuple(np.round(np.array(c)*a+sh,6))))
            for c in N: voids.append(('N', tuple(np.round(np.array(c)*a+sh,6))))

ref = (.25,.25,.25); refc = cage(np.array(ref))
rows = []
for typ, ctr in voids:
    if np.allclose(ctr, ref): continue
    d = np.linalg.norm(np.array(ctr)-np.array(ref))
    if d > 0.95: continue
    shared = len(refc & cage(np.array(ctr)))
    rows.append((round(d,4), typ, shared, 2*(4-shared)))

print("(2) Bond surgery to move the defect to each neighboring void:")
print(f"    {'dist/a':>7} {'orient':>7} {'shared':>7} {'bonds changed':>14}")
seen = set()
for d,typ,sh,ch in sorted(rows):
    if (d,typ,sh,ch) in seen: continue
    seen.add((d,typ,sh,ch))
    tag = 'FLIP' if typ=='N' else 'keep'
    print(f"    {d:7.4f} {typ:>7} {sh:>7} {ch:>14}   ({tag})")

keep = min(ch for d,typ,sh,ch in rows if typ=='P')
flip = min(ch for d,typ,sh,ch in rows if typ=='N')
print(f"\n    cheapest orientation-PRESERVING (P->P): {keep} bonds")
print(f"    cheapest orientation-FLIPPING   (P->N): {flip} bonds")
print(f"    cost ratio flip/keep = {flip/keep:.3f}  -> flipping is cheaper.")
print("\n    Conclusion: void orientation is not a conserved label.")
