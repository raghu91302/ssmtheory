#!/usr/bin/env python3
"""
verify_baryons.py
-----------------
Backs Section 4.2 and Table 2 (first-shell baryon spectrum).

For each total winding W = sum(w_i), w_i in {0,1}, with baseline -1/3 per valence
bond and the three valence bonds carrying the three color labels {R,G,B}:
  - the total charge Q = -1 + W is an INTEGER for every baryon,
  - the configuration is a COLOR SINGLET (the three colors sum to white),
  - the individual valence (quark) charges are fractional.

Requires: numpy.  Run:  python3 verify_baryons.py
"""
import numpy as np

colors = {'R': np.array([1,0,0]), 'G': np.array([0,1,0]), 'B': np.array([0,0,1])}

def baryon(ws):
    quark = [-1/3 + w for w in ws]          # the three valence (quark) charges
    Q = round(sum(quark))                    # total charge
    csum = sum(colors[k] for k in 'RGB')     # three valence bonds carry the 3 colors
    singlet = len(set(csum)) == 1            # equal in all colors = color-neutral
    integer = abs(sum(quark) - Q) < 1e-9
    return quark, Q, integer, singlet

print("First-shell baryons as color-singlet flux configurations:")
print(f"  {'name':8} {'W':>2} {'quark charges':>22} {'Q':>3} {'integer':>8} {'singlet':>8}")
for ws, name in [((0,0,0),'Delta-'),((1,0,0),'neutron'),
                 ((1,1,0),'proton'),((1,1,1),'Delta++')]:
    q, Q, integer, singlet = baryon(ws)
    qs = "(" + ",".join(f"{x:+.2f}" for x in q) + ")"
    print(f"  {name:8} {sum(ws):>2} {qs:>22} {Q:>+3d} {str(integer):>8} {str(singlet):>8}")

print("\nThe total charge Q = -1 + W is integer and color-neutral for every baryon,")
print("even though the individual quark charges are fractional. Only the color-singlet")
print("integer escapes to infinity; the fractional colored fluxes are confined.")
