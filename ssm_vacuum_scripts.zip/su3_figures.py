#!/usr/bin/env python3
"""
su3_figures.py -- regenerates the figures for the su(3)/color-qutrit paper.
  fig_emergence.pdf  (Fig. 1, Sec. 3): cage hopping -> color qutrit + dark sector
Requires: numpy, matplotlib.  Run: python3 su3_figures.py
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle
plt.rcParams.update({"font.family":"serif","font.size":11,"axes.linewidth":0.8})

fig, ax = plt.subplots(1, 2, figsize=(8.4, 3.7))

# --- left: the cage K4, six bonds in 3 skew-pair colors ---
a = ax[0]; a.set_aspect("equal"); a.axis("off")
P = {"A":(0.0,1.0),"B":(-0.9,-0.5),"C":(0.9,-0.5),"D":(0.0,0.05)}
cols = {("A","B"):"#c0392b",("C","D"):"#c0392b",
        ("A","C"):"#27ae60",("B","D"):"#27ae60",
        ("A","D"):"#2e74b5",("B","C"):"#2e74b5"}
for (u,v),c in cols.items():
    a.plot([P[u][0],P[v][0]],[P[u][1],P[v][1]],"-",color=c,lw=2.2,zorder=1)
for k,(x,y) in P.items():
    a.add_patch(Circle((x,y),0.10,fc="white",ec="black",lw=1.3,zorder=2))
    a.text(x,y,k,ha="center",va="center",fontsize=10,zorder=3)
a.set_title("cage $K_4$: three skew pairs (colors)",fontsize=10.5)
a.text(0.5,-1.15,"$M_1$ red   $M_2$ green   $M_3$ blue",ha="center",fontsize=9,transform=a.transData)
a.set_xlim(-1.3,1.3); a.set_ylim(-1.35,1.25)

# --- right: hopping splits into color qutrit (sym) + dark (antisym) ---
b = ax[1]; b.axis("off")
b.text(0.5,1.02,r"$T=(J_3-I_3)\otimes J_2$",ha="center",fontsize=12,transform=b.transAxes)
# color qutrit triangle
cx,cy,r = 0.30,0.55,0.16
ang=[90,210,330]; pts=[(cx+r*np.cos(np.radians(t)),cy+r*np.sin(np.radians(t))) for t in ang]
ccol=["#c0392b","#27ae60","#2e74b5"]
for i,(x,y) in enumerate(pts):
    b.add_patch(Circle((x,y),0.045,fc=ccol[i],ec="black",lw=1,zorder=3,transform=b.transAxes))
for i in range(3):
    for j in range(i+1,3):
        b.annotate("",xy=pts[j],xytext=pts[i],transform=b.transAxes,
                   arrowprops=dict(arrowstyle="<->",lw=1.3,color="black"),zorder=1)
b.text(cx,cy+0.27,"color qutrit (symmetric)",ha="center",fontsize=9.5,transform=b.transAxes)
b.text(cx,cy-0.30,"six color transitions",ha="center",fontsize=8.5,color="#444",transform=b.transAxes)
# dark sector
dx=0.78
for i,t in enumerate([0.62,0.50,0.38]):
    b.add_patch(Circle((dx,t),0.035,fc="#cccccc",ec="#777",lw=1,zorder=3,transform=b.transAxes))
b.text(dx,0.74,"dark sector",ha="center",fontsize=9.5,transform=b.transAxes)
b.text(dx,0.26,"(antisymmetric,\ndecoupled)",ha="center",fontsize=8.5,color="#444",transform=b.transAxes)
b.set_xlim(0,1); b.set_ylim(0,1)

plt.tight_layout()
plt.savefig("fig_emergence.pdf",bbox_inches="tight")
print("done fig_emergence.pdf")
