#!/usr/bin/env python3
"""Fig. 3: sum of neutrino masses against the lightest mass, with the K_nu = 1/2 solutions (NuFIT 6.1 splittings)."""
import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
matplotlib.rcParams['pdf.fonttype']=42; matplotlib.rcParams['ps.fonttype']=42   # TrueType fonts in PDF figures
blue,red,green='#1f4e79','#b0522a','#3a7d44'

dm21=7.53e-5; dmNO=2.529e-3; dmIO=2.484e-3
ml=np.logspace(-4.5,-0.8,300)
sNO=ml+np.sqrt(ml**2+dm21)+np.sqrt(ml**2+dmNO); sIO=ml+np.sqrt(ml**2+dmIO)+np.sqrt(ml**2+dmIO+dm21)
fig,ax=plt.subplots(figsize=(6.2,4))
ax.loglog(ml*1e3,sNO*1e3,color=blue,label='normal ordering'); ax.loglog(ml*1e3,sIO*1e3,color=green,label='inverted ordering')
ax.axhline(64.2,ls='--',color='k',lw=0.8); ax.text(0.05,67,r'DESI DR2 + CMB ($\Lambda$CDM): $\sum m_\nu<64.2$ meV',fontsize=8)
ax.plot(0.797,59.81,'o',color=red,ms=7,label=r'$K_\nu=1/2$, normal ordering'); ax.plot(1e-3*0.0005*1e3+0.0316,98.92,'s',mfc='none',mec=red,ms=7,label=r'$K_\nu=1/2$, inverted ordering (above the DESI bound)')
ax.annotate(r'$m_1=0.80$ meV, $\sum=59.8$ meV',(0.797,59.81),xytext=(0.9,45),fontsize=8,arrowprops=dict(arrowstyle='->',lw=0.7))
ax.annotate(r'IO: $m_3=0$, $\sum=98.9$ meV',(0.0316,98.92),xytext=(0.06,130),fontsize=8,arrowprops=dict(arrowstyle='->',lw=0.7))
from matplotlib.ticker import ScalarFormatter, FixedLocator
ax.yaxis.set_major_locator(FixedLocator([40,60,80,100,200,400])); ax.yaxis.set_major_formatter(ScalarFormatter()); ax.yaxis.set_minor_formatter(plt.NullFormatter())
ax.set_xlabel('lightest neutrino mass (meV)'); ax.set_ylabel(r'$\sum m_\nu$ (meV)'); ax.set_xlim(0.03,150); ax.set_ylim(40,400); ax.legend(fontsize=8,loc='upper left')
plt.tight_layout(); plt.savefig('fig3_neutrino.pdf'); plt.close()
print("figures written")
