import numpy as np
from scipy.optimize import brentq
# oscillation data (NuFIT 6.1, 2026, incl. first JUNO data): dm21 = 7.53e-5 eV^2; dm31 = +2.529e-3 (normal), dm32 = -2.484e-3 (inverted)
dm21=7.53e-5; dm31_NO=2.529e-3; dm32_IO=-2.484e-3
def masses(d,a=1.0):
    s=a*(1+np.cos(d+2*np.pi*np.arange(3)/3)); return s**2            # m_k, delocalized rule, K = 1/2
K=lambda m:m.sum()/np.sqrt(m).sum()**2
print("check K for random phases:",[round(K(masses(d)),6) for d in (0.1,0.5,0.9)])
sols=[]
ds=np.linspace(0,np.pi/3,20001)           # delta mod 2pi/3 and sign -> [0, pi/3]
for order in ("normal","inverted"):
    def ratio(d):
        m=np.sort(masses(d))
        if order=="normal":   # m1<m2<m3: dm21 = m2^2-m1^2 small, dm31 = m3^2-m1^2
            return (m[1]**2-m[0]**2)/(m[2]**2-m[0]**2)-dm21/dm31_NO
        else:                 # m3<m1<m2: dm21 = m2^2-m1^2 (the top two), |dm32| = m2^2-m3^2
            return (m[2]**2-m[1]**2)/(m[2]**2-m[0]**2)-dm21/abs(dm32_IO)
    f=np.array([ratio(d) for d in ds])
    for i in np.where(np.sign(f[:-1])!=np.sign(f[1:]))[0]:
        d=brentq(ratio,ds[i],ds[i+1]); m=np.sort(masses(d))
        scale=np.sqrt((dm31_NO if order=="normal" else abs(dm32_IO))/(m[2]**2-m[0]**2))
        mm=m*scale
        sols.append((order,d,mm))
print(f"\n{'ordering':>9} {'delta_nu':>9} {'m1 (meV)':>9} {'m2 (meV)':>9} {'m3 (meV)':>9} {'sum (meV)':>10}")
for order,d,mm in sols:
    lab={"normal":(0,1,2),"inverted":(1,2,0)}[order]   # print as m1,m2,m3 in standard labelling
    m1,m2,m3=(mm[lab[0]],mm[lab[1]],mm[lab[2]]) if order=="normal" else (mm[1],mm[2],mm[0])
    print(f"{order:>9} {d:9.5f} {m1*1e3:9.3f} {m2*1e3:9.3f} {m3*1e3:9.3f} {mm.sum()*1e3:10.2f}")
print("\nconstraints: DESI DR2 + CMB, sum < 64.2 meV (95%, LCDM); KATRIN m_beta < 450 meV; oscillation minimum 59.0 meV (NO), 98.9 meV (IO)")

# lepton mixing implied by using the same sheet-type basis for both sectors
P = np.roll(np.eye(3), 1, axis=0)
Wl = np.sqrt(.5)*np.eye(3) + .5*(np.exp(1j*2/9)*P + np.exp(-1j*2/9)*P.T)     # charged leptons (localized)
Wn = np.eye(3) + .5*(np.exp(1j*0.332)*P + np.exp(-1j*0.332)*P.T)             # neutrinos (delocalized)
U = np.linalg.eigh(Wl)[1].conj().T @ np.linalg.eigh(Wn)[1]
print("\nmixing check: operators commute =", np.allclose(Wl@Wn, Wn@Wl), "; |U|^2 =", np.round(np.abs(U)**2, 3).tolist(), "(a permutation: no mixing)")
