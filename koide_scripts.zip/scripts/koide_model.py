#!/usr/bin/env python3
"""Koide working note: reproduces every number quoted in koide_working_note.md.  numpy/scipy only."""
import numpy as np
from itertools import product
from scipy.optimize import brentq

K = lambda e: (e @ e) / e.sum() ** 2
me, mmu, mtau, smt = 0.51099895000, 105.6583755, 1776.93, 0.09   # PDG 2024
a = np.sqrt(np.array([me, mmu, mtau]))

print("1. TARGET")
print(f"   K (pole masses)            = {K(a):.6f}")
print(f"   K (running masses at M_Z)  = {K(np.sqrt(np.array([0.486570, 102.718, 1746.24]))):.6f}")
print(f"   angle of sqrt(m) to [111]  = {np.degrees(np.arccos(a.sum()/np.sqrt(3)/np.linalg.norm(a))):.4f} deg")
r = np.sqrt(2)
x = lambda d, k: 1 + r * np.cos(d + 2 * np.pi * k / 3)
d = brentq(lambda d: (x(d, 2) / x(d, 1)) ** 2 - mmu / me, 0.20, 0.24)
print(f"   delta from e, mu (r=sqrt2) = {d:.8f}  (2/9 = {2/9:.8f})")
# tau test: with the phase fixed by the electron and muon, K = 2/3 determines the tau mass
_d=brentq(lambda d:(lambda x:(x[1]/x[0])**2-mmu/me)(1+np.sqrt(2)*np.cos(d+2*np.pi*np.array([1,2,0])/3)),0.1,0.26)
_x=1+np.sqrt(2)*np.cos(_d+2*np.pi*np.array([1,2,0])/3); _r=(_x/_x[0])**2
print(f"   tau test at the fitted phase: m_tau/m_e = {_r[2]:.2f} (m_tau = {_r[2]*me:.3f} MeV) vs measured {mtau/me:.2f} +/- {smt/me:.2f}: {(_r[2]*me-mtau)/smt:.1f} sigma")

print("\n2. OBSTRUCTIONS")
ct = brentq(lambda c: K(np.sqrt(np.array([1, 207, c]))) - 2 / 3, 3400, 3600)
print(f"   exact-Koide C_tau given (1, 207)  = {ct:.5f}  (not an integer)")
hits = [v for v in product(range(-12, 13), repeat=3) if v != (0, 0, 0) and 2 * sum(v) ** 2 == 3 * sum(t * t for t in v)]
print(f"   cubic-lattice vectors at 45 deg to [111], |coords|<=12: {len(hits)}")
h = 1e-6
s_mu = (K(np.sqrt([me, mmu * (1 + h), mtau])) - K(a)) / h
s_ta = (K(np.sqrt([me, mmu, mtau * (1 + h)])) - K(a)) / h
print(f"   dK/dln m_mu = {s_mu:+.4f}, dK/dln m_tau = {s_ta:+.4f}")
rng = np.random.default_rng(0); e = rng.uniform(-0.002, 0.002, (200000, 2))
Ks = np.array([K(np.sqrt([me, mmu * (1 + p), mtau * (1 + q)])) for p, q in e[:20000]])
dev = np.abs(Ks / (2 / 3) - 1)
print(f"   random costs within 0.2%: within 1e-3 of 2/3: {np.mean(dev <= 1e-3):.2f}; within 9e-5: {np.mean(dev <= 9.4e-5):.2f}")

print("\n3. LIGHT-CONE IDENTITY  K = tau^2")
for t, nm in ((1.0, "D4 null bond"), (1 / np.sqrt(2), "D4 slice/bond"), (np.sqrt(2 / 3), "FCC (111) layer spacing/bond")):
    print(f"   {nm:30s} tau^2 = {t*t:.6f}")

print("\n4. THE MODEL")
NN = [np.array(v, float) for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
n = np.array([1, 1, 1]) / np.sqrt(3)
from collections import Counter
print("   bonds by layer (0 own sheet, +/-1 adjacent):", dict(Counter(round(v @ n / np.linalg.norm(v) * np.sqrt(1.5)) for v in NN)))
P = np.roll(np.eye(3), 1, axis=0)
def W(ph_up, ph_dn): return np.sqrt(.5) * np.eye(3) + .5 * np.exp(1j * ph_up) * P + .5 * np.exp(1j * ph_dn) * P.T
tau = np.sqrt(2 / 3)
for nm, (u, dn) in {"odd, tau^2/3 per step": (tau**2 / 3, -tau**2 / 3), "even, tau^2 per step": (tau**2, tau**2),
                    "odd, tau^2 per step": (tau**2, -tau**2)}.items():
    s = np.sort(np.linalg.svd(W(u, dn), compute_uv=False)); m = s**2 / (s**2)[0]
    print(f"   {nm:24s}: K = {K(s):.6f}, ratios {m[1]:.3f}, {m[2]:.2f}")
print(f"   measured ratios: {mmu/me:.4f}, {mtau/me:.2f} +/- {smt/me:.2f}")
ev = np.linalg.eigvals(P.T @ W(0, 0))
print("   discrete relabeling: eigen-phases / (2pi/3) =", np.round(np.angle(ev) / (2 * np.pi / 3), 4))
print(f"   required m*v per hop = tau/3 = {tau/3:.6f}; walk dispersion inertia = {(np.sqrt(.5)+1)/tau**2:.4f}")
