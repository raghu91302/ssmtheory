import numpy as np
from scipy.optimize import brentq
ETA_CAL=np.sin(2/9)
R=lambda a,dx,dy: np.roll(np.roll(a,dx,0),dy,1)
SH=[(0,1),(0,-1),(1,0),(-1,0),(1,-1),(-1,1)]
def grow(p,rule,Lx=150,T=700,w=10,seed=0):
    """birth-and-spread with 3-node nuclei; tracks each layer's registry (0,1,2 = A,B,C).
    'up' triangles continue the helix (+1), 'down' triangles reverse it (+2).
    rule 'helix': only up-triangle nuclei; rule 'random': both."""
    rng=np.random.default_rng(seed); h=np.zeros((Lx,Lx),int); reg=np.zeros((Lx,Lx),int); age=np.zeros((Lx,Lx),int)
    hist=[]; steps=[0,0]
    for t in range(T):
        # lateral spread: take the highest neighbour, and its registry
        m=h.copy(); mr=reg.copy()
        for dx,dy in SH:
            hn=R(h,dx,dy); rn=R(reg,dx,dy); better=hn>m; m=np.where(better,hn,m); mr=np.where(better,rn,mr)
        age[m>h]=0; h,reg=m,mr
        age=np.maximum(age-1,0); age[rng.random(h.shape)<p]=w
        up=(age>0)&(R(age,-1,0)>0)&(R(age,0,-1)>0)&(h==R(h,-1,0))&(h==R(h,0,-1))&(reg==R(reg,-1,0))&(reg==R(reg,0,-1))
        dn=np.zeros_like(up)
        if rule=='random':
            dn=(R(age,-1,0)>0)&(R(age,0,-1)>0)&(R(age,-1,-1)>0)&(R(h,-1,0)==R(h,0,-1))&(R(h,-1,0)==R(h,-1,-1))
        riseU=up|R(up,1,0)|R(up,0,1); riseD=(R(dn,1,0)|R(dn,0,1)|R(dn,1,1))&~riseU
        steps[0]+=int(up.sum()); steps[1]+=int(dn.sum())
        reg=np.where(riseU,(reg+1)%3,np.where(riseD,(reg+2)%3,reg)); h=h+riseU+riseD; age[riseU|riseD]=0
        hist.append(h.mean())
    hist=np.array(hist); eta=np.polyfit(np.arange(T//2,T),hist[T//2:],1)[0]
    # stacking quality of the final surface: registry should equal height mod 3 for a single ABC helix
    abc=np.mean(reg==(h%3)); acb=np.mean(reg==((-h)%3))
    walls=np.mean([(R(h,dx,dy)==h)&(R(reg,dx,dy)!=reg) for dx,dy in SH[:3]])
    return eta,abc,acb,walls,steps
# 1. lepton spectrum at the fitted phase
d=np.arcsin(ETA_CAL); x=lambda k:1+np.sqrt(2)*np.cos(d+2*np.pi*k/3); m=np.array([x(1),x(2),x(0)])**2; m/=m[0]
K=lambda v:(v@v)/v.sum()**2
print(f"1. phase delta = {d:.7f}; K = {K(np.sqrt(m)):.6f}; m_mu/m_e = {m[1]:.4f} (206.7683), m_tau/m_e = {m[2]:.2f} (3477.23 +/- 0.23)")
# 2. calibration under the helix rule: solve eta(p) = sin(delta)
from scipy.optimize import brentq
f=lambda p: np.mean([grow(p,'helix',Lx=120,T=500,seed=s)[0] for s in (0,1)])-ETA_CAL
p_h=brentq(f,0.06,0.10,xtol=5e-4)
print(f"2. helix-rule calibration: p = {p_h:.4f} = 1/{1/p_h:.1f} (exponent {-np.log(p_h):.2f}; published 3)")
# 3. fresh runs at the calibrated p on a larger lattice
res=[grow(p_h,'helix',seed=s) for s in range(4)]; e=np.array([r[0] for r in res])
print(f"3. fresh runs (150x150, 700 ticks, 4 seeds): eta = {e.mean():.4f} +/- {e.std()/2:.4f}; one-helix surface {np.mean([r[1] for r in res])*100:.1f}%; walls {np.mean([r[3] for r in res])*100:.2f}%")
# 4. random rule at a comparable lift probability
res=[grow(1/16.7,'random',seed=s) for s in range(3)]
print(f"4. random rule, p = 1/16.7: one-helix surface {np.mean([r[1] for r in res])*100:.1f}%; walls {np.mean([r[3] for r in res])*100:.2f}% of bonds")
