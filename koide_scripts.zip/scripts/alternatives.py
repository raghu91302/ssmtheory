#!/usr/bin/env python3
"""Reproduces the alternatives of Section 8 (other threefold structures, other phase origins). numpy only."""
import numpy as np
from itertools import product, combinations
Kf=lambda e:(e@e)/e.sum()**2
s3=np.sqrt(3)
# ---- 1. E6 counting operators on the three glue-class families (F4 -> E6 coordinates)
V={'v':np.array([1,0.]),'s':np.array([-.5,s3/2]),'c':np.array([-.5,-s3/2])}
S=[]
for i in range(4):
    for sg in (1,-1):
        e=np.zeros(4); e[i]=sg; S.append((e,'v'))
for sg in product((-.5,.5),repeat=4):
    x=np.array(sg); S.append((x,'s' if np.sum(x<0)%2==0 else 'c'))
fam={k:[np.concatenate([s,sg*V[c]]) for s,c in S if c==k for sg in (1,-1)] for k in 'vsc'}
bond=[np.concatenate([np.array(v,float),[0,0]]) for v in product((-1,0,1),repeat=4) if sum(map(abs,v))==2]
roots=bond+[r for k in 'vsc' for r in fam[k]]
isroot=lambda x:any(np.allclose(x,r) for r in roots)
cands={"sum |a.b|":lambda a,b:abs(a@b),"sum (a.b)^2":lambda a,b:(a@b)**2,
       "pairs at 60/120 deg":lambda a,b:float(np.isclose(abs(a@b),1)),"pairs with a+b a root":lambda a,b:float(isroot(a+b))}
print("1. E6 counting operators on the glue-class families: off-diagonal/diagonal ratio (Koide needs 1/sqrt2 = 0.7071)")
for nm,f in cands.items():
    G=np.array([[sum(f(a,b) for a in fam[k] for b in fam[l]) for l in 'vsc'] for k in 'vsc'])
    print(f"   {nm:24s}: {G[0,1]:.0f}/{G[0,0]:.0f} = {G[0,1]/G[0,0]:.4f} (rational)")
# ---- 2. Killing form of gl(3) on diagonal amplitudes: B(X,X) = 6 tr X^2 - 2 (tr X)^2 ; null cone
print("2. Killing form of gl(3): null cone 6 sum a^2 = 2 (sum a)^2  ->  K = sum a^2/(sum a)^2 = 1/3 (Koide needs 2/3)")
# ---- 3. D4 roots and short weights against the triality axis
L4=[np.array(v,float) for v in product((-1,0,1),repeat=4) if sum(map(abs,v))==2]
S4=[np.array(v,float) for v in product((-1,0,1),repeat=4) if sum(map(abs,v))==1]+[np.array(sg)/2 for sg in product((-1,1),repeat=4)]
a1,a2,a3,a4=np.array([1,-1,0,0.]),np.array([0,1,-1,0.]),np.array([0,0,1,-1.]),np.array([0,0,1,1.])
T=np.column_stack([a3,a2,a4,a1])@np.linalg.inv(np.column_stack([a1,a2,a3,a4]))
w,Vv=np.linalg.eig(T); F=np.linalg.qr(np.real(Vv[:,np.isclose(w,1)]))[0]; Prot=np.eye(4)-F@F.T
for nm,X in (("roots",L4),("short weights",S4)):
    print(f"3. D4 {nm:13s}: squared cosines to the triality rotation plane: {sorted({round(float(x@Prot@x/(x@x)),6) for x in X})} (Koide needs 1/2)")
# ---- 4. root angles of E6, E7, E8
E8=[np.array(v,float) for v in product((-1,0,1),repeat=8) if sum(map(abs,v))==2]+[np.array(sg)/2 for sg in product((-1,1),repeat=8) if sg.count(-1)%2==0]
orth=lambda R,vs:[r for r in R if all(abs(r@v)<1e-9 for v in vs)]
u=np.array([0,0,0,0,0,0,1,1.]); v2=np.array([0,0,0,0,0,1,-1,0.])
for nm,R in (("E6",orth(E8,[u,v2])),("E7",orth(E8,[u])),("E8",E8)):
    ang=sorted({round(float(np.degrees(np.arccos(np.clip(p@q/2,-1,1)))),3) for p,q in combinations(R,2)})
    print(f"4. {nm} ({len(R)} roots): root-root angles {ang}")
# ---- 5. Berry phases per step on the natural cones (spin 1/2: Omega/6 per third of a loop)
print("5. Berry phase per step on the natural cones (fitted phase 0.2222):")
for nm,c in (("45 deg (Koide / D4 light cone)",np.cos(np.pi/4)),("face diagonal to [111]",np.sqrt(2/3)),("cube axis to [111]",1/np.sqrt(3)),("tetrahedral angle",1/3)):
    Om=2*np.pi*(1-c); print(f"   {nm:32s}: {Om/6:.4f}  (= pi x {Om/6/np.pi:.4f})")
