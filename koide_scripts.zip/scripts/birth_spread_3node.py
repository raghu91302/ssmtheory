import numpy as np
from scipy.optimize import brentq
# birth-and-spread on a (111) surface where a new layer needs a 3-node nucleus:
# each tick every site lifts with prob p; a lifted node survives w ticks unless covered;
# when the three sites of an elementary triangle (same height) all carry lifted nodes, they rise one layer;
# every tick layers spread laterally by one row (max over the 6 neighbours).
def speed(p,w,Lx=160,T=700,seed=0):
    rng=np.random.default_rng(seed); h=np.zeros((Lx,Lx),int); age=np.zeros((Lx,Lx),int)
    R=lambda a,dx,dy: np.roll(np.roll(a,dx,0),dy,1)
    sh=[(0,1),(0,-1),(1,0),(-1,0),(1,-1),(-1,1)]; hist=[]
    for t in range(T):
        m=h.copy()
        for dx,dy in sh: m=np.maximum(m,R(h,dx,dy))
        age[m>h]=0; h=m                                   # covered sites lose their waiting lifts
        age=np.maximum(age-1,0); age[rng.random(h.shape)<p]=w
        up=(age>0)&(R(age,-1,0)>0)&(R(age,0,-1)>0)&(h==R(h,-1,0))&(h==R(h,0,-1))          # triangle (i,j),(i+1,j),(i,j+1)
        dn=(R(age,-1,0)>0)&(R(age,0,-1)>0)&(R(age,-1,-1)>0)&(R(h,-1,0)==R(h,0,-1))&(R(h,-1,0)==R(h,-1,-1))
        rise=up|R(up,1,0)|R(up,0,1)|R(dn,1,0)|R(dn,0,1)|R(dn,1,1)
        h=h+rise; age[rise]=0; hist.append(h.mean())
    hist=np.array(hist); return np.polyfit(np.arange(T//2,T),hist[T//2:],1)[0]
target=np.sin(2/9); p=np.exp(-3)
print(f"published lift probability p = e^-3 = {p:.4f}; target eta = {target:.4f}")
print("eta against the lifetime w of a lone lift (both kinds of nucleus):")
for w in (1,2,3,5,8,12): print(f"   w = {w:2d}: eta = {speed(p,w):.3f}",flush=True)
print("eta against p at w = 10 (two seeds):")
for pp in (np.exp(-3),1/16.7,1/14.3,1/12.5): print(f"   p = 1/{1/pp:.1f}: eta = {np.mean([speed(pp,10,seed=s,T=600) for s in (0,1)]):.3f}",flush=True)
