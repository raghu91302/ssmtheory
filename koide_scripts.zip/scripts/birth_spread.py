import numpy as np
from scipy.optimize import brentq
# polynuclear (birth-and-spread) growth of a close-packed (111) surface, triangular lattice, periodic.
# each tick: every site takes the max height of itself and its 6 neighbours (lateral spread: one row per tick),
# then nucleates a new layer with probability p (one lift succeeding starts the layer above).
def speed(p,Lx=200,T=600,seed=0):
    rng=np.random.default_rng(seed); h=np.zeros((Lx,Lx),int)
    sh=[(0,1),(0,-1),(1,0),(-1,0),(1,-1),(-1,1)]          # triangular-lattice neighbours in skew coordinates
    hist=[]
    for t in range(T):
        m=h.copy()
        for dx,dy in sh: m=np.maximum(m,np.roll(np.roll(h,dx,0),dy,1))
        h=m+(rng.random(h.shape)<p); hist.append(h.mean())
    hist=np.array(hist); return np.polyfit(np.arange(T//2,T),hist[T//2:],1)[0]
formula=lambda p:(np.pi*p/(2*np.sqrt(3)))**(1/3)
print(f"{'p per site/tick':>16} {'simulated eta':>14} {'formula':>8}")
for p in (0.01,0.02,np.exp(-3),0.1):
    print(f"{p:16.4f} {speed(p):14.3f} {formula(p):8.3f}")
target=np.sin(2/9)
pk=brentq(lambda p:speed(p,Lx=160,T=500)-target,0.001,0.05)
print(f"\nKoide target eta = sin(2/9) = {target:.4f}  ->  p = {pk:.4f} = 1/{1/pk:.0f}  (Boltzmann exponent {-np.log(pk):.2f}; published: 3)")
