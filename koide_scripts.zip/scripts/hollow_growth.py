import numpy as np
R=lambda a,dx,dy: np.roll(np.roll(a,dx,0),dy,1)
SH=[(0,1),(0,-1),(1,0),(-1,0),(1,-1),(-1,1)]
def grow(p,Lx=160,T=700,seed=0,seed_sites='vertex',kinds='up'):
    """Hollow-based birth-and-spread on a triangular lattice (skew coords).
    Up-hollow U(i,j) = triangle (i,j),(i+1,j),(i,j+1); down-hollow D(i,j) = (i+1,j),(i,j+1),(i+1,j+1).
    Each tick: lateral spread by one row; each empty flat hollow of an allowed kind is lifted with prob p
    (a lifted node stays until its hollow is covered); a vertex whose three surrounding same-kind hollows are
    all lifted nucleates the next layer there."""
    rng=np.random.default_rng(seed); h=np.zeros((Lx,Lx),int)
    U=np.zeros((Lx,Lx),bool); D=np.zeros((Lx,Lx),bool); UH=np.full((Lx,Lx),-1); DH=np.full((Lx,Lx),-1); hist=[]
    for t in range(T):
        m=h.copy()
        for dx,dy in SH: m=np.maximum(m,R(h,dx,dy))
        h=m
        flatU=(h==R(h,-1,0))&(h==R(h,0,-1))                       # corners (i,j),(i+1,j),(i,j+1) level
        flatD=(R(h,-1,0)==R(h,0,-1))&(R(h,-1,0)==R(h,-1,-1))
        hU=h; hD=R(h,-1,0)                                          # height of each hollow's floor
        U&=flatU&(UH==hU); D&=flatD&(DH==hD)                        # a lift survives only on its own, uncovered floor
        newU=flatU&~U&(rng.random(h.shape)<p); U|=newU; UH=np.where(newU,hU,UH)
        if kinds=='both':
            newD=flatD&~D&(rng.random(h.shape)<p); D|=newD; DH=np.where(newD,hD,DH)
        # up-hollows around vertex v=(i,j): U(i,j), U(i-1,j), U(i,j-1); down-hollows: D(i-1,j-1), D(i-1,j), D(i,j-1)
        nucU=U&R(U,1,0)&R(U,0,1)
        nucD=R(D,1,1)&R(D,1,0)&R(D,0,1) if kinds=='both' else np.zeros_like(U)
        nuc=nucU|nucD
        if seed_sites=='vertex': rise=nuc
        else: rise=nuc.copy(); [rise.__ior__(R(nuc,dx,dy)) for dx,dy in SH]
        h=h+rise
        hist.append(h.mean())
    hist=np.array(hist); return np.polyfit(np.arange(T//2,T),hist[T//2:],1)[0]
if __name__=="__main__":
    p=1/20; print(f"p = 1/20 per hollow per tick; target 2/9 = {2/9:.4f}, sin(2/9) = {np.sin(2/9):.4f}")
    for kinds in ('up','both'):
        for seed_sites in ('vertex','vertex+ring'):
            e=np.mean([grow(p,seed=s,kinds=kinds,seed_sites=seed_sites) for s in (0,1)])
            print(f"   nucleating hollows: {kinds:4s} | nucleus seeds {seed_sites:11s}: eta = {e:.4f}",flush=True)
