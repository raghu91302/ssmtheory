import numpy as np, random, sys, itertools, time
from ssm_sim import SSMSim, LIFT_HEIGHT, LATERAL_HEIGHT
TAU=np.sqrt(2/3); ROW=np.sqrt(3)/2
a1=np.array([1.,0.]); a2=np.array([.5,np.sqrt(3)/2]); Binv=np.linalg.inv(np.column_stack([a1,a2]))
layer=lambda z:int(round(z/TAU))
def offset_type(xy,ref):                         # lateral registry: 0,1,2 = A,B,C
    f=Binv@(np.asarray(xy)-ref); return int(round(((f[0]+f[1])%1)*3))%3

class Island(SSMSim):
    def __init__(s,N,Nc,rule):
        super().__init__(target_nodes=N,lift_prob=0.0); s.Nc=Nc; s.rule=rule; s.count={}; s.snap=[]; s.ref=None; s.types={}
    def _add_node(s,pos):
        i=super()._add_node(pos); L=layer(pos[2]); s.count[L]=s.count.get(L,0)+1
        if s.ref is None: s.ref=np.array(pos[:2])
        s.types.setdefault(L,offset_type(pos[:2],s.ref))
        if len(s.nodes)%40==0:
            P=np.array(s.nodes); b=P[np.abs(P[:,2])<0.3]; c=b[:,:2].mean(0)
            s.snap.append((len(s.nodes),max(s.count),np.percentile(np.linalg.norm(b[:,:2]-c,axis=1),97)))
        top=max(s.count)
        if s.count[top]>=s.Nc and L==top: s._nucleate(top)
        return i
    def _nucleate(s,L):
        P=np.array(s.nodes); idx=[i for i in range(len(P)) if layer(P[i][2])==L]
        c=P[idx][:,:2].mean(0); v=min(idx,key=lambda i:np.linalg.norm(P[i][:2]-c)); pv=P[v]
        want=(s.types[L]+1)%3 if s.rule=='helix' else random.choice([(s.types[L]+1)%3,(s.types[L]+2)%3])
        # three hollows around v of the wanted registry, at distance 1/sqrt3, 120 deg apart
        best=None
        for phi0 in (np.pi/6,np.pi/2):
            pts=[pv[:2]+np.array([np.cos(phi0+k*2*np.pi/3),np.sin(phi0+k*2*np.pi/3)])/np.sqrt(3) for k in range(3)]
            if offset_type(pts[0],s.ref)==want: best=pts
        if best is None: return
        new=[]
        for q in best:
            cand=np.array([q[0],q[1],pv[2]+LIFT_HEIGHT])
            if s._is_valid(cand,None): new.append(super()._add_node(cand))
        for n in new:
            s.count[L+1]=s.count.get(L+1,0)+1; s.types.setdefault(L+1,want)
            for j in range(len(s.nodes)-1):
                if j!=n and 0.95<np.linalg.norm(s.nodes[j]-s.nodes[n])<1.05: s._add_edge(n,j)
    def _stitch_lateral(s,edge,tree):
        u,v=edge; Lu=layer(s.nodes[u][2])
        if Lu!=layer(s.nodes[v][2]): s.active_edges.discard((min(u,v),max(u,v))); return False
        p1,p2=s.nodes[u],s.nodes[v]; mid=(p1+p2)/2
        att=[t for t in s.active_triangles|s.triangles if u in t and v in t and all(layer(s.nodes[x][2])==Lu for x in t)]
        if att:
            w=[x for x in att[0] if x not in (u,v)][0]; d=mid-s.nodes[w]
        else: d=np.cross(p2-p1,[0,0,1])
        d[2]=0; d/=np.linalg.norm(d)
        for cand in (mid+d*LATERAL_HEIGHT, mid-d*LATERAL_HEIGHT):
            if s._is_valid(cand,tree):
                nid=s._add_node(cand); s._add_edge(nid,u); s._add_edge(nid,v); return True
        s.active_edges.discard((min(u,v),max(u,v))); return False

def cna(G):
    fcc=hcp=0
    for i in G.nodes:
        if G.degree(i)!=12: continue
        Ni=set(G.neighbors(i)); n1=n2=0
        for j in Ni:
            c=Ni&set(G.neighbors(j)); b=[(x,y) for x,y in itertools.combinations(c,2) if G.has_edge(x,y)]
            if len(c)==4 and len(b)==2:
                if set(b[0])&set(b[1]): n2+=1
                else: n1+=1
        fcc+=n1==12; hcp+=(n1==6 and n2==6)
    return fcc,hcp
N=int(sys.argv[1]); Nc=int(sys.argv[2]); seed=int(sys.argv[3]); rule=sys.argv[4]
random.seed(seed); np.random.seed(seed); t0=time.time()
s=Island(N,Nc,rule).run(); a=np.array(s.snap); a=a[len(a)//3:]
eta=np.polyfit(a[:,2]/ROW,a[:,1],1)[0] if np.ptp(a[:,1])>0 else 0.0
seq=''.join('ABC'[s.types[L]] for L in sorted(s.types) if s.count.get(L,0)>=3)
abc=sum(len(set(seq[i:i+3]))==3 for i in range(len(seq)-2)); aba=sum(seq[i]==seq[i+2] for i in range(len(seq)-2))
f,h=cna(s.G)
print(f"{rule:6s} Nc={Nc:4d} seed={seed}: layers {len(seq)} eta={eta:.3f} | {seq[:24]} | ABC-triples {abc} ABA-triples {aba} | CNA FCC {f} HCP {h} | {time.time()-t0:.0f}s",flush=True)
