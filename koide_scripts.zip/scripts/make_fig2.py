import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
exec(open('consistency.py').read().split("# 1. lepton spectrum")[0])     # grow(), R, SH, P_CAL, ETA_CAL
exec(open('birth_spread_3node.py').read().split("target=np.sin")[0])     # speed(p,w)
blue,red,green='#1f4e79','#b0522a','#3a7d44'
# ---------------- Fig 2: derivation
d=np.linspace(0,np.pi/3,400); P3=np.roll(np.eye(3),1,axis=0)
def amps(dd,a,b):
    W=a*np.eye(3)+b*(np.exp(1j*dd)*P3+np.exp(-1j*dd)*P3.T); return np.sort(np.linalg.eigvalsh(W))
A=np.array([amps(x,1/np.sqrt(2),.5) for x in d]); Ad=np.array([amps(x,1.0,.5) for x in d])
Kf=lambda e:(e@e)/e.sum()**2
fig,ax=plt.subplots(1,3,figsize=(14,3.9),gridspec_kw={'width_ratios':[0.8,1,1]})
from matplotlib.patches import Circle
c=ax[0]; c.set_aspect('equal'); c.axis('off'); R=np.sqrt(2)
c.add_patch(Circle((1,0),R,fill=False,color='0.4')); c.plot([-1.2,3.2],[0,0],color='0.6',lw=0.8); c.plot([0,0],[-1.7,1.7],color='0.85',lw=0.8)
for k,nm in ((1,'e'),(2,r'$\mu$'),(0,r'$\tau$')):
    th=0.2222+2*np.pi*k/3; p=np.array([1+R*np.cos(th),R*np.sin(th)])
    c.plot([1,p[0]],[0,p[1]],color='0.6',lw=0.8); c.scatter(*p,s=40,color=red,zorder=3); c.plot([p[0],p[0]],[p[1],0],ls=':',color=red); c.scatter(p[0],0,s=22,color='k',zorder=3)
    c.text(p[0],-0.3 if k!=1 else 0.17,nm,ha='center',fontsize=11)
c.text(1.05,0.1,'1',fontsize=9); c.text(1.85,1.02,r'$\sqrt{2}$',fontsize=10)
c.set_xlim(-1.3,3.3); c.set_ylim(-1.9,1.8); c.set_title(r'(a) the Koide circle: $\sqrt{m_k}\propto 1+\sqrt{2}\cos(\delta+2\pi k/3)$',fontsize=9)
ax=ax[1:]
for k,(c,ls) in enumerate((("#222222",'-'),("#7a5c99",'-'),("#8a6d00",'-'))): ax[0].plot(d,A[:,k],color=c,ls=ls,lw=1.6)
dm=0.22222205; am=amps(dm,1/np.sqrt(2),.5)
for v,nm in zip(am,('e',r'$\mu$',r'$\tau$')): ax[0].plot(dm,v,'ko',ms=5); ax[0].annotate(nm,(dm,v),xytext=(6,4),textcoords='offset points')
ax[0].axvline(dm,ls=':',color='0.5'); ax[0].axhline(0,color='0.7',lw=0.6); ax[0].axvline(np.pi/12,ls='--',color='0.6',lw=0.8); ax[0].set_xlabel(r'phase $\delta$'); ax[0].set_ylabel(r'eigen-amplitude $\propto\sqrt{m_k}$'); ax[0].set_ylim(-0.4,1.95)
ax[0].set_title(r'(b) localized family operator: $\sqrt{m_k}$ vs $\delta$',fontsize=10)
ax[1].axvspan(np.pi/12,np.pi/3,color='0.92',zorder=0); ax[1].text(0.62,0.95,'electron amplitude < 0',fontsize=8,color='0.35')
ax[1].axvline(np.pi/12,ls='--',color='0.5',lw=0.8); ax[1].text(np.pi/12-0.01,0.93,r'$\pi/12$: $m_e=0$',fontsize=8,color='0.35',ha='right')
ax[1].plot(d[d<=np.pi/12],[Kf(np.abs(a)) for a in A[d<=np.pi/12]],color=red,lw=2,label=r'localized ($\sqrt{6}:\sqrt{3}$)')
ax[1].plot(d[d>np.pi/12],[Kf(np.abs(a)) for a in A[d>np.pi/12]],color=red,ls=':',lw=1)
ax[1].plot(dm,2/3,'ko',ms=5); ax[1].annotate('measured',(dm,2/3),xytext=(-50,-22),textcoords='offset points',fontsize=8,arrowprops=dict(arrowstyle='->',lw=0.6))
ax[1].plot(d,[Kf(np.abs(a)) for a in Ad],color=blue,label=r'delocalized ($6:3$)')

ax[1].set_ylim(0.3,1.0); ax[1].set_xlabel(r'phase $\delta$'); ax[1].set_ylabel(r'$K$'); ax[1].legend(fontsize=8,loc='lower left')
ax[1].set_title(r'(c) $K=2/3$ localized ($|\delta|\leq\pi/12$), $1/2$ delocalized',fontsize=10)
plt.tight_layout(); plt.savefig('fig2_derivation.pdf'); plt.close()
print('fig2 done')