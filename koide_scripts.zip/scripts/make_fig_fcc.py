import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
matplotlib.rcParams['pdf.fonttype']=42; matplotlib.rcParams['ps.fonttype']=42   # TrueType fonts in PDF figures
from itertools import product
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
col={0:'#1f4e79',1:'#b0522a',2:'#3a7d44'}; lab='ABC'
fig=plt.figure(figsize=(13,8.6))
def depth_sorted(points,elev,azim):
    v=np.array([np.cos(np.radians(elev))*np.cos(np.radians(azim)),np.cos(np.radians(elev))*np.sin(np.radians(azim)),np.sin(np.radians(elev))])
    return sorted(points,key=lambda p: np.asarray(p[0])@v)
def cube_edges(ax,n=1,c='0.55'):
    segs=[]
    for i in range(n+1):
        for j in range(n+1):
            segs+= [[(i,j,0),(i,j,n)],[(i,0,j),(i,n,j)],[(0,i,j),(n,i,j)]]
    ax.add_collection3d(Line3DCollection(segs,colors=c,linewidths=0.7))
# FCC sites in units of the cubic cell edge a: corners + face centers
def fcc(n):
    P=[]
    for p in product(range(2*n+1),repeat=3):
        if sum(p)%2==0: P.append(np.array(p)/2)
    return P
sheet=lambda p:int(round(sum(p)))%3     # (111) sheets are the planes x+y+z = 0,1,2,... (cell units)
elev,azim=20,-22
# (a) conventional cell with two (111) sheets shaded
ax=fig.add_subplot(2,3,1,projection='3d'); ax.set_proj_type('ortho')
cube_edges(ax,1)
for k,cc in ((1,col[1]),(2,col[2])):     # planes x+y+z = k : triangles through the cube
    tri=[(k,0,0),(0,k,0),(0,0,k)] if k==1 else [(1,1,0),(1,0,1),(0,1,1)]
    ax.add_collection3d(Poly3DCollection([tri],facecolor=cc,alpha=0.22,edgecolor=cc,linewidth=1.2))
P=[(p,sheet(p)) for p in fcc(1)]
for p,t in depth_sorted(P,elev,azim): ax.scatter(*p,s=170,color=col[t],edgecolor='k',linewidth=0.5,depthshade=False)
ax.plot([0,1],[0,1],[0,1],color='k',lw=1.2,ls='--'); ax.text(1.02,1.02,1.08,'[111]',fontsize=9)
ax.view_init(elev=elev,azim=azim); ax.set_box_aspect((1,1,1)); ax.set_axis_off()
ax.set_title('(a) the cubic FCC cell: atoms at corners and\nface centers; (111) sheets cut across the body diagonal',fontsize=9.5)
# (b) 2x2x2 block colored by sheet, viewed along [1-10] so the (111) sheets are edge-on
ax=fig.add_subplot(2,3,2,projection='3d'); ax.set_proj_type('ortho')
eb,ab=0,-45
cube_edges(ax,2,c='0.85')
d=np.array([1,1,-2.])/np.sqrt(6)            # in-sheet direction perpendicular to the viewing axis
for k in range(0,7):                         # edge-on sheet x+y+z = k, clipped to the block
    c=np.array([k,k,k])/3.0; ts=np.linspace(-6,6,2401); seg=np.array([c+t*d for t in ts])
    m=np.all((seg>=-1e-9)&(seg<=2+1e-9),axis=1)
    if m.sum()>1: q=seg[m]; ax.plot([q[0,0],q[-1,0]],[q[0,1],q[-1,1]],[q[0,2],q[-1,2]],color=col[k%3],lw=7,alpha=0.18,solid_capstyle='round')
P=[(p,sheet(p)) for p in fcc(2)]
for p,t in depth_sorted(P,eb,ab): ax.scatter(*p,s=80,color=col[t],edgecolor='k',linewidth=0.35,depthshade=False)
ax.plot([0,2],[0,2],[0,2],color='k',lw=1.0,ls='--'); ax.text(2.1,2.1,2.15,'[111]',fontsize=9)
ax.view_init(elev=eb,azim=ab); ax.set_box_aspect((1,1,1)); ax.set_axis_off()
ax.set_title(r'(b) $2\times2\times2$ cells seen along $[1\bar{1}0]$: the (111)'+'\nsheets are edge-on, repeating A, B, C along [111]',fontsize=9.5)
# (c) exploded stack of four sheets
ax=fig.add_subplot(2,3,3,projection='3d'); ax.set_proj_type('ortho')
a1=np.array([1,0.]); a2=np.array([.5,np.sqrt(3)/2]); gap=1.5
for l in range(4):
    t=l%3; off=t*(a1+a2)/3; z=l*gap
    xy=[i*a1+j*a2+off for i in range(-5,6) for j in range(-5,6)]; xy=[p for p in xy if np.hypot(*p)<1.95]
    for p in xy:
        for q in xy:
            if 0.99<np.linalg.norm(p-q)<1.01 and tuple(p)<tuple(q): ax.plot([p[0],q[0]],[p[1],q[1]],[z,z],color=col[t],lw=0.8,alpha=0.55)
    X=np.array(xy); ax.scatter(X[:,0],X[:,1],z,s=60,color=col[t],edgecolor='k',linewidth=0.4,depthshade=False)
    ax.text(2.35,0,z,lab[t],color=col[t],fontsize=13,weight='bold')
ax.quiver(-2.3,-1.9,0,0,0,3*gap+0.8,color='k',arrow_length_ratio=0.08,lw=1.2); ax.text(-2.3,-1.9,3*gap+1.0,'[111]',fontsize=9,ha='center')
ax.view_init(elev=14,azim=-58); ax.set_box_aspect((1,1,1.15)); ax.set_axis_off()
ax.set_title('(c) the same lattice as a stack of triangular\nsheets A, B, C (spacing exaggerated)',fontsize=9.5)
# (d) top view of the three registries
ax=fig.add_subplot(2,3,4); ax.set_aspect('equal'); ax.axis('off')
for t,off,sz in ((0,np.zeros(2),150),(1,(a1+a2)/3,90),(2,2*(a1+a2)/3,55)):
    xy=np.array([i*a1+j*a2+off for i in range(-4,5) for j in range(-4,5)]); m=(np.abs(xy[:,0])<2.3)&(np.abs(xy[:,1])<2.0)
    ax.scatter(xy[m,0],xy[m,1],s=sz,color=col[t],edgecolor='k',linewidth=0.4,zorder=3-t,label=f'sheet {lab[t]}')
    if t==0:
        for i in range(-4,5):
            for j in range(-4,5):
                p=i*a1+j*a2
                for d in (a1,a2,a2-a1):
                    q=p+d
                    if max(abs(p[0]),abs(q[0]))<2.3 and max(abs(p[1]),abs(q[1]))<2.0: ax.plot([p[0],q[0]],[p[1],q[1]],color='0.8',lw=0.6,zorder=0)
ax.legend(loc='upper center',bbox_to_anchor=(0.5,-0.02),ncol=3,fontsize=8,frameon=False)
ax.set_title('(d) seen down [111]: B and C sit over\nthe two kinds of hollow in A',fontsize=9.5)
# (e) one site and its 12 neighbors
ax=fig.add_subplot(2,3,5,projection='3d'); ax.set_proj_type('ortho')
zp=np.array([1,1,1])/np.sqrt(3); xp=np.array([1,-1,0])/np.sqrt(2); yp=np.cross(zp,xp); Rm=np.vstack([xp,yp,zp])
NN=[np.array(p)/np.sqrt(2) for p in product((-1,0,1),repeat=3) if sum(map(abs,p))==2]
nb=[(Rm@p,int(round((Rm@p)[2]/np.sqrt(2/3)))) for p in NN]
e2,a2z=12,-75
for q,l in nb: ax.plot([0,q[0]],[0,q[1]],[0,q[2]],color='k',lw=1.4 if l==0 else 1.1,ls='-' if l==0 else '--')
ring=sorted([q for q,l in nb if l==0],key=lambda q: np.arctan2(q[1],q[0]))
for i in range(6): a_,b_=ring[i],ring[(i+1)%6]; ax.plot([a_[0],b_[0]],[a_[1],b_[1]],[a_[2],b_[2]],color='0.7',lw=0.7)
for q,l in depth_sorted(nb,e2,a2z): ax.scatter(*q,s=170,color=col[l%3],edgecolor='k',linewidth=0.4,depthshade=False)
ax.scatter(0,0,0,s=260,color=col[0],edgecolor='k',linewidth=1.2,depthshade=False)
ax.text(1.2,0,0.05,'6 in own\nsheet (A)',fontsize=8,color=col[0]); ax.text(0.2,0.1,1.05,'3 above (B)',fontsize=8,color=col[1]); ax.text(0.2,0.1,-1.2,'3 below (C)',fontsize=8,color=col[2])
ax.view_init(elev=e2,azim=a2z); ax.set_box_aspect((1,1,0.9)); ax.set_axis_off(); ax.set_xlim(-1.1,1.1); ax.set_ylim(-1.1,1.1); ax.set_zlim(-1,1)
ax.set_title('(e) one site and its 12 bonds: 6 : 3 : 3',fontsize=9.5)
ax=fig.add_subplot(2,3,6); ax.axis('off')
ax.text(0.02,0.62,'Colors: sheet type along [111]\n\n'+r'$\bf A$'+'  layer index 0 (mod 3)\n'+r'$\bf B$'+'  layer index 1 (mod 3)\n'+r'$\bf C$'+'  layer index 2 (mod 3)\n\nSheet spacing $\\sqrt{2/3}\\,L$; bond length $L$;\ncubic cell edge $\\sqrt{2}\\,L$.',fontsize=9,va='center')
plt.tight_layout(h_pad=2.0); plt.savefig('fig1_fcc.pdf'); plt.savefig('fig1_fcc.png',dpi=80); print('ok')
