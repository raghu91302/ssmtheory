import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
exec(open('consistency.py').read().split("# 1. lepton spectrum")[0])     # grow(), R, SH, P_CAL, ETA_CAL
exec(open('birth_spread_3node.py').read().split("target=np.sin")[0])     # speed(p,w)
blue,red,green='#1f4e79','#b0522a','#3a7d44'
# ---------------- Fig 2: derivation (three panels)
exec(open('make_fig2.py').read())
# ---------------- Fig 3: growth
ws=[1,2,3,5,8,12]; ew=[speed(np.exp(-3),w) for w in ws]
ps=np.array([0.02,0.035,0.0498,0.06,0.0718,0.085,0.10])
eh=[np.mean([grow(p,'helix',Lx=120,T=500,seed=s)[0] for s in (0,1)]) for p in ps]
def final(rule,seed=3):
    rng_state=None
    # rerun and keep the arrays
    Lx=120; p=0.0718 if rule=='helix' else 1/16.7
    rng=np.random.default_rng(seed); h=np.zeros((Lx,Lx),int); reg=np.zeros((Lx,Lx),int); age=np.zeros((Lx,Lx),int); w=10
    for t in range(500):
        m=h.copy(); mr=reg.copy()
        for dx,dy in SH:
            hn=R(h,dx,dy); rn=R(reg,dx,dy); b=hn>m; m=np.where(b,hn,m); mr=np.where(b,rn,mr)
        age[m>h]=0; h,reg=m,mr; age=np.maximum(age-1,0); age[rng.random(h.shape)<p]=w
        up=(age>0)&(R(age,-1,0)>0)&(R(age,0,-1)>0)&(h==R(h,-1,0))&(h==R(h,0,-1))&(reg==R(reg,-1,0))&(reg==R(reg,0,-1))
        dn=np.zeros_like(up)
        if rule=='random': dn=(R(age,-1,0)>0)&(R(age,0,-1)>0)&(R(age,-1,-1)>0)&(R(h,-1,0)==R(h,0,-1))&(R(h,-1,0)==R(h,-1,-1))
        rU=up|R(up,1,0)|R(up,0,1); rD=(R(dn,1,0)|R(dn,0,1)|R(dn,1,1))&~rU
        reg=np.where(rU,(reg+1)%3,np.where(rD,(reg+2)%3,reg)); h=h+rU+rD; age[rU|rD]=0
    return (reg-h)%3            # 0 everywhere for a single ABC helix
fig,ax=plt.subplots(1,4,figsize=(13,3.4),gridspec_kw={'width_ratios':[1,1,0.8,0.8]})
ax[0].plot(ws,ew,'o-',color=blue); ax[0].axhline(np.sin(2/9),ls=':',color=red); ax[0].text(6,0.205,r'target $0.2204$',color=red,fontsize=8)
ax[0].set_xlabel(r'lifetime $w$ of a lone lift (ticks)'); ax[0].set_ylabel(r'$\eta$ (layers per row)'); ax[0].set_title(r'(a) saturation, $p=e^{-3}$',fontsize=10)
ax[1].plot(ps,eh,'o-',color=blue); ax[1].axhline(np.sin(2/9),ls=':',color=red)
ax[1].axvline(0.0718,ls='--',color=red,lw=0.8); ax[1].axvline(np.exp(-3),ls='--',color='0.5',lw=0.8)
ax[1].text(0.073,0.14,'calibrated\n1/13.9',color=red,fontsize=8); ax[1].text(0.028,0.26,'published\n1/20',color='0.4',fontsize=8)
ax[1].set_xlabel(r'lift probability $p$ per site per tick'); ax[1].set_ylabel(r'$\eta$'); ax[1].set_title('(b) helix rule: calibration',fontsize=10)
cm=ListedColormap(['#e8e8e8','#7a5c99','#c9a227'])
for i,(rule,t) in enumerate((('helix',r'(c) helix rule, $p=1/13.9$'),('random',r'(d) random rule, $p=1/16.7$'))):
    ax[2+i].imshow(final(rule),cmap=cm,vmin=0,vmax=2,interpolation='nearest'); ax[2+i].set_xticks([]); ax[2+i].set_yticks([])
    ax[2+i].set_title(t+':\ntop surface seen from above',fontsize=9)
from matplotlib.patches import Patch
fig.legend(handles=[Patch(facecolor='#e8e8e8',edgecolor='0.6',label='(c, d) gray: correctly ABC-stacked'),Patch(color='#7a5c99',label='stacking fault'),Patch(color='#c9a227',label='stacking fault (other kind)')],
             fontsize=8,loc='lower center',bbox_to_anchor=(0.62,0.0),ncol=3,frameon=False)
ax[0].set_title(r'(a) saturation, $p=e^{-3}$ (both nucleus kinds)',fontsize=9)
plt.tight_layout(rect=[0,0.07,1,1]); plt.savefig('fig3_growth.pdf'); plt.close()
# ---------------- Fig 4: neutrinos
dm21=7.53e-5; dmNO=2.529e-3; dmIO=2.484e-3
ml=np.logspace(-4.5,-0.8,300)
sNO=ml+np.sqrt(ml**2+dm21)+np.sqrt(ml**2+dmNO); sIO=ml+np.sqrt(ml**2+dmIO)+np.sqrt(ml**2+dmIO+dm21)
fig,ax=plt.subplots(figsize=(6.2,4))
ax.loglog(ml*1e3,sNO*1e3,color=blue,label='normal ordering'); ax.loglog(ml*1e3,sIO*1e3,color=green,label='inverted ordering')
ax.axhline(64.2,ls='--',color='k',lw=0.8); ax.text(0.05,67,r'DESI DR2 + CMB ($\Lambda$CDM): $\sum m_\nu<64.2$ meV',fontsize=8)
ax.plot(0.797,59.81,'o',color=red,ms=7,label=r'this model, $K_\nu=1/2$ (NO)'); ax.plot(1e-3*0.0005*1e3+0.0316,98.92,'s',mfc='none',mec=red,ms=7,label='this model (IO), above the DESI bound')
ax.annotate(r'$m_1=0.80$ meV, $\sum=59.8$ meV',(0.797,59.81),xytext=(0.9,45),fontsize=8,arrowprops=dict(arrowstyle='->',lw=0.7))
ax.annotate(r'IO: $m_3=0$, $\sum=98.9$ meV',(0.0316,98.92),xytext=(0.06,130),fontsize=8,arrowprops=dict(arrowstyle='->',lw=0.7))
from matplotlib.ticker import ScalarFormatter, FixedLocator
ax.yaxis.set_major_locator(FixedLocator([40,60,80,100,200,400])); ax.yaxis.set_major_formatter(ScalarFormatter()); ax.yaxis.set_minor_formatter(plt.NullFormatter())
ax.set_xlabel('lightest neutrino mass (meV)'); ax.set_ylabel(r'$\sum m_\nu$ (meV)'); ax.set_xlim(0.03,150); ax.set_ylim(40,400); ax.legend(fontsize=8,loc='upper left')
plt.tight_layout(); plt.savefig('fig4_neutrino.pdf'); plt.close()
print("figures written")
