import numpy as np
from itertools import product
L=6                                           # periodic FCC box (even-sum sites), stacking along [111]
sites=[p for p in product(range(L),repeat=3) if sum(p)%2==0]; idx={p:i for i,p in enumerate(sites)}; N=len(sites)
NN=[v for v in product((-1,0,1),repeat=3) if sum(map(abs,v))==2]
H=np.zeros((N,N))
for p in sites:
    for d in NN: H[idx[p],idx[tuple((p[k]+d[k])%L for k in range(3))]]=1.0      # hopping t = 1 per bond
# sheet type along [111]: layer index = (x+y+z)/2 mod 3
typ=np.array([((sum(p)//2)%3) for p in sites])
# 1. localized lepton at a site of type A: coupling to the normalized neighbour state in each sheet
o=idx[(0,0,0)]; k0=typ[o]
print("1. localized state at a type-%s site: coupling to the normalized neighbour state in each sheet"%'ABC'[k0])
for dk,nm in ((0,'own sheet'),(1,'sheet above'),(2,'sheet below')):
    nb=[j for j in range(N) if H[o,j] and typ[j]==(k0+dk)%3]
    shell=np.zeros(N); shell[nb]=1/np.sqrt(len(nb))
    print(f"   {nm:12s}: {len(nb)} bonds, <shell|H|site> = {shell@H[:,o]:.4f}  (sqrt{len(nb)} = {np.sqrt(len(nb)):.4f})")
# 2. delocalized states: uniform over whole sheet types
print("2. delocalized states (uniform over each whole sheet type):")
U=[np.where(typ==k,1.0,0) for k in range(3)]; U=[u/np.linalg.norm(u) for u in U]
M=np.array([[U[k]@H@U[l] for l in range(3)] for k in range(3)])
print("   <sheet_k|H|sheet_l> =\n",np.round(M,4),"  -> coherent counts 6, 3, 3")
# 3. the family operators and Koide
K=lambda e:(e@e)/e.sum()**2
P=np.roll(np.eye(3),1,axis=0)
for nm,a,b in (("localized (collective coupling)",np.sqrt(6),np.sqrt(3)),("delocalized (counts)",6,3)):
    W=a*np.eye(3)+b*np.exp(1j*2/9)*P+b*np.exp(-1j*2/9)*P.T
    lam=np.sort(np.linalg.eigvalsh(W)); m=np.sort(np.linalg.eigvalsh(W@W))
    print(f"3. {nm:32s}: sqrt(m) = eigenvalues {np.round(lam,4)}; K = {K(np.abs(lam)):.6f}; masses from W^2: {np.round(m,4)}; diag(W^2) = {np.real((W@W)[0,0]):.1f}")
