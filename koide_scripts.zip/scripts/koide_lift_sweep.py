import numpy as np, random, sys, itertools, time
from ssm_sim import SSMSim

class CountSim(SSMSim):
    """Unchanged growth rules; only counts successful lifts and stitches."""
    def __init__(s,*a,**k): super().__init__(*a,**k); s.nl=0; s.ns=0
    def _lift_triangle(s,tri,tree):
        ok=super()._lift_triangle(tri,tree); s.nl+=ok; return ok
    def _stitch_lateral(s,e,tree):
        ok=super()._stitch_lateral(e,tree); s.ns+=ok; return ok

def cna(G):
    """classify degree-12 nodes: FCC (12 x 421), HCP (6 x 421 + 6 x 422), other"""
    fcc=hcp=oth=0
    for i in G.nodes:
        if G.degree(i)!=12: continue
        Ni=set(G.neighbors(i)); sig=[]
        for j in Ni:
            c=Ni & set(G.neighbors(j))
            if len(c)!=4: sig.append('x'); continue
            b=[(u,v) for u,v in itertools.combinations(c,2) if G.has_edge(u,v)]
            if len(b)!=2: sig.append('x'); continue
            sig.append('422' if set(b[0])&set(b[1]) else '421')
        n421=sig.count('421'); n422=sig.count('422')
        if n421==12: fcc+=1
        elif n421==6 and n422==6: hcp+=1
        else: oth+=1
    return fcc,hcp,oth

N=int(sys.argv[1]); p=float(sys.argv[2]); seed=int(sys.argv[3])
random.seed(seed); np.random.seed(seed)
t0=time.time(); s=CountSim(target_nodes=N,lift_prob=p).run()
st=s.full_stats(); f,h,o=cna(s.G)
tot=s.nl+s.ns
print(f"p={p:.4f} seed={seed} N={st['n']} | lift fraction of moves = {s.nl/max(tot,1):.4f} | K12 = {st['pct_k12']:.1f}% | "
      f"of K12: FCC {f}, HCP {h}, other {o} | z/xy = {st['aspect']:.3f} | {time.time()-t0:.0f}s", flush=True)
