import numpy as np, random, sys, time
from ssm_sim import SSMSim, LIFT_HEIGHT, UNIT_LENGTH
TAU=np.sqrt(2/3); ROW=np.sqrt(3)/2
class Tracked(SSMSim):
    directed=False
    def _lift_triangle(s,tri,tree):
        if not s.directed: return super()._lift_triangle(tri,tree)
        u,v,w=tri; p0,p1,p2=(s.nodes[i] for i in tri)
        c=(p0+p1+p2)/3; n=np.cross(p1-p0,p2-p0); L=np.linalg.norm(n)
        if L==0: s.active_triangles.discard(tri); return False
        n/=L
        for sg in ([1,-1] if n[2]>=0 else [-1,1]):
            cand=c+n*LIFT_HEIGHT*UNIT_LENGTH*sg
            if s._is_valid(cand,tree):
                nid=s._add_node(cand); s._add_edge(nid,u); s._add_edge(nid,v); s._add_edge(nid,w); return True
        s.active_triangles.discard(tri); return False
    def _add_node(s,pos):
        i=super()._add_node(pos)
        if len(s.nodes)%100==0:
            P=np.array(s.nodes); r=np.hypot(P[:,0],P[:,1])
            s.snap.append((len(s.nodes),np.percentile(P[:,2],97),np.percentile(-P[:,2],97),np.percentile(r,97)))
        return i
N=int(sys.argv[1]); p=float(sys.argv[2]); seed=int(sys.argv[3]); directed=sys.argv[4]=='dir'
random.seed(seed); np.random.seed(seed)
s=Tracked(target_nodes=N,lift_prob=p); s.directed=directed; s.snap=[]; t0=time.time(); s.run()
a=np.array(s.snap); a=a[len(a)//2:]                      # later half: steady front
up=np.polyfit(a[:,3],a[:,1],1)[0]; dn=np.polyfit(a[:,3],a[:,2],1)[0]   # dz/dr in length units
cv=lambda k: k*ROW/TAU                                    # convert to layers per row
print(f"{'dir' if directed else 'sym'} p={p:.2f} seed={seed}: vertical/lateral speed, layers per row: up {cv(up):.3f}, down {cv(dn):.3f} | {time.time()-t0:.0f}s",flush=True)
