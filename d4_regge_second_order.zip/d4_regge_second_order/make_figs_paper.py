import os
import numpy as np, re, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import gamma_ppn as g
plt.rcParams.update({'font.size':9,'font.family':'serif','mathtext.fontset':'cm'})
# ---------- Fig 1: linear static sector
dirs={'[100]':[1,0,0,0],'[110]':[1,1,0,0],'[111]':[1,1,1,0]}; ks=np.array([0.05,0.1,0.2,0.3,0.5,0.7,1.0])
res={}
if os.path.exists('fig1data.npy'): res=np.load('fig1data.npy',allow_pickle=True).item()
for n,v in ([] if res else dirs.items()):
    v=np.array(v,float); v/=np.linalg.norm(v); P=[];G=[]
    for t in ks:
        Phi,gm,_,_=g.solve(t*v); P.append(Phi*t*t/(-4*np.pi)); G.append(gm)
    res[n]=(np.array(P),np.array(G))
np.save('fig1data.npy',res,allow_pickle=True)
fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
mk={'[100]':'o','[110]':'s','[111]':'^'}
for n,(P,G) in res.items():
    ax[0].loglog(ks,np.abs(P-1),mk[n]+'-',ms=3.5,lw=0.8,label=n)
    gg=np.abs(G-1); m=(gg>1e-7)&(n!='[111]'); ax[1].loglog(ks[m],gg[m],mk[n]+'-',ms=3.5,lw=0.8,label=n)
for a in ax: a.loglog(ks,0.03*ks**2,'k--',lw=0.6,label=r'$\propto k^2$'); a.set_xlabel(r'$|k|$ (lattice units)')
ax[0].set_ylabel(r'$|\Phi k^2/(-4\pi G\rho)-1|$'); ax[1].set_ylabel(r'$|\gamma-1|$')
ax[0].set_title('(a) Newtonian normalization',fontsize=9); ax[1].set_title(r'(b) PPN $\gamma$',fontsize=9)
ax[0].legend(fontsize=7,frameon=False); plt.tight_layout(); plt.savefig('fig1_linear.pdf')
# ---------- Fig 2: nonlinear
txt=open('results.txt' if os.path.exists('results.txt') else 'results_reference.txt').read()
blocks=txt.split('== args: ')[1:]
def parse(b):
    bb=[float(x) for x in re.search(r'per bump beta :(.*)',b).group(1).split()]
    gg=[float(x) for x in re.search(r'per bump gamma:(.*)',b).group(1).split()]
    return np.array(bb),np.array(gg)
D={b.split('\n')[0].strip():parse(b) for b in blocks}
r0=np.arange(5.0,9.01,0.5)
# per-shell strong-form fits: output of  python3 strong_form_fit.py 0.4
strong_r=np.array([3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5]); strong_b=np.array([0.0274,0.4106,0.5447,0.6632,0.6783,0.7214,0.7369,0.7449])
fig,ax=plt.subplots(1,2,figsize=(6.8,2.7))
ax[0].plot(strong_r,strong_b,'x-',color='0.4',ms=4,lw=0.8,label='per-edge (strong) fit')
b,_=D['0.4 geo 2.0 1.0']; ax[0].plot(r0,b,'o-',ms=3.5,lw=0.8,label='weak form')
ax[0].axhline(1,color='k',lw=0.5,ls=':'); ax[0].set_xlabel(r'$r$ (lattice units)'); ax[0].set_ylabel(r'fitted $\beta$')
ax[0].set_title(r'(a) strong vs. weak form, $M=0.4$',fontsize=9); ax[0].legend(fontsize=7,frameon=False,loc='lower right'); ax[0].set_ylim(-0.05,1.1)
x=1/r0**2; A=np.stack([np.ones_like(x),x],1)
sty={'0.4 geo 2.0 1.0':('C0','o',r'$M=0.4$'),'0.2 geo 2.0 1.0':('C1','s',r'$M=0.2$'),'0.4 straight 2.0 1.0':('0.5','x','straight segments')}
for k,(c,m,l) in sty.items():
    bb,gg=D[k]; ax[1].plot(x,bb,m,color=c,ms=3.5,label=r'$\beta$, '+l)
    cf=np.linalg.lstsq(A,bb,rcond=None)[0]; xx=np.linspace(0,x.max(),20); ax[1].plot(xx,cf[0]+cf[1]*xx,'-',color=c,lw=0.7)
    if 'geo' in k:
        ax[1].plot(x,gg,m,color=c,mfc='none',ms=3.5,label=r'$\gamma$, '+l); cg=np.linalg.lstsq(A,gg,rcond=None)[0]; ax[1].plot(xx,cg[0]+cg[1]*xx,'--',color=c,lw=0.7)
ax[1].axhline(1,color='k',lw=0.5,ls=':'); ax[1].set_xlabel(r'$1/r_0^2$'); ax[1].set_ylabel('weak-form fit')
ax[1].set_title(r'(b) extrapolation $X_\infty + c/r_0^2$',fontsize=9); ax[1].legend(fontsize=6,frameon=False,loc='lower left',ncol=1)
plt.tight_layout(); plt.savefig('fig2_nonlinear.pdf')
print({k:(np.round(v[0],4)) for k,v in D.items()})
