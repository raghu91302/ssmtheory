import numpy as np, regge_static as R, geo_len as GL, sys, time
M=float(sys.argv[1]) if len(sys.argv)>1 else 0.4
rs=R.Residual(B=13,zr=4)
src=rs.src
def metric_factory(m,beta=1.,gamma=1.,dlt=1.):
    def g(X):
        r=np.sqrt(((X[...,:3]-src)**2).sum(-1)); U=m/r
        A=((1-U/2)/(1+U/2))**2 + 2*(beta-1)*U**2
        Bs=(1+U/2)**4 + 2*(gamma-1)*U + 1.5*(dlt-1)*U**2
        return np.stack([Bs,Bs,Bs,A],-1)
    def G(X):
        gd=g(X); out=np.zeros(gd.shape+(4,)); idx=np.arange(4); out[...,idx,idx]=gd; return out
    return G
def E(m,**p):
    G=metric_factory(m,**p); return rs.run_lengths(lambda P,Q: GL.geo3(P,Q,G))['E']
t=time.time()
Ep,Em=E(M),E(-M)
odd0,even0=(Ep-Em)/2,(Ep+Em)/2
h=0.2
def deriv(par):
    a,b=E(M,**{par:1+h}),E(-M,**{par:1+h})
    return ((a-b)/2-odd0)/h, ((a+b)/2-even0)/h
dg_odd,dg_even=deriv('gamma'); db_odd,db_even=deriv('beta'); dd_odd,dd_even=deriv('dlt')
print('evaluations done (%.0fs)'%(time.time()-t))
mid=rs.emid; r=np.sqrt(((mid[:,:3]-src)**2).sum(1))
sel=rs.good&(mid[:,3]>=0)&(mid[:,3]<2)
print('M=%.2f   interior edges used: %d'%(M,sel.sum()))
print(' shell      n   gamma        beta       delta(g_ij U^2 coeff /(3/2))   |odd|/|odd(gamma=0)|  |even|/|even(beta=0)|')
def fit(mask):
    # gamma from odd part
    x=dg_odd[mask]; y=-odd0[mask]; gam=1+ (x@y)/(x@x)
    X=np.stack([db_even[mask],dd_even[mask]],1); y2=-even0[mask]
    sol=np.linalg.lstsq(X,y2,rcond=None)[0]
    q1=np.linalg.norm(odd0[mask])/np.linalg.norm(odd0[mask]-dg_odd[mask])
    q2=np.linalg.norm(even0[mask])/np.linalg.norm(even0[mask]-db_even[mask])
    return gam,1+sol[0],1+sol[1],q1,q2
for lo,hi in [(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(9,10),(10,11)]:
    m=sel&(r>=lo)&(r<hi)
    if m.sum()<50: continue
    g,b,d,q1,q2=fit(m)
    print(' [%2d,%2d) %6d  %.5f   %.5f   %.5f                         %.1e              %.1e'%(lo,hi,m.sum(),g,b,d,q1,q2))
g,b,d,q1,q2=fit(sel&(r>=5)&(r<11)); print(' all r in [5,11): gamma=%.5f  beta=%.5f  delta=%.5f'%(g,b,d))
np.savez('beta_geo_M%.2f.npz'%M,r=r,sel=sel,odd0=odd0,even0=even0,dg=dg_odd,db=db_even,dd=dd_even)
