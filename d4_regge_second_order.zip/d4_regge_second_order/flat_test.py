import numpy as np, regge_static as R, geo_len as GL
rs=R.Residual(B=9,zr=3); src=rs.src
def pullback(c):
    def f(X):
        y=X[...,:3]-src; r=np.linalg.norm(y,axis=-1,keepdims=True); out=X.copy(); out[...,:3]=X[...,:3]+c*y/r**3; return out
    def G(X):
        y=X[...,:3]-src; r2=(y*y).sum(-1)[...,None,None]; r=np.sqrt(r2)
        J=np.broadcast_to(np.eye(4),X.shape[:-1]+(4,4)).copy()
        J[...,:3,:3]+=c*(np.eye(3)/r**3-3*np.einsum('...i,...j->...ij',y,y)/r**5)
        return np.einsum('...ki,...kj->...ij',J,J)
    return f,G
mid=rs.emid; r=np.linalg.norm(mid[:,:3]-src,axis=1); sel=rs.good&(r>4)&(r<8)
for c in [0.4]:
    out={}
    for sgn in (1,-1):
        f,G=pullback(sgn*c)
        out[('exact',sgn)]=rs.run_lengths(lambda P,Q: ((f(Q)-f(P))**2).sum(-1))['E']
        out[('straight',sgn)]=rs.run_lengths(lambda P,Q: GL.straight(P,Q,G))['E']
        out[('geodesic',sgn)]=rs.run_lengths(lambda P,Q: GL.geo3(P,Q,G))['E']
    for k in ('exact','straight','geodesic'):
        odd=(out[(k,1)]-out[(k,-1)])/2; even=(out[(k,1)]+out[(k,-1)])/2
        print('flat space, curved coords, %-9s sampling: |odd residual| %.2e   |even residual| %.2e'%(k,np.linalg.norm(odd[sel]),np.linalg.norm(even[sel])))
