"""Exact coefficient tensor of the O(k^2) cubic Regge vertex on the periodic D4 complex.
C[I0,I1,I2,(s,mu),(t,nu)] : coefficient of eps0_{I0} eps1_{I1} eps2_{I2} k_s^mu k_t^nu,
with I = (alpha,beta) flattened (16), s,t = mode index, k's unconstrained (constraint imposed later).
Stored as integers: value = (RAT + SQ*sqrt3) * scale, scale = -1/(8 den^2 Nv)."""
import numpy as np, time, sys
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine
t0=time.time()
D1A,D1B,D2A,D2B,dAA,dAB,d2AA,d2AB,cidx,tidx,den = np.load('emergent_exact_tensors.npy',allow_pickle=True)
den=int(den); spine = sys.argv[1] if len(sys.argv)>1 else 'axis0'; Lsz=int(sys.argv[2]) if len(sys.argv)>2 else 4
cx=PeriodicD4(L=Lsz,spine=spine); pe=PeriodicEngine(cx)
# congruence classes must be recomputed for this complex (local configs may be ordered differently)
Lp=cx.L0[pe.pair].astype(int); Lt=cx.L0[pe.tri].astype(int)
ref=PeriodicD4(L=4,spine='axis0'); rpe=PeriodicEngine(ref)
cu=np.unique(ref.L0[rpe.pair].astype(int),axis=0); tu=np.unique(ref.L0[rpe.tri].astype(int),axis=0)
lut={tuple(r):i for i,r in enumerate(cu)}; tlut={tuple(r):i for i,r in enumerate(tu)}
ci=np.array([lut[tuple(r)] for r in Lp]); ti=np.array([tlut[tuple(r)] for r in Lt])[pe.owner]
g=lambda X,idx: np.asarray(X.tolist(),dtype=np.int64)[idx]
th1=(g(D1A,ci),g(D1B,ci)); th2=(g(D2A,ci),g(D2B,ci))
a1=(g(dAA,ti),g(dAB,ti)); a2=(g(d2AA,ti),g(d2AB,ti))
TS=[4,1,0]; P=len(pe.pair); CH=2048
def scat2(M):   # (P,3,3) on triangle slots -> (P,10,10)
    out=np.zeros((P,10,10),np.int64); out[:,np.ix_(TS,TS)[0],np.ix_(TS,TS)[1]]=M; return out
def scat1(v):
    out=np.zeros((P,10),np.int64); out[:,TS]=v; return out
A2=(scat2(a2[0]),scat2(a2[1])); A1=(scat1(a1[0]),scat1(a1[1]))
ev=cx.evec[pe.pair]                                       # (P,10,4)
Dm=np.rint(np.einsum('pxa,pxb->pxab',ev,ev)).astype(np.int64).reshape(P,10,16)
M=np.rint(2*pe.mid).astype(np.int64)                      # (P,10,4)  = 2*midpoint
assert np.abs(2*pe.mid-M).max()<1e-9
key=np.concatenate([ci[:,None],ti[:,None],Dm.reshape(len(ci),-1),M.reshape(len(ci),-1)],1)
_,rep,cnt=np.unique(key,axis=0,return_index=True,return_counts=True)
print('incidences',len(ci),'-> distinct local data',len(rep),flush=True)
th1=tuple(x[rep] for x in th1); th2=tuple(x[rep] for x in th2)
A2=tuple(x[rep] for x in A2); A1=tuple(x[rep] for x in A1)
Dm=Dm[rep]; M=M[rep]; W=cnt.astype(np.int64); P=len(rep)
def slotvec(n,sl):
    D=Dm[sl]; Mm=M[sl]; n_=D.shape[0]
    if n==0: return D
    if n==1: return np.einsum('pxI,pxm->pxIm',D,Mm).reshape(n_,10,-1)
    return np.einsum('pxI,pxm,pxn->pxImn',D,Mm,Mm).reshape(n_,10,-1)
def qmul_outer(A,B):   # A=(a,b) (P,nA), B=(a,b) (P,nB) -> sum_p outer, in Q(sqrt3)
    ra=A[0].T@B[0]+3*(A[1].T@B[1]); rb=A[0].T@B[1]+A[1].T@B[0]; return ra,rb
def build(celim):
    a,b=[t for t in range(3) if t!=celim]; c=celim
    C=np.zeros((2,16,16,16,3,4,3,4),dtype=np.int64)
    for s in range(3):
        for t in range(3):
            nph=[0,0,0]; nph[s]+=1; nph[t]+=1
            for c0 in range(0,P,CH):
              sl=slice(c0,min(P,c0+CH)); nP=sl.stop-sl.start
              V=[slotvec(n,sl) for n in nph]
              # terms: (two-slot factor over modes (m1,m2), one-slot factor on m3)
              terms=[(A2,(a,c),(th1,b)),(A2,(b,c),(th1,a)),(A1,None,None)]
              for F,pr,Gd in terms:
                  if pr is not None:
                      m1,m2=pr; m3=Gd[1]
                      Fa=[np.einsum('pxy,pxI,pyJ->pIJ',F[k][sl],V[m1],V[m2]).reshape(nP,-1) for k in (0,1)]
                      Gb=[-np.einsum('pz,pzK->pK',Gd[0][k][sl],V[m3])*W[sl,None] for k in (0,1)]
                      ra,rb=qmul_outer(Fa,Gb); shp=(V[m1].shape[2],V[m2].shape[2],V[m3].shape[2]); order=(m1,m2,m3)
                  else:  # A1c * (-d2theta_ab): F on c, G on (a,b)
                      Fa=[np.einsum('px,pxI->pI',A1[k][sl],V[c]) for k in (0,1)]
                      Gb=[-np.einsum('pxy,pxI,pyJ->pIJ',th2[k][sl],V[a],V[b]).reshape(nP,-1)*W[sl,None] for k in (0,1)]
                      ra,rb=qmul_outer(Fa,Gb); shp=(V[c].shape[2],V[a].shape[2],V[b].shape[2]); order=(c,a,b)
                  for k,r in enumerate((ra,rb)):
                      r=r.reshape(shp)
                      # unpack each slot index into (I, phases...) and place into C
                      parts=[]
                      for slot,mode in enumerate(order):
                          parts.append((mode,nph[mode]))
                      X=r.reshape(*[d for mode,n in parts for d in ([16]+[4]*n)])
                      # build einsum to C[I0,I1,I2,s,mu,t,nu]
                      letters=iter('ABCDEFGHIJ'); idx=[]; I={}; ph={}
                      for mode,n in parts:
                          I[mode]=next(letters); idx.append(I[mode])
                          ph[mode]=[next(letters) for _ in range(n)]; idx+=ph[mode]
                      mu = ph[s][0]; nu = ph[t][1] if s==t else ph[t][0]
                      out=I[0]+I[1]+I[2]+mu+nu
                      C[k,:,:,:,s,:,t,:]+=np.einsum(''.join(idx)+'->'+out,X)
    return C
if __name__=="__main__":
    Cs=[build(c) for c in range(3)]
    print('slot-elimination exact agreement:',all((Cs[0]==Cs[i]).all() for i in (1,2)),
          ' max|int| =',max(np.abs(C).max() for C in Cs),'  (%.0fs)'%(time.time()-t0))
    np.save(f'lattice_C_{spine}_L{Lsz}.npy',np.array([Cs[0],den,cx.nv],dtype=object),allow_pickle=True)
