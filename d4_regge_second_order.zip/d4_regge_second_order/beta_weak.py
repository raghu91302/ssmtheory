import numpy as np, regge_static as R, geo_len as GL, sys, time
M=float(sys.argv[1]) if len(sys.argv)>1 else 0.4
samp=sys.argv[2] if len(sys.argv)>2 else 'geo'
rs=R.Residual(B=13,zr=4); src=rs.src
PA=np.array(R.PAIRS); first=np.unique(rs.einv.ravel(),return_index=True)[1]
Pa=rs.X[:,PA[:,0]].reshape(-1,4)[first]; Pb=rs.X[:,PA[:,1]].reshape(-1,4)[first]
dE=Pb-Pa; xm=(Pa+Pb)/2
def metric_factory(m,beta=1.,gamma=1.,dlt=1.):
    def G(X):
        r=np.sqrt(((X[...,:3]-src)**2).sum(-1)); U=m/r
        A=((1-U/2)/(1+U/2))**2+2*(beta-1)*U**2; Bs=(1+U/2)**4+2*(gamma-1)*U+1.5*(dlt-1)*U**2
        out=np.zeros(X.shape[:-1]+(4,4)); out[...,0,0]=out[...,1,1]=out[...,2,2]=Bs; out[...,3,3]=A; return out
    return G
def E(m,**p):
    G=metric_factory(m,**p)
    L=(lambda P,Q: GL.geo3(P,Q,G)) if samp=='geo' else (lambda P,Q: GL.straight(P,Q,G))
    return rs.run_lengths(L)['E']
import os
fn='resid_%s_M%.2f.npz'%(samp,M)
if os.path.exists(fn):
    Z=np.load(fn); Ep,Em,Egp,Egm,Ebp,Ebm,Edp,Edm=[Z[k] for k in ['Ep','Em','Egp','Egm','Ebp','Ebm','Edp','Edm']]
else:
    t=time.time(); Ep,Em=E(M),E(-M); Egp,Egm=E(M,gamma=1.2),E(-M,gamma=1.2); Ebp,Ebm=E(M,beta=1.2),E(-M,beta=1.2); Edp,Edm=E(M,dlt=1.2),E(-M,dlt=1.2)
    np.savez(fn,Ep=Ep,Em=Em,Egp=Egp,Egm=Egm,Ebp=Ebp,Ebm=Ebm,Edp=Edp,Edm=Edm); print('evals %.0fs'%(time.time()-t))
# ---- weak-form test functions: radial bump x z-window x tensor structure, one x4 period
y=xm[:,:3]-src; r=np.linalg.norm(y,axis=1); rh=y/r[:,None]
ZW=float(sys.argv[3]) if len(sys.argv)>3 else 2.0
zw=np.where(np.abs(y[:,2])<ZW,np.cos(np.pi*y[:,2]/(2*ZW))**2,0.)
per=(xm[:,3]>=0)&(xm[:,3]<2)
d3=dE[:,:3]; dr=(d3*rh).sum(1)
T_rr=dr**2; T_tt=(d3**2).sum(1)-dr**2; T_44=dE[:,3]**2
centres=np.arange(5.0,9.01,0.5); wid=float(sys.argv[4]) if len(sys.argv)>4 else 1.0
tests=[]
for c in centres:
    f=np.where(np.abs(r-c)<2.5*wid,np.cos(np.pi*(r-c)/(5*wid))**2,0.)*zw*per
    for T in (T_rr,T_tt,T_44): tests.append(f*T)
tests=np.array(tests)
supp=(np.abs(tests).sum(0)>1e-12*np.abs(tests).max())
print('weak tests: %d ; edges in support %d, of which non-interior %d'%(len(tests),supp.sum(),(supp&~rs.good).sum()))
proj=lambda e: tests@np.nan_to_num(np.where(supp,e,0.))
o0,e0=proj((Ep-Em)/2),proj((Ep+Em)/2)
def der(a,b,h=0.2): return (proj((a-b)/2)-o0)/h,(proj((a+b)/2)-e0)/h
go,ge=der(Egp,Egm); bo,be=der(Ebp,Ebm); do_,de=der(Edp,Edm)
gam=1+(go@(-o0))/(go@go)
X=np.stack([be,de],1); sol=np.linalg.lstsq(X,-e0,rcond=None)[0]
print('M=%.2f  %s sampling   weak-form fit over r in [5,10]:  gamma=%.5f   beta=%.5f   delta=%.5f'%(M,samp,gam,1+sol[0],1+sol[1]))
print('   weak residual at Schwarzschild / weak residual at beta=0 : %.3e'%(np.linalg.norm(e0)/np.linalg.norm(e0-be)))
print('   odd weak residual / (gamma=0) : %.3e'%(np.linalg.norm(o0)/np.linalg.norm(o0-go)))
# per-centre beta with delta fixed at 1 (the 3 tensor tests of one bump)
bb=[];gg=[]
for i,c in enumerate(centres):
    sl=slice(3*i,3*i+3); bb.append(1+(be[sl]@(-e0[sl]))/(be[sl]@be[sl])); gg.append(1+(go[sl]@(-o0[sl]))/(go[sl]@go[sl]))
bb=np.array(bb); gg=np.array(gg); A=np.stack([np.ones_like(centres),1/centres**2],1)
cb=np.linalg.lstsq(A,bb,rcond=None)[0]; cg=np.linalg.lstsq(A,gg,rcond=None)[0]
print('   per bump beta :',' '.join('%.4f'%x for x in bb))
print('   per bump gamma:',' '.join('%.4f'%x for x in gg))
print('   fit X(r0)=X_inf + c/r0^2 :  beta_inf=%.5f (c=%.3f, rms %.1e)   gamma_inf=%.5f (c=%.3f, rms %.1e)'%(cb[0],cb[1],np.std(bb-A@cb),cg[0],cg[1],np.std(gg-A@cg)))
