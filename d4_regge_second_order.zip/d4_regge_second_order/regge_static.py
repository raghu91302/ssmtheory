"""Exact nonlinear Regge residual of a static metric on the D4 complex (Euclidean).
E_e = sum_{h ni e} delta_h dA_h/dl_e^2   (Schlaefli: this is dS/dl_e^2 for ANY edge lengths)."""
import numpy as np, itertools as it, time
from emergent_periodic_engine import _theta
TRI=list(it.combinations(range(5),3)); PAIRS=list(it.combinations(range(5),2))
def build(B=13, zr=4, t0=-2, t1=4):
    S=[]
    # type A: integer centres, odd sum; spine = c +- e0
    g=np.array(list(it.product(range(-B,B+1),range(-B,B+1),range(-zr,zr+1),range(t0,t1+1))))
    A=g[g.sum(1)%2!=0]; E=np.eye(4,dtype=int)
    for s1,s2,s3 in it.product([1,-1],repeat=3):
        S.append(np.stack([A+E[0],A-E[0],A+s1*E[1],A+s2*E[2],A+s3*E[3]],1)*2)   # store 2x coords (integers)
    # type B: half-integer centres c = z + 1/2; vertices c + s/2 with even sum; spine = lexicographically smallest vertex & antipode
    Z=g; C2=2*Z+1                                   # 2c
    signs=np.array(list(it.product([-1,1],repeat=4)))
    V2=C2[:,None,:]+signs[None]                      # 2*(vertices) , (n,16,4)
    ok=((V2//2).sum(2)%2==0)                         # vertex in D4
    Sb=[]
    for par in (0,1):
        rows=np.where(ok[:,0]==bool(par))[0] if False else None
    # group cells by their pattern of admissible signs (two patterns)
    pat=ok.astype(int)@(1<<np.arange(16))
    for p in np.unique(pat):
        idx=np.where(pat==p)[0]; sg=signs[ok[idx[0]]]          # 8 sign vectors
        # antipodal pairs
        pairs=[]; used=set()
        for i,s in enumerate(sg):
            if i in used: continue
            j=[j for j,t in enumerate(sg) if (t==-s).all()][0]; used|={i,j}; pairs.append((s,-s))
        pairs.sort(key=lambda pr: tuple(min(tuple(pr[0]),tuple(pr[1]))))
        spine=pairs[0]; rest=pairs[1:]
        for ch in it.product([0,1],repeat=3):
            vs=[spine[0],spine[1]]+[rest[k][ch[k]] for k in range(3)]
            S.append(np.stack([C2[idx]+v for v in vs],1))
    S=np.concatenate(S)                               # (Ns,5,4) doubled coords
    return S
def gauss(n=6):
    x,w=np.polynomial.legendre.leggauss(n); return (x+1)/2, w/2
GX,GW=gauss(8)
def sqlen(P,Q,metric):
    """integrated squared length along straight coordinate segment P->Q (real coords)."""
    d=Q-P; tot=0
    for x,w in zip(GX,GW):
        X=P+x*d; gdiag=metric(X)                      # (...,4)
        tot=tot+w*np.sqrt((gdiag*d*d).sum(-1))
    return tot**2
class Residual:
    def __init__(self,B=13,zr=4,src=np.array([0.23,0.37,0.11])):
        t=time.time(); S2=build(B,zr); self.X=S2/2.0; self.src=src
        # hinge ids
        vid=lambda P: ((P[...,0]+64)*256+(P[...,1]+64))*256*256+((P[...,2]+64)*256+(P[...,3]+64))
        ids=vid(S2)                                    # (Ns,5)
        tri=np.array(TRI); self.tri=tri
        H=np.sort(ids[:,tri],axis=2)                   # (Ns,10,3)
        key=H.reshape(-1,3)
        _,self.hinv=np.unique(key,axis=0,return_inverse=True); self.hinv=self.hinv.ravel(); self.nh=self.hinv.max()+1
        E=np.sort(ids[:,np.array(PAIRS)],axis=2).reshape(-1,2)
        eu,self.einv=np.unique(E,axis=0,return_inverse=True); self.einv=self.einv.ravel().reshape(-1,10); self.ne=len(eu)
        # edge midpoints (from first occurrence)
        first=np.unique(self.einv.ravel(),return_index=True)[1]
        Pm=0.5*(self.X[:,np.array(PAIRS)[:,0]]+self.X[:,np.array(PAIRS)[:,1]]).reshape(-1,4)
        self.emid=Pm[first]
        # local ordering for theta: hinge verts then apexes
        self.loc=[list(t)+[i for i in range(5) if i not in t] for t in TRI]
        self.slotmap=[]
        for loc in self.loc:
            m=[]
            for (i,j) in PAIRS:
                a,b=loc[i],loc[j]; m.append(PAIRS.index((min(a,b),max(a,b))))
            self.slotmap.append(m)
        self.slotmap=np.array(self.slotmap)            # (10 hinges, 10 local pairs) -> simplex pair index
        # hinge edge slots (pairs among hinge verts) in Heron order a=L12,b=L02,c=L01 of local (0,1,2)
        self.hedge=np.array([[PAIRS.index((min(l[1],l[2]),max(l[1],l[2]))),PAIRS.index((min(l[0],l[2]),max(l[0],l[2]))),
                               PAIRS.index((min(l[0],l[1]),max(l[0],l[1])))] for l in self.loc])
        print('complex: %d simplices, %d hinges, %d edges (%.0fs)'%(len(S2),self.nh,self.ne,time.time()-t),flush=True)
        flat=self.run(lambda X: np.ones(X.shape[:-1]+(4,)))
        self.complete_h=np.abs(flat['delta'])<1e-9
        # edges all of whose hinges are complete
        bad=np.zeros(self.ne,bool)
        he=self.einv[:,self.hedge].reshape(-1,3); hh=np.repeat(self.hinv.reshape(-1,10),1,axis=0).reshape(-1)
        np.logical_or.at(bad,he[~self.complete_h[hh]].ravel(),True)
        self.good=~bad
        print('complete hinges %d, interior edges %d, flat residual max %.1e'%(self.complete_h.sum(),self.good.sum(),np.abs(flat['E'][self.good]).max()))
    def run(self,metric):
        Xa=self.X[:,np.array(PAIRS)[:,0]]; Xb=self.X[:,np.array(PAIRS)[:,1]]
        L2=sqlen(Xa,Xb,metric)                         # (Ns,10) squared lengths per simplex edge
        Lloc=L2[:,self.slotmap]                        # (Ns,10 hinges,10)
        th=_theta(Lloc)                                # (Ns,10)
        delta=2*np.pi-np.bincount(self.hinv,weights=th.ravel(),minlength=self.nh)
        # hinge areas derivs from any incidence (identical lengths)
        abc=np.take_along_axis(L2[:,None,:].repeat(10,1),self.hedge[None].repeat(len(L2),0),2)  # (Ns,10,3)
        a,b,c=abc[...,0],abc[...,1],abc[...,2]
        Hh=2*a*b+2*b*c+2*c*a-a*a-b*b-c*c; rH=np.sqrt(Hh)
        dA=np.stack([2*b+2*c-2*a,2*a+2*c-2*b,2*a+2*b-2*c],-1)/(8*rH[...,None])   # dA/d(a,b,c)
        # each hinge appears in several simplices: count each hinge once -> weight 1/multiplicity
        mult=np.bincount(self.hinv,minlength=self.nh)[self.hinv].reshape(-1,10)
        w=(delta[self.hinv].reshape(-1,10)/mult)[...,None]*dA
        he=self.einv[:,self.hedge]                     # (Ns,10,3) global edge ids
        E=np.bincount(he.ravel(),weights=w.ravel(),minlength=self.ne)
        return {'delta':delta,'E':E}

import geo_len
def run_lengths(self,Lfun):
    """Lfun(P,Q) -> squared length per unique edge; evaluated once per edge, then mapped to incidences."""
    PA=np.array(PAIRS)
    first=np.unique(self.einv.ravel(),return_index=True)[1]
    Pa=self.X[:,PA[:,0]].reshape(-1,4)[first]; Pb=self.X[:,PA[:,1]].reshape(-1,4)[first]
    Le=Lfun(Pa,Pb)
    return self.run_L2(Le[self.einv])
def run_L2(self,L2):
    Lloc=L2[:,self.slotmap]; th=_theta(Lloc)
    delta=2*np.pi-np.bincount(self.hinv,weights=th.ravel(),minlength=self.nh)
    abc=np.take_along_axis(L2[:,None,:].repeat(10,1),self.hedge[None].repeat(len(L2),0),2)
    a,b,c=abc[...,0],abc[...,1],abc[...,2]
    rH=np.sqrt(2*a*b+2*b*c+2*c*a-a*a-b*b-c*c)
    dA=np.stack([2*b+2*c-2*a,2*a+2*c-2*b,2*a+2*b-2*c],-1)/(8*rH[...,None])
    mult=np.bincount(self.hinv,minlength=self.nh)[self.hinv].reshape(-1,10)
    w=(delta[self.hinv].reshape(-1,10)/mult)[...,None]*dA
    E=np.bincount(self.einv[:,self.hedge].ravel(),weights=w.ravel(),minlength=self.ne)
    return {'delta':delta,'E':E}
Residual.run_lengths=run_lengths; Residual.run_L2=run_L2
