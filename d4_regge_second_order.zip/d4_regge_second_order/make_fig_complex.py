"""Figure 1: (a) coning of a cross-polytope, drawn one dimension down; (b) Bloch spectrum of the linearized
Regge operator on the fifteen edge classes of the periodic D4 complex."""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import edge_spectrum as S
plt.rcParams.update({'font.size':9,'font.family':'serif','mathtext.fontset':'cm'})
NAVY,LIGHT,RED,GREY='#1f4e79','#5b8db8','#c0392b','#8a8a8a'
fig=plt.figure(figsize=(6.8,3.0))
ax=fig.add_axes([0.0,0.02,0.40,0.86],projection='3d')
V={'n':np.array([0,0,1.]),'s':np.array([0,0,-1.]),'a':np.array([1.,0,0]),'b':np.array([0,1.,0]),'c':np.array([-1.,0,0]),'d':np.array([0,-1.,0])}
eq=['a','b','c','d']
for i,(cc,al) in enumerate([(NAVY,.34),(LIGHT,.22),(NAVY,.34),(LIGHT,.22)]):
    P=[V[k] for k in ('n','s',eq[i],eq[(i+1)%4])]
    ax.add_collection3d(Poly3DCollection([[P[0],P[1],P[2]],[P[0],P[1],P[3]],[P[0],P[2],P[3]],[P[1],P[2],P[3]]],facecolor=cc,alpha=al,edgecolor='white',linewidth=0.45))
ax.plot(*zip(V['n'],V['s']),color=RED,lw=2.4,zorder=6)
for i in range(4):
    for p in ('n','s'): ax.plot(*zip(V[eq[i]],V[p]),color=GREY,lw=0.9)
    ax.plot(*zip(V[eq[i]],V[eq[(i+1)%4]]),color=GREY,lw=0.9)
for k,v in V.items(): ax.scatter(*v,s=16,color=RED if k in 'ns' else NAVY,depthshade=False,edgecolor='white',linewidth=0.5)
ax.set_xlim(-0.8,0.8); ax.set_ylim(-0.8,0.8); ax.set_zlim(-0.8,0.8)
ax.set_box_aspect((1,1,1)); ax.view_init(elev=14,azim=35); ax.set_axis_off()
ax.text2D(0.62,0.80,'spine',color=RED,fontsize=8,transform=ax.transAxes)
ax.set_title('(a) coning from a spine (3D analog)',fontsize=9,y=0.98)
# (b) spectrum
ax2=fig.add_axes([0.53,0.16,0.45,0.72])
ks=np.geomspace(0.02,1.0,14)
dirs={'generic':np.array([1,2,3,0.5]),'static [110]':np.array([1,1,0,0.]),'axis [1000]':np.array([1,0,0,0.])}
counts={}
for name,n in dirs.items():
    n=n/np.linalg.norm(n); E=np.array([np.sort(np.abs(np.linalg.eigvalsh(S.H(t*n)))) for t in ks])
    counts[name]=[(E[-1]<1e-6).sum(),((E[-1]>1e-6)&(E[-1]<1)).sum(),(E[-1]>=1).sum()]
    if name=='generic':
        Eg=E
print('counts at |k|=1 (null, soft, stiff) by direction:',counts)
floor=Eg[:,:7].max()
ax2.fill_between(ks,1e-12,3e-9,color='0.85',lw=0)
ax2.text(0.022,4e-11,'numerical zero: 4 gauge + 3 null',fontsize=7,color='0.3')
for j in range(7,13): ax2.loglog(ks,Eg[:,j],'-',color='C0',lw=0.9,label='6 metric modes' if j==7 else None)
for j in range(13,15): ax2.loglog(ks,Eg[:,j],'-',color='C3',lw=1.2,label='2 stiff non-geometric' if j==13 else None)
ax2.loglog(ks,0.12*ks**2,'k--',lw=0.6,label=r'$\propto k^2$')
ax2.set_ylim(1e-12,30); ax2.set_xlabel(r'$|k|$ (lattice units)'); ax2.set_ylabel('|eigenvalue| per vertex')
ax2.set_title('(b) 15 edge modes per vertex',fontsize=9)
leg=ax2.legend(fontsize=7,frameon=False,loc='center right')
for l in leg.get_lines(): l.set_linewidth(2.0)
plt.savefig('fig0_complex.pdf')
