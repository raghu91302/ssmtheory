"""Gamma-Gamma cubic vertex for GENERAL symmetric eps (no traceless/transverse assumption)."""
import numpy as np
import emergent_eh_vertex as E
from emergent_eh_vertex import Multi, mul
def eh_general(ks,es):
    ks=[np.asarray(k,float) for k in ks]; es=[np.asarray(e,float) for e in es]; d4=np.eye(4)
    H=Multi(None,ks)
    for i in range(3): H.add((i,),es[i])
    def deriv(A):
        out=Multi(None,ks)
        for key,v in A.d.items():
            k=sum((ks[i] for i in key),np.zeros(4)); out.d[key]=1j*np.tensordot(k,v,axes=0)
        return out
    dH=deriv(H); mm=lambda a,b:a@b
    H2=mul(H,H,mm); H3=mul(H2,H,mm)
    ginv=Multi(None,ks); ginv.add((),d4)
    for key,v in H.d.items(): ginv.add(key,-v)
    for key,v in H2.d.items(): ginv.add(key,v)
    for key,v in H3.d.items(): ginv.add(key,-v)
    # sqrt det(1+H) = exp(x), x = t1/2 - t2/4 + t3/6
    x=Multi(None,ks)
    for key,v in H.d.items(): x.add(key,0.5*np.trace(v))
    for key,v in H2.d.items(): x.add(key,-0.25*np.trace(v))
    for key,v in H3.d.items(): x.add(key,np.trace(v)/6.0)
    sm=lambda a,b:np.array(a*b)
    x2=mul(x,x,sm); x3=mul(x2,x,sm)
    sq=Multi(None,ks); sq.add((),np.array(1.0))
    for key,v in x.d.items(): sq.add(key,v)
    for key,v in x2.d.items(): sq.add(key,0.5*v)
    for key,v in x3.d.items(): sq.add(key,v/6.0)
    T=Multi(None,ks)
    for key,v in dH.d.items():
        T.add(key,np.einsum('mbn->bmn',v)+np.einsum('nbm->bmn',v)-v)
    Gam=mul(ginv,T,lambda gi,t:0.5*np.einsum('ab,bmn->amn',gi,t))
    P1=mul(Gam,Gam,lambda A,B:np.einsum('amb,bna->mn',A,B))
    P2=mul(Gam,Gam,lambda A,B:np.einsum('amn,bab->mn',A,B))
    Pm=Multi(None,ks)
    for key,v in P1.d.items(): Pm.add(key,v)
    for key,v in P2.d.items(): Pm.add(key,-v)
    GP=mul(ginv,Pm,lambda gi,p:np.array(np.einsum('mn,mn->',gi,p)))
    L=mul(sq,GP,lambda s,g:np.array(s*g))
    v=L.get((0,1,2)); return 0.0 if v is None else complex(v).real
if __name__=="__main__":
    import time
    from emergent_star import TT
    rng=np.random.default_rng(1)
    k1=np.array([1,1,0,0]); k2=np.array([0,1,1,0]); k3=-k1-k2
    es=[TT(k).astype(float) for k in (k1,k2,k3)]
    t=time.time(); a=E.eh_cubic_vertex([k1,k2,k3],es); b=eh_general([k1,k2,k3],es)
    print('traceless check',a,b,'time',time.time()-t)
