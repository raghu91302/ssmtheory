import numpy as np, sys
sys.argv=['x']
exec(open('lattice_tensor.py').read().split("if __name__")[0])
R=np.zeros((3,4,2,4),np.int64)
for m in range(4):
    R[0,m,0,m]=1; R[1,m,1,m]=1; R[2,m,0,m]=-1; R[2,m,1,m]=-1
def constrain(C):   # -> (2,16,16,16,2,4,2,4) symmetrized over the two k slots
    X=np.einsum('rIJKsmtn,smau,tnbv->rIJKaubv',C,R,R)
    return X+X.transpose(0,1,2,3,6,7,4,5)
import pickle
res={}
for c in range(3):
    res[c]=constrain(build(c)); print('elim',c,'done',flush=True)
pickle.dump(res,open('lt_axis0_L4.pkl','wb'))
print('slot symmetry after k-conservation:',[(res[0]==res[c]).all() for c in (1,2)])
print('sqrt3 component zero:',[(res[c][1]==0).all() for c in range(3)])
