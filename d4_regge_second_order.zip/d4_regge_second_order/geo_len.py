"""Geodesic squared length between P and Q for a metric field G(X)->(...,4,4):
minimise the energy E(c)=int_0^1 g(x)(xdot,xdot) ds over paths x=P+s d+s(1-s)c (Newton, FD derivatives).
For a slowly varying metric the geodesic is a parabola to leading order, so this captures the O(Gamma^2) correction."""
import numpy as np
x_,w_=np.polynomial.legendre.leggauss(8); GX=(x_+1)/2; GW=w_/2
def energy(P,d,c,G):
    E=0
    for s,w in zip(GX,GW):
        X=P+s*d+s*(1-s)*c; v=d+(1-2*s)*c
        E=E+w*np.einsum('...i,...ij,...j->...',v,G(X),v)
    return E
def straight(P,Q,G):
    d=Q-P; L=0
    for s,w in zip(GX,GW):
        L=L+w*np.sqrt(np.einsum('...i,...ij,...j->...',d,G(P+s*d),d))
    return L**2
def geodesic(P,Q,G,h=1e-3,iters=2):
    d=Q-P; c=np.zeros_like(P); I=np.eye(4)
    for _ in range(iters):
        E0=energy(P,d,c,G)
        g=np.zeros(P.shape); H=np.zeros(P.shape+(4,))
        Ep=[energy(P,d,c+h*I[i],G) for i in range(4)]; Em=[energy(P,d,c-h*I[i],G) for i in range(4)]
        for i in range(4):
            g[...,i]=(Ep[i]-Em[i])/(2*h); H[...,i,i]=(Ep[i]-2*E0+Em[i])/h**2
            for j in range(i+1,4):
                Epp=energy(P,d,c+h*(I[i]+I[j]),G); Emm=energy(P,d,c-h*(I[i]+I[j]),G)
                H[...,i,j]=H[...,j,i]=((Epp-2*E0+Emm)/h**2-H[...,i,i]-H[...,j,j])/2
        c=c-np.linalg.solve(H,g[...,None])[...,0]
    return energy(P,d,c,G)

def christoffel_lower(X,G,h=1e-4):
    """Gamma_{k,ab} = 1/2 (d_a g_kb + d_b g_ka - d_k g_ab) at X via central differences."""
    dG=np.stack([(G(X+h*np.eye(4)[m])-G(X-h*np.eye(4)[m]))/(2*h) for m in range(4)],-3)  # (...,m,a,b) = d_m g_ab
    return 0.5*(np.einsum('...akb->...kab',dG)+np.einsum('...bka->...kab',dG)-dG)
def geo2(P,Q,G):
    """second-order squared geodesic length: affine energy of straight segment minus Gamma^2 term."""
    d=Q-P; E0=0
    for s,w in zip(GX,GW): E0=E0+w*np.einsum('...i,...ij,...j->...',d,G(P+s*d),d)
    Xm=0.5*(P+Q); Gl=christoffel_lower(Xm,G); gi=np.linalg.inv(G(Xm))
    F=np.einsum('...kab,...a,...b->...k',Gl,d,d)
    return E0-np.einsum('...k,...kl,...l->...',F,gi,F)/24.0

KER=np.minimum.outer(GX,GX)*(1-np.maximum.outer(GX,GX))
def geo3(P,Q,G):
    """squared geodesic length to second order in the metric perturbation:
    E0 - (1/4) int int F(s) g^-1 K(s,s') F(s'),  F_k = -2 Gamma_{k,ab} d^a d^b along the straight segment."""
    d=Q-P; E0=0; Fs=[]
    for s,w in zip(GX,GW):
        X=P+s*d; E0=E0+w*np.einsum('...i,...ij,...j->...',d,G(X),d)
        Fs.append(-2*np.einsum('...kab,...a,...b->...k',christoffel_lower(X,G),d,d))
    gi=np.linalg.inv(G(0.5*(P+Q)))
    corr=0
    for i in range(len(GX)):
        for j in range(len(GX)):
            corr=corr+GW[i]*GW[j]*KER[i,j]*np.einsum('...k,...kl,...l->...',Fs[i],gi,Fs[j])
    return E0-0.25*corr
