"""PPN gamma from the linearized D4 Regge equations with a static mass source, on the periodic complex.
Euclidean conventions: S = -(1/8piG) sum_h A_h delta_h  (Regge sum = (1/2) int sqrt(g) R)  +  S_matter,
S_matter = m int sqrt(g_44) dtau -> coupling (1/2) rho h_44.   GR: h_44 = 2Phi, h_ij = -2 gamma Phi delta_ij,
nabla^2 Phi = 4 pi G rho  ->  Phi = -4 pi G rho / k^2,  gamma = 1."""
import numpy as np, aniso
Nbas=[]
for a in range(4):
    for b in range(a,4):
        E=np.zeros((4,4)); E[a,b]=E[b,a]=1.0 if a==b else 1/np.sqrt(2); Nbas.append(E)
Nbas=np.array(Nbas)                                   # Frobenius-orthonormal basis of Sym(4)
VOL=2.0                                               # D4 covolume per vertex
def Mmat(k):
    Q=lambda e: aniso.S_regge2(e,k)                   # per-vertex quadratic form (Re part)
    q=np.array([Q(E) for E in Nbas]); M=np.diag(q)
    for i in range(10):
        for j in range(i+1,10):
            M[i,j]=M[j,i]=(Q(Nbas[i]+Nbas[j])-q[i]-q[j])/2
    return M                                          # S2(h) = c^T M c,  h = sum c_i N_i
def solve(k,G=1.0,rho=1.0):
    M=Mmat(k)
    # per unit volume: S = -(1/(8 pi G VOL)) c^T M c + (1/2) rho h_44 ;  h_44 = c_44 (index of E_33)
    i44=[i for i,E in enumerate(Nbas) if E[3,3]==1][0]
    J=np.zeros(10); J[i44]=0.5*rho
    H=-(1/(8*np.pi*G*VOL))*M                          # action = (1/2) c^T M c  ->  dS/dc = H c + J
    # exact gauge directions k xi + xi k (lattice vertex translations under integrated sampling)
    Gv=np.array([[np.einsum('ab,ab',np.outer(k,x)+np.outer(x,k),E) for E in Nbas] for x in np.eye(4)])
    Qg,_=np.linalg.qr(Gv.T); Qg=Qg[:,np.linalg.norm(Gv,axis=1)>1e-12] if False else Qg[:,:np.linalg.matrix_rank(Gv)]
    Pp=np.eye(10)-Qg@Qg.T                             # projector off gauge
    Hp=Pp@H@Pp; ev_=np.linalg.eigh(Hp); keep=np.abs(ev_[0])>1e-6*np.abs(ev_[0]).max()
    Hinv=(ev_[1][:,keep]/ev_[0][keep])@ev_[1][:,keep].T
    c=-Hinv@(Pp@J)
    gauge_leak=np.linalg.norm(Gv@J)
    h=np.einsum('i,iab->ab',c,Nbas)
    ks=k[:3]; kh=ks/np.linalg.norm(ks); P=np.eye(3)-np.outer(kh,kh)
    Phi=h[3,3]/2; gamma=-np.einsum('ij,ij',P,h[:3,:3])/(2*h[3,3])
    ev=np.linalg.eigvalsh(M); ev=(ev,gauge_leak)
    # restricted conformal ansatz (static paper): h = 2 phi I
    E=2*np.eye(4); qc=aniso.S_regge2(E,k)
    phi_conf=-(0.5*rho*2)/(-(1/(8*np.pi*G*VOL))*qc)   # dS/dphi = -(2 qc/(8piG VOL)) phi + (1/2) rho*2 = 0
    return Phi, gamma, ev, phi_conf
if __name__=="__main__":
    for name,v in {'[100]':[1,0,0,0],'[110]':[1,1,0,0],'[111]':[1,1,1,0]}.items():
        v=np.array(v,float); v/=np.linalg.norm(v)
        for t in [0.05,0.2,0.5,1.0]:
            k=t*v; Phi,g,ev,pc=solve(k)
            print('%s |k|=%.2f  gamma=%.6f   Phi*k^2/(-4piG rho)=%.6f   source.gauge=%.0e   conformal-ansatz phi / Phi = %+.3f'
                  %(name,t,g,Phi*t*t/(-4*np.pi),ev[1],pc/Phi))
