# Periodic Freudenthal (Kuhn) triangulation of Z^4 -- the lattice Rocek-Williams used.
# EPJ Plus Table 1 claims Z4 has "no flat background" (max|deficit| = 3.8). Check it.
import numpy as np, itertools, collections
L=3
E=np.eye(4,dtype=int)
hinge_angle=collections.defaultdict(float)
def key(pts): return frozenset(tuple(p%L) for p in pts)
def dihedral(h,a,b):
    p0=h[0]; B=np.array([h[1]-p0,h[2]-p0],float).T
    P=np.eye(4)-B@np.linalg.pinv(B)
    u=P@(a-p0); v=P@(b-p0)
    return np.arccos(np.clip(u@v/np.linalg.norm(u)/np.linalg.norm(v),-1,1))
nsimp=0
for c in itertools.product(range(L),repeat=4):
    c=np.array(c)
    for perm in itertools.permutations(range(4)):
        V=[c.copy()]
        for i in perm: V.append(V[-1]+E[i])
        nsimp+=1
        for hidx in itertools.combinations(range(5),3):
            rest=[i for i in range(5) if i not in hidx]
            h=[V[i] for i in hidx]
            hinge_angle[key(h)]+=dihedral(h,V[rest[0]],V[rest[1]])
dev=np.array([2*np.pi-s for s in hinge_angle.values()])
print("simplices",nsimp,"hinges",len(hinge_angle),"max|deficit|",np.abs(dev).max())
