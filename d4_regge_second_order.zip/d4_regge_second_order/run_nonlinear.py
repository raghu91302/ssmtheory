"""Runs the Sec. 5 weak-form fits quoted in the paper and writes results.txt (~2 min per new mass/sampling;
residuals are cached in resid_*.npz, so window variations are fast)."""
import subprocess, sys
runs=["0.4 geo 2.0 1.0","0.4 geo 1.5 1.0","0.2 geo 2.0 1.0","0.2 geo 1.5 1.0","0.4 straight 2.0 1.0"]
with open('results.txt','w') as f:
    for a in runs:
        out=subprocess.run([sys.executable,'-u','beta_weak.py']+a.split(),capture_output=True,text=True).stdout
        f.write('== args: '+a+'\n'+''.join(l+'\n' for l in out.splitlines() if not l.startswith(('complex','complete'))))
        print('done',a,flush=True)
    out=subprocess.run([sys.executable,'-u','flat_test.py'],capture_output=True,text=True).stdout
    f.write(''.join(l+'\n' for l in out.splitlines() if 'sampling' in l))
