import numpy as np
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine
cx=PeriodicD4(L=4,spine='axis0'); pe=PeriodicEngine(cx).build_derivs()
TS=[4,1,0]; ED=pe.evec[pe.pair]
def samp(k):
    kd=np.einsum('pqi,i->pq',ED,k)/2
    return np.exp(1j*np.einsum('pqi,i->pq',pe.mid,k))*np.sinc(kd/np.pi)
def lin(eps,k):
    p=np.einsum('pqi,ij,pqj->pq',ED,eps,ED)*samp(k)
    ddel=np.zeros(cx.nh,complex); np.add.at(ddel,pe.owner,-(pe.dth*p).sum(1))
    # area variation: dA on the 3 triangle slots; each hinge counted once (first incidence)
    first=np.unique(pe.owner,return_index=True)[1]
    dA=np.zeros(cx.nh,complex); dA[pe.owner[first]]=(pe.dA[pe.owner[first]]*p[first][:,TS]).sum(1)
    return ddel,dA
def S_eta(eps,k):
    d,_=lin(eps,k); return float((pe.A*np.abs(d)**2).sum())/cx.nv
def S_regge2(eps,k):   # Schlaefli-reduced second variation: sum_h dA * ddelta (real part)
    d,a=lin(eps,k); return float(np.real(np.conj(a)*d).sum())/cx.nv
def coef(f,eps,n,power,t=0.1):
    g=lambda s:f(eps,s*n)/s**power
    return (4*g(t/2)-g(t))/3
if __name__=='__main__':
    rng=np.random.default_rng(3)
    def randrot():
        Q,_=np.linalg.qr(rng.normal(size=(4,4))); return Q
    print('stiffness term, k^4 coefficient:')
    for trial in range(3):
        X=rng.normal(size=(4,4)); e=X+X.T; n=rng.normal(size=4); n/=np.linalg.norm(n)
        base=coef(S_eta,e,n,4)
        P=np.eye(4)[rng.permutation(4)]                      # coordinate permutation: in Aut(D4)
        lat=coef(S_eta,P@e@P.T,P@n,4)
        rots=[coef(S_eta,Q@e@Q.T,Q@n,4) for Q in [randrot() for _ in range(4)]]
        print('  base %.5f | lattice-symmetry image %.5f | random O(4) images %s'%(base,lat,' '.join('%.5f'%r for r in rots)))
    print('Regge quadratic form, k^2 coefficient (should be isotropic = Fierz-Pauli):')
    for trial in range(2):
        X=rng.normal(size=(4,4)); e=X+X.T; n=rng.normal(size=4); n/=np.linalg.norm(n)
        base=coef(S_regge2,e,n,2); rots=[coef(S_regge2,Q@e@Q.T,Q@n,2) for Q in [randrot() for _ in range(3)]]
        print('  base %.6f | random O(4) images %s'%(base,' '.join('%.6f'%r for r in rots)))
    