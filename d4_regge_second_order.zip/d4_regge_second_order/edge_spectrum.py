"""Bloch spectrum of the linearized Regge operator on the periodic D4 complex, one mode per edge class.
Expected: 4 gauge zero modes, 6 metric modes ~k^2, 5 non-geometric modes gapped at k=0."""
import numpy as np
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine
cx=PeriodicD4(L=4,spine='axis0'); pe=PeriodicEngine(cx).build_derivs()
ev=np.rint(cx.evec).astype(int)
def canon(d):
    d=tuple(d); nd=tuple(-x for x in d); return max(d,nd)
keys=[canon(d) for d in ev]; ukeys=sorted(set(keys)); cls=np.array([ukeys.index(k) for k in keys])
NC=len(ukeys); print('edge classes:',NC,' (edges %d, vertices %d)'%(len(ev),cx.nv))
TS=[4,1,0]; first=np.unique(pe.owner,return_index=True)[1]
Pcls=cls[pe.pair]                                   # (P,10)
def H(k):
    ph=np.exp(1j*np.einsum('pqi,i->pq',pe.mid,k))
    dD=np.zeros((cx.nh,NC),complex); dA=np.zeros((cx.nh,NC),complex)
    for a in range(NC):
        ind=(Pcls==a)*ph
        np.add.at(dD[:,a],pe.owner,-(pe.dth*ind).sum(1))
        dA[pe.owner[first],a]=(pe.dA[pe.owner[first]]*ind[first][:,TS]).sum(1)
    M=np.conj(dA).T@dD/cx.nv
    return (M+M.conj().T)/2
if __name__=="__main__":
    n=np.array([1,2,3,0.5]); n/=np.linalg.norm(n)       # generic direction
    for t in [0.8,0.4,0.2,0.1,0.05]:
        w=np.linalg.eigvalsh(H(t*n)); a=np.sort(np.abs(w))
        print('|k|=%.2f  |eig| sorted:'%t,' '.join('%.1e'%x for x in a))
