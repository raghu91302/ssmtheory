import numpy as np, edge_spectrum as S, regge_static as R
ukeys=[tuple(k) for k in S.ukeys]; NC=S.NC; U=np.array(ukeys)
Eb=[]
for m in range(4):
    for n in range(m,4):
        E=np.zeros((4,4)); E[m,n]=E[n,m]=1; Eb.append(E)
Mb=np.array([[k@E@k for k in U] for E in Eb]); Qm=np.linalg.qr(Mb.T)[0][:,:10]; Pm=Qm@Qm.T
# H at small k: null space and stiff non-geometric space (real parts at k->0)
n=np.array([1,2,3,0.5]); n/=np.linalg.norm(n)
w,V=np.linalg.eigh(S.H(0.02*n)); V=V.real if np.abs(V.imag).max()<1e-6 else V
order=np.argsort(np.abs(w)); w=w[order]; V=V[:,order]
null=V[:,:7]; metric_k2=V[:,7:13]; stiff=V[:,13:]

nm=lambda X: np.linalg.norm((np.eye(NC)-Pm)@X,axis=0)**2
print('non-metric weight: null modes',np.round(nm(null),3),' k^2 modes',np.round(nm(metric_k2),3),' stiff',np.round(nm(stiff),3))
# subspaces in the 15-dim class basis
N_ng=np.linalg.svd((np.eye(NC)-Pm)@null)[0][:,:3]          # non-geometric null (action-flat) directions
G_ng=np.linalg.qr(np.real(stiff))[0]                       # stiff non-geometric
# ---- classify the per-edge even residual of sampled Schwarzschild (geodesic, M=0.4) on the slab complex
rs=R.Residual(B=13,zr=4)
PA=np.array(R.PAIRS); first=np.unique(rs.einv.ravel(),return_index=True)[1]
Pa=rs.X[:,PA[:,0]].reshape(-1,4)[first]; Pb=rs.X[:,PA[:,1]].reshape(-1,4)[first]
d=np.rint(Pb-Pa).astype(int); flip=np.array([tuple(x)<tuple(-x) for x in d])
d[flip]*=-1; base=np.where(flip[:,None],Pb,Pa)             # b = base + d with d canonical
cls=np.array([ukeys.index(tuple(x)) if tuple(x) in ukeys else -1 for x in d])
print('slab edges with class outside the periodic set:',(cls<0).sum())
Z=np.load('resid_geo_M0.40.npz'); even=(Z['Ep']+Z['Em'])/2; beta=(Z['Ebp']+Z['Ebm'])/2-even
r=np.linalg.norm((base+d/2)[:,:3]-rs.src,axis=1)
vk={}
for i in np.where(rs.good&(cls>=0))[0]:
    vk.setdefault(tuple(np.rint(base[i]).astype(int)),{})[cls[i]]=i
rows=[];rowsb=[];rr=[]
for v,dct in vk.items():
    if len(dct)==NC:
        idx=[dct[c] for c in range(NC)]; rows.append(even[idx]); rowsb.append(beta[idx]); rr.append(np.linalg.norm(np.array(v)[:3]-rs.src))
X=np.array(rows); Xb=np.array(rowsb); rr=np.array(rr)
print('vertices with all 15 incident classes interior:',len(X))
for lo,hi in [(4,6),(6,8),(8,10)]:
    m=(rr>=lo)&(rr<hi); A=X[m]; B=Xb[m]
    f=lambda Y,Q: (np.linalg.norm(Y@Q)**2)/np.linalg.norm(Y)**2
    print(' r in [%d,%d): residual at Schwarzschild -> metric %.3f  action-flat non-geom %.3f  stiff non-geom %.3f'%(lo,hi,f(A,Qm),f(A,N_ng),f(A,G_ng)),
          '| beta-signal -> metric %.3f flat %.3f stiff %.3f'%(f(B,Qm),f(B,N_ng),f(B,G_ng)))
