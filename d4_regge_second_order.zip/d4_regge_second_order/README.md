# Regge calculus on the D4 lattice through second order — reproducibility archive

Self-contained. Python 3 with numpy, scipy, sympy, matplotlib. Run everything from this directory.

## Complex and exact tensors
- `emergent_periodic_d4.py`   closed periodic D4 complex (16-cell tiling, coned, selectable spine)
- `emergent_periodic_engine.py`  Regge variations, dihedral angles, plane-wave modes
- `emergent_exact_tensors.py`  exact derivative tensors over Q(sqrt3); output `emergent_exact_tensors.npy`
  is included (rebuild: `python3 emergent_exact_tensors.py`, ~40 s)
- `emergent_eh_vertex.py`, `emergent_star.py`  continuum Gamma-Gamma vertex; TT polarizations and test kinematics

## Section 3 — exact cubic identity
    python3 lt_constrain.py          # exact coefficient tensor, 3 slot eliminations (~2 min) -> lt_axis0_L4.pkl
    python3 compare.py               # all 64,000 coefficients vs Einstein-Hilbert (eh_general.py), exact over Q
    python3 check_variant.py axis1 4 # likewise axis2, axis3, random; and  axis0 6  for L=6
(`lattice_tensor.py` holds the tensor builder.)

## Section 4 — linear static field
    python3 gamma_ppn.py             # Newtonian normalization, gamma, lattice corrections, conformal-ansatz ratio
(`aniso.py` provides the lattice quadratic form with integrated sampling.)

## Section 5 — nonlinear static field
    python3 flat_test.py             # validation of geodesic lengths (flat space, curved coordinates)
    python3 strong_form_fit.py 0.4   # per-edge (strong-form) fits by radial shell (Fig. 2a)
    python3 run_nonlinear.py         # weak-form fits for all settings -> results.txt (Table 3, Fig. 2b)
(`regge_static.py` builds the slab complex and exact nonlinear residual; `geo_len.py` the second-order geodesic
lengths; `beta_weak.py` the weak-form fit, arguments: M sampling z-window bump-width.)
`results_reference.txt` is the output quoted in the paper.

## Footnote 1 — Z^4 is flat
    python3 z4flat.py                # periodic Freudenthal triangulation of Z^4: max hinge deficit ~1e-15

## Figures
    python3 make_figs_paper.py       # fig1_linear.pdf, fig2_nonlinear.pdf

## Edge modes (Fig. 1b, Sec. 5.3)
    python3 edge_spectrum.py         # Bloch spectrum on the 15 edge classes: 7 null, 6 metric ~k^2, 2 stiff
    python3 edge_modes.py            # decomposition of the per-edge residual (needs resid_geo_M0.40.npz from
                                     # python3 beta_weak.py 0.4 geo 2.0 1.0)
    python3 make_fig_complex.py      # fig0_complex.pdf
