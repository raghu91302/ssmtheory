import numpy as np, sys, pickle, time
spine,Lsz=sys.argv[1],int(sys.argv[2])
sys.argv=['x',spine,str(Lsz)]
t=time.time()
exec(open('lattice_tensor.py').read().split("if __name__")[0])
R=np.zeros((3,4,2,4),np.int64)
for m in range(4): R[0,m,0,m]=1; R[1,m,1,m]=1; R[2,m,0,m]=-1; R[2,m,1,m]=-1
X=np.einsum('rIJKsmtn,smau,tnbv->rIJKaubv',build(0),R,R); X=X+X.transpose(0,1,2,3,6,7,4,5)
ref=pickle.load(open('lt_axis0_L4.pkl','rb'))[0]
nv=cx.nv
# compare per-vertex: X/nv vs ref/128, exactly: X*128 == ref*nv
print(spine,'L=%d'%Lsz,'Nv=%d'%nv,'identical per-vertex tensor:',bool((X*128==ref*nv).all()),
      'sqrt3 zero:',bool((X[1]==0).all()),'(%.0fs)'%(time.time()-t),flush=True)
