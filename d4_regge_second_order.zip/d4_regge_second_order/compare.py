import numpy as np, pickle, itertools as it
from fractions import Fraction as Fr
from eh_general import eh_general
from emergent_star import sample_configs, TT
res=pickle.load(open('lt_axis0_L4.pkl','rb')); C=res[0][0]      # rational part, (16,16,16,2,4,2,4)
D1A,D1B,D2A,D2B,dAA,dAB,d2AA,d2AB,cidx,tidx,den=np.load('emergent_exact_tensors.npy',allow_pickle=True)
den=int(den); Nv=128
scale=Fr(-1,8*den*den*Nv)/2            # /2: C holds X+X^T
# symmetric basis
Eb=[]
for m in range(4):
    for n in range(m,4):
        E=np.zeros((4,4),np.int64); E[m,n]=1; E[n,m]=1; Eb.append(E.reshape(16))
Eb=np.array(Eb)                                           # (10,16)
Lnum=np.einsum('iI,jJ,kK,IJKaubv->ijkaubv',Eb,Eb,Eb,C.astype(object)).reshape(10,10,10,8,8)
def lat_val(e1,e2,e3,k1,k2):
    kk=np.concatenate([k1,k2]).astype(object)
    v=np.einsum('I,J,K,IJKaubv,au,bv->',e1.reshape(16).astype(object),e2.reshape(16).astype(object),
                e3.reshape(16).astype(object),C.astype(object),kk.reshape(2,4),kk.reshape(2,4))
    return Fr(int(v))*scale
# 1) sanity vs paper's exact values on its configurations
cfgs=sample_configs()
for i in (0,2,6):
    ks=[np.array(x) for x in cfgs[i]]; es=[TT(k).astype(np.int64) for k in ks]
    print('cfg',i,'lattice poly =',lat_val(*es,ks[0],ks[1]),'  EH =',eh_general(ks,[e.astype(float) for e in es]))
# 2) full coefficient comparison over the complete monomial basis
Lat=np.vectorize(lambda x: Fr(int(x))*scale,otypes=[object])(Lnum)
EHc=np.zeros((10,10,10,8,8))
basis8=np.eye(8)
for i,j,k in it.product(range(10),repeat=3):
    es=[Eb[i].reshape(4,4).astype(float),Eb[j].reshape(4,4).astype(float),Eb[k].reshape(4,4).astype(float)]
    f=lambda kv: eh_general([kv[:4],kv[4:],-kv[:4]-kv[4:]],es)
    diag=[f(basis8[a]) for a in range(8)]
    for a in range(8):
        EHc[i,j,k,a,a]=diag[a]
        for b in range(a+1,8):
            q=(f(basis8[a]+basis8[b])-diag[a]-diag[b])/2; EHc[i,j,k,a,b]=q; EHc[i,j,k,b,a]=q
LatF=Lat.astype(float); LatS=(LatF+LatF.transpose(0,1,2,4,3))/2
diff=np.abs(LatS-EHc).max()
print('coefficients compared:',LatS.size,' nonzero(EH):',int((np.abs(EHc)>1e-12).sum()),
      ' max|lattice-EH| =',diff,'  max|EH| =',np.abs(EHc).max())
# exactness: EH coefficients are small rationals; check lattice equals EH rounded to 1/64 exactly
EHr=np.vectorize(lambda x: Fr(round(x*64),64),otypes=[object])(EHc)
LatSym=np.vectorize(lambda a,b:(a+b)/2,otypes=[object])(Lat,Lat.transpose(0,1,2,4,3))
print('exact rational equality on all coefficients:',bool((LatSym==EHr).all()),
      '| EH on 1/64 grid:',np.abs(EHc*64-np.round(EHc*64)).max()<1e-9)
