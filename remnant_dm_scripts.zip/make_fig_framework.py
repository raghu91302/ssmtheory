#!/usr/bin/env python3
"""Framework figure: (a) FCC cell and its two voids, (b) baryon, (c) octahedral occupant,
(d) a hop between tetrahedral voids of opposite orientation across a shared edge."""
import itertools, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ink, ink2, grey = "#191919", "#666666", "#9a9993"
blue, orange, green, red = "#257de0", "#f47230", "#008a17", "#ec4647"
corners = [np.array(c, float) for c in itertools.product((0, 1), repeat=3)]
faces = [np.array(p) for p in ([.5,.5,0],[.5,.5,1],[.5,0,.5],[.5,1,.5],[0,.5,.5],[1,.5,.5])]
tet_v = [np.array(v) for v in ([0,0,0],[.5,.5,0],[.5,0,.5],[0,.5,.5])]; tet_c = sum(tet_v)/4
oct_c = np.array([.5,.5,.5])
def setup(ax, title):
    ax.set_proj_type("ortho"); ax.set_box_aspect((1,1,1)); ax.view_init(elev=18, azim=-58)
    ax.set_axis_off(); ax.set_title(title, fontsize=11, color=ink, pad=0)
def seg(ax, a, b, **k): ax.plot(*zip(a, b), **k)
fig = plt.figure(figsize=(11, 3.2))
# (a)
ax = fig.add_subplot(1, 4, 1, projection="3d"); setup(ax, "(a)")
for a, b in itertools.combinations(corners, 2):
    if np.isclose(np.linalg.norm(a-b), 1): seg(ax, a, b, color=grey, lw=0.6, alpha=0.6)
for a, b in itertools.combinations(tet_v, 2): seg(ax, a, b, color=orange, lw=1.8)
for a, b in itertools.combinations(faces, 2):
    if np.isclose(np.linalg.norm(a-b), np.sqrt(0.5)): seg(ax, a, b, color=blue, lw=1.4)
ax.scatter(*np.array(corners+faces).T, s=30, color=ink2, depthshade=False)
ax.scatter(*tet_c, s=60, color=orange, marker="*", depthshade=False)
ax.scatter(*oct_c, s=60, color=blue, marker="*", depthshade=False)
ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_zlim(0,1)
# (b) baryon
ax = fig.add_subplot(1, 4, 2, projection="3d"); setup(ax, "(b)")
for a, b in itertools.combinations(tet_v, 2): seg(ax, a, b, color=orange, lw=1.2, alpha=0.7)
for i, v in enumerate(tet_v):
    seg(ax, tet_c, v, color=red if i == 0 else green, lw=3.0 if i == 0 else 2.2)
ax.scatter(*np.array(tet_v).T, s=50, color=ink2, depthshade=False)
ax.scatter(*tet_c, s=80, color=ink, depthshade=False)
ax.text(*(tet_c + 0.62*(tet_v[0]-tet_c)) + np.array([0.05,-0.02,-0.05]), "anchor", color=red, fontsize=8)
lo, hi = -0.02, 0.52; ax.set_xlim(lo,hi); ax.set_ylim(lo,hi); ax.set_zlim(lo,hi)
# (c) octahedral occupant
ax = fig.add_subplot(1, 4, 3, projection="3d"); setup(ax, "(c)")
for a, b in itertools.combinations(faces, 2):
    if np.isclose(np.linalg.norm(a-b), np.sqrt(0.5)): seg(ax, a, b, color=blue, lw=1.2, alpha=0.7)
for v in faces: seg(ax, oct_c, v, color="#6a4ce2", lw=2.2)
ax.scatter(*np.array(faces).T, s=50, color=ink2, depthshade=False)
ax.scatter(*oct_c, s=80, color=ink, depthshade=False)
ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_zlim(0,1)
# (d) hop across a shared edge
ax = fig.add_subplot(1, 4, 4, projection="3d"); setup(ax, "(d)")
t2_v = [np.array(v) for v in ([0,0,0],[.5,.5,0],[.5,0,-.5],[0,.5,-.5])]; t2_c = sum(t2_v)/4
for a, b in itertools.combinations(tet_v, 2): seg(ax, a, b, color=orange, lw=1.4)
for a, b in itertools.combinations(t2_v, 2): seg(ax, a, b, color=orange, lw=1.4, ls="--", alpha=0.8)
seg(ax, tet_v[0], tet_v[1], color=ink, lw=3)
ax.scatter(*np.array(tet_v+t2_v[2:]).T, s=40, color=ink2, depthshade=False)
ax.scatter(*tet_c, s=70, color=ink, depthshade=False); ax.scatter(*t2_c, s=70, color="white", edgecolor=ink, depthshade=False)
mid = (tet_v[0]+tet_v[1])/2
ax.plot(*zip(tet_c, mid, t2_c), color=green, lw=1.8)
ax.set_xlim(-0.05,0.55); ax.set_ylim(-0.05,0.55); ax.set_zlim(-0.55,0.55)
fig.tight_layout(); fig.savefig("fig_framework.pdf")
