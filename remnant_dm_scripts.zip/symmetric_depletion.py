#!/usr/bin/env python3
"""Asymmetric octahedral sector: chi carries epsilon, chibar exists.
Net chi yield Delta fixed (remnant sorting). Pairs captured at T_Lambda
annihilate afterwards.  Find <sigma v> for which the surviving chibar
fraction r = Ybar/(Ybar+Delta) is small, and check the CMB bound today.
Also verify: around an FCC edge, voids alternate T,O,T,O, so an edge
passage (open) connects like with like; T-O contact is a face (closed)."""
import math, itertools
import numpy as np
from scipy.integrate import solve_ivp

# --- geometry: voids around the edge from (0,0,0) to (.5,.5,0)
mid = np.array([.25,.25,0.]); e = np.array([1,1,0])/math.sqrt(2)
tets = [np.array(p) for p in itertools.product([-.25,.25,.75], repeat=3)
        if all(abs(x) in (.25,.75) for x in p)]
octs = [np.array(p) for p in itertools.product([-.5,0,.5,1], repeat=3)
        if (round(sum(p)*2) % 2 == 1)]  # FCC octahedral sites: (h+k+l) odd in units of a/2
near = [(c,'T') for c in tets if abs(np.linalg.norm(c-mid)-math.sqrt(2)*.25)<1e-6 or np.linalg.norm(c-mid)<.36] \
     + [(c,'O') for c in octs]
ring = []
for c, k in near:
    d = c - mid; perp = d - (d@e)*e
    if abs(d@e) < 1e-6 and 1e-6 < np.linalg.norm(perp) < .36:
        ring.append((math.degrees(math.atan2(perp[2], perp@np.array([1,-1,0])/math.sqrt(2))) % 360, k))
ring = sorted(set((round(a,1),k) for a,k in ring))
print("voids around one edge (angle, type):", ring)

# --- cosmology
m=1.719; Mpl=1.2209e19; gs=17.25; TL=0.155; g=2
s  = lambda T: 2*math.pi**2/45*gs*T**3
H  = lambda T: 1.66*math.sqrt(gs)*T**2/Mpl
Yeq= lambda T: g*(m*T/2/math.pi)**1.5*math.exp(-m/T)/s(T)
D  = 0.1200*1.0537e-5/2891.2/m          # net chi yield
cm3s = 1/1.1673e-17                      # cm^3/s -> GeV^-2
def final_r(sv_cgs, Y0):
    sv = sv_cgs*cm3s
    def f(lnT, y):
        T = math.exp(lnT); Y = math.exp(y[0])
        return [max(min(sv*s(T)/H(T)*(Y*(Y+D) - Yeq(T)**2)/Y, 1e12), -1e12)] if y[0] > -700 else [0.0]
    sol = solve_ivp(f, [math.log(TL), math.log(1e-4)], [math.log(Y0)],
                    method="LSODA", rtol=1e-8, atol=1e-10)
    Yb = math.exp(max(sol.y[0,-1], -700)); return Yb/(Yb+D)
Y0 = Yeq(TL)
print(f"\nnet Delta = {D:.2e}; chibar at T_Lambda (equilibrium) = {Y0:.2e}")
for sv in (1e-30,1e-27,1e-26,1e-25,2e-25,3e-25,5e-25,1e-24,1e-22,1e-15):
    r = final_r(sv, Y0)
    cmb = 2*r/(1+r)**2*sv     # effective <sigma v>: energy rate 2m n n_bar <sv> = rho^2 <sv>_eff/m, r = n_bar/n
    print(f"<sv> = {sv:.0e} cm^3/s : surviving chibar fraction r = {r:.2e}, effective <sv>_today = {cmb:.1e}")
