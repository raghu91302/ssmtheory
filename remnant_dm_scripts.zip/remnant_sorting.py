#!/usr/bin/env python3
"""Remnant-sorting abundance check for the octahedral dark-matter candidate.
1. FCC void classes per primitive cell, inscribed radii, volumes.
2. Bond-angle cosines from each void center (charge-projection rule).
3. Abundance ratio under 'probability per unit inscribed volume'.
4. Freeze-in bound: largest pair cross section for which thermal
   production below the confinement scale stays under 10% of the DM.
"""
import itertools, math
import numpy as np
from scipy.integrate import quad

# --- 1. FCC conventional cell, a = 1, bond length L = a/sqrt2
a = 1.0; L = a/math.sqrt(2)
basis = np.array([[0,0,0],[.5,.5,0],[.5,0,.5],[0,.5,.5]])
nodes = np.array([b + np.array(t) for b in basis for t in itertools.product(range(-1,3), repeat=3)])
def nearest(c, k):
    d = np.linalg.norm(nodes - c, axis=1); i = np.argsort(d)[:k]; return nodes[i], d[i]
tet = [np.array(p) for p in itertools.product([.25,.75], repeat=3)]
octs = [np.array([.5,.5,.5]), np.array([.5,0,0]), np.array([0,.5,0]), np.array([0,0,.5])]
def orient(c):
    v, _ = nearest(c, 4); u = (v - c)/np.linalg.norm(v - c, axis=1)[:,None]
    return tuple(sorted(tuple(np.sign(np.round(x, 6)).astype(int)) for x in u))
classes = {}
for c in tet: classes.setdefault(orient(c), []).append(c)
print("tetrahedral voids per conventional cell:", len(tet),
      "-> orientation classes:", [len(v) for v in classes.values()])
# inversion through a node maps one class to the other
c0 = tet[0]; img = (-c0) % 1.0
print("inversion of", c0, "->", img, "same class?", orient(img) == orient(c0))
_, dt = nearest(tet[0], 4); _, do = nearest(octs[0], 6)
rt = dt[0] - L/2; ro = do[0] - L/2
print(f"inscribed radius: tet {rt/L:.4f} L, oct {ro/L:.4f} L; per-void volume ratio {(ro/rt)**3:.4f}")

# --- 2. bond-angle cosines from the void center
def cosines(c, k):
    v, _ = nearest(c, k); u = (v - c)/np.linalg.norm(v - c, axis=1)[:,None]
    return sorted(set(np.round(u @ u.T, 6)[np.triu_indices(k, 1)]))
print("tet bond-angle cosines:", cosines(tet[0], 4), " (projection -1/3)")
print("oct bond-angle cosines:", cosines(octs[0], 6), " (adjacent 0, antipodal -1)")

# --- 3. abundance
m_chi, m_p = 1.719, 0.938272
for label, ntet in (("both tetrahedral classes hold matter", 8), ("one class only (C = site inversion)", 4)):
    R = 4*ro**3/(ntet*rt**3)
    print(f"{label}: n_chi/n_B = {R:.3f}, Omega_DM/Omega_b = {R*m_chi/m_p:.3f}")
print(f"observed (Planck 2018, 0.1200/0.02237) = {0.1200/0.02237:.3f}")

# --- 4. freeze-in bound (production starts at T_Lambda; code absent above)
Mpl = 1.2209e19; gstar = 17.25; T_L = 0.155; g = 2
s_of = lambda T: 2*math.pi**2/45*gstar*T**3
H_of = lambda T: 1.66*math.sqrt(gstar)*T**2/Mpl
def neq(T):  # nonrelativistic Maxwell-Boltzmann
    return g*(m_chi*T/2/math.pi)**1.5*math.exp(-m_chi/T)
def Y_freezein(sv_GeV):  # dY/dT = -<sv> neq^2 /(s H T)
    return quad(lambda T: sv_GeV*neq(T)**2/(s_of(T)*H_of(T)*T), 0.005, T_L, limit=200)[0]
GeV2_per_cm3s = 1/(1.1673e-17)        # 1 cm^3/s = 1.1673e-17 GeV^-2
Y_DM = 0.1200*1.0537e-5/2891.2/m_chi
Y1 = Y_freezein(1e-30*GeV2_per_cm3s)
sv_max = 1e-30*(0.1*Y_DM)/Y1
print(f"\nY_DM required = {Y_DM:.2e};  freeze-in Y at <sv>=1e-30 cm^3/s: {Y1:.2e}")
print(f"<sv> must be < {sv_max:.1e} cm^3/s for thermal production < 10% of DM")
print(f"Fermi limit (gamma gamma, with systematics) 6.3e-29 -> factor {6.3e-29/sv_max:.0e} stronger")

# --- 5. alternative capture measures (per void, units of L^3), per primitive cell: 1 O + 2 T
print("\nalternative capture measures (per primitive cell: 1 octahedral, 2 tetrahedral voids)")
sph = math.pi/6                                   # volume of a node sphere of radius L/2
om_T = math.acos(23/27)                           # vertex solid angle of a regular tetrahedron
om_O = 4*math.asin(1/3)                           # vertex solid angle of a regular octahedron
V_T, V_O = math.sqrt(2)/12, math.sqrt(2)/3        # polyhedron volumes, edge L
F_T = V_T - 4*om_T/(4*math.pi)*sph                # free volume outside packed spheres
F_O = V_O - 6*om_O/(4*math.pi)*sph
pack = 1 - (F_O + 2*F_T)/(1/math.sqrt(2))
rT_, rO_ = math.sqrt(3/8)-.5, 1/math.sqrt(2)-.5
for name, vO, vT in (("equal probability per void", 1, 1), ("bounding polyhedron", V_O, V_T),
                     ("free volume outside spheres", F_O, F_T), ("inscribed sphere", rO_**3, rT_**3)):
    R = vO/(2*vT); print(f"  {name:30s} n_chi/n_B = {R:.3f}   Omega ratio = {R*m_chi/m_p:.3f}")
print(f"  observed requires              n_chi/n_B = {0.1200/0.02237/(m_chi/m_p):.3f}   Omega ratio = {0.1200/0.02237:.3f}")
print(f"  (check: packing fraction from free volumes = {pack:.4f}, expected 0.7405)")
