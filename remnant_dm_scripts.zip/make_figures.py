#!/usr/bin/env python3
"""Figures for the remnant-sorting paper."""
import itertools, math, importlib.util
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
INK, INK2, GRID = "#191919", "#666666", "#d9d9d9"
BLUE, ORANGE = "#257de0", "#f47230"
plt.rcParams.update({"font.size": 10, "text.color": INK, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.edgecolor": INK2})
L = 1/math.sqrt(2)

# ---- Figure 1: one conventional cell, one void of each kind with its inscribed sphere
fig = plt.figure(figsize=(6.6, 3.2))
basis = [(0,0,0),(.5,.5,0),(.5,0,.5),(0,.5,.5)]
nodes = sorted({tuple(np.round(np.add(b,t),3)) for b in basis for t in itertools.product((0,1),repeat=3)
                if all(0 <= x <= 1 for x in np.add(b,t))})
def sphere(ax, c, r, col, alpha):
    u, v = np.mgrid[0:2*np.pi:30j, 0:np.pi:15j]
    ax.plot_surface(c[0]+r*np.cos(u)*np.sin(v), c[1]+r*np.sin(u)*np.sin(v), c[2]+r*np.cos(v),
                    color=col, alpha=alpha, linewidth=0, shade=True)
panels = [("Tetrahedral void", np.array([.25,.25,.25]), 4, math.sqrt(3/8)-.5, ORANGE),
          ("Octahedral void",  np.array([.5,.5,.5]),  6, math.sqrt(2)/2-.5, BLUE)]
for i, (title, c, k, rr, col) in enumerate(panels):
    ax = fig.add_subplot(1, 2, i+1, projection="3d")
    P = np.array(nodes); d = np.linalg.norm(P-c, axis=1); nb = P[np.argsort(d)[:k]]
    ax.scatter(*P.T, s=14, color="#b0b0b0", depthshade=False)
    ax.scatter(*nb.T, s=30, color=INK2, depthshade=False)
    for a, b in itertools.combinations(nb, 2):
        if abs(np.linalg.norm(a-b) - L) < 1e-6:
            ax.plot(*zip(a, b), color=INK2, lw=1)
    sphere(ax, c, rr*L, col, 0.85)
    ax.set_title(f"{title}\n$r = {rr:.4f}\\,L$", fontsize=10)
    ax.set_box_aspect((1,1,1)); ax.set_axis_off(); ax.view_init(*((24, 62) if i == 0 else (18, 32)))
fig.text(0.5, 0.02, "Per primitive cell: 2 tetrahedral voids (one of each orientation), 1 octahedral void.  "
         "Total inscribed volume, octahedral : tetrahedral = 3.13 : 1",
         ha="center", fontsize=8.5, color=INK2)
fig.savefig("fig_voids.pdf", bbox_inches="tight"); plt.close(fig)

# ---- Figure 2: surviving antiparticle fraction vs pair annihilation rate
spec = importlib.util.spec_from_file_location("sd", "symmetric_depletion.py")
src = open("symmetric_depletion.py").read().split("for sv in")[0]   # reuse definitions only
ns = {}; exec(compile(src, "sd", "exec"), ns)
sv = np.logspace(-28, -23.5, 60)
r = np.array([ns["final_r"](x, ns["Y0"]) for x in sv])
eff = 2*r/(1+r)**2*sv
cmb = 3.2e-28*1.719/0.5      # Planck 2018 p_ann bound, f_eff = 0.5
over = 2*r/(1-r+1e-300)      # (chibar + extra chi)/Delta = 2 Ybar/Delta
ok = (eff < cmb) & (over < 0.1)
edge = sv[np.argmax(ok)]
fig, ax = plt.subplots(figsize=(5.4, 3.4))
ax.set_xscale("log"); ax.set_yscale("log")
ax.axvspan(sv[0], edge, color="#efefef", lw=0)
ax.plot(sv, np.where(r > 1e-14, r, np.nan), color=BLUE, lw=2)
ax.set_xlim(sv[0], sv[-1]); ax.set_ylim(1e-14, 2)
ax.set_xlabel(r"$\chi\bar\chi$ annihilation rate $\langle\sigma v\rangle$ (cm$^3$ s$^{-1}$)")
ax.set_ylabel(r"surviving ratio $r = n_{\bar\chi}/n_\chi$")
ax.grid(True, which="major", color=GRID, lw=0.6)
ax.text(1.5e-28, 1e-9, "excluded:\ntoo much dark matter\nor CMB energy injection", fontsize=8.5, color=INK2)
ax.axvline(3e-26, color=INK2, lw=1, ls="--")
ax.text(3.4e-26, 1e-13, "thermal-relic\nvalue", fontsize=8, color=INK2)
ax.annotate("allowed", xy=(edge*1.6, 1e-3), fontsize=8.5, color=INK2)
for side in ("top", "right"): ax.spines[side].set_visible(False)
fig.savefig("fig_depletion.pdf", bbox_inches="tight"); plt.close(fig)
print("CMB bound used:", f"{cmb:.1e}", " allowed above <sv> =", f"{edge:.1e}")
