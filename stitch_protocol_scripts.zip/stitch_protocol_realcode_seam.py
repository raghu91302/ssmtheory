"""stitch_protocol_realcode_seam.py -- Sec. 8 (seam audit). Haar bicrystal: charge-string transport
(conductor); bridge-octahedron membership 0 and dual-lattice disconnection (flux insulator);
gauge-consistent diamond bonds ~0.007/bond^2; Regge cross-cells 0 (graviton insulator);
constraint census N_c(r). Requires numpy, scipy."""
import numpy as np, itertools, collections
from scipy.spatial import cKDTree
from scipy.stats import special_ortho_group
bond=np.sqrt(2.0); dbond=np.sqrt(3.0)/2
rng=np.random.default_rng(7)
R=special_ortho_group.rvs(3,random_state=rng)
ext=9
def grain(Rm,off,zlo,zhi):
    pts=[];ints=[]
    for x in range(-ext,ext+1):
        for y in range(-ext,ext+1):
            for z in range(-ext,ext+1):
                if (x+y+z)%2==0:
                    p=Rm@np.array([x,y,z],float)+off
                    if zlo<=p[2]<zhi and abs(p[0])<ext*0.65 and abs(p[1])<ext*0.65:
                        pts.append(p);ints.append((x,y,z))
    return np.array(pts),ints
A,Ai=grain(np.eye(3),np.zeros(3),-6,0); off=rng.uniform(0,1,3); B,Bi=grain(R,off,0,6)
P=np.vstack([A,B]); NA=len(A)
t=cKDTree(P); edges=[]; eidx={}; adjn=collections.defaultdict(list)
for i,js in enumerate(t.query_ball_tree(t,1.05*bond)):
    for j in js:
        if j>i and np.linalg.norm(P[i]-P[j])>=0.95*bond:
            eidx[(i,j)]=len(edges); edges.append((i,j)); adjn[i].append(j); adjn[j].append(i)
bridges={e for e,(i,j) in enumerate(edges) if (i<NA)!=(j<NA)}
area=(2*ext*0.65)**2
print(f"bridges: {len(bridges)} ({len(bridges)/area:.2f}/bond^2)")
# charge transport
def pick(depth,side):
    return [i for i,p in enumerate(P) if (p[2]<-depth if side=='A' else p[2]>depth) and abs(p[0])<2 and abs(p[1])<2][0]
a0,b0=pick(3.5,'A'),pick(3.5,'B')
prev={a0:None}; dq=collections.deque([a0])
while dq:
    u=dq.popleft()
    if u==b0: break
    for v in adjn[u]:
        if v not in prev: prev[v]=u; dq.append(v)
path=[]; u=b0
while u is not None: path.append(u); u=prev[u]
print(f"charge string: {len(path)-1} steps, constant syndrome energy 2 (path endpoints)")
# octahedra + dual components
lookA={q:i for i,q in enumerate(Ai)}; lookB={q:i+NA for i,q in enumerate(Bi)}
def octs_of(look):
    out=[]
    for x in range(-ext,ext+1):
        for y in range(-ext,ext+1):
            for z in range(-ext,ext+1):
                if (x+y+z)%2==1:
                    nbs=[look[q] for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
                         if (q:=(x+d[0],y+d[1],z+d[2])) in look]
                    if len(nbs)>=4:
                        s=set(nbs); es=frozenset(eidx[(min(a,b),max(a,b))] for a in s for b in s
                                                  if a<b and (min(a,b),max(a,b)) in eidx)
                        if es: out.append(es)
    return out
octA=octs_of(lookA); octB=octs_of(lookB); octs=octA+octB
nbr=sum(1 for es in octs for e in es if e in bridges)
e2o=collections.defaultdict(list)
for oi,es in enumerate(octs):
    for e in es: e2o[e].append(oi)
dadj=collections.defaultdict(set)
for e,ois in e2o.items():
    for a in ois:
        for b in ois:
            if a!=b: dadj[a].add(b)
seen=set(); comps=0; span=0
for s0 in range(len(octs)):
    if s0 in seen: continue
    dq=collections.deque([s0]); comp={s0}
    while dq:
        u=dq.popleft()
        for v in dadj[u]:
            if v not in comp: comp.add(v); dq.append(v)
    seen|=comp; comps+=1
    if any(o<len(octA) for o in comp) and any(o>=len(octA) for o in comp): span+=1
print(f"bridge edges in octahedral checks: {nbr} [expect 0]; dual components: {comps}, spanning both grains: {span} [expect 0]")
# --- gauge diamond bonds + constraint census: verbatim geometry of the original run ---
# (own rng(7) stream, +-2-extended clouds, exactly as the manuscript computation)
rng2=np.random.default_rng(7)
R2=special_ortho_group.rvs(3,random_state=rng2)
def grain2(Rm,off,zlo,zhi):
    pts=[]
    r=range(-ext,ext+1)
    for x in r:
        for y in r:
            for z in r:
                if (x+y+z)%2==0:
                    p=Rm@np.array([x,y,z],float)+off
                    if zlo-2<p[2]<zhi+2 and abs(p[0])<ext*0.65 and abs(p[1])<ext*0.65: pts.append(p)
    P=np.array(pts)
    t=cKDTree(P); ad=collections.defaultdict(set)
    for i,js in enumerate(t.query_ball_tree(t,1.05*bond)):
        for j in js:
            if j!=i and np.linalg.norm(P[i]-P[j])>=0.95*bond: ad[i].add(j)
    tets=set()
    for i in range(len(P)):
        for a,b,c in itertools.combinations(sorted(ad[i]),3):
            if b in ad[a] and c in ad[a] and c in ad[b]: tets.add(frozenset((i,a,b,c)))
    cent=np.array([P[list(tt)].mean(axis=0) for tt in tets]) if tets else np.zeros((0,3))
    mA=(P[:,2]>=zlo)&(P[:,2]<zhi)
    mC=(cent[:,2]>=zlo)&(cent[:,2]<zhi) if len(cent) else np.zeros(0,bool)
    return P[mA], cent[mC], P
As2,Ac2,Afull=grain2(np.eye(3),np.zeros(3),-6,0)
off2=rng2.uniform(0,1,3)
Bs2,Bc2,Bfull=grain2(R2,off2,0,6)
def crossd(P1,P2):
    if len(P1)==0 or len(P2)==0: return 0
    n=0; t1=cKDTree(P1)
    for j,js in enumerate(cKDTree(P2).query_ball_tree(t1,1.05*dbond)):
        for i in js:
            if np.linalg.norm(P2[j]-P1[i])>=0.95*dbond: n+=1
    return n
ng=crossd(As2,Bc2)+crossd(Bs2,Ac2)
print(f"gauge-consistent diamond bonds across seam: {ng} ({ng/area:.3f}/bond^2) [expect ~1, 0.007]")
slab=1.5
def trunc_nodes(Pf,zwin):
    tt=cKDTree(Pf); out=[]
    for i,p in enumerate(Pf):
        if abs(p[2])<zwin:
            nb=[j for j in tt.query_ball_point(p,1.05*bond) if j!=i and np.linalg.norm(p-Pf[j])>=0.95*bond]
            if len(nb)<12: out.append(p)
    return np.array(out) if out else np.zeros((0,3))
tA=trunc_nodes(Afull,slab); tB=trunc_nodes(Bfull,slab)
gaussA=np.vstack([As2[np.abs(As2[:,2])<slab]] + ([Ac2[np.abs(Ac2[:,2])<slab]] if len(Ac2) else []))
gaussB=np.vstack([Bs2[np.abs(Bs2[:,2])<slab]] + ([Bc2[np.abs(Bc2[:,2])<slab]] if len(Bc2) else []))
allc=np.vstack([gaussA,gaussB,tA,tB])
tc=cKDTree(allc[:,:2])
pts=rng2.uniform(-ext*0.4,ext*0.4,size=(25,2))
print(f"constraint pool: Gauss A {len(gaussA)}, Gauss B {len(gaussB)}, truncated {len(tA)+len(tB)} [expect 160, 297, 205]")
for r in [1.0,1.5,2.0]:
    cs=[len(tc.query_ball_point(p,r)) for p in pts]
    print(f"N_c(r={r}) = {np.mean(cs):.1f} +- {np.std(cs):.1f}")
print("PASS if census reproduces 13.4 / 31.8 / 59.4 and pool matches.")
