"""stitch_protocol_measurement_laws.py -- Sec. 3 / Fig. 3.
Exponential law P=cos^{2Nb}(theta/2) with kappa(theta)=-2 ln cos(theta/2); cargo-blind P;
faithful-branch law 1-F=tan^{2Nb}(theta/2); lossy fast branch. Requires numpy."""
import numpy as np, itertools, functools
I=np.eye(2); X=np.array([[0.,1],[1,0]]); Y=np.array([[0,-1j],[1j,0]]); Z=np.diag([1.,-1])
def ap(v,op,i,N):
    v=v.reshape((2,)*N); v=np.tensordot(op,v,axes=([1],[i])); return np.moveaxis(v,0,i).reshape(-1)
def meas(N,theta,a,b,fast=False):
    u=np.cos(theta/2)*I-1j*np.sin(theta/2)*Y; zt=u@Z@u.conj().T; xt=u@X@u.conj().T
    psi=np.zeros(2**N,complex); psi[0]=a; psi[-1]=b; psi/=np.linalg.norm(psi)
    k0=u@np.array([1,0.]); k1=u@np.array([0,1.])
    L0=functools.reduce(np.kron,[k0]*N); L1=functools.reduce(np.kron,[k1]*N)
    tgt=a*L0+b*L1; tgt/=np.linalg.norm(tgt)
    def ck(v,i,s):
        w=ap(ap(v,zt,i,N),zt,i+1,N); return (v+s*w)/2
    phi=psi.copy()
    for i in range(N-1): phi=ck(phi,i,+1)
    p=np.vdot(phi,phi).real; Ff=abs(np.vdot(tgt,phi))**2/p
    Fd=None
    if fast:
        Fd=0.0
        for synd in itertools.product([1,-1],repeat=N-1):
            v=psi.copy()
            for i,sg in enumerate(synd): v=ck(v,i,sg)
            pb=np.vdot(v,v).real
            if pb<1e-14: continue
            v/=np.sqrt(pb); fl=False
            for i,sg in enumerate(synd):
                if sg==-1: fl=not fl
                if fl and i+1<N: v=ap(v,xt,i+1,N)
            f1=abs(np.vdot(tgt,v))**2; v2=v.copy()
            for q in range(N): v2=ap(v2,xt,q,N)
            Fd+=pb*max(f1,abs(np.vdot(tgt,v2))**2)
    return p,Ff,Fd
a,b=1/np.sqrt(3),np.sqrt(2/3)*np.exp(1j*.7)
print("exponential law:")
for th in [0.6,1.2]:
    k=-2*np.log(np.cos(th/2))
    for N in [5,9,13]:
        p,_,_=meas(N,th,a,b)
        print(f"  theta={th} N={N}: -lnP/N={-np.log(p)/N:.4f}  kappa={k:.4f}")
print("cargo-blindness (N=9, theta=0.6): P for four cargo states:")
for (aa,bb) in [(1,0),(0,1),(2**-.5,2**-.5),(2**-.5,1j*2**-.5)]:
    print(f"  P={meas(9,0.6,aa,bb)[0]:.8f}")
print("faithful law 1-F vs tan^2N (theta=1.2):")
for N in [5,9,13]:
    _,F,_=meas(N,1.2,2**-.5,2**-.5)
    print(f"  N={N}: 1-F={1-F:.3e}  tan^2N={np.tan(0.6)**(2*N):.3e}")
print("fast-branch loss (theta=0.9):")
for N in [3,6,9]:
    print(f"  N={N}: F_fast={meas(N,0.9,a,b,fast=True)[2]:.4f}")
print("PASS if slopes match kappa, P cargo-uniform, laws agree, F_fast declining.")
