"""stitch_protocol_junction.py -- Sec. 6 / Fig. 4. Coherent junction Eq.(2): scaling t~e^{2.4Nb},
fidelity 0.96-0.98 (bare refs), manifold fidelity ~0.999, lambda^2 residual scaling,
cargo-blind clock. Requires numpy."""
import numpy as np, functools
I=np.eye(2); X=np.array([[0.,1],[1,0]]); Y=np.array([[0,-1j],[1j,0]]); Z=np.diag([1.,-1])
def kron(*o): return functools.reduce(np.kron,o)
def one(T,A,i):
    o=[I]*T; o[i]=A; return kron(*o)
def two(T,A,B,i,j):
    o=[I]*T; o[i]=A; o[j]=B; return kron(*o)
theta=0.9; J=1.0
u=np.cos(theta/2)*I-1j*np.sin(theta/2)*Y; zt=u@Z@u.conj().T; xt=u@X@u.conj().T; yt=u@Y@u.conj().T
def dressed(N,h):
    Hb=np.zeros((2**N,2**N),complex)
    for i in range(N-1): Hb-=J*two(N,Z,Z,i,i+1)
    for i in range(N):   Hb-=h*one(N,X,i)
    w,V=np.linalg.eigh(Hb); g,e=V[:,0],V[:,1]
    a=(g+e)/np.sqrt(2); b=(g-e)/np.sqrt(2)
    if abs(a[0])<abs(b[0]): a,b=b,a
    if a[0].real<0: a=-a
    if b[-1].real<0: b=-b
    return a,b,(w[1]-w[0])/2
def build(N,h,lz,lx):
    T=2*N; H=np.zeros((2**T,2**T),complex)
    for i in range(N-1):   H-=J*two(T,Z,Z,i,i+1)
    for i in range(N,T-1): H-=J*two(T,zt,zt,i,i+1)
    for i in range(N):     H-=h*one(T,X,i)
    for i in range(N,T):   H-=h*one(T,xt,i)
    H-=lz*two(T,Z,zt,N-1,N)+lx*(two(T,X,xt,N-1,N)+two(T,Y,yt,N-1,N))
    return H
def transfer(N,h,l,cargo,manifold=False):
    a,b=cargo
    d0,d1,D=dressed(N,h); Ub=kron(*[u]*N); d0B,d1B=Ub@d0,Ub@d1
    H=build(N,h,l,l); w,V=np.linalg.eigh(H)
    psi=np.kron(a*d0+b*d1,d0B); psi/=np.linalg.norm(psi)
    b00=np.kron(d0,d0B); b01=np.kron(d0,d1B)
    if manifold:
        P=V[:,:4]@V[:,:4].conj().T
        psi=P@psi; psi/=np.linalg.norm(psi)
        b00p,b01p=P@b00,P@b01
        b00,b01=b00p/np.linalg.norm(b00p),b01p/np.linalg.norm(b01p)
    c=V.conj().T@psi; c00=V.conj().T@b00; c01=V.conj().T@b01
    ts=np.linspace(1,40/(D*D/(2*l)),3000)
    ph=np.exp(-1j*np.outer(ts,w))*c[None,:]
    A0=(np.conj(c00)[None,:]*ph).sum(axis=1); A1=(np.conj(c01)[None,:]*ph).sum(axis=1)
    Fo=(np.abs(a)*np.abs(A0)+np.abs(b)*np.abs(A1))**2
    Fm=Fo.max(); k=None
    for i in range(2,len(Fo)-2):
        if Fo[i]>0.5*Fm and Fo[i]>Fo[i-1] and Fo[i]>=Fo[i+1]: k=i; break
    return Fm, ts[k]
print("scaling and fidelity (h=0.3, lam=0.3):")
tt={}
for N in [3,4,5]:
    for cargo,lab in [((0,1),'|1>'),((2**-.5,2**-.5),'|+>')]:
        F,tp=transfer(N,0.3,0.3,cargo)
        if lab=='|1>': tt[N]=tp
        print(f"  N={N} {lab}: F_opt={F:.4f}  t_first_peak={tp:.3e}")
sl=(np.log(tt[5])-np.log(tt[3]))/2
print(f"  slope: t ~ e^({sl:.2f} N)")
print("manifold + lambda^2 (N=4, |+>):")
for l in [0.3,0.15]:
    Fb,_=transfer(4,0.3,l,(2**-.5,2**-.5))
    Fm,_=transfer(4,0.3,l,(2**-.5,2**-.5),manifold=True)
    print(f"  lam={l}: 1-F(bare)={1-Fb:.3e}  F(manifold)={Fm:.6f}")
print("PASS if slope ~2.3-2.7, bare residual ~ lambda^2, manifold F -> 0.999.")
