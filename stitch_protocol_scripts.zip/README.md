# stitch_protocol verification scripts

Reproduction scripts for *The Grain-Boundary Stitch as Coherent Code-Space Tunneling:
Requirements and a Minimal Construction* (R. Kulkarni, 2026). Each script is
self-contained, prints the quantities quoted in the manuscript, and states the
expected values inline. Requirements: `numpy`, `scipy` (seam script), `matplotlib`
(figures script). All randomness is seeded; outputs are deterministic.

| Script | Reproduces |
|---|---|
| `stitch_protocol_measurement_laws.py` | Sec. 3 / Fig. 3: exponential law P = cos^(2Nb)(theta/2) with kappa(theta) = -2 ln cos(theta/2); cargo-blind success probability; faithful-branch law 1-F = tan^(2Nb)(theta/2); lossy fast branch |
| `stitch_protocol_retry_decoherence.py` | Sec. 4: Monte-Carlo repeat-until-success -- first-attempt F ~ 1, any retry F -> 0.5, cycle counts balloon |
| `stitch_protocol_junction.py` | Sec. 6 / Fig. 4: junction Hamiltonian Eq. (2) -- t ~ e^(2.4 Nb) scaling, bare-reference fidelity, exact-manifold fidelity ~ 0.999, lambda^2 residual scaling, cargo-blind clock |
| `stitch_protocol_realcode_logicals.py` | Sec. 8: rebuild and verify [[192,130,3]]; per-void weight-3 logicals; k = 127 + 3; local pairing rank 0; five-edge complete qubits (384 units) |
| `stitch_protocol_realcode_seam.py` | Sec. 8: Haar-bicrystal audit -- charge conductor (9 steps, energy 2); flux insulator (bridge-octahedron membership 0; dual lattice in two disjoint components); gauge-bond density 0.007/bond^2; graviton insulator (0 cross-cells); constraint census N_c(r) = 13.4 / 31.8 / 59.4 |
| `stitch_protocol_figures.py` | Regenerates `fig_meas_laws.pdf` and `fig_junction.pdf` in manuscript style |

`fig_splice.pdf` and `fig_boundary_portrait.pdf` (Sec. 2, Figs. 1-2) are produced by the
boundary-connectivity scripts of the companion package (*Photon-Gravity Coexistence on
the FCC Vacuum*, doi:10.5281/zenodo.21185860) in this repository.
