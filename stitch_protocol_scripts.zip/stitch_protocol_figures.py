"""stitch_protocol_figures.py -- regenerates fig_meas_laws.pdf and fig_junction.pdf
(manuscript style, fixed seeds). fig_splice.pdf and fig_boundary_portrait.pdf are produced
by the companion boundary-connectivity scripts. Requires numpy, matplotlib."""
import numpy as np, itertools, functools
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'mathtext.fontset':'dejavuserif',
 'font.size':9,'axes.linewidth':0.8,'legend.frameon':False,'xtick.direction':'in','ytick.direction':'in',
 'xtick.top':True,'ytick.right':True,'figure.dpi':300,'savefig.dpi':300,'savefig.bbox':'tight'})
C1='#2b3a67'; C2='#8c2f39'; C3='#3a7d44'; grid={'color':'0.88','lw':0.5}
I=np.eye(2); X=np.array([[0.,1],[1,0]]); Y=np.array([[0,-1j],[1j,0]]); Z=np.diag([1.,-1])
def ap(v,op,i,N):
    v=v.reshape((2,)*N); v=np.tensordot(op,v,axes=([1],[i])); return np.moveaxis(v,0,i).reshape(-1)
def meas(N,theta,a,b,fast=False):
    u=np.cos(theta/2)*I-1j*np.sin(theta/2)*Y; zt=u@Z@u.conj().T; xt=u@X@u.conj().T
    psi=np.zeros(2**N,complex); psi[0]=a; psi[-1]=b; psi/=np.linalg.norm(psi)
    k0=u@np.array([1,0.]); k1=u@np.array([0,1.])
    L0=functools.reduce(np.kron,[k0]*N); L1=functools.reduce(np.kron,[k1]*N)
    tgt=a*L0+b*L1; tgt/=np.linalg.norm(tgt)
    def ck(v,i,s):
        w=ap(ap(v,zt,i,N),zt,i+1,N); return (v+s*w)/2
    phi=psi.copy()
    for i in range(N-1): phi=ck(phi,i,+1)
    p=np.vdot(phi,phi).real; Ff=abs(np.vdot(tgt,phi))**2/p
    Fd=None
    if fast:
        Fd=0.0
        for synd in itertools.product([1,-1],repeat=N-1):
            v=psi.copy()
            for i,sg in enumerate(synd): v=ck(v,i,sg)
            pb=np.vdot(v,v).real
            if pb<1e-14: continue
            v/=np.sqrt(pb); fl=False
            for i,sg in enumerate(synd):
                if sg==-1: fl=not fl
                if fl and i+1<N: v=ap(v,xt,i+1,N)
            f1=abs(np.vdot(tgt,v))**2; v2=v.copy()
            for q in range(N): v2=ap(v2,xt,q,N)
            Fd+=pb*max(f1,abs(np.vdot(tgt,v2))**2)
    return p,Ff,Fd
a0,b0=1/np.sqrt(3),np.sqrt(2/3)*np.exp(1j*0.7)
Ns=np.arange(3,14,2)
fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
for th,c in [(0.6,C1),(1.2,C2)]:
    P=[meas(N,th,a0,b0)[0] for N in Ns]
    ax[0].semilogy(Ns,P,'o-',ms=4,color=c,lw=1.2,label=f'$\\theta={th}$')
    k=-2*np.log(np.cos(th/2))
    ax[0].semilogy(Ns,np.exp(-k*(Ns-Ns[0]))*P[0],'--',color=c,lw=0.8)
ax[0].set_xlabel('tilted checks $N_b$'); ax[0].set_ylabel('$P_{\\rm success}$ per attempt')
ax[0].set_title('(a) exponential law, $\\kappa=-2\\ln\\cos(\\theta/2)$')
ax[0].legend(); ax[0].grid(which='both',**grid); ax[0].set_axisbelow(True)
Nf=np.arange(3,10)
Fd=[meas(N,0.9,a0,b0,fast=True)[2] for N in Nf]
Ff=[meas(N,0.9,a0,b0)[1] for N in Ns]
ax[1].plot(Nf,Fd,'s-',ms=4,color=C2,lw=1.2,label='fast (deterministic)')
ax[1].plot(Ns,Ff,'o-',ms=4,color=C3,lw=1.2,label='faithful (postselected)')
ax[1].axhline(1,color='0.6',lw=0.7,ls=':')
ax[1].set_xlabel('tilted checks $N_b$'); ax[1].set_ylabel('logical fidelity')
ax[1].set_title('(b) fidelity--time tradeoff ($\\theta=0.9$)')
ax[1].set_ylim(0.55,1.03); ax[1].legend(loc='center left'); ax[1].grid(**grid); ax[1].set_axisbelow(True)
plt.tight_layout(); plt.savefig('fig_meas_laws.pdf'); plt.close()
# junction figure
def kron(*o): return functools.reduce(np.kron,o)
def one(T,A,i):
    o=[I]*T; o[i]=A; return kron(*o)
def two(T,A,B,i,j):
    o=[I]*T; o[i]=A; o[j]=B; return kron(*o)
theta=0.9; J=1.0; h=0.3; lz=0.3; lx=0.3
u=np.cos(theta/2)*I-1j*np.sin(theta/2)*Y; zt=u@Z@u.conj().T; xt=u@X@u.conj().T; yt=u@Y@u.conj().T
def dressed(N):
    Hb=np.zeros((2**N,2**N),complex)
    for i in range(N-1): Hb-=J*two(N,Z,Z,i,i+1)
    for i in range(N):   Hb-=h*one(N,X,i)
    w,V=np.linalg.eigh(Hb); g,e=V[:,0],V[:,1]
    aa=(g+e)/np.sqrt(2); bb=(g-e)/np.sqrt(2)
    if abs(aa[0])<abs(bb[0]): aa,bb=bb,aa
    if aa[0].real<0: aa=-aa
    if bb[-1].real<0: bb=-bb
    return aa,bb,(w[1]-w[0])/2
tpk={}; curves={}
for N in [3,4,5]:
    d0,d1,D=dressed(N); Ub=kron(*[u]*N); d0B,d1B=Ub@d0,Ub@d1
    T=2*N; H=np.zeros((2**T,2**T),complex)
    for i in range(N-1):   H-=J*two(T,Z,Z,i,i+1)
    for i in range(N,T-1): H-=J*two(T,zt,zt,i,i+1)
    for i in range(N):     H-=h*one(T,X,i)
    for i in range(N,T):   H-=h*one(T,xt,i)
    H-=lz*two(T,Z,zt,N-1,N)+lx*(two(T,X,xt,N-1,N)+two(T,Y,yt,N-1,N))
    w,V=np.linalg.eigh(H)
    b00=np.kron(d0,d0B); b01=np.kron(d0,d1B)
    c00=V.conj().T@b00; c01=V.conj().T@b01
    ts=np.linspace(1,40/(D*D/(lz+lx)),3000)
    for (aa,bb,lab) in [(0,1,'$|1\\rangle$'),(2**-.5,2**-.5,'$|+\\rangle$'),(1/np.sqrt(3),np.sqrt(2/3)*np.exp(1j*.7),'generic')]:
        psi=np.kron(aa*d0+bb*d1,d0B); psi/=np.linalg.norm(psi)
        c=V.conj().T@psi
        ph=np.exp(-1j*np.outer(ts,w))*c[None,:]
        A0=(np.conj(c00)[None,:]*ph).sum(axis=1); A1=(np.conj(c01)[None,:]*ph).sum(axis=1)
        Fo=(np.abs(aa)*np.abs(A0)+np.abs(bb)*np.abs(A1))**2
        if N==4: curves[lab]=(ts,Fo)
        if lab=='$|1\\rangle$':
            Fm=Fo.max(); k=None
            for i in range(2,len(Fo)-2):
                if Fo[i]>0.5*Fm and Fo[i]>Fo[i-1] and Fo[i]>=Fo[i+1]: k=i; break
            tpk[N]=ts[k]
fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
for (lab,(ts,Fo)),c,lsty in zip(curves.items(),[C1,C2,C3],['-','--',':']):
    ax[0].plot(ts/1e5,Fo,lsty,color=c,lw=1.3,label=lab)
ax[0].set_xlabel('$t\\;[10^5\\,J^{-1}]$'); ax[0].set_ylabel('transfer fidelity $F$')
ax[0].set_title('(a) coherent transfer, $N_b=4$: cargo-blind clock')
ax[0].legend(loc='upper left'); ax[0].grid(**grid); ax[0].set_axisbelow(True)
Nl=sorted(tpk); tv=[tpk[n] for n in Nl]
ax[1].semilogy(Nl,tv,'o-',ms=5,color=C1,lw=1.3,label='$t_{\\rm transfer}$')
sl=(np.log(tv[-1])-np.log(tv[0]))/(Nl[-1]-Nl[0])
ax[1].semilogy(Nl,np.exp(sl*(np.array(Nl)-Nl[0]))*tv[0],'--',color='0.5',lw=0.9,label=f'$e^{{{sl:.2f}N_b}}$')
ax[1].set_xlabel('block size $N_b$'); ax[1].set_ylabel('$t_{\\rm transfer}\\;[J^{-1}]$')
ax[1].set_title('(b) exponentially slow in the support')
ax[1].set_xticks(Nl); ax[1].legend(); ax[1].grid(which='both',**grid); ax[1].set_axisbelow(True)
plt.tight_layout(); plt.savefig('fig_junction.pdf'); plt.close()
print('figures regenerated')
