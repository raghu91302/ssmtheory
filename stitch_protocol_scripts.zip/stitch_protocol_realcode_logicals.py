"""stitch_protocol_realcode_logicals.py -- Sec. 8 (first part). Rebuild [[192,130,3]] (verify n,CSS,k);
extract per-void wt-3 logicals; k = 127 void + 3 homological; local pairing rank 0;
minimal complete qubits = 5 edges across adjacent voids (384 units). Requires numpy."""
import numpy as np, itertools, collections
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
L=4
nodes,nidx=[],{}
for x in range(L):
    for y in range(L):
        for z in range(L):
            if (x+y+z)%2==0: nidx[(x,y,z)]=len(nodes); nodes.append((x,y,z))
edges,eidx=[],{}
adj=collections.defaultdict(set)
for i,(x,y,z) in enumerate(nodes):
    for d in NN:
        nb=((x+d[0])%L,(y+d[1])%L,(z+d[2])%L)
        if nb in nidx:
            j=nidx[nb]; adj[i].add(j)
            if i<j: eidx[(i,j)]=len(edges); edges.append((i,j))
ne=len(edges)
octs=[]
for x in range(L):
    for y in range(L):
        for z in range(L):
            if (x+y+z)%2==1:
                nbs=[nidx[q] for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
                     if (q:=((x+d[0])%L,(y+d[1])%L,(z+d[2])%L)) in nidx]
                if len(nbs)==6: octs.append(nbs)
HZ=np.zeros((len(nodes),ne),np.int8)
for ei,(i,j) in enumerate(edges): HZ[i,ei]=1; HZ[j,ei]=1
HX=np.zeros((len(octs),ne),np.int8)
for oi,nbs in enumerate(octs):
    s=set(nbs)
    for ei,(i,j) in enumerate(edges):
        if i in s and j in s: HX[oi,ei]=1
def rref(M):
    M=M.copy().astype(np.int8); r=0
    for c in range(M.shape[1]):
        p=None
        for row in range(r,M.shape[0]):
            if M[row,c]: p=row; break
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for row in range(M.shape[0]):
            if row!=r and M[row,c]: M[row]^=M[r]
        r+=1
    return M[:r]
rsX=rref(HX); rsZ=rref(HZ)
k=ne-rsZ.shape[0]-rsX.shape[0]
print(f"code: n={ne}, CSS={int((HX@HZ.T%2).sum())==0}, k={k}  [expect 192,True,130]")
def in_span(rs,v):
    v=v.copy()
    for row in rs:
        c=np.argmax(row)
        if v[c]: v^=row
    return not v.any()
tets=set()
for i in range(len(nodes)):
    for a,b,c in itertools.combinations(sorted(adj[i]),3):
        if b in adj[a] and c in adj[a] and c in adj[b]: tets.add(frozenset((i,a,b,c)))
tets=[sorted(t) for t in tets]
def tE(t): return [eidx[(min(a,b),max(a,b))] for a,b in itertools.combinations(t,2)]
Xl={}; Zl={}
for ti,t in enumerate(tets):
    lx=[]; lz=[]
    for r in range(1,7):
        for sub in itertools.combinations(tE(t),r):
            v=np.zeros(ne,np.int8); v[list(sub)]=1
            if not (HZ@v%2).any() and not in_span(rsX,v): lx.append(v)
            if not (HX@v%2).any() and not in_span(rsZ,v): lz.append(v)
    Xl[ti]=lx; Zl[ti]=lz
def indep(logs,rs):
    out=[]; acc=rs
    for v in logs:
        if rref(np.vstack([acc,v])).shape[0]>rref(acc).shape[0]:
            out.append(v); acc=np.vstack([acc,v])
    return out
allX=[]; allZ=[]; local_rank=[]
for ti in range(len(tets)):
    ix=indep(Xl[ti],rsX); iz=indep(Zl[ti],rsZ)
    allX+=ix; allZ+=iz
    P=np.array([[int(a@b)%2 for b in iz] for a in ix],np.int8) if ix and iz else np.zeros((0,0),np.int8)
    local_rank.append(rref(P).shape[0] if P.size else 0)
rX=rref(np.vstack([rsX]+allX)).shape[0]-rsX.shape[0]
print(f"voids: {len(tets)}; per-void indep logicals: 3+3 wt-3; local pairing ranks: {set(local_rank)}")
print(f"void-attributed logicals per side: {rX}; homological remainder: {130-rX}  [expect 127 + 3]")
# minimal complete qubits across adjacent voids
tadj=collections.defaultdict(set)
for a,b in itertools.combinations(range(len(tets)),2):
    if len(set(tets[a])&set(tets[b]))>=2: tadj[a].add(b); tadj[b].add(a)
units=0; sizes=set()
for s in range(len(tets)):
    for t in tadj[s]:
        for x in Xl[s]:
            done=False
            for z in Zl[t]:
                if int(x@z)%2==1:
                    units+=1; sizes.add(int(((x+z)>0).sum())); done=True; break
            if done: break
print(f"adjacent-void complete-qubit units: {units}; support sizes: {sizes}  [expect 384, {{5}}]")
print("PASS if k=130, 127+3, local ranks {0}, 5-edge units.")
