"""stitch_protocol_retry_decoherence.py -- Sec. 4. Monte-Carlo repeat-until-success:
first-attempt F~1; any retry F->0.5; cycle counts balloon. Requires numpy."""
import numpy as np
rng=np.random.default_rng(2)
I=np.eye(2); X=np.array([[0.,1],[1,0]]); Y=np.array([[0,-1j],[1j,0]]); Z=np.diag([1.,-1])
def ap(v,op,i,N):
    v=v.reshape((2,)*N); v=np.tensordot(op,v,axes=([1],[i])); return np.moveaxis(v,0,i).reshape(-1)
def run(N,theta,a,b,trials=300,maxcyc=3000):
    import functools
    u=np.cos(theta/2)*I-1j*np.sin(theta/2)*Y; zt=u@Z@u.conj().T
    k0=u@np.array([1,0.]); k1=u@np.array([0,1.])
    L0=functools.reduce(np.kron,[k0]*N); L1=functools.reduce(np.kron,[k1]*N)
    tgt=a*L0+b*L1; tgt/=np.linalg.norm(tgt)
    psi0=np.zeros(2**N,complex); psi0[0]=a; psi0[-1]=b; psi0/=np.linalg.norm(psi0)
    def measure(v,op,i):
        w=ap(ap(v,op,i,N),op,i+1,N)
        vp=(v+w)/2; pp=np.vdot(vp,vp).real
        if rng.random()<pp: return vp/np.sqrt(pp),+1
        vm=(v-w)/2; return vm/np.sqrt(max(np.vdot(vm,vm).real,1e-300)),-1
    res=[]
    for _ in range(trials):
        v=psi0.copy()
        for cyc in range(1,maxcyc+1):
            synd=[]
            for i in range(N-1):
                v,s=measure(v,zt,i); synd.append(s)
            if all(x==1 for x in synd):
                res.append((cyc,abs(np.vdot(tgt,v))**2)); break
            fl=False
            for i in range(N-1):
                v,s=measure(v,Z,i)
                if s==-1: fl=not fl
                if fl: v=ap(v,X,i+1,N)
    return np.array(res)
for (N,th) in [(7,1.2),(9,0.8)]:
    r=run(N,th,2**-.5,2**-.5)
    first=r[r[:,0]==1]; retry=r[r[:,0]>1]
    print(f"N={N} theta={th}: mean cycles={r[:,0].mean():.1f} (naive {np.cos(th/2)**(-2*N):.1f});"
          f" F(first)={first[:,1].mean() if len(first) else float('nan'):.3f};"
          f" F(retried)={retry[:,1].mean() if len(retry) else float('nan'):.3f}")
print("PASS if F(first)~1 and F(retried)~0.5: measurement-based crossing decoheres.")
