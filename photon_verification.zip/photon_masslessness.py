"""
photon_masslessness.py  --  why the shared-node coupling cannot mass the photon. [Paper Sec. 4]
Reproduces: <110> centrosymmetric (rank-1 and rank-3 moments = 0); <111> non-centrosymmetric
(rank-3 nonzero = zincblende d14); the coupling is strain x FIELD STRENGTH (d symmetric in the
two strain indices) not strain x potential; and a uniform displacement sources no net gauge potential.
Requires: numpy
"""
import numpy as np, itertools
n=np.array([v for v in itertools.product([-1,0,1],repeat=3) if sum(abs(x) for x in v)==2],float)
n/=np.linalg.norm(n,axis=1,keepdims=True)                      # 12 <110> bonds
m=np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]],float); m/=np.linalg.norm(m,axis=1,keepdims=True)  # 4 <111>

print("[<110> gravity network]  centrosymmetric O_h:")
print("   rank-1 moment sum(n)      =", np.round(n.sum(0),6), " -> 0")
print("   rank-3 moment max|sum nnn|=", round(np.abs(np.einsum('ai,aj,ak->ijk',n,n,n)).max(),6),
      " -> 0  (no linear coupling to the gauge potential A)")

d=np.einsum('ai,aj,ak->ijk',m,m,m)
print("\n[<111> gauge network]  non-centrosymmetric T_d:")
print("   rank-3 moment max|sum mmm|=", round(np.abs(d).max(),4), " -> nonzero (zincblende d14)")
print("   d symmetric in strain indices (j,k)?", np.allclose(d,np.transpose(d,(0,2,1))),
      " -> coupling is eps_jk E_i (field strength), gauge invariant; NOT eps_jk A_i")

print("\n[gauge potential sourced by a uniform node displacement]")
print("   sum of the 4 <111> bond vectors =", np.round(m.sum(0),6), " -> 0 (no net A sourced)")
print("\n=> A_mu A^mu is gauge-forbidden; the induced coupling is gauge invariant; photon stays massless.")
