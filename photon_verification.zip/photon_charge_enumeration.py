"""
photon_charge_enumeration.py  --  emergent charge and color counts. [Paper Sec. 3, 5]
Reproduces: the 16-state coordination-4 ice-vertex charge spectrum {-4,-2,0,+2,+4}
(integer, no thirds); the K4 perfect-matching count (=3, the color qutrit);
and the failed geometric-angle = Weinberg-angle shortcut.
Requires: numpy
"""
import numpy as np, itertools
from collections import Counter

print("Coordination-4 ice vertex (each bond +in / -out), 2^4 = 16 states:")
cnt=Counter(sum(c) for c in itertools.product([+1,-1],repeat=4))
for Q in sorted(cnt,reverse=True):
    nin=(Q+4)//2; print(f"  {nin}-in/{4-nin}-out : {cnt[Q]:2d} states, Q={Q:+d}")
print("  spectrum:", sorted(cnt), "-> integer monopole charge, NO thirds\n")

edges=list(itertools.combinations(range(4),2)); pm=[]
for combo in itertools.combinations(edges,2):
    u=set()
    if all(not(e[0] in u or e[1] in u) and (u.update(e) or True) for e in combo) and len(u)==4: pm.append(combo)
print("K4 perfect matchings:", len(pm), "->", pm, " (=3 -> color qutrit; independent of the 4-fold flux count)\n")

ang=np.arccos(np.sqrt(2/3))
print(f"<110>-<111> angle = {np.degrees(ang):.2f} deg -> sin^2(theta_W) 'shortcut' = {np.cos(ang)**2:.3f}")
print(f"  measured sin^2(theta_W)=0.231 and RUNS with energy -> shortcut FAILS (recorded to close it)")
