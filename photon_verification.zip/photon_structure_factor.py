"""
photon_structure_factor.py  --  Coulomb-phase signatures on the <111> pyrochlore. [Paper Sec. 2]
Reproduces: the extensive ice-rule soft-mode manifold and the transverse character of the
emergent field (longitudinal fluctuations frozen, L/T -> 0) -- the emergent-gauge-field / photon
precursor.  (The pinch-point map itself is produced by photon_figures.py.)
Requires: numpy
"""
import numpy as np, itertools
L=8
A=np.array([p for p in itertools.product(range(L),repeat=3) if sum(p)%2==0],float)
def wrap(x): return np.mod(x,L)
dirs=np.array([[.5,.5,.5],[.5,-.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5]])
pyro=[]; easy=[]; sid={}
def gs(mid,dd):
    k=tuple(np.round(mid,3))
    if k not in sid: sid[k]=len(pyro); pyro.append(mid); easy.append(dd/np.linalg.norm(dd))
    return sid[k]
up=[[gs(wrap(a+dd/2),dd) for dd in dirs] for a in A]
B=wrap(A+0.5)
down=[[sid[tuple(np.round(wrap(b-dd/2),3))] for dd in dirs if tuple(np.round(wrap(b-dd/2),3)) in sid] for b in B]
pyro=np.array(pyro); easy=np.array(easy); N=len(pyro)
rows=[t for t in up]+[t for t in down if len(t)==4]
D=np.zeros((len(rows),N))
for r,tet in enumerate(rows): D[r,tet]=1.0
rank=np.linalg.matrix_rank(D)
print(f"pyrochlore cluster: N = {N} sites, {D.shape[0]} ice constraints, rank {rank}")
print(f"  soft-mode manifold dim = {N-rank}  (extensive -> emergent continuous gauge field)")
P=np.eye(N)-np.linalg.pinv(D)@D
def Mcorr(k):
    ph=np.exp(-1j*(pyro@k)); F=easy*ph[:,None]; return (F.conj().T@P@F).real
km=2*np.pi/L
print("\ntransverse test (longitudinal/transverse ratio at smallest commensurate |k|):")
for name,kh in [("[100]",[1,0,0]),("[110]",[1,1,0]),("[111]",[1,1,1])]:
    kh=np.array(kh,float); kh/=np.linalg.norm(kh); Mk=Mcorr(km*kh)
    Lc=kh@Mk@kh; Tc=np.trace(Mk)-Lc
    print(f"  {name}:  L/T = {Lc/max(Tc,1e-9):.3f}   (-> 0 = transverse; 0.5 = trivial/isotropic)")
print("  longitudinal frozen -> two transverse polarizations = emergent photon precursor")
