"""
photon_dielectric.py  --  strain renormalization of the emergent dielectric constant. [Paper Sec. 4]
Reproduces: delta_epsilon = g^2 d C^{-1} d is ISOTROPIC (no birefringence) and POSITIVE (slows light),
with shear compliance S44 = 1/2 and delta_epsilon = 0.593 g^2 * Identity.
Requires: numpy
"""
import numpy as np, itertools
n=np.array([v for v in itertools.product([-1,0,1],repeat=3) if sum(abs(x) for x in v)==2],float)
n/=np.linalg.norm(n,axis=1,keepdims=True)
C=np.einsum('ai,aj,ak,al->ijkl',n,n,n,n)                       # <110> central-force stiffness
m=np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]],float); m/=np.linalg.norm(m,axis=1,keepdims=True)
d=np.einsum('ai,aj,ak->ijk',m,m,m)                            # <111> piezoelectric tensor

def sym(a,b):
    E=np.zeros((3,3)); E[a,b]+=1; E[b,a]+=1; return E/np.linalg.norm(E)
B=[np.diag([1,0,0.]),np.diag([0,1,0.]),np.diag([0,0,1.]),sym(1,2),sym(2,0),sym(0,1)]  # xx,yy,zz,yz,zx,xy
M=np.array([[np.einsum('ijkl,ij,kl->',C,B[a],B[b]) for b in range(6)] for a in range(6)])
Minv=np.linalg.inv(M)
v=np.array([[np.einsum('jk,jk->',d[i],B[mu]) for mu in range(6)] for i in range(3)])
deps=v@Minv@v.T
print("shear compliance S44 = (M^-1)_44 =", round(Minv[3,3],4), " (expected 0.5)")
print("delta_epsilon / g^2 :")
print(np.round(deps,4))
print("isotropic (proportional to identity)?", np.allclose(deps,deps[0,0]*np.eye(3)),
      " off-diagonal zero -> NO birefringence")
print("eigenvalues:", np.round(np.linalg.eigvalsh(deps),4), " all equal & > 0 -> slows light (delta_eps>0)")
