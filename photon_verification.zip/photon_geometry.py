"""
photon_geometry.py  --  FCC sublattice geometry underlying the coexistence paper.
Reproduces: the non-bipartite <110> network; the bipartite <111> diamond (coord 4);
the pyrochlore bond-midpoint lattice (coord 6); the cuboctahedron face split
(6 squares along <100>, 8 triangles along <111>).  [Paper Secs. 1-2, 5]
Requires: numpy, scipy
"""
import numpy as np, itertools
from collections import deque, defaultdict
from scipy.spatial import ConvexHull

def bipartite(sites, d2):
    S=np.array(sites,float); n=len(S); adj={i:[] for i in range(n)}
    for i in range(n):
        nb=np.where(np.abs(np.sum((S-S[i])**2,axis=1)-d2)<1e-6)[0]
        adj[i]=[j for j in nb if j!=i]
    color={}
    for s in range(n):
        if s in color: continue
        color[s]=0; q=deque([s])
        while q:
            u=q.popleft()
            for v in adj[u]:
                if v not in color: color[v]=color[u]^1; q.append(v)
                elif color[v]==color[u]: return False
    return True

# --- <110> nearest-neighbor network (code + gravity sector) ---
fcc=[p for p in itertools.product(range(4),repeat=3) if sum(p)%2==0]
print("[<110> network]  bipartite:", bipartite(fcc,2), " (False -> triangular odd cycles; gapped Z2, no photon)")

# --- <111> diamond (FCC sites + tetrahedral-void sublattice) ---
A6=np.array([p for p in itertools.product(range(8),repeat=3) if sum(p)%2==0],float)
B6=A6+np.array([0.5,0.5,0.5]); dia=np.vstack([A6,B6])
print("[<111> diamond]  bipartite:", bipartite(np.vstack([np.array(fcc,float),
      np.array(fcc,float)+0.5]),0.75), " coordination 4 (charge lattice, hosts photon)")

# --- pyrochlore = diamond bond-midpoints; coordination 6 (use a large box, take interior) ---
dirs=np.array([[.5,.5,.5],[.5,-.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5]])
pin=set()
for a in A6:
    for dd in dirs: pin.add(tuple(np.round(a+dd/2,3)))
pin=np.array(sorted(pin))
# nearest-neighbor separation among midpoints:
c0=pin[np.argmin(np.sum((pin-pin.mean(0))**2,axis=1))]   # a central midpoint
d2all=np.sum((pin-c0)**2,axis=1); d2all=d2all[d2all>1e-9]; d2=d2all.min()
# count neighbors of several central points against the FULL set (no window clipping):
central=pin[np.all(np.abs(pin-pin.mean(0))<1.2,axis=1)]
co=[int(np.sum(np.abs(np.sum((pin-p)**2,axis=1)-d2)<1e-6)) for p in central]
print("[pyrochlore]     nn d^2 =",round(d2,3),"coordination mode:", int(np.bincount(co).argmax()), " (expected 6, corner-sharing tetrahedra)")

# --- cuboctahedron faces: 6 squares <100>, 8 triangles <111> ---
V=np.array([v for v in itertools.product([-1,0,1],repeat=3) if sum(abs(x) for x in v)==2],float)
V=V/np.linalg.norm(V,axis=1,keepdims=True); h=ConvexHull(V)
faces=defaultdict(set)
for simp,eq in zip(h.simplices,h.equations): faces[tuple(np.round(eq[:3],3))].update(simp.tolist())
nsq=sum(1 for vs in faces.values() if len(vs)==4); ntri=sum(1 for vs in faces.values() if len(vs)==3)
print(f"[cuboctahedron]  {nsq} square faces (<100>, SU(2)xU(1) sector), {ntri} triangular (<111>, SU(3) sector)")
