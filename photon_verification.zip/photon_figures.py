"""
photon_figures.py  --  regenerate the two paper figures. [Paper Figs. 1-2]
fig_sublattices.pdf : <110> (non-bipartite) vs <111> (bipartite) comparison.
fig_pinch.pdf       : (hhl) emergent-field structure factor with pinch points.
Requires: numpy, matplotlib   (writes PDFs to the current directory)
"""
import numpy as np, itertools
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
mpl.rcParams.update({"font.family":"serif","mathtext.fontset":"dejavuserif","savefig.dpi":300})

# ---- structure factor on a periodic pyrochlore (produces the pinch-point map) ----
L=8
A=np.array([p for p in itertools.product(range(L),repeat=3) if sum(p)%2==0],float)
def wrap(x): return np.mod(x,L)
dirs=np.array([[.5,.5,.5],[.5,-.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5]])
pyro=[]; easy=[]; sid={}
def gs(mid,dd):
    k=tuple(np.round(mid,3))
    if k not in sid: sid[k]=len(pyro); pyro.append(mid); easy.append(dd/np.linalg.norm(dd))
    return sid[k]
up=[[gs(wrap(a+dd/2),dd) for dd in dirs] for a in A]
B=wrap(A+0.5)
down=[[sid[tuple(np.round(wrap(b-dd/2),3))] for dd in dirs if tuple(np.round(wrap(b-dd/2),3)) in sid] for b in B]
pyro=np.array(pyro); easy=np.array(easy); N=len(pyro)
D=np.zeros((len(up)+len([t for t in down if len(t)==4]),N)); r=0
for tet in up: D[r,tet]=1; r+=1
for tet in down:
    if len(tet)==4: D[r,tet]=1; r+=1
P=np.eye(N)-np.linalg.pinv(D)@D
def Sraw(k):
    w=np.exp(-1j*(pyro@k)); return float(np.real(w.conj()@P@w)/N)
ext=4*np.pi; ng=61; ax=np.linspace(-ext,ext,ng)
img=np.array([[Sraw(np.array([h,h,l])) for h in ax] for l in ax])
fig,a=plt.subplots(figsize=(4.6,4.0))
im=a.imshow(img,origin="lower",extent=[-ext/np.pi,ext/np.pi,-ext/np.pi,ext/np.pi],cmap="magma",aspect="equal")
a.set_xlabel(r"$(h\,h\,0)$ [$\pi$]"); a.set_ylabel(r"$(0\,0\,l)$ [$\pi$]")
a.set_title("Emergent-field structure factor $S(\\mathbf{k})$\n(hhl) plane -- pinch points",fontsize=9)
fig.colorbar(im,ax=a,fraction=0.046,pad=0.04); plt.tight_layout()
plt.savefig("fig_pinch.pdf",bbox_inches="tight"); plt.close()
print("wrote fig_pinch.pdf  (structure factor, N =",N,"sites)")
print("(fig_sublattices.pdf is a schematic; see the paper source for its generator)")
