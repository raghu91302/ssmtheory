# photon_verification

Reproduction scripts for the computed results in
**"Symmetry-Protected Masslessness of an Emergent U(1) Photon Coexisting with a
Gravitational Network on the FCC Vacuum"** (SSM series).

All quantities in the paper are computed from the FCC lattice geometry; there is no
external or measured dataset. Each script is standalone and prints the paper's stated
result.

## Requirements
Standard scientific Python: `numpy`, `scipy` (convex hull), `matplotlib` (figures).
No other dependencies. Tested on Python 3.

## Scripts (run any with `python3 <name>.py`)

| Script | Reproduces | Paper |
|---|---|---|
| `photon_geometry.py` | <110> non-bipartite; <111> diamond bipartite (coord 4); pyrochlore (coord 6); cuboctahedron 6 squares <100> / 8 triangles <111> | Secs. 1-2, 5 |
| `photon_structure_factor.py` | extensive ice-rule soft manifold (513 of 1024); transverse test L/T -> 0 | Sec. 2 |
| `photon_charge_enumeration.py` | 16-state ice-vertex charges {-4,-2,0,+2,+4} (integer, no thirds); K4 = 3 matchings (color qutrit); theta_W shortcut refutation | Secs. 3, 5 |
| `photon_masslessness.py` | <110> centrosymmetric (odd moments 0); <111> T_d (rank-3 = d14); coupling eps*E not eps*A; no net A sourced | Sec. 4 |
| `photon_dielectric.py` | delta_epsilon = g^2 d C^-1 d = 0.593 g^2 * I (isotropic, no birefringence; positive, slows light); S44 = 0.5 | Sec. 4 |
| `photon_figures.py` | regenerates `fig_pinch.pdf` (structure-factor map) | Fig. 2 |

## Notes
- The `g^2` in the dielectric result is the (free, microscopic) magnetoelastic coupling;
  the geometry fixes the tensor structure and sign, not the magnitude.
- Coordination/soft-manifold counts use finite periodic or large-box clusters; values are
  the bulk (interior) results.
