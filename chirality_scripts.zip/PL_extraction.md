# P_L Prerequisite 1 - Extraction Record (Matter paper)

Source: R. Kulkarni, Phys. Open 27 (2026) 100423. Read against
PL_protocol.md (Amendment 1). Date: August 30, 2026. This record
completes the Matter-paper half of Prerequisite 1.

## A. The Lift, as the paper defines it (Sec. 2.3)

- Lift places a node above the centroid of a triangular face at the
  unique height h = sqrt(2/3) L (three-unit-sphere intersection).
- The solution set is a 0-parameter APEX PAIR - above and below the
  face - "of which one is selected by orientation." The orientation
  selection is therefore part of the Lift's published definition.
- P_lift = e^-3, suppressed by codimension; lifts are the rare events
  that weld sheets (mean inter-layer bond count 4.9 per node).
- Fig. 1: K = 12 = 6 in-plane (Stitch) + 3 upper (Layer C, z = +h,
  "reached by lift") + 3 lower (Layer A, z = -h, "the mirror lift").
  The upper/lower triads are the two sheets of the orientation
  doublet.

## B. The defect, as the paper defines it (Secs. 3-4)

- Extra node at the tetrahedral-void centroid, bonded to the 4
  bounding vertices; 1 anchor + 3 valence under the host embedding.
- The two void orientations (a/4- and 3a/4-centered) are related by
  spatial inversion; anchor choice is dynamical.
- PUBLISHED SUPPORT FOR HYPOTHESIS H (Sec. 4.4, verbatim content):
  the two void orientations are "the geometric origin of matter and
  antimatter, and the local cosmological excess of one orientation
  over the other selects the observed matter-dominated universe."
  The reservoir-for-the-sign idea is therefore already in print in
  the series; H extends it from matter selection to chirality
  selection by the same front.

## C. The hop, constructed from the Lift (per Amendment 1)

The paper defines growth, not defect motion; but the Lift determines
the hop up to the code dictionary:

- hop_up: the defect re-bonds from its current sheet to the adjacent
  UPPER sheet through a Lift-type triangular face (Layer C side).
  In code terms its support lies on edges whose checks are PENDING
  (structure created by the most recent growth events; verification
  not yet applied).
- hop_down: the defect re-bonds to the LOWER sheet through the
  mirror-Lift face (Layer A side). Support lies on edges whose
  checks are COMMITTED (stabilizers projected; the verified past).
- The environments differ ONLY in check status; geometry is
  identical by the paper's own inversion pairing (Theorem 1 of the
  F4-to-E6 paper reconstructs this).

## D. What MEI must still supply (second half of Prerequisite 1)

The dictionary defect <-> code excitation: how the extra node and its
four bonds are represented on the edge-qubit CSS code (which edges,
which checks see the defect), and the charge table. Without it, any
explicit hop operator would be a stand-in, which the protocol
forbids. MEI upload = the last input before Steps 1-4 run.

## E. Status

- Prerequisite 2 (code rebuild): COMPLETE (fcc_code.py, 6x PASS).
- Prerequisite 1, Matter half: COMPLETE (this record).
- Prerequisite 1, MEI half: PENDING (upload in the execution
  session).
- Steps 1-4 + controls C1-C3: NOT STARTED; to run in a fresh session
  under the locked criteria, never in a depleted context.

---

## F. MEI extraction (Phys. Open 27, 100414) - completes Prerequisite 1

Date: August 30, 2026.

**The defect <-> code dictionary.** Particles are localized syndrome
patterns on the [[192,130,3]] code. The footprint is a set of EDGES
(qubits) of the 13-node coordination cluster C13; the detecting
constraints are the vertex stabilizers plus the face structure
(C_s = f0 + f2). Explicitly: electron = single edge (E_s=1, C_s=1);
pion = 2-sheet, E_s=16, C_s=17 (+1 closing string); muon = 3-sheet
EM sector, 36 x 6 - 9; proton = full cluster, E_s=36, C_s=51,
dim(B)=1836; neutron = 1836 + D=3 internal probes. The coupling
matrix B (36 x 51, nnz=192, BB^T = edge Hodge Laplacian) is
constructible from fcc_code.py's H_Z, H_X plus the cluster face data.

**For the hop.** The baryon defect's code support is the full C13
cluster (E_s = 36). The doublet hop's two channels are the anchor
vertex's upper-triad edges (Layer C side) versus lower-triad edges
(Layer A side); which checks contain each edge is read directly from
H_Z (vertex checks) and H_X (octahedral checks) in fcc_code.py. All
objects for Steps 1-4 now exist on disk.

**DEFINITIONAL CAUTION (resolve before Step 1).** The two papers use
two different sheet decompositions of K=12: the Matter paper's
close-packed layering 6+3+3 (Layers A/B/C - the orientation doublet
of hypothesis H) and MEI's three orthogonal 2D sheets of 4 (the
verification-cost bookkeeping). The hop environments MUST be defined
in the Matter-paper layering; MEI's orthogonal sheets enter only
through C_s counting. Conflating them would silently change the
doublet. The execution session states which decomposition each
object uses before any computation runs.

**Side effect - a standing debt cleared.** The merged paper's one
[imported] tag (defects occupy glue classes) is verified against
source: the Matter paper (Sec. 3.1-3.2) places the extra node at the
tetrahedral-void centroid, and the tetrahedral voids are the
glue-class sites of the D4 home. The import is sound. The Paper 6
interstitial battery (added-node vs vacancy) remains open and is NOT
run here.

## G. Final status

- Prerequisite 1: COMPLETE (Matter + MEI extracted, this record).
- Prerequisite 2: COMPLETE (fcc_code.py, 6x PASS).
- Steps 1-4 + controls C1-C3: READY, NOT STARTED. Per Section E,
  they run in a fresh session under the locked criteria. Opening
  moves: resolve the sheet-decomposition caution; build the hop on
  H_Z/H_X; run with C1-C3; judge by Section 4 outcomes only.

---

## H. Step 0 executed + the Step-1 fork (working note, pre-execution)

Date: August 30, 2026. Steps 1-4 remain NOT RUN.

**Step 0 resolved.** On the verified L=4 code: the 12 neighbors split
6+3+3 along (1,1,1) with upper triad {(1,1,0),(1,0,1),(0,1,1)} and
lower triad the negatives - the Matter-paper doublet, confirmed
disjoint from MEI's 4+4+4 orthogonal decomposition. Object table
built at a bulk node: each triad edge participates in exactly 2
vertex-checks and 2 octahedral-checks, symmetric between up and down
as inversion requires. All indices on record in the transcript.

**The Step-1 fork.** Two formalizations of the hop exist, and the
choice is THE decision of Step 1:

(a) Pauli-syndrome motion (defect = violated checks on fixed qubits;
hop = X-string). VERIFIED FACT: a single-edge X-hop anticommutes
with exactly its two endpoint vertex checks (source and target of
the defect - its own syndrome) and commutes with every octahedral
check and every other vertex check. It therefore disturbs NO
environment stabilizer, committed or pending: the environments are
indistinguishable and the computation returns Outcome B trivially.
RULING: this is a modeling artifact, not a physics verdict. The
Matter paper's defect is a structural extra node with four bonds -
new qubits - not a syndrome on fixed qubits. Formalization (a) is
model-unfaithful and is EXCLUDED as the basis for the verdict. It
survives only as control C0: any pipeline must reproduce its null.

(b) Structural re-bonding (hop = destroy the four bonds, create four
new bonds at the adjacent void - the Lift/un-stitch machinery). This
engages the environment: a created or destroyed bond changes the
support of the weight-12 checks containing it, and on the committed
side those checks hold projected eigenvalues that constrain the
process; on the pending side they do not. This is the model-faithful
formalization and the one Steps 1-4 must use. It requires a bond
creation/annihilation formalism on the code - defining it cleanly is
the execution session's first construction, done fresh, with the
initialization state of a new bond taken from the growth rule (or
documented as a declared choice if the papers underdetermine it).

**Why execution still waits.** The verdict now rests entirely on a
formalism not yet defined. Defining it in a depleted context, with
the desired outcome known, is the April condition. The execution
session builds (b), runs C0/C1/C2/C3 and the physical configuration,
and judges by Section 4 of the protocol. Nothing else remains before
it.

---

## I. EXECUTION RECORD - Steps 1-4 run (August 30, 2026)

**Model M1, declared before the numbers:** fresh bond in |+> (Bell-bond
convention); committed = vertex checks at layers <= frontier,
projected; each bond created or destroyed at a committed interface
costs 1/2 in syndrome-free probability; pending interfaces free;
A^2 = (1/2)^(n_c). Hop = tetra -> octa -> tetra (the corrected
adjacency: tetra voids share faces only with octahedra - the X-check
sites sit in every hop path). Endpoint bond bookkeeping; single
sampled up-void; amplitudes averaged over the 28 geometric paths.

**Results (L=4, defect at up-void, frontier at base layer):**
- PHYSICAL: A_up = 0.500, A_down = 0.268, polarization
  P = (A_up - A_down)/(A_up + A_down) = +0.302.
- C1 (all committed / static crystal): P = 0.000 exactly; up and
  down n_c distributions identical {4,6,8} - the published static
  centrosymmetry obstruction reproduced in the numbers.
- C2 (all pending): all amplitudes 1; P = 0.000.
- C3 (frontier inverted): P = -0.305 - sign reversed, magnitude
  matched. The sign comes from the front, not the construction.

**VERDICT (per Section 4, no reinterpretation):**
- Not Outcome A: A_down = 0.268 != 0, and the suppression is a fixed
  per-step ratio, not code-distance-scaling.
- Not Outcome B: A_up != A_down by a factor 1.87.
- **OUTCOME C: the chiral structure is OBTAINED IN MODIFIED FORM.**
  The induced doublet generator is A_up sigma+ + A_down sigma-:
  a genuinely parity-violating coupling (nonzero sigma_y component,
  now DYNAMICALLY derived, upgrading the kinematic sigma_y of the
  worldline paper), chirally weighted at P = 0.30 per step, but not
  the clean projector P_L (which requires P = 1).

**Characterization of the partial structure (recorded, not decided):**
the per-step asymmetry compounds along a worldline as
(A_up/A_down)^n ~ 1.87^n: the defect statistically rides the growth
front. Whether this compounding yields an effective P_L in the
continuum limit is the follow-up computation; deciding it tonight
would be rounding up to Outcome A, which Section 4 forbids.

**Model-dependence caveats (binding on any write-up):** the |+>
initialization, the 1/2-per-interface rule, endpoint-only counting
(octahedral transit not separately costed), one sampled void
orientation, mean-over-paths aggregation. Robustness of P = 0.30
under these declared choices is untested. The RESULT that survives
all four configurations regardless of these choices: asymmetry
exists iff a frontier exists, with sign set by the front.

**Queued next:** (1) M1 robustness sweep (init state, costing rule,
octa transit, down-void defect); (2) the compounding/continuum
analysis; (3) only then, drafting - under the vocabulary of rule 5.

---

## J. Hypothesis H2 registered (August 30, 2026 - before its test runs)

**H2 (sequential handedness and the circuit phase).** The syndrome
circuit that gathers a weight-12 check must traverse the shell in
SOME cyclic order; the two routing classes (handed about the growth
axis) exist and are exchanged by spatial inversion (verified,
choice-free). H2 asserts: (a) the first executed circuit at a
defect's birth fixes the class; (b) worldline memory: subsequent
QEC updates must preserve the recorded sequence (topological lock);
(c) REQUIRED for viability - the birth choice is inherited from the
GLOBAL growth sequence (the front's own operational order), never
drawn per defect; a per-defect choice predicts handedness-mixed
matter and is falsified at once; (d) the two routing classes
accumulate different geometric phases through the out-of-plane
(sigma_y) sector, and if the class difference is pi mod 2pi, a
strict +/-1 is injected: the operational origin of the Matter
paper's empirical winding restriction w in {0,+1} (Eq. 9), and of
the integer unit the charge fence proved cannot be a Cartan charge.

**Pre-specified test (to run in the robustness session, not
tonight):** define the doublet transport rule for one out-of-plane
segment ONCE, from the Lift geometry, before computing any phase;
compute the accumulated phase for at least 6 representative paths in
EACH routing class. PASS if the phase is class-constant
(path-independent within a class = genuinely topological) AND the
class difference is pi mod 2pi. FAIL if path-dependent (artifact) or
unquantized (no strict unit). Either result publishes.

**Consistency notes on record:** H2 supplies exactly the non-Cartan
origin the charge fence demanded; it is independent of M1's
commit-status resource (two selection mechanisms, possibly
cooperating: candidate P=0.30 completer); the skeleton facts
(routing classes exist, inversion exchanges them, closed loops with
6 out-of-plane visits) are verified above.

## J'. Correction to J, from the skeleton check itself

The claim "inversion exchanges the routing classes" is FALSE and the
check caught it: spatial inversion acts on the projection plane as a
rotation by pi, which PRESERVES planar circulation (verified:
handedness +1 -> +1). What inversion actually flips is the
out-of-plane visit pattern (z-steps negate). The two routing classes
(clockwise vs counterclockwise circuits) are exchanged by CIRCUIT
REVERSAL - running the gather sequence backward, the operational
time-reversal - and by reflection, not by P.

Consequence for H2 (recorded, not yet exploited): the circuit
direction is an operational T-ODD, P-even choice - an arrow of
operation. The class-dependent phase of H2(d) therefore couples the
circuit arrow to the growth arrow (both T-odd), and the correct
discrete-symmetry bookkeeping of the accumulated phase under P, T,
and PT is hereby added to the pre-specified test: the phase's parity
under each must be COMPUTED, not assumed, and any chirality claim
must survive that bookkeeping. This tightens H2 rather than wounding
it: "chirality from chronology" now enters twice - the front's arrow
and the circuit's arrow - and the test decides whether they lock.

---

## K. EXECUTION RECORD - robustness sweep + continuum analysis

**(1) Robustness (queued item 1): DONE.** Polarization stays positive
in every physical variant: cost rule c=1/4 -> P=+0.54, c=1/2 ->
+0.30, c=3/4 -> +0.13; octa transit costed -> +0.37; down-void
defect -> +0.41; frontier placement irrelevant (+0.302 both).
C1 = 0.000 under all choices; C3 sign-flips throughout. VERDICT:
sign and front-iff are model-robust; the magnitude is
model-dependent in [0.13, 0.54] as declared.

**(2) Compounding/continuum (queued item 2): DONE, decisive.** The
effective worldline dynamics is directed hopping - the
Hatano-Nelson class. Computed:
- PHYSICAL: spectral winding W = +1 (point-gap topological
  invariant); finite-chain modes pile at the frontier end (center
  37.6/39): the non-Hermitian skin effect. "Rides the front" is now
  a topological statement.
- C1 static: W = 0, delocalized. C3 inverted: W = -1, piled at the
  opposite end.
- W depends only on sign(A_up - A_down), so it is +1 across the
  ENTIRE robustness sweep: the soft per-step polarization feeds a
  STRICT, QUANTIZED, MODEL-ROBUST +/-1 set by the front.
- NN guard: the dynamics is non-Hermitian (measurement
  irreversibility), outside Nielsen-Ninomiya's assumptions; point-gap
  winding has no Hermitian counterpart; no doubler restores the
  symmetry.

**Characterization of Outcome C, completed:** the chiral structure is
obtained as POINT-GAP TOPOLOGY - an exact winding number +/-1,
front-signed, model-robust - rather than as an amplitudinal
projector. The strict integer the program hunted exists in the
worldline spectrum.

**Boundaries (binding):** W = +1 is a statement about defect
transport, not yet about the gauge vertex; equating it with SU(2)_L
left-handedness awaits the bridge (queued item 4). Whether W is
also the H2 charge-unit integer awaits item 3. Both remain
pre-specified and unrun.

---

## L. EXECUTION RECORD - H2 phase test and the bridge (final items)

**(3) H2 phase test: FAIL, as pre-specified.** Transport rule declared
once (spin-1/2 of the growth direction, parallel transport, Berry
phase = -solid angle/2; no further choices). Results: the canonical
circuit gives phase exactly pi (a strict -1 exists), BUT (a)
within-class spread 0.55 rad under path perturbations - NOT
class-constant, hence not topological in the required sense; and (b)
the two routing classes give the SAME phase mod 2pi (reversal sends
pi -> -pi = pi) - no class discrimination. VERDICT, locked
vocabulary: the H2 circuit-phase mechanism for the integer unit is
EXCLUDED BY COMPUTATION under the declared rule. The universal -1
(hemisphere phase) is recorded as a curiosity, unhanded and
unexploited. This negative publishes with everything else.

**(4) The bridge: DONE.** Per-step vertex = 0.384 sigma_x +
i 0.116 sigma_y: a V - lambda*A structure with lambda = P = 0.30
(model-dependent, 0.13-0.54). Transmission chirality over n steps:
P_T = (a^n-b^n)/(a^n+b^n) -> 1 exponentially; right-handed
admixture (b/a)^-n: 4x10^-2 at n=5, 2x10^-3 at n=10, 4x10^-6 at
n=20, 10^-11 at n=40. STATEMENT: the vertex is partially chiral per
step; PROPAGATION is asymptotically exactly chiral.
FALSIFIER-SHAPED PREDICTION (recorded): right-handed couplings are
exponentially suppressed but never exactly zero at finite
verification depth - a structural difference from the Standard
Model's exact zero. The physical value of n (verification depth per
interaction) is NOT determined here; only the nonzero-exponential
character is claimed.

## M. Program state at close

DERIVED: dynamical parity violation (front-signed, iff-front,
model-robust in sign). OBTAINED IN MODIFIED FORM: chirality as exact
point-gap topology (W = +/-1, Hatano-Nelson class, skin effect =
riding the front) plus asymptotically exact transmission chirality;
per-step vertex V - 0.30 A. EXCLUDED: the H2 circuit-phase origin of
the integer unit (declared rule); the Pauli-hop formalization (C0).
OPEN: the physical verification depth n; the operational meaning of
W versus the Matter paper's winding w (flagged, not claimed); H2's
universality requirement if any variant of it returns. All
computations pre-registered; every verdict in locked vocabulary;
negatives recorded beside positives. Drafting, when it comes, uses
rule 5's words and includes Section L's FAIL.
