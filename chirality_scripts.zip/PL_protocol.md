# The Chiral Projection: Pre-Registered Computation Protocol

**Series:** Selection-Stitch Model, electroweak program.
**Status:** written BEFORE the computation. Nothing below may be
revised after the first computation cell runs, except by adding
dated amendments that leave the original text intact.
**Date locked:** August 30, 2026.

---

## 1. The hypothesis under test

**H (creation-front chirality).** Parity violation is the local trace
of cosmogenesis. The crystallization front that created the patch laid
every node down with the same local order: lower sheet first (then
verified and committed), upper sheet after (verification pending). The
code's dynamics couples to undecided structure only, because committed
structure sits in stabilizer eigenstates and cannot respond. The
induced interlayer su(2) therefore acts through the projector onto the
pending sheet:

    P_L = (1/2)(1 + gamma_5),   gamma_5 = sigma_z on the orientation doublet.

The sign of "left" is the front sign: the propagation sense of the
crystallization wave, fixed at nucleation, shared by every node in the
domain.

**Consequences if H holds (recorded now, tested later, in order):**
1. The chiral projection is derived, not assumed; the vector su(2)
   obstruction of the worldline analysis is resolved.
2. The integer charge unit enters with T3 of the now-chiral factor;
   +2/3 becomes constructible (the charge fence predicted exactly
   this dependence).
3. Only interlayer (out-of-plane) physics violates P; in-plane physics
   (color, the Stitch) conserves it. This is a structural postdiction.
4. P_L anchors to temporal ordering, not to a spatial vector: Lorentz
   invariant at leading order, with foliation-anchored deviations that
   the dispersion program can bound. This is the falsifier H exports.

## 2. Prerequisites (must complete before Step 1)

- **MEI verification session.** Extract from the MEI paper (Phys. Open
  100414): the defect construction (extra node in a tetrahedral void),
  the V1b/V1c verification operators as actually defined, and the
  interlayer hop as the model defines it. No stand-ins. If the MEI
  paper does not define a hop operator, the hop must be constructed
  from the code's own stabilizer structure and the construction
  documented before use.
- **Code rebuild.** Rebuild the FCC CSS code from the published spec
  (arXiv:2603.20294): qubits on edges, weight-12 checks, tetrahedral
  logical structure. Verify [[192,130,3]] parameters at Ls=4 before
  any dynamics is defined on it.

## 3. The computation (fixed procedure)

**Step 1 - the doublet with environments.** Construct a minimal
two-layer patch: a defect site with its lower-sheet (committed) and
upper-sheet (pending) connections. Committed = the relevant stabilizers
projected to their eigenstates. Pending = the same structure, checks
not yet applied (maximally mixed over the check outcomes, or the
pre-measurement state the code's growth rule specifies - whichever the
MEI/CSS papers define; record which).

**Step 2 - the matrix elements.** Compute the interlayer hop matrix
elements in both directions:
    M_down = amplitude for the defect to move via the committed sheet,
    M_up   = amplitude for the defect to move via the pending sheet,
with identical geometry, differing only in environment state.

**Step 3 - the induced generator.** From (M_up, M_down), assemble the
induced 2x2 generator on the orientation doublet. Decompose into
identity, sigma_x, sigma_y, sigma_z components.

**Step 4 - the verdict.** Read the result against Section 4's
pre-registered outcomes. No reinterpretation.

**Competitor dynamics (must be run alongside, same session):**
- C1: both environments committed (static crystal) - expect vector
  su(2), no projection (this is the published static obstruction; it
  is the control).
- C2: both environments pending - expect vector su(2) (second control).
- C3: environments swapped (committed above, pending below) - expect
  the OPPOSITE projection if H holds. This tests that the sign comes
  from the front, not from the construction.

## 4. Pre-registered outcomes

- **Outcome A (H confirmed):** |M_down| = 0 exactly, or suppressed by
  a factor that scales with code distance, with C1/C2 showing no
  asymmetry and C3 showing the reversed sign. Then P_L is derived,
  the sign is the front sign, and the result paper may be drafted.
- **Outcome B (H refuted):** |M_up| = |M_down| within numerical
  precision in the physical configuration. Then the framework fails
  to produce the chiral projection by this mechanism. This result is
  PUBLISHED as a derived negative (the series' standing practice),
  and the electroweak program within the framework is downgraded
  accordingly. No alternative mechanism may be invented in the same
  session.
- **Outcome C (partial):** suppression that is real but neither exact
  nor distance-scaling (e.g., a fixed finite ratio, or a
  Ginsparg-Wilson-like modified relation instead of a clean
  projector). Then the partial structure is characterized and
  published as such. No rounding up to Outcome A.

## 5. Discipline rules (binding)

1. The computation derives existence, form, AND sign. If the sign has
   to be inserted by hand at any step, the step fails.
2. No parameter may be tuned after seeing results. The environments,
   the hop, and the patch size are fixed by the MEI/CSS definitions
   before Step 2 runs.
3. All three competitors C1-C3 run in the same session, results
   reported regardless of outcome.
4. If three sessions end at "almost," stop and publish the almost.
5. The words used in any resulting paper: Outcome A is "derived";
   Outcome C is "obtained in modified form"; Outcome B is "excluded by
   computation." No synonym inflation.
6. E7/E8 remain fenced regardless of outcome.

## 6. What this protocol is for

Every prior gap in the series fell to counting and symmetry. This one
is dynamical, the target is known and beloved, and that is the exact
condition under which the April failure mode operates. This document
exists so that the computation, when it runs, is judged by criteria
its authors could not adjust. If H survives this protocol, it will
deserve the claim. If it does not, the series keeps the thing it
actually trades on: results that were allowed to fail.

---

## Amendment 1 (August 30, 2026 - before any computation has run)

Prerequisite 1 is corrected. The primary upload for the P_L
computation is the **Matter paper** (Phys. Open 27, 100423), not MEI:
it defines the Stitch and Lift operators, the oriented Lift's
orientation selection, the growth dynamics that constitute the
creation-front hypothesis, and the extra-node defect. The interlayer
hop must be constructed from the Lift as defined there (falling back
to the stabilizer-structure contingency only if the Lift does not
determine it). The **MEI paper** (Phys. Open 100414) is requested in
the same session for the adjacent clauses: the defect/charge table
(which also clears the merged paper's [imported] tag and the Paper 6
interstitial battery). The **V1a/V1b/V1c postulates** require no
upload: they are published in Quantum Rep. 8(3), 78 (2026) and their
content is on record. No other clause of this protocol is changed.
