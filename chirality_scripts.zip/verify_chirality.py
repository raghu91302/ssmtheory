#!/usr/bin/env python3
"""Verification script for 'Chirality from Chronology' (R. Kulkarni, 2026).
Reproduces every computation: the code rebuild, the front-asymmetry
battery with controls, the robustness sweep, the point-gap winding and
skin effect, the transmission chirality, and both recorded exclusions
(the Pauli-hop triviality and the H2 circuit-phase FAIL).
Requires numpy. Run: python3 verify_chirality.py"""
import numpy as np, itertools
from fcc_code import build, NN
ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)
HZ,HX,edges,nodes,octs=build(4)
check("code: [[192,130,3]] inputs (192 edges, CSS valid, weight 12)",
      len(edges)==192 and int(((HX@HZ.T)%2).sum())==0
      and set(HZ.sum(1))=={12} and set(HX.sum(1))=={12})
adj={i:set() for i in range(len(nodes))}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tets=[]
for i in range(len(nodes)):
    nb=sorted(x for x in adj[i] if x>i)
    for a,b,c in itertools.combinations(nb,3):
        if b in adj[a] and c in adj[a] and c in adj[b]:
            tets.append(frozenset((i,a,b,c)))
lay=lambda v: sum(nodes[v]); octsets=[frozenset(o) for o in octs]
tf=lambda t:[frozenset(f) for f in itertools.combinations(sorted(t),3)]
T0=[t for t in tets if sorted(lay(v) for v in t)==[4,4,4,6]][0]
check("hop geometry: tetra voids share faces only with octahedra",
      not any(len(set(t)&set(T0))==3 for t in tets if t!=T0))
paths=[(O,T1) for O in octsets if any(f<=O for f in tf(T0))
       for T1 in tets if T1!=T0 and any(f<=O for f in tf(T1))]
def pol(committed,c=0.5,octa=False,Td=None):
    Td=Td or T0; m0=np.mean([lay(v) for v in Td]); res={}
    pp=[(O,T1) for O in octsets if any(f<=O for f in tf(Td))
        for T1 in tets if T1!=Td and any(f<=O for f in tf(T1))]
    for O,T1 in pp:
        m1=np.mean([lay(v) for v in T1])
        d='UP' if m1>m0+1e-9 else ('DOWN' if m1<m0-1e-9 else 'LAT')
        nc=sum(1 for v in Td if v not in T1 and committed(v)) \
          +sum(1 for v in T1 if v not in Td and committed(v))
        if octa and sum(committed(v) for v in O)>3: nc+=1
        res.setdefault(d,[]).append(nc)
    A=lambda d: np.mean([c**n for n in res.get(d,[0])])**0.5
    au,ad=A('UP'),A('DOWN'); return (au-ad)/(au+ad),au,ad
P,au,ad=pol(lambda v: lay(v)<=4)
check("physical config: A_up=0.500, A_down=0.268, P=+0.302",
      abs(au-0.5)<1e-3 and abs(ad-0.2681)<1e-3 and abs(P-0.302)<2e-3)
check("C1 static: P=0 exactly", abs(pol(lambda v: True)[0])<1e-12)
check("C2 all pending: amplitudes 1, P=0",
      abs(pol(lambda v: False)[0])<1e-12 and pol(lambda v: False)[1]==1)
check("C3 inverted frontier: sign reversed",
      pol(lambda v: lay(v)>=6)[0]<-0.29)
sweep=[pol(lambda v: lay(v)<=4,c)[0] for c in (0.25,0.5,0.75)]
Tdn=[t for t in tets if sorted(lay(v) for v in t)==[4,6,6,6]][0]
sweep+=[pol(lambda v: lay(v)<=4,0.5,True)[0],
        pol(lambda v: lay(v)<=4,0.5,False,Tdn)[0]]
check("robustness: P>0 in all five variants (0.13..0.54)",
      all(p>0.1 for p in sweep))
def wind(a,b):
    ks=np.linspace(0,2*np.pi,4001)[:-1]
    Ek=a*np.exp(1j*ks)+b*np.exp(-1j*ks)
    return int(round(np.sum(np.angle(Ek[1:]/Ek[:-1]))/(2*np.pi)))
check("point-gap winding: physical +1, static 0, inverted -1",
      wind(0.5,0.268)==1 and wind(0.2035,0.2035)==0 and
      wind(0.3953,0.7416)==-1)
N=40; H=np.zeros((N,N))
for n in range(N-1): H[n+1,n]=0.5; H[n,n+1]=0.268
w,V=np.linalg.eig(H)
com=np.mean([np.sum(np.arange(N)*np.abs(V[:,i])**2)/np.sum(np.abs(V[:,i])**2)
             for i in range(N)])
check("skin effect: OBC modes pile at the frontier end", com>0.85*(N-1))
a,b=0.5,0.268
check("transmission chirality: P_T(20)>0.99999, admixture=(b/a)^-n",
      (a**20-b**20)/(a**20+b**20)>0.99999)
# exclusions
e0=next(k for k,(i,j) in enumerate(edges))
check("EXCLUSION C0: single-edge Pauli X-hop disturbs no environment "
      "check (2 endpoint Z-checks only)",
      HZ[:,0].sum()==2 and HX[:,0].sum()>=1)
u=np.array([1,1,1])/np.sqrt(3)
e1=np.array([1,-1,0])/np.sqrt(2); e2=np.cross(u,e1)
D=[np.array(d)/np.sqrt(2) for d in NN]
def sang(order):
    P=[D[k] for k in order]; tot=0.0
    for i in range(len(P)):
        A,B,C=u,P[i],P[(i+1)%len(P)]
        tot+=2*np.arctan2(np.dot(A,np.cross(B,C)),
                          1+np.dot(A,B)+np.dot(B,C)+np.dot(C,A))
    return tot
az=list(np.argsort([np.arctan2(np.dot(d,e2),np.dot(d,e1)) for d in D]))
ph=lambda o: (-sang(o)/2)%(2*np.pi)
pert=az[:1]+[az[2],az[1]]+az[3:]
check("EXCLUSION H2: canonical phase = pi but path-perturbed shifts "
      "(not topological) and classes agree mod 2pi (no discrimination)",
      abs(ph(az)-np.pi)<1e-9 and abs(ph(pert)-np.pi)>0.1 and
      abs((ph(az)-ph(az[::-1]))%(2*np.pi))<1e-9)
print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
