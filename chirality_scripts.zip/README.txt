Verification scripts for:
  "Chirality from Chronology: Parity Violation and Point-Gap Topology
   from the Verification Front of the Vacuum Code" (R. Kulkarni, 2026)

Contents:
  fcc_code.py            rebuilds and verifies the [[192,130,3]] code
  verify_chirality.py    reproduces every result: the front-asymmetry
                         battery with all controls, the robustness
                         sweep, the point-gap winding and skin effect,
                         the transmission chirality, and both recorded
                         exclusions (Pauli-hop null; circuit-phase FAIL)
  PL_protocol.md         the pre-registration document, with its dated
                         amendments intact
  PL_extraction.md       the execution record (extractions, results,
                         verdicts in the locked vocabulary)

Requirements: Python 3 with numpy.
Run:          python3 verify_chirality.py
Expected:     12x PASS, then ALL PASS. Runtime: ~1 minute.
