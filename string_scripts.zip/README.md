# Scripts for "The color string of the FCC vacuum code: tension, breaking and the lightest glueball from the proton's verification count"

R. Kulkarni. Each script runs on its own with Python 3, NumPy, SciPy and Matplotlib.

| script | paper | what it does |
|---|---|---|
| `string_numbers.py` | Secs. 5–7 | Every number of the paper: the tension, its direction dependence, the three repair thresholds, the breaking distance, the energy at the break |
| `string_paths.py` | Sec. 4, Lemmas 1–2, Table 1 | Void geometry (shared vertices and edges, the octahedron's parallel opposite edges) and the shortest-path search for the cheapest string by direction |
| `closed_strings.py` | Sec. 8, Prop. 3, Table 2 | Cycles of two, three and four tetrahedral voids and their minimal counts; the lightest closed string and m/sqrt(sigma) |
| `fig_background.py` | Figure 1 | Node and its twelve bonds; the proton's trapped node and colored edge pairs; the octahedral void |
| `fig_string2.py` | Figure 2 | The two string chains in the FCC lattice |
| `fig_repair.py` | Figure 3 | Repair threshold under linear, quadratic and bond-energy pricing |

Run, for example: `python3 string_numbers.py`
