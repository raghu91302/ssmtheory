"""Repair threshold: misfit cost of one stretched bond against the two half-bonds that replace it, three pricings."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 9, "mathtext.fontset": "cm"})
d = np.linspace(1.0, 2.0, 400)
fig, ax = plt.subplots(figsize=(4.8, 3.3))
rows = [("linear in the misfit (the counting rule)", lambda d: 2*(1-d/2) - (d-1), 1.5, "k", "-"),
        ("quadratic (an elastic solid)", lambda d: 2*(1-d/2)**2 - (d-1)**2, np.sqrt(2), "#3182bd", "--"),
        ("bond energy $\\hbar c/4L$", lambda d: 2*(2/d-1) - (1-1/d), 5/3, "#de2d26", ":")]
for lab, f, t, c, ls in rows:
    ax.plot(d, f(d), color=c, ls=ls, lw=1.6, label=lab)
    ax.plot([t], [0], "o", color=c, ms=5)
ax.axhline(0, color="0.5", lw=0.7)
ax.annotate("$3/2$", (1.5, 0), xytext=(1.505, 0.06), fontsize=9)
ax.annotate("$\\sqrt{2}$", (np.sqrt(2), 0), xytext=(1.355, -0.16), fontsize=9, color="#3182bd")
ax.annotate("$5/3$", (5/3, 0), xytext=(1.68, 0.06), fontsize=9, color="#de2d26")
ax.set_xlabel("length $d$ of the stretched bond ($L$)")
ax.set_ylabel("misfit after repair $-$ before")
ax.set_xlim(1, 2); ax.set_ylim(-1.05, 1.05)
ax.text(1.03, -0.93, "repair lowers the misfit", fontsize=8); ax.text(1.03, 0.88, "repair raises the misfit", fontsize=8)
ax.legend(fontsize=7, loc="lower left", bbox_to_anchor=(0.0, 0.1), framealpha=0.95)
fig.savefig("fig_repair.pdf", bbox_inches="tight"); fig.savefig("fig_repair.png", dpi=200, bbox_inches="tight"); print("ok")
