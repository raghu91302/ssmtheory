"""Closed color strings in the FCC lattice: cycles of tetrahedral voids, priced by rule (S2).
A closed string is a cycle void -> shared vertex -> void -> shared vertex -> ... returning to the start,
with distinct voids and distinct shared vertices (flux enters and leaves each void through different vertices).
Cost: 1692 per void, less 144 per bond-end shared by consecutive voids (288 per shared edge)."""
import itertools, numpy as np
def verts(c):
    i, j, k = c
    return frozenset(p for p in itertools.product((i, i+1), (j, j+1), (k, k+1)) if sum(p) % 2 == 0)
def edges(V): return {frozenset(e) for e in itertools.combinations(V, 2)}
R = 2
cubes = [c for c in itertools.product(range(-R, R+1), repeat=3)]
V = {c: verts(c) for c in cubes}; E = {c: edges(V[c]) for c in cubes}
o = (0, 0, 0)
nbrs = {c: [d for d in cubes if d != c and V[c] & V[d]] for c in cubes}
best = {}
def cost(cyc):
    n = len(cyc); s = 1692*n
    for a in range(n):
        u, v = cyc[a], cyc[(a+1) % n]
        if n == 2 and a == 1: break          # a 2-cycle has one pair of voids
        s -= 288*len(E[u] & E[v])
    return s
# 2-cycles: two voids sharing two vertices (an edge) -> two distinct passages
two = [d for d in nbrs[o] if len(V[o] & V[d]) >= 2]
print(f"voids sharing an edge with a given void: {len(two)};  2-void loop cost {cost([o, two[0]])}")
# 3- and 4-cycles through o with distinct shared vertices
def cycles(n):
    out = []
    def rec(path):
        if len(path) == n:
            if V[path[-1]] & V[o]: out.append(list(path))
            return
        for d in nbrs[path[-1]]:
            if d not in path: rec(path + [d])
    rec([o]); return out
def valid(cyc):
    n = len(cyc)
    for ch in itertools.product(*[sorted(V[cyc[a]] & V[cyc[(a+1) % n]]) for a in range(n)]):
        if len(set(ch)) == n: return True
    return False
for n in (3, 4):
    cs = [c for c in cycles(n) if valid(c)]
    cs_cost = sorted(set(cost(c) for c in cs))
    print(f"{n}-void loops: {len(cs)} (with orientation), costs {cs_cost[:4]} ... min {min(cs_cost)}")
me = 0.51099895
for C in (3096, 4500, 5616):
    print(f"C = {C}: mass {C*me/1e3:.3f} GeV, m/sqrt(sigma) = {C*me/450.5:.3f}  (sqrt(sigma) = 450.5 MeV)")

print(f"calibration number L_c m_e c^2 / hbar c = {0.84075*me/197.3269804:.4e};  m/sqrt(sigma) closed form = {3096*np.sqrt(0.84075*me/(1692*197.3269804)):.4f}")
