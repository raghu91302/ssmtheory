"""Two color strings through tetrahedral voids of FCC under the subtraction rule: the cheapest (vertex-sharing,
along a bond) and the cube-axis chain (edge-sharing)."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
plt.rcParams.update({"font.size": 9, "mathtext.fontset": "cm"})
def tetra(c):
    i, j, k = c
    return [np.array(p, float) for p in itertools.product((i, i+1), (j, j+1), (k, k+1)) if sum(p) % 2 == 0]
skew_cols = ["#d62728", "#2ca02c", "#1f77b4"]
def draw_lattice(ax, X, Y, Z):
    nodes = [np.array(p) for p in itertools.product(range(X+1), range(Y+1), range(Z+1)) if sum(p) % 2 == 0]
    segs = [(p, q) for p, q in itertools.combinations(nodes, 2) if abs(np.sum((p-q)**2) - 2) < 1e-9]
    ax.add_collection3d(Line3DCollection(segs, colors="0.82", linewidths=0.5))
    P = np.array(nodes); ax.scatter(P[:, 0], P[:, 1], P[:, 2], s=10, c="0.6", depthshade=False)
def draw_void(ax, V, shared=None):
    faces = [[V[a], V[b], V[c]] for a, b, c in itertools.combinations(range(4), 3)]
    ax.add_collection3d(Poly3DCollection(faces, facecolor="#fdae6b", edgecolor="none", alpha=0.33))
    pairs = [((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2))]
    for (e1, e2), col in zip(pairs, skew_cols):
        for a, b in (e1, e2): ax.plot(*zip(V[a], V[b]), color=col, lw=1.8)
    Q = np.array(V); ax.scatter(Q[:, 0], Q[:, 1], Q[:, 2], s=28, c="#3182bd", edgecolors="k", linewidths=0.5, depthshade=False)
fig = plt.figure(figsize=(13, 5.9))
# (a) vertex-sharing along a bond direction
ax = fig.add_subplot(1, 2, 1, projection="3d")
n = 4; draw_lattice(ax, n+1, n+1, 1)
chain = [(i, i, 0) for i in range(n)]
for c in chain: draw_void(ax, tetra(c))
for i in range(1, n):
    ax.scatter([i], [i], [0], s=150, facecolors="none", edgecolors="k", linewidths=1.6, depthshade=False)
cen = np.array([[i+0.5, i+0.5, 0.5] for i in range(n)]); ax.plot(*cen.T, color="k", ls=":", lw=1)
ax.set_box_aspect((n+1, n+1, 1)); ax.view_init(elev=28, azim=-55); ax.set_axis_off()
ax.set_title("(a) the cheapest string: each void the previous one moved by one bond $L_c$\n"
             "neighbours share one vertex (circled) and no bond", fontsize=9.5)
ax.text2D(0.5, 0.02, "per $L_c$:  $1836-144=1692\\,\\epsilon_b$   $\\Rightarrow$   $\\sqrt{\\sigma}=450$ MeV",
          transform=ax.transAxes, ha="center", fontsize=10.5, bbox=dict(fc="white", ec="0.6"))
# (b) edge-sharing along a cube axis
ax = fig.add_subplot(1, 2, 2, projection="3d")
m = 5; draw_lattice(ax, m, 1, 1)
for i in range(m):
    draw_void(ax, tetra((i, 0, 0)))
for i in range(1, m):
    A, B = tetra((i-1, 0, 0)), tetra((i, 0, 0)); sh = [p for p in A if any(np.allclose(p, q) for q in B)]
    ax.plot(*zip(*sh), color="k", lw=4.5, alpha=0.55)
cen = np.array([[i+0.5, 0.5, 0.5] for i in range(m)]); ax.plot(*cen.T, color="k", ls=":", lw=1)
ax.set_box_aspect((m, 1.4, 1.4)); ax.view_init(elev=20, azim=-62); ax.set_axis_off()
ax.set_title("(b) along a cube axis: voids every $L_c/\\sqrt{2}$, sharing one edge (dark)\n"
             "denser chain, so dearer per length", fontsize=9.5)
ax.text2D(0.5, 0.02, "per step $1836-144-288=1404$;  per $L_c$: $1986\\,\\epsilon_b$   $\\Rightarrow$   $\\sqrt{\\sigma}=488$ MeV",
          transform=ax.transAxes, ha="center", fontsize=10.5, bbox=dict(fc="white", ec="0.6"))
fig.text(0.5, 0.975, "A color string = tetrahedral voids without their trapped node (the proton's 1836 less 144 per void).  "
         "Red, green, blue: each void's three skew pairs.", ha="center", fontsize=10)
fig.text(0.5, 0.015, "Cheapest over all directions (Dijkstra over voids): 1692 per $L_c$ along bonds; "
         "cube axis 1986, $\\langle111\\rangle$ 2072.   QCD: $\\sqrt{\\sigma}\\approx420$–$465$ MeV.", ha="center", fontsize=9.5)
plt.subplots_adjust(left=0, right=1, top=0.86, bottom=0.06, wspace=0.0)
fig.savefig("ssm_string_paths.png", dpi=200)
for t in list(fig.texts): t.remove()
for a in fig.axes:
    a.set_title(a.get_title().split("\n")[0], fontsize=12)
    for t in list(a.texts):
        if t.get_text().startswith("per"): t.set_fontsize(13)
fig.savefig("fig_string_paths.pdf", bbox_inches="tight"); print("ok")
