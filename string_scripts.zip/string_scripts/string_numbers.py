"""Every number of the string paper: tension, direction dependence, repair thresholds, breaking, energetics."""
import numpy as np
from scipy.optimize import brentq
me = 0.51099895        # MeV
Lc = 0.84075           # fm, proton charge radius (CODATA 2022)
hbarc = 197.3269804    # MeV fm
# ---- tension
C_void = 13*144 - 3*12 - 144          # proton count less its trapped node
assert C_void == 1692
sig = C_void*me/Lc                    # MeV/fm
sig_GeV2 = sig*hbarc/1e6
print(f"string void: 1836 - 144 = {C_void};  sigma = {sig:.1f} MeV/fm = {sig_GeV2:.4f} GeV^2;  sqrt(sigma) = {np.sqrt(sig_GeV2)*1e3:.1f} MeV")
print(f"Regge slope 1/(2 pi sigma) = {1/(2*np.pi*sig_GeV2):.3f} GeV^-2")
for name, per in [("<110>", 1692.0), ("<211>", 1953.8), ("<210>", 1958.1), ("<100>", 1985.6), ("<111>", 2072.3)]:
    s = per*me/Lc*hbarc/1e6
    print(f"   {name}: {per:7.1f} per L_c  sqrt(sigma) = {np.sqrt(s)*1e3:6.1f} MeV  ratio {per/1692:.3f}")
# cube-axis chain by hand: per step 10*144 - 3*12, sqrt2 steps per L_c
print(f"cube axis by hand: (10*144-36)*sqrt2 = {(10*144-36)*np.sqrt(2):.1f}")
# ---- repair thresholds: one bond of length d against two of length d/2 (units of L)
f_quad = lambda d: (d-1)**2 - 2*(1-d/2)**2
f_lin  = lambda d: (d-1) - 2*(1-d/2)
f_inv  = lambda d: (1-1/d) - 2*(2/d-1)
for name, f in [("quadratic", f_quad), ("linear", f_lin), ("bond energy 1/L", f_inv)]:
    d = brentq(f, 1.01, 1.99)
    print(f"repair threshold, {name:16s}: d = {d:.4f} L  -> r_b = {d*Lc:.3f} fm, stored {d*C_void:.0f} eps_b = {d*C_void*me/1e3:.3f} GeV")
# ---- energetics
per_quark = 1836/3
pair = 2*per_quark
print(f"per-quark share {per_quark:.0f} eps_b = {per_quark*me:.1f} MeV; pair {pair:.0f} = {pair*me:.1f} MeV;"
      f" energetic crossing at {pair/C_void:.3f} L_c = {pair/C_void*Lc:.3f} fm")
stored = 1.5*C_void
print(f"stored at 3/2: {stored:.0f} eps_b = {stored*me:.1f} MeV; surplus over the pair {stored-pair:.0f} eps_b = {(stored-pair)*me:.1f} MeV;"
      f" end cost for coincidence {stored/2:.0f} eps_b = {stored/2*me:.1f} MeV")
print(f"pion 273 as pair cost: crossing at {273/C_void:.3f} L_c = {273/C_void*Lc:.3f} fm")
# ---- Planck-spacing comparison (matter paper's estimate)
print(f"ratio sigma(L_c)/(1e-15 GeV^2) ~ 10^{np.log10(sig_GeV2/1e-15):.1f}")
