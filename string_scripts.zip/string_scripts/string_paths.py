"""Cheapest color-string paths through tetrahedral voids of the FCC lattice under the subtraction rule.

Grid units: conventional cube side a = 2, FCC nodes at integer points with even coordinate sum, bond L = sqrt2.
Every unit cube [i,i+1]x[j,j+1]x[k,k+1] holds one tetrahedral void: its four even-sum corners.
Rule: each void of a string costs 1836 - 144 = 1692 (the proton without its trapped node); two consecutive
voids sharing an edge share its 2 bond-ends, -288.  Octahedral voids carry no skew pairs (their opposite edges are
parallel), hence no color flux, so strings run through tetrahedral voids only.
Dijkstra over voids (adjacent = sharing at least one vertex); cost per bond length for far targets by direction.
"""
import numpy as np, itertools, heapq
def verts(c):
    i, j, k = c
    return frozenset(p for p in itertools.product((i, i+1), (j, j+1), (k, k+1)) if sum(p) % 2 == 0)
def edges(V): return {frozenset(e) for e in itertools.combinations(V, 2)}
# geometry checks
A = verts((0, 0, 0)); B = verts((1, 1, 0)); C = verts((1, 0, 0))
print("translation by a bond vector: shared vertices", len(A & B), " shared edges", len(edges(A) & edges(B)))
print("cube-axis neighbour:          shared vertices", len(A & C), " shared edges", len(edges(A) & edges(C)))
# octahedron: opposite edges parallel?
O = [np.array(v) for v in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
oe = [(a, b) for a, b in itertools.combinations(range(6), 2) if abs(np.dot(O[a], O[b])) < 1e-9]
skew = 0
for (a, b), (c, d) in itertools.combinations(oe, 2):
    if len({a, b, c, d}) == 4:
        u, v = O[b]-O[a], O[d]-O[c]
        if np.linalg.norm(np.cross(u, v)) > 1e-9:
            M = np.array([u, v, O[c]-O[a]])
            if abs(np.linalg.det(M)) > 1e-9: skew += 1
print(f"octahedron: {len(oe)} edges, opposite pairs parallel -> pairs of skew edges with disjoint vertices that are 'opposite': ", end="")
opp = sum(1 for (a,b),(c,d) in itertools.combinations(oe,2) if len({a,b,c,d})==4 and np.linalg.norm(np.cross(O[b]-O[a],O[d]-O[c]))<1e-9)
print(f"{opp} parallel opposite pairs")
# Dijkstra
R = 9
cubes = list(itertools.product(range(-R, R), repeat=3))
VV = {c: verts(c) for c in cubes}; EE = {c: edges(VV[c]) for c in cubes}
nbr_off = [d for d in itertools.product(range(-2, 3), repeat=3) if d != (0, 0, 0) and len(verts((0,0,0)) & verts(d)) > 0]
print("vertex-sharing neighbours of a void:", len(nbr_off), " max centre distance (L):", round(max(np.linalg.norm(d) for d in nbr_off)/np.sqrt(2), 3))
def dijkstra(src):
    dist = {src: 1692.0}; pq = [(1692.0, src)]
    while pq:
        d, u = heapq.heappop(pq)
        if d > dist[u]: continue
        for o in nbr_off:
            v = (u[0]+o[0], u[1]+o[1], u[2]+o[2])
            if v not in VV: continue
            w = 1692.0 - 288.0*len(EE[u] & EE[v])
            if d + w < dist.get(v, 1e18): dist[v] = d + w; heapq.heappush(pq, (d + w, v))
    return dist
D = dijkstra((0, 0, 0))
print("\ncost per bond length L_c of the cheapest string, by direction (far target, end correction removed):")
for name, step in [("<110> (bond)", (1, 1, 0)), ("<100> (cube axis)", (1, 0, 0)), ("<111>", (1, 1, 1)), ("<210>", (2, 1, 0)), ("<211>", (2, 1, 1))]:
    s = np.array(step); n1, n2 = 3, 7
    if np.abs(s*n2).max() >= R: n2 = (R-1)//np.abs(s).max(); n1 = n2//2
    c1, c2 = tuple(s*n1), tuple(s*n2)
    per = (D[c2] - D[c1]) / (np.linalg.norm(s)*(n2-n1)/np.sqrt(2))
    print(f"   {name:18s} {per:7.1f}   sqrt(sigma) = {np.sqrt(per*0.51099895/0.84075*0.1973270)*1000/np.sqrt(1000):6.1f} MeV")
