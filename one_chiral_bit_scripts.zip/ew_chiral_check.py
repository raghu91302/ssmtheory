#!/usr/bin/env python3
"""Verification for 'One chiral bit': builds E6 from the D4 lift, imposes the chiral input,
and checks every claim of the paper. NumPy only."""
import numpy as np, itertools, collections
R_=[]
def check(name,cond,info=""):
    R_.append(bool(cond)); print(f"[{'OK' if cond else 'FAIL'}] {name} {info}")
r3=np.sqrt(3); key=lambda x: tuple(np.round(x,6))
# ---- 1. E6 from the D4 lift (construction of the E6 paper)
vc={'v':np.array([1.,0.]),'s':np.array([-.5,r3/2]),'c':np.array([-.5,-r3/2])}
D4=[np.r_[v,0,0] for i,j in itertools.combinations(range(4),2) for si,sj in itertools.product((1,-1),repeat=2)
    for v in [np.eye(4)[i]*si+np.eye(4)[j]*sj]]
short=[(np.eye(4)[i]*s,'v') for i in range(4) for s in (1,-1)]
short+=[(np.array(sg),'s' if sum(x<0 for x in sg)%2==0 else 'c') for sg in itertools.product((.5,-.5),repeat=4)]
R=np.array(D4+[np.r_[s,e*vc[k]] for s,k in short for e in (1,-1)])
RS={key(r) for r in R}
check("E6: 72 roots, reflection-closed, rank 6",
      len(R)==72 and all(key(b-np.dot(a,b)*a) in RS for a in R for b in R) and np.linalg.matrix_rank(R)==6)
al=np.array([[0,1,-1,0,0,0],[0,0,1,-1,0,0],[.5,-.5,-.5,.5,-.5,r3/2],[.5,-.5,-.5,.5,.5,-r3/2],
             [-.5,.5,.5,.5,-.5,-r3/2],[-.5,.5,.5,.5,.5,r3/2]])
check("simple roots of the E6 paper, Cartan determinant 3", round(np.linalg.det(al@al.T))==3)
om=np.linalg.inv(al).T
coef=np.array([np.linalg.solve(al.T,r) for r in R]); pos=R[(coef>-1e-9).all(1)]
theta=pos[np.argmax([np.linalg.solve(al.T,r).sum() for r in pos])]; a0=-theta
check("highest-root marks (2,3,2,2,1,1): node 2 has mark 3", list(np.round(np.linalg.solve(al.T,theta)).astype(int))==[2,3,2,2,1,1])
# ---- 2. the three su(3) factors and the flip
fr=lambda a,b:[a,b,a+b,-a,-b,-a-b]
Fc,FA,FB=fr(a0,al[0]),fr(al[2],al[4]),fr(al[3],al[5])
allf=[r for f in (Fc,FA,FB) for r in f]
check("deleting the mark-3 node leaves three mutually orthogonal su(3)",
      all(abs(x@y)<1e-9 for f,g in itertools.combinations((Fc,FA,FB),2) for x in f for y in g))
flip=np.diag([1,1,1,1,-1,-1]); S=lambda f:{key(r) for r in f}
check("orientation flip fixes color and swaps the other two factors",
      S([flip@r for r in Fc])==S(Fc) and S([flip@r for r in FA])==S(FB))
# ---- 3. the charge operator of the E6 paper
Qv=-(2/3*om[1]-om[2]-om[3]+om[4]+om[5])   # overall sign fixed so that the quark doublet has Y=+1/6
check("Q commutes with color and is flip-invariant", all(abs(Qv@g)<1e-9 for g in Fc) and np.allclose(flip@Qv,Qv))
check("in each swapped factor two root pairs carry charge +-1, one is neutral",
      sorted(abs(round(Qv@r,6)) for r in FA[:3])==[0,1,1] and sorted(abs(round(Qv@r,6)) for r in FB[:3])==[0,1,1])
# ---- 4. the 27
def orbit(w):
    seen={key(w):w}; fr_=[w]
    while fr_:
        nf=[]
        for x in fr_:
            for a in al:
                y=x-np.dot(x,a)*a
                if key(y) not in seen: seen[key(y)]=y; nf.append(y)
        fr_=nf
    return np.array(list(seen.values()))
W27=orbit(om[4]); W27b=orbit(om[5])
check("27 = Weyl orbit of a long-arm end, 27 states; the other end gives the conjugate",
      len(W27)==27 and S(W27b)==S(-W27))
check("the flip exchanges 27 and its conjugate (parity maps L-handed to conjugates)", S([flip@w for w in W27])==S(W27b))
charges=collections.Counter(np.round(W27@Qv,4))
check("charges on the 27: color blocks 2/3,-1/3 and conjugates; singlets -1 x2, 0 x5, +1 x2",
      charges[1.0]==2 and charges[0.0]==5 and charges[-1.0]==2)
# ---- 5. chiral input: weak su(2) in factor A; the two charged candidates
colorq=lambda w: 'singlet' if abs(w@a0)<1e-9 and abs(w@al[0])<1e-9 else 'colored'
def spectrum(beta):
    beta=beta if Qv@beta>0 else -beta
    rows=collections.Counter((colorq(w),round(0.5*w@beta,3)+0.0,round(w@Qv,3)+0.0,round(w@Qv-0.5*w@beta,3)+0.0) for w in W27)
    ok=abs(Qv@beta-1)<1e-9 and all(abs((Qv-beta/2)@g)<1e-9 for g in Fc)
    return rows,ok,beta
spA,okA,bA=spectrum(al[2]); spB,okB,_=spectrum(al[4])
check("both charged su(2) in the chosen factor commute with Y=Q-T3 and color", okA and okB)
check("the two embeddings give identical spectra (a relabeling)", spA==spB)
expect={('colored',0.5,0.667,0.167):3,('colored',-0.5,-0.333,0.167):3,     # Q_L
        ('colored',0.0,-0.667,-0.667):3,                                    # u^c
        ('colored',0.0,0.333,0.333):6,                                      # d^c, D^c
        ('colored',0.0,-0.333,-0.333):3,                                    # D
        ('singlet',0.5,0.0,-0.5):2,('singlet',-0.5,-1.0,-0.5):2,            # L, H_d
        ('singlet',0.5,1.0,0.5):1,('singlet',-0.5,0.0,0.5):1,               # H_u
        ('singlet',0.0,1.0,1.0):1,('singlet',0.0,0.0,0.0):2}                # e^c; nu^c, N
check("27 = one SM generation (Q,u^c,d^c,L,e^c,nu^c) + exotics (D,D^c,H_u,H_d,N)", spA==collections.Counter(expect))
# color triplet vs antitriplet: Q_L and D share one type, u^c, d^c, D^c the conjugate
trip=lambda ws:{(int(round(w@a0)),int(round(w@al[0]))) for w in ws}
grp=lambda T,Qq: [w for w in W27 if colorq(w)=='colored' and abs(0.5*w@bA-T)<1e-6 and abs(w@Qv-Qq)<1e-6]
A_={(1,0),(-1,1),(0,-1)}; B_={(0,1),(1,-1),(-1,0)}
QL=grp(.5,2/3)+grp(-.5,-1/3); uc=grp(0,-2/3); dD=grp(0,1/3); D_=grp(0,-1/3)
t=lambda ws: 'A' if trip(ws)<=A_ else ('B' if trip(ws)<=B_ else '?')
check("Q_L and D are one color type; u^c, d^c, D^c the conjugate type",
      t(grp(.5,2/3))==t(grp(-.5,-1/3))==t(D_)!='?' and t(uc)==t(dD)!='?' and t(uc)!=t(D_),
      f"(Q_L:{t(grp(.5,2/3))}, D:{t(D_)}, u^c:{t(uc)}, d^c/D^c:{t(dD)})")
ntrip=sum(1 for w in W27 if colorq(w)=='colored' and trip([w])<=A_)/3; nanti=sum(1 for w in W27 if colorq(w)=='colored' and trip([w])<=B_)/3
ndoub=sum(1 for w in W27 if abs(0.5*w@bA-0.5)<1e-9)
check("SU(3)^3 anomaly cancels (3 triplets, 3 antitriplets); even number of SU(2) doublets (no Witten anomaly)",
      ntrip==nanti==3 and ndoub%2==0, f"(doublets={ndoub})")
S27B=spectrum(al[3])[0]
Sbar=collections.Counter((colorq(w),round(0.5*w@bA,3)+0.0,round(w@Qv,3)+0.0,round(w@Qv-0.5*w@bA,3)+0.0) for w in -W27)
check("the mirror pairing (27, su(3)_B) equals (27bar, su(3)_A) and differs from ours: its quark doublet has Y=-1/6",
      S27B==Sbar and S27B!=spA and any(k[0]=='colored' and k[1]!=0 and abs(k[3]+1/6)<1e-3 for k in S27B))
# ---- 6. anomalies over the 27 (left-handed Weyl)
T3=lambda w:0.5*w@bA; Y=lambda w:w@Qv-T3(w)
gs=Fc[0]; tr=lambda f: sum(f(w) for w in W27)
anom={'Tr Y':tr(Y),'Tr Y^3':tr(lambda w:Y(w)**3),'SU2^2 Y':tr(lambda w:Y(w)*(w@bA)**2),
      'SU3^2 Y':tr(lambda w:Y(w)*(w@gs)**2),'Tr T3^2 Y check':tr(lambda w:T3(w)**2*Y(w))}
check("all U(1)_Y anomalies vanish on the 27", all(abs(v)<1e-9 for v in anom.values()), str({k:round(v,9) for k,v in anom.items()}))
# ---- 7. mixing angle and normalizations
TT=tr(lambda w:T3(w)**2); YY=tr(lambda w:Y(w)**2); QQ=tr(lambda w:(w@Qv)**2)
check("sin^2 theta_W = Tr T3^2 / Tr Q^2 = 3/8 on the 27", abs(TT/QQ-3/8)<1e-9, f"(TrT3^2={TT:.3f}, TrQ^2={QQ:.3f})")
check("GUT hypercharge normalization Tr Y^2 / Tr T3^2 = 5/3", abs(YY/TT-5/3)<1e-9)
check("all three su(3) factors have equal root length (equal embedding index)", len({round(r@r,6) for r in allf})==1)
# ---- 7b. what 3/8 requires, and where it comes from
def proj(v,basis):
    B=np.array(basis).T; return B@np.linalg.lstsq(B,v,rcond=None)[0]
T3v=bA/2; Yv=Qv-T3v
Yc,YA_,YB_=proj(Yv,[a0,al[0]]),proj(Yv,[al[2],al[4]]),proj(Yv,[al[3],al[5]])
kA,kB=(YA_@YA_)/(T3v@T3v),(YB_@YB_)/(T3v@T3v)
check("Y has no color part; 1/g_Y^2 = (1/3)/g_A^2 + (4/3)/g_B^2", np.allclose(Yv,Yc+YA_+YB_) and abs(Yc@Yc)<1e-12 and abs(kA-1/3)<1e-9 and abs(kB-4/3)<1e-9)
s2=lambda gA,gB: 1/((1/gA**2+kA/gA**2+kB/gB**2)*gA**2)
check("sin^2 theta_W = 3/8 when g_A = g_B, for any color coupling; 0.29/0.44 at g_B/g_A = 0.8/1.2",
      abs(s2(1,1)-3/8)<1e-12 and abs(s2(1,.8)-0.2927)<1e-3 and abs(s2(1,1.2)-0.4426)<1e-3)
bondroot=lambda r: np.allclose(r[4:],0)
check("color is built only from bond roots; su(3)_A and su(3)_B only from matter roots",
      all(bondroot(r) for r in Fc) and not any(bondroot(r) for r in FA+FB))
idx=lambda F: sum((w@F[0])**2 for w in W27)
check("the 27 contributes equally to the running of g_A and g_B (equal Dynkin-index sums)", abs(idx(FA)-idx(FB))<1e-9, f"({idx(FA):.1f}, {idx(FB):.1f})")
adj=lambda F: sum((r@F[0])**2 for r in F)
check("the gauge fields of su(3)_A and su(3)_B contribute equally (equal adjoint index sums)", abs(adj(FA)-adj(FB))<1e-9)
# SM one-loop: where alpha_1 (GUT normalized) meets alpha_2
aem,s2w,MZ=127.951,0.23122,91.1876
a1,a2=0.6*aem*(1-s2w),aem*s2w; b1,b2=41/10,-19/6
lnmu=(a1-a2)*2*np.pi/(b1-b2); MX=MZ*np.exp(lnmu)
check("SM one-loop: alpha_1 and alpha_2 meet near 1e13 GeV", 5e12<MX<2e13, f"(M = {MX:.2e} GeV)")
# ---- 8. breaking constraints
neutral=[w for w in W27 if abs(w@Qv)<1e-9 and abs(T3(w))<1e-9 and abs(Y(w))<1e-9]
check("two SM-singlet neutral states (N, nu^c) available for SU(3)_L x SU(3)_R breaking", len(neutral)==2)
check("doublets with a neutral member have Y=+-1/2", all(abs(abs(Y(w))-0.5)<1e-9 for w in W27 if abs(abs(T3(w))-.5)<1e-9 and colorq(w)=='singlet'))
# ---- 9. lattice facts used in the text
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
L=4; nodes=[p for p in itertools.product(range(L),repeat=3) if sum(p)%2==0]; ni={p:i for i,p in enumerate(nodes)}
edges=[];ei={}
for i,p in enumerate(nodes):
    for dd in NN:
        j=ni[tuple((p[k]+dd[k])%L for k in range(3))]
        if i<j and (i,j) not in ei: ei[(i,j)]=len(edges); edges.append((i,j))
octc=[p for p in itertools.product(range(L),repeat=3) if sum(p)%2]
n=len(edges); HZ=np.zeros((len(nodes),n),int); HX=np.zeros((len(octc),n),int)
for e,(i,j) in enumerate(edges): HZ[i,e]=HZ[j,e]=1
for o,p in enumerate(octc):
    s_={ni[tuple((p[k]+sg*(k==a))%L for k in range(3))] for a in range(3) for sg in (1,-1)}
    for e,(i,j) in enumerate(edges):
        if i in s_ and j in s_: HX[o,e]=1
check("FCC code rebuilt: n=192, H_X H_Z^T = 0", n==192 and not ((HX@HZ.T)%2).any())
sq=[(1,1,0),(1,0,1),(1,-1,0),(1,0,-1)]
se=[ei[tuple(sorted((ni[tuple(x%L for x in a)],ni[tuple(x%L for x in b)])))] for a,b in zip(sq,sq[1:]+sq[:1])]
Cs=int((HZ[:,se].sum(1)>0).sum()+(HX[:,se].sum(1)>0).sum())
check("square plaquette: E_s=4, C_s=9, local count 36; six faces 216", len(se)==4 and Cs==9)
check("m_W/m_e and m_Z/m_e exceed the local counts by 700-5000x",
      700<80.369e3/0.51099895/216<800 and 4900<91.1876e3/0.51099895/36<5000)
def tet(c):
    return frozenset(tuple(int(round(c[i]+d[i])) for i in range(3)) for d in itertools.product((-.5,.5),repeat=3)
                     if int(round(sum(c[i]+d[i] for i in range(3))))%2==0)
hgt=lambda p: sum(p)/np.sqrt(3); ok=True
for c0 in ((.5,.5,.5),(1.5,1.5,1.5)):
    for k in range(3):
        for sg in (1,-1):
            t=tuple(c0[i]+sg*(i==k) for i in range(3))
            for F in np.linspace(-3,3,25):
                cnt=lambda a,b: sum(hgt(x)<=F+1e-9 for x in tet(a)^tet(b))
                ok&= cnt(c0,t)==cnt(t,c0)
check("symmetric verification cost at a fixed frontier: every hop is reciprocal", ok)
# ---- 10. Appendix A: site symmetry, the flip, D4 slices, growth direction
Vt=np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])
kk=lambda A: tuple(sorted(map(tuple,np.round(A).astype(int))))
Oh=[]
for p in itertools.permutations(range(3)):
    for sg in itertools.product((1,-1),repeat=3):
        M=np.zeros((3,3))
        for i in range(3): M[i,p[i]]=sg[i]
        Oh.append(M)
Td=[g for g in Oh if kk(Vt@g.T)==kk(Vt)]
check("A: void site group has order 24, 12 improper elements, no inversion; inversion exchanges the classes",
      len(Td)==24 and sum(np.linalg.det(g)<0 for g in Td)==12 and not any(np.allclose(g,-np.eye(3)) for g in Td) and kk(-Vt)!=kk(Vt))
act=lambda g,C: np.linalg.det(g)*g@C@g.T
Pj=sum(np.array([act(g,np.eye(9)[k].reshape(3,3)).ravel() for k in range(9)]).T for g in Td)/len(Td)
check("A: no Td-invariant spin-velocity bilinear; sigma.v is odd under the improper site elements",
      round(np.trace(Pj))==0 and all(np.allclose(act(g,np.eye(3)),-np.eye(3)) for g in Td if np.linalg.det(g)<0))
check("A: sigma.v is invariant under the chiral subgroup T only", all(np.allclose(act(g,np.eye(3)),np.eye(3)) for g in Td if np.linalg.det(g)>0))
HD=lambda s_,v: s_[0]*v[0]*(v[1]**2-v[2]**2)+s_[1]*v[1]*(v[2]**2-v[0]**2)+s_[2]*v[2]*(v[0]**2-v[1]**2)
rg=np.random.default_rng(0); okD=True
for g in Td:
    for _ in range(4):
        s_,v=rg.normal(size=3),rg.normal(size=3); okD&=np.isclose(HD(np.linalg.det(g)*g@s_,g@v),HD(s_,v))
s_,v=rg.normal(size=3),rg.normal(size=3)
check("A: cubic Dresselhaus form is Td-invariant and odd under inversion", okD and np.isclose(HD(s_,-v),-HD(s_,v)))
hel=lambda v: v[0]*v[0]*(v[1]**2-v[2]**2)+v[1]*v[1]*(v[2]**2-v[0]**2)+v[2]*v[2]*(v[0]**2-v[1]**2)
check("A: the Dresselhaus form carries no helicity, Tr[(sigma.v)H_D]=0 identically", all(abs(hel(rg.normal(size=3)))<1e-12 for _ in range(100)))
def bnd(c,t): return [tuple(int(round(c[i]+d[i])) for i in range(3)) for d in itertools.product((-.5,.5),repeat=3)
                      if (int(round(sum(c[i]+d[i] for i in range(3))))+t)%2==0]
def cls(c,t):
    a=bnd(c,t)[0]; return int(np.prod(np.sign([2*(a[i]-c[i]) for i in range(3)])))
cs=[(.5,.5,.5),(1.5,.5,.5),(.5,1.5,.5),(1.5,1.5,1.5)]
hopr=lambda c,k,sg: tuple(c[i]+sg*(i==k) for i in range(3))
check("A: a tick flips a fixed void's class; a frozen-slice hop flips it; a time-mixed D4 hop preserves it",
      all(cls(c,t+1)==-cls(c,t) for c in cs for t in (0,1)) and
      all(cls(hopr(c,k,sg),t)==-cls(c,t) for c in cs for t in (0,1) for k in range(3) for sg in (1,-1)) and
      all(cls(hopr(c,k,sg),t+1)==cls(c,t) for c in cs for t in (0,1) for k in range(3) for sg in (1,-1)))
ax=np.array([1,1,1]); Gg=[g for g in Oh if np.allclose(g@ax,ax)]
check("A: the growth-direction subgroup is C3v and preserves each class; every class-exchanging element reverses the growth direction",
      len(Gg)==6 and all(kk(Vt@g.T)==kk(Vt) for g in Gg) and all(np.allclose(g@ax,-ax) for g in Oh if kk(Vt@g.T)==kk(-Vt) and abs(g@ax@ax)==3))
def ninv(d):
    mons=sorted({tuple(sorted(m)) for m in itertools.product(range(3),repeat=d)})
    basis=[(i,m) for i in range(3) for m in mons]; rg2=np.random.default_rng(1)
    pts=[(rg2.normal(size=3),rg2.normal(size=3)) for _ in range(3*len(basis))]
    ev=lambda i,m,s_,v: s_[i]*np.prod([v[k] for k in m])
    B=sum(np.array([[ev(i,m,np.linalg.det(g)*g.T@s_,g.T@v) for (i,m) in basis] for s_,v in pts]) for g in Td)/len(Td)
    return np.linalg.matrix_rank(B,tol=1e-8)
check("A: Td-invariant spin-hop couplings by degree in v: 0, 0, 1 (the cubic form is lowest and unique)", [ninv(1),ninv(2),ninv(3)]==[0,0,1])
inv=lambda p: tuple((-x)%L for x in p)
rowsZ={tuple(np.nonzero(r)[0]) for r in HZ}; rowsX={tuple(np.nonzero(r)[0]) for r in HX}
emap={e:ei[tuple(sorted((ni[inv(nodes[i])],ni[inv(nodes[j])])))] for e,(i,j) in enumerate(edges)}
check("A: spatial inversion maps the code's vertex and octahedral checks to themselves",
      {tuple(sorted(emap[e] for e in r)) for r in rowsZ}==rowsZ and {tuple(sorted(emap[e] for e in r)) for r in rowsX}==rowsX)
anc=[g for g in Td if np.allclose(g@Vt[0],Vt[0])]
check("A: the anchored defect (one vertex fixed) has site group C3v, with 3 mirrors", len(anc)==6 and sum(np.linalg.det(g)<0 for g in anc)==3)
print(f"\n{sum(R_)}/{len(R_)} checks passed")
