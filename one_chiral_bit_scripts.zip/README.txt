One Chiral Bit: The Electroweak Structure of the Selection-Stitch Vacuum from e6
Verification script
================================================================================

File
  ew_chiral_check.py   Checks every claim of the paper.

Requirements
  Python 3 and NumPy. Tested with Python 3.12.3 and NumPy 2.4.4.

Run
  python3 ew_chiral_check.py

Output
  Each check prints OK or FAIL with a short label. The last line gives the
  total. A full run takes about one second and ends with:
  42/42 checks passed

What it checks
  1. E6 from the D4 lift: 72 roots, reflection closure, rank 6, Cartan
     determinant 3, highest-root marks.
  2. The three su(3) factors; the orientation flip fixes color and exchanges
     the other two; color uses only bond roots, the other two only matter
     roots.
  3. The charge operator: it commutes with color and is flip-invariant.
  4. The 27 and its conjugate; the flip exchanges them.
  5. The chiral input: the weak su(2), its two equivalent embeddings, the
     mirror world, and the Standard Model generation content (Table 1),
     including triplet and antitriplet assignments.
  6. Anomalies: hypercharge, pure color, and the global SU(2) anomaly.
  7. The mixing angle: 1/g_Y^2 = (1/3)/g_A^2 + (4/3)/g_B^2,
     sin^2 theta_W = 3/8 at g_A = g_B for any color coupling, equal running
     of g_A and g_B from the gauge fields and the 27, and the Standard Model
     crossing of alpha_1 and alpha_2 near 1e13 GeV.
  8. The breaking sector: neutral singlets and Y = +-1/2 doublets.
  9. Lattice facts: the FCC code, the plaquette count, the boson-mass
     comparison, and the reciprocity of symmetric verification costs.
 10. Appendix A: the Td site group, the allowed spin-hop couplings by degree,
     the Dresselhaus form and its zero helicity, the anchored defect, the
     action of inversion on the code, the void class along D4 worldlines,
     and the growth-direction subgroup.
