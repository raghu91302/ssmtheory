#!/usr/bin/env python3
"""Section 10: the integer verification counts of Ref. [meiext] and the family operator.
Part 1: the bond supports of the three MEI leptons split equally between in-sheet and
        inter-sheet edges (the condition z = 2 n0 of Eq. (trace)).
Part 2: integer counts cannot satisfy Koide exactly; the Koide completion of (1, 207);
        the single phase of the family operator that reproduces the counts.
Part 3: the tau count of Ref. [meiext] by orbits under time reversal, and the
        Euler characteristic of the spatial surface shared by its two halves."""
import numpy as np
from itertools import product, combinations
# --- MEI counts and Koide
print("=== Part 1 and 2"); C = np.array([1., 207., 3483.])
K = lambda m: m.sum()/np.sqrt(m).sum()**2
print("MEI counts K =", round(K(C), 6), " (2/3 + %.2e)" % (K(C)-2/3))
a = np.sqrt(C); n = np.ones(3)/np.sqrt(3)
dem = (a@n)**2; tr = a@a - dem
print("  democratic |a.n|^2 =", round(dem, 2), " transverse =", round(tr, 2), " (Koide: equal)")
# exact-Koide tau given e, mu ; exact mu given e, tau
from scipy.optimize import brentq
print("  exact tau given (1,207):", round(brentq(lambda x: K(np.array([1,207,x]))-2/3, 3000, 4000), 4))
print("  exact mu given (1,3483):", round(brentq(lambda x: K(np.array([1,x,3483]))-2/3, 150, 260), 4))
print("  measured ratios: 206.768, 3477.37")
# --- MEI supports, classified by [111] sheet change
D4 = [np.array(v) for v in product((-1,0,1), repeat=4) if sum(map(abs,v)) == 2]      # (t,x,y,z)
lay = lambda v: (v[1]+v[2]+v[3])/2          # layer index along [111] (half-integers for time-mixed)
def classify(vecs):
    out = {}
    for v in vecs: out[lay(v)] = out.get(lay(v), 0) + 1
    return dict(sorted(out.items()))
spatial = [v for v in D4 if v[0] == 0]; mixed = [v for v in D4 if v[0] != 0]
comp = lambda v: [i for i in (1,2,3) if v[i] == 0]   # spatial bonds: which coordinate plane
x_comp = [v for v in spatial if v[1] == 0]
print("\nNeighbours by layer offset along [111] (own sheet = 0):")
print("  electron (one triality component, 4 spatial bonds):", classify(x_comp))
print("  muon (spatial halves of all three components, 12 bonds):", classify(spatial))
print("  tau (all 24 bonds incl. time-mixed):", classify(D4))
# --- edges of each support (cluster = centre + neighbours), classified by layer change
def edges(verts):
    V = [np.zeros(4, int)] + verts
    E = [(i,j) for i,j in combinations(range(len(V)),2) if sum(abs(V[i]-V[j])) == 2 and (V[i]-V[j]) @ (V[i]-V[j]) == 2]
    cls = {}
    for i,j in E:
        dl = abs(lay(V[i]) - lay(V[j])); cls[dl] = cls.get(dl,0)+1
    return len(V), len(E), dict(sorted(cls.items()))
for name, vs in (("electron 1-sheet", x_comp), ("muon 3-sheet", spatial), ("tau 24-cell", D4)):
    nv, ne, cls = edges(vs)
    print(f"  {name:16s}: nodes {nv:2d}, edges {ne:3d}, by |layer change| {cls}")

# --- the integer obstruction: (1 + 3 sqrt23 + sqrt c)^2 = 1.5 (208 + c) leaves a sqrt23 term for every integer c
best = min(range(3400, 3600), key=lambda c: abs(K(np.array([1., 207., c])) - 2/3))
print("\nnearest integer tau to Koide given (1,207):", best, " K-2/3 = %.2e" % (K(np.array([1., 207., best])) - 2/3))
print("  exact mu given (1,%d): %.5f" % (best, brentq(lambda x: K(np.array([1, x, best]))-2/3, 150, 260)))
# --- one phase of the family operator reproduces the counts
def ratios(d):
    m = np.sort([(1+np.sqrt(2)*np.cos(d+2*np.pi*k/3))**2 for k in range(3)]); return m[1]/m[0], m[2]/m[0]
dC = brentq(lambda d: ratios(d)[0]-207, 0.2, 0.24); dM = brentq(lambda d: ratios(d)[0]-206.768283, 0.2, 0.24)
print("phase giving mu = 207      : delta = %.6f, ratios 1 : %.4f : %.4f" % ((dC,)+ratios(dC)))
print("phase from measured e, mu  : delta = %.6f, ratios 1 : %.4f : %.4f" % ((dM,)+ratios(dM)))
print("relative excess of counts over measurement: mu %.3f%%, tau(3481) %.3f%%, tau(3483) %.3f%%"
      % (100*(207/206.768283-1), 100*(3481/3477.37-1), 100*(3483/3477.37-1)))
print("chance that a random value lies within %.4f of an integer: %.4f"
      % (abs(ratios(dC)[1]-best), 2*abs(ratios(dC)[1]-best)))
print("\n=== Part 3")
import numpy as np
from itertools import product, combinations
V = [np.array(v) for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]   # (t,x,y,z)
n = len(V)
nn = lambda a, b: int((V[a]-V[b]) @ (V[a]-V[b])) == 2
part = lambda i: 'S' if V[i][0] == 0 else ('F' if V[i][0] > 0 else 'P')
E = [(a, b) for a, b in combinations(range(n), 2) if nn(a, b)]
spokes = list(range(n))
tri = [c for c in combinations(range(n), 3) if all(nn(a, b) for a, b in combinations(c, 2))]
# planar squares: 4-cycles a-b-c-d with a,c and b,d at distance 2 (|diff|^2 = 4), coplanar
sq = set()
for a, c in combinations(range(n), 2):
    if int((V[a]-V[c]) @ (V[a]-V[c])) != 4: continue
    common = [b for b in range(n) if nn(a, b) and nn(c, b)]
    for b, d in combinations(common, 2):
        if int((V[b]-V[d]) @ (V[b]-V[d])) == 4:
            M = np.array([V[a], V[b], V[c], V[d]]) - V[a]
            if np.linalg.matrix_rank(M) == 2: sq.add(tuple(sorted((a, b, c, d))))
sq = sorted(sq)
print(f"24-cell: V={n}, shell edges={len(E)}, spokes={len(spokes)}, triangles={len(tri)}, planar squares={len(sq)}")
T = {i: [j for j in range(n) if np.array_equal(V[j], V[i]*np.array([-1, 1, 1, 1]))][0] for i in range(n)}
def where(obj):
    ps = {part(i) for i in obj}
    if ps == {'S'}: return 'S'
    if 'F' in ps and 'P' in ps: return 'X'          # straddles future and past
    return 'F' if 'F' in ps else 'P'
def tally(objs):
    d = {'S': 0, 'F': 0, 'P': 0, 'X': 0}
    for o in objs: d[where(o)] += 1
    return d
def orbits(objs):
    seen = set(); k = 0
    for o in objs:
        key = tuple(sorted(o))
        if key in seen: continue
        img = tuple(sorted(T[i] for i in o)); seen |= {key, img}; k += 1
    return k
cats = {'edges': [tuple(e) for e in E], 'spokes': [(i,) for i in spokes], 'triangles': tri, 'squares': sq}
for k, objs in cats.items():
    print(f"  {k:9s}: {tally(objs)}  orbits under T = {orbits(objs)}")
eo, so, qo = orbits(cats['edges']), orbits(cats['spokes']), orbits(cats['squares'])
print(f"accepted rule: (E {eo} + spokes {so}) x squares {qo} - 27 = {(eo+so)*qo-27}")
# surface: the T-fixed equatorial sphere = 12 vertices, 24 edges, 8 triangles + 6 squares
tS = tally(tri)['S']; qS = tally(sq)['S']; eS = tally(cats['edges'])['S']
chi_S = 12 - eS + tS + qS
print(f"shared surface (cuboctahedron): V=12, E={eS}, triangles={tS}, squares={qS}, chi = {chi_S}")
# candidate gluing schemes for the count, each followed by the -D^3 shedding
K = lambda m: m.sum()/np.sqrt(m).sum()**2
def rep(name, Ct):
    m = np.array([1, 207, Ct], float)
    print(f"  {name:62s} C_tau = {Ct:8.2f}  K-2/3 = {K(m)-2/3:+.2e}")
tE = tally(cats['edges']); tSp = tally(cats['spokes']); tQ = tally(sq)
EF = tE['F'] + tE['S'] + tSp['F'] + tSp['S']; QF = tQ['F'] + tQ['S']; ES = tE['S'] + tSp['S']; QS = tQ['S']; QX = tQ['X']
print("\ncandidate counts:")
rep("orbit counting (accepted)", (eo+so)*qo - 27)
rep("future half + straddling squares, no surface dedup", EF*(QF+QX) - 27)
rep("orbifold: surface weighted 1/2", ((EF-ES/2))*(QF+QX-QS/2) - 27)
rep("halves glued by inclusion-exclusion of products, /2", (2*EF*(QF+QX) - ES*QS)/2 - 27)
rep("orbit counting minus chi(surface) [additive]", (eo+so)*qo - 27 - chi_S)
rep("orbit counting, surface square counted once per half, minus overlap", (eo+so)*(qo) - 27 - (QS - (qS - 4)))

print("\n=== Part 4: is the two-bit difference forced by the code or by T?")
# square stabilizers as edge chains; linear relations over Q and GF(2)
def frank(M):
    return np.linalg.matrix_rank(M.astype(float)) if M.size else 0
def grank(M):
    M = M.copy() % 2; r = 0
    for c in range(M.shape[1]):
        p = [i for i in range(r, M.shape[0]) if M[i, c]]
        if not p: continue
        M[[r, p[0]]] = M[[p[0], r]]
        for i in range(M.shape[0]):
            if i != r and M[i, c]: M[i] ^= M[r]
        r += 1
    return r
sq_edges = lambda s: [tuple(sorted(p)) for p in ((s[0], s[1]), (s[1], s[2]), (s[2], s[3]), (s[3], s[0]))]
def square_cycle(s):            # order the 4 vertices around the square
    a = s[0]; nb_ = [v for v in s if nn(a, v)]; c = [v for v in s if v != a and v not in nb_][0]
    return (a, nb_[0], c, nb_[1])
SQ = [square_cycle(s) for s in sq]
def relations(squares, edgelist, label):
    ei = {e: i for i, e in enumerate(edgelist)}; M = np.zeros((len(squares), len(edgelist)), np.int64)
    for i, s in enumerate(squares):
        for e in sq_edges(s): M[i, ei[e]] += 1
    print(f"  {label:34s} squares {len(squares):2d}  relations over Q {len(squares)-frank(M)}  over GF(2) {len(squares)-grank(M)}")
Eall = [tuple(sorted(e)) for e in E]
half = [s for s in SQ if all(part(v) in 'SF' for v in s)]
relations(half, [e for e in Eall if all(part(v) in 'SF' for v in e)], "one half (future + spatial)")
relations(SQ, Eall, "whole 24-cell shell")
# modulo T: one row per square orbit (sum over the orbit), one column per edge orbit
Eorb = {}; 
for e in Eall: Eorb.setdefault(min(e, tuple(sorted((T[e[0]], T[e[1]])))), len(Eorb))
eo_ = lambda e: Eorb[min(e, tuple(sorted((T[e[0]], T[e[1]]))))]
Sorb = {}
for s in SQ: Sorb.setdefault(min(tuple(sorted(s)), tuple(sorted(T[v] for v in s))), s)
M = np.zeros((len(Sorb), len(Eorb)), np.int64)
for i, s in enumerate(Sorb.values()):
    for e in sq_edges(s): M[i, eo_(e)] += 1
print(f"  {'modulo T (orbits)':34s} squares {len(Sorb):2d}  relations over Q {len(Sorb)-frank(M)}  over GF(2) {len(Sorb)-grank(M)}")
# Euler characteristic of the tube boundary and of the T-fixed set
cells3 = 24                                   # octahedral cells of the 24-cell
chiX = n - len(E) + len(tri) - cells3
print(f"\n  tube boundary (24-cell surface): V {n} - E {len(E)} + F {len(tri)} - C {cells3} = chi {chiX}")
print(f"  set fixed by T (cuboctahedron): chi {chi_S}")
print(f"  chi(X) - chi(X^T) = {chiX - chi_S}  (zero for any purely spatial tube, where T fixes everything)")

print("\n=== Table: counts before and after H3' against measured ratios (PDG)")
me = 0.51099895000
for name, c0, c1, m in (("electron", 1, 1, me), ("muon", 207, 207, 105.6583755), ("charged pion", 273, 273, 139.57039),
                        ("proton", 1836, 1836, 938.27208816), ("neutron", 1839, 1839, 939.56542052), ("tau", 3483, 3481, 1776.93)):
    r = m/me
    print(f"  {name:13s} {c0:5d} -> {c1:5d}   measured {r:9.3f}   deviation {100*(c0/r-1):+.3f}% -> {100*(c1/r-1):+.3f}%")

print("\n=== Part 5: spectral-geometric dictionary")
d0 = 0.22222205
Pm = np.roll(np.eye(3), 1, axis=0)
Wd = np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*d0)*Pm + np.exp(-1j*d0)*Pm.T)
for k_, f in ((1, 3*np.sqrt(6)), (2, 36.0), (3, 72*np.sqrt(6) + 18*np.sqrt(3)*np.cos(3*d0))):
    print(f"  Tr W^{k_} = {np.trace(np.linalg.matrix_power(Wd, k_)).real:.6f}   closed-walk formula {f:.6f}")
k_of = [1, 2, 0]                                   # characters of e, mu, tau
for name, m in (("measured", [1, 206.7682830, 3477.37]), ("MEI 3483", [1, 207, 3483]), ("MEI 3481", [1, 207, 3481])):
    x = np.sqrt(np.array(m, float)); w0 = x.mean(); w1 = np.mean([x[i]*np.exp(-2j*np.pi*k_of[i]/3) for i in range(3)])
    print(f"  Fourier inverse of {name:9s}: n+/n0 = {abs(w1)**2/w0**2:.7f}, phase = {np.angle(w1):.6f}")
dims = [24, 96, 96, 24]; trT = [12, 24, 8, -6]     # traces of T on vertices, edges, triangles, cells
print("  chi(X) =", sum((-1)**k*a for k, a in enumerate(dims)), " L(T) =", sum((-1)**k*b for k, b in enumerate(trT)),
      " Str(1-T) =", sum((-1)**k*(a-b) for k, (a, b) in enumerate(zip(dims, trT))))
for name, sel in (("muon", lambda v: v[0] == 0), ("tau", lambda v: True)):
    Vc = [np.zeros(4, int)] + [np.array(v) for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2 and sel(v)]
    A = np.array([[1.0 if (a-b)@(a-b) == 2 else 0.0 for b in Vc] for a in Vc]); dg = A.sum(1); m_ = A.sum()/2
    c4 = (np.trace(np.linalg.matrix_power(A, 4)) - 2*(dg**2).sum() + 2*m_)/8
    G = np.array([[1.0 if (a-b)@(a-b) == 4 else 0.0 for b in Vc] for a in Vc])
    sq_ = np.einsum('ab,bc,cd,da,ac,bd->', A, A, A, A, G, G)/8
    print(f"  {name}: all 4-cycles = {c4:.0f}; closed 4-walks with second-neighbour diagonals / 8 = {sq_:.0f} planar squares")

print("\n=== Part 6: D4 with Euclidean and Lorentzian bond weights")
from fractions import Fraction
nb4 = [np.array(v) for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]   # (t,x,y,z)
def reg(v):            # registry offset: spatial layer change (x+y+z)/2, half-layers for null bonds
    return Fraction(int(v[1]+v[2]+v[3]), 2)
for name, w in (("Euclidean", lambda v: 1), ("interval weighting, |interval|/2", lambda v: abs(v[0]**2 - (v[1]**2+v[2]**2+v[3]**2))//2),
                ("signed weighting, future +1 / past -1 on null bonds", lambda v: 1 if v[0] == 0 else int(np.sign(v[0])))):
    n0 = sum(w(v) for v in nb4 if reg(v) == 0); z = sum(w(v) for v in nb4)
    up = sum(w(v) for v in nb4 if reg(v) > 0); dn = sum(w(v) for v in nb4 if reg(v) < 0)
    print(f"  {name:47s} counts {n0}:{up}:{dn}  K = z/3n0 = {Fraction(z, 3*n0)}")
