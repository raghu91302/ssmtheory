#!/usr/bin/env python3
"""Status of assumption A4: is the family operator W a projection of the FCC hopping Hamiltonian?
1. The sqrt(n) couplings are the root-mean-square in-sheet and inter-sheet couplings over in-plane momenta.
2. No three single-site family states reproduce W (true second-order operator gives K ~ 1/3).
3. In-sheet Bloch waves give an exact projection with |f|^2 = 3 + eps; Koide's ratio only on eps = 1 + sqrt7,
   where the intrinsic phase is too small; the zero-momentum limit is the delocalized (K = 1/2) case.
4. Stability: second-neighbor hopping shifts K by about 3.3 (t2/t1)^2.
numpy only."""
import numpy as np
from itertools import product
d = 0.2222221
P = np.roll(np.eye(3), 1, axis=0)
def Wop(a0, a1, ph=d): return a0*np.eye(3) + a1*(np.exp(1j*ph)*P + np.exp(-1j*ph)*P.T)
def K(m): m = np.clip(np.real(m), 0, None); return m.sum()/np.sqrt(m).sum()**2

# ---- in-sheet geometry along [111] (unit in-plane bond)
a = [np.array([1, 0]), np.array([-.5, np.sqrt(3)/2]), np.array([-.5, -np.sqrt(3)/2])]
dj = [np.array([0, 1/np.sqrt(3)]), np.array([.5, -1/(2*np.sqrt(3))]), np.array([-.5, -1/(2*np.sqrt(3))])]
b1 = 2*np.pi*np.array([1, 1/np.sqrt(3)]); b2 = 2*np.pi*np.array([0, 2/np.sqrt(3)])
Ng = 300; u = (np.arange(Ng) + .5)/Ng
Q = np.array([x*b1 + y*b2 for x in u for y in u])
eps = np.array([sum(2*np.cos(q @ v) for v in a) for q in Q])
f = np.array([sum(np.exp(1j*q @ v) for v in dj) for q in Q])
print("1. rms in-sheet coupling  =", round(np.sqrt((eps**2).mean()), 5), " (sqrt6 =", round(np.sqrt(6), 5), ")")
print("   rms inter-sheet coupling =", round(np.sqrt((abs(f)**2).mean()), 5), " (sqrt3 =", round(np.sqrt(3), 5), ")")

# ---- single-site family states on a periodic lattice
L = 6
sites = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 0]
idx = {p: i for i, p in enumerate(sites)}; n = len(sites)
nn = [np.array(v) for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
H = np.zeros((n, n))
for p in sites:
    for v in nn: H[idx[p], idx[tuple((np.array(p) + v) % L)]] = 1
lay = lambda p: (sum(p)//2) % 3
W = Wop(np.sqrt(6), np.sqrt(3)); WW = W @ W.conj().T
a0 = idx[(0, 0, 0)]; Ks = []; maxc = 0
for b in [idx[p] for p in sites if lay(p) == 1]:
    for c in [idx[p] for p in sites if lay(p) == 2]:
        F = np.zeros((n, 3)); F[a0, 0] = F[b, 1] = F[c, 2] = 1
        Qp = np.eye(n) - F @ F.T
        M2 = F.T @ H @ Qp @ H @ F
        Ks.append(K(np.linalg.eigvalsh(M2))); maxc = max(maxc, abs(M2[0, 1]), abs(M2[0, 2]), abs(M2[1, 2]))
print(f"2. W W^dag needs off-diagonal {abs(WW[1,0]):.2f} t^2 against diagonal 12 t^2;"
      f" single-site states give at most {maxc:.0f} t^2")
print(f"   true second-order K over all single-site triples: {min(Ks):.3f} to {max(Ks):.3f}")

# ---- in-sheet Bloch waves: exact projection
print("3. identity |f|^2 = 3 + eps holds to", f"{np.abs(abs(f)**2 - 3 - eps).max():.1e}")
s7 = 1 + np.sqrt(7); on = np.abs(eps - s7) < 0.02
red = np.abs((np.angle(f[on]) + np.pi/3) % (2*np.pi/3) - np.pi/3)
print(f"   ratio 1/sqrt2 only on eps = 1 + sqrt7 = {s7:.4f}; intrinsic phase there <= {red.max():.3f}"
      f" (fitted 0.2222)")
print("   zero in-plane momentum: (eps, |f|) = (6, 3), the delocalized operator, K =",
      round(K(np.linalg.eigvalsh(Wop(6, 3, 0.332))**2), 4))

# ---- stability against second-neighbor hopping (6 second neighbors, 3 per adjacent sheet)
print("4. second-neighbor hopping t2 (added to the inter-sheet couplings):")
for t2 in (1e-3, 2e-3, 1e-2):
    x = np.linalg.eigvalsh(Wop(np.sqrt(6), np.sqrt(3 + 3*t2**2)))
    print(f"   t2/t1 = {t2:<6} K - 2/3 = {(x**2).sum()/x.sum()**2 - 2/3:+.2e}")

# ---- trace form of the relation (Section 5): Tr W = 3 sqrt(n0) t, Tr W^2 = 3 z t^2, K = z/(3 n0)
a = np.linalg.eigvalsh(W); nvec = np.ones(3)/np.sqrt(3)
print("5. trace form: Tr W =", round(np.trace(W).real, 4), "= 3 sqrt6;  Tr W^2 =", round(np.trace(W @ W).real, 4), "= 3 z;",
      " K = z/(3 n0) =", round(12/18, 6))
print("   democratic (a.n)^2 =", round((a @ nvec)**2, 4), " transverse |a|^2 - (a.n)^2 =", round(a @ a - (a @ nvec)**2, 4), "(equal: 45 deg)")
Mt = 8*np.eye(3) + 4*np.ones((3, 3)); mt = np.linalg.eigvalsh(Mt)
print("   single-site true operator: Tr M =", np.trace(Mt), " amplitude sum =", round(np.sqrt(mt).sum(), 3), " needed", round(3*np.sqrt(6), 3))
print("   electron at fitted phase: in-sheet", round(np.sqrt(6), 3), " out-of-sheet", round(2*np.sqrt(3)*np.cos(d + 2*np.pi/3), 3))
