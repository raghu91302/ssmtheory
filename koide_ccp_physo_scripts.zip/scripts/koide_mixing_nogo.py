#!/usr/bin/env python3
"""Working note: translation-character families forbid lepton mixing.

Reproduces every number in the note. numpy only; runs in a few seconds.
  1. Dirac neutrinos at arbitrary in-plane momentum: the neutrino operator commutes with the
     charged-lepton operator (no mixing).
  2. The C3-symmetric momenta: dimension of the space of operators commuting with T and R.
  3. Majorana neutrinos invariant under T: one pure state plus a degenerate, maximally mixed pair.
  4. D4 null bonds: registry rule r = -n (mod 3), half-step U with U^2 = T, Dirac and Majorana checks.
"""
import numpy as np
from itertools import product

w = np.exp(2j * np.pi / 3)
P = np.roll(np.eye(3), 1, axis=0)                      # cyclic shift A -> B -> C on sheet types
Clock = np.diag([1, w, w**2])
Wl = np.sqrt(6) * np.eye(3) + np.sqrt(3) * (np.exp(1j * 2 / 9) * P + np.exp(-1j * 2 / 9) * P.T)


def commutant_dim(ops):
    """Dimension of the space of 3x3 matrices commuting with every operator in ops."""
    A = np.vstack([np.kron(np.eye(3), O) - np.kron(O.T, np.eye(3)) for O in ops])
    return 9 - np.linalg.matrix_rank(A, 1e-9)


# 1. Dirac neutrinos at arbitrary in-plane momentum
rng = np.random.default_rng(1)
a = [np.array([1, 0]), np.array([.5, np.sqrt(3) / 2]), np.array([-.5, np.sqrt(3) / 2])]
inplane = a + [-v for v in a]                         # the 6 in-sheet bonds
c = np.array([.5, np.sqrt(3) / 6])                    # in-plane part of an up-bond
Rm = np.array([[-.5, -np.sqrt(3) / 2], [np.sqrt(3) / 2, -.5]])
up = [c, Rm @ c, Rm @ Rm @ c]                         # the 3 up-bonds
worst = 0
for _ in range(2000):
    q = rng.uniform(-8, 8, 2)
    dnu = rng.uniform(0, 2 * np.pi)
    eps = sum(np.exp(1j * q @ v) for v in inplane).real
    gam = sum(np.exp(1j * q @ v) for v in up)
    Wn = eps * np.eye(3) + gam * np.exp(1j * dnu) * P + np.conj(gam) * np.exp(-1j * dnu) * P.T
    worst = max(worst, np.abs(Wl @ Wn - Wn @ Wl).max())
print(f"1. Dirac, 2000 random momenta and phases: max |[W_l, W_nu]| = {worst:.1e}  (no mixing)")

# 2. the C3-symmetric momenta
print(f"2. zone center (T, R commute): commuting operators form a {commutant_dim([P])}-dim space (diagonal in T basis)")
print(f"   zone corner (T R = w R T):  commuting operators form a {commutant_dim([P, Clock])}-dim space (multiples of I)")

# 3. Majorana neutrinos invariant under T (character basis k = 0, 1, 2)
M = np.array([[0.05, 0, 0], [0, 0, 0.0087], [0, 0.0087, 0]])
print("3. Majorana, T-invariant: masses", np.round(np.sort(np.abs(np.linalg.eigvalsh(M))), 4),
      "(one isolated pure k=0 state, a degenerate maximally mixed k=1,2 pair)")

# 4. D4 null bonds
A1, A2 = np.array([1., 0.]), np.array([.5, np.sqrt(3) / 2])
Binv = np.linalg.inv(np.column_stack([A1, A2]))
z = np.array([1, 1, 1]) / np.sqrt(3); x = np.array([1, -1, 0]) / np.sqrt(2); y = np.cross(z, x)
Rot = np.vstack([x, y, z])


def registry(p3):
    f = Binv @ (Rot @ (np.array(p3) / np.sqrt(2)))[:2]
    return int(round(((f[0] + f[1]) % 1) * 3)) % 3


rows = {}
for p in product(range(-3, 4), repeat=4):
    if sum(p) % 2:
        continue
    rows.setdefault(p[1] + p[2] + p[3], set()).add(registry(p[1:]))
print("4. D4: each half-layer n has one registry, r = -n (mod 3):", all(v == {(-n) % 3} for n, v in rows.items()))

idx = lambda r, s: 2 * (r % 3) + (s % 2)               # registry x slice parity (6 states)
U = np.zeros((6, 6))
for r in range(3):
    for s in range(2):
        U[idx(r - 1, s + 1), idx(r, s)] = 1
T = np.linalg.matrix_power(U, 2)
order = next(k for k in range(1, 13) if np.allclose(np.linalg.matrix_power(U, k), np.eye(6)))
print(f"   half-step U has order {order}; U^2 raises the registry by one:",
      all(T[idx(r + 1, s), idx(r, s)] == 1 for r in range(3) for s in range(2)))
flav = np.array([[np.exp(2j * np.pi * k * r / 3) / np.sqrt(3) if s == 0 else 0
                  for r in range(3) for s in range(2)] for k in range(3)])
rng = np.random.default_rng(3)
worst = 0
for _ in range(300):
    cc = rng.normal(size=6) + 1j * rng.normal(size=6)
    Mn = sum(cc[k] * np.linalg.matrix_power(U, k) for k in range(6)); Mn = Mn + Mn.conj().T
    X = np.abs(flav.conj() @ np.linalg.eigh(Mn)[1]) ** 2
    worst = max(worst, np.sort(X, axis=0)[-2, :].max())
print(f"   Dirac, 300 random U-invariant operators: largest cross-flavor overlap = {worst:.1e}")
basis = []
for i in range(6):
    for j in range(i, 6):
        E = np.zeros((6, 6)); E[i, j] = E[j, i] = 1; basis.append(E)
S = np.array([(U.T @ E @ U - E).ravel() for E in basis]).T
nulls = np.linalg.svd(S)[2][np.linalg.matrix_rank(S):]
rng = np.random.default_rng(0)
Mm = sum(rng.normal() * sum(n * E for n, E in zip(v, basis)) for v in nulls)
ev, V = np.linalg.eigh(Mm.conj().T @ Mm)
X = np.abs(flav.conj() @ V[:, np.argsort(ev)[:3]]) ** 2
print("   Majorana, U-invariant: |overlaps|^2 with the 3 lightest states (rows e, mu, tau):")
for name, k in (("e", 1), ("mu", 2), ("tau", 0)):
    print(f"     {name:4s}", np.round(X[k], 3))
