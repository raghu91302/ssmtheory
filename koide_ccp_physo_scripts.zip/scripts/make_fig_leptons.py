#!/usr/bin/env python3
"""Fig. 3: the three charged leptons on the FCC lattice, drawn to scale.
Each panel shows a 2x2x2 block of FCC cubic cells (corners and face centres, nearest-neighbour bonds)
with true proportions. Three (111) sheets of the block are shaded in the sheet colours of Fig. 1.
A lepton is an eigenstate of the family operator W: equal weight on one site of each sheet type
(the three outlined sites, joined by bonds between sheets). Its phase on each sheet, from the
eigenvector of W, is shown by the fill colour of the site and by an arrow lying in the sheet.
Bottom: sqrt(m) = in-sheet part + between-sheet part."""
import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
from itertools import product
from matplotlib.lines import Line2D
sheetcol = {0: '#1f4e79', 1: '#b0522a', 2: '#3a7d44'}; lab = 'ABC'
phcol = {0: '#e3a21a', 120: '#7b3fa0', 240: '#1aa3a3'}
delta = 0.22222205                                   # fitted to m_mu/m_e (koide_model.py)
Pm = np.roll(np.eye(3), 1, axis=0)
W = np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*delta)*Pm + np.exp(-1j*delta)*Pm.T)
ev, V = np.linalg.eigh(W); me = ev[0]**2
names = ['electron $e$', r'muon $\mu$', r'tau $\tau$']
# FCC block: even-sum integer points in [0,4]^3 (units of half the cube edge); bonds have length sqrt2
N = 4
pts = np.array([p for p in product(range(N+1), repeat=3) if sum(p) % 2 == 0], float)
bonds = [(p, q) for i, p in enumerate(pts) for q in pts[i+1:] if abs(np.sum((p-q)**2) - 2) < 1e-9]
chain = np.array([[1, 1, 2], [2, 2, 2], [3, 3, 2]], float)       # sums 4, 6, 8: sheets A, B, C
sheet_of = lambda p: int((sum(p) - 4)/2) % 3
e1 = np.array([1, -1, 0])/np.sqrt(2); e2 = np.array([1, 1, -2])/np.sqrt(6)
R = np.array([e1, e2, np.ones(3)/np.sqrt(3)]); ctr = np.full(3, N/2)
rot = lambda X: (np.atleast_2d(X) - ctr) @ R.T
def plane_poly(s):                                   # cross-section of the cube with x+y+z = s
    corners = []
    for a, b in [(i, j) for i in range(3) for j in range(3) if i != j]:
        k = 3 - a - b
        for u, v in product((0, N), repeat=2):
            w = s - u - v
            if 0 <= w <= N:
                p = np.zeros(3); p[a] = u; p[b] = v; p[k] = w; corners.append(tuple(p))
    C = np.unique(np.array(corners), axis=0); c0 = C.mean(0)
    ang = [np.arctan2((q-c0)@e2, (q-c0)@e1) for q in C]
    return C[np.argsort(ang)]
fig = plt.figure(figsize=(7.6, 6.4))
gs = fig.add_gridspec(2, 3, height_ratios=[2.6, 1.0], hspace=-0.2, wspace=0.0)
for c in range(3):
    ax = fig.add_subplot(gs[0, c], projection='3d'); ax.computed_zorder = False
    v = V[:, c]*np.exp(-1j*np.angle(V[0, c]))
    for s, j in ((4, 0), (6, 1), (8, 2)):
        ax.add_collection3d(Poly3DCollection([rot(plane_poly(s))], facecolor=sheetcol[j], alpha=0.18,
                                             edgecolor=sheetcol[j], linewidth=0.8))
    cube = [(np.array(a, float), np.array(b, float)) for a in product((0, N), repeat=3) for b in product((0, N), repeat=3)
            if sum(x != y for x, y in zip(a, b)) == 1 and a < b]
    ax.add_collection3d(Line3DCollection([rot(np.array(e)) for e in cube], colors='0.35', linewidths=0.9))
    ax.add_collection3d(Line3DCollection([rot(np.array(b)) for b in bonds], colors='0.6', linewidths=0.35, alpha=0.6))
    on = [p for p in pts if sum(p) in (4, 6, 8)]; off = [p for p in pts if sum(p) not in (4, 6, 8)]
    off = rot(np.array(off)); ax.scatter(off[:, 0], off[:, 1], off[:, 2], s=30, color='0.7', edgecolor='0.4', linewidth=0.3, depthshade=False)
    for p in on: ax.scatter(*rot(p)[0], s=30, color=sheetcol[sheet_of(p)], edgecolor='k', linewidth=0.3, depthshade=False)
    rc = rot(chain); ax.add_collection3d(Line3DCollection([(rc[0], rc[1]), (rc[1], rc[2])], colors='k', linewidths=2.2))
    for j, p in enumerate(chain):
        ph = int(round(np.degrees(np.angle(v[j])))) % 360
        q = rot(p)[0]
        ax.scatter(*q, s=30, color=phcol[ph], edgecolor='k', linewidth=2.2, depthshade=False, zorder=10)
        d = 1.2*np.array([np.cos(np.radians(ph)), np.sin(np.radians(ph)), 0])
        ax.quiver(*q, *d, color='k', lw=1.5, arrow_length_ratio=0.25, zorder=11)
        ax.text(*(q + np.array([-1.25, 0.0, 0.05])), f'{ph}°', fontsize=7.5, weight='bold', zorder=12)
    for s, j in ((4, 0), (6, 1), (8, 2)):
        P = rot(plane_poly(s)); k = np.argmax(P[:, 0] - P[:, 1])
        ax.text(P[k, 0] + 0.25, P[k, 1] - 0.25, P[k, 2], lab[j], color=sheetcol[j], fontsize=10, weight='bold')
    ax.view_init(elev=20, azim=-75); L_ = 3.1
    ax.set_xlim(-L_, L_); ax.set_ylim(-L_, L_); ax.set_zlim(-L_, L_); ax.set_box_aspect((1, 1, 1), zoom=1.42); ax.axis('off')
    ax.text2D(0.5, 0.98, names[c], transform=ax.transAxes, ha='center', va='bottom', fontsize=11)
    bx = fig.add_subplot(gs[1, c]); ins = np.sqrt(6); out = ev[c] - ins
    bx.barh([2], [ins], color='#555555', height=0.6); bx.barh([1], [out], color='#aaaaaa', height=0.6)
    bx.barh([0], [ev[c]], color='k', height=0.6); bx.axvline(0, color='k', lw=0.6)
    for yy, val in ((2, ins), (1, out), (0, ev[c])): bx.text(max(val, 0) + 0.15, yy, f'{val:+.2f}', fontsize=7.5, va='center')
    bx.set_yticks([2, 1, 0]); bx.set_yticklabels(['in-sheet', 'between sheets', r'total $\sqrt{m}$'] if c == 0 else ['', '', ''], fontsize=8)
    bx.set_xlim(-3.6, 6.4); bx.set_ylim(-0.5, 2.5); bx.tick_params(axis='x', labelsize=7)
    bx.set_xlabel(r'amplitude $/t$', fontsize=8)
    r_ = ev[c]**2/me; bx.set_title(rf'$m/m_e = {"1" if c == 0 else f"{r_:.2f}"}$', fontsize=9)
    for s_ in ('top', 'right'): bx.spines[s_].set_visible(False)
hs = [Line2D([], [], marker='o', ls='', ms=7, mfc=phcol[p], mec='k', mew=1.4, label=f'lepton phase {p}°') for p in (0, 120, 240)]
fig.legend(handles=hs, loc='upper center', ncol=3, fontsize=8, frameon=False, bbox_to_anchor=(0.5, 0.86))
plt.savefig('../fig_leptons.pdf', bbox_inches='tight')
for c in range(3):
    v = V[:, c]*np.exp(-1j*np.angle(V[0, c])); print(names[c], np.round(np.degrees(np.angle(v)) % 360, 1), round(ev[c]**2/me, 2))
