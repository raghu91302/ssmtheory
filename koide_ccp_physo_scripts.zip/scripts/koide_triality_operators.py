#!/usr/bin/env python3
"""koide_triality_operators.py -- what kind of symmetry is the 'triality' cycle?

Settles three statements about the coordinate 3-cycle
    pi : (x0, x1, x2, x3) -> (x0, x3, x1, x2)      [spatial (x,y,z) -> (z,x,y)]
which Ref. [meiext] calls triality (it writes the inverse direction, (x0,x2,x3,x1),
which generates the same group) and Section 10 of the Koide paper uses.

 S1  (geometry) pi permutes the three groups of D4 bonds ("sixteen-cells"),
     i.e. the three perfect matchings {01|23}, {02|13}, {03|12} of the coordinate
     pairs, and on the D3 = FCC slice it is the rotation about [111].
 S2  (code) pi is an automorphism of the D4 CSS code of Ref. [meiext] as explicit
     operators: it permutes the 1536 edge qubits, maps every Z-stabilizer row to a
     Z-stabilizer row and every X-stabilizer row to an X-stabilizer row, maps the
     single-edge (electron) syndromes onto each other, and cycles the three bond
     classes. Checked on the L = 4 code, whose n = 1536 and k = 1282 are re-derived
     here first (the distance, 3, is taken from Ref. [meiext], not re-checked).
 S3  (Lie theory) pi is NOT the outer triality automorphism of D4. It is a pure
     coordinate permutation, hence an element of the Weyl group W(D4) (an inner
     automorphism), and it acts trivially on D4*/D4, whose three non-zero classes
     carry the vector and the two spinor representations of Spin(8). Moreover no
     symmetry of the D4 root system that permutes those three classes by a 3-cycle
     is a symmetry of the code: the code places its X-stabilizers on the vector
     class (the odd-sum integer points), and the root-system symmetries preserving
     that choice are exactly the signed permutations, W(B4), of index 3 in W(F4).
Requires numpy only. Runs in a few seconds.
"""
import itertools as it
import numpy as np

ok = True
def check(name, cond):
    global ok
    ok &= bool(cond)
    print(f"[{'PASS' if cond else 'FAIL'}] {name}")

PI = (0, 3, 1, 2)                        # new[i] = old[PI[i]] : (x0,x1,x2,x3)->(x0,x3,x1,x2)
def pi(v):
    return tuple(v[PI[i]] for i in range(4))

# ------------------------------------------------------------------ S1 geometry
roots = sorted({tuple(s0 * (i == a) + s1 * (i == b) for i in range(4))
                for a, b in it.combinations(range(4), 2) for s0 in (1, -1) for s1 in (1, -1)})
check("24 roots of D4", len(roots) == 24)
matchings = [frozenset({frozenset({0, 1}), frozenset({2, 3})}),
             frozenset({frozenset({0, 2}), frozenset({1, 3})}),
             frozenset({frozenset({0, 3}), frozenset({1, 2})})]
def cell(r):                              # which sixteen-cell (matching) a root belongs to
    supp = frozenset(i for i in range(4) if r[i])
    return next(m for m, M in enumerate(matchings) if supp in M)
check("three sixteen-cells of 8 roots each",
      [sum(cell(r) == m for r in roots) for m in range(3)] == [8, 8, 8])
img = {m: {cell(pi(r)) for r in roots if cell(r) == m} for m in range(3)}
check("S1  pi maps each sixteen-cell onto one other, cyclically",
      all(len(v) == 1 for v in img.values()) and sorted(next(iter(v)) for v in img.values()) == [0, 1, 2]
      and all(next(iter(img[m])) != m for m in range(3)))
slice_roots = [r for r in roots if r[0] == 0]
check("S1  on the x0 = 0 slice (FCC), pi preserves the [111] layer index",
      all(sum(pi(r)[1:]) == sum(r[1:]) for r in slice_roots))

# ------------------------------------------------------------------ S2 the code
L = 4
nodes = [p for p in it.product(range(L), repeat=4) if sum(p) % 2 == 0]
voids = [p for p in it.product(range(L), repeat=4) if sum(p) % 2 == 1]
nidx = {p: i for i, p in enumerate(nodes)}
add = lambda p, d: tuple((p[i] + d[i]) % L for i in range(4))
edges, eidx = [], {}
for p in nodes:
    for r in roots:
        q = add(p, r)
        key = frozenset((p, q))
        if key not in eidx:
            eidx[key] = len(edges); edges.append((p, q))
n = len(edges)
HZ = np.zeros((len(nodes), n), np.uint8)
for e, (p, q) in enumerate(edges):
    HZ[nidx[p], e] = HZ[nidx[q], e] = 1
unit = [tuple(s * (i == a) for i in range(4)) for a in range(4) for s in (1, -1)]
HX = np.zeros((len(voids), n), np.uint8)
for v, c in enumerate(voids):
    nb = {add(c, u) for u in unit}                     # the 8 nodes of the sixteen-cell around c
    for e, (p, q) in enumerate(edges):
        if p in nb and q in nb:
            HX[v, e] = 1

def rank2(M):
    M = M.copy(); r = 0
    for c in range(M.shape[1]):
        piv = np.flatnonzero(M[r:, c])
        if piv.size == 0:
            continue
        pr = r + piv[0]
        M[[r, pr]] = M[[pr, r]]
        rows = np.flatnonzero(M[:, c]); rows = rows[rows != r]
        M[rows] ^= M[r]
        r += 1
        if r == M.shape[0]:
            break
    return r
rz, rx = rank2(HZ), rank2(HX)
k = n - rz - rx
print(f"     D4 code at L={L}: n={n}, rk HZ={rz}, rk HX={rx}, k={k}")
check("S2  code rebuilt: n=1536, uniform weight 24, CSS, k = 5L^4+2 = 1282",
      n == 1536 and set(HZ.sum(1)) == {24} and set(HX.sum(1)) == {24}
      and not ((HX.astype(int) @ HZ.T.astype(int)) % 2).any() and k == 5 * L**4 + 2)

# pi as a permutation of qubits, Z-checks and X-checks
qperm = np.array([eidx[frozenset((pi(p), pi(q)))] for (p, q) in edges])
zperm = np.array([nidx[pi(p)] for p in nodes])
vidx = {p: i for i, p in enumerate(voids)}
xperm = np.array([vidx[pi(c)] for c in voids])
check("S2  pi is a bijection on qubits", len(set(qperm)) == n)
# row of check c, transported: qubit e -> qperm[e]; check c -> zperm[c]
def transport(H, cperm):
    G = np.zeros_like(H)
    for c in range(H.shape[0]):
        G[cperm[c], qperm[np.flatnonzero(H[c])]] = 1
    return G
check("S2  pi maps every Z-stabilizer onto a Z-stabilizer (HZ invariant)", (transport(HZ, zperm) == HZ).all())
check("S2  pi maps every X-stabilizer onto an X-stabilizer (HX invariant)", (transport(HX, xperm) == HX).all())
orb = []
seen = set()
for e in range(n):
    if e in seen:
        continue
    o = [e]; f = qperm[e]
    while f != e:
        o.append(f); f = qperm[f]
    seen |= set(o); orb.append(len(o))
check("S2  qubit orbits: 512 orbits of size 3, none fixed (as stated in Ref. [meiext])",
      sorted(set(orb)) == [3] and len(orb) == 512)
# bond classes of qubits and single-edge (electron) syndromes
def ecell(e):
    p, q = edges[e]
    d = tuple(((q[i] - p[i] + 1) % L) - 1 for i in range(4))
    return cell(d)
check("S2  pi cycles the three bond classes of the qubits",
      {(ecell(e), ecell(qperm[e])) for e in range(n)} == {(m, next(iter(img[m]))) for m in range(3)})
synd_ok = all(
    (set(zperm[np.flatnonzero(HZ[:, e])]) == set(np.flatnonzero(HZ[:, qperm[e]])))
    and (set(xperm[np.flatnonzero(HX[:, e])]) == set(np.flatnonzero(HX[:, qperm[e]])))
    for e in range(n))
check("S2  single-edge defect syndromes are carried onto single-edge syndromes", synd_ok)

# ------------------------------------------------------------------ S3 Lie theory
signed = []
for p in it.permutations(range(4)):
    for s in it.product((1, -1), repeat=4):
        M = np.zeros((4, 4))
        for i in range(4):
            M[i, p[i]] = s[i]
        signed.append(M)
Hd = 0.5 * np.array([[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, 1, -1], [1, -1, -1, 1]])
key = lambda M: tuple(np.round(2 * M).astype(int).ravel())
G = {key(M): M for M in signed}
frontier = list(G.values())
while frontier:
    new = []
    for A in frontier:
        for B in (Hd,):
            C = A @ B
            if key(C) not in G:
                G[key(C)] = C; new.append(C)
    for A in list(new):
        for B in signed[:: 7]:
            C = A @ B
            if key(C) not in G:
                G[key(C)] = C; new.append(C)
    frontier = new
G = list(G.values())
R = np.array(roots, float)
rootset = {tuple(r) for r in roots}
check("S3  automorphism group of the D4 root system has order 1152 (= W(F4))",
      len(G) == 1152 and all({tuple(np.round(g @ r).astype(int)) for r in R} == rootset for g in G))
def is_weyl_D4(g):
    gi = np.round(g).astype(int)
    if not np.allclose(g, gi) or not (np.abs(gi).sum(1) == 1).all():
        return False
    return int((gi < 0).sum()) % 2 == 0
check("S3  |W(D4)| = 192 inside it", sum(map(is_weyl_D4, G)) == 192)
Pi = np.zeros((4, 4))
for i in range(4):
    Pi[i, PI[i]] = 1
check("S3  pi is an element of W(D4): an inner automorphism, not outer triality", is_weyl_D4(Pi))
# classes of D4*/D4: V = odd-sum integer, S+ / S- = half-integer with sum = 0 / 1 mod 2
def cls(y):
    if np.allclose(y, np.round(y)):
        return "0" if int(round(y.sum())) % 2 == 0 else "V"
    return "S+" if int(round(y.sum())) % 2 == 0 else "S-"
reps = {"V": np.array([1., 0, 0, 0]), "S+": np.array([.5, .5, .5, .5]), "S-": np.array([.5, .5, .5, -.5])}
def class_perm(g):
    return tuple(cls(g @ reps[c]) for c in ("V", "S+", "S-"))
check("S3  pi acts trivially on the vector and spinor classes of D4*/D4",
      class_perm(Pi) == ("V", "S+", "S-"))
three_cycles = [g for g in G if class_perm(g) in {("S+", "S-", "V"), ("S-", "V", "S+")}]
check("S3  root-system symmetries that 3-cycle the classes exist (384 of them: genuine triality)",
      len(three_cycles) == 384)
code_syms = [g for g in G if class_perm(g)[0] == "V"]       # keep X-stabilizer centres on V
check("S3  root-system symmetries preserving the code's X-stabilizer class: exactly the 384 "
      "signed permutations W(B4)", len(code_syms) == 384 and
      all(np.allclose(g, np.round(g)) and (np.abs(np.round(g)).sum(1) == 1).all() for g in code_syms))
check("S3  none of the genuine triality elements is a symmetry of the code",
      not any(class_perm(g)[0] == "V" for g in three_cycles))
check("S3  a triality element sends the X-stabilizer centre (1,0,0,0) off the integer lattice",
      all(not np.allclose(g @ reps["V"], np.round(g @ reps["V"])) for g in three_cycles))

print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
