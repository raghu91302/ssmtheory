#!/usr/bin/env python3
"""Working note, section "Can A2 be derived?": reproduces every number in it. numpy only.

  1. The code: translating by one layer maps the FCC code's checks onto themselves.
  2. A structureless particle: the delocalized family operator is the FCC band folded into the ABC cell;
     the localized sqrt6:sqrt3 operator is not a band at the symmetric in-plane momenta.
  3. The screw S (120-degree rotation plus one layer): S^3 is a pure translation along [111].
  4. Each triality component splits its bonds 2:1:1 by layer change (ratio 1/sqrt2).
  5. An oriented defect under three orientation rules: Koide survives, the family label stays positional,
     and the operator commutes with unoriented neutrinos (no mixing).
"""
import numpy as np
from itertools import product

I3 = np.eye(3)
P = np.roll(I3, 1, axis=0)
nn = [np.array(v) for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
layer = lambda v: int(sum(v)) // 2
comp = lambda v: 0 if v[0] == 0 else (1 if v[1] == 0 else 2)
Kf = lambda a: np.sum(a**2) / np.sum(a)**2

# 1. the code: vertex checks (12 bonds at a site) and octahedral checks (12 edges of a void), periodic box
L = 3; N = 2 * L
sites = [p for p in product(range(N), repeat=3) if sum(p) % 2 == 0]
wrap = lambda p: tuple(x % N for x in p)
bonds = sorted({tuple(sorted((p, wrap(np.add(p, v))))) for p in sites for v in nn})
bidx = {b: i for i, b in enumerate(bonds)}
B = lambda p, q: bidx[tuple(sorted((wrap(p), wrap(q))))]
vertex = [frozenset(B(p, np.add(p, v)) for v in nn) for p in sites]
offs = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
octa = [frozenset(B(np.add(c, d1), np.add(c, d2)) for i, d1 in enumerate(offs) for d2 in offs[i + 1:]
                  if not np.array_equal(np.add(d1, d2), (0, 0, 0)))
        for c in product(range(N), repeat=3) if sum(c) % 2 == 1]
checks = set(vertex) | set(octa)
Tb = lambda b: B(np.add(bonds[b][0], (1, 1, 0)), np.add(bonds[b][1], (1, 1, 0)))
print("1. one-layer translation maps every code check onto a check:",
      {frozenset(Tb(b) for b in c) for c in checks} == checks)

# 2. band folding
eps = lambda th: sum(np.exp(1j * th * layer(v)) for v in nn).real
print("2. FCC band along [111], zero in-plane momentum, equals 6 + 6 cos(theta):",
      all(np.isclose(eps(t), 6 + 6 * np.cos(t)) for t in np.linspace(0, 2 * np.pi, 50)))
print("   band at theta = 0, 2pi/3, 4pi/3:", [round(eps(2 * np.pi * k / 3), 6) for k in range(3)],
      "= eigenvalues of 6I + 3(P + P^-1):", np.round(np.sort(np.linalg.eigvalsh(6 * I3 + 3 * (P + P.T)))[::-1], 6))
a = [np.array([1, 0]), np.array([.5, np.sqrt(3) / 2]), np.array([-.5, np.sqrt(3) / 2])]
inpl = a + [-v for v in a]
c0 = np.array([.5, np.sqrt(3) / 6]); Rm = np.array([[-.5, -np.sqrt(3) / 2], [np.sqrt(3) / 2, -.5]])
up = [c0, Rm @ c0, Rm @ Rm @ c0]
for nm, q in (("Gamma", np.zeros(2)), ("K", np.array([4 * np.pi / 3, 0])), ("M", np.array([np.pi, np.pi / np.sqrt(3)]))):
    dg = sum(np.exp(1j * q @ v) for v in inpl).real; od = abs(sum(np.exp(1j * q @ v) for v in up))
    print(f"   folded band at in-plane {nm:5s}: off-diagonal/diagonal = {od / dg:+.4f}  (Koide needs +0.7071)")

# 3. the screw
Rr = np.array([[0, 0, 1], [1, 0, 0], [0, 1, 0]]); T = np.array([1, 1, 0])
print("3. screw S = rotate 120 deg + one layer: S^3 translates by", Rr @ Rr @ T + Rr @ T + T,
      "(straight along [111], no in-plane shift)")

# 4. component split
cnt = {(D, m): sum(1 for v in nn if layer(v) == D and comp(v) == m) for D in (-1, 0, 1) for m in range(3)}
print("4. bonds per triality component by layer change (down, own, up):",
      [(cnt[(-1, m)], cnt[(0, m)], cnt[(1, m)]) for m in range(3)], "-> ratio", round(1 / np.sqrt(2), 4))

# 5. oriented defect: registry x orientation (9 states), with the fitted phase
d, dn = 2 / 9, 0.332
S = {0: I3, 1: np.exp(1j * d) * P, -1: np.exp(-1j * d) * P.T}
tot = {D: sum(cnt[(D, m)] for m in range(3)) for D in (-1, 0, 1)}
rules = {
    "(a) orientation follows the bond": sum(np.sqrt(cnt[(D, m)]) * np.kron(S[D], np.outer(I3[m], np.ones(3)))
                                            for D in (-1, 0, 1) for m in range(3)),
    "(b) screw-locked orientation":     sum(np.sqrt(tot[D]) * np.kron(S[D], np.linalg.matrix_power(P, D % 3))
                                            for D in (-1, 0, 1)),
    "(c) orientation kept":             sum(np.sqrt(cnt[(D, 0)]) * np.kron(S[D], I3) for D in (-1, 0, 1)),
}
Wnu = np.kron(6 * I3 + 3 * (np.exp(1j * dn) * P + np.exp(-1j * dn) * P.T), I3)
Treg = np.kron(P, I3)
print("5. oriented defect (9 states), fitted phase:")
for nm, W in rules.items():
    amps = np.abs(np.linalg.eigvals(W)); dist = np.unique(np.round(amps[amps > 1e-9], 6))
    positional = np.allclose(W @ Treg, Treg @ W)
    print(f"   {nm:33s}: K = {Kf(dist):.6f}; family label = registry character: {positional}; "
          f"commutes with unoriented neutrinos: {np.allclose(W @ Wnu, Wnu @ W)}")
