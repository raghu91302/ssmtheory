#!/usr/bin/env python3
"""Koide paper v2, Section 8, "Void-trapped defects (quarks)": reproduces every number in that item.
numpy only.

  1. Geometry: nearest nodes of a tetrahedral and an octahedral void, split by layer along [111].
  2. The direct analog of the family operator (couplings sqrt(n) to those nodes, masses from W W^dagger):
     the range of K over all phases, and the highest K a tetrahedral void reaches with any in-layer coupling.
  3. The observed quark triplets, with PDG masses and with running masses at M_Z.
"""
import numpy as np
from itertools import product

Kf = lambda a: np.sum(a**2) / np.sum(a)**2
P = np.roll(np.eye(3), 1, axis=0)

# 1. geometry
nodes = [np.array(p) for p in product(range(-2, 3), repeat=3) if sum(p) % 2 == 0]
layer = lambda p: sum(p) / 2
print("1. nearest nodes of each void, by layer offset along [111]:")
for nm, c in (("tetrahedral void", np.array([.5, .5, .5])), ("octahedral void", np.array([1., 0., 0.]))):
    r = min(np.linalg.norm(n - c) for n in nodes if np.linalg.norm(n - c) > 1e-9)
    split = {}
    for n in nodes:
        if abs(np.linalg.norm(n - c) - r) < 1e-9:
            off = float(round(layer(n) - layer(c), 2)); split[off] = split.get(off, 0) + 1
    print(f"   {nm:16s}: {sum(split.values())} nodes, split {dict(sorted(split.items()))} (none in its own layer)")


# 2. the direct analog of the family operator
def K_over_phases(a, bu, bd, n=4001):
    vals = []
    for d in np.linspace(0, 2 * np.pi, n):
        W = a * np.eye(3) + bu * np.exp(1j * d) * P + bd * np.exp(-1j * d) * P.T
        vals.append(Kf(np.linalg.svd(W, compute_uv=False)))   # sqrt(m) = singular values of W
    return min(vals), max(vals)


print("2. K over all phases (masses from W W^dagger):")
for nm, args in (("site (lepton check, 6:3:3)", (np.sqrt(6), np.sqrt(3), np.sqrt(3))),
                 ("tetrahedral void (3:1)", (0, np.sqrt(3), 1)),
                 ("octahedral void (3:3)", (0, np.sqrt(3), np.sqrt(3)))):
    lo, hi = K_over_phases(*args)
    print(f"   {nm:28s}: K from {lo:.4f} to {hi:.4f}")
best = max((Kf(np.linalg.svd(a * np.eye(3) + np.sqrt(3) * np.exp(1j * d) * P + np.exp(-1j * d) * P.T,
                             compute_uv=False)), a)
           for a in np.linspace(0, 8, 801) for d in np.linspace(0, 2 * np.pi / 3, 601))
print(f"   tetrahedral void with any in-layer coupling a in [0, 8]: highest K = {best[0]:.4f} (a = {best[1]:.2f})")

# 3. observed quark triplets
pdg = dict(u=2.16, d=4.70, s=93.5, c=1273., b=4183., t=172570.)     # PDG 2024 (MeV)
mz = dict(u=1.38, d=2.82, s=57., c=638., b=2860., t=172100.)        # running at M_Z (Xing, Zhang, Zhou 2012)
K3 = lambda m, a, b, c: Kf(np.sqrt(np.array([m[a], m[b], m[c]])))
print("3. observed quark triplets:")
for nm, a, b, c in (("up-type (u, c, t)", "u", "c", "t"), ("down-type (d, s, b)", "d", "s", "b")):
    print(f"   {nm:20s}: K = {K3(pdg, a, b, c):.3f} (PDG), {K3(mz, a, b, c):.3f} (running at M_Z)")
