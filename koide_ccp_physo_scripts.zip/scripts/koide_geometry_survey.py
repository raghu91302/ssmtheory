#!/usr/bin/env python3
"""Which geometries support the Koide family construction?

The construction (Sections 3-5 of the paper) needs, along some stacking direction:
  (i)   exactly three sheet types, cycled by a lattice translation (registry period 3);
  (ii)  every site with the same neighbor counts (own type, next type, previous type) = (n0, n+, n-);
  (iii) n+ = n- > 0 (a Hermitian circulant with uniform cyclic hopping);
  (iv)  n0 = 2 n+, so that the localized couplings sqrt(n0) : sqrt(n+) have ratio 1/sqrt2.
Then K = (1 + 2 n+/n0)/3, which is 2/3 exactly when (iv) holds.

Part A scans Bravais lattices in dimensions 2-8 over every primitive stacking direction
with small Miller indices, using exact integer arithmetic. Sheet type of a lattice vector n
is (g.n) mod p, where g is the direction (a primitive dual vector) and p is the registry
period (the layer index of the shortest lattice vector along the normal). Neighbors are the
shortest nonzero lattice vectors. Counting by type mod 3 is generous: it also counts
neighbors two or more layers away, so a failure here is a failure of the construction.

Part B treats crystals with a basis (several sites per cell) and close-packed stacking
polytypes, with sheets defined by layer height (Part B1) or by lateral registry A/B/C (Part B2).
numpy only."""
import numpy as np
from itertools import product
from math import gcd
from functools import reduce

# ---------------------------------------------------------------- Part A: Bravais lattices
def cartan(kind, n):
    C = 2 * np.eye(n, dtype=int)
    if kind == "A":
        for i in range(n - 1): C[i, i + 1] = C[i + 1, i] = -1
    elif kind == "D":
        for i in range(n - 2): C[i, i + 1] = C[i + 1, i] = -1
        C[n - 3, n - 1] = C[n - 1, n - 3] = -1
    elif kind == "E":   # Bourbaki: 1-3-4-5-...-n chain, 2 attached to 4
        for i in range(2, n - 1): C[i, i + 1] = C[i + 1, i] = -1
        C[0, 2] = C[2, 0] = -1
        C[1, 3] = C[3, 1] = -1
    return C

def roots(C):
    """All roots of a simply laced root system, in simple-root coordinates."""
    n = len(C); simple = [tuple(int(i == j) for j in range(n)) for i in range(n)]
    R = set(simple); frontier = list(simple)
    while frontier:
        new = []
        for r in frontier:
            r = np.array(r)
            for i in range(n):
                s = r.copy(); s[i] -= int(r @ C[:, i])
                t = tuple(int(x) for x in s)
                if t not in R and any(t) and (all(x >= 0 for x in t) or all(x <= 0 for x in t)):
                    R.add(t); new.append(t)
        frontier = new
    R |= {tuple(-x for x in r) for r in R}
    return np.array(sorted(R))

def shortest(G, box):
    d = len(G); best, vs = None, []
    for v in product(range(-box, box + 1), repeat=d):
        if not any(v): continue
        v = np.array(v); q = int(v @ G @ v)
        if best is None or q < best: best, vs = q, [v]
        elif q == best: vs.append(v)
    return np.array(vs)

def gram_from_vectors(B):
    B = np.array(B); return (B @ B.T).astype(int)

def adj(G):
    G = np.array(G, dtype=object); d = len(G)
    from fractions import Fraction
    M = [[Fraction(int(x)) for x in row] for row in G]
    # exact inverse times determinant
    n = d; A = [row[:] + [Fraction(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0); A[c], A[p] = A[p], A[c]
        piv = A[c][c]; A[c] = [x / piv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c]; A[r] = [a - f * b for a, b in zip(A[r], A[c])]
    inv = [row[n:] for row in A]
    den = reduce(lambda a, b: a * b // gcd(a, b), [x.denominator for row in inv for x in row], 1)
    return np.array([[int(x * den) for x in row] for row in inv], dtype=np.int64)

def scan(G, NN, M):
    d = len(G); A = adj(G); res = []
    seen = set()
    for g in product(range(-M, M + 1), repeat=d):
        if not any(g) or reduce(gcd, [abs(x) for x in g]) != 1: continue
        first = next(x for x in g if x)
        if first < 0: continue                      # g and -g are the same axis
        g = np.array(g, dtype=np.int64)
        w = A @ g; w //= reduce(gcd, [abs(int(x)) for x in w])
        p = abs(int(g @ w))
        off = NN @ g
        if p != 3:
            res.append((tuple(g), p, None, int(np.abs(off).max()))); continue
        c = [int(np.sum(off % 3 == r)) for r in range(3)]
        res.append((tuple(g), p, tuple(c), int(np.abs(off).max())))
    return res

def verdict(c):
    n0, up, dn = c
    if up != dn: return "up != down"
    if n0 == 0: return "no own-type neighbors"
    if 2 * up == n0: return "KOIDE"
    return f"K = {(1 + 2 * up / n0) / 3:.4f}"

LATTICES = []
def add(name, G, NN=None, M=3, box=2):
    G = np.array(G, dtype=np.int64)
    if NN is None: NN = shortest(G, box)
    LATTICES.append((name, G, np.array(NN, dtype=np.int64), M))

# 2D
add("square (Z2)", [[1, 0], [0, 1]], M=6)
add("rectangular 1:2", [[1, 0], [0, 4]], M=6)
add("rectangular 1:sqrt2", [[1, 0], [0, 2]], M=6)
add("triangular (A2)", cartan("A", 2), roots(cartan("A", 2)), M=6)
add("centered rectangular", gram_from_vectors([[2, 0], [1, 3]]), M=6)
add("oblique", [[2, 1], [1, 3]], M=6)
# 3D
add("simple cubic (Z3)", np.eye(3, dtype=int), M=6)
add("FCC (A3 = D3)", cartan("A", 3), roots(cartan("A", 3)), M=6)
add("BCC (A3*)", gram_from_vectors([[1, 1, -1], [1, -1, 1], [-1, 1, 1]]), M=6)
add("simple hexagonal c=a", [[2, -1, 0], [-1, 2, 0], [0, 0, 2]], M=6)
add("simple hexagonal c=1.5a", [[8, -4, 0], [-4, 8, 0], [0, 0, 18]], M=6)
add("simple hexagonal c=1.633a", [[6, -3, 0], [-3, 6, 0], [0, 0, 16]], M=6)
add("tetragonal P c=1.5a", [[4, 0, 0], [0, 4, 0], [0, 0, 9]], M=6)
add("tetragonal I c=1.5a", gram_from_vectors([[4, 0, 0], [0, 4, 0], [2, 2, 3]]), M=6)
add("tetragonal I c=2a", gram_from_vectors([[2, 0, 0], [0, 2, 0], [1, 1, 2]]), M=6)
add("orthorhombic P 1:2:3", gram_from_vectors([[1, 0, 0], [0, 2, 0], [0, 0, 3]]), M=6)
add("orthorhombic C 2:3:4", gram_from_vectors([[2, 0, 0], [1, 3, 0], [0, 0, 4]]), M=6)
add("orthorhombic I 2:4:6", gram_from_vectors([[2, 0, 0], [0, 4, 0], [1, 2, 3]]), M=6)
add("orthorhombic F 2:4:6", gram_from_vectors([[0, 2, 3], [1, 0, 3], [1, 2, 0]]), M=6)
for k in range(-5, 12):
    if k in (0, 6): continue          # 90 deg = simple cubic, 60 deg = FCC, listed above
    if k == -4: continue              # cos = -1/3 is BCC, listed above
    add(f"rhombohedral cos={k}/12", [[12, k, k], [k, 12, k], [k, k, 12]], M=6)
add("monoclinic", [[3, 0, 1], [0, 5, 0], [1, 0, 7]], M=6)
add("triclinic", [[4, 1, 1], [1, 5, 2], [1, 2, 6]], M=6)
# 4D
add("hypercubic (Z4)", np.eye(4, dtype=int), M=4)
add("D4 (24-cell)", cartan("D", 4), roots(cartan("D", 4)), M=4)
add("A4", cartan("A", 4), roots(cartan("A", 4)), M=4)
add("A4*", adj(cartan("A", 4)), M=4, box=2)
# 5-8D
for n in (5, 6, 7, 8):
    add(f"Z{n}", np.eye(n, dtype=int), [r for s in (1, -1) for r in s * np.eye(n, dtype=int)], M=3 if n == 5 else 2)
    add(f"A{n}", cartan("A", n), roots(cartan("A", n)), M=3 if n == 5 else 2)
    add(f"D{n}", cartan("D", n), roots(cartan("D", n)), M=3 if n == 5 else 2)
for n in (6, 7, 8):
    add(f"E{n}", cartan("E", n), roots(cartan("E", n)), M=3 if n == 5 else 2)

print("PART A: Bravais lattices, every primitive stacking direction with |Miller index| <= M")
print(f"{'lattice':28s}{'dim':>4s}{'NN':>5s}{'M':>3s}{'axes':>7s}{'period 3':>9s}  outcomes among period-3 axes")
summary = {}
for name, G, NN, M in LATTICES:
    assert len({int(v @ G @ v) for v in NN}) == 1
    res = scan(G, NN, M)
    p3 = [r for r in res if r[1] == 3]
    outs = {}
    for g, p, c, reach in p3:
        v = verdict(c)
        key = v if v != "KOIDE" else ("KOIDE" if reach == 1 else "KOIDE (bonds beyond adjacent sheets)")
        outs.setdefault(key, []).append((g, c))
    summary[name] = outs
    o = "; ".join(f"{k}: {len(v)}" for k, v in sorted(outs.items())) or "-"
    print(f"{name:28s}{len(G):4d}{len(NN):5d}{M:3d}{len(res):7d}{len(p3):9d}  {o}")
    for k, v in outs.items():
        if k.startswith("KOIDE"):
            gs = [tuple(int(t) for t in x[0]) for x in v]
            print(f"{'':6s}-> {k} on {len(v)} axes, e.g. g = {gs[:3]}, counts (own, +1, -1) = {v[0][1]}")

# ---------------------------------------------------------------- Part B1: crystals with a basis
def crystal_scan(name, A, basis, M=3, tol=1e-6):
    """A: rows = Bravais vectors (Cartesian); basis: fractional positions. Sheets = layers
    perpendicular to the axis. Exact layer bookkeeping: with g a primitive dual vector, a site
    at fractional position n + f lies at height (g.n + g.f) d, where d is the lattice-plane spacing."""
    from fractions import Fraction
    A = np.array(A, float); d = A.shape[1]
    fb = [[Fraction(x).limit_denominator(48) for x in b] for b in basis]
    basis = np.array(basis, float)
    Gm = A @ A.T
    # crystal translations: basis differences that map the basis onto itself
    def maps(t):
        sh = (basis + t) % 1.0
        return all(np.any(np.all(np.abs(((x - basis + 0.5) % 1.0) - 0.5) < 1e-6, axis=1)) for x in sh)
    fracs = [j for j in range(len(basis)) if maps(basis[j] - basis[0])]
    R = 3
    cells = np.array(list(product(range(-R, R + 1), repeat=d)))
    sites = (cells[:, None, :] + basis[None, :, :])            # fractional
    cart = sites @ A
    nbrs = []
    for i, b in enumerate(basis @ A):
        dist = np.linalg.norm(cart - b, axis=2); dist[dist < tol] = np.inf
        idx = np.argwhere(np.abs(dist - dist.min()) < 1e-6)
        nbrs.append([(cells[c] + [fb[j][k] - fb[i][k] for k in range(d)]) for c, j in idx])
    out = []
    for g in product(range(-M, M + 1), repeat=d):
        if not any(g) or reduce(gcd, [abs(x) for x in g]) != 1 or next(x for x in g if x) < 0: continue
        w = np.linalg.solve(Gm, np.array(g, float))           # lattice direction along the normal
        w = w / np.abs(w[np.abs(w) > 1e-9]).min()
        wi = None
        for k in range(1, 400):
            if np.allclose(k * w, np.round(k * w), atol=1e-6):
                wi = np.round(k * w).astype(int); break
        if wi is None: out.append((g, "no lattice vector along axis")); continue
        wi = wi // reduce(gcd, [abs(int(x)) for x in wi])
        PB = abs(int(np.dot(g, wi)))                           # Bravais period, in plane spacings
        offs = sorted({sum(Fraction(gk) * f for gk, f in zip(g, fbi)) % 1 for fbi in fb})
        q = len(offs)
        uniform = all(offs[k] == Fraction(k, q) for k in range(q))
        if not uniform: out.append((g, dict(layers=None, uniform=False))); continue
        nl = PB * q                                             # layers per period
        cyclic = any(sum(Fraction(gk) * (fb[j][k] - fb[0][k]) for k, gk in enumerate(g)) % 1 == Fraction(1, q) % 1
                     or q == 1 for j in fracs)
        counts = []
        for nb in nbrs:
            lay = [int(q * sum(Fraction(int(gk)) * Fraction(x) for gk, x in zip(g, v))) for v in nb]
            counts.append(tuple(sum(1 for L in lay if L % nl == r) for r in range(nl)) if nl == 3 else None)
        out.append((g, dict(layers=nl, uniform=True, cyclic=bool(cyclic), counts=counts)))
    return out

def crystal_verdict(info):
    if isinstance(info, str): return info
    if not info["uniform"]: return "layers unevenly spaced"
    if info["layers"] != 3: return "period not 3"
    if not info["cyclic"]: return "types not cycled by a translation"
    if len(set(info["counts"])) > 1: return f"sites differ {sorted(set(info['counts']))}"
    return verdict(info["counts"][0])

s3 = np.sqrt(3)
CRYSTALS = [
    ("control: FCC as cubic cell + 4-site basis", np.eye(3), [[0, 0, 0], [0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]]),
    ("honeycomb", [[1, 0], [0.5, s3 / 2]], [[0, 0], [1 / 3, 1 / 3]]),
    ("kagome", [[1, 0], [0.5, s3 / 2]], [[0, 0], [0.5, 0], [0, 0.5]]),
    ("HCP (ideal c/a)", [[1, 0, 0], [0.5, s3 / 2, 0], [0, 0, np.sqrt(8 / 3)]], [[0, 0, 0], [1 / 3, 1 / 3, 0.5]]),
    ("diamond", [[0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]], [[0, 0, 0], [0.25, 0.25, 0.25]]),
    ("graphite AB", [[1, 0, 0], [0.5, s3 / 2, 0], [0, 0, 2 * 1.4]], [[0, 0, 0], [1 / 3, 1 / 3, 0], [0, 0, 0.5], [2 / 3, 2 / 3, 0.5]]),
    ("wurtzite", [[1, 0, 0], [0.5, s3 / 2, 0], [0, 0, np.sqrt(8 / 3)]], [[0, 0, 0], [1 / 3, 1 / 3, 0.5], [0, 0, 0.375], [1 / 3, 1 / 3, 0.875]]),
    ("pyrochlore", [[0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]], [[0, 0, 0], [0, 0.25, 0.25], [0.25, 0, 0.25], [0.25, 0.25, 0]]),
]
# rhombohedral (ABC) graphite: honeycomb sheets in ABC stacking, interlayer 2.4 x bond
a = 1.0; cl = 2.4
CRYSTALS.append(("graphite ABC (rhombohedral)", [[1, 0, 0], [0.5, s3 / 2, 0], [0, 0, 3 * cl]],
                 [[0, 0, 0], [1 / 3, 1 / 3, 0], [1 / 3, 1 / 3, 1 / 3], [2 / 3, 2 / 3, 1 / 3], [2 / 3, 2 / 3, 2 / 3], [0, 0, 2 / 3]]))

print("\nPART B1: crystals with a basis; sheets are layers perpendicular to the axis (|Miller| <= 3)")
for name, A, basis in CRYSTALS:
    res = crystal_scan(name, A, basis, M=3 if len(A) == 3 else 6)
    tally = {}
    for g, info in res:
        tally.setdefault(crystal_verdict(info), []).append(g)
    keys = sorted(tally, key=lambda k: -len(tally[k]))
    print(f"{name:30s} axes {len(res):3d}: " + "; ".join(f"{k}: {len(tally[k])}" for k in keys[:5]))
    for k in tally:
        if k == "KOIDE": print(f"{'':30s}-> KOIDE at {tally[k]}")

# ---------------------------------------------------------------- Part B2: close-packed polytypes
POS = {"A": (0, 0), "B": (1 / 3, 1 / 3), "C": (2 / 3, 2 / 3)}
def polytype(seq):
    """Triangular sheets stacked in the given A/B/C sequence; sheet type = lateral registry."""
    N = len(seq); h = np.sqrt(2 / 3); A = np.array([[1, 0, 0], [0.5, s3 / 2, 0], [0, 0, N * h]])
    basis = np.array([[*POS[s], i / N] for i, s in enumerate(seq)])
    cells = np.array(list(product(range(-2, 3), repeat=3)))
    sites = (cells[:, None, :] + basis[None, :, :]) @ A
    reg = np.array(["ABC".index(s) for s in seq])
    out = []
    for i, b in enumerate(basis @ A):
        dist = np.linalg.norm(sites - b, axis=2); dist[dist < 1e-9] = np.inf
        idx = np.argwhere(np.abs(dist - dist.min()) < 1e-6)
        r = (reg[idx[:, 1]] - reg[i]) % 3
        dz = np.sign(np.round((sites[idx[:, 0], idx[:, 1]] - b)[:, 2], 6))
        own = int(np.sum(r == 0)); up = tuple(int(np.sum((r == k) & (dz > 0))) for k in (1, 2))
        dn = tuple(int(np.sum((r == k) & (dz < 0))) for k in (1, 2))
        out.append((own, int(np.sum(r == 1)), int(np.sum(r == 2)), up, dn))
    return out

print("\nPART B2: close-packed stackings; sheet type = lateral registry A, B, C")
print("  per site: (own, next registry, previous registry); KOIDE needs (6,3,3) at every site,")
print("  with the next registry always above and the previous always below (a translation cycle)")
for name, seq in (("3C = FCC (ABC)", "ABC"), ("2H = HCP (AB)", "AB"), ("4H / dhcp (ABCB)", "ABCB"),
                  ("6H (ABCACB)", "ABCACB"), ("9R / Sm-type (ABABCBCAC)", "ABABCBCAC"), ("15R (ABCACBCABACABCB)", "ABCACBCABACABCB")):
    out = polytype(seq)
    ok = all(o[:3] == (6, 3, 3) and o[3] == (3, 0) and o[4] == (0, 3) for o in out)
    kinds = sorted({o[:3] for o in out})
    print(f"  {name:28s} site types {kinds}  ->  {'KOIDE' if ok else 'no'}")

# ---------------------------------------------------------------- Part C: the A_d series
print("\nPART C: root lattice A_d sliced along the coweight singling out A_{d-1}: families = d, n+/n0 = 1/(d-1); Koide needs 3 families and 1/2")
for dd in (2, 3, 4, 5, 6):
    rts = [np.array([int(k == i) - int(k == j) for k in range(dd+1)]) for i in range(dd+1) for j in range(dd+1) if i != j]
    n0 = sum(1 for r in rts if r[dd] == 0); nu = sum(1 for r in rts if r[dd] == -1); ndn = sum(1 for r in rts if r[dd] == 1)
    print(f"  A_{dd}: bonds {n0}:{nu}:{ndn}, sheet types {dd}, n+/n0 = 1/{dd-1}  ->  {'KOIDE' if dd == 3 else 'no'}")

# ---------------------------------------------------------------- Part D: D4 with the half-layer registry
print("\nPART D: D4 along [111], registry r = -(half-layer) mod 3 (two null steps = one stacking translation)")
D4n = [np.array(v) for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
reg = lambda v: (-int(v[1] + v[2] + v[3])) % 3
for name, S in (("FCC slice (12 spatial)", [v for v in D4n if v[0] == 0]), ("null bonds only (12)", [v for v in D4n if v[0] != 0]), ("full D4 (24)", D4n)):
    c = [sum(1 for v in S if reg(v) == r) for r in range(3)]
    K = (sum(c)/(3*c[0])) if c[0] else float('nan')
    print(f"  {name:24s} counts (own, +1, -1) = {tuple(c)}   K = z/(3 n0) = {K:.4f}")
