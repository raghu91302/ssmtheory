Verification scripts for:
  "Synthetic Causal Geometry in the Selection-Stitch Model"
  (R. Kulkarni, 2026)

Contents:
  verify_synthetic_geometry.py   reproduces (12 labeled checks): the
                                 no-signalling invariance of Theorem 1
                                 (random channels and the Bell case);
                                 the toy model's D(t) and influence
                                 time; the FCC 12-shell moments, the
                                 leading isotropic Laplacian, the
                                 fourth-moment identity, and the
                                 quartic cubic anisotropy
  PL_protocol.md                 the series pre-registration including
                                 Amendment 8 (this paper's registered
                                 experimental protocol and outcomes)
  PL_extraction.md               the series execution record

Requirements: Python 3 with numpy (scipy optional).
Run:          python3 verify_synthetic_geometry.py
Expected:     12x PASS, then ALL PASS. Runtime: seconds.
