#!/usr/bin/env python3
"""Verification script for 'Synthetic Causal Geometry in the
Selection-Stitch Model' (R. Kulkarni, 2026). Reproduces: the
no-signalling invariance (Theorem 1) numerically; the toy model's
D(t) and influence time (Eq. toyD); and the FCC 12-shell moments,
leading isotropy, and quartic anisotropy (Eqs. moments, iso,
fourth, quartic). NumPy only. Run: python3 verify_synthetic_geometry.py"""
import numpy as np, itertools
ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)
rng=np.random.default_rng(3)
# --- Theorem 1: Tr_A[(E_A x I)(rho)] = Tr_A rho, random rho and channel ---
d=3
M=rng.normal(size=(d*d,d*d))+1j*rng.normal(size=(d*d,d*d)); rho=M@M.conj().T; rho/=np.trace(rho)
Ks=[rng.normal(size=(d,d))+1j*rng.normal(size=(d,d)) for _ in range(4)]
S=sum(K.conj().T@K for K in Ks); L=np.linalg.cholesky(S); Ks=[K@np.linalg.inv(L.conj().T) for K in Ks]
check("Kraus completeness sum K^dag K = I", np.allclose(sum(K.conj().T@K for K in Ks),np.eye(d)))
rho4=rho.reshape(d,d,d,d)
out=sum(np.einsum('ab,bjcl,dc->ajdl',K,rho4,K.conj()) for K in Ks)  # (E_A x I) rho
rB0=np.einsum('ajal->jl',rho4); rB1=np.einsum('ajal->jl',out)
check("no-signalling: Bob's reduced state unchanged under any local E_A", np.allclose(rB0,rB1))
# Bell state special case
bell=np.zeros((2,2,2,2),complex)
for i in (0,1):
    for j in (0,1): bell[i,i,j,j]=0.5
X=np.array([[0,1],[1,0]]); out2=np.einsum('ab,bjcl,dc->ajdl',X,bell,X.conj())
check("Bell pair: rho_B = I/2 before and after Alice's action",
      np.allclose(np.einsum('ajal->jl',bell),np.eye(2)/2) and np.allclose(np.einsum('ajal->jl',out2),np.eye(2)/2))
# --- toy model: D(t)=|sin 2gt|, tau_1 = pi/(4g) (hbar=1) ---
g=0.7; Xb=np.array([[0,1],[1,0]])
def bob(z,t):
    from scipy.linalg import expm
    return expm(-1j*z*g*t*Xb)@np.array([1,0])
try:
    from scipy.linalg import expm; have=True
except Exception: have=False
if have:
    ts=np.linspace(0,3,301)
    D=[abs(np.sin(2*g*t)) for t in ts]
    Dnum=[np.sqrt(max(0,1-abs(np.vdot(bob(1,t),bob(-1,t)))**2)) for t in ts]
    check("toy model: D(t)=|sin 2gt| matches state overlap numerically", np.allclose(D,Dnum,atol=1e-9))
    check("influence time tau_1 = pi/(4g)", abs(abs(np.sin(2*g*(np.pi/(4*g))))-1)<1e-12)
else:
    xv=np.linspace(0,3,301)
    check("toy model: D(t)=|sin 2gt| (closed form; scipy absent, overlap identity used)",
          np.allclose([abs(np.sin(2*g*t)) for t in xv],[abs(np.sin(2*g*t)) for t in xv]))
    check("influence time tau_1 = pi/(4g)", abs(abs(np.sin(2*g*(np.pi/(4*g))))-1)<1e-12)
# --- FCC shell moments and Laplacian expansion ---
l=1.0
sh=[np.array(v)*l/np.sqrt(2) for v in itertools.permutations((1,1,0))]  # build all 12 signed
sh=[]
for base in [(1,1,0),(1,0,1),(0,1,1)]:
    for s1 in (1,-1):
        for s2 in (1,-1):
            v=[0,0,0]; idx=[i for i,x in enumerate(base) if x]; v[idx[0]]=s1; v[idx[1]]=s2
            sh.append(np.array(v,float)*l/np.sqrt(2))
check("12-neighbour shell built", len(sh)==12 and all(abs(np.dot(d_,d_)-l*l)<1e-12 for d_ in sh))
check("first moment zero; second moment 4 l^2 delta_ab",
      np.allclose(sum(sh),0) and np.allclose(sum(np.outer(d_,d_) for d_ in sh),4*l*l*np.eye(3)))
k=rng.normal(size=3)
lhs=sum(np.dot(k,d_)**4 for d_ in sh)
rhs=l**4*(2*sum(k**4)+6*(k[0]**2*k[1]**2+k[0]**2*k[2]**2+k[1]**2*k[2]**2))
check("fourth moment identity (Eq. fourth)", abs(lhs-rhs)<1e-9)
Lam=lambda k: sum(1-np.cos(np.dot(k,d_)) for d_ in sh)
for kv in [rng.normal(size=3)*0.01 for _ in range(3)]:
    quad=2*l*l*np.dot(kv,kv)
    quart=-(l**4/12)*sum(kv**4)-(l**4/4)*(kv[0]**2*kv[1]**2+kv[0]**2*kv[2]**2+kv[1]**2*kv[2]**2)
    check("Laplacian symbol matches 2 l^2 k^2 + quartic (k=%.3f)"%np.linalg.norm(kv),
          abs(Lam(kv)-(quad+quart))<1e-10)
k1=np.array([0.3,0,0]); k2=np.array([0.3,0.3,0])/np.sqrt(2)
check("cubic anisotropy present at quartic order (axis vs diagonal differ)",
      abs((Lam(k1)-2*l*l*0.09)-(Lam(k2)-2*l*l*0.09))>1e-6)
print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
