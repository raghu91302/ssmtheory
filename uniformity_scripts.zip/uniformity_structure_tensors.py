"""uniformity_structure_tensors.py
Reproduces Eq. (1): the two-sublattice speed split.
Structure-tensor eigenvalues of the <110> graviton network (K=12) and the
<111>-diamond photon sublattice (K=4), and the resulting speed ratio 1/sqrt(3).
Paper: Speed Universality from Domain-Boundary Transport on a Polycrystalline
Emergent Vacuum (Kulkarni, 2026), Section 2.
Requires: numpy.
"""
import itertools
import numpy as np

def structure_eigenvalue(vectors):
    v = np.array(vectors, float)
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    S = np.einsum('ai,aj->ij', v, v)
    eig = np.linalg.eigvalsh(S)
    assert np.allclose(eig, eig[0]), "structure tensor not isotropic"
    return eig[0]

# <110> graviton network: 12 nearest neighbors of FCC
nn110 = [d for d in itertools.product([-1, 0, 1], repeat=3)
         if sum(abs(x) for x in d) == 2]
# <111> diamond photon sublattice: 4 tetrahedral bond directions
diamond = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]

lam_g = structure_eigenvalue(nn110)    # K/d = 12/3 = 4
lam_p = structure_eigenvalue(diamond)  # K/d = 4/3

print(f"graviton <110>  (K=12): structure eigenvalue = {lam_g:.6f}  (expect 4)")
print(f"photon  diamond (K=4) : structure eigenvalue = {lam_p:.6f}  (expect 4/3 = {4/3:.6f})")
ratio = np.sqrt(lam_p / lam_g)
print(f"speed ratio c_gamma/c_g = sqrt((4/3)/4) = {ratio:.6f}  (expect 1/sqrt(3) = {1/np.sqrt(3):.6f})")
assert np.isclose(ratio, 1/np.sqrt(3))
print("PASS: Eq. (1) reproduced.")
