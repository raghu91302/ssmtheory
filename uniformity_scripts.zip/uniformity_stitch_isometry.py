"""uniformity_stitch_isometry.py
Reproduces Proposition 1: sector-independence of the grain-boundary stitch.
(1) spin-1 and spin-2 eigen-phases of the same rotation R are {m*theta},
    m = -1..1 and m = -2..2: one shared fundamental angle, no independent angle.
(2) both transports are norm-preserving isometries (parallel transport).
Paper: Section 4, Proposition 1. Requires: numpy, scipy.
"""
import numpy as np
from scipy.linalg import expm

def so3(axis, angle):
    ax = np.array(axis, float); ax /= np.linalg.norm(ax)
    K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
    return expm(angle * K)

def spin2_matrix(R):
    """5x5 matrix of h -> R h R^T on an orthonormalized symmetric-traceless basis."""
    e = [np.zeros((3, 3)) for _ in range(5)]
    e[0][0, 0] = 1; e[0][1, 1] = -1
    e[1][0, 0] = 1; e[1][2, 2] = -1
    e[2][0, 1] = e[2][1, 0] = 1
    e[3][0, 2] = e[3][2, 0] = 1
    e[4][1, 2] = e[4][2, 1] = 1
    B = []
    for m in e:
        v = m.copy()
        for b in B:
            v = v - np.sum(v * b) / np.sum(b * b) * b
        B.append(v)
    M = np.zeros((5, 5))
    for j, bj in enumerate(B):
        RbR = R @ bj @ R.T
        for i, bi in enumerate(B):
            M[i, j] = np.sum(bi * RbR) / np.sum(bi * bi)
    return M

theta = 0.3
R = so3([1, 1, 1], theta)
ph1 = np.sort(np.angle(np.linalg.eigvals(R)))
ph2 = np.sort(np.angle(np.linalg.eigvals(spin2_matrix(R))))
print(f"spin-1 eigen-phases: {np.round(ph1, 4)}   (expect m*{theta}, m=-1..1)")
print(f"spin-2 eigen-phases: {np.round(ph2, 4)}   (expect m*{theta}, m=-2..2)")
assert np.allclose(ph1, [-theta, 0, theta], atol=1e-9)
assert np.allclose(ph2, [-2*theta, -theta, 0, theta, 2*theta], atol=1e-9)

# isometry: h -> R h R^T preserves the Frobenius norm (test random h, several R)
rng = np.random.default_rng(0)
for _ in range(100):
    Rr = so3(rng.normal(size=3), rng.uniform(0, np.pi))
    h = rng.normal(size=(3, 3)); h = (h + h.T) / 2; h -= np.eye(3) * np.trace(h) / 3
    assert np.isclose(np.linalg.norm(Rr @ h @ Rr.T), np.linalg.norm(h))
    A = rng.normal(size=3)
    assert np.isclose(np.linalg.norm(Rr @ A), np.linalg.norm(A))
print("PASS: shared fundamental angle + norm-preserving isometry in both representations.")
