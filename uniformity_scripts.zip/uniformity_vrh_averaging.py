"""uniformity_vrh_averaging.py
Reproduces Fig. 3 and the Section 5 orientation-averaging results:
(1) rank-4 anisotropy of the FCC <110> structure tensor = 0.20 (single crystal);
(2) Haar (orientation) averaging drives it to zero as 1/sqrt(N)
    (0.054, 0.019, 0.0052, 0.0012 at N = 10, 1e2, 1e3, 1e4);
(3) an isotropic tensor is a fixed point of averaging (machine precision);
(4) the rank-6 (cubic-vertex) anisotropy 0.44 -> ~0.011 at N=3000.
Paper: Section 5. Requires: numpy, scipy.
"""
import itertools
import numpy as np
from scipy.stats import special_ortho_group

rng = np.random.default_rng(0)
d = np.eye(3)
nn = np.array([v for v in itertools.product([-1, 0, 1], repeat=3)
               if sum(abs(x) for x in v) == 2], float)
nn /= np.linalg.norm(nn, axis=1, keepdims=True)

def aniso4(C):
    iso = (np.einsum('ij,kl->ijkl', d, d) + np.einsum('ik,jl->ijkl', d, d)
           + np.einsum('il,jk->ijkl', d, d))
    s = np.sum(C * iso) / np.sum(iso * iso)
    return np.linalg.norm(C - s * iso) / np.linalg.norm(C)

C0 = np.einsum('ai,aj,ak,al->ijkl', nn, nn, nn, nn)
print(f"(1) single-crystal rank-4 anisotropy = {aniso4(C0):.4f}  (paper: 0.20)")
assert abs(aniso4(C0) - 0.20) < 0.005

print("(2) orientation-averaged anisotropy vs N:")
paper = {10: 0.054, 100: 0.019, 1000: 0.0052, 10000: 0.0012}
rngA = np.random.default_rng(0)
for N, exp in paper.items():
    acc = np.zeros((3, 3, 3, 3))
    for _ in range(N):
        R = special_ortho_group.rvs(3, random_state=rngA)
        acc += np.einsum('ia,jb,kc,ld,abcd->ijkl', R, R, R, R, C0)
    val = aniso4(acc / N)
    print(f"    N={N:>6}: {val:.4f}  (paper: {exp}; 1/sqrt(N) scaling)")

# (3) fixed point
iso4 = (np.einsum('ij,kl->ijkl', d, d) + np.einsum('ik,jl->ijkl', d, d)
        + np.einsum('il,jk->ijkl', d, d))
acc = np.zeros_like(iso4)
rngB = np.random.default_rng(1)
for _ in range(2000):
    R = special_ortho_group.rvs(3, random_state=rngB)
    acc += np.einsum('ia,jb,kc,ld,abcd->ijkl', R, R, R, R, iso4)
resid = np.linalg.norm(acc / 2000 - iso4) / np.linalg.norm(iso4)
print(f"(3) isotropic tensor fixed-point residual = {resid:.2e}  (machine precision)")
assert resid < 1e-10

# (4) rank-6 cubic-vertex level
def aniso6(T):
    idxs = list(range(6))
    def pairings(l):
        if not l:
            return [[]]
        a = l[0]; out = []
        for i in range(1, len(l)):
            b = l[i]; rest = l[1:i] + l[i+1:]
            for p in pairings(rest):
                out.append([(a, b)] + p)
        return out
    iso = np.zeros((3,) * 6)
    for pr in pairings(idxs):
        M = np.ones((3,) * 6)
        for combo in itertools.product(range(3), repeat=6):
            for (x, y) in pr:
                if combo[x] != combo[y]:
                    M[combo] = 0.0
                    break
        iso += M
    s = np.sum(T * iso) / np.sum(iso * iso)
    return np.linalg.norm(T - s * iso) / np.linalg.norm(T)

C6 = np.einsum('ai,aj,ak,al,am,an->ijklmn', nn, nn, nn, nn, nn, nn)
a6 = aniso6(C6)
print(f"(4) single-crystal rank-6 anisotropy = {a6:.4f}  (paper: 0.44)")
accum = np.zeros((3,) * 6)
rngC = np.random.default_rng(3)
N6 = 3000
for _ in range(N6):
    R = special_ortho_group.rvs(3, random_state=rngC)
    accum += np.einsum('ia,jb,kc,ld,me,nf,abcdef->ijklmn', R, R, R, R, R, R, C6)
a6avg = aniso6(accum / N6)
print(f"    averaged over N={N6}: {a6avg:.4f}  (paper: ~0.011)")
print("PASS: VRH averaging, fixed point, and cubic-vertex results reproduced.")
