"""uniformity_figures.py
Regenerates the three figures of the paper as vector PDFs:
  fig_obstruction.pdf  (Fig. 1: the two-sublattice sqrt(3) speed split)
  fig_washout.pdf      (Fig. 2: the stitch-bottleneck washout)
  fig_vrh.pdf          (Fig. 3: orientation averaging -> isotropy)
Requires: numpy, scipy, matplotlib.
"""
import itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from scipy.stats import special_ortho_group

rcParams.update({
    'font.family': 'serif', 'font.serif': ['DejaVu Serif'],
    'mathtext.fontset': 'dejavuserif', 'font.size': 9,
    'axes.linewidth': 0.8, 'axes.labelsize': 9, 'axes.titlesize': 9,
    'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'legend.fontsize': 8, 'legend.frameon': False,
    'xtick.direction': 'in', 'ytick.direction': 'in',
    'xtick.top': True, 'ytick.right': True,
    'figure.dpi': 300, 'savefig.dpi': 300,
    'savefig.bbox': 'tight', 'savefig.pad_inches': 0.03,
})
C_g, C_p, C_ac = '#2b3a67', '#8c2f39', '#3a7d44'
grid = {'color': '0.85', 'lw': 0.5}

# ---- Fig. 1: obstruction ----
fig, ax = plt.subplots(1, 2, figsize=(6.5, 2.5))
sectors = ['photon\n$\\langle111\\rangle$ diamond', 'graviton\n$\\langle110\\rangle$ network']
Kd = [4/3, 4.0]
speeds = [np.sqrt(4/3), 2.0]
x = np.arange(2)
ax[0].bar(x, Kd, width=0.5, color=[C_p, C_g], edgecolor='k', lw=0.6)
ax[0].set_xticks(x); ax[0].set_xticklabels(sectors)
ax[0].set_ylabel('structure eigenvalue  $K/d$')
ax[0].set_title('(a) single-crystal coordination')
for xi, v in zip(x, Kd):
    ax[0].text(xi, v + 0.15, f'{v:.3f}', ha='center', fontsize=8)
ax[0].set_ylim(0, 5)
ax[1].bar(x, speeds, width=0.5, color=[C_p, C_g], edgecolor='k', lw=0.6)
ax[1].set_xticks(x); ax[1].set_xticklabels(['$c_\\gamma$', '$c_g$'])
ax[1].set_ylabel('signal speed  $\\sqrt{K/d}$  (units $v_{lat}$)')
ax[1].set_title('(b) speed split  $c_\\gamma$$/$$c_g$$=$$1/\\sqrt{3}$')
ax[1].axhline(speeds[1], ls='--', color='0.4', lw=0.7)
ax[1].annotate('', xy=(1, speeds[1]), xytext=(1, speeds[0]),
               arrowprops=dict(arrowstyle='<->', color='k', lw=0.8))
ax[1].text(1.08, (speeds[0]+speeds[1])/2, '$\\sqrt{3}$', fontsize=9, va='center')
ax[1].set_ylim(0, 2.4)
for a in ax:
    a.grid(axis='y', **grid); a.set_axisbelow(True)
plt.tight_layout(); plt.savefig('fig_obstruction.pdf'); plt.close()

# ---- Fig. 2: washout ----
fig, ax = plt.subplots(figsize=(3.4, 2.6))
c_p0, c_g0 = 1/np.sqrt(3), 1.0
T = np.logspace(-2, 4, 300)
cp = 1.0/(1.0/c_p0 + T); cg = 1.0/(1.0/c_g0 + T)
ax.semilogx(T, cp/cg, color=C_g, lw=1.6)
ax.axhline(1.0, ls=':', color='0.5', lw=0.8)
ax.axhline(1/np.sqrt(3), ls='--', color=C_p, lw=0.8)
ax.text(2e-2, 1/np.sqrt(3)+0.02, '$1/\\sqrt{3}$ (intra-grain)', color=C_p, fontsize=7.5)
ax.text(6e3, 0.985, 'universality', color='0.35', fontsize=7.5, ha='right')
ax.set_xlabel('per-grain boundary cost  $\\tau_{stitch}/\\ell_{grain}$  (units $c_g^{-1}$)')
ax.set_ylabel('$c_\\gamma$$/$$c_g$')
ax.set_title('boundary crossings wash out the split')
ax.set_ylim(0.5, 1.05); ax.grid(**grid); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig('fig_washout.pdf'); plt.close()

# ---- Fig. 3: VRH ----
rng = np.random.default_rng(0)
nn = np.array([v for v in itertools.product([-1, 0, 1], repeat=3)
               if sum(abs(x) for x in v) == 2], float)
nn /= np.linalg.norm(nn, axis=1, keepdims=True)
C0 = np.einsum('ai,aj,ak,al->ijkl', nn, nn, nn, nn)
d = np.eye(3)

def aniso4(C):
    iso = (np.einsum('ij,kl->ijkl', d, d) + np.einsum('ik,jl->ijkl', d, d)
           + np.einsum('il,jk->ijkl', d, d))
    s = np.sum(C*iso)/np.sum(iso*iso)
    return np.linalg.norm(C - s*iso)/np.linalg.norm(C)

Ns = np.unique(np.round(np.logspace(0, 4, 22)).astype(int))
vals = []
for N in Ns:
    acc = np.zeros((3, 3, 3, 3))
    for _ in range(int(N)):
        R = special_ortho_group.rvs(3, random_state=rng)
        acc += np.einsum('ia,jb,kc,ld,abcd->ijkl', R, R, R, R, C0)
    vals.append(aniso4(acc/N))
fig, ax = plt.subplots(figsize=(3.4, 2.6))
ax.loglog(Ns, vals, 'o-', color=C_ac, ms=3, lw=1.1, label='FCC $\\langle110\\rangle$ average')
ax.loglog(Ns, 0.2/np.sqrt(Ns), '--', color='0.5', lw=0.9, label='$\\propto N^{-1/2}$')
ax.axhline(0.2, ls=':', color=C_g, lw=0.8)
ax.text(1.2, 0.21, 'single-crystal $0.20$', color=C_g, fontsize=7.5, va='bottom')
ax.set_xlabel('number of grain orientations  $N$')
ax.set_ylabel('rank-4 anisotropy')
ax.set_title('orientation averaging $\\to$ isotropy')
ax.legend(loc='lower left')
ax.grid(which='both', **grid); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig('fig_vrh.pdf'); plt.close()
print("wrote fig_obstruction.pdf, fig_washout.pdf, fig_vrh.pdf")
