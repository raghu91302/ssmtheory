"""uniformity_residual_suppression.py
Reproduces the Section 3/5 scale anchoring and residual suppression:
wavelength-to-bond ratios (3e28 visible light, 6e37 GW), the grain-count
example (N_grain ~ 1e25 for 1e3-bond grains at visible wavelengths), and the
(a/lambda)^2 ~ 1e-75 residual at gravitational-wave wavelengths vs the
GW170817 bound of 1e-15. Requires: numpy.
"""
import numpy as np

lP = 1.6e-35            # Planck-scale entanglement bond (m)
lam_vis = 5e-7          # visible light (m)
lam_gw = 1e3            # LIGO-band gravitational wave (m)

r_vis = lam_vis / lP
r_gw = lam_gw / lP
print(f"lambda/L (visible) = {r_vis:.1e}   (paper: 3e28)")
print(f"lambda/L (GW)      = {r_gw:.1e}   (paper: 6e37)")
assert 2e28 < r_vis < 4e28 and 5e37 < r_gw < 7e37

grain_bonds = 1e3
N_grain = r_vis / grain_bonds
print(f"N_grain at visible wavelengths, 1e3-bond grains = {N_grain:.0e}  (paper: ~1e25)")

supp = (2 * np.pi * lP / lam_gw) ** 2
print(f"(ka)^2 residual at GW wavelengths = {supp:.1e}  (paper: ~1e-75; GW170817 bound 1e-15)")
assert supp < 1e-15
print("PASS: scale anchoring and residual suppression reproduced.")
