# uniformity_ verification scripts

Reproduction scripts for every computed number and figure in:

R. Kulkarni, "Speed Universality from Domain-Boundary Transport on a
Polycrystalline Emergent Vacuum" (2026).

| Script | Reproduces |
|---|---|
| `uniformity_structure_tensors.py` | Eq. (1): the two-sublattice speed split, 1/sqrt(3) |
| `uniformity_stitch_isometry.py` | Proposition 1: shared eigen-angle + isometry (sector-independence of the stitch) |
| `uniformity_washout.py` | Eq. (2), Fig. 2 values, N-independence of the fractional split, and the 1e15 dominance requirement |
| `uniformity_vrh_averaging.py` | Section 5: rank-4 anisotropy 0.20, Haar averaging to zero (1/sqrt N), fixed-point check, rank-6 cubic-vertex 0.44 -> ~0.011 |
| `uniformity_residual_suppression.py` | Section 3/5: wavelength-to-bond ratios, grain-count example, (a/lambda)^2 residual vs GW170817 |
| `uniformity_figures.py` | Regenerates the paper's three figures as vector PDFs |

Each analysis script prints PASS after asserting agreement with the values
quoted in the paper. Requirements: `numpy`, `scipy`, `matplotlib` (figures only).
Run: `python3 <script>.py`
