"""boundary_scaling.py -- Sec. 4: patch-size scaling of the seam-sheet generators.
Same seed-7 bicrystal orientation, growing lateral window (fixed z-slabs +-6,
interior |z|<4.5). For each window: odd pairs, frustration rank r, r/area, and the
weight/extent statistics of the multi-check (weight>12) completion generators.
numpy + scipy."""
import numpy as np, collections
from scipy.spatial import cKDTree
from scipy.stats import special_ortho_group

bond=np.sqrt(2.0)
rng=np.random.default_rng(7)
R=special_ortho_group.rvs(3,random_state=rng); off=rng.uniform(0,1,3)

def rk(Mat):
    Mm=Mat.copy().astype(np.int8); r0=0
    for c in range(Mm.shape[1]):
        p=None
        for row in range(r0,Mm.shape[0]):
            if Mm[row,c]: p=row;break
        if p is None: continue
        Mm[[r0,p]]=Mm[[p,r0]]
        for row in range(Mm.shape[0]):
            if row!=r0 and Mm[row,c]: Mm[row]^=Mm[r0]
        r0+=1
    return r0

def nullspace(Mat):
    Mm=Mat.copy().astype(np.int8); m,n=Mm.shape; piv=[]; r0=0
    for c in range(n):
        p=None
        for row in range(r0,m):
            if Mm[row,c]: p=row;break
        if p is None: continue
        Mm[[r0,p]]=Mm[[p,r0]]
        for row in range(m):
            if row!=r0 and Mm[row,c]: Mm[row]^=Mm[r0]
        piv.append(c); r0+=1
    free=[c for c in range(n) if c not in piv]; basis=[]
    for f in free:
        v=np.zeros(n,np.int8); v[f]=1
        for ri,c in enumerate(piv):
            if Mm[ri,f]: v[c]=1
        basis.append(v)
    return basis

print("ext   LX    area   nZ    nX   odd    r   r/area  sheets  sheet weights (lateral extent x+y, bonds)")
for ext in [9,12,15]:
    LX=ext*0.65
    pts=[];looks=[]
    for Rm,offv,zlo,zhi in [(np.eye(3),np.zeros(3),-6,0),(R,off,0,6)]:
        look={}
        for x in range(-ext,ext+1):
            for y in range(-ext,ext+1):
                for z in range(-ext,ext+1):
                    if (x+y+z)%2==0:
                        p=Rm@np.array([x,y,z],float)+offv
                        if zlo<=p[2]<zhi and abs(p[0])<LX and abs(p[1])<LX:
                            look[(x,y,z)]=len(pts); pts.append(p)
        looks.append((Rm,offv,look))
    P=np.array(pts)
    t=cKDTree(P); edges=[];eidx={}
    for i,js in enumerate(t.query_ball_tree(t,1.05*bond)):
        for j in js:
            if j>i and np.linalg.norm(P[i]-P[j])>=0.95*bond:
                eidx[(i,j)]=len(edges); edges.append((i,j))
    nE=len(edges)
    def interior(p): return abs(p[0])<LX-1.8 and abs(p[1])<LX-1.8 and -4.5<p[2]<4.5
    starmap=collections.defaultdict(set)
    for e,(i,j) in enumerate(edges): starmap[i].add(e); starmap[j].add(e)
    Zl=[(i,es) for i,es in starmap.items() if interior(P[i])]
    Xl=[]
    for Rm,offv,look in looks:
        for x in range(-ext,ext+1):
            for y in range(-ext,ext+1):
                for z in range(-ext,ext+1):
                    if (x+y+z)%2==1:
                        c=Rm@np.array([x,y,z],float)+offv
                        if not interior(c): continue
                        nbs=[look[q] for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
                             if (q:=(x+d[0],y+d[1],z+d[2])) in look]
                        if len(nbs)>=4:
                            s=set(nbs)
                            es=set(eidx[(min(a,b),max(a,b))] for a in s for b in s
                                   if a<b and (min(a,b),max(a,b)) in eidx)
                            if es: Xl.append(es)
    SZ=np.zeros((len(Zl),nE),np.int8); SX=np.zeros((len(Xl),nE),np.int8)
    for r_,(_,es) in enumerate(Zl):
        for e in es: SZ[r_,e]=1
    for r_,es in enumerate(Xl):
        for e in es: SX[r_,e]=1
    mids=np.array([(P[i]+P[j])/2 for i,j in edges])
    M=(SX@SZ.T)%2
    odd=int(M.sum()); r=rk(M)
    area=(2*(LX-1.8))**2
    ker=nullspace(M.T)
    info=[]
    for v in np.array(ker,np.int8):
        s=np.nonzero((v@SX)%2)[0]
        if len(s)>12:
            ext_l=np.ptp(mids[s][:,0])+np.ptp(mids[s][:,1])
            info.append((len(s),ext_l))
    info.sort()
    sheets=", ".join(f"{w}({e:.0f})" for w,e in info)
    print(f"{ext:3d}  {LX:.2f}  {area:5.1f}  {len(Zl):4d}  {len(Xl):4d}  {odd:4d}  {r:4d}  {r/area:.3f}  {len(info):4d}    {sheets}")
