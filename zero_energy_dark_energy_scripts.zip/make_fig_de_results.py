"""make_fig_de_results.py -- Fig. 1. Panel (a): lag law from dark_energy_kinetics.py
(seed 11). Panel (b): driven elastic column from dark_energy_column.py (seed 5):
grand-density residual above the x=0 quasi-static reference (left axis) and
mean-square excess wall-bond stretch above the undriven thermal baseline (right axis).
All numbers are the deterministic outputs of the shipped scripts."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# (a) dark_energy_kinetics.py output
xk=np.array([0.003,0.01,0.03,0.1,0.3])
lag=np.array([0.00890,0.02924,0.08307,0.23174,0.47584])
xx=np.logspace(np.log10(0.002),np.log10(0.4),200)

# (b) dark_energy_column.py output: x=0 baseline 0.58257+-0.00409, wall<g^2>0=0.0304
xc=np.array([0.001,0.003,0.01,0.03])
gd=np.array([0.57959,0.57531,0.62148,0.68871]); ge=np.array([0.00301,0.00196,0.00145,0.00150])
res=gd-0.58257; err=np.sqrt(ge**2+0.00409**2)
g2=np.array([0.0334,0.0393,0.1032,0.3964])-0.0304

fig,(ax1,ax2)=plt.subplots(1,2,figsize=(9.6,3.7))
ax1.loglog(xx,3*xx/(1+3*xx),'-',color='0.3',lw=1.5,label=r'theory $3x/(1+3x)$')
ax1.loglog(xk,lag,'o',ms=6,color='#1f77b4',label='stochastic simulation')
ax1.set_xlabel(r'driving $x=H\tau_0$'); ax1.set_ylabel(r'fractional lag $(p_{\rm eq}-\bar p)/p_{\rm eq}$')
ax1.set_title('(a) Verified lag law',fontsize=11); ax1.legend(fontsize=8,frameon=False)

ax2.axhline(0,color='0.6',lw=0.8)
ax2.errorbar(xc,res,yerr=err,fmt='s',ms=6,color='#d62728',capsize=3,
             label='grand-density residual (left)')
ax2.set_xscale('log'); ax2.set_xlabel(r'drive $x$ per column')
ax2.set_ylabel(r'grand density $-$ quasi-static ref.  [$\varepsilon/L$]')
ax2.set_title('(b) Driven elastic column',fontsize=11)
ax2b=ax2.twinx()
ax2b.plot(xc,g2,'^--',ms=6,color='#2ca02c',label='excess wall-bond stretch (right)')
ax2b.set_yscale('log'); ax2b.set_ylabel(r'$\langle g^2\rangle-\langle g^2\rangle_0$ (front sawtooth)')
for xi,ri,ei in [(0.001,res[0],err[0]),(0.003,res[1],err[1])]:
    ax2.annotate(f"${ri:+.3f}\\pm{ei:.3f}$",(xi,ri),textcoords="offset points",
                 xytext=(6,-14),fontsize=7.5,color='#d62728')
h1,l1=ax2.get_legend_handles_labels(); h2,l2=ax2b.get_legend_handles_labels()
ax2.legend(h1+h2,l1+l2,fontsize=8,frameon=False,loc='upper left')
fig.tight_layout()
fig.savefig('fig_de_results.pdf')
print('wrote fig_de_results.pdf')
