"""boundary_code.py -- Sec. 4: bicrystal seam analysis.
Naive truncated checks: odd-pair count and wall-tension bound via max matching.
Boundary code: frustration rank r, maximal commuting completion (nX+nZ-r), explicit
construction (all Z + X-kernel) with verification. numpy + scipy."""
import numpy as np, collections
from scipy.spatial import cKDTree
from scipy.stats import special_ortho_group
bond=np.sqrt(2.0)
rng=np.random.default_rng(7)
R=special_ortho_group.rvs(3,random_state=rng)
ext=9; LX=ext*0.65
def grain(Rm,off,zlo,zhi):
    pts=[];ints=[]
    for x in range(-ext,ext+1):
        for y in range(-ext,ext+1):
            for z in range(-ext,ext+1):
                if (x+y+z)%2==0:
                    p=Rm@np.array([x,y,z],float)+off
                    if zlo<=p[2]<zhi and abs(p[0])<LX and abs(p[1])<LX: pts.append(p);ints.append((x,y,z))
    return np.array(pts),ints
A,Ai=grain(np.eye(3),np.zeros(3),-6,0); off=rng.uniform(0,1,3); B,Bi=grain(R,off,0,6)
P=np.vstack([A,B]); NA=len(A)
t=cKDTree(P); edges=[]; eidx={}
for i,js in enumerate(t.query_ball_tree(t,1.05*bond)):
    for j in js:
        if j>i and np.linalg.norm(P[i]-P[j])>=0.95*bond:
            eidx[(i,j)]=len(edges); edges.append((i,j))
nE=len(edges)
def interior(p): return abs(p[0])<LX-1.8 and abs(p[1])<LX-1.8 and -4.5<p[2]<4.5
starmap=collections.defaultdict(set)
for e,(i,j) in enumerate(edges): starmap[i].add(e); starmap[j].add(e)
Zl=[(i,es) for i,es in starmap.items() if interior(P[i])]
lookA={q:i for i,q in enumerate(Ai)}; lookB={q:i+NA for i,q in enumerate(Bi)}
def octs_of(look,Rm,off):
    out=[]
    for x in range(-ext,ext+1):
        for y in range(-ext,ext+1):
            for z in range(-ext,ext+1):
                if (x+y+z)%2==1:
                    c=Rm@np.array([x,y,z],float)+off
                    if not interior(c): continue
                    nbs=[look[q] for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
                         if (q:=(x+d[0],y+d[1],z+d[2])) in look]
                    if len(nbs)>=4:
                        s=set(nbs); es=set(eidx[(min(a,b),max(a,b))] for a in s for b in s
                                            if a<b and (min(a,b),max(a,b)) in eidx)
                        if es: out.append(es)
    return out
Xl=octs_of(lookA,np.eye(3),np.zeros(3))+octs_of(lookB,R,off)
nZ=len(Zl); nX=len(Xl)
SZ=np.zeros((nZ,nE),np.int8); SX=np.zeros((nX,nE),np.int8)
for r_,(_,es) in enumerate(Zl):
    for e in es: SZ[r_,e]=1
for r_,es in enumerate(Xl):
    for e in es: SX[r_,e]=1
M=(SX@SZ.T)%2
def rk(Mat):
    Mm=Mat.copy().astype(np.int8); r0=0
    for c in range(Mm.shape[1]):
        p=None
        for row in range(r0,Mm.shape[0]):
            if Mm[row,c]: p=row;break
        if p is None: continue
        Mm[[r0,p]]=Mm[[p,r0]]
        for row in range(Mm.shape[0]):
            if row!=r0 and Mm[row,c]: Mm[row]^=Mm[r0]
        r0+=1
    return r0
def nullspace(Mat):
    Mm=Mat.copy().astype(np.int8); m,n=Mm.shape; piv=[]; r0=0
    for c in range(n):
        p=None
        for row in range(r0,m):
            if Mm[row,c]: p=row;break
        if p is None: continue
        Mm[[r0,p]]=Mm[[p,r0]]
        for row in range(m):
            if row!=r0 and Mm[row,c]: Mm[row]^=Mm[r0]
        piv.append(c); r0+=1
    free=[c for c in range(n) if c not in piv]; basis=[]
    for f in free:
        v=np.zeros(n,np.int8); v[f]=1
        for ri,c in enumerate(piv):
            if Mm[ri,f]: v[c]=1
        basis.append(v)
    return basis
ones=int(M.sum()); r=rk(M)
area=(2*(LX-1.8))**2
print(f"interior checks: {nZ} Z, {nX} X; odd pairs {ones} [expect 239]; frustration rank r = {r} [expect 66]")
print(f"maximal commuting completion: {nX+nZ-r} of {nX+nZ} generators; deficit {r/area:.3f}/bond^2 [expect ~1.0]")
ker=nullspace(M.T)
bad=0
for v in ker:
    supp=(v[None,:]@SX)%2
    if ((supp@SZ.T)%2).any(): bad+=1
print(f"explicit completion (all Z + {len(ker)}-dim X-kernel): verification {'PASS' if bad==0 else 'FAIL'}")
adjb=collections.defaultdict(set)
xs,zs=np.nonzero(M)
for a,b in zip(xs,zs): adjb[a].add(b)
matchZ={}
def kuhn(x,seen):
    for z in adjb[x]:
        if z in seen: continue
        seen.add(z)
        if z not in matchZ or kuhn(matchZ[z],seen): matchZ[z]=x; return True
    return False
m=sum(1 for x in list(adjb) if kuhn(x,set()))
print(f"naive-H bound: matching {m} [expect 70]; E0 >= {(1-1/np.sqrt(2))*m:.1f} J/patch = {(1-1/np.sqrt(2))*m/area:.3f} J/bond^2")
# Full-weight cross-check (Sec. 3 claim): all complete (weight-12) checks commute
fZ=[i for i,(_,es) in enumerate(Zl) if len(es)==12]
fX=[i for i,es in enumerate(Xl) if len(es)==12]
Mf=(SX[fX]@SZ[fZ].T)%2
print(f"full-weight checks: {len(fZ)} Z, {len(fX)} X; odd pairs among full-weight: {int(Mf.sum())} [expect 0]")
