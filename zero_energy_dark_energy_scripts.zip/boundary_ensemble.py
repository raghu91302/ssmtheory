"""boundary_ensemble.py -- Sec. 4 extensions. (A) Completed bicrystal code parameters
(n, rank HZ, rank HX_completed, k) vs a single-crystal reference on the same window;
weight and seam-localization statistics of the completed X-generators. (B) Ensemble of
Haar-random bicrystal orientations: odd pairs, frustration rank, deficit/area, matching.
numpy + scipy."""
import numpy as np, collections
from scipy.spatial import cKDTree
from scipy.stats import special_ortho_group

bond=np.sqrt(2.0); ext=9; LX=ext*0.65

def build(R2,off2,single=False):
    def grain(Rm,off,zlo,zhi):
        pts=[];
        for x in range(-ext,ext+1):
            for y in range(-ext,ext+1):
                for z in range(-ext,ext+1):
                    if (x+y+z)%2==0:
                        p=Rm@np.array([x,y,z],float)+off
                        if zlo<=p[2]<zhi and abs(p[0])<LX and abs(p[1])<LX:
                            pts.append((p,(x,y,z)))
        return pts
    if single:
        gs=[(np.eye(3),np.zeros(3),grain(np.eye(3),np.zeros(3),-6,6))]
    else:
        gs=[(np.eye(3),np.zeros(3),grain(np.eye(3),np.zeros(3),-6,0)),
            (R2,off2,grain(R2,off2,0,6))]
    P=[];looks=[]
    for Rm,off,pl in gs:
        look={}
        for p,q in pl: look[q]=len(P); P.append(p)
        looks.append((Rm,off,look))
    P=np.array(P)
    t=cKDTree(P); edges=[];eidx={}
    for i,js in enumerate(t.query_ball_tree(t,1.05*bond)):
        for j in js:
            if j>i and np.linalg.norm(P[i]-P[j])>=0.95*bond:
                eidx[(i,j)]=len(edges); edges.append((i,j))
    nE=len(edges)
    def interior(p): return abs(p[0])<LX-1.8 and abs(p[1])<LX-1.8 and -4.5<p[2]<4.5
    starmap=collections.defaultdict(set)
    for e,(i,j) in enumerate(edges): starmap[i].add(e); starmap[j].add(e)
    Zl=[(i,es) for i,es in starmap.items() if interior(P[i])]
    Xl=[]
    for Rm,off,look in looks:
        for x in range(-ext,ext+1):
            for y in range(-ext,ext+1):
                for z in range(-ext,ext+1):
                    if (x+y+z)%2==1:
                        c=Rm@np.array([x,y,z],float)+off
                        if not interior(c): continue
                        nbs=[look[q] for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
                             if (q:=(x+d[0],y+d[1],z+d[2])) in look]
                        if len(nbs)>=4:
                            s=set(nbs)
                            es=set(eidx[(min(a,b),max(a,b))] for a in s for b in s
                                   if a<b and (min(a,b),max(a,b)) in eidx)
                            if es: Xl.append(es)
    SZ=np.zeros((len(Zl),nE),np.int8); SX=np.zeros((len(Xl),nE),np.int8)
    for r_,(_,es) in enumerate(Zl):
        for e in es: SZ[r_,e]=1
    for r_,es in enumerate(Xl):
        for e in es: SX[r_,e]=1
    mids=np.array([(P[i]+P[j])/2 for i,j in edges])
    return SZ,SX,nE,mids

def rk(Mat):
    Mm=Mat.copy().astype(np.int8); r0=0
    for c in range(Mm.shape[1]):
        p=None
        for row in range(r0,Mm.shape[0]):
            if Mm[row,c]: p=row;break
        if p is None: continue
        Mm[[r0,p]]=Mm[[p,r0]]
        for row in range(Mm.shape[0]):
            if row!=r0 and Mm[row,c]: Mm[row]^=Mm[r0]
        r0+=1
    return r0

def nullspace(Mat):
    Mm=Mat.copy().astype(np.int8); m,n=Mm.shape; piv=[]; r0=0
    for c in range(n):
        p=None
        for row in range(r0,m):
            if Mm[row,c]: p=row;break
        if p is None: continue
        Mm[[r0,p]]=Mm[[p,r0]]
        for row in range(m):
            if row!=r0 and Mm[row,c]: Mm[row]^=Mm[r0]
        piv.append(c); r0+=1
    free=[c for c in range(n) if c not in piv]; basis=[]
    for f in free:
        v=np.zeros(n,np.int8); v[f]=1
        for ri,c in enumerate(piv):
            if Mm[ri,f]: v[c]=1
        basis.append(v)
    return basis

def matching(M):
    adjb=collections.defaultdict(set)
    xs,zs=np.nonzero(M)
    for a,b in zip(xs,zs): adjb[a].add(b)
    matchZ={}
    def kuhn(x,seen):
        for z in adjb[x]:
            if z in seen: continue
            seen.add(z)
            if z not in matchZ or kuhn(matchZ[z],seen): matchZ[z]=x; return True
        return False
    return sum(1 for x in list(adjb) if kuhn(x,set()))

area=(2*(LX-1.8))**2

# ---------- (A) reference geometry: completed code vs single crystal ----------
rng=np.random.default_rng(7)
R=special_ortho_group.rvs(3,random_state=rng); off=rng.uniform(0,1,3)
SZ,SX,nE,mids=build(R,off)
M=(SX@SZ.T)%2; r=rk(M)
ker=nullspace(M.T)                      # X-combinations commuting with all Z
Xc=(np.array(ker,np.int8)@SX)%2 if ker else np.zeros((0,nE),np.int8)
rZ=rk(SZ); rXc=rk(Xc); k_bi=nE-rZ-rXc
print(f"[bicrystal, completed] n={nE}  rank(SZ)={rZ}  rank(SX_full)={rk(SX)}  "
      f"rank(SX_completed)={rXc}  k={k_bi}")
SZ0,SX0,nE0,_=build(None,None,single=True)
M0=(SX0@SZ0.T)%2
print(f"[single-crystal ref ] n={nE0}  rank(SZ)={rk(SZ0)}  rank(SX)={rk(SX0)}  "
      f"k={nE0-rk(SZ0)-rk(SX0)}  odd pairs={int(M0.sum())}")
# generator weight / seam-localization statistics for the completed X-generators
w=[]; zmean=[]; zmax=[]; span=[]
for v in Xc:
    s=np.nonzero(v)[0]
    if len(s)==0: continue
    w.append(len(s)); zs=np.abs(mids[s][:,2])
    zmean.append(zs.mean()); zmax.append(zs.max())
    span.append(np.ptp(mids[s][:,0])+np.ptp(mids[s][:,1]))
w=np.array(w)
print(f"[completed X-gens   ] count={len(w)}  weight: min={w.min()} med={int(np.median(w))} "
      f"max={w.max()};  |z|: mean={np.mean(zmean):.2f} max={np.max(zmax):.2f} bonds "
      f"(seam at z=0, checks span |z|<4.5)")
print(f"[completed X-gens   ] weight<=12 (single-check): {int((w<=12).sum())};  "
      f"weight>24 (multi-check combos): {int((w>24).sum())}")

# ---------- (B) orientation ensemble ----------
print("\nseed  nZ   nX   odd   r    r/area  match")
stats=[]
for seed in [7,11,13,17,19,23]:
    rng=np.random.default_rng(seed)
    R=special_ortho_group.rvs(3,random_state=rng); off=rng.uniform(0,1,3)
    SZ,SX,nE,_=build(R,off)
    M=(SX@SZ.T)%2
    odd=int(M.sum()); rr=rk(M); mm=matching(M)
    stats.append((odd,rr,rr/area,mm))
    print(f"{seed:4d} {SZ.shape[0]:4d} {SX.shape[0]:4d} {odd:5d} {rr:4d}  {rr/area:.3f}  {mm:4d}")
S=np.array(stats,float)
print(f"\nensemble (6 seeds): odd pairs {S[:,0].mean():.0f}+-{S[:,0].std():.0f}; "
      f"rank r {S[:,1].mean():.1f}+-{S[:,1].std():.1f}; "
      f"deficit/bond^2 {S[:,2].mean():.2f}+-{S[:,2].std():.2f}; "
      f"matching {S[:,3].mean():.1f}+-{S[:,3].std():.1f} "
      f"-> E0 >= {(1-1/np.sqrt(2))*S[:,3].mean()/area:.2f}+-{(1-1/np.sqrt(2))*S[:,3].std()/area:.2f} J/bond^2")
