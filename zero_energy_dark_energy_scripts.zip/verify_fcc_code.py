"""verify_fcc_code.py -- Sec. 3: rebuild the actual [[192,130,3]] FCC CSS code
(qubits on edges; weight-12 vertex Z-checks; weight-12 octahedral X-checks) and verify
n, the exact CSS condition HX HZ^T = 0 (all overlaps even), and k = 130. numpy only."""
import numpy as np, collections
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
L=4
nodes,nidx=[],{}
for x in range(L):
    for y in range(L):
        for z in range(L):
            if (x+y+z)%2==0: nidx[(x,y,z)]=len(nodes); nodes.append((x,y,z))
edges,eidx=[],{}
for i,(x,y,z) in enumerate(nodes):
    for d in NN:
        nb=((x+d[0])%L,(y+d[1])%L,(z+d[2])%L)
        if nb in nidx:
            j=nidx[nb]
            if i<j: eidx[(i,j)]=len(edges); edges.append((i,j))
ne=len(edges)
octs=[]
for x in range(L):
    for y in range(L):
        for z in range(L):
            if (x+y+z)%2==1:
                nbs=[nidx[q] for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
                     if (q:=((x+d[0])%L,(y+d[1])%L,(z+d[2])%L)) in nidx]
                if len(nbs)==6: octs.append(nbs)
HZ=np.zeros((len(nodes),ne),np.int8)
for ei,(i,j) in enumerate(edges): HZ[i,ei]=1; HZ[j,ei]=1
HX=np.zeros((len(octs),ne),np.int8)
for oi,nbs in enumerate(octs):
    s=set(nbs)
    for ei,(i,j) in enumerate(edges):
        if i in s and j in s: HX[oi,ei]=1
def rk(M):
    M=M.copy().astype(np.int8); r=0
    for c in range(M.shape[1]):
        p=None
        for row in range(r,M.shape[0]):
            if M[row,c]: p=row;break
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for row in range(M.shape[0]):
            if row!=r and M[row,c]: M[row]^=M[r]
        r+=1
    return r
css=int((HX@HZ.T%2).sum()); k=ne-rk(HZ)-rk(HX)
print(f"n = {ne} [expect 192]; CSS HX HZ^T = 0: {css==0}; odd-overlap pairs: {css}; k = {k} [expect 130]")
print("PASS" if (ne==192 and css==0 and k==130) else "FAIL")
