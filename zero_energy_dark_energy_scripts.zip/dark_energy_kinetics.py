"""dark_energy_kinetics.py -- Sec. 3 / Fig. 1a. Driven detailed-balance vacuum:
verify the lag law delta = 3x/(1+3x) (gamma_up/gamma_down = e, sum = 1/tau0;
per-capita replacement by empty newborns at rate 3x). numpy only."""
import numpy as np
rng=np.random.default_rng(11); e=np.e
p_eq=e/(1+e); gu=e/(1+e); gd=1/(1+e); N=200000; dt=0.01
print(f"p_eq={p_eq:.4f}, q={1/(1+e):.4f} [expect 0.7311, 0.2689]")
for x in [0.003,0.01,0.03,0.1,0.3]:
    s=(rng.random(N)<p_eq); t=0.0; acc=[]
    while t<60.0:
        r=rng.random(N)
        s=s^((~s)&(r<gu*dt))^(s&(r<gd*dt))
        s[rng.random(N)<3*x*dt]=False
        t+=dt
        if t>30.0: acc.append(s.mean())
    lag=(p_eq-np.mean(acc))/p_eq; th=3*x/(1+3*x)
    print(f"x={x:5.3f}: lag={lag:.5f}  theory={th:.5f}  ratio={lag/th:.3f}")
print("PASS if ratios ~ 1.00: lag law delta = 3x/(1+3x) verified.")
