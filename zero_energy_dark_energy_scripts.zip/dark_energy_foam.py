"""dark_energy_foam.py -- Sec. 6. Exact hinge-closure geometry: dihedral slopes,
cheapest closure mode, foam coefficient. numpy + scipy."""
import numpy as np
from scipy.optimize import brentq
def dihedral(fe,he):
    a=1.0+he; f=1.0+fe
    A=np.zeros(3); B=np.array([a,0,0.])
    xc=a/2; yc=np.sqrt(f**2-xc**2); C=np.array([xc,yc,0])
    xd=a/2; yd=(xc**2+yc**2-2*xd*xc)/(2*yc); zd=np.sqrt(f**2-xd**2-yd**2)
    D=np.array([xd,yd,zd])
    n1=np.cross(B-A,C-A); n2=np.cross(B-A,D-A)
    return np.arccos(np.clip(n1@n2/(np.linalg.norm(n1)*np.linalg.norm(n2)),-1,1))
th0=np.arccos(1/3); delta=2*np.pi-5*th0; need=delta/5; h=1e-6
sf=(dihedral(h,0)-dihedral(-h,0))/(2*h); sh=(dihedral(0,h)-dihedral(0,-h))/(2*h)
print(f"slopes: flank {sf:.4f}, hinge {sh:.4f} rad/strain [expect -0.4714, +0.4714]")
ef=brentq(lambda e_: dihedral(e_,0)-(th0+need),-0.3,0.0)
eh=brentq(lambda e_: dihedral(0,e_)-(th0+need),0.0,0.3)
print(f"closure strains: flank {ef:.5f}, hinge {eh:.5f} [expect -0.0489, +0.0515]")
kL2=36.0
Ef=17.5*0.5*kL2*ef**2; Eh=0.5*kL2*eh**2
print(f"E(flank)={Ef:.4f} eps, E(hinge)={Eh:.4f} eps -> C_foam = {min(Ef,Eh)/7:.5f} eps/node [expect 0.0068]")
print(f"ansatz (delta/2pi)^2 = {(delta/(2*np.pi))**2:.2e} -> refuted (x16 and wrong channel)")
