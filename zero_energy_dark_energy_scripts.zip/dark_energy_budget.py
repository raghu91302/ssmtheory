"""dark_energy_budget.py -- Secs. 2-5 / Table 1. Displacement reading, per-event budget,
and channel pricing (linear, boundary-local quadratic, coarse quadratic). numpy only."""
import numpy as np
hbar=1.054571817e-34; c=2.99792458e8; G=6.67430e-11
lP=np.sqrt(hbar*G/c**3); tP=lP/c; EP=np.sqrt(hbar*c**5/G); rhoP=EP/lP**3
L=np.sqrt(4*np.log(2))*lP; n0=np.sqrt(2)/L**3
H0=67.4e3/3.0857e22
rho=0.685*3*H0**2*c**2/(8*np.pi*G)
print(f"observed rho_DE = {rho/rhoP:.2e} rho_P")
Kc=(2.0/3.0)*n0*(36*(hbar*c/(4*L)))   # bulk modulus B = (2/3) n0 kappa L^2, kappa L^2 = 36 eps
print(f"stiffness K_c = {Kc/rhoP:.3f} rho_P; displacement dn/n0 = {rho/Kc:.2e} [expect 1.0e-123]")
rate=3*H0*n0
print(f"creation rate {rate:.2e} /m^3/s; per-event budget {rho/rate/(hbar*c/(4*L)):.1e} J_bond [expect 3.8e-105]")
for lab,eps in [("hbar c/2L",hbar*c/(2*L)),("hbar c/4L",hbar*c/(4*L))]:
    tau0=hbar/eps; d=3*H0*tau0
    print(f"[eps={lab}] B1 linear: {eps*n0*(np.e/(1+np.e))*d/rhoP:.1e} rho_P (dead);"
          f" B2 coarse quad: {12*eps*n0*d**2/rhoP:.2e} rho_P;"
          f" B3 local/boundary: {12*eps*n0*d**2/(1/6.0e15)/rhoP:.1e} rho_P (dead)")
print(f"free coincidence check: (H0*tP)^2 = {(H0*tP)**2:.2e} vs rho_obs/rhoP = {rho/rhoP:.2e} (factor {(H0*tP)**2/(rho/rhoP):.0f})")
print("grain-size window from c_obs = l_g/(tau0 e^kNb), Planckian anchor:")
for kNb in [32,36,40]:
    print(f"  kNb={kNb}: l_g = {c*1*tP*np.exp(kNb):.1e} - {c*5*tP*np.exp(kNb):.1e} m")
print("linear-lag no-go: tau required =",f"{rho/(Kc*3*H0)/tP:.1e} t_P (unphysical)")
