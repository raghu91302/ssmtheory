# zero_energy_dark_energy verification scripts

Reproduction scripts for *A Zero-Energy Vacuum and Its Dark Energy: Stabilizer and
Boundary-Code Theorems, Exclusion Structure, and a Computed Null for the
Crystallization Channel* (R. Kulkarni, 2026). Each script is self-contained, prints
the quantities quoted in the paper, and states expected values inline. Requirements:
`numpy` (all), `scipy` (boundary_code, dark_energy_foam, dark_energy_column). All
randomness is seeded; outputs are deterministic.

| Script | Reproduces |
|---|---|
| `verify_fcc_code.py` | Sec. 3: rebuild of the [[192,130,3]] FCC CSS code; n = 192, exact commutation HX HZ^T = 0, k = 130 |
| `boundary_code.py` | Sec. 4: Haar-bicrystal seam -- 239 odd check pairs under naive truncation; frustration rank r = 66; maximal commuting completion 542 of 608 (explicitly constructed and verified); deficit 1.006 per bond^2; wall-tension bound E0 >= 20.5 J per patch = 0.31 J per bond^2 via maximum matching (70) |
| `dark_energy_kinetics.py` | Sec. 7 / Fig. 1a: driven detailed-balance vacuum; lag law delta = 3x/(1+3x) verified to half a percent across two decades |
| `dark_energy_budget.py` | Secs. 6-9 / Table 1: stiffness K_c = 0.046 rho_P; displacement 2.5e-122; per-event budget 3.8e-105 J_bond; channel pricing (linear dead 10^61, boundary-local dead 10^19, coarse quadratic 1.5-3.1e-120 rho_P); free-coincidence check (H0 t_P)^2 (factor 12); grain-size window l_g = 1e-20 to 2e-17 m |
| `dark_energy_foam.py` | Sec. 10: exact hinge-closure geometry -- dihedral slopes +-0.4714 rad/strain; closure strains -0.0489 (flank) and +0.0515 (hinge); foam coefficient C = 0.0068 eps per transit node; refutation of the (delta/2pi)^2 ansatz |
| `dark_energy_column.py` | Sec. 11 / Fig. 1b: elastic driven column (thermal spring chain, barrier-gated detailed-balance creation, receding wall); small-drive bulk null and front-sawtooth absorption. Usage: `python3 dark_energy_column.py 0.0 0.001 0.003 0.01 0.03` |
