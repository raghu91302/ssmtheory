"""dark_energy_slab3d.py -- Sec. 7 extension: three-dimensional FCC driven slab.
Mirrors dark_energy_column.py: thermal harmonic FCC crystal (kappa L^2 = 36 eps),
(001) growth surface coupled per lateral column to a receding rigid wall (soft
springs kappa_w = kappa/6), detailed-balance creation/annihilation (bulk vacancy
channel + per-column surface channel), overdamped Langevin, periodic in x,y, pinned
base. Reports grand density, interior (bulk-only) grand density, and per-column
wall-spring excess extension <g^2>; residuals are taken against the x=0 run.
Usage: python3 dark_energy_slab3d.py 0.0 0.001 0.003 0.01 [0.03]"""
import numpy as np, sys, time

rng=np.random.default_rng(5)
kap=36.0; kw=6.0; T=1.0; epsb=1.5; mu=-6.5
gam=1.0; dt=0.0025; nu_bulk=0.05; nu_front=3.0
W=6; K0=16
S=1.0/np.sqrt(2.0); h=S
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
    (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
UP=[o for o in NN if o[2]>0]
A=(W*S)**2

class Slab:
    def __init__(self):
        self.key2n={}; self.coord=[]; self.P=[]; self.alive=[]
        self.ei=[]; self.ej=[]; self.esh=[]; self.eal=[]
        for k in range(K0):
            for i in range(W):
                for j in range(W):
                    if (i+j+k)%2==0: self._new(i,j,k)
        self.pack(); self.retop()
        self.Zw=max(self.P[n][2] for n in range(len(self.P)) if self.alive[n])+h
        self.H0=K0*S
    def phys(self,i,j,k): return np.array([i*S,j*S,k*S])
    def _new(self,i,j,k):
        idx=len(self.coord); self.key2n[(i%W,j%W,k)]=idx
        self.coord.append((i%W,j%W,k))
        self.P.append(self.phys(i,j,k)+0.01*rng.standard_normal(3))
        self.alive.append(True)
        for o in NN:
            q=((i+o[0])%W,(j+o[1])%W,k+o[2])
            m=self.key2n.get(q)
            if m is not None and self.alive[m]:
                sh=(self.phys(i,j,k)+np.array(o)*S)-self.phys(*self.coord[m])
                self.ei.append(idx); self.ej.append(m); self.esh.append(sh); self.eal.append(True)
        return idx
    def pack(self):
        self.pos=np.array(self.P); self.al=np.array(self.alive,bool)
        self.Ei=np.array(self.ei,int); self.Ej=np.array(self.ej,int)
        self.Esh=np.array(self.esh) if self.esh else np.zeros((0,3)); self.Eal=np.array(self.eal,bool)
        self.pin=np.array([k<2 for (_,_,k) in self.coord])
    def retop(self):
        top={}
        for n,(i,j,k) in enumerate(self.coord):
            if self.alive[n] and (( (i,j) not in top) or k>self.coord[top[(i,j)]][2]): top[(i,j)]=n
        self.cols=top; self.topn=np.array(list(top.values()),int)
    def col_top(self,i,j): return self.cols.get((i%W,j%W))
    def spr(self,n): return 0.5*kw*((self.Zw-self.P[n][2])-h)**2
    def occ_nn(self,i,j,k):
        out=[]
        for o in NN:
            m=self.key2n.get(((i+o[0])%W,(j+o[1])%W,k+o[2]))
            if m is not None and self.alive[m]: out.append((m,o))
        return out
    def try_insert(self,i,j,k):
        i,j=i%W,j%W
        if k<2: return
        m=self.key2n.get((i,j,k))
        if m is not None and self.alive[m]: return
        nbs=self.occ_nn(i,j,k)
        if len(nbs)<3: return
        pid=self.phys(i,j,k)
        # relaxed placement (3D analogue of the 1D midpoint insertion): ideal position
        # plus the mean displacement of the occupied neighbors, inheriting local strain
        img=[self.P[m2]+((pid+np.array(o)*S)-self.phys(*self.coord[m2])) for m2,o in nbs]
        u=np.mean([im-(pid+np.array(o)*S) for im,(m2,o) in zip(img,nbs)],axis=0)
        p=pid+u
        dE=0.0
        for im,(m2,o) in zip(img,nbs):
            dE+=0.5*kap*(np.linalg.norm(im-p)-1.0)**2-epsb
        t=self.col_top(i,j); dW=0.0
        if t is None or self.coord[t][2]<k:
            dW+=0.5*kw*((self.Zw-p[2])-h)**2-(self.spr(t) if t is not None else 0.0)
        dOm=dE+dW-mu
        if dOm<=0 or rng.random()<np.exp(-dOm/T):
            if m is not None:
                self.alive[m]=True; self.P[m]=p+0.01*rng.standard_normal(3)
                for m2,o in nbs:
                    self.ei.append(m); self.ej.append(m2)
                    self.esh.append((pid+np.array(o)*S)-self.phys(*self.coord[m2])); self.eal.append(True)
            else:
                nn=self._new(i,j,k); self.P[nn]=p+0.01*rng.standard_normal(3)
            self.pack(); self.retop()
    def try_remove(self,n):
        i,j,k=self.coord[n]
        if k<2 or not self.alive[n]: return
        dE=0.0; cnt=0
        for m2,o in self.occ_nn(i,j,k):
            d=np.linalg.norm((self.P[m2]+((self.phys(i,j,k)+np.array(o)*S)-self.phys(*self.coord[m2])))-np.array(self.P[n]))
            dE+=0.5*kap*(d-1.0)**2-epsb; cnt+=1
        if cnt==0: return
        dW=0.0
        if self.col_top(i,j)==n:
            nk=None
            for kk in range(k-2,1,-2):
                q=self.key2n.get((i,j,kk))
                if q is not None and self.alive[q]: nk=q; break
            if nk is None: return
            dW+=0.5*kw*((self.Zw-self.P[nk][2])-h)**2-self.spr(n)
        dOm=(-dE)+dW+mu
        if dOm<=0 or rng.random()<np.exp(-dOm/T):
            self.alive[n]=False
            for e in range(len(self.ei)):
                if self.eal[e] and (self.ei[e]==n or self.ej[e]==n): self.eal[e]=False
            self.pack(); self.retop()
    def total_E(self):
        d=self.pos[self.Ej]+self.Esh-self.pos[self.Ei]; ln=np.linalg.norm(d,axis=1)
        Eb=((0.5*kap*(ln-1.0)**2-epsb)*self.Eal).sum()
        g=(self.Zw-self.pos[self.topn][:,2])-h
        return Eb+0.5*kw*(g**2).sum()
    def interior(self):
        zlo=3.0*S; zhi=self.pos[self.al][:,2].max()-3.5
        if zhi<=zlo: return np.nan
        mid=0.5*(self.pos[self.Ei]+self.pos[self.Ej]+self.Esh)
        d=self.pos[self.Ej]+self.Esh-self.pos[self.Ei]; ln=np.linalg.norm(d,axis=1)
        sel=self.Eal&(mid[:,2]>zlo)&(mid[:,2]<zhi)
        Eb=(0.5*kap*(ln[sel]-1.0)**2-epsb).sum()
        Nin=int(((self.pos[:,2]>zlo)&(self.pos[:,2]<zhi)&self.al).sum())
        return (Eb-mu*Nin)/(A*(zhi-zlo))

def run(x,Ttot=600.0,burn=250.0):
    s=Slab(); ncols=W*W
    samples=[];bulks=[];g2=[];Ns=[]
    for st in range(int(Ttot/dt)):
        d=s.pos[s.Ej]+s.Esh-s.pos[s.Ei]; ln=np.linalg.norm(d,axis=1); ln[ln==0]=1
        fb=(kap*(ln-1.0)/ln)[:,None]*d*s.Eal[:,None]
        F=np.zeros_like(s.pos)
        for c in range(3):
            F[:,c]+=np.bincount(s.Ei,weights=fb[:,c],minlength=len(s.pos))
            F[:,c]-=np.bincount(s.Ej,weights=fb[:,c],minlength=len(s.pos))
        F[s.topn,2]+=kw*((s.Zw-s.pos[s.topn][:,2])-h)
        mob=s.al&~s.pin
        s.pos[mob]+=(F[mob]/gam)*dt+np.sqrt(2*T*dt/gam)*rng.standard_normal((int(mob.sum()),3))
        for n in np.flatnonzero(mob): s.P[n]=s.pos[n]
        s.Zw+=x*dt*s.H0
        Nal=int(s.al.sum())
        for _ in range(rng.poisson(nu_bulk*Nal*dt)):
            if rng.random()<0.5:
                n=int(rng.choice(np.flatnonzero(s.al))); i,j,k=s.coord[n]
                o=NN[int(rng.integers(0,12))]; s.try_insert(i+o[0],j+o[1],k+o[2])
            else:
                s.try_remove(int(rng.choice(np.flatnonzero(s.al))))
        for _ in range(rng.poisson(nu_front*ncols*dt)):
            ci,cj=int(rng.integers(0,W)),int(rng.integers(0,W))
            t=s.col_top(ci,cj)
            if t is None: continue
            i,j,k=s.coord[t]
            if rng.random()<0.5:
                o=UP[int(rng.integers(0,4))]; s.try_insert(i+o[0],j+o[1],k+o[2])
            else: s.try_remove(t)
        if st%200==0: s.retop()
        if st*dt>burn and st%300==0:
            samples.append((s.total_E()-mu*s.al.sum())/(A*s.Zw))
            bulks.append(s.interior())
            g=(s.Zw-s.pos[s.topn][:,2]-h)/h
            g2.append(float((g**2).mean())); Ns.append(int(s.al.sum()))
    half=len(Ns)//2
    drift=float(np.mean(Ns[half:])-np.mean(Ns[:half]))
    return (float(np.mean(samples)),float(np.std(samples)/np.sqrt(len(samples))),
            float(np.nanmean(bulks)),float(np.nanstd(bulks)/np.sqrt(len(bulks))),
            float(np.mean(g2)),int(s.al.sum()),drift)

if __name__=="__main__":
    for x in [float(a) for a in sys.argv[1:]]:
        t0=time.time()
        m,e,bm,be,g2,Nf,dr=run(x)
        print(f"x={x:7.5f}  grand={m:9.5f}+-{e:.5f}  bulk={bm:9.5f}+-{be:.5f}  "
              f"col<g^2>={g2:8.4f}  N_final={Nf}  N_drift={dr:+.1f}  [{time.time()-t0:.0f}s]",flush=True)
