"""dark_energy_column.py -- Sec. 7 / Fig. 1b. Elastic driven column: thermal spring chain,
DB creation/annihilation (bulk barrier-gated), receding wall. Usage: python3 dark_energy_column.py 0.0 0.001 0.003 0.01 0.03"""
import numpy as np, sys
rng=np.random.default_rng(5)
kap=36.0; L=1.0; eps=1.0; T=1.0; mu=-1.0
gam=1.0; dt=0.003; nu_bulk=0.05; nu_front=1.0
def energy(z,Zw):
    d=np.diff(z)
    return 0.5*kap*((d-L)**2).sum()+0.5*kap*((Zw-z[-1])-L)**2-eps*len(z)
def acc(dE): return dE<=0 or rng.random()<np.exp(-dE/T)
def attempt_bond(z,Zw,i):
    if i<len(z)-1:
        l=z[i+1]-z[i]
        if rng.random()<0.5:
            dE=0.5*kap*(2*(l/2-L)**2-(l-L)**2)-eps
            if acc(dE-mu): z=np.insert(z,i+1,0.5*(z[i]+z[i+1]))
        elif i>0:
            l1=z[i]-z[i-1]
            dE=0.5*kap*(((l1+l)-L)**2-(l1-L)**2-(l-L)**2)+eps
            if acc(dE+mu): z=np.delete(z,i)
    else:
        l=Zw-z[-1]
        if rng.random()<0.5:
            dE=0.5*kap*(2*(l/2-L)**2-(l-L)**2)-eps
            if acc(dE-mu): z=np.append(z,0.5*(z[-1]+Zw))
        elif len(z)>3:
            l1=z[-1]-z[-2]
            dE=0.5*kap*(((l1+l)-L)**2-(l1-L)**2-(l-L)**2)+eps
            if acc(dE+mu): z=z[:-1]
    return z
def run(x,Ttot=1500.0,burn=500.0,N0=40):
    z=np.arange(N0)*L*1.0; Zw=z[-1]+L
    samples=[]; g2=[]
    for step in range(int(Ttot/dt)):
        d=np.diff(z); f=np.zeros_like(z)
        fb=kap*(d-L); f[:-1]+=fb; f[1:]-=fb
        f[-1]+=kap*((Zw-z[-1])-L)
        z[1:]+=(f[1:]/gam)*dt+np.sqrt(2*T*dt/gam)*rng.standard_normal(len(z)-1)
        Zw+=x*dt*N0*L
        for _ in range(rng.poisson(nu_bulk*len(z)*dt)):
            z=attempt_bond(z,Zw,int(rng.integers(0,len(z))))
        if rng.random()<nu_front*dt:
            z=attempt_bond(z,Zw,len(z)-1)
        if step*dt>burn and step%300==0:
            samples.append((energy(z,Zw)-mu*len(z))/Zw)
            g2.append(((Zw-z[-1])/L-1.0)**2)
    return np.mean(samples),np.std(samples)/np.sqrt(len(samples)),np.mean(g2),len(z)
for x in [float(a) for a in sys.argv[1:]]:
    m,e_,g2,Nf=run(x)
    print(f"x={x:7.5f}  grand_density={m:9.5f}+-{e_:.5f}  wall<g^2>={g2:7.4f}  N_final={Nf}")
