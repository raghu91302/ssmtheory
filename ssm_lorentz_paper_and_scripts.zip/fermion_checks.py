#!/usr/bin/env python3
"""fermion_checks.py -- spin-1/2 matter on D4* (Euclidean route). PASS/FAIL per claim.
Action: Wilson-type Dirac operator using all 24 D4* hops with equal kinetic weight;
Wilson parameter r = 1 on axis hops and r = 1/2 on the 16 time-mixed hops (r = the hop's step along each axis).
Reflection positivity is tested with open, reflection-symmetric time boundaries; calibrated on hypercubic Wilson fermions."""
import numpy as np, itertools, importlib.util, os
from scipy.optimize import minimize, brentq
here=os.path.dirname(os.path.abspath(__file__))
ok=lambda c,m: print(("PASS " if c else "FAIL ")+m)
R=np.array([v for v in np.vstack([np.eye(4),-np.eye(4)])]+[np.array(s)/2 for s in itertools.product([1,-1],repeat=4)])
Rp=np.array([r for r in R if tuple(r)>tuple(-r)]);ax=np.array([np.isclose(np.abs(r).max(),1) for r in Rp])
v=lambda k:(np.sin(Rp@k)@Rp)/3
def Wt(k,rh=0.5):
    c=1-np.cos(Rp@k);return 2*(np.sum(c[ax])+rh*np.sum(c[~ax]))/6
# 1. doublers
N=20;js=2*np.pi*np.arange(N)/N;j4=4*np.pi*np.arange(2*N)/(2*N)
Q=np.stack(np.meshgrid(js,js,js,j4,indexing='ij'),-1).reshape(-1,4)
nv=np.linalg.norm((np.sin(Q@Rp.T))@Rp/3,axis=1)
same=lambda a,b:(lambda d:np.allclose(d,np.round(d),atol=1e-5) and int(np.round(d).sum())%2==0)((a-b)/(2*np.pi))
zs=[]
for c in Q[nv<0.4]:
    r=minimize(lambda k:np.sum(v(k)**2),c,method='Nelder-Mead',options={'xatol':1e-11,'fatol':1e-22,'maxiter':5000})
    if r.fun<1e-14 and not any(same(r.x,y) for y in zs): zs.append(r.x)
J=lambda z:np.array([[(v(z+1e-6*e)-v(z-1e-6*e))[i]/2e-6 for e in np.eye(4)] for i in range(4)])
chir=sum(int(np.sign(np.linalg.det(J(z)))) for z in zs)
ok(len(zs)==72 and chir==0, f"naive D4* fermion: {len(zs)} species, net chirality {chir} (Nielsen-Ninomiya)")
ws=sorted(Wt(z) for z in zs)
ok(ws[0]<1e-12 and ws[1]>2.5, f"Wilson term leaves one light species; lightest doubler at {ws[1]:.3f} (cutoff scale)")
# 2. light cone
def E_f(p,m):
    def f(E):
        k=np.array([*p,1j*E]);vv=(np.sin(Rp@k)@Rp)/3;return np.real((m+Wt(k))**2+np.sum(vv*vv))
    Es=np.linspace(1e-5,3,3000);vals=[f(E) for E in Es]
    for a,b,fa,fb in zip(Es,Es[1:],vals,vals[1:]):
        if fa*fb<0: return brentq(f,a,b,xtol=1e-14)
dirs=[np.array([1,0,0.]),np.array([1,1,0])/2**.5,np.ones(3)/3**.5]
for m in [0.0,0.05]:
    E0=E_f(np.full(3,1e-9),m) if m else 0.0
    vs=[np.sqrt(E_f(0.004*n,m)**2-E0**2)/0.004 for n in dirs]
    ok(np.allclose(vs,1,atol=5e-6), f"fermion (m={m}) limiting speed = photon speed, every direction ({np.round(vs,7)})")
# 3. reflection positivity
sp=importlib.util.spec_from_file_location('o',os.path.join(here,'open_rp.py'));o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o)
good=lambda r: min(r[0],r[1])==0
ok(good(o.gram('Z4',3,12,1,0.5,1.0)) and good(o.gram('Z4',3,12,0,0.5,1.0)), "calibration: hypercubic Wilson r=1 is reflection positive (link and site planes)")
ok(not good(o.gram('Z4',3,12,1,0.5,1.5)), "calibration: hypercubic Wilson r=1.5 violates (test has power)")
ok(good(o.gram('D4s',3,8,0,0.5,1.0,0.5,1.0)) and good(o.gram('D4s',3,8,1,0.5,1.0,0.5,1.0)), "D4* fermion with r_half=1/2: reflection positive, both plane types")
ok(not good(o.gram('D4s',2,10,0,0.5,1.0,1.0,1.0)), "D4* fermion with uniform r=1: violates")
ok(not good(o.gram('D4s',2,10,0,0.5,1.0,0.4,1.0)) and not good(o.gram('D4s',2,10,0,0.5,1.0,0.6,1.0)), "the condition is sharp: r_half=0.4 and 0.6 both violate")
# 4. the hop matrices form the binary tetrahedral group 2T (the defect's spin group)
gm=o.g
blocks=[sum(r[mu]*gm[mu] for mu in range(4))[0:2,2:4] for r in R]
key=lambda Mx: tuple(np.round(Mx,8).ravel()); Sset={key(B) for B in blocks}
closed=all(key(A@B) in Sset for A in blocks for B in blocks)
ncls=len({frozenset(key(np.linalg.inv(X)@A@X) for X in blocks) for A in blocks})
def order(A):
    Mx=A.copy()
    for n in range(1,13):
        if np.allclose(Mx,np.eye(2)): return n
        Mx=Mx@A
from collections import Counter
ords=dict(sorted(Counter(order(A) for A in blocks).items()))
ok(closed and len(Sset)==24 and ncls==7 and ords=={1:1,2:1,3:8,4:6,6:8}, f"the 24 hop matrices form 2T (order 24, 7 classes, element orders {ords})")
