"""One-loop speed split from a lattice with a preferred time direction.
Massless phi coupled to massive chi via g*phi*chi^2. Euclidean lattice, spatial spacing 1,
temporal spacing r. r=1: hypercubic (time and space equivalent). r->0: continuous time
(Hamiltonian / real-time-foliated lattice). Sigma(p) = g^2 * sum_q G(q) G(q+p).
The quadratic coefficients A0 (in p0^2) and As (in ps^2) give phi's speed shift:
c_phi^2 = (1 - As)/(1 - A0)  ~ 1 + (A0 - As). chi's tree speed is 1 for every r."""
import numpy as np
def phat2(p,a): return (2/a*np.sin(p*a/2))**2
def sigma(p0,ps,r,m,Ns=24):
    qs=2*np.pi*(np.arange(Ns)-Ns//2)/Ns
    Nt=int(round(Ns/r)); q0=2*np.pi/r*(np.arange(Nt)-Nt//2)/Nt
    Q0,QX,QY,QZ=np.meshgrid(q0,qs,qs,qs,indexing='ij',sparse=True)
    sp=phat2(QX,1)+phat2(QY,1)+phat2(QZ,1)
    G1=1/(m*m+phat2(Q0,r)+sp)
    sp2=phat2(QX+ps,1)+phat2(QY,1)+phat2(QZ,1)
    G2=1/(m*m+phat2(Q0+p0,r)+sp2)
    vol=(2*np.pi)**3*(2*np.pi/r)
    return np.sum(G1*G2)*vol/(Ns**3*Nt)/(2*np.pi)**4
def coeffs(r,m,h=0.02,Ns=24):
    s0=sigma(0,0,r,m,Ns)
    A0=(sigma(h,0,r,m,Ns)-s0)/h**2
    As=(sigma(0,h,r,m,Ns)-s0)/h**2
    return A0,As
loop=1/(16*np.pi**2)
m=0.5
print("m_chi =",m," (units of 1/a_s); values in units of g^2/(16 pi^2)")
for r in [1.0,0.5,0.25,0.125]:
    A0,As=coeffs(r,m)
    print(f" r=a_t/a_s={r:6.3f}:  A_time={A0/loop:+.5f}  A_space={As/loop:+.5f}  speed^2 shift (A0-As)={ (A0-As)/loop:+.5f}")
print("convergence check r=0.25, Ns=32:",[round(x/loop,5) for x in coeffs(0.25,m,Ns=32)])
