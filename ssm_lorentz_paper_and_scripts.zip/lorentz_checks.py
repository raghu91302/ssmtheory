#!/usr/bin/env python3
"""lorentz_checks.py -- real-time light cone of the SSM photon and matter walk.
Units: grid spacing h = a/2 = 1 (photon grid and tetrahedral-void grid both have this spacing).
Prints PASS/FAIL for each claim."""
import numpy as np
from scipy.linalg import expm
ok=lambda c,msg: print(("PASS " if c else "FAIL ")+msg)
rng=np.random.default_rng(0)
D=rng.normal(size=(120,3)); D/=np.linalg.norm(D,axis=1)[:,None]
named=[np.array([1,0,0.]),np.array([1,1,0])/2**.5,np.ones(3)/3**.5]
# 1. photon, continuous time
wph=lambda k: np.sqrt(np.sum(4*np.sin(k/2)**2))
sp=lambda q:[wph(q*n)/q for n in D]
r1,r2=np.ptp(sp(0.1)),np.ptp(sp(0.05))
ok(abs(r1/r2-4)<0.05, f"photon (continuous time): speed isotropic at k->0, anisotropy ~k^2 (ratio {r1/r2:.3f}, expect 4)")
ok(abs(wph(0.1*named[0])/0.1-(1-0.01/24))<1e-6, "photon: [100] phase velocity = 1 - k^2/24")
# 2. photon, leapfrog stability
def stable(s,N=4000):
    K=rng.uniform(-np.pi,np.pi,size=(N,3)); return np.all(s*np.sqrt(np.sum(np.sin(K/2)**2,axis=1))<=1+1e-12)
ok(stable(1/3**.5) and not stable(0.6), "photon (leapfrog): stable iff c*tau/h <= 1/sqrt(3)")
# 3. Dirac walk
sx=np.array([[0,1],[1,0]]);sy=np.array([[0,-1j],[1j,0]]);sz=np.diag([1.,-1]);I2=np.eye(2)
al=[np.kron(sx,s) for s in (sx,sy,sz)];be=np.kron(sz,I2)
S=lambda j,kj: np.cos(kj)*np.eye(4)-1j*np.sin(kj)*al[j]
C=lambda t: expm(-1j*t*be)
Useq=lambda k,t: C(t)@S(2,k[2])@S(1,k[1])@S(0,k[0])
Upal=lambda k,t: C(t/2)@S(0,k[0])@S(1,k[1])@S(2,k[2])@C(t)@S(2,k[2])@S(1,k[1])@S(0,k[0])@C(t/2)
w=lambda U,k,t,per: np.sort(np.abs(np.angle(np.linalg.eigvals(U(k,t)))))[0]/per
def vlow(U,t,per,n):
    q1,q2=(0.01,0.02) if t==0.04 else (0.002,0.004);a,b=w(U,q1*n,t,per),w(U,q2*n,t,per);return np.sqrt((b*b-a*a)/(q2*q2-q1*q1))
vs=[vlow(Useq,0.04,1,n) for n in named]
ok(np.ptp(vs)>0.01, f"walk, sequential order: leading-order anisotropy (v = {np.round(vs,4)})")
ok(w(Useq,0.02*named[2],0.0,1)>1e-4, "walk, sequential order: massless walk gets a gap along [111]")
vp=[vlow(Upal,0.08,2,n) for n in named]
ok(np.ptp(vp)<1e-4, f"walk, palindromic order (xyz then zyx): isotropic at leading order (v = {np.round(vp,5)})")
sp1=np.ptp([w(Upal,0.05*n,0.08,2) for n in named]);sp2=np.ptp([w(Upal,0.005*n,0.08,2) for n in named])
ok(sp1/sp2>5e3, f"walk, palindromic: anisotropy falls ~k^4 (ratio {sp1/sp2:.0f} for k/10)")
m=0.04;dv=1-np.mean([vlow(Upal,2*m,2,n) for n in named])
ok(abs(dv/(2*m)**2-1/6)<0.01, f"walk: limiting speed 1 - (m tau)^2/6 (got coefficient {dv/(2*m)**2:.4f})")
# 4. one-loop split
def phat2(p,a): return (2/a*np.sin(p*a/2))**2
def sigma(p0,ps,r,mm,Ns=24):
    qs=2*np.pi*(np.arange(Ns)-Ns//2)/Ns;Nt=int(round(Ns/r));q0=2*np.pi/r*(np.arange(Nt)-Nt//2)/Nt
    Q0,QX,QY,QZ=np.meshgrid(q0,qs,qs,qs,indexing='ij',sparse=True)
    G1=1/(mm*mm+phat2(Q0,r)+phat2(QX,1)+phat2(QY,1)+phat2(QZ,1))
    G2=1/(mm*mm+phat2(Q0+p0,r)+phat2(QX+ps,1)+phat2(QY,1)+phat2(QZ,1))
    return np.sum(G1*G2)/(Ns**3*Nt)/r
def split(r,mm,h=0.02):
    s0=sigma(0,0,r,mm);return ((sigma(h,0,r,mm)-s0)-(sigma(0,h,r,mm)-s0))/h**2*16*np.pi**2
iso=split(1.0,0.5); fol=split(0.25,0.5)
ok(abs(iso)<1e-10, f"one loop, time and space equivalent: speed split = {iso:.1e} (exactly zero)")
ok(abs(fol)>1e-3, f"one loop, time singled out: speed split = {fol:.4f} x g^2/(16 pi^2) (nonzero)")
