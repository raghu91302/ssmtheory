"""Figure 2: D4* as a stack of time slices (schematic x-t projection)."""
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.size":9})
C_NODE,C_OCT,C_TET,C_AX,C_MIX,C_GREY="#2f5d8a","#c0504d","#e3a33b","#222222","#7f77dd","#999999"
fig,ax=plt.subplots(figsize=(6.6,3.6))
xs=np.arange(-3,4);xh=np.arange(-2.5,3.0,1.0);ts=[-1,0,1];th=[-0.5,0.5]
# time-mixed links (photon only): integer <-> half sites
for t in ts:
    for x in xs:
        for dx in (-0.5,0.5):
            for dt in (-0.5,0.5):
                if -1<=t+dt<=1 and -3<=x+dx<=3: ax.plot([x,x+dx],[t,t+dt],color=C_MIX,lw=0.8,ls=(0,(3,2)),zorder=1)
# axis links (photon and fermions)
for t in ts:
    ax.plot([xs[0],xs[-1]],[t,t],color=C_AX,lw=1.1,zorder=2)
for t in th:
    ax.plot([xh[0],xh[-1]],[t,t],color=C_AX,lw=1.1,zorder=2)
for x in xs: ax.plot([x,x],[-1,1],color=C_AX,lw=1.1,zorder=2)
for x in xh: ax.plot([x,x],[-0.5,0.5],color=C_AX,lw=1.1,zorder=2)
# crossing links at the reflection plane t=0: temporal links at half-integer x
for x in xh: ax.plot([x,x],[-0.5,0.5],color="#d85a30",lw=2.4,zorder=3)
# sites
for t in ts:
    for x in xs:
        node=((x+t)%2==0)   # D4 (FCC nodes) = even-sum points of (x,y,z,t)
        ax.scatter([x],[t],s=46,marker="o" if node else "s",color=C_NODE if node else C_OCT,zorder=4,edgecolor="white",lw=0.6)
for t in th:
    ax.scatter(xh,[t]*len(xh),s=60,marker="^",color=C_TET,zorder=4,edgecolor="white",lw=0.6)
ax.plot([-3.25,3.25],[0,0],color=C_GREY,lw=0.8,ls="--",zorder=0)
ax.text(3.35,0.02,"reflection\nplane",va="center",fontsize=8,color="#555555")
for t,lab in [(-1,"integer slice"),(-0.5,"half-integer slice"),(0,"integer slice"),(0.5,"half-integer slice"),(1,"integer slice")]:
    ax.text(-3.45,t,lab,ha="right",va="center",fontsize=7.5,color="#555555")
ax.set_xlim(-5.6,4.4);ax.set_ylim(-1.3,1.45);ax.axis("off")
ax.annotate("",xy=(4.1,1.2),xytext=(4.1,-1.0),arrowprops=dict(arrowstyle="->",color="#555555"))
ax.text(4.2,1.2,"$t$",fontsize=9,color="#555555")
h=[plt.Line2D([],[],marker="o",ls="",color=C_NODE,label="FCC node"),
   plt.Line2D([],[],marker="s",ls="",color=C_OCT,label="octahedral void"),
   plt.Line2D([],[],marker="^",ls="",color=C_TET,label="tetrahedral void"),
   plt.Line2D([],[],color=C_AX,lw=1.1,label="axis link (photon and matter)"),
   plt.Line2D([],[],color=C_MIX,lw=0.8,ls=(0,(3,2)),label="time-mixed link (photon only)"),
   plt.Line2D([],[],color="#d85a30",lw=2.4,label="links crossing the plane")]
ax.legend(handles=h,loc="upper center",bbox_to_anchor=(0.5,1.13),ncol=3,frameon=False,fontsize=7.5,handlelength=1.8)
fig.savefig("Figure2_slicing.pdf",bbox_inches="tight");fig.savefig("Figure2_slicing.png",dpi=170,bbox_inches="tight")
print("ok")
