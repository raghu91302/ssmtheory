"""Field of a defect moving along a straight worldline (Euclidean: tilted line source) on D4* vs Z4.
Isotropy of the profile in the 4D perpendicular distance <=> exact Lorentz contraction after continuation."""
import numpy as np, itertools, collections
def setup(kind,n):
    N=2*n; X=np.indices((N,)*4).reshape(4,-1).T
    if kind=='D4s':
        R=np.array([v for v in np.vstack([2*np.eye(4),-2*np.eye(4)])]+list(itertools.product([1,-1],repeat=4)),int)
        mask=np.array([len(set(x%2))==1 for x in X]).reshape((N,)*4)
    else:
        R=np.vstack([2*np.eye(4),-2*np.eye(4)]).astype(int);mask=np.all(X%2==0,axis=1).reshape((N,)*4)
    k=2*np.pi*np.fft.fftfreq(N)
    Kg=np.stack(np.meshgrid(k,k,k,k,indexing='ij'),-1)
    Kk=np.sum(1-np.cos(Kg@R.T),axis=-1)*(4/len(R))/2*2  # normalize to |k_physical|^2 at small k
    return N,R,mask,Kk
def line_field(kind,n,u,m):
    N,R,mask,Kk=setup(kind,n)
    src=np.zeros((N,)*4)
    pts={tuple(np.mod(j*np.array(u),N)) for j in range(N)}
    for p in pts: src[p]+=1
    # convolution restricted to lattice: solve (K+m^2)phi = src on lattice sites (Kk defined on doubled grid acts within sublattice)
    phi=np.real(np.fft.ifftn(np.fft.fftn(src)/(Kk+m*m)))
    return N,phi,mask
def profile(kind,n,u,m,maxd=4.1):
    N,phi,mask=line_field(kind,n,u,m)
    u=np.array(u,float);uh=u/np.linalg.norm(u)
    out=collections.defaultdict(list)
    for w in itertools.product(range(-8,9),repeat=4):
        w=np.array(w)
        if not mask[tuple(np.mod(w,N))]: continue
        if abs(w@uh)>1e-9: continue
        d=np.linalg.norm(w)/2
        if 0<d<=maxd: out[round(d,6)].append(phi[tuple(np.mod(w,N))])
    return out
m=0.4;n=12
for kind,dirs in [('D4s',{'rest  (0,0,0,1)':(0,0,0,2),'moving (1,1,1,1)/2':(1,1,1,1),'moving (1,0,0,1)':(2,0,0,2)}),
                  ('Z4',{'rest  (0,0,0,1)':(0,0,0,2),'moving (1,0,0,1)':(2,0,0,2),'moving (1,1,0,0)':(2,2,0,0)})]:
    print(f"== {kind}: field at perpendicular distance d (normalized per unit length of worldline)")
    res={}
    for name,u in dirs.items():
        pr=profile(kind,n,u,m);L=np.linalg.norm(u)/2
        res[name]={d:np.array(v)*L for d,v in pr.items()}
    ds=sorted(set.intersection(*[set(r) for r in res.values()]))
    for d in ds[:6]:
        vals={nm:(r[d].mean(),np.ptp(r[d])) for nm,r in res.items()}
        allv=np.concatenate([r[d] for r in res.values()])
        print(f"  d={d:.4f}: "+"  ".join(f"{nm}: {v[0]:.6f}" for nm,v in vals.items())+f"   relative spread {np.ptp(allv)/allv.mean():.1e}")
