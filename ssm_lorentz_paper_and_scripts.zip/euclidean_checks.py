#!/usr/bin/env python3
"""euclidean_checks.py -- one light cone for light and matter on the D4* lattice (Euclidean route).
PASS/FAIL for each claim. Needs numpy, scipy. Runs in a few minutes."""
import numpy as np, itertools
from scipy.optimize import brentq
ok=lambda c,m: print(("PASS " if c else "FAIL ")+m)
R=np.array([v for v in np.vstack([np.eye(4),-np.eye(4)])]+[np.array(s)/2 for s in itertools.product([1,-1],repeat=4)])
Rp=np.array([r for r in R if tuple(r)>tuple(-r)])
ok(len(R)==24 and np.allclose(np.linalg.norm(R,axis=1),1), "D4* has 24 shortest vectors, all of length 1")
# triangles
tris=[];seen=set()
for a,b in itertools.product(R,R):
    c=-(a+b)
    if np.any(np.all(np.isclose(R,c),axis=1)):
        vs=[np.zeros(4),a,a+b];mn=min(map(tuple,vs))
        key=frozenset(tuple(np.round(np.array(v)-mn,6)) for v in vs)
        if key not in seen: seen.add(key);tris.append((-np.array(mn),[a,b,c]))
ok(len(tris)==32, "32 triangular plaquettes per site")
def link(r):
    for i,p in enumerate(Rp):
        if np.allclose(r,p): return i,1,np.zeros(4)
        if np.allclose(r,-p): return i,-1,-p
def d2(k):
    M=np.zeros((32,12),complex)
    for t,(v0,es) in enumerate(tris):
        x=v0.copy()
        for e in es: i,s,sh=link(e);M[t,i]+=s*np.exp(1j*(k@(x+sh)));x=x+e
    return M
Kmat=lambda k: np.sum(1-np.cos(R@k))/3
def E_photon(p):
    def f(E):
        ev=sorted(np.linalg.eigvals(d2(-np.array([*p,1j*E])).T@d2(np.array([*p,1j*E]))),key=abs);return ev[1].real
    q=np.linalg.norm(p);Es=np.linspace(0.5*q,1.5*q,30);v=[f(E) for E in Es]
    for a,b,fa,fb in zip(Es,Es[1:],v,v[1:]):
        if fa*fb<0: return brentq(f,a,b)
E_matter=lambda p,m: brentq(lambda E:(Kmat(np.array([*p,1j*E]))+m*m).real,0,5)
dirs=[np.array([1,0,0.]),np.array([1,1,0])/2**.5,np.ones(3)/3**.5]
vph=[E_photon(0.01*n)/0.01 for n in dirs]
ok(np.allclose(vph,1,atol=1e-7), f"photon real-time speed = 1 in all directions ({np.round(vph,9)})")
for m in [0.0,0.1]:
    vm=[np.sqrt(E_matter(0.01*n,m)**2-(E_matter(np.full(3,1e-12),m)**2 if m else 0))/0.01 for n in dirs]
    ok(np.allclose(vm,1,atol=2e-7), f"matter (m={m}) real-time limiting speed = photon speed, no tuning ({np.round(vm,9)})")
d1=1-np.sqrt(E_matter(0.01*dirs[0],0.5)**2-E_matter(np.full(3,1e-12),0.5)**2)/0.01
d2_=1-np.sqrt(E_matter(0.01*dirs[0],0.1)**2-E_matter(np.full(3,1e-12),0.1)**2)/0.01
ok(abs(np.log(d1/d2_)/np.log(5)-4)<0.2, f"mass dependence of limiting speed ~ (ma)^4 (exponent {np.log(d1/d2_)/np.log(5):.2f})")
# one loop on D4*
Kv=lambda k: np.sum(1-np.cos(k@R.T),axis=-1)/3
def sig(p,m=0.5,N=16):
    js=2*np.pi*np.arange(N)/N;j4=4*np.pi*np.arange(2*N)/(2*N)
    Q=np.stack(np.meshgrid(js,js,js,j4,indexing='ij'),-1).reshape(-1,4)
    return np.mean(1/((Kv(Q)+m*m)*(Kv(Q+p)+m*m)))
s0=sig(np.zeros(4));h=0.02
At=(sig(np.array([0,0,0,h]))-s0)/h**2;As=(sig(np.array([h,0,0,0]))-s0)/h**2
ok(abs(At-As)<1e-12*abs(At)+1e-14, f"one loop on D4*: time and space coefficients equal (split {(At-As)*16*np.pi**2:.1e} x g^2/16pi^2)")
# matter RP
def rp_matter(L=3,T=6,m=0.3):
    P=np.array([2*L]*3+[2*T]);sites=[X for X in itertools.product(*[range(p) for p in P]) if len(set(np.array(X)%2))==1]
    idx={s:i for i,s in enumerate(sites)};K=np.eye(len(sites))*m*m
    for s in sites:
        for r in (2*R).astype(int):
            t=tuple(np.mod(np.array(s)+r,P));K[idx[s],idx[s]]+=1/3;K[idx[s],idx[t]]-=1/3
    G=np.linalg.inv(K);tv=lambda x:((x+P[3]//2)%P[3])-P[3]//2
    pos=[i for i,s in enumerate(sites) if 0<=tv(s[3])<P[3]//2-1];rf=lambda s:tuple(np.mod([s[0],s[1],s[2],-s[3]],P))
    M=np.array([[G[idx[rf(sites[a])],b] for b in pos] for a in pos]);return np.linalg.eigvalsh((M+M.T)/2).min()
ok(rp_matter()>-1e-10, "matter field on D4* is reflection positive")
print("(photon reflection positivity: run rp.py D4s 3 6, rp_half.py, and rp_power.py for the detector control)")
