"""Figure 1: one-loop shift of the speed of a massless field vs how strongly time is singled out (a_t/a_s).
Data: one_loop_split.py (scalar loop, m=0.5) and fermion_loop.py (Wilson fermion loop, m=0.5)."""
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, numpy as np
plt.rcParams.update({"font.family":"serif","font.size":9,"axes.edgecolor":"#888888","axes.labelcolor":"#333333","xtick.color":"#555555","ytick.color":"#555555"})
r=np.array([1.0,0.5,0.25,0.125])
scalar=np.array([0.0,0.11837/0.59859,0.15365/0.59394,0.16204/0.59290])
fermion=np.array([0.0,0.2743,0.4391,0.5197])
fig,ax=plt.subplots(figsize=(4.6,2.9))
for y,c,lab in [(scalar,"#2a78d6","scalar loop"),(fermion,"#eb6834","Wilson-fermion loop")]:
    ax.plot(r,100*y,color=c,lw=2,marker="o",ms=6,mec="white",mew=1.2,label=lab,zorder=3)
    ax.text(0.112,100*y[-1],lab,color="#333333",ha="left",va="center",fontsize=8)
ax.set_xscale("log",base=2);ax.invert_xaxis()
ax.set_xticks(r);ax.set_xticklabels(["1\n(time = space)","1/2","1/4","1/8"])
ax.set_xlabel("temporal / spatial lattice spacing, $a_t/a_s$")
ax.set_ylabel("relative speed shift (%)")
ax.set_xlim(1.25,0.045);ax.set_ylim(-3,60)
ax.grid(axis="y",color="#e6e6e6",lw=0.6);ax.set_axisbelow(True)
for s in ("top","right"): ax.spines[s].set_visible(False)
ax.legend(frameon=False,fontsize=8,loc="upper left")
fig.savefig("Figure1_split.pdf",bbox_inches="tight");fig.savefig("Figure1_split.png",dpi=170,bbox_inches="tight");print("ok")
