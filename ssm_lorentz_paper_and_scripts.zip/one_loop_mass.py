"""Mass dependence of the one-loop speed shifts at a_t/a_s = 1/8 (continuous-time limit) and at 1
(isotropic): phi (light) from one_loop_split.py, chi (matter) from matter_loop.py, and the split."""
import os, numpy as np
here=os.path.dirname(os.path.abspath(__file__))
A={}; exec(open(os.path.join(here,'one_loop_split.py')).read().split("loop=1/")[0],A)
B={}; exec(open(os.path.join(here,'matter_loop.py')).read().split("if __name__")[0],B)
loop=1/(16*np.pi**2)
for m in [0.5,0.25,0.12]:
    Ns=40 if m<0.2 else 32; h=min(0.02,m/10)
    for r in [0.125,1.0]:
        A0,As=A['coeffs'](r,m,h=h,Ns=Ns); B0,Bs=B['coeffs'](r,m,Ns,h=h)
        a=(A0-As)/loop; b=(B0-Bs)/r/loop
        print(f" m*a={m} a_t/a_s={r}: phi shift {a:+.4f}  chi shift {b:+.4f}  split c_phi^2-c_chi^2 {a-b:+.4f}")
