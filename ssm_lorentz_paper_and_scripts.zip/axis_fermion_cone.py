import numpy as np
from scipy.optimize import brentq
# axis-only Wilson fermion (hypercubic, spacing 1 on each sublattice), r=1
def f(E,p,m):
    k=np.array([*p,1j*E]);s=np.sin(k);W=np.sum(1-np.cos(k))
    return np.real((m+W)**2+np.sum(s*s))
def E_f(p,m):
    Es=np.linspace(1e-6,3,6000);v=[f(E,p,m) for E in Es]
    for a,b,fa,fb in zip(Es,Es[1:],v,v[1:]):
        if fa*fb<0: return brentq(lambda E:f(E,p,m),a,b,xtol=1e-15)
dirs=[np.array([1,0,0.]),np.array([1,1,0])/2**.5,np.ones(3)/3**.5]
for m in [0.0,0.01,0.02,0.05]:
    E0=E_f(np.full(3,1e-9),m) if m else 0
    for q in [0.004,0.002]:
        vs=[np.sqrt(E_f(q*d,m)**2-E0**2)/q for d in dirs]
        print(f"m={m} q={q}: speeds {np.round(vs,9)}  1-v[100]={1-vs[0]:.2e}")
