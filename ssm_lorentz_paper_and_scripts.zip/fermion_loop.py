"""One-loop polarisation of a field coupled to a Wilson-fermion loop (vertex psibar psi), axis-only fermions.
Compare time and space quadratic coefficients: equal when time and space are treated alike (hypercubic),
split when the temporal spacing differs (time singled out)."""
import numpy as np, itertools
g=[np.array(m,complex) for m in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
def Sinv_parts(Q,m,a):   # Wilson operator with spacing a=(1,1,1,a_t): D = i sum g_mu sin(k a)/a + m + sum (1-cos(k a))/a
    s=np.sin(Q*a)/a; w=m+np.sum((1-np.cos(Q*a))/a,axis=-1)
    return s,w
def Pi(p,m,at,N):
    a=np.array([1,1,1,at]);qs=2*np.pi*(np.arange(N)-N//2)/N;Nt=int(round(N/at));q0=2*np.pi/at*(np.arange(Nt)-Nt//2)/Nt
    Q=np.stack(np.meshgrid(qs,qs,qs,q0,indexing='ij'),-1).reshape(-1,4)
    s1,w1=Sinv_parts(Q,m,a);s2,w2=Sinv_parts(Q+p,m,a)
    # tr[S(q)S(q+p)] with S = (w - i s.g)/(w^2+s^2): tr = 4 (w1 w2 - s1.s2)/((w1^2+s1^2)(w2^2+s2^2))
    t=4*(w1*w2-np.sum(s1*s2,axis=-1))/((w1**2+np.sum(s1**2,-1))*(w2**2+np.sum(s2**2,-1)))
    return -np.mean(t)/at   # fermion loop sign; normalisation irrelevant for the split
def split(m,at,N=20,h=0.02):
    P0=Pi(np.zeros(4),m,at,N)
    At=(Pi(np.array([0,0,0,h]),m,at,N)-P0)/h**2;As=(Pi(np.array([h,0,0,0]),m,at,N)-P0)/h**2
    return At,As
for at in [1.0,0.5,0.25,0.125]:
    At,As=split(0.5,at)
    print(f"a_t/a_s={at}: time coeff {At*16*np.pi**2:+.5f}, space coeff {As*16*np.pi**2:+.5f}, relative split {(At-As)/abs(As):+.2e}")
