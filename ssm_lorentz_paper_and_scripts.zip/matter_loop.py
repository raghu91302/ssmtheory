"""One-loop speed shift of the massive field chi (the 'matter' field) in the same model as
one_loop_split.py, so that the light-matter split c_phi^2 - c_chi^2 can be formed.
Normalisation: phi self-energy = g^2 * sum G_chi G_chi (one_loop_split.py); then the chi
self-energy is 2 g^2 * sum G_phi G_chi.  Gamma = p^2 + m^2 - Sigma, so c^2 - 1 ~ A_time - A_space.
The massless phi propagator is summed on a half-shifted (antiperiodic) momentum grid to avoid
the zero mode; the integrand is integrable at q=0 in four dimensions."""
import numpy as np
def phat2(p,a): return (2/a*np.sin(p*a/2))**2
def sigma_chi(p0,ps,r,m,Ns):
    qs=2*np.pi*(np.arange(Ns)-Ns//2+0.5)/Ns
    Nt=int(round(Ns/r)); q0=2*np.pi/r*(np.arange(Nt)-Nt//2+0.5)/Nt
    Q0,QX,QY,QZ=np.meshgrid(q0,qs,qs,qs,indexing='ij',sparse=True)
    sp=phat2(QX,1)+phat2(QY,1)+phat2(QZ,1)
    Gphi=1/(phat2(Q0,r)+sp)
    Gchi=1/(m*m+phat2(Q0+p0,r)+phat2(QX+ps,1)+phat2(QY,1)+phat2(QZ,1))
    return 2*np.mean(Gphi*Gchi)
def coeffs(r,m,Ns,h=0.02):
    s0=sigma_chi(0,0,r,m,Ns)
    return (sigma_chi(h,0,r,m,Ns)-s0)/h**2,(sigma_chi(0,h,r,m,Ns)-s0)/h**2
loop=1/(16*np.pi**2)
# Brillouin-zone sum: as in one_loop_split.py, sum*vol/(Ns^3 Nt)/(2pi)^4 with vol=(2pi)^4/r, i.e. mean/r.
def split(r,m,Ns):
    B0,Bs=coeffs(r,m,Ns); return B0/r/loop,Bs/r/loop,(B0-Bs)/r/loop
if __name__=="__main__":
    m=0.5
    for r in [1.0,0.5,0.25,0.125]:
        b=split(r,m,24); print(f"m={m} a_t/a_s={r}: B_t={b[0]:+.4f} B_s={b[1]:+.4f} chi shift={b[2]:+.4f}")
    print("convergence r=0.25 Ns=32:",[round(x,4) for x in split(0.25,m,32)])
    for m in [0.25,0.12]:
        print(f"m={m} a_t/a_s=0.125 Ns=40: chi shift={split(0.125,m,40)[2]:+.4f}")
