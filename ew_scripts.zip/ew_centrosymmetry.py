#!/usr/bin/env python3
"""
EW-2: the chirality obstruction. FCC is centrosymmetric (space group Fm-3bar-m).
At a bulk node the up-Lift environment and down-Lift environment are related by
INVERSION through the node, so their handedness is opposite and cancels. A global
stacking sense (single seed) is a real handedness of the crystal as a whole, but
it does NOT imprint a uniform per-node chirality on the interlayer su(2).
=> chirality PERMITTED, not FORCED. The proof is the inversion relation, not a
   handedness probe (the verified, robust argument).
"""
import numpy as np
a1=np.array([1.0,0]); a2=np.array([0.5,np.sqrt(3)/2])
oA=np.array([0,0]); oB=(a1+a2)/3; oC=2*(a1+a2)/3; h=np.sqrt(2/3)

# bulk B-node at (oB, z=0). Up environment = C layer (z=+h), down = A layer (z=-h).
B=np.array([oB[0],oB[1],0.0])
# the 3 up-Lift partners (nearest C nodes) and 3 down-Lift partners (nearest A nodes)
def near3(off,z):
    pts=np.array([[ (i*a1+j*a2+off)[0],(i*a1+j*a2+off)[1],z] for i in range(-3,4) for j in range(-3,4)])
    return pts[np.argsort(np.linalg.norm(pts-B,axis=1))[:3]]
up=near3(oC,+h); dn=near3(oA,-h)

# CLAIM: up and dn are related by inversion through B: dn == 2B - up (as sets).
inv_up=np.array([2*B-u for u in up])
# match inv_up to dn as sets
def setmatch(X,Y):
    Y=list(Y)
    for x in X:
        k=np.argmin([np.linalg.norm(x-y) for y in Y])
        if np.linalg.norm(x-Y[k])>1e-6: return False
        Y.pop(k)
    return True
print("=== FCC bulk inversion symmetry through a node ===")
print("up-Lift partners (C layer):",[tuple(round(float(c),3) for c in u) for u in up])
print("down-Lift partners (A layer):",[tuple(round(float(c),3) for c in d) for d in dn])
print("inversion of up-partners through B (2B - up):",[tuple(round(float(c),3) for c in x) for x in inv_up])
ok=setmatch(inv_up,dn)
print(f"\ndown-partners == inversion of up-partners through B: {ok}")
print()
if ok:
    print("PROVEN: the up-Lift and down-Lift environments of a bulk node are exact")
    print("inversion partners. Inversion reverses handedness, so the two Lifts carry")
    print("OPPOSITE chirality and cancel at every bulk node.")
    print()
    print("=> A single seed sets a global stacking sense (a real crystal handedness),")
    print("   but FCC centrosymmetry means it does NOT produce a uniform per-node")
    print("   chirality on the interlayer su(2). The crystallization handedness is")
    print("   global/boundary, not bulk-local.")
    print("=> Interlayer SU(2)_L chirality is PERMITTED but NOT FORCED.")
    print("   Obstruction = FCC centrosymmetry (Fm-3m), an independently checkable fact.")
else:
    print("inversion relation does not hold as stated -- re-examine.")
