# Electroweak boundary paper — verification scripts

Verification scripts for *An Electroweak-Shaped Structure on the FCC Vacuum:
Static Centrosymmetry Forbids Chirality, but a Defect Worldline Relaxes the
Obstruction to PT and Violates Parity* (R. Kulkarni).

Companion to the strong-sector color paper, DOI [10.5281/zenodo.18503168](https://doi.org/10.5281/zenodo.18503168).

## Requirements
```
pip install -r requirements.txt
```
(`numpy`, `scipy`)

## Reproduce everything
```
./run_all.sh
```
This runs the four scripts in manuscript order and writes results to `outputs/`.
Compare against the committed `expected_output_*.txt` files.

## Scripts

| Script | Paper section | Checks |
|---|---|---|
| `ew_su2_structure.py` | Sec 2 | The 6 square faces of the cuboctahedron carry an su(2) (three ⟨100⟩ axis-pairs closing as so(3)≅su(2)); the interlayer reading gives a 2-dim doublet and an order-2 grading. |
| `ew_centrosymmetry.py` | Sec 4 | The down-Lift environment is the exact inversion image of the up-Lift through the node (machine precision) — the static parity (P) cancellation from FCC centrosymmetry. |
| `ew_worldline_pt.py` | Sec 5 | On a chronological worldline, spatial inversion P pairs only the spatial parts of the future-up and past-down steps; the full 4-vectors are paired only by PT. The obstruction relaxes P → PT. |
| `ew_parity_violation.py` | Sec 5 | Classifying the doublet generators by P and PT, σ_y is the unique P-odd / PT-even generator (the oriented-Lift contribution): genuine parity violation. The bare generator is still vector (left/right retention equal), so P_L is not forced. |

## Result (three tiers)
- **Reached:** su(2)×u(1)-shaped structure on the square faces; on a worldline, genuine parity violation from the oriented Lift.
- **Forbidden statically / open on the worldline:** centrosymmetry forbids a static chiral assignment (P-cancellation); the worldline relaxes it to PT (compatible with a chiral coupling). The left projection P_L that would complete SU(2)_L is **not** forced — the open frontier.
- **Not touched:** chiral hypercharge assignments; gauge anomaly cancellation.

These scripts establish a group-theoretic correspondence and a symmetry-relaxation
result, not a dynamical demonstration that the square-face axes act as internal
gauge generators.
