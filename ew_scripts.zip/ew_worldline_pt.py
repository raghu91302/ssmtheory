#!/usr/bin/env python3
"""
CORRECTED temporal model: a defect WORLDLINE THREADING the stack chronologically.
A (past, t=-dt) -> B (now, t=0) -> C (future, t=+dt). A single time-ordered path.
The 'down' connection (B<-A) is to the PAST; the 'up' connection (B->C) is to the
FUTURE. Question: does spatial inversion P (which leaves time alone) still pair
the past-down step against the future-up step? If NOT, time breaks the obstruction.

Built to TRY to keep P pairing them (fail to fix). Two independent checks at end.
"""
import numpy as np
a1=np.array([1.0,0]); a2=np.array([0.5,np.sqrt(3)/2])
oA=np.array([0,0]); oB=(a1+a2)/3; oC=2*(a1+a2)/3; h=np.sqrt(2/3)
B=np.array([oB[0],oB[1],0.0]); B4=np.array([0.0,B[0],B[1],B[2]])
def near3(off,z):
    pts=np.array([[ (i*a1+j*a2+off)[0],(i*a1+j*a2+off)[1],z] for i in range(-3,4) for j in range(-3,4)])
    return pts[np.argsort(np.linalg.norm(pts-B,axis=1))[:3]]

# THREADED worldline: down-step is the connection to the PAST (A at t=-dt),
# up-step is the connection to the FUTURE (C at t=+dt).
dt=1.0
up4   = np.array([[+dt, p[0],p[1],p[2]] for p in near3(oC,+h)])   # B -> C, future
down4 = np.array([[-dt, p[0],p[1],p[2]] for p in near3(oA,-h)])   # A -> B, past
def setmatch(X,Y,tol=1e-6):
    Y=[y for y in Y]
    for x in X:
        k=int(np.argmin([np.linalg.norm(x-y) for y in Y]))
        if np.linalg.norm(x-Y[k])>tol: return False
        Y.pop(k)
    return True

print("=== threaded worldline A(t=-dt) -> B(t=0) -> C(t=+dt) ===")
print(f"  up-step (future)  times: {[round(float(x),3) for x in sorted(up4[:,0])]}")
print(f"  down-step (past)  times: {[round(float(x),3) for x in sorted(down4[:,0])]}")

# spatial inversion P through B4 (time untouched):
def P(v4):
    out=v4.copy(); out[1:]=2*B4[1:]-v4[1:]; return out
Pup=np.array([P(u) for u in up4])
print("\n=== does spatial P pair the future-up step with the past-down step? ===")
sp = setmatch([u[1:] for u in Pup],[d[1:] for d in down4])   # space match
tm = np.allclose([round(float(x),3) for x in sorted(Pup[:,0])], [round(float(x),3) for x in sorted(down4[:,0])])         # time match
print(f"  P(up) spatial == down spatial: {sp}")
print(f"  P(up) time == down time:       {tm}   (P leaves time = +dt; down is at -dt)")
print(f"    P(up) times: {[round(float(x),3) for x in sorted(Pup[:,0])]}   down times: {[round(float(x),3) for x in sorted(down4[:,0])]}")
print()
if sp and not tm:
    print("  P matches the SPACE but NOT the time: P(up) sits at t=+dt, the down-step")
    print("  at t=-dt. As 4-vectors they do NOT coincide. Spatial inversion does NOT")
    print("  pair the future-up and past-down worldline steps.")
    print("  => the static P-cancellation is LIFTED on a chronological worldline.")

# CHECK 2: what symmetry WOULD pair them? PT (flip space and time through B4):
def PT(v4): return 2*B4 - v4
PTup=np.array([PT(u) for u in up4])
pt_match=setmatch([u for u in PTup],[d for d in down4])
print(f"\n=== which symmetry pairs up<->down on the worldline? ===")
print(f"  PT (full spacetime inversion) pairs up<->down: {pt_match}")
print(f"    PT(up) times: {[round(float(x),3) for x in sorted(PTup[:,0])]}  down times: {[round(float(x),3) for x in sorted(down4[:,0])]}")
print()

# Note: Checks 1-2 are EXACT geometric set-membership relations (which 4-vectors
# coincide under P vs PT). They are basis-independent and robust. We deliberately do
# NOT use an ad-hoc signed-volume "chirality scalar" here: such a scalar is a weaker,
# convention-dependent probe and is not what the claim rests on. The claim is the
# symmetry relation itself: P fails to pair the worldline steps; PT pairs them.

print("=== VERDICT ===")
if sp and not tm and pt_match:
    print("On a chronological defect worldline, spatial inversion P pairs the SPATIAL parts")
    print("of the future-up and past-down Lift steps but NOT the full 4-vectors (they sit")
    print("at t=+dt and t=-dt). The static centrosymmetric cancellation was a pure-space P")
    print("relation; threading the stack in time separates the partners in the time")
    print("coordinate, so P no longer pairs them. The operator that DOES pair them is the")
    print("full spacetime inversion PT.")
    print("=> The obstruction RELAXES from a P relation to a PT relation on a defect")
    print("   worldline. Since chiral theories are compatible with PT (CPT), the static")
    print("   prohibition is lifted (not that chirality is forced -- see ew_parity_violation.py).")
else:
    print(f"Relation not as expected: sp={sp}, tm={tm}, pt_match={pt_match}. Re-examine.")
