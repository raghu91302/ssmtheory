#!/usr/bin/env python3
"""
CORRECTED temporal model: a defect WORLDLINE THREADING the stack chronologically.
A (past, t=-dt) -> B (now, t=0) -> C (future, t=+dt). A single time-ordered path.
The 'down' connection (B<-A) is to the PAST; the 'up' connection (B->C) is to the
FUTURE. Question: does spatial inversion P (which leaves time alone) still pair
the past-down step against the future-up step? If NOT, time breaks the obstruction.

Built to TRY to keep P pairing them (fail to fix). Two independent checks at end.
"""
import numpy as np
a1=np.array([1.0,0]); a2=np.array([0.5,np.sqrt(3)/2])
oA=np.array([0,0]); oB=(a1+a2)/3; oC=2*(a1+a2)/3; h=np.sqrt(2/3)
B=np.array([oB[0],oB[1],0.0]); B4=np.array([0.0,B[0],B[1],B[2]])
def near3(off,z):
    pts=np.array([[ (i*a1+j*a2+off)[0],(i*a1+j*a2+off)[1],z] for i in range(-3,4) for j in range(-3,4)])
    return pts[np.argsort(np.linalg.norm(pts-B,axis=1))[:3]]

# THREADED worldline: down-step is the connection to the PAST (A at t=-dt),
# up-step is the connection to the FUTURE (C at t=+dt).
dt=1.0
up4   = np.array([[+dt, p[0],p[1],p[2]] for p in near3(oC,+h)])   # B -> C, future
down4 = np.array([[-dt, p[0],p[1],p[2]] for p in near3(oA,-h)])   # A -> B, past
def setmatch(X,Y,tol=1e-6):
    Y=[y for y in Y]
    for x in X:
        k=int(np.argmin([np.linalg.norm(x-y) for y in Y]))
        if np.linalg.norm(x-Y[k])>tol: return False
        Y.pop(k)
    return True

print("=== threaded worldline A(t=-dt) -> B(t=0) -> C(t=+dt) ===")
print(f"  up-step (future)  times: {sorted(up4[:,0])}")
print(f"  down-step (past)  times: {sorted(down4[:,0])}")

# spatial inversion P through B4 (time untouched):
def P(v4):
    out=v4.copy(); out[1:]=2*B4[1:]-v4[1:]; return out
Pup=np.array([P(u) for u in up4])
print("\n=== does spatial P pair the future-up step with the past-down step? ===")
sp = setmatch([u[1:] for u in Pup],[d[1:] for d in down4])   # space match
tm = np.allclose(sorted(Pup[:,0]), sorted(down4[:,0]))         # time match
print(f"  P(up) spatial == down spatial: {sp}")
print(f"  P(up) time == down time:       {tm}   (P leaves time = +dt; down is at -dt)")
print(f"    P(up) times: {sorted(Pup[:,0])}   down times: {sorted(down4[:,0])}")
print()
if sp and not tm:
    print("  P matches the SPACE but NOT the time: P(up) sits at t=+dt, the down-step")
    print("  at t=-dt. As 4-vectors they do NOT coincide. Spatial inversion does NOT")
    print("  pair the future-up and past-down worldline steps.")
    print("  => the static P-cancellation is LIFTED on a chronological worldline.")

# CHECK 2: what symmetry WOULD pair them? PT (flip space and time through B4):
def PT(v4): return 2*B4 - v4
PTup=np.array([PT(u) for u in up4])
pt_match=setmatch([u for u in PTup],[d for d in down4])
print(f"\n=== which symmetry pairs up<->down on the worldline? ===")
print(f"  PT (full spacetime inversion) pairs up<->down: {pt_match}")
print(f"    PT(up) times: {sorted(PTup[:,0])}  down times: {sorted(down4[:,0])}")
print()

# CHECK 3 (independent): the spacetime 'screw' chirality = sign of the 4-volume
# spanned by (time direction, and the spatial handedness of the up-triangle).
# Compute the signed 4-volume of the worldline cell vs its mirror.
def chir4(steps4, center4):
    # 3 spatial bond vectors of the future triangle + the time axis -> 3x3 spatial
    # handedness weighted by time direction
    sp=[s[1:]-center4[1:] for s in steps4]
    n=np.cross(sp[1]-sp[0], sp[2]-sp[0])
    tdir=np.mean([s[0] for s in steps4])-center4[0]   # net time direction (+ future)
    return np.sign(tdir*np.dot(n, np.mean(sp,axis=0)))
c_up=chir4(up4,B4); c_dn=chir4(down4,B4)
print(f"=== independent check: spacetime screw chirality ===")
print(f"  future-up spacetime chirality: {c_up:+.0f}")
print(f"  past-down spacetime chirality: {c_dn:+.0f}")
print(f"  (static space-only these were OPPOSITE and cancelled; with time weighting:)")
print("  SAME sign -> reinforce (chiral worldline)" if c_up==c_dn else "  OPPOSITE -> cancel")
print()
print("=== VERDICT ===")
if sp and not tm and not pt_match:
    print("On a chronological defect worldline, spatial inversion P does NOT pair the")
    print("future-up and past-down Lift steps (they sit at t=+dt and t=-dt). The static")
    print("centrosymmetric cancellation was a PURE-SPACE P relation; threading the stack")
    print("in time separates the partners in the time coordinate, so P no longer cancels")
    print("the handedness. => TIME LIFTS THE OBSTRUCTION on a defect worldline.")
    print("   The bulk static lattice stays achiral, but a defect worldline climbing the")
    print("   stack is a spacetime screw and carries a definite chirality.")
else:
    print("P still effectively pairs them; time does not lift the obstruction.")
