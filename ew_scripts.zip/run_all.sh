#!/usr/bin/env bash
# Reproduce all verification results for the electroweak boundary paper, in the
# order they appear in the manuscript. Outputs are written to outputs/<script>.txt.
set -e
mkdir -p outputs
echo "[1/4] su(2) structure on the square faces (Sec 2)"
python3 ew_su2_structure.py    | tee outputs/ew_su2_structure.txt
echo "[2/4] static centrosymmetry obstruction / inversion pairing (Sec 4)"
python3 ew_centrosymmetry.py   | tee outputs/ew_centrosymmetry.txt
echo "[3/4] worldline: P relaxes to PT (Sec 5)"
python3 ew_worldline_pt.py     | tee outputs/ew_worldline_pt.txt
echo "[4/4] parity violation: sigma_y is the P-odd/PT-even generator (Sec 5)"
python3 ew_parity_violation.py | tee outputs/ew_parity_violation.txt
echo
echo "All scripts completed. Outputs in ./outputs/"
