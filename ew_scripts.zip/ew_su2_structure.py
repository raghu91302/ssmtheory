#!/usr/bin/env python3
"""
EW-1: the square faces of the FCC cuboctahedron carry su(2); with the diagonal
U(1) the rank matches SU(2)xU(1). Read as interlayer objects they give a 2-dim
doublet with a valid order-2 chirality operator. (Verified, clean.)
"""
import numpy as np, itertools
verts=[]
for s in itertools.product([1,-1],repeat=2):
    verts += [(s[0],s[1],0),(s[0],0,s[1]),(0,s[0],s[1])]
verts=sorted(set(verts)); V=np.array(verts,float); N=12
edges=[(i,j) for i in range(N) for j in range(i+1,N) if abs(np.linalg.norm(V[i]-V[j])-np.sqrt(2))<1e-6]
adj={i:set() for i in range(N)}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tris=[t for t in itertools.combinations(range(N),3) if all(b in adj[a] for a,b in itertools.combinations(t,2))]
def planar4(q):
    a=q[0]; return abs(np.linalg.det(np.array([V[x]-V[a] for x in q[1:]])))<1e-6
squares=[q for q in itertools.combinations(range(N),4)
         if sum(1 for a,b in itertools.combinations(q,2) if b in adj[a])==4 and planar4(q)]
print(f"cuboctahedron: {N} vertices, {len(edges)} edges, {len(tris)} triangles, {len(squares)} squares")
assert len(tris)==8 and len(squares)==6
# square normals -> 3 axes
norms=sorted({tuple(np.round(V[list(s)].mean(0)/np.linalg.norm(V[list(s)].mean(0)),3)) for s in squares})
axes=sorted({tuple(sorted(abs(x) for x in n)) for n in norms})
print(f"6 squares along +-x,+-y,+-z = 3 antipodal axis-pairs")
# the 3 axes close as so(3)=su(2)
Jx=np.array([[0,0,0],[0,0,-1],[0,1,0]],float);Jy=np.array([[0,0,1],[0,0,0],[-1,0,0]],float);Jz=np.array([[0,-1,0],[1,0,0],[0,0,0]],float)
co=lambda a,b:a@b-b@a
print("3 square-axes close as so(3)=su(2):",
      np.allclose(co(Jx,Jy),Jz) and np.allclose(co(Jy,Jz),Jx) and np.allclose(co(Jz,Jx),Jy))
print("rank(su(2))=1; with diagonal U(1) -> rank 2 = rank(SU(2)xU(1)).")
# interlayer doublet + order-2 chirality
sz=np.array([[1,0],[0,-1]],complex)
print("interlayer up/down doublet: g5=sigma_z, g5^2=I:",np.allclose(sz@sz,np.eye(2)),
      "eigenvalues",np.round(np.linalg.eigvalsh(sz),3),"(valid chirality operator)")
print("=> square faces carry an SU(2)xU(1)-shaped structure with a valid chirality operator.")
