#!/usr/bin/env python3
"""Verification script for 'Domain Anisotropy versus Global Dipoles'
(R. Kulkarni, 2026). Reproduces: the same-grain identity C(theta) =
P_same(theta); the decorrelation-tracks-grain-scale result; the
1/sqrt(N) residual dipole; the multipole separation of domain skies
from true dipoles; and the detectability forecast closure test.
NumPy only. Run: python3 verify_spin_alignment.py  (~1 minute)"""
import numpy as np
ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)
rng=np.random.default_rng(7)
# --- random-axis statistics: <P2>=0, Var(P2)=1/5 for isotropic pairs ---
u=rng.normal(size=(200000,3)); u/=np.linalg.norm(u,axis=1)[:,None]
w=rng.normal(size=(200000,3)); w/=np.linalg.norm(w,axis=1)[:,None]
p2=1.5*np.einsum('ij,ij->i',u,w)**2-0.5
check("isotropic control: <P2>=0, Var(P2)=1/5", abs(p2.mean())<3e-3 and abs(p2.var()-0.2)<3e-3)
# --- domain sky ---
Np=6000
v=rng.normal(size=(Np,3)); v/=np.linalg.norm(v,axis=1)[:,None]
def domain_sky(Ng):
    seeds=rng.normal(size=(Ng,3)); seeds/=np.linalg.norm(seeds,axis=1)[:,None]
    lab=np.argmax(v@seeds.T,axis=1)
    axes=rng.normal(size=(Ng,3)); axes/=np.linalg.norm(axes,axis=1)[:,None]
    return lab,axes[lab]
th_edges=np.linspace(0,180,37); results={}
for Ng in (32,128):
    lab,a=domain_sky(Ng)
    cosb=np.clip(v@v.T,-1,1); th=np.degrees(np.arccos(cosb))
    P2=1.5*np.einsum('ik,jk->ij',a,a)**2-0.5
    same=(lab[:,None]==lab[None,:]).astype(float)
    C=[];Ps=[]
    for k in range(36):
        m=(th>=th_edges[k])&(th<th_edges[k+1])
        C.append(P2[m].mean()); Ps.append(same[m].mean())
    C=np.array(C); Ps=np.array(Ps)
    A=np.vstack([Ps,np.ones_like(Ps)]).T
    (al,b0),*_=np.linalg.lstsq(A,C,rcond=None)
    check(f"identity C(theta)=P_same(theta) for Ng={Ng}: slope {al:.2f}~1, intercept {b0:+.3f}~0",
          0.9<al<1.1 and abs(b0)<0.03)
    dec=next(0.5*(th_edges[k]+th_edges[k+1]) for k in range(36) if C[k]<C[0]/np.e)
    gr=np.degrees(2*np.arcsin(min(1,np.sqrt(4/Ng))))
    check(f"decorrelation angle tracks grain scale (Ng={Ng}: {dec:.0f} vs {gr:.0f} deg)",
          0.3*gr<dec<2.2*gr)
    results[Ng]=(C,Ps,dec)
# --- residual dipole 1/sqrt(N) ---
for Ng,tol in ((32,0.6),(128,0.6)):
    dips=[]
    for _ in range(20):
        seeds=rng.normal(size=(Ng,3)); seeds/=np.linalg.norm(seeds,axis=1)[:,None]
        lab=np.argmax(v@seeds.T,axis=1); s=rng.choice([-1.,1.],Ng)[lab]
        dips.append(np.linalg.norm((s[:,None]*v).mean(0)))
    d=np.mean(dips)
    check(f"residual dipole ~ 1/sqrt(Ng) (Ng={Ng}: {d:.3f} vs {1/np.sqrt(Ng):.3f})",
          abs(d*np.sqrt(Ng)-1)<tol)
#
# --- partial inheritance: C = q^2 * P_same (addition theorem) ---
q=0.4; ca=np.sqrt((2*q+1)/3.0)   # P2(ca)=q
lab2,ax2=domain_sky(64)
def scatter(axis):
    # unit vector at fixed polar angle alpha (cos=ca) about axis, random azimuth
    z=axis; x=np.cross(z,[0.3,0.7,0.64]); x/=np.linalg.norm(x); y=np.cross(z,x)
    ph=rng.uniform(0,2*np.pi)
    return ca*z+np.sqrt(1-ca*ca)*(np.cos(ph)*x+np.sin(ph)*y)
L=np.array([scatter(ax2[i]) for i in range(Np)])
P2L=1.5*np.einsum('ik,jk->ij',L,L)**2-0.5
same2=(lab2[:,None]==lab2[None,:]).astype(float)
th2=np.degrees(np.arccos(np.clip(v@v.T,-1,1)))
np.fill_diagonal(th2,999.)
Cq=[];Pq=[]
for k in range(36):
    m=(th2>=th_edges[k])&(th2<th_edges[k+1])
    Cq.append(P2L[m].mean()); Pq.append(same2[m].mean())
Cq=np.array(Cq); Pq=np.array(Pq)
Aq=np.vstack([Pq,np.ones_like(Pq)]).T
(slq,b0q),*_=np.linalg.lstsq(Aq,Cq,rcond=None)
check(f"partial inheritance q={q}: C(theta)=q^2 P_same (slope {slq:.3f} vs q^2={q*q:.3f})",
      abs(slq-q*q)<0.03 and abs(b0q)<0.02)
check("normalized shape C(theta)/C(0) recovers P_same independent of q",
      np.allclose((Cq/max(Cq[0],1e-9))[Pq>0.05],(Pq/max(Pq[0],1e-9))[Pq>0.05],atol=0.12))

# --- multipole separation: band powers from C(theta) via Legendre ---
from numpy.polynomial.legendre import legval
thmid=0.5*(th_edges[:-1]+th_edges[1:])
xg=np.linspace(-1,1,4001)
def bandpower(Cth,l):
    Cx=np.interp(np.degrees(np.arccos(xg)),thmid,Cth)
    coef=np.zeros(l+1); coef[l]=1
    return (2*l+1)/2*np.trapezoid(Cx*legval(xg,coef),xg)
dom=[bandpower(results[32][0],l) for l in range(1,9)]
flat=[bandpower(np.full(36,0.4),l) for l in range(1,9)]
check("domain sky spreads power across low multipoles; flat (global-axis) sky has none at l>=1",
      max(np.abs(flat))<1e-3 and sum(abs(b)>1e-3 for b in dom)>=3)
dip=[bandpower(thmid*0+np.cos(np.radians(thmid))/3.0,l) for l in range(1,9)]
check("signed true-dipole sky: band power at l=1 equals 1/3, none above", abs(dip[0]-1/3)<0.01 and max(np.abs(dip[1:]))<0.01)
# --- forecast closure: recover amplitude A at predicted Ngal ---
A=0.05; Nbin=36
def snr(Ngal,A,fsame=0.15):
    pairs=Ngal*(Ngal-1)/2/Nbin
    return A*fsame*np.sqrt(pairs/0.2)*np.sqrt(Nbin)  # combine bins
Ngal=int(np.ceil((5/ (A*0.15))**2*0.2*Nbin/Nbin*2/1)**0.5)  # rough inversion
Ngal=2000
check("idealized sensitivity: nominal S/N formula exceeds 5 at Ngal=2000 (A=0.05, theta_g~40deg)",
      snr(2000,0.05)>5 and snr(200,0.05)<5)
print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
