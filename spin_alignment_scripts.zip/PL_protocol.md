# The Chiral Projection: Pre-Registered Computation Protocol

**Series:** Selection-Stitch Model, electroweak program.
**Status:** written BEFORE the computation. Nothing below may be
revised after the first computation cell runs, except by adding
dated amendments that leave the original text intact.
**Date locked:** August 30, 2026.

---

## 1. The hypothesis under test

**H (creation-front chirality).** Parity violation is the local trace
of cosmogenesis. The crystallization front that created the patch laid
every node down with the same local order: lower sheet first (then
verified and committed), upper sheet after (verification pending). The
code's dynamics couples to undecided structure only, because committed
structure sits in stabilizer eigenstates and cannot respond. The
induced interlayer su(2) therefore acts through the projector onto the
pending sheet:

    P_L = (1/2)(1 + gamma_5),   gamma_5 = sigma_z on the orientation doublet.

The sign of "left" is the front sign: the propagation sense of the
crystallization wave, fixed at nucleation, shared by every node in the
domain.

**Consequences if H holds (recorded now, tested later, in order):**
1. The chiral projection is derived, not assumed; the vector su(2)
   obstruction of the worldline analysis is resolved.
2. The integer charge unit enters with T3 of the now-chiral factor;
   +2/3 becomes constructible (the charge fence predicted exactly
   this dependence).
3. Only interlayer (out-of-plane) physics violates P; in-plane physics
   (color, the Stitch) conserves it. This is a structural postdiction.
4. P_L anchors to temporal ordering, not to a spatial vector: Lorentz
   invariant at leading order, with foliation-anchored deviations that
   the dispersion program can bound. This is the falsifier H exports.

## 2. Prerequisites (must complete before Step 1)

- **MEI verification session.** Extract from the MEI paper (Phys. Open
  100414): the defect construction (extra node in a tetrahedral void),
  the V1b/V1c verification operators as actually defined, and the
  interlayer hop as the model defines it. No stand-ins. If the MEI
  paper does not define a hop operator, the hop must be constructed
  from the code's own stabilizer structure and the construction
  documented before use.
- **Code rebuild.** Rebuild the FCC CSS code from the published spec
  (arXiv:2603.20294): qubits on edges, weight-12 checks, tetrahedral
  logical structure. Verify [[192,130,3]] parameters at Ls=4 before
  any dynamics is defined on it.

## 3. The computation (fixed procedure)

**Step 1 - the doublet with environments.** Construct a minimal
two-layer patch: a defect site with its lower-sheet (committed) and
upper-sheet (pending) connections. Committed = the relevant stabilizers
projected to their eigenstates. Pending = the same structure, checks
not yet applied (maximally mixed over the check outcomes, or the
pre-measurement state the code's growth rule specifies - whichever the
MEI/CSS papers define; record which).

**Step 2 - the matrix elements.** Compute the interlayer hop matrix
elements in both directions:
    M_down = amplitude for the defect to move via the committed sheet,
    M_up   = amplitude for the defect to move via the pending sheet,
with identical geometry, differing only in environment state.

**Step 3 - the induced generator.** From (M_up, M_down), assemble the
induced 2x2 generator on the orientation doublet. Decompose into
identity, sigma_x, sigma_y, sigma_z components.

**Step 4 - the verdict.** Read the result against Section 4's
pre-registered outcomes. No reinterpretation.

**Competitor dynamics (must be run alongside, same session):**
- C1: both environments committed (static crystal) - expect vector
  su(2), no projection (this is the published static obstruction; it
  is the control).
- C2: both environments pending - expect vector su(2) (second control).
- C3: environments swapped (committed above, pending below) - expect
  the OPPOSITE projection if H holds. This tests that the sign comes
  from the front, not from the construction.

## 4. Pre-registered outcomes

- **Outcome A (H confirmed):** |M_down| = 0 exactly, or suppressed by
  a factor that scales with code distance, with C1/C2 showing no
  asymmetry and C3 showing the reversed sign. Then P_L is derived,
  the sign is the front sign, and the result paper may be drafted.
- **Outcome B (H refuted):** |M_up| = |M_down| within numerical
  precision in the physical configuration. Then the framework fails
  to produce the chiral projection by this mechanism. This result is
  PUBLISHED as a derived negative (the series' standing practice),
  and the electroweak program within the framework is downgraded
  accordingly. No alternative mechanism may be invented in the same
  session.
- **Outcome C (partial):** suppression that is real but neither exact
  nor distance-scaling (e.g., a fixed finite ratio, or a
  Ginsparg-Wilson-like modified relation instead of a clean
  projector). Then the partial structure is characterized and
  published as such. No rounding up to Outcome A.

## 5. Discipline rules (binding)

1. The computation derives existence, form, AND sign. If the sign has
   to be inserted by hand at any step, the step fails.
2. No parameter may be tuned after seeing results. The environments,
   the hop, and the patch size are fixed by the MEI/CSS definitions
   before Step 2 runs.
3. All three competitors C1-C3 run in the same session, results
   reported regardless of outcome.
4. If three sessions end at "almost," stop and publish the almost.
5. The words used in any resulting paper: Outcome A is "derived";
   Outcome C is "obtained in modified form"; Outcome B is "excluded by
   computation." No synonym inflation.
6. E7/E8 remain fenced regardless of outcome.

## 6. What this protocol is for

Every prior gap in the series fell to counting and symmetry. This one
is dynamical, the target is known and beloved, and that is the exact
condition under which the April failure mode operates. This document
exists so that the computation, when it runs, is judged by criteria
its authors could not adjust. If H survives this protocol, it will
deserve the claim. If it does not, the series keeps the thing it
actually trades on: results that were allowed to fail.

---

## Amendment 1 (August 30, 2026 - before any computation has run)

Prerequisite 1 is corrected. The primary upload for the P_L
computation is the **Matter paper** (Phys. Open 27, 100423), not MEI:
it defines the Stitch and Lift operators, the oriented Lift's
orientation selection, the growth dynamics that constitute the
creation-front hypothesis, and the extra-node defect. The interlayer
hop must be constructed from the Lift as defined there (falling back
to the stabilizer-structure contingency only if the Lift does not
determine it). The **MEI paper** (Phys. Open 100414) is requested in
the same session for the adjacent clauses: the defect/charge table
(which also clears the merged paper's [imported] tag and the Paper 6
interstitial battery). The **V1a/V1b/V1c postulates** require no
upload: they are published in Quantum Rep. 8(3), 78 (2026) and their
content is on record. No other clause of this protocol is changed.

---

## Amendment 2 - Hypothesis H3 registered (August 30, 2026, before any
## computation toward it has run)

**H3 (Witten-effect origin of the integer unit).** The chiral,
parity-violating worldline (winding W = +/-1, derived) induces a
topological theta-term on the compact U(1) of the <100> gauge network
(the square-face EM channels); by the Witten effect, the monopole
sector then shifts the electric charge of matter defects. If the
induced theta/2pi is an integer, a strict +/-1 injects, lifting the
geometric -1/3 to the up-type +2/3. Mechanism class: gauge-sector
topology - distinct from, and untouched by, the two prior exclusions
(symmetric Cartan charges; circuit Berry phases). Anchors: Witten
1979; Polyakov compact-U(1) monopoles; Callan-Harvey inflow for a 1D
winding sourcing a bulk term. Structural rhyme, flagged not claimed:
the Matter paper's ladder q = -1/3 + w has the shape of a Witten
dyon tower, with w a candidate monopole linking number.

**Prerequisites (constructions, in order, before the calculation):**
(P1) build the compact U(1) on the <100> node-void cubic sublattice
in code terms (the parked photon program, hereby promoted);
(P2) identify its monopole defects as code objects; (P3) define the
matter worldline's coupling to the gauge links.

**Pre-specified calculation:** compute the theta induced by the
W = +1 worldline via anomaly-inflow bookkeeping on the constructed
network. No parameter may be tuned toward any target value.

**Pre-registered outcomes:**
- A: theta/2pi integer and nonzero => integer unit derived via
  Witten; the w-tower identification is then tested against the
  Matter paper's baryon spectrum.
- B: theta/2pi = +/-1/3 (mod 1) => Witten sources the THIRDS; this
  COLLIDES with the geometric thirds derivation and a consistency
  resolution is mandatory before any claim; the collision itself
  publishes.
- C: theta unquantized or dependent on construction choices => H3
  excluded by computation; publishes beside H2's exclusion.
Controls: theta must vanish when W = 0 (static crystal) and flip
sign with W (inverted frontier); failure of either control voids
any positive outcome.

**Vocabulary:** A = "derived"; B = "obtained with a collision,
unresolved"; C = "excluded by computation." No synonym inflation.

---

## Amendment 3 - Hypothesis H4 registered (August 30, 2026, before any
## computation toward it has run)

**H4 (the electroweak bosons as square-sector code fluctuations).**
The W+-, Z, and photon are the four square-plaquette fluctuation
modes of the K=12 shell (MEI Sec. 9.2 count), living on the <100>
grid of Amendment 2. W+- ARE the directed interlayer hops of the
chirality paper (a sigma+ + b sigma-, a != b), which already pump
+-1 unit of the derived U(1) charge; Z is the orientation-diagonal
generator their commutator produces; the photon is the compact-U(1)
link phase. Named, not claimed: the committed/pending distinction as
the symmetry-breaking order parameter (the front as condensate).

**Ordered computations - (i) and (ii) MUST complete and pass before
(iii) or (iv) is opened:**
(i) CLOSURE, target-free: the commutator algebra of the up- and
    down-hop operators on doublet x link space. PASS iff it closes
    as su(2) + u(1) with the Amendment-2 phase as the u(1).
(ii) CHARGES: W+- carry +-1 under the derived U(1); Z and photon
    carry 0. Strict PASS/FAIL.
(iii) NEUTRAL MIXING: the geometric recombination angle of the two
    neutral generators into a massless and a massive mode. Reported
    as computed; NO comparison with sin^2(theta_W) until the value is
    frozen in the record.
(iv) MASSES: W and Z as verification costs of square-plaquette
    fluctuations (MEI mass formula), computed blind as integer
    counts; comparison with m_W/m_e and m_Z/m_e only after freezing.

**Controls:** (i)-(ii) must hold with the static-crystal amplitudes
(a = b) as well - the ALGEBRA must not depend on the front; only the
coupling asymmetry may. Any construction in which the algebra closes
only for a != b is rejected as steering.

**Outcomes/vocabulary:** A "derived" (i and ii pass; iii and iv
reported whatever they give); B "obtained in modified form" (closure
into a larger or different algebra - reported as such); C "excluded
by computation." Numerical agreement in (iii)/(iv) never upgrades a
verdict; disagreement never downgrades (i)/(ii).

**Prerequisites:** Amendment-2 P2 (monopoles as code objects) and a
declared operator formalism for square-plaquette fluctuations,
written before (i) runs.

---

## Amendment 4 - P2 construction registered (August 31, 2026, before it runs)

**P2 (monopoles as code objects).** The photon grid is the simple
cubic lattice of FCC nodes plus octahedral voids (Amendment 2). Its
compact U(1) carries monopoles by the DeGrand-Toussaint construction:
the integer flux mismatch through the six faces of an elementary
cube. The construction is judged on three facts, fixed now:
 (a) the elementary cubes' centers coincide EXACTLY with the FCC
     tetrahedral-void centroids, each cube having 4 node corners and
     4 void corners;
 (b) the two parity classes of cube centers coincide with the two
     tetrahedral-void ORIENTATIONS (up/down);
 (c) the DeGrand-Toussaint monopole number is an integer on every
     cube and its current is conserved (divergence-free) on this
     grid, for arbitrary link configurations.
PASS on all three => monopoles are code-localized objects: their
cells are the tetrahedral voids, the sites that carry the code's
logical qubits and the trapped matter node. FAIL on any => the
construction is refuted as stated and the unit derivation's
prerequisite is not met.
**Recorded, not claimed (to be tested later):** if (a)-(c) pass, the
flux linking number n of the Witten shift is conjectured to be the
monopole number of the defect's OWN cell, making the quark a
node-plus-monopole in one tetrahedral void. This identification is
a hypothesis until a computation ties the ring-threading flux of
Amendment 2 to a cell monopole number.
**What remains declared even on PASS:** the link phases as functions
of the code's qubits. This construction fixes where monopoles live
and that they are well-defined; it does not derive the U(1) from the
stabilizers.

---

## Amendment 5 - the gate opened (August 31, 2026, before the runs)

**(iii) declared formalism.** The neutral sector breaks by a
condensate v in some doublet of the derived algebra; the photon is
the generator annihilating v. NO condensate is chosen here. The
computation is the choice-free constraint: for which hypercharge Y
does the doublet possess a member with Q = T3 + Y = 0, so that a
massless photon can exist? The angle itself is NOT computed unless
that doublet is derived, which it is not in the present record.

**(iv) declared formalism.** The W and Z are square-plaquette
fluctuations; their mass is the verification cost of the MEI paper,
C = E_s x C_s, counted on the actual code for a square plaquette
(E_s = its edges; C_s = the vertex and octahedral checks that detect
it). The count is frozen in the record before any comparison with
m_W/m_e = 157,300 or m_Z/m_e = 178,400. A miss is a result.

---

## Amendment 6 - Hypothesis H5 registered (August 31, 2026, before it runs)

**H5 (the lepton doublet from the single-bond defect).** The Matter
paper's projection rule assigns charge as the projection of a
defect's bonds onto its anchor axis (valence bonds: -1/3 each; the
anchor onto itself: +1). The lepton is the single-bond defect of the
MEI paper (E_s = 1, no valence partners). H5: its baseline charge is
the self-projection of its one bond, +-1, signed by the void
orientation exactly as the quark baseline is - a stated EXTENSION of
the published rule with no free parameter. On the derived operator
formalism (void x sheet x rotor; hops pumping one unit; T3 = +-1/2)
the lepton doublet's quantum numbers then follow with no further
input.

**Pre-registered outcomes:** A - Y constant on the doublet and equal
to +-1/2 with a neutral member (the gate's requirement met): DERIVED.
B - Y constant but not +-1/2: OBTAINED IN MODIFIED FORM, gate unmet.
C - Y not constant, or su(2)-invariance fails: EXCLUDED BY
COMPUTATION. Controls: the C-conjugate doublet must carry -Y on both
members; Y must commute with W+-, T3; the quark result must be
reproduced unchanged by the same code.
**Not in scope even on A:** the mixing angle (needs the coupling
normalization) and the family count (the E6 nine-state block is
noted, not used).

---

## Amendment 7 - H6 and H7 registered (August 31, 2026, before either runs)

**H6 (link phases from the qubits).** A node-void link of the photon
grid joins a vertex Z-check and an octahedral X-check that share
exactly four edge qubits. H6: the compact U(1) link phase is an
operator-valued function of those four qubits, and it is DERIVED,
not declared, by the requirement of gauge covariance under the code's
own checks. Test: (a) construct the candidate phase; (b) verify it
transforms covariantly under the vertex and octahedral checks at its
endpoints; (c) verify the induced plaquette phases reproduce the
DeGrand-Toussaint monopoles of Amendment 4 on the tetrahedral cells;
(d) read off the coupling normalizations of the u(1) and su(2)
sectors from the phase moved per qubit operation. Outcomes: A -
covariant phase exists and (c) holds => derived; the ratio g'/g is
then computed, FROZEN, and only afterward compared with
sin^2(theta_W). B - a covariant phase exists but (c) fails => obtained
in modified form; no angle. C - no covariant construction => excluded
by computation. Recorded test, not claimed: monopole number =
logical-qubit eigenvalue of the cell.

**H7 (the condensate scale).** The Y = 1/2 sector's scale is
extensive - set by the front over a region - since local counts are
excluded (Amendment 5). BINDING RULE: the scale must be fixed by a
quantity already derived or measured in the series (the verification
depth n, the simulation's finite-size exponent, the code distance)
with NO free size parameter. Any construction requiring one is
recorded as a fit and may not be called a derivation. m_W and m_Z
are compared only after the frozen scale and the frozen couplings of
H6 are in the record. H7 may not be opened before H6 returns A or B.

---

## Amendment 8 - the synthetic-geometry protocol registered
## (September 2026)

**Question.** Can an engineered correlation act as an SSM spacetime
stitch? Three graphs are separated (embedding, correlation,
interaction); Theorem 1 of the synthetic-geometry paper proves
pre-shared entanglement plus local operations plus unconditioned
stabilizer correction transmits nothing.

**Registered experimental protocol (paper Sec. 9).** Matched
endpoints at separations L_j; randomized trials (ordinary
entanglement vs. proposed stitch activation); spacelike-separated
random setting choice at A; time-tagged informationally complete
record at B with no setting information; D_{A->B}(t) estimated only
after both records complete; delta, windows, and multiple-testing
correction pre-registered; all cross-talk channels bounded; distance
scaling tested.

**Outcomes, fixed now.** NULL (ordinary resources): no early
response - the standard-QM prediction, and the series' own via the
un-hosted-lattice reading (J L <= hbar c; every hosted lattice
below c). POSITIVE: distance-independent early onset set by hbar/g
with closed accounting - would constitute a new interaction sector,
judged only against criteria (S1)-(S5) of the paper, and would
require reconciliation with relativistic QFT.

**Derivation target registered, not claimed:** c as the commit
speed of the un-hosted lattice; the natural FCC saturating
J L = hbar c natively.

**Amendment 8 addition - the affirmative conjecture named.** The
positive branch is stated in the framework's voice: expanding
entanglement into the full polycrystalline FCC machinery (code,
checks, front) superimposed on real spacetime is conjectured to
constitute an adjacency transition that would signal ahead of the
background cone. Registered, not claimed; standard QM predicts the
null; the Section-9 protocol decides.

**Amendment 8 correction (dated).** The phrase "coupling-length
exchange rate J L <= hbar c" is withdrawn as a purported universal
law: coupling strength and retardation are separate quantities. The
correct general statement is retardation itself: hosted couplings
have D(t)=0 before L/c, so engineered lattices inherit the substrate
cone. The natural lattice's internal velocity is a derivation target
from its microscopic update rule and interaction spectrum.

---

## Amendment 9 - H8 registered (September 2026, before any data contact)

**H8 (grain-domain spin alignment).** The vacuum is polycrystalline;
each grain has a stacking/growth axis (a <111> direction). H8: if
galaxy angular momenta inherit any lattice orientation, the
signature is PATCHWISE - alignment correlated within a grain and
decorrelating across grain boundaries - not an all-sky dipole. NO
mechanism from electroweak front chirality to galactic angular
momentum is claimed; this is a geometric-inheritance hypothesis, and
the standard-cosmology NULL (tidal-torque isotropy) is the expected
outcome.

**Computable now (this session):** the signature only - the
two-point alignment correlation C(theta) of a domain sky, its
angular power spectrum, and the residual dipole of a finite grain
count - so the prediction is quantitative and distinguishable from
(a) isotropy and (b) a true dipole, before any survey is examined.

**Pre-registered outcomes for any future data test:** A - alignment
correlation with a finite decorrelation angle and domain-like power
spectrum, residual dipole consistent with 1/sqrt(N_grains):
supported. B - pure dipole or other global pattern: H8 NOT
supported (that is a different hypothesis, not this one). C - 
isotropy within sensitivity: null; H8 unsupported and standard
cosmology stands, as expected. Controls: annotation/handedness
systematics must be bounded first (the known failure mode of
published spin-dipole claims); analysis choices frozen before
unblinding.
