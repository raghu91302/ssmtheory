Verification scripts for:
  "Domain Anisotropy versus Global Dipoles: A Discriminant for
   Galaxy-Spin Alignment Claims from a Polycrystalline Vacuum"
  (R. Kulkarni, 2026)

Contents:
  verify_spin_alignment.py   reproduces (12 labeled checks): the
                             isotropic control (<P2>=0, Var=1/5); the
                             factorization C = A P_same on simulated
                             domain skies at A=1 (two sizes) and at
                             partial inheritance q=0.4 (A=q^2); the
                             amplitude-free normalized shape; the
                             decorrelation-tracks-grain-scale result;
                             the 1/sqrt(N) residual dipole (two
                             sizes); the multipole separation of the
                             four hypotheses; the idealized-sensitivity closure
  PL_protocol.md             the series pre-registration including
                             Amendment 9
  PL_extraction.md           the series execution record

No observational data are used or included.
Requirements: Python 3 with numpy.
Run:          python3 verify_spin_alignment.py
Expected:     12x PASS, then ALL PASS. Runtime: ~1 minute.
