#!/usr/bin/env python3
"""Figure 3: (a) predicted solar splitting against the Hubble constant; (b) every choice tried."""
import numpy as np, matplotlib, matplotlib.ticker
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.optimize import brentq
plt.rcParams.update({"font.size": 9, "font.family": "serif", "mathtext.fontset": "dejavuserif"})
BLUE, RED, GOLD, GREY = "#2c5f9e", "#c14844", "#b7791f", "#8796ad"
D31, sD31, omh2 = 2.521e-3, 0.020e-3, 0.1430
Mp = 2.435e18; H100 = 100e3/3.0857e22*6.582e-25
u = lambda d: np.sort((1+np.cos(d+2*np.pi*np.arange(3)/3))**2)
eL = lambda h: ((h*h-omh2)*3*H100**2*Mp**2)**0.25*1e9
def pred(d31, rho14):
    m1t = rho14/(2*np.sqrt(2))
    g = lambda dd: (lambda x: x[0]/np.sqrt(x[2]**2-x[0]**2))(u(dd)) - m1t/np.sqrt(d31)
    dd = brentq(g, 0.2, np.pi/3-1e-7); x = u(dd); a = np.sqrt(d31/(x[2]**2-x[0]**2)); m = a*x
    return (m[1]**2-m[0]**2)*1e5
hs = np.linspace(0.64, 0.76, 61)
c = np.array([pred(D31, eL(h)) for h in hs])
lo = np.array([pred(D31-sD31, eL(h)) for h in hs]); hi = np.array([pred(D31+sD31, eL(h)) for h in hs])
fig, (a, b) = plt.subplots(1, 2, figsize=(7.0, 4.0))
a.fill_between(hs*100, np.minimum(lo, hi), np.maximum(lo, hi), color=BLUE, alpha=0.25, lw=0)
a.plot(hs*100, c, color=BLUE, lw=1.5, label=r"predicted, $\rho_\Lambda = 64\,m_1^4$")
a.axhspan(7.530-0.097, 7.530+0.097, color=GREY, alpha=0.35, lw=0, label="measured (global fit with JUNO)")
a.axhspan(7.530-0.024, 7.530+0.024, color=GREY, alpha=0.7, lw=0, label="JUNO 6-year precision (illustrative)")
for h, lab, col in [(0.6736, "Planck", GOLD), (0.730, "SH0ES", RED)]:
    a.axvline(h*100, color=col, ls="--", lw=0.9); a.text(h*100+0.3, 7.82, lab, color=col, fontsize=7.5)
a.set_xlabel(r"$H_0$ (km s$^{-1}$ Mpc$^{-1}$)"); a.set_ylabel(r"$\Delta m^2_{21}$ ($10^{-5}$ eV$^2$)")
a.set_ylim(6.9, 7.95); a.legend(fontsize=6.3, frameon=True, framealpha=0.9, edgecolor="none", loc="lower left")
a.set_title(r"(a) the solar splitting predicted from $\rho_\Lambda$", fontsize=9)
trials = [("corner bonds, Euclidean step (Eq. 12)", 64, True), ("frame bonds, Euclidean step", 8, True),
          ("all 24 D4 bonds, Euclidean step", 216, True), ("FCC tick, cell time extent", 90.51, True),
          ("FCC tick, cell mean extent", 45.25, True), ("FCC tick, one tick", 256, True),
          ("null steps, cell time extent", 32, True), ("null steps, cell mean extent", 16, True),
          ("null steps, one tick per cell", 64, True),
          ("octahedron volume", 135.76, False), ("tetrahedron volume / bond", 543.06, False),
          ("conventional FCC cube", 22.63, False), (r"$\langle100\rangle$ cell, FCC tick", 181.0, False),
          (r"$\langle100\rangle$ network, own tick", 8.0, False), ("D4 null spacing, own tick", 1.0, False)]
m1 = 0.7938
y = np.arange(len(trials))[::-1]
vals = [k**0.25*m1 for _, k, _ in trials]
cols = [(RED if k == 64 else BLUE) if live else "0.6" for _, k, live in trials]
b.axvspan(2.239-0.013, 2.239+0.013, color=GOLD, alpha=0.5, lw=0, label=r"Planck $\rho_\Lambda^{1/4}$")
b.scatter(vals, y, color=cols, s=18, zorder=3)
b.axhline(y[8]-0.5, color="0.75", lw=0.6)
b.set_yticks(y); b.set_yticklabels([t for t, _, _ in trials], fontsize=6.8)
for lab, (_, _, live) in zip(b.get_yticklabels(), trials):
    if not live: lab.set_color("0.45")
b.set_xscale("log"); b.set_xlim(0.6, 5); b.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); b.set_xticks([0.8, 1, 1.5, 2, 3, 4]); b.set_xticklabels(["0.8", "1", "1.5", "2", "3", "4"])
b.set_xlabel(r"$\rho_\Lambda^{1/4}$ implied (meV)")
b.set_title("(b) every choice tried", fontsize=9)
fig.tight_layout(); fig.savefig("fig_nde.pdf", bbox_inches="tight"); fig.savefig("fig_nde.png", dpi=160, bbox_inches="tight")
print("ok")
