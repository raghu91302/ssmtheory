#!/usr/bin/env python3
"""Consistency rule for impedance matching across the two geometries, and the proton check.
(1) A spatial defect uses the densest-lattice bond rule, alpha_s = K_D / D (FCC: 12/3).
    The time-only worldline uses the hypercube corner channel, alpha_t = 2^(D+1)/(D+1) (16/4).
    Matching both to one vacuum needs one bond quantum hbar c/(alpha L) in both: alpha_s = alpha_t.
    Kissing numbers: exact for D = 1,2,3,4,8,24; for D = 5,6,7 the best known value and the upper bound.
(2) The proton's cell, L_c = 4 hbar/(m_p c), and the matching against the QCD vacuum.
(3) Matching (equal energies) versus pressure balance (bag model) for the neutrino."""
import numpy as np
K = {1:(2,2), 2:(6,6), 3:(12,12), 4:(24,24), 5:(40,44), 6:(72,78), 7:(126,134), 8:(240,240), 24:(196560,196560)}
print("D   K_D/D (best known; upper bound)   2^(D+1)/(D+1)   equal?")
for D,(k,kup) in K.items():
    a_s, a_su, a_t = k/D, kup/D, 2**(D+1)/(D+1)
    print(f"{D:2d}   {a_s:9.3f} ; {a_su:9.3f}          {a_t:12.3f}     {'yes' if abs(a_s-a_t)<1e-12 else 'no'}")
hbarc = 197.3269804  # MeV fm
mp, me = 938.27208816, 0.51099895
Lc = 4*hbarc/mp
print(f"\nproton cell L_c = 4 hbar/(m_p c) = {Lc:.4f} fm (CODATA r_p = 0.84075(64) fm)")
print(f"16 bond quanta at L_c: 16*hbar c/(4 L_c) = {16*hbarc/(4*Lc):.3f} MeV = m_p")
print(f"alpha^-1 = pi sqrt(m_p/m_e) = {np.pi*np.sqrt(mp/me):.2f}  (preprint; running value 135.5 +/- 0.3)")
r_mass = mp/Lc**3*hbarc**3          # MeV^4: rho = m_p / L_c^3 (Z^2 = N = 16)
r_bond = (mp/16)/Lc**3*hbarc**3     # one bond quantum per cell (Z_vac^2 = 1)
print(f"QCD vacuum implied: Z^2 = N = 16 (mass per cell): rho^1/4 = {r_mass**0.25:.0f} MeV")
print(f"                    one bond quantum per cell:    rho^1/4 = {r_bond**0.25:.0f} MeV")
for name,G2 in [("SVZ <(as/pi)G^2> = 0.012 GeV^4",0.012),("<(as/pi)G^2> = 0.02 GeV^4",0.02)]:
    eps = 9/32*G2*1e12   # MeV^4, |eps_vac| = (b/32)<(as/pi)G^2>, b = 9 for three flavors
    print(f"  gluon condensate, {name}: |eps|^1/4 = {eps**0.25:.0f} MeV")
print("  MIT bag constant: B^1/4 = 145-235 MeV")
# (3) neutrino: equal energies vs pressure balance
m1, s1 = 0.794e-3, 0.013e-3
coef_meas, coef_err = 63.3, 4.4
for name,c in [("matching, equal energies per cell",64.0),("pressure balance (bag), vacuum = 1/3 of confinement",64/3)]:
    print(f"\n{name}: coefficient {c:.1f}, rho^1/4 = {c**0.25*m1*1e3:.3f} meV, pull {(c-coef_meas)/coef_err:+.1f} sigma")

# (4) Lorentzian ordering of the proton's quanta (bond rule I1: one quantum per bond per tick).
import itertools
nodes = range(5)          # complete graph K5: trapped node 0 + four corners of the tetrahedral void
walks = [(0,a,b) for a in nodes if a!=0 for b in nodes if b!=a]
first = {}
for w in walks: first.setdefault(frozenset(w[:2]),[]).append(w)
print(f"\nK5: {len(walks)} two-step walks from the trapped node; first steps use {len(first)} bonds, "
      f"{sorted(len(v) for v in first.values())} walks each")
inflight = len(first)     # at most one quantum per bond per tick
ticks = len(walks)//inflight
r_lor = (mp*inflight/16)/Lc**3*hbarc**3
print(f"at most {inflight} quanta in transit per tick; 16 delivered over {ticks} ticks")
print(f"cell holds {inflight} of 16 quanta: rho_QCD^1/4 = (m_p/4) = {r_lor**0.25:.1f} MeV  (m_p/4 = {mp/4:.1f})")
