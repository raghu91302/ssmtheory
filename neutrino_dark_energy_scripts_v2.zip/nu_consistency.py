#!/usr/bin/env python3
"""Consistency rule for impedance matching across three geometries (Section 4.8, Eqs. (13)-(14), Table 2), and the proton check.
(1) Each cell carries its factor internally.  The proton's tetrahedral void: 12 directed edges,
    second moment (12/3) 1.  The time-only worldline: 16 hypercube corner bonds, (16/4) 1.
    In D space dimensions the simplex gives (D+1)D/D = D+1 and the (D+1)-hypercube gives 2^(D+1)/(D+1);
    vacuum, simplex and hypercube must agree: K_D/D = D+1 = 2^(D+1)/(D+1); the second equality is
    n^2 = 2^n with n = D+1: n = 2, 4 only.  The vacuum count K_D/D (kissing numbers exact for D = 1,2,3,4,8,24;
    best known value and upper bound for D = 5,6,7).
(2) The proton's cell, L_c = 4 hbar/(m_p c), and the matching against the QCD vacuum.
(3) Matching (equal energies) versus pressure balance (bag model) for the neutrino."""
import numpy as np
T = np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]], float)
import itertools
Ev = {tuple(int(x) for x in (T[j]-T[i])/2) for i in range(4) for j in range(4) if i != j}
Fv = {r for r in itertools.product([-1,0,1], repeat=3) if sum(map(abs,r)) == 2}
print(f"tetrahedron edge vectors = FCC bond vectors (A3 roots): {Ev == Fv} ({len(Ev)} vectors)")
Ed = np.array([(T[j]-T[i])/np.linalg.norm(T[j]-T[i]) for i in range(4) for j in range(4) if i != j])
Sp = np.array([t/np.linalg.norm(t) for t in T])
print(f"proton cell: {len(Ed)} directed tetrahedron edges, second moment {np.round(Ed.T@Ed,6)[0,0]} x 1 (isotropic: "
      f"{np.allclose(Ed.T@Ed, 4*np.eye(3))}); four spokes alone: {np.round(Sp.T@Sp,4)[0,0]} x 1")
print("n^2 = 2^n for n = 1..20:", [n for n in range(1,21) if n*n == 2**n], "-> D = n-1 =", [n-1 for n in range(1,21) if n*n == 2**n])
print("D   vacuum K_D/D (best; upper)   simplex D+1   hypercube 2^(D+1)/(D+1)")
K = {1:(2,2), 2:(6,6), 3:(12,12), 4:(24,24), 5:(40,44), 6:(72,78), 7:(126,134), 8:(240,240), 24:(196560,196560)}
for D,(k,kup) in K.items():
    a_s, a_su, a_t = k/D, kup/D, 2**(D+1)/(D+1)
    print(f"{D:2d}   {a_s:9.3f} ; {a_su:9.3f}        {D+1:9d}   {a_t:13.3f}   {'all equal' if abs(a_s-(D+1))<1e-12 and abs(D+1-a_t)<1e-12 else ''}")
hbarc = 197.3269804  # MeV fm
mp, me = 938.27208816, 0.51099895
Lc = 4*hbarc/mp
print(f"\nproton cell L_c = 4 hbar/(m_p c) = {Lc:.4f} fm (CODATA r_p = 0.84075(64) fm)")
print(f"16 bond quanta at L_c: 16*hbar c/(4 L_c) = {16*hbarc/(4*Lc):.3f} MeV = m_p")
r_mass = mp/Lc**3*hbarc**3          # MeV^4: rho = m_p / L_c^3 (Z^2 = N = 16)
r_bond = (mp/16)/Lc**3*hbarc**3     # one bond quantum per cell (Z_vac^2 = 1)
print(f"QCD vacuum implied: Z^2 = N = 16 (mass per cell): rho^1/4 = {r_mass**0.25:.0f} MeV")
print(f"                    one bond quantum per cell:    rho^1/4 = {r_bond**0.25:.0f} MeV")
for name,G2 in [("SVZ <(as/pi)G^2> = 0.012 GeV^4",0.012),("<(as/pi)G^2> = 0.02 GeV^4",0.02)]:
    eps = 9/32*G2*1e12   # MeV^4, |eps_vac| = (b/32)<(as/pi)G^2>, b = 9 for three flavors
    print(f"  gluon condensate, {name}: |eps|^1/4 = {eps**0.25:.0f} MeV")
print("  MIT bag constant: B^1/4 = 145-235 MeV")
# (3) neutrino: equal energies vs pressure balance
m1, s1 = 0.7938e-3, 0.013e-3
coef_meas, coef_err = 2.821**4, 4*0.048*2.821**3
for name,c in [("matching, equal energies per cell",64.0),("pressure balance (bag), vacuum = 1/3 of confinement",64/3)]:
    print(f"\n{name}: coefficient {c:.1f}, rho^1/4 = {c**0.25*m1*1e3:.3f} meV, pull {(c-coef_meas)/coef_err:+.1f} sigma")

# (4) Lorentzian ordering of the proton's quanta (bond rule I1: one quantum per bond per tick).
nodes = range(5)          # complete graph K5: trapped node 0 + four corners of the tetrahedral void
walks = [(0,a,b) for a in nodes if a!=0 for b in nodes if b!=a]
first = {}
for w in walks: first.setdefault(frozenset(w[:2]),[]).append(w)
print(f"\nK5: {len(walks)} two-step walks from the trapped node; first steps use {len(first)} bonds, "
      f"{sorted(len(v) for v in first.values())} walks each")
inflight = len(first)     # at most one quantum per bond per tick
ticks = len(walks)//inflight
r_lor = (mp*inflight/16)/Lc**3*hbarc**3
print(f"at most {inflight} quanta in transit per tick; 16 delivered over {ticks} ticks")
print(f"cell holds {inflight} of 16 quanta: rho_QCD^1/4 = (m_p/4) = {r_lor**0.25:.1f} MeV  (m_p/4 = {mp/4:.1f})")

# (5) A cube cell for a spatial defect: K/d = 6/3 = 2.
print(f"\ncube cell: by edge direction K/d = 2 -> L = 8 hbar/(m_p c) = {8*hbarc/mp:.3f} fm; by directed edges (24/3 = 8) "
      f"-> L = 2 hbar/(m_p c) = {2*hbarc/mp:.3f} fm; tetrahedron {4*hbarc/mp:.4f} fm; measured 0.84075 fm")
print("cube in D dims: by direction 2, by directed edges 2^D; either equals 2^(D+1)/(D+1) only for D = 1:",
      [D for D in range(1,12) if 2 == 2**(D+1)/(D+1)], [D for D in range(1,12) if 2**D == 2**(D+1)/(D+1)])

# (6) Mass counts all 16 paths; stiffness uses the 12 edge paths (lattice bonds) only.
print(f"spoke length / bond length = {np.linalg.norm(T[0])/np.linalg.norm(T[1]-T[0]):.4f} (sqrt(3/8) = {np.sqrt(3/8):.4f}); "
      f"edges + spokes second moment = {(Ed.T@Ed + Sp.T@Sp)[0,0]:.4f} x 1 (16/3)")
