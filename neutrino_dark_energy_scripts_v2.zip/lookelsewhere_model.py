#!/usr/bin/env python3
"""Look-elsewhere for the lattice reading (Section 6).
The relation rho = c * m1^4 is tested through the ratio R = rho^1/4 / m1 = 2.821 +- 0.048; each choice gives
R = c^(1/4).  Null hypothesis: rho and m1 unrelated, with R log-uniform over one decade, [1, 10], since both
scales are known to lie near one meV.
Live alternatives: the family rho = beta alpha^3 m1^4 of Table 1 (8 distinct coefficients).
The equal-time rows of the search (Section 6) assign the neutrino an energy per spatial volume, which premise A
excludes; they are reported for completeness (13 distinct coefficients in all)."""
import numpy as np
R, sR = 2.821, 0.048
live = [64, 8, 216, 90.5, 45.25, 256, 32, 16]
allc = [64, 8, 45.25, 90.5, 135.8, 543, 22.6, 181, 1, 256, 32, 16, 216]
rng = np.random.default_rng(1)
x = np.exp(rng.uniform(0, np.log(10), 400000))
for name, c in (("alpha^3 beta family (live)", live), ("all choices of the search", allc)):
    Rl = np.array(sorted(set(c)))**0.25
    d = np.min(np.abs(np.log(x[:, None]/Rl[None, :])), axis=1)
    print(f"{name:30s}: {len(Rl):2d} coefficients; P(some choice within 1 sigma) = {(d < sR/R).mean():.2f}")
print(f"one fixed coefficient, present precision ({100*sR/R:.1f}%): P = {2*(sR/R)/np.log(10):.3f}")
print(f"one fixed coefficient after JUNO (about 0.7% in R):  P = {2*0.007/np.log(10):.4f}")
