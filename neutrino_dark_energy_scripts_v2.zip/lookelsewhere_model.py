#!/usr/bin/env python3
"""Look-elsewhere restricted to the lattice choices of Table 'trials' (Section 6).
The relation rho = c * m1^4 is tested against the ratio R = rho^1/4 / m1 = 2.821 +- 0.048.
Each lattice choice gives R = c^(1/4).  Null hypothesis: rho and m1 unrelated, so R is log-uniform over a
range; we use one decade around the lattice values, [1, 10], and also the span of the choices themselves."""
import numpy as np
coef = np.array(sorted({64, 8, 45.25, 90.5, 135.8, 543, 22.6, 181, 1, 256, 32, 16, 216}))
Rl = coef**0.25
R, sR = 2.821, 0.048
print(f"{len(coef)} distinct coefficients; ratios {np.round(Rl,3)}")
within = Rl[np.abs(np.log(Rl/R)) < sR/R]
print(f"lattice ratios within 1 sigma of the measured {R}: {np.round(within,4)}")
rng = np.random.default_rng(1)
for lo,hi,name in ((1.0,10.0,"one decade [1,10]"),(Rl.min(),Rl.max(),"span of the choices")):
    x = np.exp(rng.uniform(np.log(lo),np.log(hi),400000))
    d = np.min(np.abs(np.log(x[:,None]/Rl[None,:])),axis=1)
    p1 = (d < sR/R).mean(); p03 = (d < 0.003).mean()
    print(f"null R log-uniform over {name}: P(some choice within 1 sigma = {100*sR/R:.1f}%) = {p1:.2f};"
          f"  within 0.3%: {p03:.3f}")
# a single pre-specified coefficient (no search): probability of a 1-sigma hit
for lo,hi,name in ((1.0,10.0,"one decade"),):
    print(f"one fixed coefficient, null over {name}: P(within 1 sigma) = {2*(sR/R)/np.log(hi/lo):.3f}")
# the same coefficient after JUNO: prediction uncertainty about 0.7% in R (Planck h limited)
print(f"one fixed coefficient after JUNO (about 0.7% in R): P(within 1 sigma) = {2*0.007/np.log(10):.4f}")
