#!/usr/bin/env python3
"""Simple constants near the measured ratio rho_L^1/4 / m1 = 2.821 +- 0.048 (Section 6, 'Constants').
Constants (a/b) s between 1 and 20, with a, b in {1,2,3,4,5,6,8,9,12,16,24} and
s in {1, sqrt2, sqrt3, sqrt6, pi, 1/pi, sqrt(pi)}.  The paper cites the count within 1 sigma."""
import numpy as np
base = [1,2,3,4,5,6,8,9,12,16,24]; S = [1, np.sqrt(2), np.sqrt(3), np.sqrt(6), np.pi, 1/np.pi, np.sqrt(np.pi)]
c = np.array(sorted({round(a/b*s, 9) for a in base for b in base for s in S if 1 < a/b*s < 20}))
R, sR = 2.821, 0.048
band = c[(c > R-sR) & (c < R+sR)]
print(f"{len(c)} constants in (1,20); within 1 sigma of {R}: {len(band)} -> {np.round(band,4)}")
