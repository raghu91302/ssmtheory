"""Section 4.6, operator check: the hypercube walk against the neutrino operators of MEI Extended.
Code (MEI Extended, Sec. 'Where the qubits and stabilizers sit'): qubits on D4 edges of the L=4 torus;
Z-stabilizers at vertices (24 incident edges); X-stabilizers at odd-sum points (24 edges among the 8
surrounding vertices). A Z-string worldline is a logical operator if H_X w = 0 and w is not in rowspan(H_Z).
Triality sets (coordinate pair-of-pairs, coordinate 0 = time): A={01|23}, B={02|13}, C={03|12}."""
import itertools, numpy as np
L=4
V=[v for v in itertools.product(range(L),repeat=4) if sum(v)%2==0]
vid={v:i for i,v in enumerate(V)}
roots=[r for r in itertools.product([-1,0,1],repeat=4) if sum(map(abs,r))==2]
add=lambda a,b: tuple((x+y)%L for x,y in zip(a,b))
E={}; 
for v in V:
    for r in roots:
        w=add(v,r); k=frozenset([v,w])
        if k not in E: E[k]=len(E)
nE=len(E); print("vertices",len(V),"edges",nE)
HZ=np.zeros((len(V),nE),np.uint8)
for k,i in E.items():
    for v in k: HZ[vid[v],i]=1
odd=[p for p in itertools.product(range(L),repeat=4) if sum(p)%2==1]
HX=np.zeros((len(odd),nE),np.uint8)
for j,p in enumerate(odd):
    nb=[add(p,s) for i in range(4) for s in [tuple(int(c) for c in np.eye(4,dtype=int)[i]), tuple(-int(c) for c in np.eye(4,dtype=int)[i])]]
    for a,b in itertools.combinations(nb,2):
        k=frozenset([a,b])
        if k in E: HX[j,E[k]]=1
assert all(HX[j].sum()==24 for j in range(len(odd)))
def rank2(M):
    M=M.copy()%2; r=0; rows,cols=M.shape
    for c in range(cols):
        piv=[i for i in range(r,rows) if M[i,c]]
        if not piv: continue
        M[[r,piv[0]]]=M[[piv[0],r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
        if r==rows: break
    return r
rZ=rank2(HZ); print("rank H_Z",rZ, " CSS check H_X H_Z^T = 0:", not ((HX.astype(int)@HZ.T.astype(int))%2).any())
def walk(steps,start=(0,0,0,0)):
    w=np.zeros(nE,np.uint8); p=start
    for s in steps:
        q=add(p,s); w[E[frozenset([p,q])]]^=1; p=q
    assert p==start, "not closed"
    return w
inspan=lambda w: rank2(np.vstack([HZ,w]))==rZ
def report(name,w):
    c=not (HX.astype(int)@w %2).any(); nsyn=int((HX.astype(int)@w %2).sum())
    print(f"{name:52s} weight {int(w.sum()):2d}  X-syndromes fired {nsyn:2d}  logical operator: {c and not inspan(w)}")
wlA=walk([(1,1,0,0),(1,-1,0,0)]*2); wlB=walk([(1,0,1,0),(1,0,-1,0)]*2); wlC=walk([(1,0,0,1),(1,0,0,-1)]*2)
for n,w in [("wl_A (MEI, own frame-A bonds)",wlA),("wl_B",wlB),("wl_C",wlC)]: report(n,w)
# hypercube walks of frame A: centre->corner steps = bonds of B and C
hyp1=walk([(1,0,1,0),(1,0,-1,0)]*2)
hyp2=walk([(1,0,1,0),(1,0,0,1),(1,0,-1,0),(1,0,0,-1)])
report("frame-A hypercube walk, B-type corner steps",hyp1)
report("frame-A hypercube walk, mixed B/C corner steps",hyp2)
hyp3=walk([(1,0,1,0),(1,0,0,-1),(1,0,-1,0),(1,0,0,1)]); report("mixed B/C corner steps, other order",hyp3)
hyp4=walk([(1,0,1,0),(1,0,-1,0),(1,0,0,1),(1,0,0,-1)]); report("B then C corner steps",hyp4)
def equiv(w1,w2): return inspan((w1^w2))
print()
cls={"A":wlA,"B":wlB,"C":wlC}
for n,w in [("B-type corner walk",hyp1),("mixed B/C corner walk",hyp2)]:
    eq=[k for k,v in cls.items() if equiv(w,v)]
    eq2=[k1+"+"+k2 for k1,k2 in itertools.combinations("ABC",2) if equiv(w,cls[k1]^cls[k2])]
    print(f"{n:24s} equivalent to: {eq or '-'}   to a sum: {eq2 or '-'}")
print("wl_A ~ wl_B ?",equiv(wlA,wlB)," wl_A ~ wl_C ?",equiv(wlA,wlC)," wl_B ~ wl_C ?",equiv(wlB,wlC))
