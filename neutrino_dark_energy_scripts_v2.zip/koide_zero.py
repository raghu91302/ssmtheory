"""Section 2, Eq. (3): the K_nu = 1/2 neutrino masses in the normal ordering."""
import numpy as np
from scipy.optimize import brentq
d21,d31=7.53e-5,2.521e-3   # NuFIT-6.1 inputs (dm31 without SK-atm), normal ordering
u=lambda dl: np.sort((1+np.cos(dl+2*np.pi*np.arange(3)/3))**2)          # m_k / a^2
f=lambda dl: (lambda x:(x[1]**2-x[0]**2)/(x[2]**2-x[0]**2))(u(dl)) - d21/d31
dl=brentq(f,0.2,0.45); x=u(dl); a2=np.sqrt(d31/(x[2]**2-x[0]**2)); m=a2*x
print(f"delta_nu = {dl:.4f}, a^2 = {a2*1e3:.3f} meV, masses = {np.round(m*1e3,3)} meV, sum = {m.sum()*1e3:.2f} meV, K = {m.sum()/np.sqrt(m).sum()**2:.4f}")
eps=np.pi/3-dl
print(f"Koide zero: amplitude 1+cos(theta) vanishes at theta = pi; lightest state sits eps = pi/3 - delta_nu = {eps:.4f} rad from it")
print(f"  m1 = a^2 (1 - cos eps)^2 = {a2*(1-np.cos(eps))**2*1e3:.4f} meV  (small-eps form a^2 eps^4/4 = {a2*eps**4/4*1e3:.4f})")
print(f"  det W / a^3 = prod(1+cos th_k) = {np.prod(1+np.cos(dl+2*np.pi*np.arange(3)/3)):.6f} = (1+cos 3 delta)/4 = {(1+np.cos(3*dl))/4:.6f}")
H100=100e3/3.0857e22*6.582e-25; Mp=2.435e18
eL=((0.6736**2-0.1430)*3*H100**2*Mp**2)**0.25*1e12
print(f"rho_L^1/4 = {eL:.3f} meV")
for name,v in [("m1",m[0]),("a^2 (circle scale)",a2),("(m1 m2 m3)^(1/3)",np.prod(m)**(1/3)),("sqrt(m1 m2)",np.sqrt(m[0]*m[1]))]:
    print(f"  rho_L^1/4 / {name:20s} = {eL/(v*1e3):.4f}")
