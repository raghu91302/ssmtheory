"""Section 6: mass combinations and simple constants near rho_L^1/4 / m1."""
import numpy as np, itertools as it
from scipy.optimize import brentq
rng=np.random.default_rng(0)
def m_from(d21,d31):
    f=lambda x: (x+np.sqrt(x*x+d21)+np.sqrt(x*x+d31))/(np.sqrt(x)+(x*x+d21)**.25+(x*x+d31)**.25)**2-0.5
    m1=brentq(f,1e-8,0.05); return np.array([m1,np.sqrt(m1**2+d21),np.sqrt(m1**2+d31)])
# inputs as in nde_numbers.py: dm21 = 7.530 +- 0.097 e-5 (fit with JUNO), dm31 = 2.521 +- 0.020 e-3 (NuFIT-6.1)
N=4000
d21=rng.normal(7.530e-5,0.097e-5,N); d31=rng.normal(2.521e-3,0.020e-3,N)
M=np.array([m_from(a,b) for a,b in zip(d21,d31)])
# cosmology: flat LCDM, rho_L = (Omega_L h^2) * rho_c100 ; Planck 2018 h=0.6736+-0.0054, Omega_m h^2=0.1430+-0.0011
Mp=2.435e18; H100=100e3/3.0857e22*6.582e-25
def eL(h,omh2): return ((h*h-omh2)*3*H100**2*Mp**2)**0.25*1e12   # meV
h=rng.normal(0.6736,0.0054,N); om=rng.normal(0.1430,0.0011,N)
E=eL(h,om)
R=E/(M[:,0]*1e3)
print(f"m1 = {M[:,0].mean()*1e3:.3f} +- {M[:,0].std()*1e3:.3f} meV ; sum = {M.sum(1).mean()*1e3:.2f} meV")
print(f"rho_L^1/4 (Planck LCDM) = {eL(0.6736,0.1430):.3f} +- {E.std():.3f} meV (central inputs) ; SH0ES h=0.73: {eL(0.73,0.143):.3f} meV")
print(f"R = rho_L^1/4 / m1 = {R.mean():.3f} +- {R.std():.3f}   (2 sqrt2 = {2*np.sqrt(2):.4f}); with h=0.73: {eL(0.73,0.143)/(M[:,0].mean()*1e3):.3f}")
# look-elsewhere: simple constants a^p * b^q ... from small integers, sqrt2, sqrt3, pi
base=[1,2,3,4,5,6,8,9,12,16,24]
cands=set()
for a in base:
    for b in base:
        for s in [1, np.sqrt(2), np.sqrt(3), np.pi, 1/np.pi, np.sqrt(np.pi), np.sqrt(6)]:
            v=a/b*s
            if 1<v<20: cands.add(round(v,6))
cands=np.array(sorted(cands))
lo,hi=R.mean()-R.std(),R.mean()+R.std()
hits=cands[(cands>lo)&(cands<hi)]
print(f"simple constants in [{lo:.3f},{hi:.3f}] (1 sigma): {len(hits)} of {len(cands)}: {hits}")
# also other mass combinations vs rho_L^1/4: for each target mass scale, nearest simple constant & rel. distance
m=M.mean(0)*1e3
targets={'m1':m[0],'m2':m[1],'m3':m[2],'sum':m.sum(),'geo(m1m2m3)':np.prod(m)**(1/3),'sqrt(m1m2)':np.sqrt(m[0]*m[1]),'sqrt(m1m3)':np.sqrt(m[0]*m[2]),'sqrt(m2m3)':np.sqrt(m[1]*m[2]),'Koide mu':(np.sqrt(m).sum()/3)**2}
Em=E.mean()
print("\nratio rho_L^1/4 / X (ratio of sample means) and nearest simple constant:")
for k,v in targets.items():
    r=Em/v; c=cands[np.argmin(abs(np.log(cands/r)))] if r>1 else 1/cands[np.argmin(abs(np.log(cands*r)))]
    print(f"  {k:12s} X={v:8.3f}  ratio={r:7.4f}  nearest simple={c:.4f}  off by {100*(r/c-1):+.2f}%")
