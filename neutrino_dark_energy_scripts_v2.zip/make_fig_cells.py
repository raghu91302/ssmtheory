"""Figure 2: the two effective cells of Section 4.8.
(a) The proton's cell: a tetrahedral void of the FCC slice with its trapped node. The six edges are lattice
bonds; taken in both directions they give twelve edge paths with second moment (12/3) 1. The four spokes from
the node are the defect's own bonds, not lattice bonds. (b) The neutrino's cell: the frame tesseract centered on a D4 site, shown in a
two-dimensional projection. The sixteen corner bonds stay inside the cell, with second moment (16/4) 1; the
eight frame bonds, which leave through its faces, are not drawn. Projections are conceptual."""
import itertools, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8, "font.family": "serif", "mathtext.fontset": "dejavuserif"})
BLUE, RED, GOLD, GREY = "#2c5f9e", "#c14844", "#b7791f", "#8796ad"
fig = plt.figure(figsize=(7.0, 3.1))
# (a) proton: tetrahedral void
ax = fig.add_subplot(1, 2, 1, projection="3d")
T = np.array([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], float)
for i, j in itertools.combinations(range(4), 2):
    ax.plot(*zip(T[i], T[j]), color=BLUE, lw=1.8)
    m = (T[i]+T[j])/2; d = (T[j]-T[i])*0.12
    ax.quiver(*(m-d), *(2*d), color=BLUE, arrow_length_ratio=0.45, lw=0.8)
    ax.quiver(*(m+d), *(-2*d), color=BLUE, arrow_length_ratio=0.45, lw=0.8)
for t in T:
    ax.plot(*zip((0, 0, 0), t), color=RED, lw=1.0, ls=(0, (3, 2)))
ax.scatter(*T.T, color=BLUE, s=26, depthshade=False)
ax.scatter([0], [0], [0], color=RED, s=34, depthshade=False)
ax.text2D(0.535, 0.40, "trapped\nnode", color=RED, fontsize=7, transform=ax.transAxes)
ax.view_init(elev=18, azim=28); ax.set_box_aspect((1, 1, 1)); ax.set_axis_off()
ax.set_title("(a) proton: tetrahedral void\n12 edge paths (bonds), $12/3 = 4$; 4 spokes (not lattice bonds)", fontsize=8)
# (b) neutrino: frame tesseract, 2D projection
bx = fig.add_subplot(1, 2, 2)
ang = np.deg2rad([0, 36, 87, 144]); lng = np.array([1, 0.7, 1, 0.7])             # 4D frame axes -> 2D,
Pm = np.array([lng*np.cos(ang), lng*np.sin(ang)])                               # chosen so no two of the 16 rays overlap
C = np.array(list(itertools.product([-0.5, 0.5], repeat=4)))                     # 16 corners, |c| = L
proj = lambda v: Pm @ v
for i, j in itertools.combinations(range(16), 2):
    if np.sum(C[i] != C[j]) == 1:
        p, q = proj(C[i]), proj(C[j]); bx.plot([p[0], q[0]], [p[1], q[1]], color=GREY, lw=0.5, zorder=1)
for c in C:
    p = proj(c); bx.plot([0, p[0]], [0, p[1]], color=BLUE, lw=1.0, zorder=2)
bx.scatter(*np.array([proj(c) for c in C]).T, color=BLUE, s=12, zorder=3)
bx.scatter([0], [0], color="k", s=22, zorder=4)
bx.set_aspect("equal"); bx.set_axis_off()
bx.set_title("(b) neutrino: frame tesseract (projected)\n16 corner bonds inside the cell, $16/4 = 4$", fontsize=8)
fig.tight_layout(); fig.savefig("fig_cells.pdf", bbox_inches="tight"); fig.savefig("fig_cells.png", dpi=160, bbox_inches="tight")
# checks
Tu = np.array([(T[j]-T[i])/np.linalg.norm(T[j]-T[i]) for i in range(4) for j in range(4) if i != j])
Cu = C/np.linalg.norm(C, axis=1)[:, None]
print("edges second moment / 1:", np.round(np.diag(Tu.T@Tu), 6), " corners second moment / 1:", np.round(np.diag(Cu.T@Cu), 6))
