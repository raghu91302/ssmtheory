"""Section 4.6: bond classes of the frame tesseract centered on a D4 site. The neutrino of frame k steps along
the 8 frame bonds (centre to neighboring centre); the 16 corner bonds (the other two frames) are taken as the
vacuum channel inside the cell.
Frame k = 4 mutually orthogonal roots f1..f4 (length L = sqrt2). The tesseract centered on a site has
corners at (+-f1+-f2+-f3+-f4)/2. Check: corners are D4 roots (distance L), and the isotropy factor K/d of
each bond class."""
import itertools, numpy as np
R=[np.array(v) for v in itertools.product([-1,0,1],repeat=4) if sum(abs(x) for x in v)==2]
F=np.array([[1,1,0,0],[1,-1,0,0],[0,0,1,1],[0,0,1,-1]])
corners=[sum(s*f for s,f in zip(sg,F))/2 for sg in itertools.product([1,-1],repeat=4)]
rootset={tuple(r) for r in R}
print("corners:",len(corners)," all D4 roots at distance L:",all(tuple(c.astype(int)) in rootset for c in corners))
frame=[f for f in F]+[-f for f in F]
print("own-frame bonds:",len(frame),"; corner bonds:",len(corners),"; total",len(frame)+len(corners),"= 24")
def kd(vs):
    U=[v/np.linalg.norm(v) for v in vs]; T=sum(np.outer(u,u) for u in U); return T[0,0], np.allclose(T,T[0,0]*np.eye(4))
for name,vs in [("own-frame bonds (tesseract edges directions, leave the cell)",frame),
                ("corner bonds (stay inside the tesseract)",corners),("all 24 D4 bonds",R)]:
    k,iso=kd(vs); coef=k**3
    print(f"{name:60s} K/d = {k:.0f} (isotropic {iso})  -> coef (beta=1) {coef:5.0f}  pull {(coef-2.821**4)/(4*0.048*2.821**3):+6.1f} sigma")
# time content of corner bonds
print("corner bonds with a time component:",sum(1 for c in corners if c[0]!=0),"of 16")
# corners of frame k = vertices of the other two 16-cells
others=[r for r in R if not any(np.array_equal(r,f) for f in frame)]
print("corner bonds == the 16 roots outside frame k:", {tuple(c.astype(int)) for c in corners}=={tuple(r) for r in others})
for n in range(2,7): print(f"n={n}: hypercube corner directions 2^n={2**n}, K/d = {2**n/n:.3f}")
