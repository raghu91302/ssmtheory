#!/usr/bin/env python3
import numpy as np, sys, io, contextlib
from collections import Counter
import layered_growth as lg
cnt=Counter(); third=Counter()
for seed in range(40):
    lg.rng=np.random.default_rng(seed)
    c=lg.Cluster(); c.P=[np.array(p) for p in lg.sheet(4)]; c.rebond()
    for layer in range(3): lg.lift_layer(c, layer*np.sqrt(2/3))
    seq,_=lg.stacking(c); cnt[seq]+=1
    if len(seq)>=3: third["ABA (hcp-like)" if seq[2]=="A" else "ABC (fcc-like)"]+=1
print("stacking sequences over 40 seeds:",dict(cnt))
print("third layer:",dict(third))
