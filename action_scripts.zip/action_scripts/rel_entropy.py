#!/usr/bin/env python3
"""Relative entropy of the proton's strain field, GfE-style, on the confinement lattice.
GfE dictionary (lattice form): G~ g~^-1 - I = diag(eps_e) on one-forms, eps_e = l_e^2/L^2 - 1;
relative entropy L = -Tr ln(G~ g~^-1) = -sum_e ln(1+eps_e).  Second order: (1/2) sum eps^2."""
import numpy as np
from scipy.optimize import minimize
from scipy.spatial import cKDTree
n=8
pts=[(x,y,z) for x in range(2*n) for y in range(2*n) for z in range(2*n) if (x+y+z)%2==0]
P0=np.array(pts,float)/np.sqrt(2); N=len(P0); tree=cKDTree(P0)
bonds=np.array(sorted(tree.query_pairs(1.0+1e-6)))
centre=P0.mean(axis=0); c0=np.round(centre*np.sqrt(2)/2)*2/np.sqrt(2)
corners=np.array([c0+np.array(d)/np.sqrt(2) for d in [(0,0,0),(1,1,0),(1,0,1),(0,1,1)]]); void=corners.mean(0)
ci=[tree.query(c)[1] for c in corners]
rad=np.linalg.norm(P0-void,axis=1); R=rad.max(); fixed=rad>0.85*R; free=np.where(~fixed)[0]; nf=len(free)
def eg(x):
    P=np.vstack([P0.copy(),[void]]); P[free]=x[:nf*3].reshape(-1,3)
    E=0.0; G=np.zeros_like(P)
    d=P[bonds[:,0]]-P[bonds[:,1]]; r=np.linalg.norm(d,axis=1); e=r-1.0
    E+=0.5*(e**2).sum(); f=(e/r)[:,None]*d; np.add.at(G,bonds[:,0],f); np.add.at(G,bonds[:,1],-f)
    for i in ci:
        d=P[N]-P[i]; r=np.linalg.norm(d); e=r-1.0; E+=0.5*e*e; g=(e/r)*d; G[N]+=g; G[i]-=g
    return E, G[free].ravel()
res=minimize(eg,P0[free].ravel(),jac=True,method='L-BFGS-B',options={'maxiter':8000,'gtol':1e-11})
P=np.vstack([P0.copy(),[void]]); P[free]=res.x.reshape(-1,3)
# strains on lattice bonds and spokes (GfE convention eps = l^2/L^2 - 1)
l=np.linalg.norm(P[bonds[:,0]]-P[bonds[:,1]],axis=1); eps=l**2-1.0
ls=np.array([np.linalg.norm(P[N]-P[i]) for i in ci]); eps_s=ls**2-1.0
print(f"relaxed: E_el={res.fun:.4f} kL^2; spokes {ls.mean():.4f} L (eps_spoke={eps_s.mean():+.3f})")
S_latt=-np.log1p(eps).sum(); S_sp=-np.log1p(eps_s).sum()
S2_latt=0.5*(eps**2).sum(); S2_sp=0.5*(eps_s**2).sum()
print(f"\nrelative entropy -sum ln(1+eps):  lattice bonds {S_latt:+.4f}   spokes {S_sp:+.4f}   total {S_latt+S_sp:+.4f} nats")
print(f"second order (1/2)sum eps^2:      lattice bonds {S2_latt:+.4f}   spokes {S2_sp:+.4f}   total {S2_latt+S2_sp:+.4f}")
nb=(np.abs(eps)>1e-3).sum()
print(f"bonds with |eps|>1e-3: {nb} of {len(bonds)};  ln2 per such bond would be {nb*np.log(2):.1f} nats")
print(f"proton's footprint in the M/E/I count: 36 bonds -> 36 ln2 = {36*np.log(2):.1f} nats; 1836 bond-states -> {1836*np.log(2):.0f} nats")
# scaling onto the Planck lattice: strain is intensive, entropy is extensive in Planck bonds
Lc=0.8413e-15; lP=1.616e-35; ratio=Lc/lP
print(f"\nPlanck bonds per confinement bond along its length: {ratio:.1e}; per confinement cell: {ratio**3:.1e}")
print(f"if each Planck bond in a strained fm bond carries the same eps, the Planck-lattice relative entropy is")
print(f"   S_Planck ~ {S2_latt+S2_sp:.2f} x {ratio**3:.1e} ~ {(S2_latt+S2_sp)*ratio**3:.1e} nats  (footprint volume scaling)")
