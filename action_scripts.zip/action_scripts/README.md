# Scripts for "An action for the Selection–Stitch Model"

All scripts are plain Python 3 (numpy, scipy, networkx). Run from this directory.

| script | paper section | what it does | runtime |
|---|---|---|---|
| `abstract_ssm.py` | 7.1–7.2 | Abstract rigid-bond model: finds regular tetrahedra and octahedra in a unit-bond graph, computes the Regge deficit around every closed edge; verifies FCC and HCP are deficit-free with (2 tet, 2 oct) around every edge | seconds |
| `fk_phases.py` | 7.2, Table 1 | A15 and C15 Frank–Kasper foams: bonds/node, tets/node, signed and unsigned deficit/node, and the crossover λ_c | seconds |
| `a15.py` | 7.2 | A15 alone, with the energy comparison against FCC | seconds |
| `fcc_vs_hcp.py` | 8.1 | Rank-3 structure tensor and tet–tet / tet–oct / oct–oct face sharings for FCC and HCP | seconds |
| `rigid_growth.py` | 8.2 | Random stitch + lift with rigid geometry and overlap exclusion; produces the foam | ~1 min |
| `layered_growth.py` | 8.2 | Sheet first, then lift, layer by layer; reports stacking sequence and (2,2) rings | seconds |
| `stacking_stats.py` | 8.2 | Stacking statistics over 40 seeds (ABC vs ABA) | ~1 min |
| `centro_growth.py` | 8.2, Prop. 3 | Lift with the centrosymmetry selector; 30/30 ABC vs random baseline | ~2 min |
| `trapped_strain.py` | 9.4 | Relaxes an FCC cluster with a trapped node on harmonic bonds; measures u_r(r), misfit volume, energy split | ~2 min |
| `two_defects.py` | 9.4 | Two trapped nodes at six separations; pair interaction energy (unresolved; see paper) | ~20 min |

Dependencies: `pip install numpy scipy networkx`.
