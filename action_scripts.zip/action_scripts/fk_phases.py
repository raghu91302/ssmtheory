#!/usr/bin/env python3
"""Frank-Kasper tetrahedral close-packings in the abstract rigid-bond model: bonds/node and |deficit|/node."""
import numpy as np, itertools
from collections import defaultdict
from abstract_ssm import deficits, TET, OCT

def build(basis,cell,n,cut):
    pts=[]
    for i,j,k in itertools.product(range(n),repeat=3):
        for b in basis: pts.append(np.array([i,j,k])+np.array(b))
    pts=np.array(pts)@cell if cell is not None else np.array(pts)
    N=len(pts); adj=defaultdict(set)
    # periodic minimum image in fractional coords
    frac=np.array([[i,j,k] for i,j,k in itertools.product(range(n),repeat=3) for b in basis])+np.array([b for _ in range(n**3) for b in basis])
    C=np.eye(3) if cell is None else np.array(cell)
    for a in range(N):
        d=frac-frac[a]; d-=n*np.round(d/n); r=np.linalg.norm(d@C,axis=1)
        for b in np.where((r>1e-6)&(r<cut))[0]: adj[a].add(int(b))
    return adj,N

def report(name,adj,N):
    D,nt,no,T,O=deficits(adj)
    E=sum(len(v) for v in adj.values())/2; vals=np.array(list(D.values()))
    Z=sorted(set(len(v) for v in adj.values()))
    dist=defaultdict(int)
    for e in D: dist[(nt[e],no[e])]+=1
    b=E/N; d=abs(vals).sum()/N
    lam_c=(b-6.0)/d if d>0 else float('inf')
    print(f"{name:26s} Z={Z}  bonds/node={b:.3f}  tets/node={len(T)/N:.2f}  octs/node={len(O)/N:.2f}  |d|/node={d:.4f}  signed d/node={vals.sum()/N:+.4f}  lam_c={lam_c:.3f}")
    return b,d,lam_c

results={}
# A15 (Cr3Si)
A15=[(0,0,0),(.5,.5,.5),(.25,0,.5),(.75,0,.5),(.5,.25,0),(.5,.75,0),(0,.5,.25),(0,.5,.75)]
adj,N=build(A15,None,3,0.63); results['A15']=report("A15 (Cr3Si)",adj,N)
# C15 Laves (MgCu2): cubic, Mg at diamond positions, Cu at 16d
C15=[]
diamond=[(0,0,0),(.25,.25,.25)]; fcc=[(0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0)]
for f in fcc:
    for dpos in diamond: C15.append(tuple((f[i]+dpos[i])%1 for i in range(3)))
cu=[(5/8,5/8,5/8),(3/8,7/8,1/8),(7/8,1/8,3/8),(1/8,3/8,7/8)]
for f in fcc:
    for c in cu: C15.append(tuple((f[i]+c[i])%1 for i in range(3)))
adj,N=build(C15,None,2,0.46); results['C15']=report("C15 Laves (MgCu2)",adj,N)
# Z phase / sigma are tetragonal & complex; use the simplest second check: BCC as a NON-tetrahedral comparator (has irregular tets)
bcc=[(0,0,0),(.5,.5,.5)]
adj,N=build(bcc,None,4,0.9); results['BCC']=report("BCC (comparator)",adj,N)
print("\nFCC: bonds/node=6.000, |d|/node=0  (reference)")
print("\nlam_c is where FCC overtakes each foam; in Planck units L^2 = lam_c/(c) with c=0.159 (A=L c tau) or 0.112 (Lorentzian):")
for k,(b,d,lc) in results.items():
    if lc<float('inf') and lc>0:
        print(f"  {k:5s}: lam_c={lc:.3f} -> L_cryst = {np.sqrt(lc/0.159):.3f} (A=Lc tau)  or  {np.sqrt(lc/0.112):.3f} (Lorentzian)  l_P")
