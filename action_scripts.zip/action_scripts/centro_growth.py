#!/usr/bin/env python3
"""Does a local centrosymmetry preference, applied at each lift, select ABC (FCC) over ABA (HCP)?
Rule: when starting a new layer, evaluate both candidate sublattices by the rank-3 structure tensor
sum_ijk T_ijk^2 at the nodes of the layer below that would become 12-coordinated; choose the smaller.
This is the photon sector's masslessness condition (T=0) used as a growth selector."""
import numpy as np, itertools, sys
from collections import Counter
import layered_growth as lg

def T3sq(c, node):
    vecs=[(c.P[w]-c.P[node]) for w in c.adj[node]]
    vecs=[v/np.linalg.norm(v) for v in vecs]
    T=sum(np.einsum('i,j,k->ijk',n,n,n) for n in vecs)
    return float((T*T).sum())

def candidate_sublattices(c, zlayer):
    """the two families of triangles at zlayer, by apex position class"""
    tris=set()
    for a in c.adj:
        if abs(c.P[a][2]-zlayer)>1e-6: continue
        for b in c.adj[a]:
            if abs(c.P[b][2]-zlayer)>1e-6: continue
            for d in c.adj[a]&c.adj[b]:
                if a<b<d and abs(c.P[d][2]-zlayer)<1e-6: tris.add((a,b,d))
    fam={}
    a1=np.array([1,0.]); a2=np.array([.5,np.sqrt(3)/2]); M=np.array([a1,a2]).T
    for t in tris:
        cen=(c.P[t[0]]+c.P[t[1]]+c.P[t[2]])[:2]/3
        f=np.linalg.solve(M,cen); f-=np.floor(f); key=tuple(np.round(f*3).astype(int)%3)
        fam.setdefault(key,[]).append(t)
    return list(fam.values())

def grow_with_rule(seed, layers=3, use_rule=True):
    lg.rng=np.random.default_rng(seed)
    c=lg.Cluster(); c.P=[np.array(p) for p in lg.sheet(4)]; c.rebond()
    for k in range(layers):
        z=k*np.sqrt(2/3); fams=candidate_sublattices(c,z)
        if not fams: break
        if use_rule and k>=1 and len(fams)>=2:
            scores=[]
            for F in fams:
                trial=lg.Cluster(); trial.P=[p.copy() for p in c.P]; trial.rebond()
                for (a,b,d) in F:
                    A,B,D=trial.P[a],trial.P[b],trial.P[d]; n=np.cross(B-A,D-A); n/=np.linalg.norm(n); n*=np.sign(n[2])
                    trial.try_add((A+B+D)/3+np.sqrt(2/3)*n)
                # nodes of the layer below (z_{k-1}) now 12-coordinated
                below=[i for i in range(len(trial.P)) if abs(trial.P[i][2]-k*np.sqrt(2/3))<1e-6 and len(trial.adj[i])==12]
                scores.append(sum(T3sq(trial,i) for i in below)/max(len(below),1))
            F=fams[int(np.argmin(scores))]
        else:
            F=fams[lg.rng.integers(len(fams))]
        for (a,b,d) in F:
            A,B,D=c.P[a],c.P[b],c.P[d]; n=np.cross(B-A,D-A); n/=np.linalg.norm(n); n*=np.sign(n[2])
            c.try_add((A+B+D)/3+np.sqrt(2/3)*n)
    return lg.stacking(c)[0]

for rule in (False,True):
    cnt=Counter(grow_with_rule(s,use_rule=rule) for s in range(30))
    print(f"{'centrosymmetry rule' if rule else 'random':20s}: {dict(cnt)}")
