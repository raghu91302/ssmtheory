#!/usr/bin/env python3
"""Strain field of a trapped node in an FCC lattice with harmonic bonds.
All bonds (lattice and spokes) have natural length L=1 and stiffness k=1.
The trapped node sits at a tetrahedral void and bonds to its 4 corners (natural length 1, but the
geometry only allows 0.612 at the void centre): the misfit drives a strain field into the lattice.
Relax all positions (outer shell held fixed), then measure the radial displacement u_r(r)."""
import numpy as np, itertools
from scipy.optimize import minimize
from scipy.spatial import cKDTree
n=7                                           # conventional cells per side (side 2 in bond units L=sqrt2 -> rescale)
pts=[(x,y,z) for x in range(2*n) for y in range(2*n) for z in range(2*n) if (x+y+z)%2==0]
P0=np.array(pts,float)/np.sqrt(2)             # bond length 1
N=len(P0); centre=P0.mean(axis=0)
# tetrahedral void nearest the centre: corners (0,0,0),(1,1,0),(1,0,1),(0,1,1) type, centre at (1/2,1/2,1/2)/sqrt2 offset
c0=np.round(centre*np.sqrt(2)/2)*2            # an even-even-even lattice point near the centre
c0=c0/np.sqrt(2)
corners=np.array([c0+np.array(d)/np.sqrt(2) for d in [(0,0,0),(1,1,0),(1,0,1),(0,1,1)]])
void=corners.mean(axis=0)
tree=cKDTree(P0); ci=[tree.query(c)[1] for c in corners]
assert all(np.linalg.norm(P0[i]-c)<1e-9 for i,c in zip(ci,corners))
# bonds
pairs=tree.query_pairs(1.0+1e-6); bonds=np.array(sorted(pairs)); print(f"N={N} nodes, {len(bonds)} bonds, void at {void}")
# fixed outer shell
rad=np.linalg.norm(P0-void,axis=1); R=rad.max(); fixed=rad>0.85*R
free=np.where(~fixed)[0]; print(f"free nodes {len(free)}, fixed shell {fixed.sum()}")
# trapped node index N (appended)
def energy_grad(x):
    P=np.vstack([P0.copy(),[void]])
    P[free]=x[:len(free)*3].reshape(-1,3); P[N]=x[len(free)*3:]
    E=0.0; G=np.zeros_like(P)
    d=P[bonds[:,0]]-P[bonds[:,1]]; r=np.linalg.norm(d,axis=1); e=r-1.0
    E+=0.5*(e**2).sum(); f=(e/r)[:,None]*d
    np.add.at(G,bonds[:,0],f); np.add.at(G,bonds[:,1],-f)
    for i in ci:
        d=P[N]-P[i]; r=np.linalg.norm(d); e=r-1.0; E+=0.5*e*e; g=(e/r)*d; G[N]+=g; G[i]-=g
    return E, np.concatenate([G[free].ravel(),G[N]])
x0=np.concatenate([P0[free].ravel(),void])
res=minimize(energy_grad,x0,jac=True,method='L-BFGS-B',options={'maxiter':5000,'gtol':1e-10})
P=np.vstack([P0.copy(),[void]]); P[free]=res.x[:len(free)*3].reshape(-1,3); P[N]=res.x[len(free)*3:]
print(f"relaxed: E={res.fun:.5f} (k L^2 units), spokes = {[round(np.linalg.norm(P[N]-P[i]),4) for i in ci]}")
# radial displacement field
u=P[:N]-P0; r0=np.linalg.norm(P0-void,axis=1); rhat=(P0-void)/r0[:,None]
ur=(u*rhat).sum(axis=1)
bins=np.arange(0.5,0.85*R,0.5); print("\n   r        <u_r>       <u_r> r^2   n")
for a,b in zip(bins[:-1],bins[1:]):
    m=(r0>=a)&(r0<b)&(~fixed)
    if m.sum(): print(f"  {0.5*(a+b):5.2f}   {ur[m].mean():+.5f}   {(ur[m]*r0[m]**2).mean():+.5f}   {m.sum()}")
np.save('relaxed.npy',P); np.save('P0.npy',P0); np.save('ur.npy',np.c_[r0,ur])
# elastic energy in the lattice vs in the spokes
Es=sum(0.5*(np.linalg.norm(P[N]-P[i])-1)**2 for i in ci)
print(f"\nenergy: spokes {Es:.4f}, lattice strain {res.fun-Es:.4f}, total {res.fun:.4f}  (k L^2)")
