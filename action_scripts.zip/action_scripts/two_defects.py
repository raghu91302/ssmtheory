#!/usr/bin/env python3
"""Elastic interaction of two trapped nodes in FCC. Relax with 0, 1, 2 defects; E_int(d) = E_2 - 2 E_1.
Separations chosen along the void lattice (tetrahedral voids form a simple cubic lattice of spacing L/sqrt2)."""
import numpy as np, sys
from scipy.optimize import minimize
from scipy.spatial import cKDTree
n=8
pts=[(x,y,z) for x in range(2*n) for y in range(2*n) for z in range(2*n) if (x+y+z)%2==0]
P0=np.array(pts,float)/np.sqrt(2); N=len(P0); tree=cKDTree(P0)
bonds=np.array(sorted(tree.query_pairs(1.0+1e-6)))
centre=P0.mean(axis=0); c0=np.round(centre*np.sqrt(2)/2)*2/np.sqrt(2)
def void_corners(c):
    cs=np.array([c+np.array(d)/np.sqrt(2) for d in [(0,0,0),(1,1,0),(1,0,1),(0,1,1)]])
    idx=[tree.query(x)[1] for x in cs]; assert all(np.linalg.norm(P0[i]-x)<1e-9 for i,x in zip(idx,cs)); return idx,cs.mean(axis=0)
def relax(voids):
    idxs=[];vs=[]
    for c in voids: i,v=void_corners(c); idxs.append(i); vs.append(v)
    ref=np.mean(vs,axis=0) if vs else centre
    rad=np.linalg.norm(P0-ref,axis=1); R=rad.max(); fixed=rad>0.85*R; free=np.where(~fixed)[0]; nf=len(free)
    M=len(voids)
    def eg(x):
        P=np.vstack([P0.copy(),np.array(vs).reshape(-1,3)]) if M else P0.copy()
        P[free]=x[:nf*3].reshape(-1,3)
        for m in range(M): P[N+m]=x[nf*3+3*m:nf*3+3*m+3]
        E=0.0; G=np.zeros_like(P)
        d=P[bonds[:,0]]-P[bonds[:,1]]; r=np.linalg.norm(d,axis=1); e=r-1.0
        E+=0.5*(e**2).sum(); f=(e/r)[:,None]*d; np.add.at(G,bonds[:,0],f); np.add.at(G,bonds[:,1],-f)
        for m in range(M):
            for i in idxs[m]:
                d=P[N+m]-P[i]; r=np.linalg.norm(d); e=r-1.0; E+=0.5*e*e; g=(e/r)*d; G[N+m]+=g; G[i]-=g
        return E, np.concatenate([G[free].ravel()]+[G[N+m] for m in range(M)])
    x0=np.concatenate([P0[free].ravel()]+[v for v in vs])
    res=minimize(eg,x0,jac=True,method='L-BFGS-B',options={'maxiter':8000,'gtol':1e-11})
    return res.fun
E0=relax([]); E1=relax([c0])
print(f"E0={E0:.6f}  E1={E1:.6f}  single-defect energy {E1-E0:.6f} (k L^2)")
a=1/np.sqrt(2)   # void-lattice spacing
seps=[((2,0,0),"[100] x2 = 1.41 L"),((2,2,0),"[110] x2 = 2.00 L"),((2,2,2),"[111] x2 = 2.45 L"),
      ((4,0,0),"[100] x4 = 2.83 L"),((4,4,0),"[110] x4 = 4.00 L"),((6,0,0),"[100] x6 = 4.24 L")]
print(f"\n{'separation':22s}{'d/L':>7s}{'E_int':>12s}{'E_int d^3':>12s}")
out=[]
for dv,lab in seps:
    c1=c0+np.array(dv)*a          # shift in units of the void lattice; must land on a valid void
    try:
        E2=relax([c0,c1]); d=np.linalg.norm(np.array(dv)*a); Ei=E2-2*E1+E0
        print(f"{lab:22s}{d:7.3f}{Ei:+12.6f}{Ei*d**3:+12.5f}"); out.append((d,Ei))
    except AssertionError: print(f"{lab:22s} -- not a void position, skipped")
np.save('two_defect_Eint.npy',np.array(out))
