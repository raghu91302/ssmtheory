#!/usr/bin/env python3
"""What distinguishes FCC from HCP in the abstract complex, given both are Regge-flat with 6 bonds/node."""
import numpy as np, itertools
from collections import defaultdict
from abstract_ssm import fcc_periodic, hcp_periodic, tets, octahedra

def analyse(name, adj, pos):
    N=len(adj); T=tets(adj); O=octahedra(adj)
    # 1. rank-3 structure tensor at each node: sum over bonds of n_i n_j n_k (zero iff centrosymmetric)
    T3=[]
    for v in adj:
        vecs=[]
        for w in adj[v]:
            d=pos[w]-pos[v]; d-=np.round(d/box)*box if box is not None else 0; vecs.append(d/np.linalg.norm(d))
        t3=sum(np.einsum('i,j,k->ijk',n,n,n) for n in vecs); T3.append(np.abs(t3).max())
    # 2. face-sharing tetrahedron pairs (triangular bipyramids) per node
    faces=defaultdict(list)
    for t in T:
        for f in itertools.combinations(t,3): faces[f].append(t)
    tt=sum(1 for f,ts in faces.items() if len(ts)==2)
    # 3. tet-oct and oct-oct face sharings
    ofaces=defaultdict(list)
    for o in O:
        # faces of an octahedron: 8 triangles = triples of mutually adjacent vertices
        for f in itertools.combinations(o,3):
            if all(b in adj[a] for a,b in itertools.combinations(f,2)): ofaces[f].append(o)
    to=sum(1 for f in faces if f in ofaces); oo=sum(1 for f,os in ofaces.items() if len(os)==2)
    print(f"{name}: nodes={N}, tets={len(T)}, octs={len(O)}")
    print(f"   rank-3 structure tensor max|T_ijk| per node: {max(T3):.4f}   (0 = centrosymmetric)")
    print(f"   tet-tet face sharings/node = {tt/N:.3f}   tet-oct/node = {to/N:.3f}   oct-oct/node = {oo/N:.3f}")

# FCC positions
n=4; pts=[(x,y,z) for x in range(2*n) for y in range(2*n) for z in range(2*n) if (x+y+z)%2==0]
pos=np.array(pts,float); box=2*n
analyse("FCC", fcc_periodic(n), pos)
# HCP positions (rebuild consistently with hcp_periodic)
a1=np.array([1,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0]); c=np.array([0,0,np.sqrt(8/3)])
basis=[np.zeros(3),(a1+a2)/3+c/2]; pts=[]
for i in range(n):
    for j in range(n):
        for k in range(n):
            for b in basis: pts.append(i*a1+j*a2+k*c+b)
pos=np.array(pts); box=None
adj=hcp_periodic(n)
# for HCP the minimum-image above is not orthorhombic; compute bond vectors from replicated copies instead
def analyse_hcp(adj,pos):
    N=len(pos); reps=[pos+di*n*a1+dj*n*a2+dk*n*c for di,dj,dk in itertools.product([-1,0,1],repeat=3)]
    allp=np.vstack(reps); T3=[]
    for v in range(N):
        d=allp-pos[v]; r=np.linalg.norm(d,axis=1); vecs=d[(r>0.5)&(r<1.05)]
        vecs=vecs/np.linalg.norm(vecs,axis=1)[:,None]
        t3=sum(np.einsum('i,j,k->ijk',x,x,x) for x in vecs); T3.append(np.abs(t3).max())
    T=tets(adj); O=octahedra(adj)
    faces=defaultdict(list)
    for t in T:
        for f in itertools.combinations(t,3): faces[f].append(t)
    tt=sum(1 for f,ts in faces.items() if len(ts)==2)
    ofaces=defaultdict(list)
    for o in O:
        for f in itertools.combinations(o,3):
            if all(b in adj[a] for a,b in itertools.combinations(f,2)): ofaces[f].append(o)
    to=sum(1 for f in faces if f in ofaces); oo=sum(1 for f,os in ofaces.items() if len(os)==2)
    print(f"HCP: nodes={N}, tets={len(T)}, octs={len(O)}")
    print(f"   rank-3 structure tensor max|T_ijk| per node: {max(T3):.4f}   (0 = centrosymmetric)")
    print(f"   tet-tet face sharings/node = {tt/N:.3f}   tet-oct/node = {to/N:.3f}   oct-oct/node = {oo/N:.3f}")
analyse_hcp(adj,pos)
