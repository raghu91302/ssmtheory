#!/usr/bin/env python3
"""Two trapped nodes in FCC via the lattice Green's function.
Harmonic unit bonds (k=1, length 1). A trapped node at a tetrahedral void pushes its 4 corners outward
along <111> with force f (relaxed value from the cluster calculation: f = 1 - 0.673 = 0.327).
Defect = force distribution F_i = f n_i on the 4 corners. Interaction of two defects at separation d:
   E_int(d) = -(1/N) sum_k Re[ F1(k)^dag G(k) F2(k) e^{-i k.d} ],   G(k) = D(k)^-1,
   D(k) = 2 sum_{6 bond pairs} (1 - cos k.b) n n^T.
Exact on the periodic lattice; no relaxation, no boundary."""
import numpy as np, itertools
n=48                                   # conventional cells per side (cell side 2 in units where bond = sqrt2)
f=0.327
bonds=np.array([b for b in itertools.product([-1,0,1],repeat=3) if sum(x*x for x in b)==2],float)
pos=bonds[[i for i in range(12) if tuple(bonds[i])>tuple(-bonds[i])]]   # 6 positive directions
nhat=pos/np.sqrt(2)
# k grid on the FCC reciprocal lattice: use the conventional cubic supercell of side 2n; sites = even-parity points
# FFT over the full cubic grid of side 2n with the FCC mask handled by restricting to FCC k-points is messy;
# simpler: treat the FCC lattice as a Bravais lattice with primitive vectors and an N1xN2xN3 grid.
a1=np.array([1,1,0.]); a2=np.array([1,0,1.]); a3=np.array([0,1,1.])
A=np.array([a1,a2,a3]); B=2*np.pi*np.linalg.inv(A).T   # reciprocal
N=n
m=np.fft.fftfreq(N)*N                                 # integer indices
M1,M2,M3=np.meshgrid(m,m,m,indexing='ij')
K=(M1[...,None]*B[0]+M2[...,None]*B[1]+M3[...,None]*B[2])/N   # k vectors, shape (N,N,N,3)
# dynamical matrix
D=np.zeros(K.shape[:3]+(3,3))
for b,nh in zip(pos,nhat):
    c=1-np.cos(K@b)
    D+=2*c[...,None,None]*np.outer(nh,nh)
D[0,0,0]=np.eye(3)                                      # zero mode: F(0)=0 so value irrelevant
G=np.linalg.inv(D); G[0,0,0]=0
# defect force distribution at a tetrahedral void centred at (1/2,1/2,1/2) with corners (0,0,0),(1,1,0),(1,0,1),(0,1,1)
corners=np.array([(0,0,0),(1,1,0),(1,0,1),(0,1,1)],float); cen=corners.mean(0)
Fk=np.zeros(K.shape[:3]+(3,),complex)
for c in corners:
    nn=(c-cen)/np.linalg.norm(c-cen)
    Fk+=f*nn*np.exp(-1j*(K@c))[...,None]
# self energy check: E_self = -(1/2N) sum F^dag G F
GF=np.einsum('...ij,...j->...i',G,Fk)
Eself=-0.5*np.real(np.einsum('...i,...i->...',np.conj(Fk),GF)).sum()/N**3
print(f"N={N}^3 sites; force-dipole self-energy (lattice relaxation energy) = {Eself:.5f} k L^2  (cluster calc gave 0.040)")
# interaction: E_int(d) = -(1/N) sum_k Re[F^dag G F e^{-i k.d}] for d a lattice vector; compute via FFT
S=np.einsum('...i,...i->...',np.conj(Fk),GF)            # F^dag G F (k)
Eint_r=-np.real(np.fft.ifftn(S))                         # E_int at lattice vector index (i,j,k) -> r = i a1 + j a2 + k a3
def Eint(d):
    # d must be an FCC lattice vector; solve d = i a1 + j a2 + k a3
    ijk=np.rint(np.linalg.solve(A.T,d)).astype(int)%N
    return Eint_r[tuple(ijk)]
print("\nseparation (lattice vector)      d/L      E_int        E_int d^3")
for d,lab in [((2,0,0),"[100] 2"),((2,2,0),"[110] 2sqrt2"),((2,2,2),"[111] 2sqrt3"),((4,0,0),"[100] 4"),((4,4,0),"[110]"),((4,4,4),"[111]"),
              ((6,0,0),"[100] 6"),((6,6,0),"[110]"),((6,6,6),"[111]"),((8,0,0),"[100] 8"),((8,8,0),"[110]"),((8,8,8),"[111]"),((10,0,0),"[100] 10")]:
    dv=np.array(d,float); dl=np.linalg.norm(dv)/np.sqrt(2)
    e=Eint(dv); print(f"  {lab:14s} {tuple(d)}   {dl:6.3f}   {e:+.3e}   {e*dl**3:+.4f}")
