#!/usr/bin/env python3
import numpy as np, itertools, sys
n=int(sys.argv[1]) if len(sys.argv)>1 else 64
f=0.327
bonds=np.array([b for b in itertools.product([-1,0,1],repeat=3) if sum(x*x for x in b)==2],float)
pos=bonds[[i for i in range(12) if tuple(bonds[i])>tuple(-bonds[i])]]; nhat=pos/np.sqrt(2)
A=np.array([[1,1,0.],[1,0,1.],[0,1,1.]]); B=2*np.pi*np.linalg.inv(A).T; N=n
m=np.fft.fftfreq(N)*N; M1,M2,M3=np.meshgrid(m,m,m,indexing='ij')
K=(M1[...,None]*B[0]+M2[...,None]*B[1]+M3[...,None]*B[2])/N
D=np.zeros(K.shape[:3]+(3,3))
for b,nh in zip(pos,nhat): D+=2*(1-np.cos(K@b))[...,None,None]*np.outer(nh,nh)
D[0,0,0]=np.eye(3); G=np.linalg.inv(D); G[0,0,0]=0
corners=np.array([(0,0,0),(1,1,0),(1,0,1),(0,1,1)],float); cen=corners.mean(0)
Fk=np.zeros(K.shape[:3]+(3,),complex)
for c in corners:
    nn=(c-cen)/np.linalg.norm(c-cen); Fk+=f*nn*np.exp(-1j*(K@c))[...,None]
S=np.einsum('...i,...i->...',np.conj(Fk),np.einsum('...ij,...j->...i',G,Fk))
Er=-np.real(np.fft.ifftn(S))
def Eint(d): return Er[tuple(np.rint(np.linalg.solve(A.T,np.array(d,float))).astype(int)%N)]
# asymptotic A(direction) = E d^3 at the largest usable d (< N/4 in cubic units)
dirs={"[100]":(1,0,0),"[110]":(1,1,0),"[111]":(1,1,1),"[210]":(2,1,0),"[211]":(2,1,1),"[310]":(3,1,0)}
print(f"N={N}^3;  E_int d^3 at increasing d (cubic units), last column = direction cosines l^4+m^4+n^4")
rows=[]
for lab,v in dirs.items():
    v=np.array(v,float); u=v/np.linalg.norm(v); s4=(u**4).sum()
    vals=[]
    for s in (4,6,8,10,12):
        d=v*s; 
        if (d%1).any() or np.linalg.norm(d)>N/3: continue
        # d must be an FCC vector: even coordinate sum
        if int(d.sum())%2: continue
        dl=np.linalg.norm(d)/np.sqrt(2); vals.append((dl,Eint(d)*dl**3))
    print(f"  {lab:6s}", "  ".join(f"d={dl:5.2f}:{e:+.4f}" for dl,e in vals), f"   sum l^4={s4:.3f}")
    if vals: rows.append((s4,vals[-1][1]))
# fit E d^3 = a + b*(l^4+m^4+n^4)
X=np.array([[1,s] for s,_ in rows]); y=np.array([e for _,e in rows])
coef,res,_,_=np.linalg.lstsq(X,y,rcond=None)
print(f"\nfit E_int d^3 = a + b (l^4+m^4+n^4):  a={coef[0]:+.4f}, b={coef[1]:+.4f};  zero crossing at sum l^4 = {-coef[0]/coef[1]:.3f} (isotropic average is 0.600)")
print("residuals:", np.round(y-X@coef,4))
