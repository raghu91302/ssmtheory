#!/usr/bin/env python3
"""Micro-SSM on the ABSTRACT complex: rigid unit bonds, regular cells.
Cells: regular tetrahedra (dihedral arccos(1/3)=70.53 deg) and regular octahedra (arccos(-1/3)=109.47 deg).
Deficit around an edge = 2pi - (n_tet * 70.53 + n_oct * 109.47) deg.  Zero iff 2 tets + 2 octs, or 6 octs... etc.
Energy per node = -J * (bonds per node) + lam * (deficit per node).
"""
import numpy as np, itertools
from collections import defaultdict
TET=np.arccos(1/3); OCT=np.arccos(-1/3)

def cells_from_graph(adj):
    """find all 4-cliques (tets) and octahedra (K_{2,2,2}) in a unit-bond graph"""
    nodes=list(adj); tets=set(); octs=set()
    for a in nodes:
        na=sorted(x for x in adj[a] if x>a)
        for b,c,d in itertools.combinations(na,3):
            if c in adj[b] and d in adj[b] and d in adj[c]: tets.add((a,b,c,d))
    # octahedron: 6 nodes, each adjacent to 4 of the others (not its antipode)
    for a in nodes:
        for b,c in itertools.combinations(sorted(adj[a]),2):
            if c in adj[b]: continue      # b,c must be antipodal-type? no: in an octahedron a's 4 neighbours form a 4-cycle
        # simpler: enumerate 4-cycles through a's neighbours and check the two apices
    # brute force octahedra via 4-cycles of mutually adjacent-in-ring nodes with two common apices
    for a in nodes:
        for b in adj[a]:
            if b<=a: continue
            common=sorted(adj[a]&adj[b])
            for c,d in itertools.combinations(common,2):
                if c in adj[d]: continue           # c,d non-adjacent: they are the other antipodal pair of a square? no
                # square a-c-b-d? need a~c, c~b, b~d, d~a with a!~b? but a~b. Use: octahedron = 3 antipodal pairs {a,a'},{b,b'},{c,c'}, all cross-adjacent
    return tets, octs

def octahedra(adj):
    """octahedra = triples of antipodal pairs, every vertex adjacent to all four non-antipodal vertices"""
    octs=set(); nodes=list(adj)
    for a in nodes:
        for b in adj[a]:
            if b<=a: continue
            for c in adj[a]&adj[b]:
                if c<=b: continue
                # a,b,c a triangle; find the three antipodes a',b',c' with a'~b,c,b',c' etc.
                for ap in (adj[b]&adj[c])-adj[a]-{a}:
                    for bp in (adj[a]&adj[c]&adj[ap])-adj[b]-{b}:
                        for cp in (adj[a]&adj[b]&adj[ap]&adj[bp])-adj[c]-{c}:
                            octs.add(tuple(sorted((a,b,c,ap,bp,cp))))
    return octs

def tets(adj):
    T=set()
    for a in adj:
        for b,c,d in itertools.combinations(sorted(x for x in adj[a] if x>a),3):
            if c in adj[b] and d in adj[b] and d in adj[c]: T.add((a,b,c,d))
    return T

def deficits(adj):
    T=tets(adj); O=octahedra(adj)
    ang=defaultdict(float); ntet=defaultdict(int); noct=defaultdict(int)
    for t in T:
        for e in itertools.combinations(t,2): ang[e]+=TET; ntet[e]+=1
    for o in O:
        # octahedron edges: all pairs except the 3 antipodal ones (non-adjacent)
        for e in itertools.combinations(o,2):
            if e[1] in adj[e[0]]: ang[e]+=OCT; noct[e]+=1
    return {e:2*np.pi-ang[e] for e in ang}, ntet, noct, T, O

def fcc_periodic(n):
    pts=[(x,y,z) for x in range(2*n) for y in range(2*n) for z in range(2*n) if (x+y+z)%2==0]
    idx={p:i for i,p in enumerate(pts)}; adj=defaultdict(set)
    NN=[v for v in itertools.product([-1,0,1],repeat=3) if sum(x*x for x in v)==2]
    for p in pts:
        for d in NN:
            q=tuple((p[i]+d[i])%(2*n) for i in range(3)); adj[idx[p]].add(idx[q])
    return adj
def hcp_periodic(n):
    # ABAB stacking of triangular layers, periodic in-plane; use ideal HCP graph
    a1=np.array([1,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0]); c=np.array([0,0,np.sqrt(8/3)])
    basis=[np.zeros(3),(a1+a2)/3+c/2]
    pts=[]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                for b in basis: pts.append(i*a1+j*a2+k*c+b)
    pts=np.array(pts); N=len(pts)
    box=np.array([n,n*np.sqrt(3)/2*0+n,n])  # not orthorhombic; do minimum image roughly via replication
    # replicate 3x3x3 and detect neighbours of the central copy at distance ~1
    reps=[]
    for di,dj,dk in itertools.product([-1,0,1],repeat=3):
        reps.append(pts+di*n*a1+dj*n*a2+dk*n*c)
    allp=np.vstack(reps); adj=defaultdict(set)
    for i in range(N):
        d=np.linalg.norm(allp-pts[i],axis=1)
        for j in np.where((d>0.5)&(d<1.05))[0]: adj[i].add(int(j%N))
    return adj

for name,adj in [("FCC (periodic 4^3 cells)",fcc_periodic(4)),("HCP (periodic 4^3 cells)",hcp_periodic(4))]:
    D,nt,no,T,O=deficits(adj)
    N=len(adj); E=sum(len(v) for v in adj.values())/2
    vals=np.array(list(D.values()))
    print(f"{name}: nodes={N}, bonds/node={E/N:.2f}, tets/node={len(T)/N:.2f}, octs/node={len(O)/N:.2f}")
    print(f"   edge deficits: mean={vals.mean():.5f} rad, max|.|={abs(vals).max():.5f}; (n_tet,n_oct) per edge = {set((nt[e],no[e]) for e in D)}")
