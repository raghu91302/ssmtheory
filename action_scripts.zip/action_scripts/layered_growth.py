#!/usr/bin/env python3
"""SSM protocol in the series' order: planar stitch builds a hexagonal sheet; lift then caps its triangles.
Rigid geometry, automatic bonding at unit distance, overlap rejection at 0.9. No energy needed for this test:
the question is what geometry the ordered moves produce."""
import numpy as np, itertools, sys
from collections import defaultdict
from rigid_growth import Cluster, TOL
rng=np.random.default_rng(int(sys.argv[1]) if len(sys.argv)>1 else 0)

def sheet(R):
    """hexagonal (triangular-lattice) sheet of radius R by planar stitch"""
    a1=np.array([1,0,0.]); a2=np.array([.5,np.sqrt(3)/2,0.])
    return [i*a1+j*a2 for i in range(-R,R+1) for j in range(-R,R+1) if np.linalg.norm(i*a1+j*a2)<=R]

def lift_layer(c, zlayer, ntry=6000):
    """cap the planar triangles lying at height zlayer, on the +z side; overlap rule picks the sublattice"""
    added=0
    for _ in range(ntry):
        tris=set()
        for a in c.adj:
            if abs(c.P[a][2]-zlayer)>1e-6: continue
            for b in c.adj[a]:
                if abs(c.P[b][2]-zlayer)>1e-6: continue
                for d in c.adj[a]&c.adj[b]:
                    if a<b<d and abs(c.P[d][2]-zlayer)<1e-6: tris.add((a,b,d))
        if not tris: break
        a,b,d=list(tris)[rng.integers(len(tris))]; A,B,D=c.P[a],c.P[b],c.P[d]
        n=np.cross(B-A,D-A); n/=np.linalg.norm(n); n*=np.sign(n[2])
        if c.try_add((A+B+D)/3+np.sqrt(2/3)*n): added+=1
    return added

def stacking(c):
    """classify layers by z; report the lateral offset pattern (A/B/C)"""
    z=np.round(np.array([p[2] for p in c.P])/np.sqrt(2/3)).astype(int)
    layers=sorted(set(z)); labels=[]; ref={}
    for L in layers:
        pts=np.array([p[:2] for p,zz in zip(c.P,z) if zz==L])
        # lateral position class: fractional coords of centroid-ish representative mod lattice
        a1=np.array([1,0.]); a2=np.array([.5,np.sqrt(3)/2]); M=np.array([a1,a2]).T
        f=np.linalg.solve(M,pts[0]); f=f-np.floor(f); key=tuple(np.round(f*3).astype(int)%3)
        if key not in ref: ref[key]="ABC"[len(ref)]
        labels.append(ref[key])
    return "".join(labels), [int((z==L).sum()) for L in layers]

c=Cluster(); c.P=[np.array(p) for p in sheet(4)]; c.rebond()
N0=len(c.P); print(f"sheet: N={N0}, bonds/node={c.nbonds()/N0:.2f}, mean Z={np.mean([len(v) for v in c.adj.values()]):.2f}")
for layer in range(4):
    n=lift_layer(c, layer*np.sqrt(2/3)); N=len(c.P); g,nt,no=c.gap_energy()
    Z=np.array([len(v) for v in c.adj.values()])
    print(f"after lift {layer+1}: +{n} nodes, N={N}, tets={nt}, octs={no}, gap sum={g:.2f}, max Z={Z.max()}")
seq,counts=stacking(c)
print(f"\nstacking sequence: {seq}   layer sizes {counts}")
# interior check: nodes with Z=12 and their (tet,oct) rings
T=c.tets(); O=c.octs(); ring=defaultdict(lambda:[0,0])
for t in T:
    for e in itertools.combinations(t,2): ring[e][0]+=1
for o in O:
    for e in itertools.combinations(o,2):
        if e[1] in c.adj[e[0]]: ring[e][1]+=1
closed=[e for e,(a,b) in ring.items() if a==2 and b==2]
print(f"edges with the FCC/HCP (2 tet, 2 oct) ring: {len(closed)} of {c.nbonds()}")
