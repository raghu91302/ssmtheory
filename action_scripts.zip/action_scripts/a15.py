#!/usr/bin/env python3
import numpy as np, itertools
from collections import defaultdict
from abstract_ssm import deficits, TET
# A15 (Cr3Si) Frank-Kasper phase: 8 sites per cubic cell; tetrahedral close-packing.
basis=[(0,0,0),(.5,.5,.5),(.25,0,.5),(.75,0,.5),(.5,.25,0),(.5,.75,0),(0,.5,.25),(0,.5,.75)]
n=3
pts=[];
for i,j,k in itertools.product(range(n),repeat=3):
    for b in basis: pts.append(np.array([i+b[0],j+b[1],k+b[2]]))
pts=np.array(pts); N=len(pts)
def mind(p,q):
    d=p-q; d-=n*np.round(d/n); return np.linalg.norm(d)
# nearest-neighbour cutoff: A15 NN distances are 0.5 (chain), 0.559, 0.612 in cell units; use 0.63
adj=defaultdict(set)
for i in range(N):
    for j in range(i+1,N):
        if mind(pts[i],pts[j])<0.63: adj[i].add(j); adj[j].add(i)
D,nt,no,T,O=deficits(adj)
E=sum(len(v) for v in adj.values())/2
Z=sorted(set(len(v) for v in adj.values()))
vals=np.array(list(D.values()))
print(f"A15: nodes={N}, coordinations={Z}, bonds/node={E/N:.3f}, tets/node={len(T)/N:.2f}, octs/node={len(O)/N:.2f}")
print(f"   closed edges={len(D)} ; (n_tet) distribution={dict((k,sum(1 for e in D if nt[e]==k)) for k in set(nt[e] for e in D))}")
print(f"   sum deficit = {vals.sum():+.3f} rad (signed), sum|deficit| = {abs(vals).sum():.3f} rad  -> |deficit|/node = {abs(vals).sum()/N:.4f}")
print(f"   per-edge: 5-tet edges {2*np.pi-5*TET:+.4f}, 6-tet edges {2*np.pi-6*TET:+.4f}")
print()
print("energy per node, E = -J*bonds + lam*|deficit|  (J=1):")
b_fcc,d_fcc=6.0,0.0; b_a15,d_a15=E/N,abs(vals).sum()/N
print(f"   FCC: -{b_fcc:.3f} + 0*lam ;  A15: -{b_a15:.3f} + {d_a15:.4f}*lam")
print(f"   crossover lam_c = {(b_a15-b_fcc)/d_a15:.3f} :  tetrahedral foam wins below, FCC wins above")
