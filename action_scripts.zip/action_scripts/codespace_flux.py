#!/usr/bin/env python3
"""Is U_f = (k/n) E_bond the code-space value of the charging operator?
CSS code on FCC bonds: Z-checks = 12 bonds at a node (N of them), X-checks = 12 bonds of a void cube.
Flux excitations are X-type on bonds. The question: what fraction of the single-bond flux variance
survives projection into the code space?
For a stabilizer code, P = prod_s (1+s)/2. For a single-qubit operator O_b:
   Tr(P O_b^2 P)/Tr(P) = <O_b^2> in the maximally mixed code state = 1 if O_b^2 = I.
That is trivially 1, so the variance question must be about the X-sector's FREE degrees of freedom:
how many independent flux patterns are allowed per bond."""
import numpy as np, itertools
from collections import defaultdict
def build(L):
    pts=[(x,y,z) for x in range(2*L) for y in range(2*L) for z in range(2*L) if (x+y+z)%2==0]
    idx={p:i for i,p in enumerate(pts)}; N=len(pts)
    NN=[v for v in itertools.product([-1,0,1],repeat=3) if sum(x*x for x in v)==2]
    bonds=[]; bidx={}
    for p in pts:
        for d in NN:
            q=tuple((p[i]+d[i])%(2*L) for i in range(3))
            e=tuple(sorted((idx[p],idx[q])))
            if e not in bidx: bidx[e]=len(bonds); bonds.append(e)
    n=len(bonds)
    # Z-checks: node stars (weight 12)
    HZ=np.zeros((N,n),np.int8)
    for e,b in bidx.items():
        for v in e: HZ[v,b]=1
    # X-checks: the 12 bonds of each void-centred cube = the bonds of the 12 edges of the cube whose
    # centre is an odd-parity point. Equivalent construction: for each odd point, the 12 bonds joining
    # its 12 nearest even points pairwise at distance 1 that lie on the cube's edges.
    odd=[(x,y,z) for x in range(2*L) for y in range(2*L) for z in range(2*L) if (x+y+z)%2==1]
    HX=[]
    for o in odd:
        ring=[]
        for d in NN:
            q=tuple((o[i]+d[i])%(2*L) for i in range(3))
            # q is odd+even=odd? (sum d even) -> q has same parity as o. skip
        # the 6 even neighbours of an odd point are at <100>
        ev=[tuple((o[i]+d[i])%(2*L) for i in range(3)) for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
        row=np.zeros(n,np.int8); w=0
        for a,b in itertools.combinations(ev,2):
            e=tuple(sorted((idx[a],idx[b])))
            if e in bidx: row[bidx[e]]=1; w+=1
        if w: HX.append(row)
    HX=np.array(HX)
    return N,n,HZ,HX
def rank2(M):
    M=M.copy()%2; r=0; rows,cols=M.shape
    for c in range(cols):
        piv=None
        for i in range(r,rows):
            if M[i,c]: piv=i; break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
        if r==rows: break
    return r
for L in (2,3,4):
    N,n,HZ,HX=build(L)
    rz=rank2(HZ); rx=rank2(HX); k=n-rz-rx
    print(f"L={L}: N={N} nodes, n={n} bonds; rank H_Z={rz}, rank H_X={rx} (rows {HX.shape[0]}, weight {HX.sum(1)[0] if len(HX) else 0}); k=n-rz-rx={k}")
    print(f"        k/n = {k/n:.4f};  2N+2 = {2*N+2}, (2N+2)/n = {(2*N+2)/n:.4f};  target 130/192={130/192:.4f}")
    # free flux configurations: X-type operators modulo X-stabilizers, constrained by Z-checks
    print(f"        flux d.o.f. per bond: (n - rz)/n = {(n-rz)/n:.4f}   [Gauss law only]")
    print(f"        logical fraction    : k/n        = {k/n:.4f}")
