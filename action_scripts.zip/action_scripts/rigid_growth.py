#!/usr/bin/env python3
"""Rigid growth by the SSM's own moves. Nodes at positions fixed by regular geometry:
   lift  = new node at the apex of a regular tetrahedron over an existing triangle;
   stitch = new node completing an equilateral triangle over an existing edge, in a random plane.
Bonds form automatically between any two nodes at unit distance (within tol). No bond stretching.
Metropolis on E = -J*bonds + lam*sum_open_edges |gap|, where the gap is 2pi minus the dihedral sum of the
regular tets and octs actually present around the edge (an open edge is one whose ring is not closed)."""
import numpy as np, itertools, sys
from collections import defaultdict
rng=np.random.default_rng(int(sys.argv[2]) if len(sys.argv)>2 else 0)
lam=float(sys.argv[1]) if len(sys.argv)>1 else 0.0
TOL=0.08; TET=np.arccos(1/3); OCT=np.arccos(-1/3)

class Cluster:
    def __init__(s):
        s.P=[np.array([0,0,0.]),np.array([1,0,0.]),np.array([.5,np.sqrt(3)/2,0.]),np.array([.5,np.sqrt(3)/6,np.sqrt(2/3)])]
        s.adj=defaultdict(set); s.rebond()
    def rebond(s):
        P=np.array(s.P); d=np.linalg.norm(P[:,None]-P[None],axis=2); s.adj=defaultdict(set)
        for i,j in zip(*np.where((d>1-TOL)&(d<1+TOL))):
            if i<j: s.adj[i].add(j); s.adj[j].add(i)
        for i in range(len(P)): s.adj.setdefault(i,set())
    def nbonds(s): return sum(len(v) for v in s.adj.values())//2
    def tets(s):
        T=set()
        for a in s.adj:
            for b,c,d in itertools.combinations(sorted(x for x in s.adj[a] if x>a),3):
                if c in s.adj[b] and d in s.adj[b] and d in s.adj[c]: T.add((a,b,c,d))
        return T
    def octs(s):
        O=set(); adj=s.adj
        for a in adj:
            for b in adj[a]:
                if b<=a: continue
                for c in adj[a]&adj[b]:
                    if c<=b: continue
                    for ap in (adj[b]&adj[c])-adj[a]-{a}:
                        for bp in (adj[a]&adj[c]&adj[ap])-adj[b]-{b}:
                            for cp in (adj[a]&adj[b]&adj[ap]&adj[bp])-adj[c]-{c}:
                                O.add(tuple(sorted((a,b,c,ap,bp,cp))))
        return O
    def gap_energy(s):
        T=s.tets(); O=s.octs(); ang=defaultdict(float); faces=defaultdict(int)
        for t in T:
            for e in itertools.combinations(t,2): ang[e]+=TET
            for f in itertools.combinations(t,3): faces[f]+=1
        for o in O:
            for e in itertools.combinations(o,2):
                if e[1] in s.adj[e[0]]: ang[e]+=OCT
            for f in itertools.combinations(o,3):
                if all(y in s.adj[x] for x,y in itertools.combinations(f,2)): faces[f]+=1
        # an edge is 'interior-ish' if it has >=3 cells; gap = 2pi - angle sum (0 if closed)
        g=sum(abs(2*np.pi-a) for e,a in ang.items() if a>2*TET+1e-9)
        return g,len(T),len(O)
    def energy(s):
        g,nt,no=s.gap_energy(); return -s.nbonds()+lam*g, nt, no
    def try_add(s,pos):
        P=np.array(s.P); 
        if len(P) and np.linalg.norm(P-pos,axis=1).min()<0.9: return False
        s.P.append(pos); s.rebond(); return True
    def lift(s):
        T=list(s.tets())
        tris=set()
        for a in s.adj:
            for b in s.adj[a]:
                for c in s.adj[a]&s.adj[b]:
                    if a<b<c: tris.add((a,b,c))
        if not tris: return False
        a,b,c=list(tris)[rng.integers(len(tris))]; A,B,C=s.P[a],s.P[b],s.P[c]
        n=np.cross(B-A,C-A); n/=np.linalg.norm(n); cen=(A+B+C)/3
        return s.try_add(cen+rng.choice([-1,1])*np.sqrt(2/3)*n)
    def stitch(s):
        edges=[(a,b) for a in s.adj for b in s.adj[a] if a<b]
        if not edges: return False
        a,b=edges[rng.integers(len(edges))]; A,B=s.P[a],s.P[b]; m=(A+B)/2; u=B-A; u/=np.linalg.norm(u)
        v=np.cross(u,rng.normal(size=3)); v/=np.linalg.norm(v); w=np.cross(u,v)
        th=rng.uniform(0,2*np.pi)
        return s.try_add(m+(np.sqrt(3)/2)*(np.cos(th)*v+np.sin(th)*w))
    def remove(s):
        if len(s.P)<=4: return False
        i=rng.integers(len(s.P)); s.P.pop(i); s.rebond(); return True

def run(steps,T):
    c=Cluster(); E,_,_=c.energy(); acc=0
    for k in range(steps):
        backup=[p.copy() for p in c.P]
        mv=rng.choice(['lift','stitch','remove'],p=[0.45,0.45,0.10])
        ok=getattr(c,mv)()
        if not ok: continue
        E2,_,_=c.energy()
        if E2<E or rng.random()<np.exp(-(E2-E)/T): E=E2; acc+=1
        else: c.P=backup; c.rebond()
    return c

for T in (0.5,0.2):
    c=run(3000,T); N=len(c.P); g,nt,no=c.gap_energy()
    Z=np.array([len(v) for v in c.adj.values()])
    print(f"lam={lam} T={T}: N={N}, bonds/node={c.nbonds()/N:.2f}, tets/node={nt/N:.2f}, octs/node={no/N:.2f}, "
          f"gap sum={g:.2f}, max Z={Z.max()}, mean Z={Z.mean():.2f}")
