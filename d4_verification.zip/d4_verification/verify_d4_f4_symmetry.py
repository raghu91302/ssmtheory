import numpy as np, itertools as it

# Build W(F4) (order 1152, point group of D4 / the 24-cell) from simple-root reflections,
# and W(B4) (order 384, hypercubic) from signed permutations.
# Then compute dim of invariant homogeneous polynomials of each degree via the Reynolds
# projector. The DECISIVE quantity: dim of degree-4 invariants.
#   B4 -> 2  (|x|^4 AND the anisotropic sum x_mu^4)  => O(a^2) anisotropy allowed
#   F4 -> 1  (only |x|^4)                            => anisotropic operator FORBIDDEN to all orders

def reflect(alpha):
    a=np.array(alpha,float); 
    return np.eye(4)-2*np.outer(a,a)/np.dot(a,a)

# F4 simple roots
F4_simple=[(0,1,-1,0),(0,0,1,-1),(0,0,0,1),(0.5,-0.5,-0.5,-0.5)]
gens=[reflect(a) for a in F4_simple]

def close(gens, tol=1e-9, cap=5000):
    G=[np.eye(4)]; 
    def key(M): return tuple(np.round(M.flatten(),6))
    seen={key(np.eye(4))}
    frontier=[np.eye(4)]
    while frontier:
        nf=[]
        for M in frontier:
            for g in gens:
                P=g@M; k=key(P)
                if k not in seen:
                    seen.add(k); G.append(P); nf.append(P)
                    if len(G)>cap: return G
        frontier=nf
    return G
F4=close(gens); print("|W(F4)| =",len(F4),"(expect 1152)")

# B4 = signed permutations
B4=[]
for perm in it.permutations(range(4)):
    P=np.zeros((4,4))
    for i,p in enumerate(perm): P[i,p]=1
    for signs in it.product([1,-1],repeat=4):
        B4.append(P*np.array(signs)[:,None])
print("|W(B4)| =",len(B4),"(expect 384)")

# monomial basis of degree d in 4 vars
def monomials(d):
    return [e for e in it.product(range(d+1),repeat=4) if sum(e)==d]
def poly_rep(G,d):
    """matrix of how a group element permutes/ mixes degree-d monomials, averaged (Reynolds).
       Return dim of invariant subspace = rank of averaging projector."""
    mons=monomials(d); idx={m:i for i,m in enumerate(mons)}; n=len(mons)
    # Build averaging operator on coefficient space by sampling action on each monomial.
    # Action of g on variables: x_i -> sum_j g[i? ] ... polynomials compose with g^{-1}; use g acting x->g x.
    P=np.zeros((n,n))
    for g in G:
        # for each monomial x^e, (g.x)^e expand -> linear combo of monomials
        M=np.zeros((n,n))
        for col,e in enumerate(mons):
            # (prod_i (sum_j g[i,j] x_j)^{e_i})
            # expand via repeated convolution over monomials
            coeffs={(0,0,0,0):1.0}
            for i in range(4):
                for _ in range(e[i]):
                    new={}
                    for mono,c in coeffs.items():
                        for j in range(4):
                            if abs(g[i,j])<1e-12: continue
                            nm=list(mono); nm[j]+=1; nm=tuple(nm)
                            new[nm]=new.get(nm,0)+c*g[i,j]
                    coeffs=new
            for mono,c in coeffs.items():
                M[idx[mono],col]+=c
        P+=M
    P/=len(G)
    # dim invariants = rank of P (projector onto invariants), = trace rounded
    return int(round(np.trace(P))), P, mons

for d in [2,4,6]:
    fF,_,_=poly_rep(F4,d)
    fB,_,_=poly_rep(B4,d)
    print(f"degree {d}: dim invariants  F4={fF}   B4={fB}")

# Explicitly: project the anisotropic tensor sum x_mu^4 under each group
dimF,PF,mons=poly_rep(F4,4)
# coefficient vector of sum x_mu^4
v=np.zeros(len(mons))
for i,m in enumerate(mons):
    if m in [(4,0,0,0),(0,4,0,0),(0,0,4,0),(0,0,0,4)]: v[i]=1
projF=PF@v
# coefficient vector of |x|^4 = (sum x_mu^2)^2
w=np.zeros(len(mons))
def add(mon,c):
    w[mons.index(mon)]+=c
# (x1^2+x2^2+x3^2+x4^2)^2
for a in range(4):
    for b in range(4):
        e=[0,0,0,0]; e[a]+=2; e[b]+=2; w[mons.index(tuple(e))]+=1
print("\nF4-average of (sum x_mu^4): is it proportional to |x|^4 (isotropic)?")
# check projF parallel to w
mask=np.abs(w)>1e-9
ratio=projF[mask]/w[mask]
print("  ratio projF/|x|^4 on its support:",np.round(ratio,4),"-> constant =",np.allclose(ratio,ratio[0]))
print("  => under F4, the anisotropic quartic collapses to the isotropic invariant (no separate anisotropic invariant).")
