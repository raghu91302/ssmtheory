# D4 Lattice Gauge Theory — Verification Scripts

Numerical verification for **"Lattice Gauge Theory on the D4 Root Lattice:
Exact Dirac Factorization, Doubler Classification, and a Leading-Order
Isotropic Plaquette Action."**

Each script is self-contained and prints `... verified` on success. Every
nontrivial claim is cross-checked against the hypercubic lattice (whose
answers are textbook) so the method itself is validated, not just the D4 output.

## Requirements
    pip install -r requirements.txt        # numpy, sympy

## Scripts and the results they reproduce

| Script | Paper result | Checks |
|---|---|---|
| `verify_d4.py` | Sections 2–8 + Appendix | kissing number 24; structure tensor 12δ; slicing to FCC; Dirac factorization; 144 zeros in 4 classes; chirality sum 0−48+64−16=0; per-cell Wilson data (12 links, 32 triangles); stiffness coefficient c=48 with exact (δδ−δδ); Wilson masses {48,54,56,64}/a; su(3) closure/Jacobi/Casimir |
| `verify_d4_doubler_reduction.py` | Prop. 6 | reciprocal lattice 2πD4* index 2 over 2πZ⁴; 144 raw zeros → 72 Brillouin-zone-inequivalent (no fixed points); reduced chirality sum 0−24+32−8=0; Wilson term leaves exactly one massless fermion at Γ |
| `verify_d4_tree_matching.py` | Prop. 4 | tree-level coupling g_eff² = α/β with α = 2N/c_dens; D4 → α=N (g_eff²=N/β); hypercubic control → α=2N (recovers β=2N/g₀²) |
| `verify_d4_gauge_dispersion.py` | Prop. 7 | free gauge inverse propagator from plaquette form factors; hypercubic validated to machine precision; anisotropic Σk_μ⁴ coefficient −1/12 (hypercubic) vs 0 (D4); directional anisotropy scales as \|k\|² vs \|k\|⁴ |
| `verify_d4_f4_symmetry.py` | Prop. 8 | builds W(F4) (order 1152) and W(B4) (order 384); degree-4 invariant dimension 1 (F4) vs 2 (B4); averaging Σk_μ⁴ over F4 collapses it to the isotropic (\|k\|²)²; ⇒ rotational improvement protected to all orders |

## Run all

    for f in verify_d4*.py; do echo "== $f =="; python3 "$f"; done

## Notes
- `verify_d4.py` is the original base verifier; the four `verify_d4_*` scripts
  were added for the structural/perturbative results of the revised manuscript.
- All scripts are deterministic up to fixed RNG seeds used only for sampling
  random momenta/directions in validation loops.
