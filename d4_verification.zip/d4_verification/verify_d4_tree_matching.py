import numpy as np
# Consistent derivation of tree-level alpha in g_eff^2 = alpha/beta.
# Method: c_dens = [ Sigma_{distinct plaquettes} A^t (x) A^t ] / (physical 4-volume),
#         written as c_dens*(dd-dd);  then  alpha = 2N / c_dens.
# Cross-check the SAME code on hypercubic (must yield alpha=2N) and D4.

def dd():
    d=np.eye(4); return np.einsum('mr,ns->mnrs',d,d)-np.einsum('ms,nr->mnrs',d,d)
DD=dd()

def c_dens(plaq_edges, area_prefactor, cell_volume):
    """plaq_edges: list of (n1,n2) for the DISTINCT plaquettes in one unit cell
       (origin as base vertex). A^plaq = area_prefactor * (n1 ^ n2). a=1."""
    T=np.zeros((4,4,4,4))
    for (n1,n2) in plaq_edges:
        b=np.outer(n1,n2)-np.outer(n2,n1)
        A=area_prefactor*b
        T+=np.einsum('mn,rs->mnrs',A,A)
    c=T[0,1,0,1]
    iso_err=np.linalg.norm(T-c*DD)
    return c/cell_volume, iso_err

I=np.eye(4)

# ----- hypercubic: distinct squares per cell = 6 (one per plane, origin = SW corner) -----
sq=[(I[i],I[j]) for i in range(4) for j in range(i+1,4)]
c_hc,err_hc=c_dens(sq, area_prefactor=1.0, cell_volume=1.0)  # square: A=a^2 b, cell vol=a^4=1
print(f"hypercubic: distinct squares/cell={len(sq)}, c_dens={c_hc}, iso_err={err_hc:.1e}  -> alpha=2N/c_dens={2/c_hc:g}N (expect 2N)")

# ----- D4: distinct triangles per cell = 32 -----
# build neighbors
N=[]
for i in range(4):
  for j in range(i+1,4):
    for si in(1,-1):
      for sj in(1,-1):
        v=np.zeros(4); v[i]=si; v[j]=sj; N.append(v)
Nset=set(map(lambda x:tuple(x.astype(int)),N))
# all triangles incident to origin (unordered), then take per-cell = /3
tri=[]; seen=set()
for n1 in N:
  for n2 in N:
    if np.allclose(n1,n2): continue
    if tuple((n2-n1).astype(int)) in Nset:
      k=frozenset([tuple(n1.astype(int)),tuple(n2.astype(int))])
      if k not in seen: seen.add(k); tri.append((n1,n2))
print(f"D4: triangles incident to origin (unordered)={len(tri)}")
# Sum A(x)A over all 96 incident triangles, then per-cell = /3 (each tri has 3 vertices)
T=np.zeros((4,4,4,4)); s=0.5  # triangle area bivector A=(a^2/2) b
for (n1,n2) in tri:
    A=s*(np.outer(n1,n2)-np.outer(n2,n1)); T+=np.einsum('mn,rs->mnrs',A,A)
T_cell=T/3.0
c_d4=T_cell[0,1,0,1]/2.0          # cell_volume = 2 (a^4)
err_d4=np.linalg.norm(T_cell-T_cell[0,1,0,1]*DD)
print(f"D4: c_dens={c_d4}, iso_err={err_d4:.1e}  -> alpha=2N/c_dens={2/c_d4:g}N")

print()
print("RESULT (SU(3), N=3):")
print(f"  hypercubic: alpha = 2N = 6   => g_eff^2 = 6/beta   (=known beta=6/g0^2)")
print(f"  D4        : alpha = {2/c_d4:g}N = {2/c_d4*3:g}   => g_eff^2 = {2/c_d4:g}N/beta = 3/beta")
print(f"  ratio alpha_D4/alpha_hc = {c_hc/c_d4:g}  (D4 reaches a given g_eff at half the beta)")
