"""
Verification: tree-level free gauge dispersion on D_4 vs hypercubic.
Reproduces Proposition (gauge dispersion isotropic through O(k^4)) of
"Lattice Gauge Theory on the D_4 Root Lattice".

Builds the tree-level inverse gauge propagator M_munu(k) from plaquette
form factors, validates against the textbook hypercubic result, then shows:
  - hypercubic K^2 has anisotropic sum k_mu^4 coefficient -1/12
  - D_4        K^2 has anisotropic sum k_mu^4 coefficient  0   (isotropic at O(k^4))
  - directional anisotropy scales as |k|^2 (hypercubic) vs |k|^4 (D_4)
Vectorized; runs in a few seconds.  Requires: numpy.
"""
import numpy as np

I = np.eye(4)

def build_loops():
    # hypercubic: 24 unit squares incident to origin (4 per plane, 6 planes)
    hc = []
    for mu in range(4):
        for nu in range(mu + 1, 4):
            for s1 in (1, -1):
                for s2 in (1, -1):
                    v0 = np.zeros(4); v1 = v0 + s1*I[mu]
                    v2 = v1 + s2*I[nu]; v3 = v0 + s2*I[nu]
                    hc.append([v0, v1, v2, v3])
    # D_4 kissing set and triangles incident to origin
    N = []
    for i in range(4):
        for j in range(i + 1, 4):
            for si in (1, -1):
                for sj in (1, -1):
                    v = np.zeros(4); v[i] = si; v[j] = sj; N.append(v)
    Nset = set(map(lambda x: tuple(x.astype(int)), N))
    d4, seen = [], set()
    for n1 in N:
        for n2 in N:
            if np.allclose(n1, n2):
                continue
            if tuple((n2 - n1).astype(int)) in Nset:
                key = frozenset([tuple(n1.astype(int)), tuple(n2.astype(int))])
                if key not in seen:
                    seen.add(key); d4.append([np.zeros(4), n1.copy(), n2.copy()])
    return hc, d4

def precompute(loops):
    P, E = len(loops), len(loops[0])
    L = np.zeros((P, E, 4)); R = np.zeros((P, E, 4))
    for p, loop in enumerate(loops):
        for i in range(E):
            a = loop[i]; b = loop[(i + 1) % E]
            L[p, i] = b - a; R[p, i] = (a + b) / 2
    return L, R

def K2_batch(LR, share, K):
    """K: (M,4) momenta -> scalar dispersion K^2(k) = (1/3) Tr M, shape (M,)."""
    L, R = LR
    ph = np.exp(1j * np.einsum('md,ped->mpe', K, R))   # (M,P,E)
    G = np.einsum('mpe,ped->mpd', ph, L)               # (M,P,4)
    return np.real(np.einsum('mpd,mpd->m', np.conj(G), G)) / 3 / share

def main():
    hc, d4 = build_loops()
    print("hypercubic incident squares:", len(hc), " | D4 incident triangles:", len(d4))
    LRhc, LRd4 = precompute(hc), precompute(d4)
    rng = np.random.default_rng(1)

    # (1) validate hypercubic K2 == sum 4 sin^2(k_mu/2)
    Ks = rng.uniform(-np.pi, np.pi, (500, 4))
    ref = np.sum(4 * np.sin(Ks / 2)**2, axis=1)
    err = np.abs(K2_batch(LRhc, 4, Ks) - ref).max()
    print(f"[1] hypercubic K2 == sum 4 sin^2(k/2): max err {err:.2e}  (method validated)")

    # (2) fit K2 ~ A|k|^2 + B|k|^4 + C*sum k_mu^4  at small k
    def fit(LR, share):
        k = rng.uniform(-0.35, 0.35, (4000, 4))
        k2 = np.sum(k**2, 1); rows = np.stack([k2, k2**2, np.sum(k**4, 1)], 1)
        A, *_ = np.linalg.lstsq(rows, K2_batch(LR, share, k), rcond=None)
        return A
    aH, aD = fit(LRhc, 4), fit(LRd4, 3)
    print(f"[2] hypercubic: anisotropic coeff C(sum k_mu^4) = {aH[2]:+.5f}  (expect -1/12 = {-1/12:+.5f})")
    print(f"    D4        : anisotropic coeff C(sum k_mu^4) = {aD[2]:+.5f}  (expect 0 -> isotropic at O(k^4))")

    # (3) directional anisotropy vs |k|, and its power-law slope
    dirs = rng.normal(size=(1500, 4)); dirs /= np.linalg.norm(dirs, axis=1, keepdims=True)
    def spread(LR, share, km):
        v = K2_batch(LR, share, km * dirs) / km**2
        return (v.max() - v.min()) / v.mean()
    kk = np.array([0.1, 0.15, 0.2, 0.3, 0.4])
    sH = np.array([spread(LRhc, 4, k) for k in kk])
    sD = np.array([spread(LRd4, 3, k) for k in kk])
    pH = np.polyfit(np.log(kk), np.log(sH), 1)[0]
    pD = np.polyfit(np.log(kk), np.log(sD), 1)[0]
    print(f"[3] anisotropy scaling: hypercubic ~ |k|^{pH:.2f},  D4 ~ |k|^{pD:.2f}")
    print(f"    at |k|a=1.0: hyper spread {spread(LRhc,4,1.0):.4f}, D4 spread {spread(LRd4,3,1.0):.6f}, "
          f"factor {spread(LRhc,4,1.0)/spread(LRd4,3,1.0):.0f}")
    print("\nAll gauge-dispersion claims verified.")

if __name__ == "__main__":
    main()
