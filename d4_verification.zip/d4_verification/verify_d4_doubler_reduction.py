import numpy as np, itertools as it
from fractions import Fraction as Fr
from collections import Counter, defaultdict

PI=np.pi
# D4 neighbors
N=[]
for i in range(4):
    for j in range(i+1,4):
        for si in (1,-1):
            for sj in (1,-1):
                v=[0,0,0,0]; v[i]=si; v[j]=sj; N.append(np.array(v))

def f(k):
    c=np.cos(k); return np.array([4*np.sin(k[m])*(c.sum()-c[m]) for m in range(4)])
def J(k):
    Jm=np.zeros((4,4))
    for n in N: Jm+=np.outer(n,n)*np.cos(np.dot(k,n))
    return Jm
def mW(k):  # r=1,a=1, 2*sum(1-cos)
    return 2*sum(1-np.cos(np.dot(k,n)) for n in N)

# ---- 1. Enumerate the 144 zeros exactly on the pi/6 grid, in [0,2pi) ----
# angles as integer multiples of pi/6: 0..11
grid=[Fr(m,6) for m in range(12)]   # in units of pi
def ang(fr): return float(fr)*PI
zeros=[]
for combo in it.product(range(12),repeat=4):
    k=np.array([ang(Fr(m,6)) for m in combo])
    if np.abs(f(k)).max()<1e-9:
        zeros.append(combo)
print("raw zeros in [0,2pi)  (Z^4 BZ):", len(zeros))

def klass(combo):
    # number of axes with sin=0  => k in {0,pi} i.e. multiple of 6 -> m in {0,6}
    nS=sum(1 for m in combo if m in (0,6))
    return {4:'Case1',2:'L2',1:'L3',0:'L4'}.get(nS,'other')
cnt=Counter(klass(z) for z in zeros)
print("raw by class:", dict(cnt))

# ---- 2. Quotient by the pi(1,1,1,1) shift: add 6 (mod 12) to each component ----
def shift(combo): return tuple((m+6)%12 for m in combo)
seen=set(); orbits=[]
for z in zeros:
    z=tuple(z)
    if z in seen: continue
    s=shift(z); seen.add(z); seen.add(s)
    orbits.append((z,s))
print("\nfixed points under pi(1,1,1,1):", sum(1 for z in zeros if shift(tuple(z))==tuple(z)))
print("reduced inequivalent zeros (D4 BZ):", len(orbits))
ocnt=Counter(klass(o[0]) for o in orbits)
print("reduced by class:", dict(ocnt))

# ---- 3. Chirality: check both members of each orbit share chirality; sum over orbits ----
def chi(combo):
    k=np.array([ang(Fr(m,6)) for m in combo]); d=np.linalg.det(J(k))
    return int(np.sign(d)), d
eq=True; classsum=Counter(); tot=0; degen=0
for (a,b) in orbits:
    ca,da=chi(a); cb,db=chi(b)
    if abs(da)<1e-6 or abs(db)<1e-6: degen+=1
    if ca!=cb: eq=False
    classsum[klass(a)]+=ca; tot+=ca
print("\nany orbit with degenerate (det J=0) member:", degen)
print("both members share chirality in every orbit:", eq)
print("reduced chirality sum  Σχ:", tot)
print("reduced chirality by class:", dict(classsum))

# ---- 4. Wilson: which reduced zeros stay massless? ----
massless=[o for o in orbits if mW(np.array([ang(Fr(m,6)) for m in o[0]]))<1e-9]
print("\nreduced zeros with m_W = 0 (physical massless fermions):", len(massless))
for o in massless:
    print("   massless at (units of pi/6):", o[0], " == Gamma/all-pi orbit")
# tabulate m_W per class (representative)
print("m_W by class (representative value):")
for cl in ['Case1','L2','L3','L4']:
    reps=[o[0] for o in orbits if klass(o[0])==cl]
    vals=sorted({round(mW(np.array([ang(Fr(m,6)) for m in r])),3) for r in reps})
    print(f"   {cl}: m_W ∈ {vals}")

# ---- 5. Independent cross-check on a brute L=12 momentum grid (no class assumptions) ----
# already enumerated full grid above => zeros count is the brute count. Confirm 144 and 72.
print("\ncross-check: brute grid gave", len(zeros), "raw ->", len(orbits), "reduced")

# ---- 6. hypercubic sanity: naive Z^4 has 16 zeros, self-dual, no reduction ----
hz=[c for c in it.product((0,6),repeat=4)]  # sin(k)=0
print("hypercubic sanity (sin k_mu=0): 16 zeros, no D4-style glue -> 16 species:", len(hz))
