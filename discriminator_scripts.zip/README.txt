Verification script for "Distinguishing a Two-Step Quantum-Classical Threshold
from Collapse Models" (R. Kulkarni, 2026).

Run:       python3 verify_discriminators.py      (requires numpy)
Expected:  31x PASS, then ALL PASS (a few minutes).

Sections of the script, with the part of the paper each supports:
  0   the published thresholds m_soft, m_hard and the ratio sqrt(3)  (Section 3)
  1   the Diosi-Penrose self-energy of a uniform sphere, checked
      against a noise-free Fourier-space integral                    (Section 4.1)
  2   equal mass, different density (Diosi-Penrose)                  (Section 5, Table 1)
  3   Diosi-Penrose collapse times below m_soft; dependence on L     (Sections 6 and 11, Table 2)
  3b  CSL: the decoherence formula against the single-nucleon rate;
      the XENONnT bound at r_C = 1e-7 m;
      equal-mass ratios; collapse times; heating                     (Sections 4.2, 5, 6, 7; Tables 1, 2)
  3c  the constraint from Bild et al. (2023)                         (Section 8)
  3d  the worked example                                             (Section 10.3, Table 5)
  3e  where experiments stand: masses and gaps                       (Section 10.1, Table 3)
  4   which irreversible channels heat, free and trapped (including
      L = f(H)), with the trapped formula tested at several masses;
      the LISA Pathfinder bound                                      (Section 7)
  5   the Hahn echo on a static versus a stochastic phase            (Section 9)
