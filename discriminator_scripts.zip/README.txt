Verification script for "Distinguishing a Two-Step Quantum-Classical Threshold
from Collapse Models" (R. Kulkarni, 2026).

Run:       python3 verify_discriminators.py      (requires numpy)
Expected:  46x PASS, then ALL PASS (a few seconds).

Sections of the script, with the part of the paper each supports:
  0   the published thresholds m_soft, m_hard and the ratio sqrt(3)  (Section 3)
  1   the Diosi-Penrose self-energy of a uniform sphere, checked
      against a noise-free Fourier-space integral                    (Section 4.1)
  2   equal mass, different density (Diosi-Penrose)                  (Section 5, Table 1)
  3   Diosi-Penrose collapse times below m_soft; dependence on L     (Sections 6 and 11, Table 2)
  3b  CSL: the decoherence formula against the single-nucleon rate;
      the XENONnT bound at r_C = 1e-7 m;
      equal-mass ratios; collapse times; heating                     (Sections 4.2, 5, 6, 7; Tables 1, 2)
  3c  the conditional constraint from Bild et al. (2023), for the
      rms (16.2 ug) and maximum-displacement (1.0 ug) masses         (Section 8)
  3d  the worked example                                             (Section 10.4, Table 6)
  3e  where experiments stand: masses and gaps                       (Section 10.1, Table 3)
  4   which irreversible channels heat, free and trapped (including
      L = f(H)), with the trapped formula tested at several masses;
      the LISA Pathfinder bound, recomputed at L = 2.8 l_P           (Sections 7, 11)
  5   the Hahn echo on a static versus a stochastic phase            (Section 9)
  6   revision checks: the Compton-scale correction on the motion,
      the soccer-ball estimate and the equivalent beta0             (Section 3, Section 2.5)
      classical phase stability of a 1 kg pendulum                   (Section 7.4)
      energy dephasing (L = n) versus localization (L = x) on an
      oscillator: phonon-number statistics                           (Section 7.5)
      E_G = I(0) - I(d) and the overlap integral                     (Appendix A)
      the silica radius at m_soft and d/R                            (Table 1)
      every entry of Tables 1 and 2                                  (Sections 5, 6)
      Gamma_0 at m_soft equals the Compton frequency c/L             (Section 3)
      flat entanglement spectrum of the calibration entropy          (Section 2.3)

Repository copy: https://github.com/raghu91302/ssmtheory/raw/main/discriminator_scripts.zip
