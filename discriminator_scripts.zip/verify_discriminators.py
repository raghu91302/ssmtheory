#!/usr/bin/env python3
"""Checks for 'Four discriminators between the SSM two-step threshold and Diosi-Penrose collapse'.
Run: python3 verify_discriminators.py   (needs numpy)"""
import numpy as np
ok=True
def check(name,cond):
    global ok; ok&=bool(cond); print(("PASS  " if cond else "FAIL  ")+name)
G=6.67430e-11; hbar=1.054571817e-34; c=2.99792458e8
lP=np.sqrt(hbar*G/c**3); mP=np.sqrt(hbar*c/G); L=1.665*lP
m_soft=hbar/(L*c); m_hard=np.sqrt(3)*m_soft
def EG(m,R,d):
    lam=d/(2*R); f=np.where(lam<=1,2*lam**2-1.5*lam**3+0.2*lam**5,1.2-1/(2*lam)); return G*m**2/R*f
def EG_fourier(m,R,d,K=4000.0,n=400001):
    k=np.linspace(1e-6,K/R,n); q=k*R; Fq=3*(np.sin(q)-q*np.cos(q))/q**3
    return 2*G*m**2/np.pi*np.trapezoid(Fq**2*(1-np.sinc(k*d/np.pi)),k)
m0=1.66053906660e-27; rC=1e-7
def Gamma_CSL(m,R,d,lam,rC=rC,n=800001):
    k=np.linspace(1e-9/rC,8.0/rC,n); q=k*R
    F=np.where(q>1e-6,3*(np.sin(q)-q*np.cos(q))/np.maximum(q,1e-30)**3,1.0)
    return lam/m0**2*(4*np.pi*rC**2)**1.5*m**2*np.trapezoid(4*np.pi*k**2/(2*np.pi)**3*np.exp(-(k*rC)**2)*F**2*(1-np.sinc(k*d/np.pi)),k)
R_of=lambda m,rho:(3*m/(4*np.pi*rho))**(1/3)

print("=== 0. The published thresholds")
check(f"m_soft = hbar/(Lc) = {m_soft*1e9:.2f} ug, m_hard = {m_hard*1e9:.2f} ug, ratio sqrt(3)",
      abs(m_soft*1e9-13.07)<0.05 and abs(m_hard*1e9-22.64)<0.05 and abs(m_hard/m_soft-np.sqrt(3))<1e-12)

print("=== 1. Diosi-Penrose self-energy of a uniform sphere")
m,R=1e-9,50e-6
check("closed form agrees with a noise-free Fourier integral to 0.01% for d/R = 0.001 ... 8",
      all(abs(EG(m,R,d)-EG_fourier(m,R,d))/EG(m,R,d)<1e-4 for d in (5e-8,5e-6,25e-6,1e-4,4e-4)))
check("small-separation limit E_G -> G m^2 d^2 / (2 R^3) (relative correction 0.75 d/2R)", abs(EG(m,R,1e-12)/(G*m**2*1e-24/(2*R**3))-1)<1e-6)

print("=== 2. Prediction 1: equal mass, different density")
m=m_soft; rs,rg=2200,19300
t=lambda rho,d: hbar/EG(m,R_of(m,rho),d)
check(f"dx = 1 nm << R: tau_DP(silica)/tau_DP(gold) = {t(rs,1e-9)/t(rg,1e-9):.3f} = density ratio {rg/rs:.3f}",
      abs(t(rs,1e-9)/t(rg,1e-9)-rg/rs)/(rg/rs)<1e-3)
check(f"dx = 1 mm: gold still collapses faster, by {t(rs,1e-3)/t(rg,1e-3):.2f}x (cube root of density ratio {(rg/rs)**(1/3):.2f}, approached as dx/R grows)",
      t(rs,1e-3)/t(rg,1e-3)>1.5)
check("SSM thresholds depend on m only: identical for every material (by P3)", True)
check("internal energy shifts the rest mass of a room-temperature body by < 1e-11", 800*300/c**2<1e-11)

print("=== 3. Prediction 2: DP collapse well below m_soft (silica)")
tt=lambda m,d: hbar/EG(m,R_of(m,2200),d)
check(f"1e-15 kg over 1 um: tau_DP = {tt(1e-15,1e-6):.2f} s (order 1 s)", 0.1<tt(1e-15,1e-6)<10)
check(f"1 ng over 1 um: tau_DP = {tt(1e-12,1e-6):.1e} s (sub-ms)", tt(1e-12,1e-6)<1e-3)
check(f"1 ug over 1 nm: tau_DP = {tt(1e-9,1e-9):.2f} s (sub-second)", tt(1e-9,1e-9)<1)
check("all these masses are below m_soft (SSM: no intrinsic decoherence)", max(1e-15,1e-12,1e-9)<m_soft)

ms28=hbar/(2.8*lP*c)
check(f"for L up to 2.8 l_P, m_soft = {ms28*1e9:.1f} ug stays above every mass in Table 2 (largest 1 ug); the L^-4 margin moves by {4*np.log10(2.8/1.665):.2f} < 1 order",
      ms28>1e-9 and abs(ms28*1e9-7.8)<0.05 and 4*np.log10(2.8/1.665)<1)
print("=== 3b. CSL (r_C = 1e-7 m)")
check("CSL formula reproduces the single-nucleon rate lam(1 - exp(-d^2/4 r_C^2)) exactly",
      all(abs(Gamma_CSL(m0,1e-15,d,1e-16)/(1e-16*(1-np.exp(-d**2/(4*rC**2))))-1)<1e-6 for d in (2e-8,1e-7,3e-7,1e-6)))
mm=m_soft; g=lambda rho,d: Gamma_CSL(mm,R_of(mm,rho),d,1.0)
r1,r2=g(19300,1e-3)/g(2200,1e-3), g(19300,1e-9)/g(2200,1e-9)
check(f"CSL, equal mass: gold collapses {r1:.2f}x faster than silica at 1 mm (density ratio 8.77) and {r2:.1f}x at 1 nm",
      abs(r1-19300/2200)/(19300/2200)<0.01 and r2>15)
lam_X=3.0e-3*rC**2          # XENONnT (2026): lambda/r_C^2 < 3.0e-3 s^-1 m^-2 (90% C.L.), Markovian CSL
check(f"XENONnT bound at r_C = 1e-7 m: lambda < {lam_X:.1e} 1/s, below the GRW value 1e-16 by a factor {1e-16/lam_X:.1f}",
      abs(lam_X/3e-17-1)<1e-9 and 1e-16>lam_X)
tb=1/Gamma_CSL(1e-15,R_of(1e-15,2200),1e-6,lam_X)
check(f"CSL at the XENONnT bound, 1e-15 kg over 1 um: {tb:.1e} s (about a microsecond)", abs(tb/1.43e-6-1)<0.05)
hX=0.75*lam_X*hbar**2/(m0**2*rC**2)
check(f"CSL heating of 1 kg at the XENONnT bound: {hX:.1e} W", abs(hX/9.0e-18-1)<0.05)
print("=== 3c. A constraint from Bild et al. (2023): effective mass 16.2 ug, coherence for up to 40 us")
mB=16.2e-9; xB=mB/m_soft; GwB=hbar/(mB*L**2)*(xB**2-1)**2
check(f"m/m_soft = {xB:.3f}; full-scale window rate {GwB:.1e} 1/s exceeds 1/(40 us) by 10^{np.log10(GwB*40e-6):.0f}; delta = {xB**2/6:.3f}",
      abs(xB-1.239)<0.002 and np.log10(GwB*40e-6)>37 and abs(xB**2/6-0.256)<0.002)
print("=== 3d. Worked example")
Rn=100e-9; mn=2200*4/3*np.pi*Rn**3
tdpn=hbar/EG(mn,Rn,100e-9); tgn=1/Gamma_CSL(mn,Rn,100e-9,lam_X)
check(f"100 nm silica nanosphere over 100 nm: DP {tdpn:.1e} s, CSL at the XENONnT bound {tgn:.1e} s",
      abs(tdpn/5.8e3-1)<0.05 and abs(tgn/7.7e-3-1)<0.05)
print("=== 3e. Where experiments stand")
m_rec=172e3*1.66053906660e-27; m_np=2200*4/3*np.pi*(100e-9)**3
check(f"spatial-superposition record: 172 kDa = {m_rec:.1e} kg; worked-example spheres are 10^{np.log10(m_np/m_rec):.1f} and 10^{np.log10(1e-15/m_rec):.1f} times heavier",
      abs(m_rec/2.86e-22-1)<0.01 and abs(np.log10(m_np/m_rec)-4.5)<0.1 and abs(np.log10(1e-15/m_rec)-6.5)<0.1)
check(f"the 10 kg LIGO mirror is {10/m_hard:.0e} times m_hard; the 1 fg ground-state nanoparticle is {1e-18/m_soft:.0e} times m_soft",
      10/m_hard>1e8 and 1e-18/m_soft<1e-9)
print("=== 4. Prediction 3: which channels heat")
N=128; Lb=40.0; x=(np.arange(N)-N/2)*Lb/N; dx=Lb/N; k=2*np.pi*np.fft.fftfreq(N,d=dx)
F=np.fft.fft(np.eye(N),axis=0)/np.sqrt(N); P2=F.conj().T@np.diag(k**2)@F; H=0.5*P2; X=np.diag(x)
D=lambda Lo,r: Lo@r@Lo.conj().T-0.5*(Lo.conj().T@Lo@r+r@Lo.conj().T@Lo)
psi=np.exp(-(x-6)**2/4)+np.exp(-(x+6)**2/4); psi/=np.linalg.norm(psi); rho=np.outer(psi,psi)
dA=D(P2,rho); dB=D(X,rho)
check("momentum-diagonal channel (L commutes with H): no heating", abs(np.trace(H@dA).real)<1e-10)
check("momentum-diagonal channel: momentum distribution, hence far-field fringes, unchanged", np.abs(np.diag(F@dA@F.conj().T)).max()<1e-10)
check("position-localizing channel (L = x): heats at exactly gamma hbar^2/(2m)", abs(np.trace(H@dB).real-0.5)<1e-9)
def trap_heat(hb,mm,ww,Ll,channel):
    Na=90; a_=np.diag(np.sqrt(np.arange(1,Na)),1)
    xo=np.sqrt(hb/(2*mm*ww))*(a_+a_.T); po=1j*np.sqrt(hb*mm*ww/2)*(a_.T-a_)
    Ho=po@po/(2*mm)+0.5*mm*ww**2*xo@xo
    Lo=(Ll**2/hb**2)*(po@po) if channel=="p" else Ho/(hb*ww)
    w_=np.exp(-np.arange(Na)/1.5); w_[12:]=0; w_/=w_.sum(); ro=np.diag(w_).astype(complex)
    return hb/(mm*Ll**2)*np.real(np.trace(Ho@D(Lo,ro))), np.real(np.trace(po@po@ro))
cases=[(1.0,1.0,1.0,0.3),(1.0,3.0,1.0,0.3),(2.0,5.0,0.7,0.2)]
okf=all(abs(trap_heat(*cs,"p")[0]-2*cs[2]**2*cs[3]**2*trap_heat(*cs,"p")[1]/cs[0])<1e-8 for cs in cases)
Ptrap=2*(2*np.pi)**2*L**2*(1.0*1.380649e-23*300)/hbar
check(f"in a trap, L = (L p/hbar)^2 at rate hbar/(m L^2) heats at 2 w^2 L^2 <p^2>/hbar for m = 1, 3, 5 (no extra factor of m); 1 kg at 1 Hz, 300 K: {Ptrap:.1e} W",
      okf and Ptrap<1e-50)
check("a channel diagonal in the Hamiltonian, L = f(H), produces no heating in a trap", abs(trap_heat(1.0,2.0,1.5,0.3,"H")[0])<1e-10)
mT=1.928; Gam0=hbar/(mT*L**2); Gmax=((1e-15)**2/2)*L**2/hbar**2
P_pos=Gam0*hbar**2/L**2/(2*mT)
check(f"a position-localizing channel at length L and the published rate would heat the 1.93 kg test mass at {P_pos:.1e} W", abs(P_pos/3e35-1)<0.1)
check(f"a position-localizing breakdown at the published rate scale exceeds the LISA Pathfinder bound by {np.log10(Gam0/Gmax):.0f} orders",
      np.log10(Gam0/Gmax)>60)

print("=== 5. Prediction 4: Hahn echo")
rng=np.random.default_rng(7)
def run(shift,gamma,echo,shots=3000,steps=300,T=1.0):
    dt=T/steps; z=[]
    for s in range(shots):
        n=rng.normal(0,np.sqrt(2*gamma*dt),steps) if gamma else np.zeros(steps)
        d=shift*dt+n; d[steps//2:]*= -1 if echo else 1; z.append(np.exp(1j*d.sum()))
    return np.mean(z)
zr=run(25.0,0,False); ze=run(25.0,0,True)
check("static shift: contrast fully preserved, phase = shift*T without echo", abs(abs(zr)-1)<1e-9 and abs(np.angle(zr)-np.angle(np.exp(25j)))<1e-9)
check("static shift: Hahn echo returns the phase to zero", abs(np.angle(ze))<1e-9 and abs(abs(ze)-1)<1e-9)
zs=run(0,1.0,True); check(f"stochastic dephasing survives the echo: contrast {abs(zs):.3f} ~ exp(-1) = 0.368", abs(abs(zs)-np.exp(-1))<0.05)

print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
