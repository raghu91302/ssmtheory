#!/usr/bin/env python3
"""Color kinematics of the D3 code (the spatial slice of D4).

A. Parity theorem.  Every edge has two endpoints (H_Z column weight 2) and lies
   in exactly two octahedra (H_X column weight 2), so any Pauli operator
   anticommutes with an even number of vertex checks and an even number of
   void checks.  Verified exhaustively on the 4^6 - 1 = 4095 non-identity Pauli
   operators supported on a chordless {111} hexagon: no operator flips exactly
   one vertex check.
B. Color link template.  Exactly two X-supports on a hexagon are charged at an
   antipodal vertex pair with no void syndrome (the two half-hexagons); their
   sum, the hexagon loop, lies outside the X-stabilizer group; the three
   antipodal-pair strings pairwise overlap; composing one route per pair gives
   the alternating edge triple (charging all six vertices), never the loop.
Requires numpy only.
"""
import numpy as np
from itertools import product, combinations

failures = []
def check(cond, msg):
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond: failures.append(msg)

NN = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]

def build(L):
    nodes = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 0]
    nid = {p: i for i, p in enumerate(nodes)}
    add = lambda p, d: tuple((p[k] + d[k]) % L for k in range(3))
    edges = []; eid = {}
    for p in nodes:
        for d in NN:
            q = add(p, d)
            if q in nid and nid[p] < nid[q]:
                eid[(p, q)] = len(edges); edges.append((p, q))
    E = lambda p, q: eid[(p, q)] if (p, q) in eid else eid[(q, p)]
    voids = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 1]
    AX = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 1]
    HZ = np.zeros((len(nodes), len(edges)), np.uint8)
    for k, (p, q) in enumerate(edges): HZ[nid[p], k] = 1; HZ[nid[q], k] = 1
    HX = np.zeros((len(voids), len(edges)), np.uint8)
    for oi, o in enumerate(voids):
        nb = [add(o, a) for a in AX]
        for a, b in combinations(nb, 2):
            if (a, b) in eid or (b, a) in eid: HX[oi, E(a, b)] = 1
    return nodes, nid, edges, E, HZ, HX, add

def gf2rank(M):
    M = M.copy() % 2; r = 0; rows, cols = M.shape
    for c in range(cols):
        p = np.nonzero(M[r:, c])[0]
        if len(p) == 0: continue
        p = p[0] + r; M[[r, p]] = M[[p, r]]; m = np.nonzero(M[:, c])[0]; m = m[m != r]; M[m] ^= M[r]; r += 1
        if r == rows: break
    return r

# ------------------------------------------------------------------ A
print("A. PARITY THEOREM (L = 4)")
L = 4
nodes, nid, edges, E, HZ, HX, add = build(L)
check(HZ.shape == (32, 192) and HX.shape == (32, 192) and not (HX.astype(int) @ HZ.T.astype(int) % 2).any(),
      "D3 code rebuilt: 192 qubits, 32 vertex checks, 32 void checks, CSS")
check(set(HZ.sum(0)) == {2}, "every edge has exactly two endpoints (H_Z column weight 2)")
check(set(HX.sum(0)) == {2}, "every edge lies in exactly two octahedra (H_X column weight 2)")
# chordless {111} hexagon: the six in-plane neighbors of a site
o = (0, 0, 0)
hexv = [(1, -1, 0), (1, 0, -1), (0, 1, -1), (-1, 1, 0), (-1, 0, 1), (0, -1, 1)]   # cyclic order, 60 deg apart
hexv = [add(o, d) for d in hexv]
hexE = [E(hexv[i], hexv[(i + 1) % 6]) for i in range(6)]
chordless = all(not ((hexv[i], hexv[j]) in {(p, q) for p, q in edges} or (hexv[j], hexv[i]) in {(p, q) for p, q in edges})
                for i, j in combinations(range(6), 2) if (j - i) % 6 not in (1, 5))
check(len(set(hexE)) == 6 and chordless, "chordless hexagonal six-cycle located in a {111} plane")
n_even = 0; n_single = 0; n_tot = 0
for op in product(range(4), repeat=6):        # 0=I 1=X 2=Y 3=Z per hexagon edge
    if not any(op): continue
    n_tot += 1
    x = np.zeros(192, np.uint8); z = np.zeros(192, np.uint8)
    for k, t in enumerate(op):
        if t in (1, 2): x[hexE[k]] = 1
        if t in (2, 3): z[hexE[k]] = 1
    vflip = int((HZ.astype(int) @ x % 2).sum()); oflip = int((HX.astype(int) @ z % 2).sum())
    if vflip % 2 == 0 and oflip % 2 == 0: n_even += 1
    if vflip == 1: n_single += 1
print(f"  {n_tot} non-identity Pauli operators on the hexagon: {n_even} with even vertex and even void syndrome, {n_single} single-vertex-charged")
check(n_tot == 4095 and n_even == 4095 and n_single == 0, "no single-endpoint color-charged operator exists on the strong channel (0 of 4095)")

# ------------------------------------------------------------------ B
print("\nB. COLOR LINK TEMPLATE ON THE HEXAGON (L = 4)")
hexid = {hexv[i]: i for i in range(6)}
routes = {}
for mask in range(1, 64):
    x = np.zeros(192, np.uint8)
    for k in range(6):
        if mask >> k & 1: x[hexE[k]] = 1
    vs = HZ.astype(int) @ x % 2; os_ = HX.astype(int) @ x % 2
    if vs.sum() == 2:
        charged = tuple(sorted(hexid[nodes[i]] for i in np.nonzero(vs)[0] if nodes[i] in hexid))
        if len(charged) == 2 and (charged[1] - charged[0]) == 3:
            routes.setdefault(charged, []).append(mask); voids_disturbed = int(os_.sum())
print("  antipodal pairs and their charged X-supports (weights):", {k: [bin(m).count('1') for m in v] for k, v in routes.items()})
check(len(routes) == 3 and all(len(v) == 2 and all(bin(m).count('1') == 3 for m in v) for v in routes.values()),
      "each antipodal pair is connected by exactly two X-supports on the hexagon, the two half-hexagon routes of weight 3")
check(voids_disturbed == 6, "each route disturbs 6 void checks (2 per edge, none shared), two per edge, none shared")
loop = np.zeros(len(edges), np.uint8); loop[hexE] = 1
rX = gf2rank(HX)
check(gf2rank(np.vstack([HX, loop[None, :]])) == rX + 1, "the hexagon loop (difference of the two routes) lies outside the X-stabilizer group: the phase between routes is physical")
pairs = list(routes.keys())
overlap = all(any((routes[a][i] & routes[b][j]) for i in range(2) for j in range(2)) for a, b in combinations(pairs, 2))
check(overlap, "the three color strings pairwise overlap on hexagon edges (phases not independently diagonalizable)")
loopmask = 63; n_loop = 0; n_alt = 0
for choice in product(range(2), repeat=3):
    comp = 0
    for pr, c in zip(pairs, choice): comp ^= routes[pr][c]
    if comp == loopmask: n_loop += 1
    if comp in (0b010101, 0b101010): n_alt += 1
print(f"  compositions of one route per pair: {n_loop} of 8 give the hexagon loop, {n_alt} of 8 give an alternating edge triple")
check(n_loop == 0 and n_alt == 8, "the three color strings compose to the alternating edge triple (a junction charging all six vertices), never to the neutral loop")

print()
if failures:
    print(f"{len(failures)} check(s) failed:"); [print("  -", f) for f in failures]; raise SystemExit(1)
print("All color-kinematics checks passed.")
