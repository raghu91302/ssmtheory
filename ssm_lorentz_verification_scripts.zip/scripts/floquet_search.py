"""Search for a Floquet measurement schedule on the SSM FCC code that exchanges the two kinds of check.
Periodic box of side 4 (units h = a/2): 32 nodes, 32 octahedral voids, 192 bond qubits.
State: Bell pairs between the 192 code qubits and 192 reference qubits (pure stabilizer state, 384
generators). Measuring a system Pauli P: if P commutes with every generator it is already in the group;
otherwise the standard update. Logical qubits that survive = S(R) = rank(proj_system G) - 192.
Self-duality Phi = (translation by e1) o (X<->Z). A schedule is s followed by Phi(s); we look for
schedules where (i) logical qubits survive indefinitely, and (ii) the instantaneous stabilizer group
contains all Z-stars but not all X-stars at some step (and, by symmetry, the reverse half a period later)."""
import numpy as np, itertools, sys
L=4; n=192; N=2*n; W=(2*N+63)//64
pts=lambda par:[p for p in itertools.product(range(L),repeat=3) if sum(p)%2==par]
nodes,octs=pts(0),pts(1)
nn=[d for d in itertools.product((-1,0,1),repeat=3) if sum(map(abs,d))==2]
wrap=lambda p:tuple(x%L for x in p); add=lambda p,d:wrap(tuple(p[i]+d[i] for i in range(3)))
mid=lambda p,d:tuple((2*p[i]+d[i])%(2*L) for i in range(3))     # midpoint coordinates doubled, mod 2L
mids=sorted({mid(v,d) for v in nodes for d in nn}); assert len(mids)==n
qi={m:i for i,m in enumerate(mids)}
def node_star(v): return [qi[mid(v,d)] for d in nn]
def oct_edges(o):
    C=[add(o,tuple(s if i==j else 0 for i in range(3))) for j in range(3) for s in (1,-1)]
    out=set()
    for p in C:
        for d in nn:
            q=add(p,d)
            if q in C: out.add(qi[mid(p,d)])
    return sorted(out)
assert all(len(oct_edges(o))==12 for o in octs)
def shift(m): return tuple(((m[0]+2)%(2*L),m[1],m[2]))           # translation by e1 (doubled coords)
perm=[qi[shift(m)] for m in mids]
# Pauli as (xbits,zbits) over N qubits packed in one bit array of length 2N: x at [0,N), z at [N,2N)
def pauli(xq=(),zq=()):
    v=np.zeros(2*N,dtype=np.uint8)
    for q in xq: v[q]^=1
    for q in zq: v[N+q]^=1
    return v
def pack(v): return np.packbits(v).view(np.uint8)
class State:
    def __init__(s):
        G=np.zeros((N,2*N),dtype=np.uint8)
        for q in range(n):                       # Bell pairs: XX and ZZ on (q, n+q)
            G[q,q]=G[q,n+q]=1; G[n+q,N+q]=G[n+q,N+n+q]=1
        s.G=G
    def comm(s,v):                               # symplectic products of all generators with v
        x,z=s.G[:,:N],s.G[:,N:]
        return ((x@v[N:]+z@v[:N])%2).astype(bool)
    def measure(s,v):
        a=np.nonzero(s.comm(v))[0]
        if len(a)==0: return
        g=s.G[a[0]].copy()
        s.G[a[1:]]^=g
        s.G[a[0]]=v
    def rank(M):
        M=M.copy()%2; r=0; rows,cols=M.shape
        for c in range(cols):
            p=np.nonzero(M[r:,c])[0]
            if len(p)==0: continue
            p=p[0]+r; M[[r,p]]=M[[p,r]]
            nz=np.nonzero(M[:,c])[0]; nz=nz[nz!=r]; M[nz]^=M[r]; r+=1
            if r==rows: break
        return r
    def logical(s):
        sysc=np.concatenate([np.arange(n),N+np.arange(n)])
        return State.rank(s.G[:,sysc])-n
    def contains(s,v):                           # pure state: v in group iff it commutes with all
        return not s.comm(v).any()
Zstars=[pauli(zq=node_star(v)) for v in nodes]
Xstars=[pauli(xq=oct_edges(o)) for o in octs]
def fam_singles(t): return [pauli(xq=[q]) if t=='X' else pauli(zq=[q]) if t=='Z' else pauli(xq=[q],zq=[q]) for q in range(n)]
def collinear_pairs(centres,par):            # pairs of qubits on the same line through a centre (node or octahedral)
    out=[]
    for c in centres:
        for d in nn:
            if d<tuple(-x for x in d): continue
            out.append((qi[mid(c,d)] if par==0 else None, qi[mid(c,tuple(-x for x in d))] if par==0 else None))
    return out
def node_pairs(): return [(qi[mid(v,d)],qi[mid(v,tuple(-x for x in d))]) for v in nodes for d in nn if d>tuple(-x for x in d)]
def oct_pairs():
    # dual collinear pairs: qubits on the two dual edges through octahedral centre o in opposite directions
    out=[]
    for o in octs:
        for d in nn:
            if d>tuple(-x for x in d):
                # dual edge from o to o+d crosses the bond whose midpoint is the dual midpoint
                m1=tuple((2*o[i]+d[i])%(2*L) for i in range(3)); m2=tuple((2*o[i]-d[i])%(2*L) for i in range(3))
                out.append((qi[m1],qi[m2]))
    return out
FAM={
 'Zstar':Zstars,'Xstar':Xstars,
 'Xs':fam_singles('X'),'Zs':fam_singles('Z'),'Ys':fam_singles('Y'),
 'ZZn':[pauli(zq=p) for p in node_pairs()],'XXo':[pauli(xq=p) for p in oct_pairs()],
 'XXn':[pauli(xq=p) for p in node_pairs()],'ZZo':[pauli(zq=p) for p in oct_pairs()],
}
DUAL={'Zstar':'Xstar','Xstar':'Zstar','Xs':'Zs','Zs':'Xs','Ys':'Ys','ZZn':'XXo','XXo':'ZZn','XXn':'ZZo','ZZo':'XXn'}
# sanity: Phi maps each family onto its dual family
def phi(v):
    x,z=v[:N].copy(),v[N:].copy(); X=np.zeros(N,np.uint8); Z=np.zeros(N,np.uint8)
    for q in range(n): X[perm[q]]=z[q]; Z[perm[q]]=x[q]
    return np.concatenate([X,Z])
for f,g in DUAL.items():
    A={tuple(np.nonzero(phi(v))[0]) for v in FAM[f]}; B={tuple(np.nonzero(v)[0]) for v in FAM[g]}
    assert A==B,(f,g)
print("self-duality maps every measurement family onto its dual: ok")
def run(seq,periods=4):
    s=State(); full=list(seq)+[DUAL[f] for f in seq]; hist=[]
    for p in range(periods):
        for f in full:
            for v in FAM[f]: s.measure(v)
            if p==periods-1:
                hist.append((f,s.logical(),all(s.contains(v) for v in Zstars),all(s.contains(v) for v in Xstars)))
    return hist
names=list(FAM)
found=[]
for Lseq in (1,2,3):
    for seq in itertools.product(names,repeat=Lseq):
        if any(seq[i]==seq[i+1] for i in range(len(seq)-1)): continue
        h=run(seq)
        k=min(x[1] for x in h)
        alt=any(z and not x for _,_,z,x in h) and any(x and not z for _,_,z,x in h)
        if k>0 and alt:
            found.append((seq,k,h)); print("CANDIDATE",seq,"logical",k,[(f,l,int(z),int(x)) for f,l,z,x in h],flush=True)
print("searched schedules up to 3 families per half-period; candidates:",len(found))
