"""Usage: python3 rp.py {Z4|D4|D4star} L T   (D4: site reflection through a slice of node checks)
Reflection positivity (RP) of the Gaussian compact-U(1) sector, by direct Gram-matrix test.
Doubled coordinates X = 2x. Lattice given by site set, roots, plaquettes (closed root cycles).
Observables: fluxes of plaquettes lying in the half-space t >= 0. Reflection theta: X_t -> -X_t.
RP <=> M_ab = <theta(F_a) F_b> = eps_a G(theta a, b) is positive semidefinite."""
import numpy as np, itertools, sys
def build(kind,L,T):
    P=np.array([2*L]*3+[2*T])
    if kind=='Z4':
        roots=[tuple(2*v) for v in np.eye(4,dtype=int)]
        sites=[X for X in itertools.product(*[range(0,p,2) for p in P])]
    elif kind=='D4': # D4 root lattice: even-sum points of Z4, 24 roots +-e_mu +- e_nu (the history of the alternating schedule)
        roots=[2*np.array(v) for v in itertools.product((-1,0,1),repeat=4) if sum(map(abs,v))==2 and tuple(v)>tuple(-np.array(v))]
        roots=[tuple(r) for r in roots]
        sites=[X for X in itertools.product(*[range(0,p,2) for p in P]) if (sum(X)//2)%2==0]
    else: # D4* = Z4 u (Z+1/2)^4
        roots=[tuple(2*v) for v in np.eye(4,dtype=int)]+[s for s in itertools.product([1,-1],repeat=4) if s[0]==1]
        sites=[X for X in itertools.product(*[range(p) for p in P]) if len(set(np.array(X)%2))==1]
    roots=[np.array(r) for r in roots]
    sidx={s:i for i,s in enumerate(sites)}
    allr=roots+[-r for r in roots]
    def wrap(X): return tuple(np.mod(X,P))
    links={}
    for i,s in enumerate(sites):
        for j,r in enumerate(roots): links[(s,j)]=len(links)
    def link(Xa,Xb):  # oriented link a->b, returns (index,sign)
        d=np.array(Xb)-np.array(Xa); d=(d+P//2)%P-P//2
        for j,r in enumerate(roots):
            if np.array_equal(d,r): return links[(wrap(Xa),j)],1
            if np.array_equal(d,-r): return links[(wrap(Xb),j)],-1
        raise ValueError
    # plaquette shapes: closed cycles of allowed roots
    shapes=[]
    if kind=='Z4':
        for m,n in itertools.combinations(range(4),2):
            e=[roots[m],roots[n],-roots[m],-roots[n]];shapes.append(e)
    else:  # triangles: closed cycles of three roots
        seen=set()
        for a,b in itertools.product(allr,allr):
            c=-(a+b)
            if any(np.array_equal(c,r) for r in allr):
                verts=[np.zeros(4,int),a,a+b]
                key=frozenset(tuple(v-min(verts,key=tuple)) for v in verts)
                if key in seen: continue
                seen.add(key);shapes.append([a,b,c])
    plaqs=[]  # list of vertex lists (absolute, unwrapped from a base site)
    seenp=set()
    for s in sites:
        for sh in shapes:
            v=[np.array(s)];
            for e in sh[:-1]: v.append(v[-1]+e)
            k=frozenset(wrap(x) for x in v)
            if k in seenp: continue
            seenp.add(k);plaqs.append([wrap(x) for x in v])
    d2=np.zeros((len(plaqs),len(links)))
    for p,v in enumerate(plaqs):
        for a,b in zip(v,v[1:]+v[:1]):
            i,sg=link(a,b);d2[p,i]+=sg
    return dict(P=P,sites=sites,plaqs=plaqs,d2=d2,nlinks=len(links),wrap=wrap)
def rp_test(kind,L,T):
    g=build(kind,L,T);P=g['P'];d2=g['d2'];plaqs=g['plaqs']
    Lap=d2.T@d2
    G=d2@np.linalg.pinv(Lap,rcond=1e-10,hermitian=True)@d2.T
    idx={frozenset(v):i for i,v in enumerate(plaqs)}
    def tval(Xt): return ((Xt+P[3]//2)%P[3])-P[3]//2  # signed time in (-T,T]
    pos=[p for p,v in enumerate(plaqs) if all(0<=tval(x[3])<P[3]//2-2 for x in v)]
    # make sure plaquettes don't wrap across far side
    def refl(x): return g['wrap'](np.array([x[0],x[1],x[2],-x[3]]))
    M=np.zeros((len(pos),len(pos)))
    for ia,a in enumerate(pos):
        v=plaqs[a];rv=[refl(x) for x in v];b=idx[frozenset(rv)]
        # orientation: compare cyclic order
        w=plaqs[b];n=len(w);st=w.index(rv[0])
        eps=1 if all(w[(st+k)%n]==rv[k] for k in range(n)) else -1
        M[ia,:]=eps*G[b,pos]
    asym=np.abs(M-M.T).max()
    ev=np.linalg.eigvalsh((M+M.T)/2)
    print(f"{kind} L={L} T={T}: links={g['nlinks']} plaquettes={len(plaqs)} per-site={len(plaqs)/len(g['sites']):.0f} "
          f"| positive-side plaquettes={len(pos)} | asym={asym:.1e} | min eig={ev.min():+.3e} max eig={ev.max():.3e} | #neg(<-1e-9)={np.sum(ev<-1e-9)}")
    return ev
if __name__=="__main__":
    kind=sys.argv[1];L=int(sys.argv[2]);T=int(sys.argv[3]);rp_test(kind,L,T)
