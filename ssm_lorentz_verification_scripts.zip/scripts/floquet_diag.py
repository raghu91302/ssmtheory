import itertools, importlib.util, sys
sys.argv=['x']
src=open('floquet_search.py').read().split("names=list(FAM)")[0]
ns={}; exec(src,ns)
run,FAM=ns['run'],ns['FAM']; names=list(FAM)
stats={'k>0':0,'alt':0,'both':0,'total':0}; keep=[]; alts=[]
for Lseq in (1,2,3):
    for seq in itertools.product(names,repeat=Lseq):
        if any(seq[i]==seq[i+1] for i in range(len(seq)-1)): continue
        h=run(seq,periods=3); stats['total']+=1
        k=min(x[1] for x in h); alt=any(z and not x for _,_,z,x in h) and any(x and not z for _,_,z,x in h)
        stats['k>0']+=k>0; stats['alt']+=alt; stats['both']+=(k>0 and alt)
        if k>0: keep.append((seq,k))
        if alt: alts.append((seq,k,[x[1] for x in h]))
print(stats)
print("logical-preserving schedules (first 15):",keep[:15])
print("alternating schedules (first 10) with logical counts per step:",alts[:10])
