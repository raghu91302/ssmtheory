"""One-loop light-matter speed split on the two history lattices of the pulsed FCC code, with bare speeds
matched (both kinetic terms -> q^2 at small q).  phi massless (light), chi massive (matter), cubic vertex,
normalisation as in the D4* paper: Sigma_phi = g^2 sum G_chi G_chi, Sigma_chi = 2 g^2 sum G_phi G_chi,
inverse propagator q^2 + m^2 - Sigma, so c^2 - 1 = A_t - A_s for each field.
(A) FCC x Z (same checks every tick):  K = (1/4) sum_FCC12 (1-cos q.n) + 2(1-cos q_t)/2*... normalised below
(B) D4 (alternating rounds):           K = (1/6) sum_24 roots (1-cos q.n)
Sums over the cube [-pi,pi]^4 (a uniform cover of each Brillouin zone); massless propagators on a shifted grid."""
import numpy as np, itertools, sys
fcc=[np.array(d) for d in itertools.product((-1,0,1),repeat=3) if sum(map(abs,d))==2]
d4=[np.array(r) for r in itertools.product((-1,0,1),repeat=4) if sum(map(abs,r))==2]
def K_A(q):   # q: (qx,qy,qz,qt) sparse grids
    s=sum(1-np.cos(n[0]*q[0]+n[1]*q[1]+n[2]*q[2]) for n in fcc)/4.0     # -> q_s^2
    return s+2*(1-np.cos(q[3]))                                           # -> q_t^2
def K_B(q):
    return sum(1-np.cos(sum(n[i]*q[i] for i in range(4))) for n in d4)/6.0
def grid(N,shift):
    g=2*np.pi*(np.arange(N)-N//2+(0.5 if shift else 0.0))/N
    return np.meshgrid(g,g,g,g,indexing='ij',sparse=True)
def shifts(K,m,N,h=0.02):
    q=grid(N,False); qs=grid(N,True)
    def add(q,p): return [q[i]+p[i] for i in range(4)]
    loop=1/(16*np.pi**2)
    def Sphi(p):  return np.mean(1/(m*m+K(q))*1/(m*m+K(add(q,p))))
    def Schi(p):  return 2*np.mean(1/K(qs)*1/(m*m+K(add(qs,p))))
    out=[]
    for S in (Sphi,Schi):
        s0=S((0,0,0,0)); At=(S((0,0,0,h))-s0)/h**2; As=(S((h,0,0,0))-s0)/h**2
        out.append((At-As)*(2*np.pi)**4/(2*np.pi)**4/loop*1.0)
    return out
m=0.5
for N in [16,24]:
    for name,K in [("(A) FCC x Z, same checks every tick",K_A),("(B) D4, alternating rounds",K_B)]:
        a,b=shifts(K,m,N)
        print(f"N={N} {name:38s}: c_phi^2-1 = {a:+.4f}, c_chi^2-1 = {b:+.4f}, split c_phi^2-c_chi^2 = {a-b:+.4f}  [g^2/16pi^2]",flush=True)
