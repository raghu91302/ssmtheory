"""Figure 1: history lattices built by two check schedules (schematic x-t projection)."""
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.size":9})
C_NODE,C_OCT,C_LINK,C_TIME="#2f5d8a","#e3a33b","#444444","#7f77dd"
fig,axs=plt.subplots(1,2,figsize=(7.0,3.0))
xs=range(0,7); ts=range(0,5)
ax=axs[0]
for t in ts:
    ax.plot([0,6],[t,t],color=C_LINK,lw=0.8,zorder=1)
    ax.scatter([x for x in xs if x%2==0],[t]*4,s=40,color=C_NODE,zorder=3,edgecolor="white",lw=0.6)
for x in xs:
    if x%2==0: ax.plot([x,x],[0,4],color=C_TIME,lw=1.6,zorder=2)
ax.set_title("(a) the same checks every tick",fontsize=9)
ax=axs[1]
for t in ts:
    for x in xs:
        if (x+t)%2==0:
            for dx in (-1,1):
                if 0<=x+dx<=6 and t+1<=4: ax.plot([x,x+dx],[t,t+1],color=C_TIME,lw=1.6,zorder=2)
            if x+2<=6: ax.plot([x,x+2],[t,t],color=C_LINK,lw=0.8,zorder=1)
for t in ts:
    pts=[x for x in xs if (x+t)%2==0]
    ax.scatter(pts,[t]*len(pts),s=40,marker="o" if t%2==0 else "s",color=C_NODE if t%2==0 else C_OCT,zorder=3,edgecolor="white",lw=0.6)
ax.set_title("(b) node and octahedral checks alternating",fontsize=9)
for ax in axs:
    ax.set_xlim(-0.6,6.6); ax.set_ylim(-0.6,4.9); ax.set_xticks([]); ax.set_yticks(range(5))
    ax.set_yticklabels([f"$t_{k}$" for k in range(5)]); ax.set_xlabel("space",color="#555555")
    for s in ("top","right","bottom"): ax.spines[s].set_visible(False)
    ax.spines["left"].set_color("#999999")
axs[0].set_ylabel("tick",color="#555555")
h=[plt.Line2D([],[],marker="o",ls="",color=C_NODE,label="node check"),
   plt.Line2D([],[],marker="s",ls="",color=C_OCT,label="octahedral check"),
   plt.Line2D([],[],color=C_LINK,lw=0.8,label="coupling within a round"),
   plt.Line2D([],[],color=C_TIME,lw=1.6,label="coupling between rounds")]
fig.legend(handles=h,loc="lower center",ncol=4,frameon=False,fontsize=8,bbox_to_anchor=(0.5,-0.04))
fig.tight_layout(rect=(0,0.07,1,1))
fig.savefig("Figure3_history.pdf",bbox_inches="tight"); fig.savefig("Figure3_history.png",dpi=200,bbox_inches="tight"); print("ok")
