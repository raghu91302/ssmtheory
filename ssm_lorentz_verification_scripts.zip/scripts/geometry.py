"""Restitch geometry of a node trapped in a tetrahedral void of the FCC lattice.
Units: h = a/2 (a = cubic cell edge). FCC nodes = integer points with even coordinate sum,
octahedral voids = integer points with odd sum, tetrahedral voids = (Z+1/2)^3.
A tetrahedral void's four anchor corners are the FCC nodes at distance sqrt(3)/2."""
import numpy as np, itertools
from collections import defaultdict
def corners_tet(c):   # FCC nodes among the 8 cube corners around a tetrahedral void
    return {tuple(int(round(c[i]+d[i])) for i in range(3)) for d in itertools.product((-.5,.5),repeat=3)
            if sum(int(round(c[i]+d[i])) for i in range(3))%2==0}
def corners_oct(o):   # the six FCC nodes at distance 1 from an octahedral void
    return {tuple(o[i]+(s if i==j else 0) for i in range(3)) for j in range(3) for s in (1,-1)}
T0=(0.5,0.5,0.5); C0=corners_tet(T0)
print("tetrahedral void",T0,"anchor corners",sorted(C0))
# 1) the 8 points of the unit cube around T0: 4 own corners (nodes) + 4 octahedral voids across faces
cube=[tuple(int(round(T0[i]+d[i])) for i in range(3)) for d in itertools.product((-.5,.5),repeat=3)]
for p in cube:
    kind="FCC node (own corner)" if sum(p)%2==0 else "octahedral void"
    shared=len(C0 & corners_oct(p)) if sum(p)%2 else None
    print(f"  cube corner {p}: {kind}" + (f", shares {shared} corners with the tetrahedron (a face)" if shared else ""))
# 2) tetrahedral neighbors by displacement class and number of shared anchor corners
classes=defaultdict(set)
for d in itertools.product(range(-2,3),repeat=3):
    if d==(0,0,0): continue
    T=tuple(T0[i]+d[i] for i in range(3)); n=len(C0 & corners_tet(T))
    if n>0: classes[(round(float(np.linalg.norm(d)),3),n)].add(tuple(sorted(map(abs,d))))
print("tetrahedral neighbors that share anchor corners:")
for (dist,n),ds in sorted(classes.items()):
    cnt=sum(1 for d in itertools.product(range(-2,3),repeat=3) if d!=(0,0,0) and
            round(float(np.linalg.norm(d)),3)==dist and len(C0 & corners_tet(tuple(T0[i]+d[i] for i in range(3))))==n)
    print(f"  distance {dist} h, shared corners {n} ({'edge' if n==2 else 'vertex'}): {cnt} neighbors, displacement type {sorted(ds)};"
          f" bonds to break/form = {4-n}")
