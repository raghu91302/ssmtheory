"""Pulsed repetition code in 1D (the SSM code of the Zeno paper, Sec. 8): checks Z_i Z_{i+1} with cost lam,
moving term -t sum X_i, applied in ticks of length tau. One Euclidean tick is the transfer matrix
    T = exp(-tau H_X) exp(-tau H_Z),  H_X = -t sum X_i,  H_Z = (lam/2) sum (1 - Z_i Z_{i+1}),
which is exactly the transfer matrix of the 2D Ising model with
    spatial coupling   K_x   = lam*tau/2          (from the check cost)
    temporal coupling  K_tau : tanh K_tau = exp(-2 t tau)   (from the moving term).
Free-fermion spectrum of T:  cosh g(k) = cosh(2 t tau) cosh(lam tau) - sinh(2 t tau) sinh(lam tau) cos k.
We verify this against exact diagonalization, then read off the critical point, the speed, and the
condition for the history weight to treat space and time alike (K_x = K_tau)."""
import numpy as np, itertools
from scipy.linalg import expm
def exact_T(L,lam,t,tau):
    X=np.array([[0,1],[1,0]]);Z=np.diag([1,-1]);I=np.eye(2)
    op=lambda A,i:np.kron(np.kron(np.eye(2**i),A),np.eye(2**(L-i-1)))
    HX=-t*sum(op(X,i) for i in range(L))
    HZ=(lam/2)*sum(np.eye(2**L)-op(Z,i)@op(Z,(i+1)%L) for i in range(L))   # periodic
    return expm(-tau*HX)@expm(-tau*HZ)
def g_formula(k,lam,t,tau):
    c=np.cosh(2*t*tau)*np.cosh(lam*tau)-np.sinh(2*t*tau)*np.sinh(lam*tau)*np.cos(k)
    return np.arccosh(c)
# --- 1. check the formula: lowest excitation gaps of T vs free-fermion levels (even sector, antiperiodic k)
L=10; lam,t,tau=1.3,0.5,0.4
ev=np.sort(-np.log(np.abs(np.linalg.eigvals(exact_T(L,lam,t,tau)))))
gaps=ev-ev[0]
ks=np.pi*(2*np.arange(L)+1)/L                     # NS sector momenta
single=np.sort(g_formula(ks,lam,t,tau))
two=np.sort([single[i]+single[j] for i in range(L) for j in range(i+1,L)])[:4]
print("exact lowest gaps of T (L=10):",np.round(gaps[1:7],6))
print("free-fermion two-particle levels :",np.round(two,6), "(even sector)")
# --- 2. critical point, speed, isotropy
print("\ncritical point: g(0) = |lam - 2t| tau, so the code is critical at lam = 2t for every tick length tau")
print("at lam = 2t the low-k spectrum is g = sinh(lam tau)|k|: the speed is v = sinh(lam tau) sites per tick")
for lt in [0.2,0.5,0.8814,1.2]:
    k=1e-4; v=g_formula(k,2.0,1.0,lt/2.0)/k
    print(f"   lam*tau = {lt:6.4f}: v = {v:.6f} sites/tick (sinh = {np.sinh(lt):.6f})")
lt_iso=np.log(1+np.sqrt(2))
print(f"one site per tick (the light cone along the lattice diagonal) needs lam*tau = ln(1+sqrt2) = {lt_iso:.6f}")
# --- 3. isotropy off criticality: K_x = K_tau  <=>  equal decay in space and in time
def Kx(lam,tau): return lam*tau/2
def Ktau(t,tau): return np.arctanh(np.exp(-2*t*tau))
print("\nmassive species: equal weight for a failed check held one tick (K_x) and one move (K_tau)")
for lam in [2.4,3.0]:
    tau=0.3
    # choose t so that K_tau = K_x
    t=-np.log(np.tanh(Kx(lam,tau)))/(2*tau)
    m_time=g_formula(0,lam,t,tau)                         # decay rate per tick (temporal mass)
    # spatial decay: g(k)=0 at imaginary k = i*kappa -> cosh(kappa) from formula
    c0=np.cosh(2*t*tau)*np.cosh(lam*tau); s0=np.sinh(2*t*tau)*np.sinh(lam*tau)
    kappa=np.arccosh((c0-1)/s0)                           # spatial decay rate per site
    print(f"   lam={lam}, tau={tau}: t={t:.4f} (K_x=K_tau={Kx(lam,tau):.4f}); temporal decay {m_time:.6f} per tick,"
          f" spatial decay {kappa:.6f} per site")
