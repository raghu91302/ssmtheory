"""Free Wilson fermions on the D4 root lattice (even-sum Z^4, 24 hops n = +-e_mu +- e_nu, one r, all equal
weights kappa = 1/12 so that D ~ gamma.d + m), with time along e4: FCC slices at every integer t, every
hop that changes t has n4 = +-1 and a spatial part +-e_i. Site reflection through t = 0.
At fixed spatial momentum p the operator is a chain in t; Gram matrix of psibar on t = 1..depth against the
mirror slices, reflection matrix gamma4, as in kn_momentum.py (sign convention fixed by hypercubic r=1)."""
import numpy as np, itertools
g=[np.array(M,complex) for M in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
I4=np.eye(4); roots=[np.array(r) for r in itertools.product((-1,0,1),repeat=4) if sum(map(abs,r))==2]
def chain(p,m,r,Nt,hops,kap):
    n=2*Nt+1; D=np.zeros((4*n,4*n),complex)
    blk={d:np.zeros((4,4),complex) for d in (-1,0,1)}
    for v in hops:
        blk[int(v[3])]+=-kap*(r*I4-sum(v[mu]*g[mu] for mu in range(4)))*np.exp(1j*np.dot(p,v[:3]))
    blk[0]+=(m+len(hops)*kap*r)*I4
    for a in range(n):
        for d in (-1,0,1):
            b=a+d
            if 0<=b<n: D[4*a:4*a+4,4*b:4*b+4]+=blk[d]
    return D
def gram(p,m,r,hops,kap,Nt=20,depth=10):
    D=chain(p,m,r,Nt,hops,kap);S=np.linalg.inv(D);c=Nt
    A=np.concatenate([np.arange(4*(c+k),4*(c+k)+4) for k in range(1,depth+1)])
    B=np.concatenate([np.arange(4*(c-k),4*(c-k)+4) for k in range(1,depth+1)])
    M=(S[np.ix_(A,B)]@np.kron(np.eye(depth),g[3])).T
    ev=np.linalg.eigvalsh((M+M.conj().T)/2)
    return ev.min(), ev.max(), np.abs(M-M.conj().T).max()
ps=[np.array(q) for q in itertools.product(np.linspace(-np.pi,np.pi,7,endpoint=False)+0.13,repeat=3)]+[np.zeros(3),np.array([np.pi,0,0]),np.array([np.pi,np.pi,0]),np.array([np.pi]*3)]
# normalization: sum over hops of kap * n n^T = identity  ->  D4 roots: kap = 1/12 ; hypercubic axes: kap = 1/2
axes=[np.array(v) for v in np.vstack([np.eye(4,dtype=int),-np.eye(4,dtype=int)])]
def scan(label,hops,kap,r,m):
    res=[gram(p,m,r,hops,kap) for p in ps]
    lmin=min(x[0] for x in res); lmax=max(x[1] for x in res)
    print(f"{label}, r={r}, m={m}: min eigenvalue / largest eigenvalue over all p = {lmin/lmax:+.2e} (herm err {max(x[2] for x in res)/lmax:.0e})",flush=True)
for m in [0.5,0.1]:
    scan("hypercubic control (axis hops)",axes,0.5,1.0,m)
for r in [0.8,1.0,1.25,1.5]:
    for m in [0.5,0.1]:
        scan("D4 root lattice, one r",roots,1/12,r,m)
