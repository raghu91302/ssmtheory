"""3+1D pulsed FCC code: which history lattice do the check rounds build?
Units h = a/2. FCC nodes: even-sum points of Z^3; octahedral voids: odd-sum points.
(A) same checks every tick  -> history FCC x Z, temporal links straight up.
(B) node and octahedral checks in alternating rounds -> sites at tick n are nodes (n even) or octahedral
    voids (n odd); the moving term links each site to the checks it shares bonds with at the next tick."""
import itertools, numpy as np
nodes_nn=[d for d in itertools.product((-1,0,1),repeat=3) if sum(map(abs,d))==2]          # FCC: 12
def oct_corners(o): return {tuple(o[i]+(s if i==j else 0) for i in range(3)) for j in range(3) for s in (1,-1)}
def node_bonds(v):  return {frozenset({v,tuple(v[i]+d[i] for i in range(3))}) for d in nodes_nn}
def oct_edges(o):
    C=list(oct_corners(o)); return {frozenset({p,q}) for p in C for q in C if p<q and sum((p[i]-q[i])**2 for i in range(3))==2}
v=(0,0,0)
share=[]
for d in itertools.product(range(-2,3),repeat=3):
    o=d
    if sum(o)%2==1:
        n=len(node_bonds(v)&oct_edges(o))
        if n: share.append((o,n))
print("octahedral checks sharing bonds with the node check at the origin:",sorted(share))
print(" -> ",len(share),"octahedral voids, each at distance h along a cube axis, sharing",{n for _,n in share},"bonds")
# history lattice (B): links (+-e_i, +-1) between rounds and FCC links within a round
links_B=[(d+(0,)) for d in nodes_nn]+[tuple(s if i==j else 0 for i in range(3))+(st,) for j in range(3) for s in (1,-1) for st in (1,-1)]
links_B=[np.array(l) for l in links_B]
roots_D4=[np.array(r) for r in itertools.product((-1,0,1),repeat=4) if sum(map(abs,r))==2]
same=sorted(map(tuple,links_B))==sorted(map(tuple,roots_D4))
print(f"(B) history links: {len(links_B)}; identical to the 24 roots of D4: {same}")
M=sum(np.outer(l,l) for l in links_B); print("(B) sum n n^T over links =\n",M)
links_A=[np.array(d+(0,)) for d in nodes_nn]+[np.array((0,0,0,s)) for s in (1,-1)]
MA=sum(np.outer(l,l) for l in links_A); print("(A) FCC x Z: sum n n^T over links =\n",MA)
