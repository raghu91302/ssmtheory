"""Figure 2: the pulsed repetition code (exact). (a) speed of the massless mode vs check cost per tick;
(b) dispersion at the isotropic point and at lam*tau = 0.5."""
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.size":9,"axes.edgecolor":"#999999","xtick.color":"#555555","ytick.color":"#555555"})
def g(k,lam,t,tau): return np.arccosh(np.maximum(1.0,np.cosh(2*t*tau)*np.cosh(lam*tau)-np.sinh(2*t*tau)*np.sinh(lam*tau)*np.cos(k)))
fig,axs=plt.subplots(1,2,figsize=(7.0,2.8))
x=np.linspace(0,1.6,200); ax=axs[0]
ax.plot(x,np.sinh(x),color="#2a78d6",lw=2); ax.axhline(1,color="#bbbbbb",lw=0.8,zorder=0)
xi=np.log(1+np.sqrt(2)); ax.plot([xi],[1],"o",color="#2a78d6",mec="white",mew=1.2,ms=7,zorder=3)
ax.annotate(r"$\lambda\tau=\ln(1+\sqrt{2})$",xy=(xi,1),xytext=(0.95,0.35),fontsize=8,arrowprops=dict(arrowstyle="-",color="#888888",lw=0.6))
ax.set_xlabel(r"check cost per tick, $\lambda\tau$"); ax.set_ylabel("speed (sites per tick)")
ax.set_title("(a) speed at the balance point $\\lambda=2t$",fontsize=9)
ax=axs[1]; k=np.linspace(0,np.pi,200)
ax.plot(k,g(k,2,1,xi/2),color="#2a78d6",lw=2,label=r"$\lambda\tau=0.881$ (one site per tick)")
ax.plot(k,g(k,2,1,0.25),color="#eb6834",lw=2,label=r"$\lambda\tau=0.5$")
ax.plot(k,k,color="#bbbbbb",lw=0.8,ls="--",label="light cone, one site per tick")
ax.set_xlabel("momentum $k$ (per site)"); ax.set_ylabel("energy per tick")
ax.set_title("(b) lowest band of one tick",fontsize=9); ax.legend(frameon=False,fontsize=7,loc="upper left")
for a in axs:
    for s in ("top","right"): a.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig("Figure2_pulsed.pdf",bbox_inches="tight"); fig.savefig("Figure2_pulsed.png",dpi=200,bbox_inches="tight"); print("ok")
