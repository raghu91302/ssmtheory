"""Is the SSM FCC code self-dual under X<->Z combined with a lattice map that sends nodes to octahedral voids?
Qubits: FCC bonds (node pairs at distance sqrt2, units h=a/2). Z-check: the 12 bonds at a node.
X-check: the 12 edges of an octahedral cell. Test: translation by e1 (nodes <-> octahedral voids) maps
each node check's qubit set onto an octahedral check's qubit set, and vice versa?"""
import itertools
nn=[d for d in itertools.product((-1,0,1),repeat=3) if sum(map(abs,d))==2]
add=lambda p,d:tuple(p[i]+d[i] for i in range(3))
def bond(p,q): return frozenset({p,q})
def node_check(v): return frozenset(bond(v,add(v,d)) for d in nn)
def oct_check(o):
    C=[add(o,tuple(s if i==j else 0 for i in range(3))) for j in range(3) for s in (1,-1)]
    return frozenset(bond(p,q) for p in C for q in C if p<q and sum((p[i]-q[i])**2 for i in range(3))==2)
# a qubit is a bond; describe it by its midpoint m and direction; translating the midpoint by e1 gives the
# midpoint of another bond? map bond -> the bond whose midpoint is shifted by e1
def mid(b): p,q=tuple(b); return tuple((p[i]+q[i])/2 for i in range(3))
def bond_at_mid(m):
    # bonds with this midpoint: endpoints m +- d/2 for d in nn, both even-sum integer points
    out=[]
    for d in nn:
        p=tuple(m[i]-d[i]/2 for i in range(3)); q=tuple(m[i]+d[i]/2 for i in range(3))
        if all(abs(x-round(x))<1e-9 for x in p+q):
            p=tuple(int(round(x)) for x in p); q=tuple(int(round(x)) for x in q)
            if sum(p)%2==0 and sum(q)%2==0: out.append(bond(p,q))
    return set(out)
# how many bonds share a midpoint? (a qubit location may host several bonds)
m0=mid(bond((0,0,0),(1,1,0))); print("bonds with midpoint",m0,":",len(bond_at_mid(m0)))
# natural candidate: the qubit of bond (p,q) is shared by exactly two octahedral cells; the line joining
# those two octahedral centres is the 'dual edge' crossing the bond. Check crossing structure:
def octs_of_bond(b):
    return [o for o in itertools.product(range(-3,4),repeat=3) if sum(o)%2==1 and b in oct_check(o)]
b=bond((0,0,0),(1,1,0)); O=octs_of_bond(b); print("octahedral cells containing bond",sorted(b),":",O)
print("dual edge midpoint",tuple((O[0][i]+O[1][i])/2 for i in range(3)),"bond midpoint",mid(b))
# map phi: bond (p,q) -> dual edge (o1,o2) [as a pair of octahedral centres]; node check at v -> the set of
# dual edges of its 12 bonds. Is that the 'star' of some octahedral centre in the octahedral FCC graph?
def dual_edge(b): o=octs_of_bond(b); return frozenset(o)
star_dual=set(dual_edge(bb) for bb in node_check((0,0,0)))
centres=set().union(*star_dual); print("dual edges of the node star at the origin touch octahedral centres:",sorted(centres))
# compare: an octahedral check (12 edges) in terms of dual edges is the star of its centre?
oc=(1,0,0); star_oct=set(dual_edge(bb) for bb in oct_check(oc))
print("octahedral check at",oc,"as dual edges: all contain the centre?",all(oc in e for e in star_oct),"; count",len(star_oct))
print("node star as dual edges: these 12 dual edges form a closed cage (each centre touched twice?):",
      sorted([sum(1 for e in star_dual if c in e) for c in centres]))

# direct test: translate every qubit (bond midpoint) by e1; does node_check(v) map onto oct_check(v+e1)?
def mids(check): return frozenset(mid(b) for b in check)
ok=True
for v in [p for p in itertools.product(range(-2,3),repeat=3) if sum(p)%2==0]:
    shifted=frozenset(tuple(m[i]+(1 if i==0 else 0) for i in range(3)) for m in mids(node_check(v)))
    ok &= shifted==mids(oct_check(add(v,(1,0,0))))
for o in [p for p in itertools.product(range(-2,3),repeat=3) if sum(p)%2==1]:
    shifted=frozenset(tuple(m[i]+(1 if i==0 else 0) for i in range(3)) for m in mids(oct_check(o)))
    ok &= shifted==mids(node_check(add(o,(1,0,0))))
print("translation by e1 maps every Z-check support onto an X-check support and back:",ok)
