"""Restitching as tight binding on the tetrahedral sublattice (simple cubic, spacing h = a/2).
A small restitch amplitude t1 gives a band E(k) = E0 + 2 t1 sum_j (1 - cos k_j h), i.e. a kinetic mass
M2 = hbar^2 / (2 t1 h^2) and maximum group velocity 2 t1 h / hbar along an axis.
Relativity requires the kinetic mass to equal the rest mass (M2 = M1) and the limiting speed to be c."""
hbar_c=1.97327e-16       # GeV m
E_P=1.22089e19           # GeV, Planck energy
l_P=1.61626e-35          # m, Planck length
for name,M in [("electron",0.000511),("proton",0.938272)]:
    for hname,h in [("Planck length",l_P),("10 Planck lengths",10*l_P)]:
        t1=hbar_c**2/(2*M*h**2)          # GeV, amplitude needed for M2 = M (in GeV, with c=1)
        vmax=2*t1*h/hbar_c               # in units of c
        print(f"{name:8s} h = {hname:17s}: t1 needed for M2=M1 is {t1:.2e} GeV = {t1/E_P:.1e} E_P;"
              f" the band's maximum speed would then be {vmax:.1e} c")
# conversely: with t1 at the Planck scale the kinetic mass is
for h in [l_P]:
    t1=E_P; M2=hbar_c**2/(2*t1*h**2)
    print(f"t1 = E_P, h = l_P: kinetic mass M2 = {M2:.2e} GeV = {M2/E_P:.2f} E_P (max speed {2*t1*h/hbar_c:.2f} c)")
