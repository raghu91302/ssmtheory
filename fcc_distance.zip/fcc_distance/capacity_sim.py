"""Code-capacity check (independent bit flips, perfect syndrome): weight-8 fluorite code
[[128,20,8]] vs a rotated toric layer [[64,2,8]] (the FCC sheet code layer). Failure = any logical flipped."""
import numpy as np, json, time, gf2
from ldpc import BpOsdDecoder
from fluorite import code
import pymatching

def toric_rot(L):          # rotated toric layer: qubits on vertices of L x L torus, checkerboard plaquettes
    n = L * L; q = lambda i, j: (i % L) * L + (j % L); HZ = []; HX = []
    for i in range(L):
        for j in range(L):
            row = np.zeros(n, np.uint8)
            for a, b in ((0, 0), (0, 1), (1, 0), (1, 1)): row[q(i + a, j + b)] = 1
            (HZ if (i + j) % 2 == 0 else HX).append(row)
    return np.array(HX), np.array(HZ)

def run(HX, HZ, p, shots, rng, matching=False):
    LX, LZ = gf2.logical_pairs(HX, HZ); n = HX.shape[1]
    if matching: dec = pymatching.Matching(HZ)
    else: dec = BpOsdDecoder(HZ, error_rate=p, max_iter=60, bp_method="ms", osd_method="osd_cs", osd_order=10)
    fails = 0; done = 0
    while done < shots and fails < 300:
        e = (rng.random(n) < p).astype(np.uint8); s = (HZ.astype(int) @ e % 2).astype(np.uint8)
        c = dec.decode(s); r = (e ^ c[:n].astype(np.uint8)).astype(int)
        fails += int(((LZ.astype(int) @ r) % 2).any()); done += 1
    return fails, done

if __name__ == "__main__":
    rng = np.random.default_rng(3); out = []
    HXf, HZf = code([[4, 0, 0], [0, 4, 0], [0, 0, 4]], "w8"); HXt, HZt = toric_rot(8)
    for p in (0.01, 0.02, 0.03, 0.05):
        t = time.time()
        f1, s1 = run(HXf, HZf, p, 200000 if p < 0.03 else 30000, rng)
        f2, s2 = run(HXt, HZt, p, 400000, rng, matching=True)
        r = dict(p=p, fluorite_block=f1 / s1, fluorite_per_logical=1 - (1 - f1 / s1) ** (1 / 20), fl_fails=f1,
                 toric_block=f2 / s2, toric_per_logical=1 - (1 - f2 / s2) ** (1 / 2), to_fails=f2)
        out.append(r); print({k: (f"{v:.2e}" if isinstance(v, float) else v) for k, v in r.items()}, f"{time.time()-t:.0f}s", flush=True)
    json.dump(out, open("capacity_sim.json", "w"), indent=1)
