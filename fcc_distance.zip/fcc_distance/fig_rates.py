import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
p=[.1,.15,.2,.3]
fl3=[(62,4800),(65,2000),(62,1000),(68,400)]; fl4=[(40,32600),(50,8200),(61,2800),(76,600)]
def rate(f,s,k,R): return 1-(1-f/s)**(1/(k*R))
fig,ax=plt.subplots(figsize=(5.2,3.8))
for d,k,R,lab,c,m in [(fl3,14,5,"tetrahedral-void L=3  [[54,14,5]]","#d9822b","s"),(fl4,20,8,"tetrahedral-void L=4  [[128,20,8]]","#b0331f","s")]:
    y=[rate(f,s,k,R) for f,s in d]; e=[v/np.sqrt(f) for v,(f,s) in zip(y,d)]
    ax.errorbar(p,y,yerr=e,marker=m,color=c,lw=2,ms=6,capsize=2,label=lab)
tp=[.1,.2,.3]
for L,y,c in [(4,[2.4e-4,9.8e-4,2.1e-3],"#9db7e0"),(6,[9.1e-6,7.6e-5,2.6e-4],"#4a7bc8"),(8,[4.1e-7,7.0e-6,4.6e-5],"#1f4e9c")]:
    ax.plot(tp,y,marker="o",ls="--",color=c,lw=1.5,ms=5,label=f"toric layer L={L}")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xticks([.1,.15,.2,.3]); ax.set_xticklabels(["0.1","0.15","0.2","0.3"]); ax.minorticks_off()
ax.set_xlabel("gate error p (%)"); ax.set_ylabel("failure per logical qubit per round"); ax.grid(alpha=.25); ax.legend(fontsize=7.5,frameon=False)
plt.tight_layout(); plt.savefig("fig2.pdf"); plt.savefig("fig2.png",dpi=100)
