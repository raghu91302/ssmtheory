"""Fourth run: faster and more accurate decoder, L = 4, 5, 6.
Decoder: BP (min-sum, adaptive scaling, serial schedule, 100 iterations) + OSD-CS order 4.
Rounds = code distance (8, 10, 12).  Z basis, no idle noise, plain (unflagged) circuit.
Usage: python3 circuit_sim4.py "L,p,cap_seconds;L,p,cap;..."   (jobs run one after another)
Each finished job appends one JSON line to circuit_sim4.jsonl; lines for the same (L,p) can be pooled."""
import numpy as np, json, sys, time, os, shutil
from ldpc import BpOsdDecoder
from fluorite_circuit import circuit, dem_matrices
ROUNDS = {3: 5, 4: 8, 5: 10, 6: 12}
OUT = "circuit_sim4.jsonl"; COPY = "/mnt/user-data/outputs/fcc_distance/circuit_sim4.jsonl"

def job(L, p, cap, target=80):
    R = ROUNDS[L]; c, k = circuit(L, R, p); H, O, pri = dem_matrices(c); Od = O.toarray()
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0,
                       schedule="serial", osd_method="osd_cs", osd_order=4)
    seed = int(time.time() * 1000) % (2 ** 31); s = c.compile_detector_sampler(seed=seed)
    fails = shots = conv = 0; t = time.time()
    while fails < target and time.time() - t < cap:
        det, obs = s.sample(20, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8)); fails += int(((Od @ e) % 2 != obs[i]).any()); conv += int(dec.converge)
        shots += len(det)
    return dict(L=L, k=k, p=p, rounds=R, shots=shots, fails=fails, bp_converged=conv, seed=seed, secs=int(time.time() - t))

if __name__ == "__main__":
    for spec in sys.argv[1].split(";"):
        L, p, cap = spec.split(","); x = job(int(L), float(p), float(cap))
        with open(OUT, "a") as f: f.write(json.dumps(x) + "\n")
        print(x, flush=True)
        try: shutil.copy(OUT, COPY)
        except Exception as e: print("copy failed", e, flush=True)
