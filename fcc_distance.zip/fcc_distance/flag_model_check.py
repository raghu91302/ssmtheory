import sys
from fault_model import *
T = ORDERS["tetra-first (4 L then 4 R)"]
for seed in range(int(sys.argv[1])):
    d, used, s = model(4, hook_comps(4, lambda gi, g: T, cost=2, segments=True), trials=300, seed=seed, target=7)
    print(seed, d, len(used), len(s), flush=True)
    if d < 8: print("BELOW 8:", used, s); break
