
## 14. Joint logical measurement with a toric layer (surgery.py, surgery_sim.py)

`python3 surgery.py 4 200` builds the bridge between one line operator of the
L=4 checkerboard block and one row of a distance-8 rotated toric layer and
prints the merged-code parameters (24 bridge qubits, k 22 -> 21, check weight
<= 9, distance upper bound 8).
`python3 surgery_sim.py "merged,4,8,0.001,300;control,4,8,0.002,300"` runs the
circuit-level simulation in chunks and appends to surgery_sim.jsonl.
Pooled results (L=4, 8 rounds, Z basis, bridge on for all rounds):

| p     | kind    | shots   | wrong measured value | shots with a stored-qubit failure |
|-------|---------|---------|----------------------|-----------------------------------|
| 0.1%  | merged  | 139,780 | 12                   | 111                               |
| 0.2%  | merged  | 17,200  | 23                   | 136                               |
| 0.2%  | control | 9,360   | -                    | 97                                |
| 0.3%  | merged  | 7,060   | 27                   | 253                               |
| 0.3%  | control | 1,880   | -                    | 96                                |

Not covered: switching the bridge on and off inside a memory run, X-type and
ribbon measurements, a physical layout for the bridge qubits. Distances of the
merged code are randomized-search upper bounds.
