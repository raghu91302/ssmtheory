import numpy as np, time, sys
from ldpc import BpOsdDecoder
from ldpc.bplsd_decoder import BpLsdDecoder
from fluorite_circuit import circuit, dem_matrices
L=int(sys.argv[1]); p=float(sys.argv[2]); R=2*L if L>4 else 8; n=int(sys.argv[3])
c,k=circuit(L,R,p); H,O,pri=dem_matrices(c); Od=O.toarray(); print("L",L,"p",p,"H",H.shape,flush=True)
det,obs=c.compile_detector_sampler(seed=5).sample(n,separate_observables=True)
decs={"bposd_cs4":BpOsdDecoder(H,channel_probs=list(pri),max_iter=60,bp_method="ms",ms_scaling_factor=0.625,osd_method="osd_cs",osd_order=4),
 "bposd0":BpOsdDecoder(H,channel_probs=list(pri),max_iter=60,bp_method="ms",ms_scaling_factor=0.625,osd_method="osd0",osd_order=0),
 "bplsd0":BpLsdDecoder(H,channel_probs=list(pri),max_iter=60,bp_method="ms",ms_scaling_factor=0.625,lsd_method="lsd_0",lsd_order=0),
 "bplsd_cs4":BpLsdDecoder(H,channel_probs=list(pri),max_iter=60,bp_method="ms",ms_scaling_factor=0.625,lsd_method="lsd_cs",lsd_order=4),
 "bplsd_it20":BpLsdDecoder(H,channel_probs=list(pri),max_iter=20,bp_method="ms",ms_scaling_factor=0.625,lsd_method="lsd_cs",lsd_order=4)}
for name,d in decs.items():
    if len(sys.argv)>4 and name not in sys.argv[4:]: continue
    t=time.time(); f=0; conv=0
    for i in range(n):
        e=d.decode(det[i].astype(np.uint8)); f+=int(((Od@e)%2!=obs[i]).any()); conv+=int(getattr(d,"converge",0))
    print(name,"fails",f,"/",n,"bp_conv",conv,"s/shot %.3f"%((time.time()-t)/n),flush=True)
