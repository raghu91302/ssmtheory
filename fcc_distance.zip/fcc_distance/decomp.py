# Are the failure patterns those of single minimum-weight logical operators?
# S1 = patterns of wrong values caused by one weight-2L line or ribbon (as an X operator) in the
# logical basis of the circuit; S2 = sums of two.  For every observed failure pattern: the
# smallest number of lines/ribbons that gives it.   Usage: python3 decomp.py
import json, numpy as np, gf2, os
from fluorite import code, Group
L = 4; hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; n = 2 * N
HX, HZ = code(hnf, "w8"); LX, LZ = gf2.logical_pairs(HX, HZ); k = len(LZ)
A = np.array([[0, 2, 2], [2, 0, 2], [2, 2, 0]]); EL = list(G.elems())
def pos(q): return np.array(EL[q % N]) @ A + (-1 if q < N else 1)
def qidx(p):
    for s, off in ((0, 1), (1, -1)):
        u = np.array(p) + off; h4 = np.array([-u[0] + u[1] + u[2], u[0] - u[1] + u[2], u[0] + u[1] - u[2]])
        if (h4 % 4 == 0).all(): return s * N + G.idx(tuple(h4 // 4))
ops = {}
for q0 in range(n):
    p = pos(q0)
    for ax in range(3):
        d = np.zeros(3, int); d[ax] = 2; ops[("line", frozenset(qidx(p + j * d) for j in range(2 * L)))] = 1
        b, c = [i for i in range(3) if i != ax]; r = np.zeros(3, int); r[ax] = 2
        for sg in (1, -1):
            d = np.zeros(3, int); d[b] = 2; d[c] = 2 * sg; q = frozenset(qidx(p + j * d + e * r) for j in range(L) for e in (0, 1))
            if len(q) == 2 * L: ops[("ribbon", q)] = 1
pat = {}
for (t, q) in ops:
    v = np.zeros(n, np.uint8); v[list(q)] = 1
    if ((HZ.astype(int) @ v) % 2).any(): continue
    f = (LZ.astype(int) @ v) % 2
    if f.any(): pat.setdefault(int("".join(map(str, f)), 2), t)
S1 = set(pat); print("operators", len(ops), "distinct nonzero patterns of single lines/ribbons:", len(S1), " wrong values per single operator: mean %.2f" % np.mean([bin(x).count("1") for x in S1]))
S1l = list(S1); S2 = {a ^ b for i, a in enumerate(S1l) for b in S1l[i + 1:]} - {0}
def level(x):
    if x in S1: return 1
    if x in S2: return 2
    if any((x ^ a) in S2 for a in S1l): return 3
    return 4
F = [b for fn in ("mult_11.json", "mult_12.json") for b in json.load(open(fn))["fails"]]; src = {"memory runs, p=0.2%": F}
if os.path.exists("diag.jsonl"):
    for l in open("diag.jsonl"):
        r = json.loads(l); src.setdefault("diag runs, p=%.1f%%" % (100 * r["p"]), []).extend(x["f"] for x in r["fails"])
rng = np.random.default_rng(0); src["random patterns"] = ["".join(map(str, rng.integers(0, 2, k))) for _ in range(300)]
for name, F in src.items():
    lv = np.array([level(int(b, 2)) for b in F]); w = np.array([b.count("1") for b in F])
    print(f"{name}: {len(F)} patterns; needs 1 operator: {(lv==1).sum()}, 2: {(lv==2).sum()}, 3: {(lv==3).sum()}, more or not reachable: {(lv==4).sum()};  mean wrong values by level:", {int(j): round(float(w[lv == j].mean()), 1) for j in sorted(set(lv))})

# ---- Is there a logical basis in which failures touch few values?  Fit a change of basis T (invertible
# over GF(2), i.e. new logical Z operators = products of the old ones) that minimizes the mean number of
# wrong values over the 72 single-operator patterns only, then apply it to the observed failures.
P = np.array([[int(c) for c in format(x, "020b")] for x in S1l], dtype=np.uint8)
obs = {nm: np.array([[int(c) for c in b] for b in F], dtype=np.uint8) for nm, F in src.items()}
best = None
for t in range(60):
    rng = np.random.default_rng(t); G_ = P.copy(); T = np.eye(k, dtype=np.uint8); imp = True
    while imp:
        imp = False
        for i in rng.permutation(k):
            for j in rng.permutation(k):
                if i != j and (G_[:, i] ^ G_[:, j]).sum() < G_[:, i].sum(): G_[:, i] ^= G_[:, j]; T[:, i] ^= T[:, j]; imp = True
    if best is None or G_.sum() < best[0]: best = (G_.sum(), T.copy())
T = best[1]; print("single lines/ribbons: mean wrong values %.2f -> %.2f after change of basis" % (P.sum() / len(P), best[0] / len(P)))
for nm, M in obs.items():
    M2 = (M.astype(int) @ T) % 2; print(f"{nm}: mean wrong values {M.sum()/len(M):.2f} -> {M2.sum()/len(M2):.2f};  shots with one wrong value {int((M.sum(1)==1).sum())} -> {int((M2.sum(1)==1).sum())}, with <= 2: {int((M.sum(1)<=2).sum())} -> {int((M2.sum(1)<=2).sum())}")
np.save("basis_T.npy", T)
