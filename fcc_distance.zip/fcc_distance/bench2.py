import numpy as np, time, sys
from ldpc import BpOsdDecoder
from fluorite_circuit import circuit, dem_matrices
L=int(sys.argv[1]); p=float(sys.argv[2]); R=2*L if L>4 else 8; n=int(sys.argv[3])
c,k=circuit(L,R,p); H,O,pri=dem_matrices(c); Od=O.toarray()
det,obs=c.compile_detector_sampler(seed=5).sample(n,separate_observables=True)
cfg={"ms200":dict(max_iter=200,bp_method="ms",ms_scaling_factor=0.625),
"ms1000":dict(max_iter=1000,bp_method="ms",ms_scaling_factor=0.625),
"ms0_200":dict(max_iter=200,bp_method="ms",ms_scaling_factor=0.0),
"ps200":dict(max_iter=200,bp_method="ps"),
"ms_serial200":dict(max_iter=200,bp_method="ms",ms_scaling_factor=0.625,schedule="serial"),
"ms9_200":dict(max_iter=200,bp_method="ms",ms_scaling_factor=0.9)}
for name,kw in cfg.items():
    for osd in (("osd0",0),("osd_cs",4)):
        d=BpOsdDecoder(H,channel_probs=list(pri),osd_method=osd[0],osd_order=osd[1],**kw)
        t=time.time(); f=0; conv=0
        for i in range(n):
            e=d.decode(det[i].astype(np.uint8)); f+=int(((Od@e)%2!=obs[i]).any()); conv+=int(d.converge)
        print(name,osd[0],"fails",f,"/",n,"bp_conv",conv,"s/shot %.3f"%((time.time()-t)/n),flush=True)
