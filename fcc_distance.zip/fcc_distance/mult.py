# Per-failure multiplicity of wrong logical values. Usage: python3 mult.py seed seconds
import sys, time, json, numpy as np
from fluorite_circuit import circuit, dem_matrices
from ldpc import BpOsdDecoder
seed, cap = int(sys.argv[1]), float(sys.argv[2])
L, p = 4, 0.002
c, k = circuit(L, 2 * L, p); H, O, pri = dem_matrices(c); O = O.toarray().astype(np.uint8)
dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0, schedule="serial", osd_method="osd_cs", osd_order=4)
s = c.compile_detector_sampler(seed=seed); t0 = time.time(); shots = 0; fails = []
while time.time() - t0 < cap:
    d, o = s.sample(200, separate_observables=True)
    for i in range(200):
        r = ((O @ dec.decode(d[i].astype(np.uint8))) % 2) ^ o[i]
        if r.any(): fails.append("".join(map(str, r.astype(int))))
    shots += 200
json.dump(dict(shots=shots, k=k, fails=fails), open(f"mult_{seed}.json", "w")); print(shots, len(fails))
