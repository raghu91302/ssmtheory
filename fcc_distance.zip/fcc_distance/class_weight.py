# Smallest data-qubit weight of an X operator that causes a given pattern of wrong logical Z values
# (L = 4).  Randomized information-set search over {v : HZ v = 0, LZ v = f}; results are upper bounds.
# Calibration: patterns of single lines/ribbons must give 8.   Usage: python3 class_weight.py [iterations]
import json, sys, os, numpy as np, gf2, collections
from fluorite import code
L = 4; HX, HZ = code([[L, 0, 0], [0, L, 0], [0, 0, L]], "w8"); LX, LZ = gf2.logical_pairs(HX, HZ); n = HZ.shape[1]; k = len(LZ)
IT = int(sys.argv[1]) if len(sys.argv) > 1 else 300
M = np.vstack([HZ, LZ]).astype(np.uint8)
def packed(A): return [int("".join(map(str, r)), 2) for r in A]
def minw(f, rng):
    s = np.concatenate([np.zeros(len(HZ), np.uint8), f]); best = n
    for it in range(IT):
        perm = rng.permutation(n); A = np.concatenate([M[:, perm], s[:, None]], 1).copy(); piv = []; r = 0
        for c in range(n):
            if r == len(A): break
            nz = np.nonzero(A[r:, c])[0]
            if len(nz) == 0: continue
            i = r + nz[0]
            if i != r: A[[r, i]] = A[[i, r]]
            rows = np.nonzero(A[:, c])[0]; rows = rows[rows != r]; A[rows] ^= A[r]; piv.append(c); r += 1
        base = A[:r, n]; w0 = int(base.sum()); best = min(best, w0)
        free = [c for c in range(n) if c not in set(piv)]
        cols = A[:r][:, free]                                   # flipping free var j changes pivots by cols[:, j]
        w1 = (cols ^ base[:, None]).sum(0) + 1; best = min(best, int(w1.min()))
        if len(free) > 1:                                       # pairs of free variables
            X = cols ^ base[:, None]
            for a in range(min(len(free), 54)):
                w2 = (X[:, a:a + 1] ^ cols[:, a + 1:]).sum(0) + 2
                if len(w2): best = min(best, int(w2.min()))
    return best
if __name__ == "__main__":
    rng = np.random.default_rng(0); src = collections.OrderedDict()
    src["memory runs p=0.2%"] = [b for fn in ("mult_11.json", "mult_12.json") for b in json.load(open(fn))["fails"]]
    if os.path.exists("diag.jsonl"):
        for l in open("diag.jsonl"):
            r = json.loads(l); src.setdefault("diag p=%.1f%%" % (100 * r["p"]), []).extend(x["f"] for x in r["fails"])
    cache = json.load(open("class_weight.json")) if os.path.exists("class_weight.json") else {}
    for nm, F in src.items():
        for b in set(F):
            if b not in cache: cache[b] = minw(np.array([int(c) for c in b], dtype=np.uint8), rng)
        json.dump(cache, open("class_weight.json", "w"))
        w = [cache[b] for b in F]; print(nm, len(F), "failed shots; smallest operator weight for the pattern:", dict(sorted(collections.Counter(w).items())), flush=True)
    R = ["".join(map(str, rng.integers(0, 2, k))) for _ in range(40)]
    print("random patterns:", dict(sorted(collections.Counter(minw(np.array([int(c) for c in b], dtype=np.uint8), rng) for b in R).items())))
