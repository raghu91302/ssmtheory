# Why do failed shots have many wrong values?  Samples faults from the detector error model (one
# mechanism per merged column, so the true fault set e is known), decodes, and records for every
# failed shot: the pattern of wrong values, the number of faults |e|, the size of the correction
# |c|, and the costs sum(log((1-p)/p)) of e and of c.  cost(c) > cost(e) means that the decoder
# returned a less likely explanation than the true one, so a minimum-weight decoder would not
# have chosen it.   Usage: python3 diag.py L p seconds   -> appends to diag.jsonl
import sys, time, json, numpy as np, stim
from fluorite_circuit import circuit, dem_matrices
from ldpc import BpOsdDecoder
L, p, cap = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
c, k = circuit(L, 2 * L, p); H, O, pri = dem_matrices(c); Hd = H.tocsc(); Od = O.toarray().astype(np.uint8)
w = np.log((1 - pri) / pri)
dem = stim.DetectorErrorModel()
for j in range(H.shape[1]):
    dem.append("error", pri[j], [stim.target_relative_detector_id(int(d)) for d in Hd.indices[Hd.indptr[j]:Hd.indptr[j + 1]]] + [stim.target_logical_observable_id(int(o)) for o in np.nonzero(Od[:, j])[0]])
dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0, schedule="serial", osd_method="osd_cs", osd_order=4)
seed = int(time.time() * 1000) % 2**31; s = dem.compile_sampler(seed=seed); t0 = time.time(); shots = 0; rec = []; ne = []
while time.time() - t0 < cap:
    d, o, e = s.sample(50, return_errors=True)
    for i in range(50):
        ei = e[i].astype(np.uint8); ci = dec.decode(d[i].astype(np.uint8)); conv = bool(dec.converge)
        r = ((Od @ ci) % 2) ^ o[i]; ne.append(int(ei.sum()))
        if r.any(): rec.append(dict(f="".join(map(str, r.astype(int))), ne=int(ei.sum()), nc=int(ci.sum()), ce=float(w @ ei), cc=float(w @ ci), conv=conv))
    shots += 50
open("diag.jsonl", "a").write(json.dumps(dict(L=L, p=p, k=k, rounds=2 * L, shots=shots, seed=seed, mean_faults=float(np.mean(ne)), fails=rec)) + "\n")
print(L, p, shots, len(rec), flush=True)
