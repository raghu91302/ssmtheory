# Profile of the ensemble: time per setting and, per shot, cost and failure of every setting.
import sys, time, json, numpy as np
from fluorite_circuit import circuit, dem_matrices
from ldpc import BpOsdDecoder
L, p, cap = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
c, k = circuit(L, 2 * L, p); H, O, pri = dem_matrices(c); Od = O.toarray().astype(np.uint8); w = np.log((1 - pri) / pri)
exec(open("ens_settings.py").read())
decs = [BpOsdDecoder(H, channel_probs=list(pri), osd_method="osd_cs", **s) for s in SET]
s = c.compile_detector_sampler(seed=int(time.time() * 1000) % 2**31); t0 = time.time(); T = np.zeros(len(SET)); rows = []
while time.time() - t0 < cap:
    d, o = s.sample(10, separate_observables=True)
    for i in range(10):
        syn = d[i].astype(np.uint8); row = []
        for j, dc in enumerate(decs):
            t = time.time(); x = dc.decode(syn); T[j] += time.time() - t
            row.append((round(float(w @ x), 4), int((((Od @ x) % 2) ^ o[i]).any())))
        rows.append(row)
open("ens_prof.jsonl", "a").write(json.dumps(dict(L=L, p=p, shots=len(rows), T=T.tolist(), rows=rows)) + "\n"); print(L, p, len(rows), (T / len(rows)).round(3).tolist(), flush=True)
