"""Fluorite-lattice bicycle codes.
Geometry: ancillas on FCC sites, data qubits on the two kinds of tetrahedral voids
(species L and R). Every coupling is nearest-neighbour (FCC site <-> adjacent tet void).
Translation group G = FCC lattice / Lambda (a twisted 3-torus), x, y, z = FCC primitive vectors.
X-check at site g: L qubits at g*A, R qubits at g*B;  HX = [A | B], HZ = [B^T | A^T].
Nearest-neighbour condition: A subset of {1, x, y, z}, B subset of {1, x^-1, y^-1, z^-1}."""
import numpy as np, itertools, json, sys, time
import gf2

class Group:
    def __init__(self, hnf):                     # lower-triangular HNF rows
        (d1, _, _), (a, d2, _), (b, c, d3) = hnf
        self.d = (d1, d2, d3); self.a, self.b, self.c = a, b, c; self.N = d1 * d2 * d3
    def idx(self, v):
        x, y, z = v
        q = z // self.d[2]; z -= q * self.d[2]; x -= q * self.b; y -= q * self.c
        q = y // self.d[1]; y -= q * self.d[1]; x -= q * self.a
        x %= self.d[0]
        return x + self.d[0] * (y + self.d[1] * z)
    def elems(self):
        return [(x, y, z) for z in range(self.d[2]) for y in range(self.d[1]) for x in range(self.d[0])]
    def poly(self, terms):
        M = np.zeros((self.N, self.N), np.uint8)
        for g in self.elems():
            i = self.idx(g)
            for t in terms: M[i, self.idx((g[0] + t[0], g[1] + t[1], g[2] + t[2]))] ^= 1
        return M

X, Y, Z, O = (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 0, 0)
neg = lambda t: tuple(-u for u in t)
TYPES = {
    "w6":  ([O, X, Y],    [O, neg(X), neg(Z)]),          # weight-6 checks, genuinely 3D
    "w8":  ([O, X, Y, Z], [O, neg(X), neg(Y), neg(Z)]),  # weight-8, X and Z checks on the same support
    "w7":  ([O, X, Y, Z], [O, neg(X), neg(Y)]),
    "w6p": ([O, X, Y],    [O, neg(X), neg(Y)]),          # planar control (no z)
}

def code(hnf, typ):
    G = Group(hnf); A = G.poly(TYPES[typ][0]); B = G.poly(TYPES[typ][1])
    HX = np.hstack([A, B]); HZ = np.hstack([B.T, A.T])
    assert not ((HX.astype(int) @ HZ.T) % 2).any()
    return HX, HZ

def hnfs(N):
    for d1 in range(1, N + 1):
        if N % d1: continue
        for d2 in range(1, N // d1 + 1):
            if (N // d1) % d2: continue
            d3 = N // d1 // d2
            for a in range(d1):
                for b in range(d1):
                    for c in range(d2):
                        yield ((d1, 0, 0), (a, d2, 0), (b, c, d3))

if __name__ == "__main__":
    typ = sys.argv[1]; Ns = [int(v) for v in sys.argv[2:]]
    out = []; t0 = time.time()
    for N in Ns:
        best = {}; cnt = 0
        for h in hnfs(N):
            HX, HZ = code(h, typ); n = 2 * N
            k = n - 2 * gf2.rank(HX)
            cnt += 1
            if k <= 0: continue
            best.setdefault(k, []).append(h)
        row = dict(N=N, type=typ, lattices=cnt, k_values={k: len(v) for k, v in sorted(best.items())})
        out.append(row); print(row, f"{time.time()-t0:.0f}s", flush=True)
        json.dump({str(k): v for k, v in best.items()}, open(f"cands_{typ}_{N}.json", "w"))
