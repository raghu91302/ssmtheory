"""Circuit-level simulation of the joint measurement Z_cb (x) Z_toric (surgery.py), L = 4, R rounds.
Decoder as in circuit_sim4.py.  Usage: python3 surgery_sim.py "kind,L,R,p,cap_seconds;..."  kind = merged | control
Each job appends one JSON line to surgery_sim.jsonl (lines for the same setting are pooled).
meas_fail: the measured value of Z_cb Z_toric is wrong.  data_fail: some stored logical qubit is wrong."""
import numpy as np, json, sys, time, shutil
from ldpc import BpOsdDecoder
from surgery import circuit
from fluorite_circuit import dem_matrices
OUT = "surgery_sim.jsonl"; COPY = "/mnt/user-data/outputs/fcc_distance/surgery_sim.jsonl"
def job(kind, L, R, p, cap):
    c, no, info = circuit(L, R, p, kind == "merged"); H, O, pri = dem_matrices(c); Od = O.toarray()
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0,
                       schedule="serial", osd_method="osd_cs", osd_order=4)
    seed = int(time.time() * 1000) % (2 ** 31); s = c.compile_detector_sampler(seed=seed)
    shots = meas = dat = anyf = 0; t = time.time(); o = 1 if kind == "merged" else 0
    while time.time() - t < cap:
        det, obs = s.sample(20, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8)); bad = ((Od @ e) % 2 != obs[i])
            meas += int(bad[:o].any()); dat += int(bad[o:].any()); anyf += int(bad.any())
        shots += len(det)
    return dict(kind=kind, L=L, R=R, p=p, shots=shots, meas_fail=meas, data_fail=dat, any_fail=anyf, k=no - o, seed=seed, secs=int(time.time() - t))
if __name__ == "__main__":
    for spec in sys.argv[1].split(";"):
        kd, L, R, p, cap = spec.split(","); x = job(kd, int(L), int(R), float(p), float(cap))
        with open(OUT, "a") as f: f.write(json.dumps(x) + "\n")
        print(x, flush=True)
        try: shutil.copy(OUT, COPY)
        except Exception as e: print("copy failed", e, flush=True)
