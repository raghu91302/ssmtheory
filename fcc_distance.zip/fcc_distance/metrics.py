"""Shared pooling for the two metrics. block: 1-(1-P_any)^(1/(kR)); value: 1-(1-q)^(1/R), q = wrong values / (k * shots)."""
import json, collections, os
def load(RUN):
    cb = collections.OrderedDict()   # block statistics: circuit_sim4 + mult runs
    mv = collections.OrderedDict()   # per-value statistics: mult runs only
    def add(d, key, k, R, s, f, w=0):
        a = d.setdefault(key, dict(k=k, R=R, s=0, f=0, w=0)); a["s"] += s; a["f"] += f; a["w"] += w
    for l in open(f"{RUN}/circuit_sim4.jsonl"):
        x = json.loads(l); add(cb, (x["L"], x["p"]), x["k"], x["rounds"], x["shots"], x["fails"])
    for l in open(f"{RUN}/mult_sim.jsonl"):
        x = json.loads(l)
        for d in (cb, mv): add(d, (x["L"], x["p"]), x["k"], x["rounds"], x["shots"], x["fails"], sum(x["mult"]))
    for fn in ("mult_11.json", "mult_12.json"):
        x = json.load(open(f"{RUN}/{fn}")); w = sum(b.count("1") for b in x["fails"])
        for d in (cb, mv): add(d, (4, 0.002), x["k"], 8, x["shots"], len(x["fails"]), w)
    tor = collections.OrderedDict()
    for fn in ("toric_joint.jsonl", "toric_joint_idle.jsonl"):
        if os.path.exists(f"{RUN}/{fn}"):
            for l in open(f"{RUN}/{fn}"):
                x = json.loads(l); add(tor, (x["L"], x["p"], x.get("r", 0.0)), 2, x["rounds"], x["shots"], x["any"], x["vals"])
    for d in (cb, mv, tor):
        for a in d.values():
            a["block"] = 1 - (1 - a["f"] / a["s"]) ** (1 / (a["k"] * a["R"]))
            a["value"] = 1 - (1 - a["w"] / (a["k"] * a["s"])) ** (1 / a["R"]) if a["w"] else None
            a["m"] = a["w"] / a["f"] if a["f"] and a["w"] else None
    return cb, mv, tor
if __name__ == "__main__":
    import sys
    cb, mv, tor = load(sys.argv[1] if len(sys.argv) > 1 else ".")
    print("block (pooled)"); [print(k, a["f"], a["s"], "%.2e" % a["block"]) for k, a in sorted(cb.items())]
    print("per value"); [print(k, a["f"], a["s"], "m=%.2f" % a["m"], "block %.2e value %.2e" % (a["block"], a["value"])) for k, a in sorted(mv.items())]
    print("toric"); [print(k, a["f"], a["s"], "m=%.2f" % a["m"], "block %.2e value %.2e" % (a["block"], a["value"])) for k, a in sorted(tor.items())]

def load_ens(RUN):
    """Two-setting ensemble runs (ens_main.jsonl): every shot decoded with setting A, setting B and the ensemble.
    Returns {(L, p): dict(k, R, s, secs, A=..., B=..., E=...)} with f, w, block, value, m for each decoder."""
    en = collections.OrderedDict()
    for l in open(f"{RUN}/ens_main.jsonl"):
        x = json.loads(l)
        a = en.setdefault((x["L"], x["p"]), dict(k=x["k"], R=x["rounds"], s=0, secs=0.0, choseb=0, f=[0, 0, 0], w=[0, 0, 0]))
        a["s"] += x["shots"]; a["secs"] += x["secs"]; a["choseb"] += x["chose_b"]
        for i in range(3): a["f"][i] += x["fails"][i]; a["w"][i] += sum(x["mult"][i])
    for a in en.values():
        for i, n in enumerate("ABE"):
            f, w = a["f"][i], a["w"][i]
            a[n] = dict(k=a["k"], R=a["R"], s=a["s"], f=f, w=w, block=1 - (1 - f / a["s"]) ** (1 / (a["k"] * a["R"])),
                        value=1 - (1 - w / (a["k"] * a["s"])) ** (1 / a["R"]) if w else None, m=w / f if f else None)
    return collections.OrderedDict(sorted(en.items()))
