"""Second circuit-level run: idle noise, X basis, more statistics.
Idle model: every data qubit gets DEPOLARIZE1(r*p) for each time step in which it is idle,
applied once per round as q = steps * r * p.  Idle steps per round (CNOT layers in which the
qubit is not used, plus 4 reset/measure steps): fluorite 8 + 4 = 12, toric layer 4 + 4 = 8."""
import numpy as np, json, sys, time, pymatching
from multiprocessing import Pool
from ldpc import BpOsdDecoder
from fluorite_circuit import circuit, dem_matrices
from toric_builder import rotated_toric, build
FL_STEPS, TO_STEPS = 12, 8

def fluorite_job(a):
    L, p, r, basis, rounds, cap, seed = a
    c, k = circuit(L, rounds, p, q=FL_STEPS * r * p, basis=basis); H, O, pri = dem_matrices(c)
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=60, bp_method="ms", ms_scaling_factor=0.625, osd_method="osd_cs", osd_order=4)
    s = c.compile_detector_sampler(seed=seed); fails = shots = 0; t = time.time(); Od = O.toarray()
    while fails < 60 and time.time() - t < cap:
        det, obs = s.sample(200, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8)); fails += int(((Od @ e) % 2 != obs[i]).any())
        shots += len(det)
    blk = fails / shots
    return dict(code="fluorite", L=L, k=k, p=p, r=r, basis=basis, rounds=rounds, shots=shots, fails=fails, block=blk,
                per_logical_round=1 - (1 - blk) ** (1 / (k * rounds)), secs=int(time.time() - t))

def toric_job(a):
    L, p, r = a
    c, k = build(*rotated_toric(L), p, L, TO_STEPS * r)        # builder applies idle_factor * p before each round
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    s = c.compile_detector_sampler(seed=11 + L); f = t = 0
    while t < 4e7 and f < 400:
        ev, ob = s.sample(200000, separate_observables=True); x = m.decode_batch(ev) != ob; f += int(x.sum()); t += x.size
    return dict(code="toric", L=L, k=k, p=p, r=r, fails=f, obs_samples=t, per_logical_round=1 - (1 - f / t) ** (1 / L))

if __name__ == "__main__":
    out = []
    if sys.argv[1] == "toric":
        jobs = [(L, p, r) for r in (0.1, 1.0) for L in (4, 6, 8) for p in (1e-3, 2e-3)]
        with Pool(2) as pool:
            for x in pool.imap_unordered(toric_job, jobs): out.append(x); print(x, flush=True)
        json.dump(out, open("circuit_sim2_toric.json", "w"), indent=1)
    else:
        jobs = [(4, 1e-3, 0.0, "Z", 8, 3600, 101), (4, 2e-3, 0.1, "Z", 8, 900, 102), (4, 2e-3, 0.0, "X", 8, 900, 103),
                (4, 1e-3, 0.1, "Z", 8, 2400, 104), (4, 1e-3, 0.0, "X", 8, 2400, 105), (4, 1e-3, 1.0, "Z", 8, 1500, 106)]
        with Pool(2) as pool:
            for x in pool.imap_unordered(fluorite_job, jobs):
                out.append(x); print(x, flush=True); json.dump(out, open("circuit_sim2_fluorite.json", "w"), indent=1)
