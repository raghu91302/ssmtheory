import sys, time, resource
resource.setrlimit(resource.RLIMIT_AS, (int(3.5 * 2**30),) * 2)
import fluorite_circuit, fluorite_flag_circuit
which, L, R, a, b, basis = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
c, k = (fluorite_circuit if which == "plain" else fluorite_flag_circuit).circuit(L, R, 1e-3, basis=basis); t = time.time()
try:
    e = c.search_for_undetectable_logical_errors(dont_explore_detection_event_sets_with_size_above=a, dont_explore_edges_with_degree_above=b, dont_explore_edges_increasing_symptom_degree=False)
    print(which, basis, "L", L, "rounds", R, "params", a, b, "->", len(e), "faults", int(time.time() - t), "s", flush=True)
except BaseException as ex: print(which, a, b, "failed", type(ex).__name__, flush=True)
