import numpy as np, time, sys
from ldpc import BpOsdDecoder
from fluorite_circuit import circuit, dem_matrices
L=int(sys.argv[1]); p=float(sys.argv[2]); R=2*L if L>4 else 8; n=int(sys.argv[3])
c,k=circuit(L,R,p); H,O,pri=dem_matrices(c); Od=O.toarray(); print(H.shape,flush=True)
det,obs=c.compile_detector_sampler(seed=7).sample(n,separate_observables=True)
cfg={"ms0_200_cs4":dict(max_iter=200,bp_method="ms",ms_scaling_factor=0.0,osd_method="osd_cs",osd_order=4),
"ms0_200_cs10":dict(max_iter=200,bp_method="ms",ms_scaling_factor=0.0,osd_method="osd_cs",osd_order=10),
"ms0_60_cs4":dict(max_iter=60,bp_method="ms",ms_scaling_factor=0.0,osd_method="osd_cs",osd_order=4),
"ms0_serial100_cs4":dict(max_iter=100,bp_method="ms",ms_scaling_factor=0.0,schedule="serial",osd_method="osd_cs",osd_order=4)}
for name,kw in cfg.items():
    if len(sys.argv)>4 and name not in sys.argv[4:]: continue
    d=BpOsdDecoder(H,channel_probs=list(pri),**kw)
    t=time.time(); f=0; conv=0
    for i in range(n):
        e=d.decode(det[i].astype(np.uint8)); f+=int(((Od@e)%2!=obs[i]).any()); conv+=int(d.converge)
    print(name,"fails",f,"/",n,"bp_conv",conv,"s/shot %.3f"%((time.time()-t)/n),flush=True)
