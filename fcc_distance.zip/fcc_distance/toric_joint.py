# Toric-layer baseline with joint statistics. Usage: python3 toric_joint.py [seconds per point]
# For each (L, p): shots, any (runs with at least one wrong value), vals (wrong values, 2 per run). Appends to toric_joint.jsonl.
import sys, json, time, numpy as np, pymatching
from toric_builder import rotated_toric, build
cap = float(sys.argv[1]) if len(sys.argv) > 1 else 60
for L in (4, 6, 8):
    for p in (1e-3, 1.5e-3, 2e-3, 3e-3, 4e-3, 5e-3):
        c, k = build(*rotated_toric(L), p, L, 0.0)
        m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
        s = c.compile_detector_sampler(seed=4242 + 10 * L + int(p * 1e4)); t0 = time.time(); shots = a = v = 0
        while (time.time() - t0 < cap and v < 4000) or v < 30 and time.time() - t0 < 6 * cap:
            ev, ob = s.sample(100000, separate_observables=True); x = m.decode_batch(ev) != ob
            shots += len(x); a += int(x.any(1).sum()); v += int(x.sum())
        r = dict(code="toric", L=L, p=p, rounds=L, k=k, shots=shots, any=a, vals=v, secs=round(time.time() - t0))
        open("toric_joint.jsonl", "a").write(json.dumps(r) + "\n"); print(r, flush=True)
