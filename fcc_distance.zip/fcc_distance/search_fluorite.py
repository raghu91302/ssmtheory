import numpy as np, json, sys, time
import gf2
from fluorite import code, hnfs
typ = sys.argv[1]; Ns = [int(v) for v in sys.argv[2:]]
rng = np.random.default_rng(5); res = []; t0 = time.time()
for N in Ns:
    byk = {}
    for h in hnfs(N):
        HX, HZ = code(h, typ); k = 2 * N - 2 * gf2.rank(HX)
        if k > 0: byk.setdefault(k, []).append(h)
    for k, hs in sorted(byk.items()):
        pick = [hs[i] for i in rng.permutation(len(hs))[:400]]
        scr = []
        for h in pick:
            HX, HZ = code(h, typ)
            d, _ = gf2.min_weight_logical(HZ, HX, trials=6, rng=rng)       # X-distance (= Z-distance by symmetry)
            scr.append((d, h))
        scr.sort(key=lambda t: -t[0])
        top = []
        for d0, h in scr[:4]:
            HX, HZ = code(h, typ)
            dx, _ = gf2.min_weight_logical(HZ, HX, trials=200, rng=rng)
            dz, _ = gf2.min_weight_logical(HX, HZ, trials=200, rng=rng)
            top.append((min(dx, dz), dx, dz, h))
        top.sort(key=lambda t: -t[0]); d, dx, dz, h = top[0]
        r = dict(type=typ, N=N, n=2 * N, k=k, d=d, dX=dx, dZ=dz, hnf=h, lattices_with_k=len(hs), merit=k * d * d / (2 * N))
        res.append(r)
        print(f"{typ} n={2*N:4d} k={k:3d}: best [[{2*N},{k},<={d}]]  k d^2/n = {r['merit']:.1f}   ({len(hs)} tori)  {time.time()-t0:.0f}s", flush=True)
    json.dump(res, open(f"search_{typ}.json", "w"), indent=1)
