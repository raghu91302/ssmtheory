"""Extra toric-layer baseline points (no idle noise) at p = 0.15, 0.4, 0.5 %."""
import json
from circuit_sim2 import toric_job
out = []
for p in (1.5e-3, 4e-3, 5e-3):
    for L in (4, 6, 8):
        x = toric_job((L, p, 0.0)); out.append(x); print(x, flush=True)
json.dump(out, open("toric_extra.json", "w"), indent=1)
