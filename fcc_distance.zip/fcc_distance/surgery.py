"""Joint logical measurement  Z_cb (x) Z_toric  between a checkerboard block (size L) and a rotated
toric layer (distance m = 2L), by code deformation.

Graph: the 2L qubits of a checkerboard line c_j, the 2L qubits of a toric row t_j, edge qubits on
(c_j, c_j+1), (t_j, t_j+1) and the rungs (c_j, t_j).
New Z checks  A_v = Z_v * prod Z_e (edges at v);  prod_v A_v = Z_cb Z_toric.
Old X checks that overlap the line or row get X on the edge between the two overlap qubits.
New X checks: the 2L squares (c_j, c_j+1, t_j+1, t_j).

code(L)                -> dict with merged check lists (ordered supports), sizes, operators
circuit(L, R, p, merged=True) -> stim circuit.  Data start in |0>, edges in |+>, R rounds of all checks,
     then data measured in Z and edges in X.  Z-type detectors only (as in fluorite_circuit.py).
     Observable 0 (merged only): product of the A_v outcomes of round 1 = the measured value of Z_cb Z_toric.
     Next observables: all Z logicals of the two blocks from the final data measurement.
merged=False gives the two blocks side by side with no bridge (control)."""
import numpy as np, stim, itertools, gf2
from fluorite import code as cb_code, Group
from hook_distance import supports, ORDERS
from toric_builder import rotated_toric

def cb_line(L):
    hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; E = np.eye(3, dtype=int); q = []; h = np.zeros(3, int)
    for _ in range(L):
        q.append(G.idx(tuple(h))); h = h - E[0]; q.append(N + G.idx(tuple(h))); h = h + (1 - E[0])
    return q

def code(L):
    hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; HXc, HZc = cb_code(hnf, "w8"); N = HXc.shape[0]; n1 = 2 * N
    sup = supports(hnf, ORDERS["tetra-first (4 L then 4 R)"]); m = 2 * L; n2, TZ, TX = rotated_toric(m); n = n1 + n2
    c = cb_line(L); t = [n1 + j for j in range(m)]                       # toric row 0
    Zb = [list(sup[g]) for g in range(N)] + [[n1 + x for x in s] for s in TZ]   # block Z checks (ordered)
    Xb = [list(sup[g]) for g in range(N)] + [[n1 + x for x in s] for s in TX]
    edges = [(c[j], c[(j + 1) % m]) for j in range(m)] + [(t[j], t[(j + 1) % m]) for j in range(m)] + [(c[j], t[j]) for j in range(m)]
    eid = {frozenset(e): n + i for i, e in enumerate(edges)}; S = c + t
    A = [[v] + [eid[frozenset(e)] for e in edges if v in e] for v in S]
    Xm = []
    for s in Xb:
        ov = [x for x in s if x in S]; assert len(ov) in (0, 2), ov
        Xm.append(list(s) + ([eid[frozenset(ov)]] if ov else []))
    sq = [[eid[frozenset((c[j], c[(j + 1) % m]))], eid[frozenset((c[j], t[j]))], eid[frozenset((t[j], t[(j + 1) % m]))], eid[frozenset((c[(j + 1) % m], t[(j + 1) % m]))]] for j in range(m)]
    def mat(rows, w):
        M = np.zeros((len(rows), w), np.uint8)
        for i, r in enumerate(rows): M[i, r] = 1
        return M
    HX0, HZ0 = mat(Xb, n), mat(Zb, n); LZ = gf2.quotient_basis(HX0, HZ0)
    return dict(n=n, n1=n1, ne=len(edges), S=S, Zb=Zb, Xb=Xb, A=A, Xm=Xm, sq=sq, LZ=LZ, HX0=HX0, HZ0=HZ0,
                HXm=mat(Xm + sq, n + len(edges)), HZm=mat(Zb + A, n + len(edges)))

def layers(checks, priority):
    """Greedy CNOT layers that keep each check's order; checks earlier in `priority` go first in each layer."""
    ptr = [0] * len(checks); out = []
    while any(ptr[i] < len(checks[i]) for i in range(len(checks))):
        used = set(); lay = []
        for i in priority:
            if ptr[i] < len(checks[i]) and checks[i][ptr[i]] not in used:
                used.add(checks[i][ptr[i]]); lay.append((i, checks[i][ptr[i]])); ptr[i] += 1
        out.append(lay)
    return out

def circuit(L, R, p, merged=True):
    K = code(L); n, ne = K["n"], K["ne"]; nq = n + (ne if merged else 0)
    Zc = K["Zb"] + (K["A"] if merged else []); Xc = (K["Xm"] + K["sq"]) if merged else K["Xb"]
    za = list(range(nq, nq + len(Zc))); xa = list(range(nq + len(Zc), nq + len(Zc) + len(Xc)))
    zl = layers(Zc, range(len(Zc))); xl = layers(Xc, range(len(Xc)))
    data = list(range(n)); edge = list(range(n, nq)); c = stim.Circuit()
    c.append("R", data + edge); c.append("X_ERROR", data + edge, p)
    if edge: c.append("H", edge); c.append("DEPOLARIZE1", edge, p)
    nb = len(K["Zb"]); m = 0; last = None; first = None
    for r in range(R):
        c.append("R", za); c.append("X_ERROR", za, p)
        for lay in zl:
            tg = [x for i, q in lay for x in (q, za[i])]; c.append("CX", tg); c.append("DEPOLARIZE2", tg, p)
        c.append("X_ERROR", za, p); c.append("M", za); cur = list(range(m, m + len(Zc))); m += len(Zc)
        c.append("R", xa); c.append("X_ERROR", xa, p); c.append("H", xa); c.append("DEPOLARIZE1", xa, p)
        for lay in xl:
            tg = [x for i, q in lay for x in (xa[i], q)]; c.append("CX", tg); c.append("DEPOLARIZE2", tg, p)
        c.append("H", xa); c.append("DEPOLARIZE1", xa, p); c.append("X_ERROR", xa, p); c.append("M", xa); m += len(Xc)
        for i in range(len(Zc)):
            if last is None and i >= nb: continue                        # A_v is random in round 1
            c.append("DETECTOR", [stim.target_rec(cur[i] - m)] + ([stim.target_rec(last[i] - m)] if last else []))
        if first is None: first = cur
        last = cur; firstm = m if r == 0 else firstm
    if edge: c.append("H", edge); c.append("DEPOLARIZE1", edge, p)
    c.append("X_ERROR", data + edge, p); c.append("M", data + edge); base = m; m += nq
    for i in range(nb):
        c.append("DETECTOR", [stim.target_rec(base + x - m) for x in K["Zb"][i]] + [stim.target_rec(last[i] - m)])
    o = 0
    if merged:
        c.append("DETECTOR", [stim.target_rec(base + x - m) for x in K["S"]] + [stim.target_rec(last[i] - m) for i in range(nb, len(Zc))])
        c.append("OBSERVABLE_INCLUDE", [stim.target_rec(first[i] - m) for i in range(nb, len(Zc))], 0); o = 1
    for k, row in enumerate(K["LZ"]):
        c.append("OBSERVABLE_INCLUDE", [stim.target_rec(base + int(x) - m) for x in np.nonzero(row)[0]], o + k)
    return c, o + len(K["LZ"]), dict(z_layers=len(zl), x_layers=len(xl), qubits=c.num_qubits)

if __name__ == "__main__":
    import sys
    L = int(sys.argv[1]); K = code(L); HX, HZ = K["HXm"], K["HZm"]
    assert not ((HX.astype(int) @ HZ.T) % 2).any()
    k0 = K["n"] - gf2.rank(K["HX0"]) - gf2.rank(K["HZ0"]); km = HX.shape[1] - gf2.rank(HX) - gf2.rank(HZ)
    print(f"L={L}: blocks n={K['n']} (checkerboard {K['n1']} + toric {K['n']-K['n1']}), k={k0}; bridge {K['ne']} qubits; merged k={km}; max check weight X {HX.sum(1).max()} Z {HZ.sum(1).max()}")
    rng = np.random.default_rng(0); T = int(sys.argv[2]) if len(sys.argv) > 2 else 100
    dz, _ = gf2.min_weight_logical(HX, HZ, trials=T, rng=rng); dx, _ = gf2.min_weight_logical(HZ, HX, trials=T, rng=rng)
    print(f"merged distance upper bounds: Z {dz}, X {dx}")
    for mg in (True, False):
        c, no, info = circuit(L, 3, 1e-3, mg); dem = c.detector_error_model()
        print("merged" if mg else "control", info, "observables", no, "detectors", dem.num_detectors)
