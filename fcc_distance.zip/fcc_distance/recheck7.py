import json, sys
from fault_model import *
cls = lambda g: (g[0] + g[1] + g[2]) % 2
for l in open("sub2.log"):
    p = l.split(" ", 3)
    if len(p) == 4 and p[2] == "7":
        os_ = [[(s, tuple(t)) for s, t in o] for o in json.loads(p[3])]
        res = []
        for seed in range(4):
            d, used, s = model(4, hook_comps(4, lambda gi, g: os_[cls(g)]), trials=400, seed=100 + seed, target=6); res.append(d)
            if d <= 6: break
        print(p[0], p[1], res, flush=True)
