"""Flagged circuit with the decoder of circuit_sim4.py.
Usage: python3 circuit_sim6.py "which,L,p,cap_seconds;..."  (which = flag | plain)  -> circuit_sim6.jsonl"""
import numpy as np, json, sys, time, shutil
from ldpc import BpOsdDecoder
import fluorite_circuit, fluorite_flag_circuit
from fluorite_circuit import dem_matrices
ROUNDS = {3: 5, 4: 8, 5: 10, 6: 12}
OUT = "circuit_sim6.jsonl"; COPY = "/mnt/user-data/outputs/fcc_distance/circuit_sim6.jsonl"
def job(which, L, p, cap, target=80):
    R = ROUNDS[L]; c, k = (fluorite_flag_circuit if which == "flag" else fluorite_circuit).circuit(L, R, p)
    H, O, pri = dem_matrices(c); Od = O.toarray()
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0,
                       schedule="serial", osd_method="osd_cs", osd_order=4)
    seed = int(time.time() * 1000) % (2 ** 31); s = c.compile_detector_sampler(seed=seed)
    fails = shots = conv = 0; t = time.time()
    while fails < target and time.time() - t < cap:
        det, obs = s.sample(20, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8)); fails += int(((Od @ e) % 2 != obs[i]).any()); conv += int(dec.converge)
        shots += len(det)
    return dict(circuit=which, L=L, k=k, p=p, rounds=R, shots=shots, fails=fails, bp_converged=conv, seed=seed, secs=int(time.time() - t))
if __name__ == "__main__":
    for spec in sys.argv[1].split(";"):
        w, L, p, cap = spec.split(","); x = job(w, int(L), float(p), float(cap))
        with open(OUT, "a") as f: f.write(json.dumps(x) + "\n")
        print(x, flush=True)
        try: shutil.copy(OUT, COPY)
        except Exception as e: print("copy failed", e, flush=True)
