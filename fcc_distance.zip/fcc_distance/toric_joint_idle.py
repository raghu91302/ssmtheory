# Toric-layer baseline with idle noise and joint statistics (for the idle-noise table).
# Usage: python3 toric_joint_idle.py [seconds per point]. Appends to toric_joint_idle.jsonl.
import sys, json, time, numpy as np, pymatching
from toric_builder import rotated_toric, build
TO_STEPS = 8
cap = float(sys.argv[1]) if len(sys.argv) > 1 else 60
for p, r in ((1e-3, 0.1), (1e-3, 1.0), (2e-3, 0.1)):
    for L in (4, 6, 8):
        c, k = build(*rotated_toric(L), p, L, TO_STEPS * r)
        m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
        s = c.compile_detector_sampler(seed=5151 + 10 * L + int(p * 1e4) + int(100 * r)); t0 = time.time(); shots = a = v = 0
        while (time.time() - t0 < cap and v < 4000) or v < 100 and time.time() - t0 < 8 * cap:
            ev, ob = s.sample(100000, separate_observables=True); x = m.decode_batch(ev) != ob
            shots += len(x); a += int(x.any(1).sum()); v += int(x.sum())
        rec = dict(code="toric", L=L, p=p, r=r, rounds=L, k=k, shots=shots, any=a, vals=v, secs=round(time.time() - t0))
        open("toric_joint_idle.jsonl", "a").write(json.dumps(rec) + "\n"); print(rec, flush=True)
