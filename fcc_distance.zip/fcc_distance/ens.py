# Is the failure rate limited by the decoder?  Decodes every shot with the paper's BP-OSD setting and with
# an ensemble: several BP-OSD settings, keeping the correction of lowest cost sum(log((1-p)/p)).
# Appends to ens.jsonl: shots, failures and wrong values for the single decoder and for the ensemble.
# Usage: python3 ens.py L p seconds
import sys, time, json, numpy as np
from fluorite_circuit import circuit, dem_matrices
from ldpc import BpOsdDecoder
L, p, cap = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
c, k = circuit(L, 2 * L, p); H, O, pri = dem_matrices(c); Od = O.toarray().astype(np.uint8); w = np.log((1 - pri) / pri)
kw = dict(channel_probs=list(pri), osd_method="osd_cs")
SET = [dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.0, schedule="serial", osd_order=4),      # the paper's setting
       dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.625, schedule="parallel", osd_order=4),
       dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.9, schedule="serial", osd_order=4),
       dict(max_iter=100, bp_method="ps", schedule="serial", osd_order=4),
       dict(max_iter=8, bp_method="ms", ms_scaling_factor=0.0, schedule="parallel", osd_order=10)]      # short BP, so OSD decides
decs = [BpOsdDecoder(H, **kw, **s) for s in SET]
seed = int(time.time() * 1000) % 2**31; s = c.compile_detector_sampler(seed=seed); t0 = time.time(); shots = 0
f1 = f2 = w1 = w2 = 0; win = [0] * len(SET); m1 = []; m2 = []
while time.time() - t0 < cap:
    d, o = s.sample(20, separate_observables=True)
    for i in range(20):
        syn = d[i].astype(np.uint8); cs = [dc.decode(syn) for dc in decs]; cost = [float(w @ x) for x in cs]; j = int(np.argmin(cost)); win[j] += 1
        r1 = ((Od @ cs[0]) % 2) ^ o[i]; r2 = ((Od @ cs[j]) % 2) ^ o[i]
        if r1.any(): f1 += 1; m1.append(int(r1.sum()))
        if r2.any(): f2 += 1; m2.append(int(r2.sum()))
    shots += 20
open("ens.jsonl", "a").write(json.dumps(dict(L=L, p=p, k=k, rounds=2 * L, shots=shots, seed=seed, single_fails=f1, ens_fails=f2, single_mult=m1, ens_mult=m2, chosen=win, secs=round(time.time() - t0))) + "\n")
print(L, p, shots, "single", f1, "ensemble", f2, "chosen", win, flush=True)
