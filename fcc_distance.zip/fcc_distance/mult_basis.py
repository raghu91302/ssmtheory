# Does the number of wrong values per failed shot depend on the logical basis?  Greedy search over
# changes of basis (row additions on the logical Z operators) that lower the mean number of wrong
# values in the failure patterns of mult_11.json (L = 4, p = 0.2%).  The basis is then tested on the
# independent patterns of mult_12.json, so that the result is not a fit to the same sample.
import json, numpy as np
F = np.array([[int(c) for c in b] for fn in ("mult_11.json", "mult_12.json") for b in json.load(open(fn))["fails"]], dtype=np.uint8)
print("failed shots", len(F), "distinct patterns", len({tuple(r) for r in F}), "mean wrong values", round(F.mean(1).mean() * F.shape[1], 2))
A = np.array([[int(c) for c in b] for b in json.load(open("mult_11.json"))["fails"]], dtype=np.uint8)
B = np.array([[int(c) for c in b] for b in json.load(open("mult_12.json"))["fails"]], dtype=np.uint8)
rng = np.random.default_rng(1); best = None
for t in range(20):
    G = A.copy(); H = B.copy(); improved = True
    while improved:
        improved = False
        for i in rng.permutation(G.shape[1]):
            for j in rng.permutation(G.shape[1]):
                if i != j and (G[:, i] ^ G[:, j]).sum() < G[:, i].sum(): G[:, i] ^= G[:, j]; H[:, i] ^= H[:, j]; improved = True
    m = (G.sum() / len(G), H.sum() / len(H)); best = m if best is None or m[0] < best[0] else best
print("original basis: fit set %.2f, test set %.2f" % (A.sum() / len(A), B.sum() / len(B)))
print("after greedy change of basis: fit set %.2f, test set %.2f" % best)
