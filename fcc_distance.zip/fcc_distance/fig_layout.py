import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, itertools
fig = plt.figure(figsize=(7.2, 3.6))
# (a) conventional cell
ax = fig.add_subplot(121, projection="3d")
sites = [p for p in itertools.product([0, .5, 1], repeat=3) if (round(2*sum(p)) % 2 == 0)]
tets = list(itertools.product([.25, .75], repeat=3))
octs = [p for p in itertools.product([0, .5, 1], repeat=3) if (round(2*sum(p)) % 2 == 1)]
for a, b in itertools.combinations(itertools.product([0, 1], repeat=3), 2):
    if sum(abs(np.array(a)-np.array(b))) == 1: ax.plot(*zip(a, b), color="0.75", lw=0.8)
c = (.5, .5, 0)
for t in tets:
    for s in sites:
        if abs(np.linalg.norm(np.array(t)-np.array(s)) - np.sqrt(3)/4) < 1e-9: ax.plot(*zip(t, s), color="0.6", lw=0.6)
ax.scatter(*zip(*sites), s=60, c="#1f4e9c", depthshade=False, label="FCC site: check ancilla")
ax.scatter(*zip(*tets), s=45, c="#d9822b", marker="s", depthshade=False, label="tetrahedral void: data qubit")
ax.scatter(*zip(*octs), s=40, c="white", edgecolors="k", marker="^", depthshade=False, label="octahedral void: flag qubit")
ax.set_axis_off(); ax.view_init(18, 28); ax.set_box_aspect((1, 1, 1)); ax.set_title("(a)", loc="left", fontsize=10)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, 0.02), fontsize=7, frameon=False)
# (b) one check
ax = fig.add_subplot(122, projection="3d")
L = [(s[0]*.25, s[1]*.25, s[2]*.25) for s in itertools.product([1, -1], repeat=3) if s[0]*s[1]*s[2] == 1]
R = [(s[0]*.25, s[1]*.25, s[2]*.25) for s in itertools.product([1, -1], repeat=3) if s[0]*s[1]*s[2] == -1]
for a, b in itertools.combinations(L + R, 2):
    if abs(np.linalg.norm(np.array(a)-np.array(b)) - .5) < 1e-9: ax.plot(*zip(a, b), color="0.8", lw=0.7)
for i, t in enumerate(L): ax.plot(*zip((0, 0, 0), t), color="#d9822b", lw=1.4); ax.text(t[0]*1.25, t[1]*1.25, t[2]*1.25, str(i+1), fontsize=8)
for i, t in enumerate(R): ax.plot(*zip((0, 0, 0), t), color="#7a4fb5", lw=1.4); ax.text(t[0]*1.25, t[1]*1.25, t[2]*1.25, str(i+5), fontsize=8)
ax.plot(*zip((0, 0, 0), (.5, 0, 0)), color="k", lw=1.0, ls="--")
ax.scatter(*zip(*L), s=55, c="#d9822b", marker="s", depthshade=False); ax.scatter(*zip(*R), s=55, c="#7a4fb5", marker="s", depthshade=False)
ax.scatter([0], [0], [0], s=80, c="#1f4e9c", depthshade=False); ax.scatter([.5], [0], [0], s=50, c="white", edgecolors="k", marker="^", depthshade=False)
ax.set_axis_off(); ax.view_init(18, 28); ax.set_box_aspect((1.5, 1, 1)); ax.set_xlim(-.25, .5); ax.set_title("(b)", loc="left", fontsize=10)
plt.tight_layout(); plt.savefig("fig1.pdf"); plt.savefig("fig1.png", dpi=110)
