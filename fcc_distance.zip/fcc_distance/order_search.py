import numpy as np, time, json
from hook_distance import fault_distance, ORDERS
base = ORDERS["tetra-first (4 L then 4 R)"]; rng = np.random.default_rng(2); h = [[4, 0, 0], [0, 4, 0], [0, 0, 4]]
best = []; t0 = time.time(); seen = set()
while time.time() - t0 < 900:
    perm = tuple(rng.permutation(8)); 
    if perm in seen: continue
    seen.add(perm); o = [base[i] for i in perm]
    d = fault_distance(h, o, trials=12, seed=1)
    if d >= 6:
        d = fault_distance(h, o, trials=80, seed=2)
    best.append((d, [int(i) for i in perm]))
best.sort(reverse=True); json.dump(best, open("order_search.json", "w"))
from collections import Counter
print("orders tried:", len(best), "fault-distance histogram:", sorted(Counter(d for d, _ in best).items()))
print("best:", best[:5])
