"""Measuring one weight-2L logical Z operator of the checkerboard code by code deformation (gauging).
Vertices = the 2L qubits of the operator.  Edge qubits join them (ribbon: rungs and rails; line: a cycle).
New Z checks  A_v = Z_v * prod Z_e (edges at v); their product is the logical operator.
Old X checks get X on a set of edges whose boundary is their overlap with the operator.
New X checks: the weight-4 squares of the ribbon.  The remaining long loop of X on edges turns out to be a product of the measured X checks.
Reports the merged code's parameters, check weights and distances (upper bounds from a randomized search).
Usage: python3 merge_test.py L [trials]"""
import numpy as np, sys, gf2, itertools, networkx as nx
from fluorite import code, Group
L = int(sys.argv[1]); T = int(sys.argv[2]) if len(sys.argv) > 2 else 200
hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; n = 2 * N; HX, HZ = code(hnf, "w8"); k = n - 2 * gf2.rank(HX)
A = np.array([[0, 2, 2], [2, 0, 2], [2, 2, 0]]); EL = list(G.elems())
def pos(q): return np.array(EL[q % N]) @ A + (-1 if q < N else 1)
def qidx(p):
    for s, off in ((0, 1), (1, -1)):
        u = np.array(p) + off; h4 = np.array([-u[0] + u[1] + u[2], u[0] - u[1] + u[2], u[0] + u[1] - u[2]])
        if (h4 % 4 == 0).all(): return s * N + G.idx(tuple(h4 // 4))
def build(kind):
    p = pos(0)
    if kind == "line":
        d = np.array([2, 0, 0]); S = [qidx(p + j * d) for j in range(2 * L)]; edges = [(S[j], S[(j + 1) % (2 * L)]) for j in range(2 * L)]; squares = []
    else:                                  # ribbon: rung along z, steps along (1,1,0); pick the orientation that commutes
        for sg in (1, -1):
            d = np.array([2, 2 * sg, 0]); r = np.array([0, 0, 2]); rail = [[qidx(p + j * d + e * r) for j in range(L)] for e in (0, 1)]
            S = rail[0] + rail[1]; v = np.zeros(n, int); v[S] = 1
            if len(set(S)) == 2 * L and not ((HX @ v) % 2).any(): break
        edges = [(rail[0][j], rail[1][j]) for j in range(L)] + [(rail[e][j], rail[e][(j + 1) % L]) for e in (0, 1) for j in range(L)]
        squares = [[(rail[0][j], rail[1][j]), (rail[0][(j + 1) % L], rail[1][(j + 1) % L]), (rail[0][j], rail[0][(j + 1) % L]), (rail[1][j], rail[1][(j + 1) % L])] for j in range(L)]
    return S, edges, squares
def merged(kind):
    S, edges, squares = build(kind); v = np.zeros(n, np.uint8); v[S] = 1
    assert not ((HX.astype(int) @ v) % 2).any() and gf2.rank(np.vstack([HZ, v[None]])) > gf2.rank(HZ)
    eid = {frozenset(e): n + i for i, e in enumerate(edges)}; m = n + len(edges); gr = nx.Graph(edges)
    Zc = [np.concatenate([r, np.zeros(len(edges), np.uint8)]) for r in HZ]
    for s in S:
        a = np.zeros(m, np.uint8); a[s] = 1
        for e in edges:
            if s in e: a[eid[frozenset(e)]] = 1
        Zc.append(a)
    Xc = []
    for r in HX:
        a = np.concatenate([r, np.zeros(len(edges), np.uint8)]); Tset = [s for s in S if r[s]]
        if Tset:                           # minimum-weight pairing of the overlap inside the graph
            Kg = nx.Graph(); sp = {s: nx.single_source_shortest_path(gr, s) for s in Tset}
            for x, y in itertools.combinations(Tset, 2): Kg.add_edge(x, y, weight=-len(sp[x][y]))
            for x, y in nx.max_weight_matching(Kg, maxcardinality=True):
                path = sp[x][y]
                for u, w in zip(path, path[1:]): a[eid[frozenset((u, w))]] ^= 1
        Xc.append(a)
    for sq in squares:
        a = np.zeros(m, np.uint8)
        for e in sq: a[eid[frozenset(e)]] = 1
        Xc.append(a)
    loop = np.zeros(m, np.uint8)           # the unmeasured long loop
    if kind == "line": loop[n:] = 1
    else:
        for e in edges[L:2 * L]: loop[eid[frozenset(e)]] = 1
    Xs = np.array(Xc + [loop]); Zs = np.array(Zc)
    assert not ((Xs.astype(int) @ Zs.T) % 2).any(), "merged checks must commute"
    km = m - gf2.rank(Xs) - gf2.rank(Zs)
    rng = np.random.default_rng(0)
    Xm = np.array(Xc); implied = gf2.rank(Xm) == gf2.rank(Xs)      # is the long loop a product of measured X checks?
    dz, _ = gf2.min_weight_logical(Xm, Zs, trials=T, rng=rng); dx, _ = gf2.min_weight_logical(Zs, Xm, trials=T, rng=rng)
    wx = np.array(Xc).sum(1); wz = Zs.sum(1)
    print(f"L={L} {kind}: {len(edges)} extra qubits, merged code n={m}, k={km} (block k={k}); max check weight X {wx.max()}, Z {wz.max()}; "
          f"new Z checks weight {Zs[len(HZ):].sum(1).max()}; long loop (weight {loop.sum()}) implied by measured checks: {implied}; distance upper bounds: Z {dz}, X {dx} (block d = {2*L if L > 3 else 5})", flush=True)
for kind in ("line", "ribbon"): merged(kind)
