# Correlated logical failures: how many stored values are wrong in a failed run.
# Usage: python3 mult_sim.py "L,p,seconds;L,p,seconds;..."   (checkerboard, Z basis, 2L rounds, no idle noise)
# Appends one line per 300 s chunk to mult_sim.jsonl: shots, fails (runs with any wrong value),
# flips (wrong-value count per logical operator), mult (wrong values in each failed run).
import sys, time, json, shutil, numpy as np
from fluorite_circuit import circuit, dem_matrices
from ldpc import BpOsdDecoder
def job(L, p, cap, seed):
    c, k = circuit(L, 2 * L, p); H, O, pri = dem_matrices(c); O = O.toarray().astype(np.uint8)
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0,
                       schedule="serial", osd_method="osd_cs", osd_order=4)
    s = c.compile_detector_sampler(seed=seed); t0 = time.time(); shots = 0; mult = []; flips = np.zeros(k, dtype=int)
    while time.time() - t0 < cap:
        d, o = s.sample(20, separate_observables=True)
        for i in range(20):
            r = ((O @ dec.decode(d[i].astype(np.uint8))) % 2) ^ o[i]
            if r.any(): mult.append(int(r.sum())); flips += r
        shots += 20
    return dict(code="checkerboard", L=L, p=p, rounds=2 * L, k=k, shots=shots, fails=len(mult), flips=flips.tolist(), mult=mult, seed=seed, secs=round(time.time() - t0))
if __name__ == "__main__":
    for n, j in enumerate(sys.argv[1].split(";")):
        L, p, cap = j.split(","); L = int(L); p = float(p); cap = float(cap); t = 0; i = 0
        while t < cap:
            x = job(L, p, min(300, cap - t), 900000 + 1000 * L + int(p * 1e5) * 10 + int(time.time()) % 100000 * 7 % 9973)
            open("mult_sim.jsonl", "a").write(json.dumps(x) + "\n"); print(x["L"], x["p"], x["shots"], x["fails"], flush=True); t += 300
