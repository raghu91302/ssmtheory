"""Small GF(2) toolkit for CSS code studies (numpy, uint8)."""
import numpy as np

def rref(M):
    M = (np.array(M, dtype=np.uint8) & 1).copy()
    rows, cols = M.shape
    piv = []; r = 0
    for c in range(cols):
        if r >= rows: break
        nz = np.nonzero(M[r:, c])[0]
        if len(nz) == 0: continue
        p = r + nz[0]
        if p != r: M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        if len(hit): M[hit] ^= M[r]
        piv.append(c); r += 1
    return M[:r], piv

def rank(M):
    return len(rref(M)[1]) if np.size(M) else 0

def kernel(M):
    M = np.array(M, dtype=np.uint8)
    R, piv = rref(M)
    n = M.shape[1]
    free = [c for c in range(n) if c not in set(piv)]
    K = np.zeros((len(free), n), dtype=np.uint8)
    for i, f in enumerate(free):
        K[i, f] = 1
        for j, p in enumerate(piv):
            if R[j, f]: K[i, p] = 1
    return K

def in_rowspan(R, piv, v):
    """R, piv = rref(A); is v in rowspan(A)?"""
    v = v.copy()
    for j, p in enumerate(piv):
        if v[p]: v ^= R[j]
    return not v.any()

def gf2_inv(A):
    k = A.shape[0]
    R, piv = rref(np.hstack([A.astype(np.uint8) & 1, np.eye(k, dtype=np.uint8)]))
    assert piv[:k] == list(range(k)), "singular"
    return R[:k, k:]

def quotient_basis(H_ker, H_mod):
    """Basis of ker(H_ker) modulo rowspan(H_mod)."""
    K = kernel(H_ker)
    Rm, pm = rref(H_mod)
    R, piv = rref(np.vstack([Rm, K]))
    # rows of R whose pivots are not pivots of Rm span the quotient
    # (Rm occupies the first len(pm) pivots after rref only if ordered); do it robustly:
    out = []; cur = Rm.copy(); r0 = len(pm)
    for v in K:
        t = np.vstack([cur, v]); R1, p1 = rref(t)
        if len(p1) > r0: out.append(v); cur = R1; r0 = len(p1)
    return np.array(out, dtype=np.uint8)

def logical_pairs(HX, HZ):
    """LX, LZ with LX LZ^T = I (mod 2)."""
    LZ = quotient_basis(HX, HZ)
    LX = quotient_basis(HZ, HX)
    A = (LX.astype(int) @ LZ.T.astype(int)) % 2
    LX = (gf2_inv(A).astype(int) @ LX.astype(int) % 2).astype(np.uint8)
    assert np.array_equal((LX.astype(int) @ LZ.T.astype(int)) % 2, np.eye(len(LZ), dtype=int))
    return LX, LZ

def min_weight_logical(H_ker, H_mod, trials=2000, rng=None, target=None):
    """Randomized information-set estimate of
    min wt of v in ker(H_ker) \\ rowspan(H_mod). Returns (upper bound, vector)."""
    rng = rng or np.random.default_rng(0)
    G = kernel(H_ker)                       # generator of ker
    Rm, pm = rref(H_mod)
    n = G.shape[1]; best = n + 1; bv = None
    for t in range(trials):
        perm = rng.permutation(n)
        R, piv = rref(G[:, perm])
        rows = R
        # single rows and pairwise sums of a few rows
        cand = [rows]
        if len(rows) > 1:
            idx = rng.integers(0, len(rows), size=(min(400, len(rows)**2), 2))
            idx = idx[idx[:, 0] != idx[:, 1]]
            if len(idx): cand.append(rows[idx[:, 0]] ^ rows[idx[:, 1]])
        C = np.vstack(cand)
        w = C.sum(1)
        for i in np.argsort(w):
            if w[i] == 0: continue
            if w[i] >= best: break
            v = np.zeros(n, np.uint8); v[perm] = C[i]
            if not in_rowspan(Rm, pm, v):
                best = int(w[i]); bv = v; break
        if target is not None and best <= target: break
    return best, bv
