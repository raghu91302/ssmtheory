FCC codes with growing distance: what was tried and what worked
================================================================
Requires: python3, numpy, ldpc, pymatching.  gf2.py = GF(2) tools and a randomized
distance search (upper bound; reproduces d = 6, 10, 12 for the BB codes [[72,12,6]],
[[90,8,10]], [[144,12,12]], see check_est.py).  exact_distance.py = exact
meet-in-the-middle check that no kernel vector of weight <= w exists.

1. Two-sheet code (sheets_ladder.py)
   FCC code restricted to two triad sheets: [[2L^3, L^3+2, 4]], weight-8 checks.
   L=4: [[128,66,4]], L=6: [[432,218,4]].  The graph is bipartite, so no weight-3
   logical exists; weight-4 logicals are single-sheet squares.  One more rung
   (rate 1/2, d=4) between the FCC code (rate 2/3, d=3) and one sheet (d=L).
   d=4 still corrects only one error.

2. Fluorite-lattice codes (fluorite.py, search_fluorite.py, family.py)
   Ancillas on FCC sites; data qubits on the tetrahedral voids (two per FCC site,
   species L and R).  Every coupling is nearest-neighbour: each FCC site touches its
   8 adjacent tetrahedral voids, each void its 4 adjacent FCC sites.
   Two-block form over the FCC translation group G = FCC lattice / Lambda:
   HX = [A | B], HZ = [B^T | A^T], A subset of {1,x,y,z}, B subset of {1,1/x,1/y,1/z},
   x, y, z = FCC primitive vectors.
   - weight 8 (A = 1+x+y+z, B = 1+1/x+1/y+1/z): X and Z checks on the same 8 voids
     around each FCC site.  This is the checkerboard fracton model (data qubits =
     vertices of a simple cubic lattice, checks on alternate cubes).
   - weight 6 (A = 1+x+y, B = 1+1/x+1/z).
   All sublattices Lambda (Hermite normal form) were enumerated for N = 16..96 sites.

   Best codes found (k d^2/n; rotated toric / three-sheet code = 2, gross code = 12):
     weight 8: [[64,8,8]] 8.0   [[80,10,<=8]] 8.0   [[96,12,<=8]] 8.0
               [[128,20,8]] 10.0   [[120,8,<=12]] 9.6   [[144,6,<=14]] 8.2
     weight 6: [[120,8,<=10]] 6.7   [[126,6,<=12]] 6.9   [[168,6,<=14]] 7.0
   Family on the plain FCC-primitive L x L x L torus (family.py):
     L=3 [[54,14,5]] (exact)   L=4 [[128,20,8]] (exact)
     L=5 [[250,26,<=10]]       L=6 [[432,32,<=12]]
     i.e. [[2L^3, 6L-4, 2L]] for L >= 4 as far as checked; k d^2/n -> 12.
   Exact checks: no X- or Z-type kernel vector of weight <= 7 in [[64,8,8]] and
   [[128,20,8]] (exact_distance.py), so d = 8 for both.  Entries with "<=" are
   upper bounds from the randomized search.

3. Noise check (capacity_sim.py -> capacity_sim.json)
   Independent bit flips, perfect syndromes.  [[128,20,8]] with BP-OSD vs a rotated
   toric layer [[64,2,8]] with matching.  Failure per logical qubit:
     p=1%: 1.4e-4 vs 5.6e-5    p=2%: 1.8e-3 vs 7.7e-4    p=3%: 7.1e-3 vs 3.3e-3
   Both fall as about p^4 (distance 8).  The fluorite code is about 2.4x worse per
   logical qubit and uses 6.4 data qubits per logical qubit instead of 32.

NOT DONE: circuit-level simulation (weight-8 check circuits, hook errors);
open-boundary version; exact distances for L >= 5; a full prior-work search.
The checkerboard model itself is known (Vijay, Haah, Fu 2016); its code-capacity
threshold is about 10.7% (Canossa et al., arXiv:2512.22888).

4. Prior work found after the search (see chat for links)
   [[128,20,8]] and [[54,14,5]] with these checks are published: Galimova,
   "Independent Trivariate Bicycle Codes", arXiv:2603.17703 (circuit-level
   pseudo-threshold 0.45% for [[128,20,8]]).  Not found: the family
   [[2L^3,6L-4,2L]] for L >= 5, the checkerboard identification on the
   FCC-primitive torus, the tetrahedral-void layout, a CNOT-order analysis.

5. CNOT order and hook errors (hook_distance.py, order_search.py -> order_search.json)
   One ancilla per weight-8 check.  Fault distance = fewest faults (single-qubit
   errors or ancilla hooks) giving a logical; spacelike faults only; upper bounds.
   L=4 (code distance 8): 3554 random orders: 2462 give 4, 213 give 5, 860 give 6,
   19 gave 7 at 80 trials but the two rechecked fell to 6.  Best = 6, e.g.
   'tetra-first': the four voids of one tetrahedron, then the other four.
   L=3 (code distance 5): tetra-first gives 4.

6. Circuit-level memory (fluorite_circuit.py, circuit_sim.py)
   Noise p: DEPOLARIZE2 after each CNOT, flips on reset and measurement,
   DEPOLARIZE1 after H.  No idle noise.  Z-basis memory.  One ancilla per FCC site,
   Z-check then X-check, 8 CNOT layers each, tetra-first order.
   Fluorite code: BP-OSD (min-sum, osd_cs order 4), >= 50 failures per point except
   L=4, p=0.1% (15 failures in 13,800 shots).  Rounds: 8 (L=4), 5 (L=3).
   Toric layer (FCC sheet layer, toric_builder.py): PyMatching, rounds = L.
   Failure per logical qubit per round:
        p        fluorite L=3   fluorite L=4   toric L=4   toric L=6   toric L=8
        0.10%    1.9e-4         6.8e-6         2.4e-4      9.1e-6      4.1e-7
        0.15%    4.7e-4         3.8e-5         -           -           -
        0.20%    9.1e-4         1.4e-4         9.8e-4      7.6e-5      7.0e-6
        0.30%    2.7e-3         8.5e-4         2.1e-3      2.6e-4      4.6e-5
   Qubits per logical qubit (data + ancillas): fluorite L=4: 192/20 = 9.6;
   fluorite L=3: 81/14 = 5.8; three-sheet shared, L=6: 864/36 = 24; L=4: 256/24 = 10.7.
   At p = 0.1% the L=4 fluorite code matches a distance-6 toric layer, as the
   fault distance of 6 predicts.

7. Exact distances and k (dfs_distance.py)
   Exhaustive branch-and-bound: no logical of weight <= 2L-1, logicals at 2L, so
   d = 2L exactly for L = 5, 6, 7 (L = 4 by exact_distance.py).  k = 6L-4 for L = 3..10.
   (Supersedes the "<=" entries for L = 5, 6 in section 2.)

8. Idle noise, X basis, more shots (circuit_sim2.py -> circuit_sim2_*.json)
   Idle model: DEPOLARIZE1(r p) per idle step; 12 steps per round (fluorite), 8 (toric).
   Failure per logical qubit per round, L = 4 fluorite vs toric L = 4 / 6 / 8:
     p=0.1% r=0   Z: 7.7e-6 (40/32,600)   2.4e-4  9.1e-6  4.1e-7
     p=0.1% r=0   X: 1.0e-5 (28/17,000)
     p=0.1% r=0.1 Z: 1.3e-5 (43/21,000)   3.1e-4  1.4e-5  7.1e-7
     p=0.1% r=1   Z: 1.9e-4 (60/2,000)    1.9e-3  2.2e-4  2.8e-5
     p=0.2% r=0   X: 1.9e-4 (61/2,000)
     p=0.2% r=0.1 Z: 1.6e-4 (60/2,400)    1.3e-3  1.2e-4  1.3e-5
   Fluorite L=4 matches toric L=6 at p = 0.1%, but its curve is steeper: at p = 0.3%
   it is 3.3x worse than toric L=6.

9. Flags (fluorite_flag_circuit.py, circuit_sim3.py -> circuit_sim3_flag.json)
   Flag qubit per site on the octahedral void.  L = 4, Z basis, flagged vs plain:
     0.10%: 8.7e-6 (5/3,600) vs 7.7e-6    0.15%: 2.7e-5 (6/1,400) vs 3.8e-5
     0.20%: 1.4e-4 (18/800)  vs 1.4e-4    0.30%: 7.3e-4 (44/400)  vs 8.5e-4
   No visible gain.  Fault distance of the flagged circuit not determined
   (circuit_distance.py: Stim heuristic gives <= 6 for the plain circuit; ran out
   of memory for the flagged one).

10. L = 5 (sim_L5.py -> circuit_sim_L5.json), [[250,26,10]], 10 rounds, small samples:
     0.3%: 2.2e-4 (11/200)    0.2%: 1.2e-5 (3/1,000)

11. Prior work to credit: Galimova arXiv:2603.17703 ([[54,14,5]], [[128,20,8]],
    circuit-level pseudo-threshold 0.45%); Liang & Chen arXiv:2510.05211 ([[64,8,8]],
    [[120,8,12]] parameters); Vijay-Haah-Fu 2016 (checkerboard model).

12. Final runs for the paper (new decoder: BP min-sum, adaptive scaling, serial schedule,
    100 iterations, OSD-CS order 4).
    circuit_sim4.py  -> circuit_sim4.jsonl : L = 4, 5, 6, Z basis, no idle noise (Table 2, Fig. 2)
    circuit_sim5.py  -> circuit_sim5.jsonl : L = 4, X basis and idle noise (Table 4)
    circuit_sim6.py  -> circuit_sim6.jsonl : L = 4 flagged circuit (Table 5)
    toric_extra.py   -> toric_extra.json   : toric baseline at p = 0.15, 0.4, 0.5 %
    bench.py, bench2.py, bench3.py         : decoder-setting comparison
    fault_model.py, flag_model_check.py    : fault-distance model with flags (segments cost 2)
    cd2.py                                 : Stim search, plain vs flagged, same limits
    sublattice_search.py, recheck7.py      : site-dependent CNOT orders (none above 6)
    make_results.py                        : pools the .jsonl files, writes the tables and fig2.pdf
    Lines for the same (L, p) in a .jsonl file are independent runs and are pooled.
    Older files (circuit_sim.py .. circuit_sim3.py, sim_L5.py) used the first decoder
    setting and are kept for the record only.

13. Access to single logical qubits (after the paper draft; not in the manuscript).
    access_test.py    : axis-line logical operators (weight 2L). They span half of the logical
                        space (3L-2 of 6L-4) and all commute with each other.
    partner_shape.py  : the minimum-weight partner of a line is a diagonal "ribbon": a rung of
                        two voids along one cubic axis, stepped L times along a face diagonal.
    access_test2.py   : lines + ribbons. Rank among logicals 18/20, 25/26, 30/32 (L = 4, 5, 6).
                        Independent anticommuting (Z, X) pairs of single weight-2L operators
                        found by greedy search: 14/20, 18/26, 24/32 (lower bounds).
    merge_test.py     : measuring one line or ribbon by code deformation (gauging): 2L or 3L
                        extra qubits, check weight <= 9, merged code keeps k-1 logical qubits,
                        distance upper bound = block distance (8 at L = 4, 10 at L = 5).
    Not done: circuit-level simulation of the measurement, a joint measurement with a second
    block, and a layout for the extra qubits.
