"""Control: rotated toric layer vs rotated surface code in ONE circuit family.

Both codes go through a copy of build_sheet_circuit_multiplex from the published
3sheet_code.zip (_fcc_circuit.py): same gate order (each stabilizer's CNOTs in
sequence), same noise, Z-check detectors only, idle DEPOLARIZE1(2 r p) per round
for three-way ancilla sharing at idle ratio r. Only the stabilizers change.
An FCC sheet is exactly L independent rotated toric layers, so the toric layer
here stands for the FCC sheet per logical qubit.
Within each check, qubits are visited in a fixed hook-aware order:
Z checks NW, SW, NE, SE ("N"), X checks NW, NE, SW, SE ("Z") for the
surface code; NE, SW, NW, SE for the toric layer, whose last two qubits are
diagonal (straight hooks align with one of the torus's two logical directions
and halve the circuit distance).
"""
import sys, json, numpy as np, stim, pymatching
sys.path.insert(0, __import__('os').path.dirname(__file__))
from fcc_code import to_matrix, find_logical_Z_basis


def rotated_surface(d):
    q = lambda i, j: i * d + j
    Z, X = [], []
    for a in range(-1, d):
        for b in range(-1, d):
            corners = {'NW': (a, b), 'NE': (a, b + 1), 'SW': (a + 1, b), 'SE': (a + 1, b + 1)}
            inside = {k: v for k, v in corners.items() if 0 <= v[0] < d and 0 <= v[1] < d}
            ztype = (a + b) % 2 == 0
            if len(inside) == 4:
                pass
            elif len(inside) == 2:
                if ztype and not (b == -1 or b == d - 1): continue      # Z boundary checks on left/right
                if not ztype and not (a == -1 or a == d - 1): continue  # X boundary checks on top/bottom
            else:
                continue
            order = ('NW', 'SW', 'NE', 'SE') if ztype else ('NW', 'NE', 'SW', 'SE')
            stab = [q(*inside[k]) for k in order if k in inside]
            (Z if ztype else X).append(stab)
    return d * d, Z, X


def rotated_toric(L):
    q = lambda i, j: (i % L) * L + (j % L)
    Z, X = [], []
    for a in range(L):
        for b in range(L):
            c = {'NW': (a, b), 'NE': (a, b + 1), 'SW': (a + 1, b), 'SE': (a + 1, b + 1)}
            ztype = (a + b) % 2 == 0
            order = ('NE', 'SW', 'NW', 'SE')   # diagonal hook: full circuit distance L (straight hooks give L/2)
            (Z if ztype else X).append([q(*c[k]) for k in order])
    return L * L, Z, X


def build(n_data, Z_stabs, X_stabs, p, rounds, idle_factor, carry=0.0):
    HX, HZ = to_matrix(X_stabs, n_data), to_matrix(Z_stabs, n_data)
    L_Z = find_logical_Z_basis(HX, HZ)
    n_z, n_x = len(Z_stabs), len(X_stabs)
    z_anc = list(range(n_data, n_data + n_z)); x_anc = list(range(n_data + n_z, n_data + n_z + n_x))
    p_idle = idle_factor * p
    c = stim.Circuit()
    c.append("R", list(range(n_data + n_z + n_x)))
    if p > 0: c.append("X_ERROR", list(range(n_data)), p)
    for r in range(rounds):
        if p_idle > 0: c.append("DEPOLARIZE1", list(range(n_data)), p_idle)
        c.append("R", z_anc)
        if p > 0: c.append("X_ERROR", z_anc, p)
        if carry > 0 and r > 0: c.append("X_ERROR", z_anc, carry)   # failed reset of a shared ancilla
        for i, stab in enumerate(Z_stabs):
            for d in stab:
                c.append("CX", [d, z_anc[i]])
                if p > 0: c.append("DEPOLARIZE2", [d, z_anc[i]], p)
        if p > 0: c.append("X_ERROR", z_anc, p)
        c.append("M", z_anc)
        c.append("R", x_anc)
        if p > 0: c.append("X_ERROR", x_anc, p)
        c.append("H", x_anc)
        if p > 0: c.append("DEPOLARIZE1", x_anc, p)
        for i, stab in enumerate(X_stabs):
            for d in stab:
                c.append("CX", [x_anc[i], d])
                if p > 0: c.append("DEPOLARIZE2", [x_anc[i], d], p)
        c.append("H", x_anc)
        if p > 0:
            c.append("DEPOLARIZE1", x_anc, p); c.append("X_ERROR", x_anc, p)
        c.append("M", x_anc)
        per = n_z + n_x
        for i in range(n_z):
            if r == 0: c.append("DETECTOR", [stim.target_rec(-per + i)])
            else: c.append("DETECTOR", [stim.target_rec(-per + i), stim.target_rec(-2 * per + i)])
    if p > 0: c.append("X_ERROR", list(range(n_data)), p)
    c.append("M", list(range(n_data)))
    for i, stab in enumerate(Z_stabs):
        c.append("DETECTOR", [stim.target_rec(-n_data - (n_z + n_x) + i)] + [stim.target_rec(-n_data + d) for d in stab])
    for k, lz in enumerate(L_Z):
        c.append("OBSERVABLE_INCLUDE", [stim.target_rec(-n_data + d) for d in range(n_data) if lz[d]], k)
    return c, len(L_Z)


def per_logical(c, shots, seed):
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    fails = tot = 0; left = shots; s = 0
    while left:
        b = min(left, 100000)
        ev, ob = c.compile_detector_sampler(seed=seed + s).sample(b, separate_observables=True)
        f = (m.decode_batch(ev) != ob); fails += int(f.sum()); tot += f.size; left -= b; s += 1
    return fails, tot


if __name__ == '__main__':
    P, R = 0.002, 12
    out = {}
    for r in (0.0, 0.3, 1.0, 2.0):
        for fam, sizes, shots in (('surface', (3, 5, 7), {3: 200000, 5: 400000, 7: 1000000}),
                                  ('toric', (4, 6, 8), {4: 150000, 6: 300000, 8: 600000})):
            for d in sizes:
                code = rotated_surface(d) if fam == 'surface' else rotated_toric(d)
                c, k = build(*code, P, R, 2 * r)
                f, t = per_logical(c, shots[d], 7700 + 1000 * int(10 * r) + (0 if fam == 'surface' else 500) + d)
                pl = f / t
                out[f"{fam},{r},{d}"] = dict(family=fam, r=r, d=d, k=k, fails=f, obs_samples=t,
                                             per_round=1 - (1 - pl) ** (1 / R))
                print(fam, r, d, k, f, t, f"{out[f'{fam},{r},{d}']['per_round']:.3e}", flush=True)
    json.dump(out, open('/tmp/control.json', 'w'), indent=1); print('DONE')
