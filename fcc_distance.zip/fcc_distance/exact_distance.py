"""Exact lower bound on distance for a translation-invariant CSS code by meet-in-the-middle.
Proves: no vector of weight <= w in ker(H_ker) (so every logical AND stabilizer of that
type has weight > w), or lists the kernel vectors found. Uses the translation symmetry:
any kernel vector can be shifted to contain qubit L(0) or R(0)."""
import numpy as np, itertools, sys, time, json
import gf2
from fluorite import code

def col_syndromes(H):
    m, n = H.shape; assert m <= 64
    w = (1 << np.arange(m, dtype=np.uint64)).astype(np.uint64)
    return (H.astype(np.uint64) * w[:, None]).sum(0).astype(np.uint64)   # no carries: distinct bits

def subset_syndromes(s, idxs, rmax):
    out = [np.zeros(1, np.uint64)]
    for r in range(1, rmax + 1):
        c = np.array(list(itertools.combinations(idxs, r)), dtype=np.int32)
        v = np.zeros(len(c), np.uint64)
        for j in range(r): v ^= s[c[:, j]]
        out.append(v)
    return np.concatenate(out)

def low_weight_kernel(H, w, anchors):
    """count kernel vectors of weight <= w containing an anchor (pairs of subsets)"""
    s = col_syndromes(H); n = H.shape[1]; found = 0
    ra = (w - 1 + 1) // 2; rb = (w - 1) // 2                 # others on each side: ra + rb = w - 1
    for a in anchors:
        others = [j for j in range(n) if j != a]
        T = np.sort(subset_syndromes(s, others, rb))
        S = subset_syndromes(s, others, ra) ^ s[a]
        lo = np.searchsorted(T, S, 'left'); hi = np.searchsorted(T, S, 'right')
        found += int((hi - lo).sum())
    return found

if __name__ == "__main__":
    typ = sys.argv[1]; hnf = json.loads(sys.argv[2]); w = int(sys.argv[3])
    HX, HZ = code(hnf, typ); N = HX.shape[0]; n = 2 * N; k = n - 2 * gf2.rank(HX)
    t = time.time()
    fx = low_weight_kernel(HZ, w, [0, N]); fz = low_weight_kernel(HX, w, [0, N])
    print(f"{typ} {hnf}: n={n} k={k}; kernel vectors of weight <= {w} through an anchor: X-type {fx}, Z-type {fz}  ({time.time()-t:.0f}s)")
    if fx == 0 and fz == 0: print(f"  => distance >= {w+1} (exact check)")
