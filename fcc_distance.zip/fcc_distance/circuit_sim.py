"""Circuit-level memory: weight-8 fluorite code (BP-OSD) vs rotated toric layer = FCC sheet layer (matching).
Same noise model in both.  Reports failure per logical qubit per round."""
import numpy as np, json, sys, time, pymatching
from multiprocessing import Pool
from ldpc import BpOsdDecoder
from fluorite_circuit import circuit, dem_matrices
from toric_builder import rotated_toric, build

def fluorite_job(a):
    L, p, rounds, max_shots, order = a
    c, k = circuit(L, rounds, p, order=order); H, O, pri = dem_matrices(c)
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=60, bp_method="ms", ms_scaling_factor=0.625,
                       osd_method="osd_cs", osd_order=4)
    s = c.compile_detector_sampler(seed=int(p * 1e6) + L); fails = shots = 0; t = time.time(); Od = O.toarray()
    while shots < max_shots and fails < 60:
        det, obs = s.sample(200, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8))
            fails += int(((Od @ e) % 2 != obs[i]).any())
        shots += len(det)
        if time.time() - t > 1500: break
    blk = fails / shots; per = 1 - (1 - blk) ** (1 / (k * rounds))
    return dict(code="fluorite", L=L, n=2 * L**3, k=k, p=p, rounds=rounds, shots=shots, fails=fails, block=blk, per_logical_round=per, secs=time.time() - t)

def toric_job(a):
    L, p, rounds, max_shots = a
    c, k = build(*rotated_toric(L), p, rounds, 0.0)
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    s = c.compile_detector_sampler(seed=7 + L); f = t = 0
    while t < max_shots * k and f < 400:
        ev, ob = s.sample(200000, separate_observables=True); x = m.decode_batch(ev) != ob; f += int(x.sum()); t += x.size
    return dict(code="toric", L=L, n=L * L, k=k, p=p, rounds=rounds, obs_samples=t, fails=f, per_logical_round=1 - (1 - f / t) ** (1 / rounds))

if __name__ == "__main__":
    which = sys.argv[1]; out = []
    if which == "toric":
        jobs = [(L, p, L, 20_000_000) for L in (4, 6, 8) for p in (1e-3, 2e-3, 3e-3, 4e-3)]
        with Pool(2) as pool:
            for r in pool.imap_unordered(toric_job, jobs): out.append(r); print(r, flush=True)
    else:
        from hook_distance import ORDERS
        order = ORDERS["tetra-first (4 L then 4 R)"]
        jobs = [(L, p, 8 if L == 4 else 5, 400000, order) for p in (3e-3, 2e-3, 1.5e-3, 1e-3) for L in (4, 3)]
        with Pool(2) as pool:
            for r in pool.imap_unordered(fluorite_job, jobs): out.append(r); print(r, flush=True); json.dump(out, open(f"circuit_sim_{which}.json", "w"), indent=1)
    json.dump(out, open(f"circuit_sim_{which}.json", "w"), indent=1)
