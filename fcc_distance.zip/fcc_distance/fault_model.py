"""Spacelike fault-distance model with weighted compound faults.
A compound fault is (data-error vector, cost).  Cost c is modelled with c coupled coordinates.
fault_distance(L, comp) -> (upper bound on min total cost of a logical, description of the fault set)."""
import numpy as np, gf2
from fluorite import code
from hook_distance import supports, ORDERS

def model(L, comps, trials=60, seed=0, target=None):
    hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; HX, HZ = code(hnf, "w8"); n = HX.shape[1]
    V = np.array([v for v, c, _ in comps], np.uint8); cost = [c for _, c, _ in comps]; h = len(comps)
    extra = sum(c - 1 for c in cost); tot = n + h + extra
    Hk = np.zeros((HZ.shape[0] + extra, tot), np.uint8); Hk[:HZ.shape[0], :n] = HZ; Hk[:HZ.shape[0], n:n + h] = (HZ.astype(int) @ V.T) % 2
    mod = np.zeros((h + HX.shape[0], tot), np.uint8); mod[:h, :n] = V; mod[:h, n:n + h] = np.eye(h, dtype=np.uint8); mod[h:, :n] = HX
    e = n + h; r = HZ.shape[0]
    for i, c in enumerate(cost):
        for _ in range(c - 1):
            Hk[r, n + i] = 1; Hk[r, e] = 1; mod[i, e] = 1; r += 1; e += 1
    d, v = gf2.min_weight_logical(Hk, mod, trials=trials, rng=np.random.default_rng(seed), target=target)
    used = [comps[i][2] for i in np.nonzero(v[n:n + h])[0]]; singles = list(np.nonzero(v[:n])[0])
    return d, used, singles

def hook_comps(L, order_of_site, cost=1, segments=False):
    """order_of_site(g_index, g) -> order list.  Suffix hooks (sizes 2..6) at cost `cost`;
    if segments: every contiguous segment of length 2..6 (two ancilla faults / flagged model)."""
    from fluorite import Group
    hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; n = 2 * N; out = []
    for gi, g in enumerate(G.elems()):
        o = order_of_site(gi, g); q = [(0 if s == 'L' else N) + G.idx((g[0] + t[0], g[1] + t[1], g[2] + t[2])) for s, t in o]
        segs = [(a, 8) for a in range(2, 7)] if not segments else [(a, b) for a in range(8) for b in range(a + 2, 9) if b - a <= 6 and not (a == 0 and b == 8)]
        seen = set()
        for a, b in segs:
            key = frozenset(q[a:b]); comp = frozenset(q) - key
            if key in seen or comp in seen: continue
            seen.add(key); v = np.zeros(n, np.uint8); v[q[a:b]] = 1; out.append((v, cost, (g, a, b)))
    return out

if __name__ == "__main__":
    T = ORDERS["tetra-first (4 L then 4 R)"]
    d, used, singles = model(4, hook_comps(4, lambda gi, g: T), trials=40)
    print("unflagged tetra-first: <=", d, "hooks", used, "singles", len(singles))
    d, used, singles = model(4, hook_comps(4, lambda gi, g: T, cost=2, segments=True), trials=40)
    print("flag model (segments cost 2): <=", d, "hooks", used, "singles", len(singles))
