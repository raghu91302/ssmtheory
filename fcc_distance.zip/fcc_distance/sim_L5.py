"""L = 5 circuit-level points for the plain (unflagged) circuit, [[250,26,10]], 10 rounds."""
import json, sys
from circuit_sim2 import fluorite_job
out = []
for a in [(5, 3e-3, 0.0, "Z", 10, 600, 301), (5, 2e-3, 0.0, "Z", 10, 3000, 302)]:
    x = fluorite_job(a); out.append(x); print(x, flush=True); json.dump(out, open("circuit_sim_L5.json", "w"), indent=1)
