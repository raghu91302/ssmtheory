SET = [dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.0, schedule="serial", osd_order=4),      # the paper's single setting
       dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.625, schedule="parallel", osd_order=4),
       dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.9, schedule="serial", osd_order=4),
       dict(max_iter=100, bp_method="ps", schedule="serial", osd_order=4),
       dict(max_iter=8, bp_method="ms", ms_scaling_factor=0.0, schedule="parallel", osd_order=10)]      # short BP, so OSD decides
