"""Site-dependent CNOT orders without flags: two sublattices (parity of x+y+z), each with its own order."""
import numpy as np, itertools, sys, json
from fault_model import *
from fluorite import Group
X, Y, Z, O = (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 0, 0); neg = lambda t: tuple(-u for u in t)
Ls = [('L', O), ('L', X), ('L', Y), ('L', Z)]; Rs = [('R', O), ('R', neg(X)), ('R', neg(Y)), ('R', neg(Z))]
L = 4; G = Group([[L, 0, 0], [0, L, 0], [0, 0, L]]); N = G.N; rng = np.random.default_rng(int(sys.argv[1]))
def rand_order(mode):
    if mode == "tetra":
        a = [Ls[i] for i in rng.permutation(4)]; b = [Rs[i] for i in rng.permutation(4)]; return a + b if rng.random() < .5 else b + a
    al = Ls + Rs; return [al[i] for i in rng.permutation(8)]
def conflict_free(of):
    for j in range(8):
        seen = set()
        for gi, g in enumerate(G.elems()):
            s, t = of(gi, g)[j]; q = (s, G.idx((g[0] + t[0], g[1] + t[1], g[2] + t[2])))
            if q in seen: return False
            seen.add(q)
    return True
best = 0; n = 0
while True:
    mode = "tetra" if rng.random() < .5 else "any"; nc = int(sys.argv[2])
    os_ = [rand_order(mode) for _ in range(nc)]
    cls = (lambda g: (g[0] + g[1] + g[2]) % 2) if nc == 2 else (lambda g: (g[0] % 2) + 2 * (g[1] % 2)) if nc == 4 else (lambda g: (g[0] + 2 * g[1] + 3 * g[2]) % nc)
    of = lambda gi, g: os_[cls(g)]
    if not conflict_free(of): continue
    n += 1
    d, used, s = model(L, hook_comps(L, of), trials=12, seed=n, target=6)
    if d >= 7:
        d, used, s = model(L, hook_comps(L, of), trials=150, seed=n + 1, target=6)
    if d > best or d >= 7:
        best = max(best, d); print(n, mode, d, json.dumps(os_), flush=True)
    if n % 50 == 0: print("tested", n, "best", best, flush=True)
