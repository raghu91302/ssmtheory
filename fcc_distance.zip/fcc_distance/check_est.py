import numpy as np, gf2, time
def shift(k, s): return np.roll(np.eye(k, dtype=np.uint8), s, axis=1)
def bb(l, m, A, B):
    x = lambda a: np.kron(shift(l, a % l), np.eye(m, dtype=np.uint8)); y = lambda b: np.kron(np.eye(l, dtype=np.uint8), shift(m, b % m))
    P = lambda T: sum(x(e) if v == 'x' else y(e) for v, e in T) % 2
    Am, Bm = P(A), P(B); return np.hstack([Am, Bm]).astype(np.uint8), np.hstack([Bm.T, Am.T]).astype(np.uint8)
for name, args, d in [("[[72,12,6]]", (6, 6, [('x',3),('y',1),('y',2)], [('y',3),('x',1),('x',2)]), 6),
                      ("[[90,8,10]]", (15, 3, [('x',9),('y',1),('y',2)], [('x',0),('x',2),('x',7)]), 10),
                      ("[[144,12,12]]", (12, 6, [('x',3),('y',1),('y',2)], [('y',3),('x',1),('x',2)]), 12)]:
    HX, HZ = bb(*args); t = time.time()
    for tr in (6, 30, 200):
        dx, _ = gf2.min_weight_logical(HZ, HX, trials=tr, rng=np.random.default_rng(1))
        print(name, f"known d={d}; estimator with {tr} trials: <= {dx}  ({time.time()-t:.0f}s)", flush=True)
