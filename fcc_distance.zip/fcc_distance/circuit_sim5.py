"""Variants with the decoder of circuit_sim4.py: X basis and idle noise at L = 4, and L = 3.
Usage: python3 circuit_sim5.py "L,p,r,basis,cap_seconds;..."   -> appends JSON lines to circuit_sim5.jsonl
Idle model as in circuit_sim2.py: q = 12 * r * p per data qubit per round."""
import numpy as np, json, sys, time, shutil
from ldpc import BpOsdDecoder
from fluorite_circuit import circuit, dem_matrices
ROUNDS = {3: 5, 4: 8, 5: 10, 6: 12}
OUT = "circuit_sim5.jsonl"; COPY = "/mnt/user-data/outputs/fcc_distance/circuit_sim5.jsonl"
def job(L, p, r, basis, cap, target=80):
    R = ROUNDS[L]; c, k = circuit(L, R, p, q=12 * r * p, basis=basis); H, O, pri = dem_matrices(c); Od = O.toarray()
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=100, bp_method="ms", ms_scaling_factor=0.0,
                       schedule="serial", osd_method="osd_cs", osd_order=4)
    seed = int(time.time() * 1000) % (2 ** 31); s = c.compile_detector_sampler(seed=seed)
    fails = shots = 0; t = time.time()
    while fails < target and time.time() - t < cap:
        det, obs = s.sample(20, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8)); fails += int(((Od @ e) % 2 != obs[i]).any())
        shots += len(det)
    return dict(L=L, k=k, p=p, r=r, basis=basis, rounds=R, shots=shots, fails=fails, seed=seed, secs=int(time.time() - t))
if __name__ == "__main__":
    for spec in sys.argv[1].split(";"):
        L, p, r, b, cap = spec.split(","); x = job(int(L), float(p), float(r), b, float(cap))
        with open(OUT, "a") as f: f.write(json.dumps(x) + "\n")
        print(x, flush=True)
        try: shutil.copy(OUT, COPY)
        except Exception as e: print("copy failed", e, flush=True)
