"""Upper bound on the circuit-level fault distance with Stim's heuristic search
(search_for_undetectable_logical_errors).  Compares the plain and flagged circuits."""
import sys, time, stim
import fluorite_circuit, fluorite_flag_circuit
L = int(sys.argv[1]); rounds = int(sys.argv[2]); which = sys.argv[3]; basis = sys.argv[4]
mod = fluorite_circuit if which == "plain" else fluorite_flag_circuit
c, k = mod.circuit(L, rounds, 1e-3, basis=basis)
t = time.time()
err = c.search_for_undetectable_logical_errors(dont_explore_detection_event_sets_with_size_above=int(sys.argv[5]),
        dont_explore_edges_with_degree_above=int(sys.argv[6]), dont_explore_edges_increasing_symptom_degree=False)
print(which, basis, "L", L, "rounds", rounds, "fault distance <=", len(err), int(time.time() - t), "s", flush=True)
