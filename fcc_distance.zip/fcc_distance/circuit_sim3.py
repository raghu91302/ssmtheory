"""Third run: flagged check circuit (flag qubit on the octahedral void), L = 4, no idle noise.
Same decoder settings as circuit_sim2.py so the numbers compare directly."""
import numpy as np, json, sys, time
from multiprocessing import Pool
from ldpc import BpOsdDecoder
from fluorite_circuit import dem_matrices
from fluorite_flag_circuit import circuit

def job(a):
    L, p, basis, rounds, cap, seed = a
    c, k = circuit(L, rounds, p, basis=basis); H, O, pri = dem_matrices(c)
    dec = BpOsdDecoder(H, channel_probs=list(pri), max_iter=60, bp_method="ms", ms_scaling_factor=0.625, osd_method="osd_cs", osd_order=4)
    s = c.compile_detector_sampler(seed=seed); fails = shots = 0; t = time.time(); Od = O.toarray()
    while fails < 60 and time.time() - t < cap:
        det, obs = s.sample(200, separate_observables=True)
        for i in range(len(det)):
            e = dec.decode(det[i].astype(np.uint8)); fails += int(((Od @ e) % 2 != obs[i]).any())
        shots += len(det)
    blk = fails / shots
    return dict(code="fluorite-flag", L=L, k=k, p=p, basis=basis, rounds=rounds, shots=shots, fails=fails, block=blk,
                per_logical_round=1 - (1 - blk) ** (1 / (k * rounds)), secs=int(time.time() - t))

if __name__ == "__main__":
    jobs = [(4, 3e-3, "Z", 8, 400, 201), (4, 2e-3, "Z", 8, 900, 202), (4, 1e-3, "Z", 8, 3000, 203), (4, 1.5e-3, "Z", 8, 1500, 204)]
    out = []
    with Pool(int(sys.argv[1])) as pool:
        for x in pool.imap_unordered(job, jobs):
            out.append(x); print(x, flush=True); json.dump(out, open("circuit_sim3_flag.json", "w"), indent=1)
