"""FCC code restricted to a subset of triad sheets.
3 sheets = full FCC code, 2 sheets = 'two-sheet code', 1 sheet = sheet code.
Qubits on edges of the chosen sheets; Z = vertex star, X = octahedron, both restricted."""
import numpy as np, itertools, sys, time
import gf2
SHEET = {"xy": [(1,1,0),(1,-1,0)], "xz": [(1,0,1),(1,0,-1)], "yz": [(0,1,1),(0,1,-1)]}

def build(L, sheets):
    dirs = [d for s in sheets for d in SHEET[s]]
    V = [v for v in itertools.product(range(L), repeat=3) if sum(v) % 2 == 0]
    W = [v for v in itertools.product(range(L), repeat=3) if sum(v) % 2 == 1]
    eid = {}
    def edge(a, d):
        b = tuple((a[i] + d[i]) % L for i in range(3)); k = (min(a, b), max(a, b))
        return eid.setdefault(k, len(eid))
    for v in V:
        for d in dirs: edge(v, d)
    n = len(eid)
    HZ = np.zeros((len(V), n), np.uint8)
    for i, v in enumerate(V):
        for d in dirs:
            for s in (1, -1): HZ[i, edge(v, tuple(s * t for t in d))] ^= 1
    HX = np.zeros((len(W), n), np.uint8)
    full = set(dirs) | set(tuple(-t for t in d) for d in dirs)
    for i, w in enumerate(W):
        nb = [tuple((w[j] + s * (j == ax)) % L for j in range(3)) for ax in range(3) for s in (1, -1)]
        raw = [tuple(w[j] + s * (j == ax) for j in range(3)) for ax in range(3) for s in (1, -1)]
        for a in range(6):
            for b in range(a + 1, 6):
                d = tuple(raw[b][j] - raw[a][j] for j in range(3))
                if d in full: HX[i, eid[(min(nb[a], nb[b]), max(nb[a], nb[b]))]] ^= 1
    assert not ((HX.astype(int) @ HZ.T) % 2).any()
    return HX, HZ

if __name__ == "__main__":
    for L in (4, 6):
        for sheets in (["xy", "xz", "yz"], ["xz", "yz"], ["xy"]):
            t = time.time(); HX, HZ = build(L, sheets); n = HX.shape[1]
            k = n - gf2.rank(HX) - gf2.rank(HZ)
            tr = 300 if n < 300 else 60
            dx, _ = gf2.min_weight_logical(HZ, HX, trials=tr); dz, _ = gf2.min_weight_logical(HX, HZ, trials=tr)
            print(f"L={L} sheets={'+'.join(sheets):9s}: [[{n},{k},<={min(dx,dz)}]] (dX<={dx}, dZ<={dz}) rate {k/n:.2f} "
                  f"check weight {int(HZ.sum(1).max())}  ({time.time()-t:.0f}s)", flush=True)
