"""Addressing single logical qubits of the checkerboard code.
Two families of weight-2L logical operators: axis lines, and diagonal ribbons
(a rung of two voids along one cubic axis, stepped L times along a perpendicular face diagonal).
T1: ranks.  T2: largest set of independent, mutually commuting pairs (Z-operator, X-operator) that anticommute.
Usage: python3 access_test2.py L"""
import numpy as np, sys, gf2, itertools
from fluorite import code, Group
L = int(sys.argv[1]); hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; n = 2 * N
HX, HZ = code(hnf, "w8"); k = n - 2 * gf2.rank(HX); rs = gf2.rank(HX)
A = np.array([[0, 2, 2], [2, 0, 2], [2, 2, 0]]); EL = list(G.elems())
def pos(q): return np.array(EL[q % N]) @ A + (-1 if q < N else 1)
def qidx(p):
    for s, off in ((0, 1), (1, -1)):
        u = np.array(p) + off; h4 = np.array([-u[0] + u[1] + u[2], u[0] - u[1] + u[2], u[0] + u[1] - u[2]])
        if (h4 % 4 == 0).all(): return s * N + G.idx(tuple(h4 // 4))
    raise ValueError(p)
ops = {}
for q0 in range(n):
    p = pos(q0)
    for ax in range(3):                                            # axis lines
        d = np.zeros(3, int); d[ax] = 2; q = [qidx(p + j * d) for j in range(2 * L)]
        ops[("line", frozenset(q))] = q
    for ax in range(3):                                            # ribbons: rung along ax, steps along a face diagonal perpendicular to ax
        b, c = [i for i in range(3) if i != ax]; r = np.zeros(3, int); r[ax] = 2
        for sg in (1, -1):
            d = np.zeros(3, int); d[b] = 2; d[c] = 2 * sg
            q = [qidx(p + j * d + e * r) for j in range(L) for e in (0, 1)]
            if len(set(q)) == 2 * L: ops[("ribbon", frozenset(q))] = q
keys = list(ops); V = np.zeros((len(keys), n), np.uint8)
for i, kk in enumerate(keys): V[i, ops[kk]] = 1
ok = ~((HX.astype(int) @ V.T) % 2).any(0); keys = [kk for kk, o in zip(keys, ok) if o]; V = V[ok]
typ = np.array([kk[0] for kk in keys]); rk = lambda M: gf2.rank(np.vstack([HX, M])) - rs
print(f"L={L} k={k}: lines {sum(typ=='line')} (rank {rk(V[typ=='line'])}), ribbons that commute with checks {sum(typ=='ribbon')} (rank {rk(V[typ=='ribbon']) if (typ=='ribbon').any() else 0}), together rank {rk(V)} of {k}")
C = (V.astype(int) @ V.T) % 2
print("rank of the commutation matrix (logical qubits reachable with products of these operators):", gf2.rank(C.astype(np.uint8)))
rng = np.random.default_rng(0); best = []
nontriv = [i for i in range(len(keys)) if rk(V[[i]]) == 1]
for trial in range(int(sys.argv[2]) if len(sys.argv) > 2 else 200):
    zs = []; xs = []
    for i in sorted(nontriv, key=lambda i: C[i].sum() + 3 * rng.random()):
        if any(C[i, x] for x in xs): continue
        cand = [j for j in rng.permutation(nontriv) if C[i, j] and not any(C[z, j] for z in zs)]
        if not cand: continue
        j = min(cand[:12], key=lambda j: C[j].sum() + rng.random()); zs.append(int(i)); xs.append(int(j))
    if len(zs) > len(best): best = list(zip(zs, xs))
    if len(best) == k: break
M = C[np.ix_([a for a, b in best], [b for a, b in best])]; assert (M == np.eye(len(best), dtype=M.dtype)).all()
from collections import Counter
print(f"independent addressable pairs found: {len(best)} of k = {k};  pair types (Z,X): {dict(Counter((typ[a], typ[b]) for a, b in best))}")
np.save(f"access_pairs_L{L}.npy", np.array([[ops[keys[a]], ops[keys[b]]] for a, b in best]))
