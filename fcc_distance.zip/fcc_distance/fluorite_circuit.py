"""Stim memory circuit for the weight-8 fluorite (checkerboard) code on the FCC-primitive
L x L x L torus.  One ancilla per FCC site, used for the Z-check and then the X-check.
Noise: DEPOLARIZE2(p) after every CNOT, X_ERROR(p) after reset and before measurement,
DEPOLARIZE1(p) after H, optional DEPOLARIZE1(q) on data before each round (idle).
Z-basis memory: detectors on Z-checks only (X-checks are still run and add noise)."""
import numpy as np, stim
import gf2
from fluorite import code
from hook_distance import supports, ORDERS

def circuit(L, rounds, p, q=0.0, order=None, hnf=None, basis="Z"):
    hnf = hnf or [[L, 0, 0], [0, L, 0], [0, 0, L]]
    order = order or ORDERS["tetra-first (4 L then 4 R)"]
    HX, HZ = code(hnf, "w8"); N = HX.shape[0]; n = 2 * N
    LX, LZ = gf2.logical_pairs(HX, HZ)
    sup = supports(hnf, order)                               # sup[g][j] = data qubit of j-th CNOT at site g
    for g in range(N): assert sorted(sup[g]) == sorted(np.nonzero(HX[g])[0].tolist())
    data = list(range(n)); anc = list(range(n, n + N))
    c = stim.Circuit(); c.append("R", data + anc); c.append("X_ERROR", data, p)
    if basis == "X": c.append("H", data); c.append("DEPOLARIZE1", data, p)
    m = 0; last = None
    for r in range(rounds):
        if q > 0: c.append("DEPOLARIZE1", data, q)
        # Z-check: data control, ancilla target
        c.append("R", anc); c.append("X_ERROR", anc, p)
        for j in range(8):
            t = [x for g in range(N) for x in (sup[g][j], anc[g])]
            c.append("CX", t); c.append("DEPOLARIZE2", t, p)
        c.append("X_ERROR", anc, p); c.append("M", anc); zi = list(range(m, m + N)); m += N
        if basis == "Z": cur = zi
        # X-check: ancilla control
        c.append("R", anc); c.append("X_ERROR", anc, p); c.append("H", anc); c.append("DEPOLARIZE1", anc, p)
        for j in range(8):
            t = [x for g in range(N) for x in (anc[g], sup[g][j])]
            c.append("CX", t); c.append("DEPOLARIZE2", t, p)
        c.append("H", anc); c.append("DEPOLARIZE1", anc, p); c.append("X_ERROR", anc, p); c.append("M", anc)
        if basis == "X": cur = list(range(m, m + N))
        m += N
        for g in range(N):
            recs = [stim.target_rec(cur[g] - m)] + ([stim.target_rec(last[g] - m)] if last else [])
            c.append("DETECTOR", recs)
        last = cur
    if basis == "X": c.append("H", data); c.append("DEPOLARIZE1", data, p)
    c.append("X_ERROR", data, p); c.append("M", data); base = m; m += n
    if basis == "X": LZ = LX
    for g in range(N):
        c.append("DETECTOR", [stim.target_rec(base + int(x) - m) for x in np.nonzero(HZ[g])[0]] + [stim.target_rec(last[g] - m)])
    for k, row in enumerate(LZ):
        c.append("OBSERVABLE_INCLUDE", [stim.target_rec(base + int(x) - m) for x in np.nonzero(row)[0]], k)
    return c, len(LZ)

def dem_matrices(c):
    """detector error model -> (check matrix, observable matrix, priors), merging identical columns"""
    dem = c.detector_error_model(decompose_errors=False, flatten_loops=True)
    cols = {}
    for inst in dem:
        if inst.type != "error": continue
        p = inst.args_copy()[0]
        dets = frozenset(t.val for t in inst.targets_copy() if t.is_relative_detector_id())
        obs = frozenset(t.val for t in inst.targets_copy() if t.is_logical_observable_id())
        key = (dets, obs); p0 = cols.get(key, 0.0); cols[key] = p0 * (1 - p) + p * (1 - p0)
    from scipy.sparse import csc_matrix
    nd, no = dem.num_detectors, dem.num_observables
    r1, c1, r2, c2, pri = [], [], [], [], []
    for j, ((dets, obs), p) in enumerate(cols.items()):
        r1 += list(dets); c1 += [j] * len(dets); r2 += list(obs); c2 += [j] * len(obs); pri.append(p)
    H = csc_matrix((np.ones(len(r1), np.uint8), (r1, c1)), shape=(nd, len(pri)))
    O = csc_matrix((np.ones(len(r2), np.uint8), (r2, c2)), shape=(no, len(pri)))
    return H, O, np.array(pri)

if __name__ == "__main__":
    for L in (3, 4):
        c, k = circuit(L, 4, 1e-3)
        H, O, pri = dem_matrices(c)
        print(f"L={L}: k={k}, qubits={c.num_qubits}, detectors={H.shape[0]}, error mechanisms={H.shape[1]}, max detectors per mechanism={int(H.sum(0).max())}")
