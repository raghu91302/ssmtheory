# Summary of diag.jsonl.  Usage: python3 diag_report.py
import json, numpy as np, collections
d = collections.defaultdict(lambda: dict(shots=0, f=[]))
for l in open("diag.jsonl"):
    r = json.loads(l); d[r["p"]]["shots"] += r["shots"]; d[r["p"]]["f"] += r["fails"]; d[r["p"]]["mf"] = r["mean_faults"]
m = lambda X: np.mean([x["f"].count("1") for x in X]) if X else 0
for p, a in sorted(d.items()):
    F = a["f"]; sub = [x for x in F if x["cc"] > x["ce"] + 1e-9]; opt = [x for x in F if x["cc"] <= x["ce"] + 1e-9]
    print(f"p={p}: shots {a['shots']}, failed {len(F)}, mean faults per shot {a['mf']:.1f}, mean wrong values {m(F):.2f}")
    print(f"   correction less likely than the true faults (decoder at fault): {len(sub)}, mean wrong values {m(sub):.1f}, BP not converged in {sum(not x['conv'] for x in sub)}")
    print(f"   correction at least as likely as the true faults (no decoder could be sure): {len(opt)}, mean wrong values {m(opt):.1f}, BP not converged in {sum(not x['conv'] for x in opt)}")
