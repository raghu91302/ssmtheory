# k of the checkerboard code on the cubic torus of even side Lc (Lc^3 qubits): 6*Lc-6, the value quoted by Vijay-Haah-Fu.
import numpy as np, itertools
from gf2 import rank
for Lc in (4,6,8):
    idx=lambda x,y,z:((x%Lc)*Lc+(y%Lc))*Lc+(z%Lc)
    rows=[]
    for x,y,z in itertools.product(range(Lc),repeat=3):
        if (x+y+z)%2==0:
            r=np.zeros(Lc**3,dtype=np.uint8)
            for d in itertools.product((0,1),repeat=3): r[idx(x+d[0],y+d[1],z+d[2])]=1
            rows.append(r)
    H=np.array(rows); print(Lc,'n',Lc**3,'k',Lc**3-2*rank(H),'6Lc-6',6*Lc-6)
