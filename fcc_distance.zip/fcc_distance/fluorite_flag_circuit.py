"""Flagged version of the weight-8 check circuit.  One extra 'flag' qubit per FCC site
(physically: the adjacent octahedral void), coupled only to that site's ancilla.
Z-check: ancilla is the CNOT target; a Z fault on it spreads to data.  Flag starts in |+>,
CNOT(flag -> ancilla) after the first data CNOT and again before the last; flag measured in X.
X-check: ancilla is the control (in |+>); an X fault spreads.  Flag starts in |0>,
CNOT(ancilla -> flag) after the first data CNOT and before the last; flag measured in Z.
Detectors: check outcomes (Z or X by basis) and all flag outcomes."""
import numpy as np, stim, gf2
from fluorite import code
from hook_distance import supports, ORDERS

def circuit(L, rounds, p, q=0.0, basis="Z", order=None):
    hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; order = order or ORDERS["tetra-first (4 L then 4 R)"]
    HX, HZ = code(hnf, "w8"); N = HX.shape[0]; n = 2 * N; LX, LZ = gf2.logical_pairs(HX, HZ); sup = supports(hnf, order)
    data = list(range(n)); anc = list(range(n, n + N)); flg = list(range(n + N, n + 2 * N))
    af = [x for g in range(N) for x in (anc[g], flg[g])]; fa = [x for g in range(N) for x in (flg[g], anc[g])]
    c = stim.Circuit(); c.append("R", data + anc + flg); c.append("X_ERROR", data, p)
    if basis == "X": c.append("H", data); c.append("DEPOLARIZE1", data, p)
    m = 0; last = None
    def layer(j, kind):
        t = [x for g in range(N) for x in ((sup[g][j], anc[g]) if kind == "Z" else (anc[g], sup[g][j]))]
        c.append("CX", t); c.append("DEPOLARIZE2", t, p)
    for r in range(rounds):
        if q > 0: c.append("DEPOLARIZE1", data, q)
        # ---- Z-check
        c.append("R", anc + flg); c.append("X_ERROR", anc + flg, p); c.append("H", flg); c.append("DEPOLARIZE1", flg, p)
        layer(0, "Z"); c.append("CX", fa); c.append("DEPOLARIZE2", fa, p)
        for j in range(1, 7): layer(j, "Z")
        c.append("CX", fa); c.append("DEPOLARIZE2", fa, p); layer(7, "Z")
        c.append("H", flg); c.append("DEPOLARIZE1", flg, p); c.append("X_ERROR", anc + flg, p); c.append("M", anc + flg)
        zi = list(range(m, m + N)); zf = list(range(m + N, m + 2 * N)); m += 2 * N
        # ---- X-check
        c.append("R", anc + flg); c.append("X_ERROR", anc + flg, p); c.append("H", anc); c.append("DEPOLARIZE1", anc, p)
        layer(0, "X"); c.append("CX", af); c.append("DEPOLARIZE2", af, p)
        for j in range(1, 7): layer(j, "X")
        c.append("CX", af); c.append("DEPOLARIZE2", af, p); layer(7, "X")
        c.append("H", anc); c.append("DEPOLARIZE1", anc, p); c.append("X_ERROR", anc + flg, p); c.append("M", anc + flg)
        xi = list(range(m, m + N)); xf = list(range(m + N, m + 2 * N)); m += 2 * N
        cur = zi if basis == "Z" else xi
        for g in range(N):
            c.append("DETECTOR", [stim.target_rec(cur[g] - m)] + ([stim.target_rec(last[g] - m)] if last else []))
        for g in range(N):
            c.append("DETECTOR", [stim.target_rec(zf[g] - m)]); c.append("DETECTOR", [stim.target_rec(xf[g] - m)])
        last = cur
    if basis == "X": c.append("H", data); c.append("DEPOLARIZE1", data, p)
    c.append("X_ERROR", data, p); c.append("M", data); base = m; m += n
    Lg = LZ if basis == "Z" else LX
    for g in range(N):
        c.append("DETECTOR", [stim.target_rec(base + int(x) - m) for x in np.nonzero(HZ[g])[0]] + [stim.target_rec(last[g] - m)])
    for k, row in enumerate(Lg):
        c.append("OBSERVABLE_INCLUDE", [stim.target_rec(base + int(x) - m) for x in np.nonzero(row)[0]], k)
    return c, len(Lg)

if __name__ == "__main__":
    from fluorite_circuit import dem_matrices
    for b in "ZX":
        c, k = circuit(3, 3, 1e-3, basis=b); H, O, pri = dem_matrices(c)
        print(b, "L=3: qubits", c.num_qubits, "detectors", H.shape[0], "mechanisms", H.shape[1])
