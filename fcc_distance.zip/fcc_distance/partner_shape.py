"""Minimum-weight logical operator that anticommutes with a given line operator, and its shape."""
import numpy as np, sys, gf2
from fluorite import code, Group
L = int(sys.argv[1]); hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; n = 2 * N
HX, HZ = code(hnf, "w8"); E = np.eye(3, dtype=int); A = np.array([[0, 2, 2], [2, 0, 2], [2, 2, 0]])
def pos(q):
    h = np.array(list(G.elems())[q % N]); return h @ A + (-1 if q < N else 1)
def line(h, ax):
    q = []; h = np.array(h)
    for _ in range(L):
        q.append(G.idx(tuple(h))); h = h - E[ax]; q.append(N + G.idx(tuple(h))); h = h + (1 - E[ax])
    return q
l = np.zeros(n, np.uint8); l[line((0, 0, 0), 0)] = 1
Hmod = gf2.kernel(np.vstack([HZ, l[None]]))
d, v = gf2.min_weight_logical(HZ, Hmod, trials=int(sys.argv[2]), rng=np.random.default_rng(1))
print("L", L, "min weight of a partner (upper bound):", d)
P = np.array([pos(q) for q in np.nonzero(v)[0]]); print("positions (units a/4, mod torus):"); print(P[np.lexsort(P.T[::-1])].tolist())
np.save(f"partner_L{L}.npy", v)
