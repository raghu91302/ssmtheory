"""Pools circuit_sim4.jsonl / circuit_sim5.jsonl, writes tab_main.tex and fig2.pdf, prints a summary."""
import json, sys, collections, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
RUN = sys.argv[1] if len(sys.argv) > 1 else "."
def pool(fn, key):
    d = collections.OrderedDict()
    for l in open(f"{RUN}/{fn}"):
        x = json.loads(l); a = d.setdefault(key(x), dict(f=0, s=0, k=x["k"], R=x["rounds"])); a["f"] += x["fails"]; a["s"] += x["shots"]
    for a in d.values(): a["rate"] = 1 - (1 - a["f"] / a["s"]) ** (1 / (a["k"] * a["R"])) if a["s"] else None
    return d
def sci(v):
    if v is None or v == 0: return "--"
    e = int(np.floor(np.log10(v))); return f"${v/10**e:.1f}\\times10^{{{e}}}$"
main = pool("circuit_sim4.jsonl", lambda x: (x["L"], x["p"]))
toric = {0.001: (2.4e-4, 9.1e-6, 4.1e-7), 0.0015: (5.4e-4, 3.0e-5, 2.4e-6), 0.002: (9.8e-4, 7.6e-5, 7.0e-6),
         0.003: (2.1e-3, 2.6e-4, 4.6e-5), 0.004: (3.8e-3, 6.9e-4, 1.6e-4), 0.005: (5.9e-3, 1.4e-3, 4.3e-4)}
P = sorted(toric)
rows = []
for p in P:
    c = [f"{100*p:.2f}\\%"]
    for L in (4, 5, 6):
        a = main.get((L, p)); c.append(f"{sci(a['rate'])} ({a['f']}/{a['s']:,})" if a and a["f"] else ("--" if not a else f"$<${sci(1-(1-3/a['s'])**(1/(a['k']*a['R'])))} (0/{a['s']:,})"))
    c += [sci(v) for v in toric[p]]; rows.append(" & ".join(c) + "\\\\")
open("tab_main.tex", "w").write("\n".join(rows) + "\n")
for k, a in main.items(): print(k, a["f"], a["s"], "%.2e" % a["rate"])
fig, ax = plt.subplots(figsize=(5.6, 4.0))
for L, c, lab in [(4, "#f0a35e", "checkerboard L=4  [[128,20,8]]"), (5, "#d1542b", "checkerboard L=5  [[250,26,10]]"), (6, "#7d1d12", "checkerboard L=6  [[432,32,12]]")]:
    pts = [(100 * p, a["rate"], a["f"]) for (l, p), a in sorted(main.items()) if l == L and a["f"] > 0]
    if pts:
        x, y, f = zip(*pts); ax.errorbar(x, y, yerr=[v / np.sqrt(n) for v, n in zip(y, f)], marker="s", color=c, lw=2, ms=5.5, capsize=2, label=lab)
for i, (L, c) in enumerate([(4, "#a9c1e8"), (6, "#4a7bc8"), (8, "#173f85")]):
    ax.plot([100 * p for p in P], [toric[p][i] for p in P], marker="o", ls="--", color=c, lw=1.4, ms=4.5, label=f"toric layer L={L}")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xticks([.1, .15, .2, .3, .4, .5]); ax.set_xticklabels(["0.1", "0.15", "0.2", "0.3", "0.4", "0.5"]); ax.minorticks_off()
ax.set_xlabel("gate error p (%)"); ax.set_ylabel("failure per logical qubit per round"); ax.grid(alpha=.25); ax.legend(fontsize=7.5, frameon=False, loc="lower right")
plt.tight_layout(); plt.savefig("fig2.pdf"); plt.savefig("fig2.png", dpi=110)

# ---- flags (circuit_sim6.jsonl) and X basis / idle noise / L = 3 (circuit_sim5.jsonl)
import os
def cell(a): return f"{sci(a['rate'])} ({a['f']}/{a['s']:,})" if a and a["f"] else "running"
if os.path.exists(f"{RUN}/circuit_sim6.jsonl"):
    fl = pool("circuit_sim6.jsonl", lambda x: (x["circuit"], x["p"]))
    open("tab_flag.tex", "w").write("\n".join(f"{100*p:.2f}\\% & {cell(main.get((4, p)))} & {cell(fl.get(('flag', p)))}\\\\" for p in (0.001, 0.0015, 0.002, 0.003)) + "\n")
    for k, a in fl.items(): print(k, a["f"], a["s"], "%.2e" % a["rate"])
if os.path.exists(f"{RUN}/circuit_sim5.jsonl"):
    v = pool("circuit_sim5.jsonl", lambda x: (x["L"], x["p"], x["r"], x["basis"]))
    tor = {(0.001, 0.1): ("3.1\\times10^{-4}", "1.4\\times10^{-5}", "7.1\\times10^{-7}"), (0.001, 1.0): ("1.9\\times10^{-3}", "2.2\\times10^{-4}", "2.8\\times10^{-5}"),
           (0.002, 0.1): ("1.3\\times10^{-3}", "1.2\\times10^{-4}", "1.3\\times10^{-5}")}
    rows = []
    for p, r, b in [(0.001, 0.0, "X"), (0.002, 0.0, "X"), (0.001, 0.1, "Z"), (0.001, 1.0, "Z"), (0.002, 0.1, "Z")]:
        t = tor.get((p, r)); rows.append(f"{100*p:.1f}\\% & $r={r:g}$, ${b}$ & {cell(v.get((4, p, r, b)))} & " + (" & ".join(f"${u}$" for u in t) if t else "-- & -- & --") + "\\\\")
    open("tab_idle.tex", "w").write("\n".join(rows) + "\n")
    for k, a in v.items(): print(k, a["f"], a["s"], "%.2e" % a["rate"] if a["rate"] else None)
