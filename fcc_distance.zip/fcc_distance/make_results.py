"""Pools the raw files and writes tab_main.tex (block metric), tab_value.tex (per stored value), tab_flag.tex, tab_idle.tex and fig2.pdf.
Usage: python3 make_results.py RUN_DIR"""
import json, sys, os, collections, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from metrics import load, load_ens
RUN = sys.argv[1] if len(sys.argv) > 1 else "."
cb, mv, tor = load(RUN); en = load_ens(RUN)
EN = collections.OrderedDict((k, a["E"]) for k, a in en.items())   # ensemble: main result
def sci(v):
    if v is None or v == 0: return "--"
    e = int(np.floor(np.log10(v))); m = round(v / 10**e, 1)
    if m >= 10: m, e = 1.0, e + 1
    return f"${m:.1f}\\times10^{{{e}}}$"
P = [0.001, 0.0015, 0.002, 0.003, 0.004, 0.005]
def cell(a): return f"{sci(a['block'])} ({a['f']}/{a['s']:,})" if a and a["f"] else "--"
rows = []
for p in P:
    c = [f"{100*p:.2f}\\%"] + [cell(EN.get((L, p))) for L in (4, 5, 6)]
    c += [sci(tor[(L, p, 0.0)]["block"]) for L in (4, 6, 8)]; rows.append(" & ".join(c) + "\\\\")
open("tab_main.tex", "w").write("\n".join(rows) + "\n")
rows = []
for p in P:
    c = [f"{100*p:.2f}\\%"]
    for L in (4, 5, 6):
        a = EN.get((L, p)); c.append(f"{sci(a['value'])} ({a['m']:.1f}; {a['f']})" if a and a["f"] else "--")
    c += [sci(tor[(L, p, 0.0)]["value"]) for L in (4, 6, 8)]; rows.append(" & ".join(c) + "\\\\")
open("tab_value.tex", "w").write("\n".join(rows) + "\n")
rows = []
for (L, p), a in en.items():
    A, E = a["A"], a["E"]
    rows.append(f"{L} & {100*p:.2f}\\% & {a['s']:,} & {A['f']} & {E['f']} & {sci(A['block'])} & {sci(E['block'])} & {A['block']/E['block']:.1f}\\\\")
open("tab_ens.tex", "w").write("\n".join(rows) + "\n")
fig, axs = plt.subplots(1, 2, figsize=(9.6, 4.5), sharey=True)
for ax, d, key, ttl in ((axs[0], EN, "block", "(a) block failure per logical qubit per round"), (axs[1], EN, "value", "(b) error per stored value per round")):
    for L, c, lab in [(4, "#f0a35e", "checkerboard L=4  [[128,20,8]]"), (5, "#d1542b", "checkerboard L=5  [[250,26,10]]"), (6, "#7d1d12", "checkerboard L=6  [[432,32,12]]")]:
        pts = [(100 * p, a[key], a["f"]) for (l, p), a in sorted(d.items()) if l == L and a["f"] > 0]
        if pts:
            x, y, f = zip(*pts); ax.errorbar(x, y, yerr=[v / np.sqrt(n) for v, n in zip(y, f)], marker="s", color=c, lw=2, ms=5.5, capsize=2, label=lab)
    for L, c in [(4, "#a9c1e8"), (6, "#4a7bc8"), (8, "#173f85")]:
        ax.plot([100 * p for p in P], [tor[(L, p, 0.0)][key] for p in P], marker="o", ls="--", color=c, lw=1.4, ms=4.5, label=f"toric layer L={L}")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xticks([.1, .15, .2, .3, .4, .5]); ax.set_xticklabels(["0.1", "0.15", "0.2", "0.3", "0.4", "0.5"]); ax.minorticks_off()
    ax.set_xlabel("gate error p (%)"); ax.set_title(ttl, fontsize=9.5); ax.grid(alpha=.25)
axs[0].set_ylabel("rate per round"); axs[1].tick_params(labelleft=True)
h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, fontsize=8, frameon=False, loc="lower center", ncol=3)
plt.tight_layout(rect=(0, 0.11, 1, 1)); plt.savefig("fig2.pdf"); plt.savefig("fig2.png", dpi=110)
def pool(fn, key):
    d = collections.OrderedDict()
    for l in open(f"{RUN}/{fn}"):
        x = json.loads(l); a = d.setdefault(key(x), dict(f=0, s=0, k=x["k"], R=x["rounds"])); a["f"] += x["fails"]; a["s"] += x["shots"]
    for a in d.values(): a["block"] = 1 - (1 - a["f"] / a["s"]) ** (1 / (a["k"] * a["R"]))
    return d
fl = pool("circuit_sim6.jsonl", lambda x: (x["circuit"], x["p"]))
open("tab_flag.tex", "w").write("\n".join(f"{100*p:.2f}\\% & {cell(cb.get((4, p)))} & {cell(fl.get(('flag', p)))}\\\\" for p in (0.001, 0.0015, 0.002, 0.003)) + "\n")
v = pool("circuit_sim5.jsonl", lambda x: (x["L"], x["p"], x["r"], x["basis"]))
rows = []
for p, r, b in [(0.001, 0.0, "X"), (0.002, 0.0, "X"), (0.001, 0.1, "Z"), (0.001, 1.0, "Z"), (0.002, 0.1, "Z")]:
    t = [tor.get((L, p, r)) for L in (4, 6, 8)] if b == "Z" else [None] * 3
    rows.append(f"{100*p:.1f}\\% & $r={r:g}$, ${b}$ & {cell(v.get((4, p, r, b)))} & " + " & ".join(sci(u["block"]) if u else "--" for u in t) + "\\\\")
open("tab_idle.tex", "w").write("\n".join(rows) + "\n")
print("== flag"); [print(k, a["f"], a["s"], "%.2e" % a["block"]) for k, a in fl.items()]
print("== sim5"); [print(k, a["f"], a["s"], "%.2e" % a["block"]) for k, a in v.items()]
