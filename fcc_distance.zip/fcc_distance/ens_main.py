# Main memory runs with the two-setting ensemble: every shot is decoded with the single setting of the first
# runs (A: adaptive min-sum scaling) and with a second BP-OSD setting (B: min-sum scaling 0.9); the ensemble keeps
# the more probable correction (lower sum of log((1-p)/p)).  Appends 300 s chunks to ens_main.jsonl with, for
# A, B and the ensemble: failed shots, wrong values in total, and wrong values per failed shot.
# Usage: python3 ens_main.py WORKER DEADLINE_SECONDS     (tasks of this worker are read from ens_plan.json:
#        [L, p, budget in seconds, target number of ensemble failures, worker])
import sys, time, json, os, shutil, numpy as np
from fluorite_circuit import circuit, dem_matrices
from ldpc import BpOsdDecoder
W, DEAD = int(sys.argv[1]), float(sys.argv[2]); T0 = time.time(); FN = "ens_main.jsonl"
SET = [dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.0, schedule="serial", osd_method="osd_cs", osd_order=4),
       dict(max_iter=100, bp_method="ms", ms_scaling_factor=0.9, schedule="serial", osd_method="osd_cs", osd_order=4)]
def spent(L, p):
    s = f = 0
    if os.path.exists(FN):
        for l in open(FN):
            r = json.loads(l)
            if r["L"] == L and abs(r["p"] - p) < 1e-9: s += r["secs"]; f += r["fails"][2]
    return s, f
for L, p, budget, target, w in json.load(open("ens_plan.json")):
    if w != W: continue
    s0, f0 = spent(L, p)
    if s0 >= budget or f0 >= target or DEAD - (time.time() - T0) < 120: continue
    c, k = circuit(L, 2 * L, p); H, O, pri = dem_matrices(c); Od = O.toarray().astype(np.uint8); wt = np.log((1 - pri) / pri)
    decs = [BpOsdDecoder(H, channel_probs=list(pri), **s) for s in SET]
    while True:
        s0, f0 = spent(L, p); left = min(300, budget - s0, DEAD - (time.time() - T0) - 30)
        if left < 60 or f0 >= target: break
        seed = int(time.time() * 1000) % 2**31; smp = c.compile_detector_sampler(seed=seed); t0 = time.time(); shots = 0
        fails = [0, 0, 0]; mult = [[], [], []]; flips = np.zeros((3, k), int); chose_b = 0; conv = [0, 0]
        while time.time() - t0 < left:
            d, o = smp.sample(10, separate_observables=True)
            for i in range(10):
                syn = d[i].astype(np.uint8); xs = []
                for j, dc in enumerate(decs): xs.append(dc.decode(syn)); conv[j] += int(dc.converge)
                b = int(float(wt @ xs[1]) < float(wt @ xs[0]) - 1e-9); chose_b += b
                for j, x in enumerate((xs[0], xs[1], xs[b])):
                    r = ((Od @ x) % 2) ^ o[i]
                    if r.any(): fails[j] += 1; mult[j].append(int(r.sum())); flips[j] += r
            shots += 10
        open(FN, "a").write(json.dumps(dict(L=L, p=p, k=k, rounds=2 * L, shots=shots, seed=seed, fails=fails, mult=mult, flips=flips.tolist(), chose_b=chose_b, bp_converged=conv, secs=round(time.time() - t0, 1))) + "\n")
        try: shutil.copy(FN, "/mnt/user-data/outputs/fcc_distance/" + FN)
        except Exception: pass
        print(W, L, p, shots, fails, flush=True)
