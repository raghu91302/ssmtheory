"""Can single logical qubits of the checkerboard code be addressed?
T1: straight-line (string) logical operators and their rank among all logicals.
T2: largest set of mutually commuting anticommuting pairs (Z-line, X-line) = independently addressable qubits.
Usage: python3 access_test.py L"""
import numpy as np, sys, gf2
from fluorite import code, Group
L = int(sys.argv[1]); hnf = [[L, 0, 0], [0, L, 0], [0, 0, L]]; G = Group(hnf); N = G.N; n = 2 * N
HX, HZ = code(hnf, "w8"); k = n - 2 * gf2.rank(HX)
E = np.eye(3, dtype=int)
def line(h, ax):
    """Qubits on the cubic-axis line through void L(h): L(h) -> R(h - e_ax) -> L(h - e_ax + e_b + e_c) -> ..."""
    q = []; h = np.array(h)
    for _ in range(L):
        q.append(G.idx(tuple(h))); h = h - E[ax]; q.append(N + G.idx(tuple(h))); h = h + (1 - E[ax])
    return q
lines = {}
for h in G.elems():
    for ax in range(3):
        q = line(h, ax); lines[(ax, frozenset(q))] = q
keys = list(lines); V = np.zeros((len(keys), n), np.uint8)
for i, kk in enumerate(keys): V[i, lines[kk]] = 1
assert len(set(len(set(q)) for q in lines.values())) == 1 and not ((HX.astype(int) @ V.T) % 2).any(), "lines must commute with all checks"
rs = gf2.rank(HX); rl = gf2.rank(np.vstack([HX, V])) - rs
print(f"L={L}: n={n} k={k}; {len(keys)} lines of weight {2*L} ({len(keys)//3} per axis); rank of lines among logicals = {rl} of {k}")
# commutation between Z-type line i and X-type line j: overlap parity
C = (V.astype(int) @ V.T) % 2
print("each line anticommutes with", sorted(set(C.sum(1))), "other lines")
# T2: greedy + random restarts for mutually commuting anticommuting pairs (z_i, x_i)
rng = np.random.default_rng(0); best = []
for trial in range(300):
    pairs = []; zs = []; xs = []
    for i in rng.permutation(len(keys)):
        if any(C[i, x] for x in xs): continue                       # Z-line i must commute with chosen X-lines
        if zs and gf2.rank(np.vstack([HX, V[zs + [i]]])) - rs < len(zs) + 1: continue   # independent
        cand = [j for j in rng.permutation(len(keys)) if C[i, j] and not any(C[z, j] for z in zs)]
        if not cand: continue
        zs.append(int(i)); xs.append(int(cand[0])); pairs.append((int(i), int(cand[0])))
    if len(pairs) > len(best): best = pairs
    if len(best) == k: break
print(f"largest set of independent (Z-line, X-line) pairs found: {len(best)} of k = {k}")
M = C[np.ix_([a for a, b in best], [b for a, b in best])]
assert (M == np.eye(len(best), dtype=M.dtype)).all()
np.save(f"access_pairs_L{L}.npy", np.array([[lines[keys[a]], lines[keys[b]]] for a, b in best]))
