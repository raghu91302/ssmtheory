"""Exact search: all kernel vectors of H (weight <= w) containing an anchor qubit, by branch and bound.
Any vector in the kernel must flip an odd number of qubits of each unsatisfied check, so we branch on
the qubits of one unsatisfied check.  Each qubit sits in 4 checks, so #unsatisfied <= 4 * remaining."""
import numpy as np, sys, time, gf2
from fluorite import code
sys.setrecursionlimit(10000)
def search(H, w, anchors):
    m, n = H.shape
    colmask = [int(''.join('1' if H[i, j] else '0' for i in range(m - 1, -1, -1)), 2) for j in range(n)]
    rows = [np.nonzero(H[i])[0].tolist() for i in range(m)]
    found = []; nodes = 0
    def rec(syn, chosen, left, banned):
        nonlocal nodes; nodes += 1
        if syn == 0: found.append(sorted(chosen)); return
        if left == 0 or bin(syn).count('1') > 4 * left: return
        c = (syn & -syn).bit_length() - 1
        loc = set()
        for q in rows[c]:
            if q in chosen or q in banned or q in loc: continue
            rec(syn ^ colmask[q], chosen | {q}, left - 1, banned | loc)
            loc.add(q)                           # later branches exclude q: no duplicates
    for a in anchors: rec(colmask[a], frozenset([a]), w - 1, frozenset())
    return found, nodes
if __name__ == "__main__":
    L = int(sys.argv[1]); w = int(sys.argv[2])
    HX, HZ = code([[L, 0, 0], [0, L, 0], [0, 0, L]], "w8"); N = L ** 3
    t = time.time(); found, nodes = search(HZ, w, [0, N])
    R, piv = gf2.rref(HX); logical = 0
    for f in found:
        v = np.zeros(2 * N, np.uint8); v[f] = 1
        logical += not gf2.in_rowspan(R, piv, v)
    print(f"L={L}: kernel vectors of weight <= {w} through an anchor: {len(found)} (logical: {logical}, stabilizer: {len(found)-logical}); nodes {nodes}; {time.time()-t:.0f}s")
