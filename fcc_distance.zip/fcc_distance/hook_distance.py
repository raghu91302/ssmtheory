"""Effect of the CNOT order on the weight-8 check: 'hook' errors.
A single ancilla fault after the j-th CNOT leaves an error on the remaining qubits of the
check.  Fault distance = fewest faults (single-qubit errors or hooks) that make a logical.
Computed as the distance of an augmented code (spacelike faults only, no measurement errors)."""
import numpy as np, sys, itertools, gf2
from fluorite import code, Group, TYPES

def supports(hnf, order):
    """order: list of ('L'|'R', term) giving the CNOT sequence for the check at each site"""
    G = Group(hnf); N = G.N; sup = []
    for g in G.elems():
        sup.append([(0 if s == 'L' else N) + G.idx((g[0] + t[0], g[1] + t[1], g[2] + t[2])) for s, t in order])
    return sup

def fault_distance(hnf, order, trials=60, seed=0):
    HX, HZ = code(hnf, "w8"); n = HX.shape[1]
    hooks = []
    for q in supports(hnf, order):
        for j in range(2, 7):                    # suffixes of size 2..6 (size 7 = one qubit times the check)
            v = np.zeros(n, np.uint8); v[q[8 - j:]] = 1; hooks.append(v)
    M = np.hstack([np.eye(n, dtype=np.uint8), np.array(hooks).T])           # n x (n + h)
    Hk = (HZ.astype(int) @ M % 2).astype(np.uint8)
    kerM = np.hstack([np.array(hooks), np.eye(len(hooks), dtype=np.uint8)])  # hook + its single-qubit parts
    lift = np.hstack([HX, np.zeros((HX.shape[0], len(hooks)), np.uint8)])
    d, _ = gf2.min_weight_logical(Hk, np.vstack([kerM, lift]), trials=trials, rng=np.random.default_rng(seed))
    return d

X, Y, Z, O = (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 0, 0); neg = lambda t: tuple(-u for u in t)
ORDERS = {
    "tetra-first (4 L then 4 R)": [('L', O), ('L', X), ('L', Y), ('L', Z), ('R', O), ('R', neg(X)), ('R', neg(Y)), ('R', neg(Z))],
    "alternating L,R":            [('L', O), ('R', O), ('L', X), ('R', neg(X)), ('L', Y), ('R', neg(Y)), ('L', Z), ('R', neg(Z))],
    "L,R antipodal pairs":        [('L', O), ('R', neg(X)), ('L', X), ('R', O), ('L', Y), ('R', neg(Z)), ('L', Z), ('R', neg(Y))],
}
if __name__ == "__main__":
    for L in (3, 4):
        h = [[L, 0, 0], [0, L, 0], [0, 0, L]]
        for name, o in ORDERS.items():
            print(f"L={L}  code distance {5 if L == 3 else 8}  order '{name}': fault distance <= {fault_distance(h, o)}", flush=True)
