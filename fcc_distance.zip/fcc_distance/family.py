"""Weight-8 fluorite (checkerboard-type) code on the FCC-primitive L x L x L torus."""
import numpy as np, time, sys, gf2
from fluorite import code
from exact_distance import low_weight_kernel
for L in [int(v) for v in sys.argv[1:]]:
    t = time.time(); h = [[L, 0, 0], [0, L, 0], [0, 0, L]]
    HX, HZ = code(h, "w8"); N = L ** 3; n = 2 * N; k = n - 2 * gf2.rank(HX)
    tr = 200 if n <= 300 else (40 if n <= 500 else 12)
    d, v = gf2.min_weight_logical(HZ, HX, trials=tr, rng=np.random.default_rng(L))
    msg = f"L={L}: [[{n},{k},<={d}]]  (6L-4={6*L-4}, 2L={2*L})  k d^2/n={k*d*d/n:.1f}"
    if N <= 64 and d <= 9:
        f = low_weight_kernel(HZ, d - 1, [0, N]); msg += f"; exact: {'d = ' + str(d) if f == 0 else 'kernel vectors below d exist: ' + str(f)}"
    print(msg, f"({time.time()-t:.0f}s)", flush=True)
