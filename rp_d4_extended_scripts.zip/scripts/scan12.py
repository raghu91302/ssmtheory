"""Shells 1 + 2 (hops with dt in {0, 1/2, 1}), W(F4)-symmetric: parameters a = share of the kinetic normalization
carried by shell 1 (6 w1 = a, 12 w2 = 1 - a), rho1, rho2. Score = min over key momenta of lambda_min / lambda_max."""
import sys, itertools, numpy as np
from multishell import *
KEY = [np.zeros(3)] + [np.array(v) * t for t in (0.3, 1.0, 2.0) for v in ([1, 0, 0], [1, 1, 0], [1, 1, 1])] + \
      [np.array(v) for v in ([np.pi, 0, 0], [np.pi, np.pi, 0], [np.pi] * 3, [2 * np.pi, 0, 0], [2 * np.pi, np.pi, 0],
                             [2 * np.pi, 2 * np.pi, 0], [0.7, 2.1, 2.9])]
def H12(a, r1, r2):
    return hops([a / 6, (1 - a) / 12, 0, 0], [r1, r2, 0, 0])
if __name__ == "__main__":
    m = float(sys.argv[1]) if len(sys.argv) > 1 else 0.5
    best = []
    for a in np.linspace(0, 1, 11):
        for r1 in np.linspace(0.0, 2.0, 21):
            for r2 in np.linspace(0.0, 2.5, 21):
                try:
                    s, h = rp_score(m, H12(a, r1, r2), momenta=KEY, Nt=14, depth=7)
                except np.linalg.LinAlgError:
                    continue
                best.append((s, a, r1, r2))
    best.sort(reverse=True)
    print(f"m={m}: top 12 of {len(best)}")
    for b in best[:12]: print(f"  score {b[0]:+.3e}  a={b[1]:.2f} rho1={b[2]:.2f} rho2={b[3]:.3f}")
