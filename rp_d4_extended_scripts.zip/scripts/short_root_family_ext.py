"""Short root, Corollary 1 family outside [0,1]: a = 6 w1, 12 w2 = 1 - a, rho1 = 1/2, rho2 = 1 + w1/(12 w2).
Condition (iii) of Theorem 3 requires v2 = 2(w1 + 6 w2) = (3 - 2a)/3 >= 0, i.e. a <= 3/2. Also reports d."""
import numpy as np
from timedir import Direction
from multishell import hops
from dense_search_common import DENSE
D = Direction((0, 0, 0, 1))
print("a      d(m=0.5)   " + "  ".join(f"m={m:<9}" for m in (0.1, 0.5, 2.0)))
for a in [-3.0, -1.0, -0.5, -0.2, 1.05, 1.1, 1.2, 1.3, 1.4, 1.5]:
    w1, w2 = a / 6, (1 - a) / 12
    rho = [0.5, 1 + w1 / (12 * w2), 0, 0]
    H = hops([w1, w2, 0, 0], rho)
    d = 0.5 + sum(w * r for _, w, r in H)
    row = []
    for m in (0.1, 0.5, 2.0):
        r = [D.gram(p, m, H, Nt=12, depth=6) for p in DENSE]; lmax = max(v[1] for v in r)
        row.append(min(v[0] for v in r) / lmax)
    print(f"{a:<6} {d:+.3f}    " + "  ".join(f"{x:+.2e}  " for x in row), flush=True)
