"""For a given action and spatial momentum: is there ANY 4x4 reflection matrix X (Theta psi = psibar X) making the
Gram matrix of linear observables Hermitian and positive? Same convex search as kn_reflection.sdp (PRD scripts)."""
import numpy as np
from scipy.optimize import minimize
from multishell import *
def SAB(p, m, H, Nt=16, depth=7):
    S = np.linalg.inv(chain(p, m, H, Nt)); c = Nt
    A = np.concatenate([np.arange(4*(c+k), 4*(c+k)+4) for k in range(1, depth+1)])
    B = np.concatenate([np.arange(4*(c-k), 4*(c-k)+4) for k in range(1, depth+1)])
    return S[np.ix_(A, B)], depth
def best_lambda(SAB_, n):
    basis = []
    for k in range(32):
        E = np.zeros(16, complex); E[k % 16] = 1 if k < 16 else 1j; E = E.reshape(4, 4)
        basis.append((SAB_ @ np.kron(np.eye(n), E)).T)
    B = np.array(basis)
    A = (B - np.conj(np.transpose(B, (0, 2, 1)))).reshape(32, -1)
    Areal = np.concatenate([A.real, A.imag], 1).T
    u, sv, vt = np.linalg.svd(Areal, full_matrices=False); null = vt[np.sum(sv > 1e-9 * sv.max()):]
    if len(null) == 0: return None, 0
    Hs = [np.tensordot(v, B, 1) for v in null]; Hs = [(h + h.conj().T) / 2 for h in Hs]
    tr = np.array([np.trace(h).real for h in Hs]); d = Hs[0].shape[0]
    if np.allclose(tr, 0): return None, len(Hs)
    c0 = tr / np.dot(tr, tr) * d; P = np.eye(len(Hs)) - np.outer(tr, tr) / np.dot(tr, tr)
    Q = np.linalg.svd(P)[0][:, :len(Hs) - 1]
    f = lambda y: -np.linalg.eigvalsh(sum(ci * h for ci, h in zip(c0 + Q @ y, Hs)))[0]
    best = np.inf; rng = np.random.default_rng(0)
    for t in range(5):
        r = minimize(f, rng.normal(0, 3, len(Hs) - 1) if t else np.zeros(len(Hs) - 1), method="Powell",
                     options={"maxiter": 20000, "xtol": 1e-10, "ftol": 1e-12})
        best = min(best, r.fun)
    return -best, len(Hs)
if __name__ == "__main__":
    from scan12 import H12
    H = H12(0.796, 0.678, 1.193)
    res = sorted(((gram(p, 0.5, H)[0], tuple(np.round(p, 3))) for p in MOMENTA))
    print("worst momenta for X = gamma4:", res[:3])
    for v, p in res[:2]:
        lam, dim = best_lambda(*SAB(np.array(p), 0.5, H))
        print(f"p={p}: Hermitian family of X has dimension {dim}; best lambda_min (mean eigenvalue 1) over all such X: {lam}")
    ax = [(np.array(v, float), 0.5, 1.0) for v in np.vstack([np.eye(4), -np.eye(4)])]
    lam, dim = best_lambda(*SAB(np.array(res[0][1]), 0.5, ax))
    print(f"control, axis-only r=1 at the same p: dimension {dim}, best lambda_min {lam}")
