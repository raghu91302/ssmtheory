"""Projector-structured W(F4) family: rho3 = 3/2, rho4 = 2, rho1, rho2 fixed by the dt = 1/2 and dt = 1 conditions
(no gamma4 = +1 coupling forward in time at zero momentum). Free: w1, w2, w3, w4 with 6w1+12w2+72w3+24w4 = 1."""
import sys, numpy as np
from multishell import *
def family(w1, w2, w3, w4):
    rho3, rho4 = 1.5, 2.0
    rho1 = 0.5 - 3 * w3 / w1 if w1 else 0.0
    rho2 = 1 + (w1 / 2 - 3 * w3 - 8 * w4) / (6 * w2) if w2 else None
    return [w1, w2, w3, w4], [rho1, rho2 if rho2 is not None else 0, rho3, rho4]
def check_dt(w, rho):
    """sum of w(rho - dt) per dt over hops with dt>0 (should vanish)."""
    out = {}
    for v, ws, r in hops(w, rho):
        if v[3] > 0:
            out[v[3]] = out.get(v[3], 0) + ws * (r - v[3])
    return {k: round(x, 12) for k, x in sorted(out.items())}
if __name__ == "__main__":
    rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
    best = []
    for trial in range(60):
        x = rng.normal(0, 1, 4)
        x = x / normalization(x)
        if x[0] == 0 or x[1] == 0: continue
        w, rho = family(*x)
        H = hops(w, rho)
        sc, he = rp_score(0.5, H, momenta=MOMENTA[:40])
        best.append((sc, tuple(np.round(w, 4)), tuple(np.round(rho, 3))))
    best.sort(reverse=True)
    for b in best[:8]: print(b)
    w, rho = family(*[x for x in best[0][1]])
    print("dt sums:", check_dt(w, rho))
