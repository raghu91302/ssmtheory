"""Lemma 2: the matrices commuting with the spin lift of the stabilizer of a hop n (shells 1-4) are spanned by 1 and
gamma.n, so -w (rho - gamma.n) is the general W(F4)-covariant hop matrix (parity included)."""
import numpy as np
from multishell import g, SHELLS, SHELL_KEYS, weyl_group
g5 = g[0] @ g[1] @ g[2] @ g[3]; W = weyl_group()
basis = [np.eye(4)] + [g[m] for m in range(4)] + [g[a] @ g[b] for a in range(4) for b in range(a + 1, 4)] + [g[a] @ g5 for a in range(4)] + [g5]
def lift(R):
    det = np.linalg.det(R); A = []
    for mu in range(4):
        target = sum(R[nu, mu] * g[nu] for nu in range(4))   # S gamma_mu S^-1 = R gamma (leaves gamma.d invariant)
        A.append(np.array([(B @ g[mu] - target @ B).ravel() for B in basis]).T)
    vt = np.linalg.svd(np.vstack(A))[2]; c = vt[-1].conj()
    return sum(ci * B for ci, B in zip(c, basis))
E = [np.eye(4)[:, [i]] @ np.eye(4)[[j], :] for i in range(4) for j in range(4)]
for k in SHELL_KEYS:
    for n in (np.array(SHELLS[k][0]), np.array(SHELLS[k][-1])):
        stab = [M for M in W if np.allclose(M @ n, n)]
        A = np.vstack([np.array([(S @ e @ np.linalg.inv(S) - e).ravel() for e in E]).T for S in map(lift, stab)])
        null = np.linalg.svd(A)[2][np.sum(np.linalg.svd(A, compute_uv=False) > 1e-9):]
        X = [v.conj().reshape(4, 4) for v in null]
        gn = sum(n[m] * g[m] for m in range(4))
        span = np.linalg.matrix_rank(np.array([x.ravel() for x in X] + [np.eye(4).ravel(), gn.ravel()]), 1e-8)
        print(f"shell {k}, n={n}: stabilizer {len(stab)}, commutant dim {len(X)}, equals span(1, gamma.n): {span == len(X) == 2}")
