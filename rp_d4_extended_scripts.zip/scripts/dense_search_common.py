import numpy as np
rng = np.random.default_rng(5)
DENSE = [rng.uniform(-2 * np.pi, 2 * np.pi, 3) for _ in range(260)] + \
        [np.array(v) * t for t in (0.05, 0.15, 0.4, 1.0, 2.0) for v in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 1], [1, -1, 0], [0.3, 0.7, 0.2], [1, 0, 1], [0.5, 0.5, -1])]
