import sys, numpy as np
from scipy.optimize import minimize
from scan12 import *
m = float(sys.argv[1]) if len(sys.argv) > 1 else 0.5
def f(x):
    a, r1, r2 = x
    try: return -rp_score(m, H12(a, r1, r2), momenta=KEY, Nt=14, depth=7)[0]
    except np.linalg.LinAlgError: return 1.0
for x0 in [(0.8, 0.7, 1.125), (0.9, 0.7, 1.3), (0.8, 0.6, 1.125), (0.7, 0.7, 1.0)]:
    r = minimize(f, x0, method="Nelder-Mead", options={"maxiter": 400, "xatol": 1e-5, "fatol": 1e-10})
    a, r1, r2 = r.x
    full = rp_score(m, H12(a, r1, r2))
    print(f"start {x0}: a={a:.4f} rho1={r1:.4f} rho2={r2:.4f}  key score {-r.fun:+.3e}  full-grid score {full[0]:+.3e}", flush=True)
