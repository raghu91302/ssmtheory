"""Long root, nearest-neighbour W(F4) action with one Wilson parameter r. Theorem 3 excludes r != 1/sqrt2 (u1 != 0);
at r = 1/sqrt2 the zero-momentum conditions hold and this checks nonzero momentum on the 300-point set."""
import numpy as np
from timedir import Direction
from multishell import hops
from dense_search_common import DENSE
D = Direction((1, 1, 0, 0)); r = 2 ** -0.5
for m in (0.1, 0.5, 2.0):
    H = hops([1 / 6, 0, 0, 0], [r, 0, 0, 0])
    z = D.score(m, H, [np.zeros(3)], Nt=20, depth=10)[0]
    res = [D.gram(p, m, H, Nt=12, depth=6) for p in DENSE]; lmax = max(v[1] for v in res)
    print(f"m={m}: p=0 score {z:+.1e}; worst over 300 momenta {min(v[0] for v in res) / lmax:+.3e}", flush=True)
