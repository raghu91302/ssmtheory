"""Check of the zero-momentum lemma on general gamma4-diagonal chains.
At p = 0 a Wilson-type operator with time steps k (k = 1..R, in slice units) is
   (D psi)(t) = d psi(t) - sum_k w_k (rho_k - k gamma4) psi(t+k) - sum_k w_k (rho_k + k gamma4) psi(t-k).
On gamma4 = +1 the forward coefficients are u_k = w_k (rho_k - k), the backward ones v_k = w_k (rho_k + k).
Lemma: the reflection matrix (Theta psi = psibar gamma4, all linear observables at t > 0) is positive semidefinite iff
the gamma4 = +1 chain hops only backward (all u_k = 0; with Theta psi = -psibar gamma4 the roles of u and v swap), has range at most 2, and, at range 2, its
characteristic polynomial has one positive and one negative root. Random tests against brute-force inversion."""
import numpy as np
from multishell import g, I4
def gram(us, vs, d, Nt=40, depth=14):
    n = 2 * Nt + 1; D = np.zeros((4 * n, 4 * n))
    P = (I4 + g[3].real) / 2; Q = (I4 - g[3].real) / 2      # projectors on gamma4 = +1, -1
    for a in range(n):
        D[4*a:4*a+4, 4*a:4*a+4] = d * I4
        for k, (u, v) in enumerate(zip(us, vs), start=1):
            # gamma4=+1: forward u, backward v; gamma4=-1: forward v, backward u
            if a + k < n: D[4*a:4*a+4, 4*(a+k):4*(a+k)+4] -= u * P + v * Q
            if a - k >= 0: D[4*a:4*a+4, 4*(a-k):4*(a-k)+4] -= v * P + u * Q
    S = np.linalg.inv(D); c = Nt
    A = np.concatenate([np.arange(4*(c+k), 4*(c+k)+4) for k in range(1, depth+1)])
    B = np.concatenate([np.arange(4*(c-k), 4*(c-k)+4) for k in range(1, depth+1)])
    M = (S[np.ix_(A, B)] @ np.kron(np.eye(depth), g[3].real)).T
    ev = np.linalg.eigvalsh((M + M.T) / 2); return ev.min() / np.abs(ev).max()
def predicted(us, vs):
    us, vs = np.array(us), np.array(vs)
    if np.any(np.abs(us) > 1e-12): return False        # gamma4=+1 must not hop forward (sign fixed by Theta = gamma4)
    c = vs
    R = max(i + 1 for i in range(len(c)) if abs(c[i]) > 1e-12)
    if R >= 3: return False
    if R == 2:
        r = np.roots([-c[1], -c[0], 1.0])          # 1 - c1 y - c2 y^2
        return np.all(np.isreal(r)) and (r.real.min() < 0 < r.real.max())
    return True
rng = np.random.default_rng(0)
agree = 0; total = 0; seen = {}
for trial in range(400):
    R = rng.integers(1, 4)
    kind = rng.choice(["one-way", "two-way"])
    us = np.zeros(3); vs = np.zeros(3)
    vs[:R] = rng.normal(0, 0.15, R) * (rng.random(R) < 0.85)
    if kind == "two-way": us[:R] = rng.normal(0, 0.15, R) * (rng.random(R) < 0.85)
    if rng.random() < 0.5: us, vs = vs, us
    d = 1.0
    if np.abs(np.r_[us, vs]).sum() > 0.8 or np.abs(np.r_[us, vs]).sum() == 0: continue
    s = gram(us, vs, d)
    pos = s > -1e-10
    pr = predicted(us, vs)
    total += 1; agree += (pos == pr)
    key = (kind, int(R), pr); seen[key] = seen.get(key, 0) + 1
    if pos != pr: print("MISMATCH", us, vs, s)
print(f"agreement {agree}/{total}"); print("cases:", seen)
