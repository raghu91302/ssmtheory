"""Active-set search for a free-field reflection-positive W(F4)-symmetric action, time along the long root (1,1,0,0).
Each round: optimize the 8 shell parameters on the active momentum set, evaluate on a dense random set of 300 momenta,
add the 6 worst momenta to the active set. The final score is the minimum over the dense set (not used for fitting
before it enters the active set), so it cannot be inflated by overfitting.
Usage: python3 dense_search.py m shells"""
import sys, numpy as np
from scipy.optimize import minimize
from timedir import Direction, momenta
from multishell import hops, normalization
m = float(sys.argv[1]); shells = int(sys.argv[2])
D = Direction((1, 1, 0, 0))
rng = np.random.default_rng(5)
DENSE = [rng.uniform(-2 * np.pi, 2 * np.pi, 3) for _ in range(260)] + \
        [np.array(v) * t for t in (0.05, 0.15, 0.4, 1.0, 2.0) for v in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 1], [1, -1, 0], [0.3, 0.7, 0.2], [1, 0, 1], [0.5, 0.5, -1])]
def unpack(x):
    w = np.zeros(4); rho = np.zeros(4); w[:shells] = x[:shells]; rho[:shells] = x[shells:]
    n = normalization(w)
    return (None, None) if abs(n) < 1e-6 else (w / n, rho)
def per_p(x, P):
    w, rho = unpack(x)
    H = hops(w, rho)
    r = [D.gram(p, m, H, Nt=12, depth=6) for p in P]
    lmax = max(v[1] for v in r)
    return np.array([v[0] / lmax for v in r])
def f(x, P):
    w, rho = unpack(x)
    if w is None or np.abs(w).max() > 5: return 1e3
    try: return -per_p(x, P).min()
    except np.linalg.LinAlgError: return 1e3
starts = {2: [np.array([0.1405, 0.0131, 0.6622, 1.3583])],
          4: [np.array([0.1086, 0.0236, 0.0007, 0.0007, 0.5633, 1.3322, 1.3821, 1.7339]),
              np.array([0.0667, 0.0272, 0.0039, -0.0002, 0.3261, 1.2774, 1.4163, 0.29])]}[shells]
for x in starts:
    A = list(momenta(n=14))
    for rnd in range(6):
        r = minimize(f, x, args=(A,), method="Nelder-Mead", options={"maxiter": 1500, "xatol": 1e-7, "fatol": 1e-12})
        x = r.x
        dense = per_p(x, DENSE)
        worst = np.argsort(dense)[:6]
        print(f"m={m} shells={shells} round {rnd}: active-set score {-r.fun:+.3e}, dense score {dense.min():+.3e}", flush=True)
        A += [DENSE[i] for i in worst]
    w, rho = unpack(x)
    print(f"FINAL m={m} shells={shells}: dense score {dense.min():+.3e} at p={np.round(DENSE[int(np.argmin(dense))], 3)}; "
          f"w={np.round(w, 5)} rho={np.round(rho, 4)}", flush=True)
