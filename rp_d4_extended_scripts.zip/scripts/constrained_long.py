"""Long-root time direction: search only inside the family that is exactly positive at zero momentum (the lemma):
u1 = 6w1(r1-d) + 8w2(r2-d) + 24w3(r3-d) = 0,  u2 = w2(r2-2d) + 12w3(r3-2d) + 6w4(r4-2d) = 0,  w2 + 12w3 + 6w4 >= 0,
d = 1/sqrt2, normalization 6w1+12w2+72w3+24w4 = 1. Free: w2, w3, w4, r3, r4 (w1 from normalization, r2, r1 solved).
Active-set search as in dense_search.py. Usage: python3 constrained_long.py m"""
import sys, numpy as np
from scipy.optimize import minimize
from timedir import Direction, momenta
from multishell import hops
from dense_search_common import DENSE
m = float(sys.argv[1]); d = 2 ** -0.5
D = Direction((1, 1, 0, 0))
def params(x):
    w2, w3, w4, r3, r4 = x
    w1 = (1 - 12 * w2 - 72 * w3 - 24 * w4) / 6
    if abs(w2) < 1e-9 or abs(w1) < 1e-9 or w2 + 12 * w3 + 6 * w4 < 0: return None
    r2 = 2 * d - (12 * w3 * (r3 - 2 * d) + 6 * w4 * (r4 - 2 * d)) / w2
    r1 = d - (8 * w2 * (r2 - d) + 24 * w3 * (r3 - d)) / (6 * w1)
    return [w1, w2, w3, w4], [r1, r2, r3, r4]
def per_p(x, P):
    if params(x) is None: return -np.ones(len(P))
    w, rho = params(x); H = hops(w, rho)
    r = [D.gram(p, m, H, Nt=12, depth=6) for p in P]; lmax = max(v[1] for v in r)
    return np.array([v[0] / lmax for v in r])
def f(x, P):
    pr = params(x)
    if pr is None or np.abs(pr[0]).max() > 3 or np.abs(pr[1]).max() > 20: return 1e3
    try: return -per_p(x, P).min()
    except np.linalg.LinAlgError: return 1e3
rng = np.random.default_rng(2)
starts = [np.array([0.004, 0.0, 0.0, 1.5, 1.5]), np.array([0.008, 0.0005, 0.0005, 1.4, 1.4]),
          np.array([0.004, 0.001, -0.001, 1.0, 2.0])] + [np.r_[rng.uniform(0, .02, 1), rng.normal(0, .002, 2), rng.uniform(0, 3, 2)] for _ in range(3)]
for x in starts:
    if params(x) is None:
        continue
    A = list(momenta(n=14))
    for rnd in range(5):
        r = minimize(f, x, args=(A,), method="Nelder-Mead", options={"maxiter": 1200, "xatol": 1e-7, "fatol": 1e-12}); x = r.x
        dense = per_p(x, DENSE); A += [DENSE[i] for i in np.argsort(dense)[:6]]
    if params(x) is None:
        continue
    w, rho = params(x)
    print(f"m={m}: zero-momentum-exact family, dense score {dense.min():+.3e}  w={np.round(w,5)} rho={np.round(rho,4)}  "
          f"p=0 check {D.score(m, hops(w, rho), [np.zeros(3)], Nt=20, depth=10)[0]:+.1e}", flush=True)
