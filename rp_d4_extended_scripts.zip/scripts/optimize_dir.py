"""Optimize the W(F4)-symmetric four-shell action for free-field RP with time along tau (default: long root (1,1,0,0))."""
import sys, numpy as np
from scipy.optimize import minimize
from timedir import Direction, momenta
from multishell import hops, normalization
tau = tuple(map(float, sys.argv[1].split(","))) if len(sys.argv) > 1 else (1, 1, 0, 0)
m = float(sys.argv[2]) if len(sys.argv) > 2 else 0.5
shells = int(sys.argv[3]) if len(sys.argv) > 3 else 4
D = Direction(tau); P = momenta(n=14)
def unpack(x):
    w = np.zeros(4); rho = np.zeros(4)
    w[:shells] = x[:shells]; rho[:shells] = x[shells:]
    n = normalization(w)
    return (None, None) if abs(n) < 1e-6 else (w / n, rho)
def f(x):
    w, rho = unpack(x)
    if w is None or np.abs(w).max() > 5: return 1e3
    try: return -D.score(m, hops(w, rho), P, Nt=12, depth=6)[0]
    except np.linalg.LinAlgError: return 1e3
rng = np.random.default_rng(1)
s2 = 2 ** -0.5
starts = [np.r_[[1/6, 0, 0, 0][:shells], [s2, s2 * 2, 1, 2][:shells]],
          np.r_[[0.1, 0.03, 0, 0][:shells], [s2, 2 * s2, 2 * s2, 2 * s2][:shells]],
          np.r_[[1/6, 0, 0, 0][:shells], [1, 1, 1, 1][:shells]]] + \
         [np.r_[rng.normal(0, .05, shells), rng.uniform(0, 2, shells)] for _ in range(5)]
best = None
for x0 in starts:
    r = minimize(f, x0, method="Nelder-Mead", options={"maxiter": 2500, "xatol": 1e-6, "fatol": 1e-11})
    w, rho = unpack(r.x)
    print(f"score {-r.fun:+.3e}  w={np.round(w, 4)}  rho={np.round(rho, 4)}", flush=True)
    if best is None or r.fun < best.fun: best = r
w, rho = unpack(best.x)
full = D.score(m, hops(w, rho), momenta(seed=7, n=40), Nt=20, depth=10)
print(f"BEST tau={tau} m={m} shells<={shells}: score {-best.fun:+.3e}; on a fresh momentum set {full[0]:+.3e}")
