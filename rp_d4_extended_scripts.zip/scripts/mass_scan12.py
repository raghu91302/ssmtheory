"""Short root, shells 1+2, all three parameters free (a = 6 w1, rho1, rho2): best worst-case score at several masses.
Nelder-Mead on the key momenta of scan12.py from three starts, then evaluated on the 224-point grid MOMENTA of
multishell.py (6^3 shifted grid plus 8 special points). Reproduces the range 6e-5 .. 2.3e-4 quoted in Sec. 7."""
import numpy as np
from scipy.optimize import minimize
from scan12 import H12, KEY
from multishell import rp_score
for m in (0.1, 0.5, 1.0, 2.0, 4.0):
    f = lambda x: -rp_score(m, H12(*x), momenta=KEY, Nt=14, depth=7)[0]
    best = None
    for x0 in [(0.796, 0.678, 1.193), (0.6, 0.6, 1.0), (0.9, 0.8, 1.5)]:
        r = minimize(f, x0, method="Nelder-Mead", options={"maxiter": 300, "xatol": 1e-5, "fatol": 1e-10})
        if best is None or r.fun < best.fun: best = r
    a, r1, r2 = best.x
    print(f"m={m}: a={a:.4f} rho1={r1:.4f} rho2={r2:.4f}  key {-best.fun:+.3e}  grid {rp_score(m, H12(a, r1, r2))[0]:+.3e}", flush=True)
