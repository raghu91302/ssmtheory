"""Which reflection matrices X leave the action invariant? Theta psi(x) = psibar(theta x) X maps the hop term
psibar(x) M_n psi(x+n) to psibar(theta(x+n)) [X M_n^dagger X^-1] psi(theta x) (up to the fixed sign of the Grassmann
reordering), so invariance requires X M_n^dagger = M_{-theta n} X for every hop n. Linear in X; we compute its solution
space for each action (theta = reflection in tau = e4). Taste-type sign factors eps(x) must also satisfy
eps(x) eps(x+n) = 1 for every hop, i.e. be constant on a connected lattice."""
import numpy as np, itertools
from multishell import g, I4, hops, SHELLS
th = np.diag([1, 1, 1, -1.0])
def solutions(H):
    rows = []
    E = [np.eye(4)[:, [i]] @ np.eye(4)[[j], :] for i in range(4) for j in range(4)]
    Md = {}
    for v, w, rho in H:
        Md[tuple(v)] = -w * (rho * I4 - sum(v[mu] * g[mu] for mu in range(4)))
    for v, M in Md.items():
        Mt = Md[tuple(-(th @ np.array(v)))]
        rows.append(np.array([(e @ M.conj().T - Mt @ e).ravel() for e in E]).T)
    A = np.vstack(rows); sv = np.linalg.svd(A, compute_uv=False)
    vt = np.linalg.svd(A)[2]; null = vt[np.sum(sv > 1e-10):]
    return [n.conj().reshape(4, 4) for n in null]
axis = lambda w, rho: [(np.array(v, float), w, rho) for v in np.vstack([np.eye(4), -np.eye(4)])]
for name, H in [("hypercubic Wilson r=1", axis(0.5, 1.0)), ("hypercubic naive", axis(0.5, 0.0)),
                ("D4* Wilson, one r [W(F4)]", hops([1/6, 0, 0, 0], [1, 0, 0, 0])),
                ("D4* naive [W(F4)]", hops([1/6, 0, 0, 0], [0, 0, 0, 0])),
                ("D4* shells 1-4 generic [W(F4)]", hops([0.1, 0.02, 0.001, 0.002], [0.7, 1.2, 1.5, 2.0]))]:
    X = solutions(H)
    names = []
    for x in X:
        c = [abs(np.trace(x.conj().T @ M)) / 4 for M in (I4, g[3], g[0] @ g[1] @ g[2] @ g[3])]
        names.append(f"{np.round(c,3)} on (1, gamma4, gamma5)")
    print(f"{name:34s}: solution space dimension {len(X)}; " + "; ".join(names))
