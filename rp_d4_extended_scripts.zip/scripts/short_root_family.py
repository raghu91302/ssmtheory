"""Time along the short root e4: the lemma forces w3 = w4 = 0, rho1 = 1/2, rho2 = 1 + w1/(12 w2) (one parameter a:
6 w1 = a, 12 w2 = 1 - a; a = 0 is shell 2 alone with rho2 = 1). Dense-momentum score for each a and mass."""
import numpy as np
from timedir import Direction
from multishell import hops
from dense_search_common import DENSE
D = Direction((0, 0, 0, 1))
print("a      " + "  ".join(f"m={m:<9}" for m in (0.1, 0.5, 2.0)))
for a in [0.0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99]:
    w1, w2 = a / 6, (1 - a) / 12
    rho = [0.5, 1 + w1 / (12 * w2), 0, 0]
    row = []
    for m in (0.1, 0.5, 2.0):
        H = hops([w1, w2, 0, 0], rho)
        r = [D.gram(p, m, H, Nt=12, depth=6) for p in DENSE]; lmax = max(v[1] for v in r)
        row.append(min(v[0] for v in r) / lmax)
    print(f"{a:<6} " + "  ".join(f"{x:+.2e}  " for x in row), flush=True)
