"""Reflection positivity with the most general slice-independent or sublattice-dependent reflection matrix.
Theta psi(t) = psibar(-t) X_{c(t)}, with c(t) = parity of the slice index (integer vs half-integer slices for tau = e4).
For a given operator and momentum, find the X's for which the Gram matrix of all linear observables on slices 1..depth
is Hermitian, and maximize its smallest eigenvalue (trace normalized). Joint over several momenta: the same X for all.
"""
import sys, itertools, numpy as np
from scipy.optimize import minimize
from multishell import chain, hops, g, I4
def blocks(p, m, H, Nt=14, depth=6):
    S = np.linalg.inv(chain(p, m, H, Nt)); c = Nt
    A = [np.arange(4*(c+k), 4*(c+k)+4) for k in range(1, depth+1)]
    B = [np.arange(4*(c-k), 4*(c-k)+4) for k in range(1, depth+1)]
    return S, A, B
def basis_grams(p, m, H, sublattice, depth=6):
    S, A, B = blocks(p, m, H, depth=depth)
    out = []
    nX = 2 if sublattice else 1
    for which in range(nX):
        for k in range(32):
            E = np.zeros(16, complex); E[k % 16] = 1 if k < 16 else 1j; E = E.reshape(4, 4)
            M = np.zeros((4*depth, 4*depth), complex)
            for i, a in enumerate(A):
                for j, b in enumerate(B):
                    par = (j + 1) % 2          # slice parity of the mirrored slice -(j+1)
                    Xj = E if (not sublattice or par == which) else np.zeros((4, 4))
                    M[4*i:4*i+4, 4*j:4*j+4] = S[np.ix_(a, b)] @ Xj
            out.append(M.T)
    return out
def best(momenta, m, H, sublattice=False, depth=6, tries=6):
    Bs = [np.array(basis_grams(p, m, H, sublattice, depth)) for p in momenta]
    nb = Bs[0].shape[0]
    A = np.concatenate([(B - np.conj(np.transpose(B, (0, 2, 1)))).reshape(nb, -1) for B in Bs], 1)
    Ar = np.concatenate([A.real, A.imag], 1).T
    u, sv, vt = np.linalg.svd(Ar, full_matrices=True)
    null = vt[np.sum(sv > 1e-9 * sv.max()):]
    if len(null) == 0: return None, 0
    Hs = [[(h + h.conj().T) / 2 for h in (np.tensordot(v, B, 1) for v in null)] for B in Bs]
    def f(c):
        vals = []
        for Hp in Hs:
            Mx = sum(ci * h for ci, h in zip(c, Hp)); ev = np.linalg.eigvalsh(Mx)
            vals.append(ev[0] / (np.abs(ev).max() + 1e-300))
        return -min(vals)
    rng = np.random.default_rng(0); bestv = np.inf
    for t in range(tries):
        r = minimize(f, rng.normal(0, 1, len(null)), method="Powell", options={"maxiter": 30000, "xtol": 1e-10, "ftol": 1e-13})
        bestv = min(bestv, r.fun)
    return -bestv, len(null)
if __name__ == "__main__":
    P = [np.zeros(3), np.array([0.4, 0, 0]), np.array([0.7, 0.3, 1.1]), np.array([np.pi, 0.2, 0])]
    axis = lambda w, rho: [(np.array(v, float), w, rho) for v in np.vstack([np.eye(4), -np.eye(4)])]
    cases = {
        "hypercubic Wilson r=1 (control, positive)": axis(0.5, 1.0),
        "hypercubic naive r=0": axis(0.5, 0.0),
        "hypercubic Wilson r=1.5 (control, violates)": axis(0.5, 1.5),
        "D4* naive, all 24 links [W(F4)]": hops([1/6, 0, 0, 0], [0, 0, 0, 0]),
        "D4* Wilson r=1, all 24 links [W(F4)]": hops([1/6, 0, 0, 0], [1, 0, 0, 0]),
        "D4* Wilson r=1/2, all 24 links [W(F4)]": hops([1/6, 0, 0, 0], [0.5, 0, 0, 0]),
    }
    for name, H in cases.items():
        for sub in (False, True):
            v, dim = best(P, 0.5, H, sublattice=sub)
            print(f"{name:48s} {'sublattice X' if sub else 'common X   '}: Hermitian family dim {dim:2d}, best lambda_min/|lambda|max {v}", flush=True)
