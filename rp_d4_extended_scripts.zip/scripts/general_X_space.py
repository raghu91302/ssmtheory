"""Real-space test: reflection matrix X(x) allowed to depend on the slice type (integer / half-integer, tau = e4)
and on the spatial position mod 2 (staggered-type taste factors). Periodic spatial box of side L (in units of the
cubic cell), open time chain of half-step slices. Gram matrix of all linear observables on slices 1..depth against
their mirror images; find the X(x) making it Hermitian; maximize lambda_min/|lambda|max."""
import sys, itertools, numpy as np
from scipy.optimize import minimize
from multishell import g, I4, hops
L = int(sys.argv[1]) if len(sys.argv) > 1 else 2
Nt, depth = 7, 4
def build(H, m):
    sl = list(range(-Nt, Nt + 1))                      # slice index s -> t = s/2
    sites = []
    for s in sl:
        off = 0.5 if s % 2 else 0.0
        for x in itertools.product(range(L), repeat=3):
            sites.append((s, tuple(((np.array(x) + off) % L).round(3))))
    idx = {v: i for i, v in enumerate(sites)}
    N = len(sites); D = np.zeros((4 * N, 4 * N), complex)
    for (s, x), i in idx.items():
        D[4*i:4*i+4, 4*i:4*i+4] += m * I4 + sum(w * rho for _, w, rho in H) * I4
        for v, w, rho in H:
            s2 = s + int(round(2 * v[3]))
            if abs(s2) > Nt: continue
            x2 = tuple(((np.array(x) + v[:3]) % L).round(3))
            j = idx[(s2, x2)]
            D[4*i:4*i+4, 4*j:4*j+4] -= w * (rho * I4 - sum(v[mu] * g[mu] for mu in range(4)))
    return D, idx, sites
def classes(sites):
    """class of a site: (slice type, spatial position mod 2 rounded)"""
    cl = {}
    for (s, x) in sites:
        key = (s % 2, tuple(int(np.floor(c)) % 2 for c in x))
        cl.setdefault(key, len(cl))
    return cl
def test(H, m, tries=4):
    D, idx, sites = build(H, m)
    S = np.linalg.inv(D)
    cl = classes(sites)
    pos = [(s, x) for (s, x) in sites if 1 <= s <= depth]
    mir = [(-s, x) for (s, x) in pos]                     # spatial position unchanged by the reflection
    ia = np.concatenate([np.arange(4*idx[v], 4*idx[v]+4) for v in pos])
    ib = np.concatenate([np.arange(4*idx[v], 4*idx[v]+4) for v in mir])
    SAB = S[np.ix_(ia, ib)]
    keys = [(s % 2, tuple(int(np.floor(c)) % 2 for c in x)) for (s, x) in mir]
    nC = len(cl); basis = []
    for c in range(nC):
        for k in range(32):
            E = np.zeros(16, complex); E[k % 16] = 1 if k < 16 else 1j; E = E.reshape(4, 4)
            Xd = np.zeros((len(mir) * 4, len(mir) * 4), complex)
            for j, key in enumerate(keys):
                if cl[key] == c: Xd[4*j:4*j+4, 4*j:4*j+4] = E
            basis.append((SAB @ Xd).T)
    B = np.array(basis)
    A = (B - np.conj(np.transpose(B, (0, 2, 1)))).reshape(len(B), -1)
    Ar = np.concatenate([A.real, A.imag], 1)
    # null space of Ar^T (combinations with Hermitian Gram)
    u, sv, vt = np.linalg.svd(Ar, full_matrices=False)
    null = u[:, sv < 1e-9 * sv.max()].T
    if len(null) == 0: return None, 0
    Hs = [(h + h.conj().T) / 2 for h in (np.tensordot(v, B, 1) for v in null)]
    def f(c):
        ev = np.linalg.eigvalsh(sum(ci * h for ci, h in zip(c, Hs))); return -ev[0] / (np.abs(ev).max() + 1e-300)
    rng = np.random.default_rng(0); best = np.inf
    for t in range(tries):
        r = minimize(f, rng.normal(0, 1, len(Hs)), method="Powell", options={"maxiter": 40000, "xtol": 1e-10, "ftol": 1e-13})
        best = min(best, r.fun)
    return -best, len(Hs)
if __name__ == "__main__":
    axis = lambda w, rho: [(np.array(v, float), w, rho) for v in np.vstack([np.eye(4), -np.eye(4)])]
    for name, H in [("hypercubic naive (control: positive with taste factors)", axis(0.5, 0.0)),
                    ("hypercubic Wilson r=1.5 (control: violates)", axis(0.5, 1.5)),
                    ("D4* naive [W(F4)]", hops([1/6, 0, 0, 0], [0, 0, 0, 0])),
                    ("D4* Wilson r=1/2 [W(F4)]", hops([1/6, 0, 0, 0], [0.5, 0, 0, 0])),
                    ("D4* Wilson r=1 [W(F4)]", hops([1/6, 0, 0, 0], [1, 0, 0, 0]))]:
        v, dim = test(H, 0.5)
        print(f"L={L} {name:56s}: Hermitian family dim {dim:3d}, best lambda_min/|lambda|max {v}", flush=True)
