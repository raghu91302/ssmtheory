"""Free-field reflection positivity on D4* with time along an arbitrary lattice direction tau.

Slices are the level sets of x.tau_hat; they are spaced by delta (the smallest positive projection of a lattice
vector). At fixed momentum p perpendicular to tau the operator is a chain in the slice index; a hop n contributes
-w (rho - gamma.n) e^{i p.n_perp} between slices j and j + n.tau_hat/delta. Reflection through the slice t = 0,
Theta psi = psibar (gamma.tau_hat). Gram matrix of psibar on slices 1..depth against their mirror images.
Hops: the W(F4)-symmetric four-shell family of multishell.py.
"""
import itertools, sys
import numpy as np
from multishell import SHELLS, SHELL_KEYS, hops, normalization, g, I4

class Direction:
    def __init__(self, tau):
        tau = np.array(tau, float)
        self.tau = tau / np.linalg.norm(tau)
        # orthonormal frame for the perpendicular space
        M = np.linalg.svd(self.tau[None, :])[2]
        self.perp = M[1:]
        proj = sorted({round(abs(np.dot(v, self.tau)), 9) for k in SHELL_KEYS for v in map(np.array, SHELLS[k])} - {0.0})
        self.delta = proj[0]
        for x in proj:
            assert abs(x / self.delta - round(x / self.delta)) < 1e-7, (x, self.delta)
        self.gtau = sum(self.tau[mu] * g[mu] for mu in range(4))
    def steps(self, v):
        return int(round(np.dot(v, self.tau) / self.delta))
    def chain(self, p, m, H, Nt):
        n = 2 * Nt + 1
        blk = {}
        diag = m * I4
        for v, w, rho in H:
            d = self.steps(v)
            M = -w * (rho * I4 - sum(v[mu] * g[mu] for mu in range(4))) * np.exp(1j * np.dot(p, self.perp @ v))
            blk[d] = blk.get(d, 0) + M
            diag = diag + w * rho * I4
        blk[0] = blk.get(0, 0) + diag
        D = np.zeros((4 * n, 4 * n), complex)
        for a in range(n):
            for d, M in blk.items():
                b = a + d
                if 0 <= b < n:
                    D[4 * a:4 * a + 4, 4 * b:4 * b + 4] += M
        return D
    def gram(self, p, m, H, Nt=16, depth=8):
        S = np.linalg.inv(self.chain(p, m, H, Nt)); c = Nt
        A = np.concatenate([np.arange(4 * (c + k), 4 * (c + k) + 4) for k in range(1, depth + 1)])
        B = np.concatenate([np.arange(4 * (c - k), 4 * (c - k) + 4) for k in range(1, depth + 1)])
        Mg = (S[np.ix_(A, B)] @ np.kron(np.eye(depth), self.gtau)).T
        ev = np.linalg.eigvalsh((Mg + Mg.conj().T) / 2)
        return ev.min(), ev.max(), np.abs(Mg - Mg.conj().T).max()
    def score(self, m, H, momenta, **kw):
        r = [self.gram(p, m, H, **kw) for p in momenta]
        lmax = max(x[1] for x in r)
        return min(x[0] for x in r) / lmax, max(x[2] for x in r) / lmax

def momenta(seed=0, n=24):
    rng = np.random.default_rng(seed)
    pts = [np.zeros(3)] + [np.array(v) * t for t in (0.2, 0.7) for v in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 1])]
    pts += [rng.uniform(-2 * np.pi, 2 * np.pi, 3) for _ in range(n)]
    return pts

DIRECTIONS = {"shell1 (e4, as before)": (0, 0, 0, 1), "shell2 (1,1,0,0)": (1, 1, 0, 0), "shell3 (1,1,1,0)": (1, 1, 1, 0)}

if __name__ == "__main__":
    P = momenta()
    for name, tau in DIRECTIONS.items():
        D = Direction(tau)
        prof = {}
        for k in SHELL_KEYS:
            prof[k] = sorted({abs(D.steps(np.array(v))) for v in SHELLS[k]})
        print(f"{name}: slice spacing {D.delta:.4f}; |slice steps| per shell {prof}")
        # control: hypercubic-like sanity is not available off-axis; report the nearest-neighbour action
        sc = D.score(0.5, hops([1 / 6, 0, 0, 0], [1, 0, 0, 0]), P)
        print(f"   first shell, rho=1, m=0.5: score {sc[0]:+.3e} (herm {sc[1]:.0e})")
    # control in the e4 frame: axis-only r=1 must give 0
    D = Direction((0, 0, 0, 1))
    ax = [(np.array(v, float), 0.5, 1.0) for v in np.vstack([np.eye(4), -np.eye(4)])]
    print("control, axis-only r=1 with tau = e4:", D.score(0.5, ax, P))
