"""Reflection maps that are genuine involutions: Theta psi(x) = psibar(theta x) eps(x) X0, with X0 a fixed element of
the Clifford basis {Gamma_A, i Gamma_A} and eps(x) = +-1 depending on the slice type (integer / half-integer slices,
tau = e4) and on the spatial position mod 2 (staggered-type taste signs). For each X0 that makes the Gram matrix
Hermitian, every sign pattern is tried (2^classes), and the best lambda_min/|lambda|max is reported.
Usage: python3 sign_patterns.py L"""
import sys, itertools, numpy as np
from multishell import g, I4, hops
import general_X_space as G
L = int(sys.argv[1]) if len(sys.argv) > 1 else 2
G.L = L
g5 = g[0] @ g[1] @ g[2] @ g[3]
cliff = {"1": I4}
for k in range(1, 5):
    for c in itertools.combinations(range(4), k):
        M = I4.copy()
        for mu in c: M = M @ g[mu]
        cliff["g" + "".join(str(mu + 1) for mu in c)] = M
X0s = {**{k: v for k, v in cliff.items()}, **{"i" + k: 1j * v for k, v in cliff.items()}}
def run(H, m=0.5):
    D, idx, sites = G.build(H, m); S = np.linalg.inv(D)
    pos = [(s, x) for (s, x) in sites if 1 <= s <= G.depth]; mir = [(-s, x) for (s, x) in pos]
    ia = np.concatenate([np.arange(4*idx[v], 4*idx[v]+4) for v in pos])
    ib = np.concatenate([np.arange(4*idx[v], 4*idx[v]+4) for v in mir])
    SAB = S[np.ix_(ia, ib)]
    keys = [(s % 2, tuple(int(np.floor(c)) % 2 for c in x)) for (s, x) in mir]
    cl = sorted(set(keys)); ci = np.array([cl.index(k) for k in keys])
    best = (-np.inf, None, None)
    for name, X0 in X0s.items():
        # per-class Gram pieces: M = sum_c eps_c M_c, M_c Hermitian individually is not required, only the sum
        Ms = []
        for c in range(len(cl)):
            Xd = np.zeros((4*len(mir), 4*len(mir)), complex)
            for j in np.nonzero(ci == c)[0]: Xd[4*j:4*j+4, 4*j:4*j+4] = X0
            Ms.append((SAB @ Xd).T)
        Ms = np.array(Ms); scale = np.abs(Ms).max()
        for signs in itertools.product((1, -1), repeat=len(cl) - 1):
            e = np.array((1,) + signs)
            M = np.tensordot(e, Ms, 1)
            if np.abs(M - M.conj().T).max() > 1e-9 * scale: continue
            ev = np.linalg.eigvalsh((M + M.conj().T) / 2); v = ev[0] / np.abs(ev).max()
            if v > best[0]: best = (v, name, e)
            if v > -1e-12: break
    return best, len(cl)
if __name__ == "__main__":
    axis = lambda w, rho: [(np.array(v, float), w, rho) for v in np.vstack([np.eye(4), -np.eye(4)])]
    for name, H in [("hypercubic Wilson r=1 (control: positive)", axis(0.5, 1.0)),
                    ("hypercubic Wilson r=1.5 (control: violates)", axis(0.5, 1.5)),
                    ("hypercubic naive", axis(0.5, 0.0)),
                    ("D4* naive [W(F4)]", hops([1/6, 0, 0, 0], [0, 0, 0, 0])),
                    ("D4* Wilson r=1/2 [W(F4)]", hops([1/6, 0, 0, 0], [0.5, 0, 0, 0])),
                    ("D4* Wilson r=1 [W(F4)]", hops([1/6, 0, 0, 0], [1, 0, 0, 0]))]:
        (v, X0, e), n = run(H)
        print(f"L={L} {name:46s}: {n} sign classes; best lambda_min/|lambda|max {v:+.3e} with X0={X0}, signs={e}", flush=True)
