"""Figure 3: short-root one-parameter family, worst eigenvalue ratio over 300 momenta (from short_root_family.log)."""
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
rows = [l.split() for l in open("../short_root_family.log").read().splitlines()[1:] if l.strip()]
a = np.array([float(r[0]) for r in rows]); V = np.array([[float(x) for x in r[1:4]] for r in rows])
fig, ax = plt.subplots(figsize=(5.2, 3.4))
for j, (m, c, mk) in enumerate([(0.1, "#2a6fb0", "o"), (0.5, "#d0742a", "s"), (2.0, "#3b8a3b", "^")]):
    ax.semilogy(a, -V[:, j], marker=mk, color=c, lw=1.5, ms=4, label=f"$m={m}$")
ax.set_xlabel("$a=6w_1$ (share of the kinetic term on the first shell)")
ax.set_ylabel(r"$|\lambda_{\min}|/\lambda_{\max}$ (violation)")
ax.set_xlim(0, 1); ax.grid(alpha=0.3, which="both", lw=0.5); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig("fig3_short.pdf"); fig.savefig("fig3_short.png", dpi=150)
