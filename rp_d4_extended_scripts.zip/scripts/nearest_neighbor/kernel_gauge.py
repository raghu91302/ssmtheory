"""Real-space plane kernel in random U(1) gauge fields on and next to the plane (mirror rule U(theta l)=U(l),
crossing links = 1). Condition: X gamma4 Hermitian PSD."""
import numpy as np, itertools
import os; src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'kernel.py')).read(); exec(src[:src.rindex('if __name__')])
def kernel_U(L,m,ra,rh,wh,seed):
    rng=np.random.default_rng(seed);onsite,hops=setup(m,ra,rh,wh)
    P=2*L
    plane=[y for y in itertools.product(range(0,P,2),repeat=3)]                 # integer sites, doubled coords
    Asites=[x for x in itertools.product(range(1,P,2),repeat=3)]                 # half-integer spatial (t=+1/2)
    Bsites=plane                                                                  # (y, t=1)
    pi={y:i for i,y in enumerate(plane)};ai={x:i for i,x in enumerate(Asites)};nP,nA=len(plane),len(Asites)
    w=lambda X:tuple(np.mod(X,P))
    U={}
    def link(a,b,kind):   # phase for oriented link a->b (4-tuples in doubled coords); kind picks random/mirror
        k=(a,b)
        if k in U: return U[k]
        if kind=='cross': v=1.0
        else: v=np.exp(1j*rng.uniform(-np.pi,np.pi))
        U[k]=v;U[(b,a)]=np.conj(v);return v
    K=np.zeros((4*nP,4*nP),complex)
    for y in plane:
        i=pi[y];K[4*i:4*i+4,4*i:4*i+4]+=onsite*I4
        for d,Mm in hops:
            if d[3]!=0: continue
            z=w(np.array(y)+(2*d[:3]).astype(int));j=pi[z]
            K[4*i:4*i+4,4*j:4*j+4]+=Mm*link(y+(0,),z+(0,),'plane')
    Ki=np.linalg.inv(K)
    nT=nA+nP
    def idx(site,t): return ai[site] if t==1 else nA+pi[site]   # t in doubled units: 1 (A) or 2 (B)
    Hup=np.zeros((4*nP,4*nT),complex);Hdn=np.zeros((4*nP,4*nT),complex);Hb=np.zeros((4*nT,4*nP),complex)
    for y in plane:
        i=pi[y]
        for d,Mm in hops:
            if d[3]==0: continue
            dd=(2*d).astype(int);z=w(np.array(y)+dd[:3]);t=dd[3]
            if t>0:
                u=link(y+(0,),z+(t,),'pos');j=idx(z,t)
                Hup[4*i:4*i+4,4*j:4*j+4]+=Mm*u
                Mback=[Mx for e,Mx in hops if np.allclose(e,-d)][0]
                Hb[4*j:4*j+4,4*i:4*i+4]+=Mback*np.conj(u)
            else:
                u=link(y+(0,),z+(-t,),'pos')   # mirror rule: same phase as the positive link
                j=idx(z,-t);Hdn[4*i:4*i+4,4*j:4*j+4]+=Mm*u
    X=Hb@Ki@Hdn
    Mdown=[Mx for e,Mx in hops if np.allclose(e,[0,0,0,-1])][0]
    for x in Asites:
        j=ai[x];X[4*j:4*j+4,4*j:4*j+4]+=-Mdown
    Y=X@np.kron(np.eye(nT),g4)
    ev=np.linalg.eigvalsh((Y+Y.conj().T)/2)
    return ev.min()/np.abs(ev).max(),np.abs(Y-Y.conj().T).max()
print("random gauge fields on and next to the plane, L=3 plane (27 sites):")
for rh,wh in [(0.5,1.0),(0.5,0.3),(1.0,1.0),(0.6,1.0)]:
    r=[kernel_U(3,0.5,1.0,rh,wh,s) for s in range(5)]
    print(f"  r_half={rh}, w_half={wh}: worst {min(x[0] for x in r):+.2e}, hermiticity {max(x[1] for x in r):.0e}")
print("mass dependence (free kernel, r_half=1/2, w_half=1):")
for m in [2.0,0.5,0.0,-0.2,-0.5,-1.0,-1.5]:
    w_,h=check(m,1.0,0.5,1.0,N=10);print(f"  m={m:+.1f}: worst {w_:+.2e}")
