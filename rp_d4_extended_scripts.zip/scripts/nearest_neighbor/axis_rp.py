"""Reflection positivity of axis-only Wilson fermions (r=1) on D4*, in random U(1) backgrounds whose two
sides are mirror images (crossing links = 1), open reflection-symmetric time boundaries, both plane types.
Uses gauge_rp.py with time-mixed weight w_half = 0."""
import importlib.util, os
sp=importlib.util.spec_from_file_location('gr',os.path.join(os.path.dirname(os.path.abspath(__file__)),'gauge_rp.py'))
gr=importlib.util.module_from_spec(sp);sp.loader.exec_module(gr)
for L in [2,4]:
    for m in [-0.9,0.0]:
        for plane,lab in [(0,'integer plane'),(1,'half-integer plane')]:
            gr.report(f"D4* axis-only r=1, m={m}, {lab}, {L}^3 spatial",('D4s',L,8,plane,m,1.0,0.0,0.0,'same'),seeds=2)
