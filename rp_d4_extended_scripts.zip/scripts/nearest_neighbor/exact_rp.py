"""Exact reflection-positivity test of the INTERACTING measure on a tiny D4* lattice.
Spatial period 1 (one site per time slice), open reflection-symmetric time range.
Dynamical Z2 links: the 16 time-mixed links touching the plane site (8 up, 8 mirror-down); all other links = 1.
beta = 0 (gauge action off). Observables: all fermion bilinears psibar_a M psi_b on the positive side (even: no sign convention).
Gram_ij = sum_U det D(U) <Theta(F_i) F_j>_U, must be PSD."""
import numpy as np, itertools, sys
g=[np.array(m,complex) for m in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
I4=np.eye(4);g4=g[3];g5=g[0]@g[1]@g[2]@g[3]
cliff=[I4]+g+[g[a]@g[b] for a,b in itertools.combinations(range(4),2)]+[g[a]@g[b]@g[c] for a,b,c in itertools.combinations(range(4),3)]+[g5]
Tm=4; P=2
sites=[(0,0,0,t) if t%2==0 else (1,1,1,t) for t in range(-Tm,Tm+1)]
idx={s:i for i,s in enumerate(sites)};n=len(sites)
axis=[tuple(2*v) for v in np.eye(4,dtype=int)]+[tuple(-2*v) for v in np.eye(4,dtype=int)]
half=list(itertools.product([1,-1],repeat=4))
def wrap(x): return (x[0]%P,x[1]%P,x[2]%P,x[3])
def canon(x,r):
    neg=tuple(-a for a in r)
    if r>neg: return (x,r)
    return (wrap(tuple(a+b for a,b in zip(x,r))),neg)
def build(m,ra,rh,wh,Udyn):
    norm=2+4*wh;D=np.zeros((4*n,4*n),complex)
    for s in sites:
        i=idx[s];D[4*i:4*i+4,4*i:4*i+4]+=(m+(ra*8+rh*wh*16)/norm)*I4
        for r,w,rr in [(a,1.0,ra) for a in axis]+[(h,wh,rh) for h in half]:
            if w==0: continue
            x=tuple(a+b for a,b in zip(s,r))
            if x[3]<-Tm or x[3]>Tm: continue
            t=wrap(x);j=idx[t];rhat=np.array(r)/2
            key=canon(s,r);u=Udyn.get(key,1.0)
            if key!=(s,r): u=np.conj(u)
            D[4*i:4*i+4,4*j:4*j+4]+=-(w/norm)*u*(rr*I4-sum(rhat[mu]*g[mu] for mu in range(4)))
    return D
plane=(0,0,0,0)
dynkeys=[canon(plane,h) for h in half]   # 8 up (t=+1) and 8 down (t=-1)
up=[k for k,h in zip(dynkeys,half) if h[3]==1]; dn=[k for k,h in zip(dynkeys,half) if h[3]==-1]
mirror={}
for hu in [h for h in half if h[3]==1]:
    hd=(hu[0],hu[1],hu[2],-1); mirror[canon(plane,hu)]=canon(plane,hd)
pos=[s for s in sites if s[3] in (1,2)]
refl=lambda s:(s[0],s[1],s[2],-s[3])
obs=[(a,b,M) for a in pos for b in pos for M in cliff]
def gram(m,ra,rh,wh,group='Z2'):
    G=np.zeros((len(obs),len(obs)),complex)
    vals=[1.0,-1.0]
    keys=up+dn
    for bits in itertools.product(vals,repeat=len(keys) if wh>0 else 0):
        Ud=dict(zip(keys,bits))
        D=build(m,ra,rh,wh,Ud);detD=np.linalg.det(D);S=np.linalg.inv(D)
        Sb=lambda a,b: S[4*idx[a]:4*idx[a]+4,4*idx[b]:4*idx[b]+4]
        # precompute blocks
        cache={}
        def B(a,b):
            if (a,b) not in cache: cache[(a,b)]=Sb(a,b)
            return cache[(a,b)]
        for i,(a,b,M) in enumerate(obs):
            C=g4.T@np.conj(M)@g4.T      # Theta(F_i) = psi_{ta} C psibar_{tb}
            ta,tb=refl(a),refl(b)
            for j,(c,d,Mp) in enumerate(obs):
                # <psi_1 C psibar_2  psibar_3 M' psi_4> = -[ S12 S43 - S13 S42 ] contracted
                t1=np.trace(C@B(tb,ta).T) if False else None
                # sum_{mu nu rho sig} C_{mu nu} M'_{rho sig} * -( S(ta mu,tb nu) S(d sig,c rho) - S(ta mu,c rho) S(d sig,tb nu) )
                X1=np.sum(C*B(ta,tb))*np.sum(Mp*B(d,c).T)
                X2=np.einsum('mn,rs,mr,sn->',C,Mp,B(ta,c),B(d,tb))
                G[i,j]+=detD*(-(X1-X2))
    H=(G+G.conj().T)/2;herm=np.abs(G-G.conj().T).max()/np.abs(G).max()
    ev=np.linalg.eigvalsh(H);sc=np.abs(ev).max()
    return ev.min()/sc,int(np.sum(ev<-1e-9*sc)),herm
if __name__=="__main__":
    for label,args in [("control: axis hops only (w_half=0)",(0.5,1.0,0.5,0.0)),
                       ("control: r_half=1, w_half=1 (fails already in fixed backgrounds)",(0.5,1.0,1.0,1.0)),
                       ("test: r_half=1/2, w_half=1/6",(0.5,1.0,0.5,1/6)),
                       ("test: r_half=1/2, w_half=1",(0.5,1.0,0.5,1.0))]:
        mn,nn,h=gram(*args);print(f"{label}: min/max eig {mn:+.2e}, #negative {nn}, hermiticity dev {h:.0e}",flush=True)
