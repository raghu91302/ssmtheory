import numpy as np, itertools
import os; src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'kernel.py')).read(); exec(src[:src.rindex('if __name__')])
def planeK(L,m,seed):
    rng=np.random.default_rng(seed);on,hp=setup(m,1.0,0.5,1.0);P=2*L
    pl=list(itertools.product(range(0,P,2),repeat=3));pi={y:i for i,y in enumerate(pl)};n=len(pl)
    K=np.zeros((4*n,4*n),complex);U={}
    for y in pl:
        i=pi[y];K[4*i:4*i+4,4*i:4*i+4]+=on*I4
        for d,Mm in hp:
            if d[3]!=0: continue
            z=tuple(np.mod(np.array(y)+(2*d[:3]).astype(int),P))
            if (y,z) not in U: v=np.exp(1j*rng.uniform(-np.pi,np.pi));U[(y,z)]=v;U[(z,y)]=np.conj(v)
            K[4*i:4*i+4,4*pi[z]:4*pi[z]+4]+=Mm*U[(y,z)]
    return K
print("plane determinant det K in random gauge fields (should be real and >= 0):")
for m in [0.5,-1.0]:
    for s in range(3):
        K=planeK(3,m,s);sign,logd=np.linalg.slogdet(K)
        print(f"  m={m}, seed {s}: phase of det = {np.angle(sign):+.1e}, log|det| = {logd:.2f}, gamma4 K gamma4 = K^dagger: {np.allclose(np.kron(np.eye(27),g4)@K@np.kron(np.eye(27),g4),K.conj().T)}")
print("mass threshold of the kernel condition (free):")
for m in [-0.9,-1.0,-1.05,-1.1,-1.2]:
    print(f"  m={m}: worst {check(m,1.0,0.5,1.0,N=12)[0]:+.2e}")
