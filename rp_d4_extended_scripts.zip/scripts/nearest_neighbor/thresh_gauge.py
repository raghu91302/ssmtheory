import numpy as np, itertools
from scipy.optimize import minimize
import os; src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'worst.py')).read(); exec(src[:src.index("rng=np.random.default_rng(0)")])
rng=np.random.default_rng(1)
def worst(m,L=2,trials=6):
    N=nphase(L);best=-1
    for t in range(trials):
        r=minimize(lambda x:-ratio(x,L,m),rng.uniform(-np.pi,np.pi,N),method='L-BFGS-B',options={'maxiter':400})
        best=max(best,-r.fun)
    return best
for m in [1.2,1.4,1.6,1.8]:
    print(f"m={m}: worst ratio {worst(m):.4f}")
# max ||G||^2 over gauge fields (plane <- A coupling), L=2
def Gnorm(phis,L=2):
    P=2*L;pl=list(itertools.product(range(0,P,2),repeat=3));A=list(itertools.product(range(1,P,2),repeat=3))
    pi={y:i for i,y in enumerate(pl)};ai={x:i for i,x in enumerate(A)};it=iter(phis)
    G=np.zeros((4*len(pl),4*len(A)),complex)
    for y in pl:
        for s in itertools.product([1,-1],repeat=3):
            x=tuple(np.mod(np.array(y)+np.array(s),P))
            G[4*pi[y]:4*pi[y]+4,4*ai[x]:4*ai[x]+4]+=sum(0.5*s[k]*g[k] for k in range(3))*np.exp(1j*next(it))
    PmB=np.kron(np.eye(len(pl)),(I4-g4)/2);PpA=np.kron(np.eye(len(A)),(I4+g4)/2)
    M=PmB@G@PpA; return np.linalg.norm(M,2)**2
best=0
for t in range(8):
    r=minimize(lambda x:-Gnorm(x),rng.uniform(-np.pi,np.pi,64),method='L-BFGS-B');best=max(best,-r.fun)
print(f"max over gauge fields of ||P- G P+||^2 = {best:.4f}  (free-field max 16; crude bound 48)")
