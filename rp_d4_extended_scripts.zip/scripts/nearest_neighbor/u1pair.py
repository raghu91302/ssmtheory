import numpy as np, itertools
src=open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'ctrl.py')).read(); exec(src[:src.index('print(')])
def gram_zn(m,ra,rh,wh,keys,N):
    G=np.zeros((len(obs),len(obs)),complex)
    vals=[np.exp(2j*np.pi*k/N) for k in range(N)]
    for bits in itertools.product(vals,repeat=len(keys)):
        D=build(m,ra,rh,wh,dict(zip(keys,bits)));det=np.linalg.det(D);S=np.linalg.inv(D)[np.ix_(sel,sel)]
        a=np.einsum('ipq,pq->i',Chat,S);b=np.einsum('juv,vu->j',Mhat,S)
        T=np.einsum('pu,juv,vq->jpq',S,Mhat,S);X2=np.einsum('ipq,jpq->ij',Chat,T)
        G+=det*(-(np.outer(a,b)-X2))
    G/=N**len(keys);H=(G+G.conj().T)/2;ev=np.linalg.eigvalsh(H);sc=np.abs(ev).max()
    return G,float(ev.min()/sc),int(np.sum(ev<-1e-9*sc))
hu=(1,1,1,1);hd=(1,1,1,-1)
pair=[canon(plane,hu),canon(plane,hd)]
for wh in [1/6,1.0]:
    G16,mn16,n16=gram_zn(0.5,1.0,0.5,wh,pair,16)
    G24,mn24,n24=gram_zn(0.5,1.0,0.5,wh,pair,24)
    print(f"w_half={wh:.3f}, one time-mixed link + mirror, U(1) Haar (Z16 vs Z24 agree to {np.abs(G16-G24).max()/np.abs(G16).max():.0e}): min/max eig {mn16:+.2e}, #negative {n16}")
Gz,mnz,nz=gram_zn(0.5,1.0,0.5,0.0,[canon(plane,(0,0,0,2)),canon(plane,(0,0,0,-2))],16)
print(f"control w_half=0, temporal link pair U(1): min/max eig {mnz:+.2e}, #negative {nz}")
