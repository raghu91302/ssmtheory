import numpy as np, itertools
from scipy.optimize import minimize, brentq
import os; src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'worst.py')).read(); exec(src[:src.index("rng=np.random.default_rng(0)")])
rng=np.random.default_rng(2);wh=1/6
bound=lambda m,w,Gm=48: (w/(2+4*w))**2*Gm/(2*(1/(2+4*w))*(m+(2+8*w)/(2+4*w)))
for m in [-1.0,-0.5,0.0]:
    N=nphase(2);best=max(-minimize(lambda x:-ratio(x,2,m,wh),rng.uniform(-np.pi,np.pi,N),method='L-BFGS-B',options={'maxiter':400}).fun for t in range(5))
    print(f"w_half=1/6, m={m:+.1f}: worst ratio over gauge fields {best:.4f}; rigorous bound {bound(m,wh):.4f}  (<= 1 means positivity holds)")
# doublers and light cone at w_half = 1/6
R=np.array([v for v in np.vstack([np.eye(4),-np.eye(4)])]+[np.array(s)/2 for s in itertools.product([1,-1],repeat=4)])
Rp=np.array([r for r in R if tuple(r)>tuple(-r)]);ax=np.array([np.isclose(np.abs(r).max(),1) for r in Rp])
n=2+4*wh;wv=np.where(ax,1.0,wh)/n*2   # kinetic weight per positive root, normalised so v ~ k
v=lambda k:(np.sin(Rp@k)*wv)@Rp
Wt=lambda k: np.sum(np.where(ax,1.0,0.5)*wv*(1-np.cos(Rp@k)))
print("small-k normalisation of v:",np.round([v(np.eye(4)[i]*1e-4)[i]/1e-4 for i in range(4)],6))
N=20;js=2*np.pi*np.arange(N)/N;j4=4*np.pi*np.arange(2*N)/(2*N)
Q=np.stack(np.meshgrid(js,js,js,j4,indexing='ij'),-1).reshape(-1,4);nv=np.linalg.norm(np.sin(Q@Rp.T)*wv@Rp,axis=1)
same=lambda a,b:(lambda d:np.allclose(d,np.round(d),atol=1e-5) and int(np.round(d).sum())%2==0)((a-b)/(2*np.pi))
zs=[]
for c in Q[nv<0.3]:
    r=minimize(lambda k:np.sum(v(k)**2),c,method='Nelder-Mead',options={'xatol':1e-11,'fatol':1e-22,'maxiter':5000})
    if r.fun<1e-14 and not any(same(r.x,y) for y in zs): zs.append(r.x)
ws=sorted(Wt(z) for z in zs)
print(f"w_half=1/6: {len(zs)} naive zeros; Wilson masses: physical {ws[0]:.3f}, lightest doubler {ws[1]:.3f}")
def E_f(p,m):
    def f(E):
        k=np.array([*p,1j*E]);vv=v(k);return np.real((m+Wt(k))**2+np.sum(vv*vv))
    Es=np.linspace(1e-5,3,3000);vals=[f(E) for E in Es]
    for a,b,fa,fb in zip(Es,Es[1:],vals,vals[1:]):
        if fa*fb<0: return brentq(f,a,b,xtol=1e-14)
dirs=[np.array([1,0,0.]),np.array([1,1,0])/2**.5,np.ones(3)/3**.5]
vs=[E_f(0.004*d,0.0)/0.004 for d in dirs]
print("w_half=1/6 massless fermion speed by direction:",np.round(vs,7))
