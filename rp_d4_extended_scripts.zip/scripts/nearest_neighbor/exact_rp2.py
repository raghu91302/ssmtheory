import numpy as np, itertools, time
src=open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'exact_rp.py')).read(); exec(src[:src.rindex('def gram')])
four=pos+[refl(s) for s in pos]; fi={s:k for k,s in enumerate(four)}
def emb(a,b,Mx):
    E=np.zeros((16,16),complex);E[4*fi[a]:4*fi[a]+4,4*fi[b]:4*fi[b]+4]=Mx;return E
Chat=np.array([emb(refl(a),refl(b),-(g4.T@np.conj(M)@g4.T)) for a,b,M in obs])   # Theta(F_i) = psi_{ta} Chat psibar_{tb}, sign fixed
Mhat=np.array([emb(c,d,M) for c,d,M in obs])                                     # F_j = psibar_c Mhat psi_d
sel=np.concatenate([np.arange(4*idx[s],4*idx[s]+4) for s in four])
def gram(m,ra,rh,wh):
    keys=up+dn; G=np.zeros((len(obs),len(obs)),complex)
    for bits in itertools.product([1.0,-1.0],repeat=len(keys) if wh>0 else 0):
        D=build(m,ra,rh,wh,dict(zip(keys,bits)));det=np.linalg.det(D);S=np.linalg.inv(D)[np.ix_(sel,sel)]
        a=np.einsum('ipq,pq->i',Chat,S); b=np.einsum('juv,vu->j',Mhat,S)       # <psi Chat psibar> , <psibar Mhat psi> pieces
        T=np.einsum('pu,juv,vq->jpq',S,Mhat,S)
        X2=np.einsum('ipq,jpq->ij',Chat,T)
        G+=det*(-(np.outer(a,b)-X2))
    H=(G+G.conj().T)/2;herm=np.abs(G-G.conj().T).max()/np.abs(G).max();ev=np.linalg.eigvalsh(H);sc=np.abs(ev).max()
    return ev.min()/sc,int(np.sum(ev<-1e-9*sc)),herm
for label,args in [("control: axis hops only (w_half=0)",(0.5,1.0,0.5,0.0)),
                   ("control: r_half=1, w_half=1",(0.5,1.0,1.0,1.0)),
                   ("test: r_half=1/2, w_half=1/6",(0.5,1.0,0.5,1/6)),
                   ("test: r_half=1/2, w_half=1",(0.5,1.0,0.5,1.0))]:
    t0=time.time();mn,nn,h=gram(*args)
    print(f"{label}: min/max eig {mn:+.2e}, #negative {nn}, hermiticity {h:.0e}  ({time.time()-t0:.0f}s)",flush=True)
