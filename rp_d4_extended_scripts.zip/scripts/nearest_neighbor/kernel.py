"""Fermion RP on D4*: integrate out the plane t=0, reduce to the cross kernel.
-S_cross = sum psibar_z X_{z,z'} psi_{theta z'};  sufficient condition for RP: X(p) gamma4 is Hermitian PSD
(with theta psi = -psibar(theta x) gamma4). Positive-side sites adjacent to the plane: A=(x,1/2), B=(y,1)."""
import numpy as np, itertools
g=[np.array(m,complex) for m in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
I4=np.eye(4);g4=g[3]
axis=[s*np.eye(4)[i] for i in range(4) for s in (1,-1)]
half=[np.array(s)/2 for s in itertools.product([1,-1],repeat=4)]
def setup(m,ra,rh,wh,wa=1.0):
    norm=2*wa+4*wh
    M=lambda d,w,r: -(w/norm)*(r*I4-sum(d[mu]*g[mu] for mu in range(4)))
    onsite=m+(ra*wa*8+rh*wh*16)/norm
    hops=[(d,M(d,wa,ra)) for d in axis]+[(d,M(d,wh,rh)) for d in half]
    return onsite,hops
def kernel(p,m,ra,rh,wh):
    onsite,hops=setup(m,ra,rh,wh)
    ph=lambda d: np.exp(1j*p@d[:3])
    K=onsite*I4+sum(Mm*ph(d) for d,Mm in hops if d[3]==0)
    Ki=np.linalg.inv(K)
    typ=lambda d: 'A' if abs(d[3])==0.5 else ('B' if abs(d[3])==1 else None)
    H={('A',1):0,('B',1):0,('A',-1):0,('B',-1):0}; Hb={'A':0,'B':0}
    for d,Mm in hops:
        t=typ(d)
        if t is None: continue
        sgn=int(np.sign(d[3]))
        H[(t,sgn)]=H[(t,sgn)]+Mm*ph(d)               # plane y -> y+d   (psibar_y M psi_{y+d})
        if sgn>0:
            dm=-d; Mback=[Mx for dd,Mx in hops if np.allclose(dd,dm)][0]
            Hb[t]=Hb[t]+Mback*np.conj(ph(d))          # site y+d -> plane y (psibar_{y+d} M psi_y)
    X=np.zeros((8,8),complex)
    for a,ta in enumerate('AB'):
        for b,tb in enumerate('AB'):
            X[4*a:4*a+4,4*b:4*b+4]=Hb[ta]@Ki@H[(tb,-1)]
    # direct crossing e_t link between (x,1/2) and (x,-1/2): psibar_{x+} M(-e_t) psi_{x-}; -S contains -M
    Mdown=[Mx for dd,Mx in hops if np.allclose(dd,[0,0,0,-1])][0]
    X[0:4,0:4]+=-Mdown
    return X
def check(m,ra,rh,wh,N=12):
    worst=np.inf;herm=0
    for p in itertools.product(2*np.pi*np.arange(N)/N,repeat=3):
        Y=kernel(np.array(p),m,ra,rh,wh)@np.kron(np.eye(2),g4)
        herm=max(herm,np.abs(Y-Y.conj().T).max())
        ev=np.linalg.eigvalsh((Y+Y.conj().T)/2);worst=min(worst,ev.min()/max(1e-15,np.abs(ev).max()))
    return worst,herm
if __name__=="__main__":
    print("min over spatial momenta of (smallest eig / largest |eig|) of X(p) gamma4; >= 0 means the kernel condition holds")
    for rh in [0.4,0.5,0.6,1.0]:
        for wh in [0.3,1.0,3.0]:
            w,h=check(0.5,1.0,rh,wh);print(f"  r_half={rh}, w_half={wh}: {w:+.3e}   (hermiticity dev {h:.0e})")
