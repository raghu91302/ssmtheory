"""Fermion reflection positivity with OPEN, reflection-symmetric time boundaries (no antiperiodic seam).
Time range X_t in [-Tm, Tm] (doubled units), reflection X_t -> 2*plane - X_t about the centre."""
import numpy as np, itertools
g=[np.array(m,complex) for m in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
I4=np.eye(4)
def build(kind,L,Tm,plane,m,ra,rh,wh):
    Ps=2*L
    if kind=='Z4':
        Ra=list(2*np.eye(4,dtype=int))+list(-2*np.eye(4,dtype=int));Rh=[];wh=0
        par=lambda X: all(x%2==0 for x in X)
    else:
        Ra=list(2*np.eye(4,dtype=int))+list(-2*np.eye(4,dtype=int));Rh=list(itertools.product([1,-1],repeat=4))
        par=lambda X: len(set(np.array(X)%2))==1
    lo,hi=plane-Tm,plane+Tm
    sites=[X for X in itertools.product(range(Ps),range(Ps),range(Ps),range(lo,hi+1)) if par(X)]
    idx={s:i for i,s in enumerate(sites)};n=len(sites);D=np.zeros((4*n,4*n),complex)
    wa=1.0;norm=2*wa+4*wh
    for s in sites:
        i=idx[s];D[4*i:4*i+4,4*i:4*i+4]+=(m+(ra*wa*8+rh*wh*16)/norm)*I4
        for rr,w,r in [(x,wa,ra) for x in Ra]+[(x,wh,rh) for x in Rh]:
            if w==0: continue
            raw=np.array(s)+np.array(rr)
            if raw[3]<lo or raw[3]>hi: continue   # open boundary
            t=(raw[0]%Ps,raw[1]%Ps,raw[2]%Ps,raw[3]);j=idx[t];rhat=np.array(rr)/2.0
            D[4*i:4*i+4,4*j:4*j+4]+=-(w/norm)*(r*I4-sum(rhat[mu]*g[mu] for mu in range(4)))
    return sites,idx,D
def gram(kind,L,Tm,plane,m,ra,rh=1.0,wh=0.0,depth=None):
    sites,idx,D=build(kind,L,Tm,plane,m,ra,rh,wh);S=np.linalg.inv(D)
    depth=depth or Tm//2
    pos=[s for s in sites if plane<s[3]<=plane+depth]
    refl=lambda s:(s[0],s[1],s[2],2*plane-s[3])
    ix=lambda a: np.concatenate([4*np.array(a)[:,None]+k for k in range(4)],1).ravel()
    A=[idx[s] for s in pos];B=[idx[refl(s)] for s in pos]
    M=(S[np.ix_(ix(A),ix(B))]@np.kron(np.eye(len(pos)),g[3])).T
    herm=np.abs(M-M.conj().T).max()/np.abs(M).max()
    ev=np.linalg.eigvalsh((M+M.conj().T)/2);sc=np.abs(ev).max()
    npos,nneg=int(np.sum(ev>1e-8*sc)),int(np.sum(ev<-1e-8*sc))
    worst=min(ev.max(),-ev.min())/sc
    return npos,nneg,herm,worst
def say(tag,r):
    npos,nneg,h,w=r
    v="RP holds" if min(npos,nneg)==0 else f"VIOLATED (minority eigenvalues up to {w:.1e} of scale)"
    print(f"{tag}: +{npos} / -{nneg}, hermiticity dev {h:.0e} -> {v}")
if __name__=="__main__":
    print("== calibration, hypercubic Wilson, m=0.5")
    for r in [1.0,1.5]:
        say(f"  Z4 link plane, r={r}",gram('Z4',3,12,1,0.5,r))
        say(f"  Z4 site plane, r={r}",gram('Z4',3,12,0,0.5,r))
