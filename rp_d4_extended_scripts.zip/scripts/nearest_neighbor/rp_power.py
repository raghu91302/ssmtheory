import numpy as np, itertools
import rp
# monkeypatch: Z4 with plaquettes + 1x2 rectangles with weight c1 (Wilson gauge action extension)
def build_rect(L,T):
    g=rp.build('Z4',L,T); P=g['P']; wrap=g['wrap']
    roots=[np.array(2*v) for v in np.eye(4,dtype=int)]
    # reuse link function by rebuilding small helper
    links={}
    for s in g['sites']:
        for j in range(4): links[(s,j)]=len(links)
    def link(a,b):
        d=np.array(b)-np.array(a);d=(d+P//2)%P-P//2
        for j,r in enumerate(roots):
            if np.array_equal(d,r): return links[(wrap(a),j)],1
            if np.array_equal(d,-r): return links[(wrap(b),j)],-1
    rects=[];seen=set()
    for s in g['sites']:
        for m,n in itertools.permutations(range(4),2):
            e=[roots[m],roots[m],roots[n],-roots[m],-roots[m],-roots[n]]
            v=[np.array(s)]
            for x in e[:-1]: v.append(v[-1]+x)
            k=frozenset(wrap(x) for x in v)
            if k in seen: continue
            seen.add(k);rects.append([wrap(x) for x in v])
    d2r=np.zeros((len(rects),g['nlinks']))
    for p,v in enumerate(rects):
        for a,b in zip(v,v[1:]+v[:1]):
            i,sg=link(a,b);d2r[p,i]+=sg
    return g,d2r
def test(c1,L=3,T=6):
    g,d2r=build_rect(L,T);d2=g['d2'];P=g['P'];plaqs=g['plaqs']
    c0=1-8*c1
    K=c0*d2.T@d2+c1*d2r.T@d2r
    G=d2@np.linalg.pinv(K,rcond=1e-10,hermitian=True)@d2.T
    idx={frozenset(v):i for i,v in enumerate(plaqs)}
    tval=lambda Xt:((Xt+P[3]//2)%P[3])-P[3]//2
    pos=[p for p,v in enumerate(plaqs) if all(0<=tval(x[3])<P[3]//2-2 for x in v)]
    refl=lambda x:g['wrap'](np.array([x[0],x[1],x[2],-x[3]]))
    M=np.zeros((len(pos),len(pos)))
    for ia,a in enumerate(pos):
        rv=[refl(x) for x in plaqs[a]];b=idx[frozenset(rv)];w=plaqs[b];n=len(w);st=w.index(rv[0])
        eps=1 if all(w[(st+k)%n]==rv[k] for k in range(n)) else -1
        M[ia,:]=eps*G[b,pos]
    ev=np.linalg.eigvalsh((M+M.T)/2)
    print(f"Z4 plaquette+rectangle, c1={c1:+.4f}: min eig={ev.min():+.3e} (#neg={np.sum(ev<-1e-9)})")
for c1 in [0.0,-1/12,-0.2,+0.05]: test(c1)
