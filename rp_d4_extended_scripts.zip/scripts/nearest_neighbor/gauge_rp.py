"""Fermion RP in random U(1) gauge backgrounds that are mirror images across the reflection plane,
with links crossing the plane gauge-fixed to 1. Open, reflection-symmetric time boundaries."""
import numpy as np, itertools, sys
src=open(''+__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'open_rp.py')+'').read(); exec(src[:src.rindex('if __name__')])
def build_U(kind,L,Tm,plane,m,ra,rh,wh,rule,seed,amp=np.pi):
    rng=np.random.default_rng(seed);Ps=2*L
    Ra=list(2*np.eye(4,dtype=int))+list(-2*np.eye(4,dtype=int))
    Rh=list(itertools.product([1,-1],repeat=4)) if kind!='Z4' else []
    if kind=='Z4': wh=0;par=lambda X: all(x%2==0 for x in X)
    else: par=lambda X: len(set(np.array(X)%2))==1
    lo,hi=plane-Tm,plane+Tm
    sites=[X for X in itertools.product(range(Ps),range(Ps),range(Ps),range(lo,hi+1)) if par(X)]
    idx={s:i for i,s in enumerate(sites)};n=len(sites);D=np.zeros((4*n,4*n),complex)
    wa=1.0;norm=2*wa+4*wh
    wrap=lambda X:(X[0]%Ps,X[1]%Ps,X[2]%Ps,X[3])
    refl=lambda X:(X[0],X[1],X[2],2*plane-X[3])
    phase={}
    def U(a,b):  # oriented link a->b (wrapped coords)
        key=(a,b)
        if key in phase: return phase[key]
        ta,tb=a[3],b[3]
        if (ta-plane)*(tb-plane)<0: val=1.0                      # crossing link: gauge-fixed
        elif min(ta,tb)>=plane and not (ta==plane and tb==plane): val=np.exp(1j*rng.uniform(-amp,amp))  # positive side
        elif ta==plane and tb==plane:                             # in the plane: theta maps it to itself
            val=np.exp(1j*rng.uniform(-amp,amp)) if rule=='same' else rng.choice([1.0,-1.0])
        else:                                                     # negative side: mirror of positive link
            pa,pb=refl(a),refl(b);up=U(pa,pb)
            val=up if rule=='same' else np.conj(up)
        phase[key]=val;phase[(b,a)]=np.conj(val);return val
    for s in sites:
        i=idx[s];D[4*i:4*i+4,4*i:4*i+4]+=(m+(ra*wa*8+rh*wh*16)/norm)*I4
        for rr,w,r in [(x,wa,ra) for x in Ra]+[(x,wh,rh) for x in Rh]:
            if w==0: continue
            raw=np.array(s)+np.array(rr)
            if raw[3]<lo or raw[3]>hi: continue
            t=wrap(tuple(raw));j=idx[t];rhat=np.array(rr)/2.0
            D[4*i:4*i+4,4*j:4*j+4]+=-(w/norm)*U(s,t)*(r*I4-sum(rhat[mu]*g[mu] for mu in range(4)))
    return sites,idx,D
def gramU(kind,L,Tm,plane,m,ra,rh,wh,rule,seed):
    sites,idx,D=build_U(kind,L,Tm,plane,m,ra,rh,wh,rule,seed);S=np.linalg.inv(D)
    depth=Tm//2;pos=[s for s in sites if plane<s[3]<=plane+depth]
    refl=lambda s:(s[0],s[1],s[2],2*plane-s[3])
    ix=lambda a: np.concatenate([4*np.array(a)[:,None]+k for k in range(4)],1).ravel()
    A=[idx[s] for s in pos];B=[idx[refl(s)] for s in pos]
    M=(S[np.ix_(ix(A),ix(B))]@np.kron(np.eye(len(pos)),g[3])).T
    herm=np.abs(M-M.conj().T).max()/np.abs(M).max()
    ev=np.linalg.eigvalsh((M+M.conj().T)/2);sc=np.abs(ev).max()
    return int(np.sum(ev>1e-8*sc)),int(np.sum(ev<-1e-8*sc)),herm
def report(tag,args,seeds=3):
    res=[gramU(*args,seed=s) for s in range(seeds)]
    okk=all(min(a,b)==0 and h<1e-8 for a,b,h in res)
    print(f"{tag}: "+"; ".join(f"(+{a}/-{b}, herm {h:.0e})" for a,b,h in res)+(" -> RP holds" if okk else " -> FAILS"))
if __name__=="__main__":
    for rule in ['same','conj']:
        print(f"== mirror rule: U(theta link) = {'U' if rule=='same' else 'conj U'}")
        report("  Z4 Wilson r=1, link plane",('Z4',2,10,1,0.5,1.0,1.0,0.0,rule))
        report("  Z4 Wilson r=1, site plane",('Z4',2,10,0,0.5,1.0,1.0,0.0,rule))
        report("  Z4 Wilson r=1.5, link plane",('Z4',2,10,1,0.5,1.5,1.0,0.0,rule))
