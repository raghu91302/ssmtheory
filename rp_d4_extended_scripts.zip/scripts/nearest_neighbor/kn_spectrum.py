"""Transfer-matrix spectrum of free Wilson fermions on D4* (Hurwitz frame: sites Z^4 u Z^4+h, h=(1/2,1/2,1/2,1/2)),
time along e4 (a shortest vector), as in the simulation basis of Katz & Nogradi, arXiv:2512.10604.
Their operator (Eqs. 11-12): D0 = (1/6) sum_{24} gamma.n grad_n, Wilson term giving r p^2/2  ->
   D(k) = m + sum_n c_n [ r_n - r_n cos(k.n) ] * ... ; in position space each hop n carries -(w_n/N)(r_n - gamma.n), N = 2 w_a + 4 w_h.
Katz-Nogradi: all 24 weights equal (w_a = w_h = 1, N = 6) and one Wilson parameter r for every hop.
At fixed spatial momentum p, put z = exp(i k4 / 2): det D(p,z) is a Laurent polynomial in z. Its roots with |z|<1 are the
eigenvalues of the half-step transfer (translation by h); z^2 those of the unit step. Reflection positivity, for any
reflection, gives a self-adjoint transfer matrix, so every root must be real; a non-real root excludes positivity."""
import numpy as np, itertools
g=[np.array(M,complex) for M in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
I4=np.eye(4)
AX=[s*np.eye(4)[mu] for mu in range(4) for s in (1,-1)]
HM=[np.array(s)/2 for s in itertools.product([1,-1],repeat=4)]
def hops(ra,rh,wa,wh):
    N=2*wa+4*wh; out=[]
    for n in AX: out.append((n,-(wa/N)*(ra*I4-sum(n[mu]*g[mu] for mu in range(4)))))
    for n in HM: out.append((n,-(wh/N)*(rh*I4-sum(n[mu]*g[mu] for mu in range(4)))))
    diag=(8*wa*ra+16*wh*rh)/N
    return out,diag
def roots(p,m,ra,rh,wa=1.0,wh=1.0):
    """finite nonzero roots z of det D(p,z)=0, D(p,z)=sum_{j=-2..2} C_j z^j (z=e^{i k4/2}), via the 16x16
    companion linearization of z^2 D(p,z) = sum_k A_k z^k (generalized eigenproblem; handles singular A_0, A_4)."""
    from scipy.linalg import eig
    hp,diag=hops(ra,rh,wa,wh); C={j:np.zeros((4,4),complex) for j in range(-2,3)}
    C[0]+=(m+diag)*I4
    for n,M in hp: C[int(round(2*n[3]))]+=M*np.exp(1j*np.dot(p,n[:3]))
    A=[C[k-2] for k in range(5)]; Z=np.zeros((4,4)); n=4
    L=np.block([[Z,I4,Z,Z],[Z,Z,I4,Z],[Z,Z,Z,I4],[-A[0],-A[1],-A[2],-A[3]]])
    R=np.block([[I4,Z,Z,Z],[Z,I4,Z,Z],[Z,Z,I4,Z],[Z,Z,Z,A[4]]])
    w=eig(L,R,right=False)
    w=w[np.isfinite(w)]; return w[np.abs(w)>1e-9]
def report(tag,ra,rh,wa,wh,m,ngrid=7):
    worst=0;nonreal=0;neg=0;tot=0
    ps=[np.array(q) for q in itertools.product(np.linspace(-np.pi,np.pi,ngrid,endpoint=False)+0.137,repeat=3)]
    for p in ps:
        r=roots(p,m,ra,rh,wa,wh); r=r[np.abs(r)<1-1e-9]; tot+=len(r)
        im=np.abs(r.imag); worst=max(worst,im.max(initial=0)); nonreal+=np.sum(im>1e-7)
        neg+=np.sum((im<=1e-7)&(r.real<0))
    print(f"{tag:58s} m={m:+.2f}: roots |z|<1 per p = {tot/len(ps):.1f}, non-real {nonreal}/{tot} (max|Im z| {worst:.2e}), real negative {neg}")
if __name__=="__main__":
    for m in [0.0,0.2]:
        report("control: axis-only Wilson r=1 (Theorem B)",1,0,1,0,m)
        report("time-mixed, r_axis=1, r_mixed=1/2, equal weights",1,0.5,1,1,m)
        for r in [0.5,0.75,1.0,1.5,2.0]:
            report(f"Katz-Nogradi: uniform r={r}, equal weights",r,r,1,1,m)
