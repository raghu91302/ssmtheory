"""Is the free Wilson action of Katz & Nogradi (arXiv:2512.10604) reflection positive for SOME reflection matrix?
Action on D4* (Hurwitz frame), all 24 hops with equal weight and one Wilson parameter r (built by open_rp.build with
ra = rh = r, wh = 1, i.e. hop -(1/6)(r - gamma.n)), time along e4, open reflection-symmetric time boundaries.
Reflection Theta psi(x) = psibar(theta x) X with a general 4x4 matrix X. Gram matrix of all linear observables at t>0:
M(X) = (S_AB kron(1,X))^T. Positivity for some X  <=>  max over the Hermitian family of lambda_min(M), at fixed trace, is >= 0
(a concave maximisation, so a local optimum is global). Controls: hypercubic/axis-only r=1 and the mixed action with r_half = 1/2 (both feasible, X = gamma4)."""
import numpy as np, itertools, os, importlib.util
sp=importlib.util.spec_from_file_location('o',os.path.join(os.path.dirname(os.path.abspath(__file__)),'open_rp.py'))
o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o);g=o.g
def blocks(L,Tm,plane,m,ra,rh,wh):
    sites,idx,D=o.build('D4s',L,Tm,plane,m,ra,rh,wh);S=np.linalg.inv(D)
    pos=[s for s in sites if plane<s[3]<=plane+Tm//2];refl=lambda s:(s[0],s[1],s[2],2*plane-s[3])
    ix=lambda a: np.concatenate([4*np.array(a)[:,None]+k for k in range(4)],1).ravel()
    return S[np.ix_(ix([idx[s] for s in pos]),ix([idx[refl(s)] for s in pos]))],len(pos)
def clifford():
    out=[]
    for sub in itertools.chain.from_iterable(itertools.combinations(range(4),k) for k in range(5)):
        G=np.eye(4,dtype=complex)
        for mu in sub: G=G@g[mu]
        for ph in (1,-1,1j,-1j): out.append((sub,ph,ph*G))
    return out
def clifford_scan(SAB,n):
    best=None
    for sub,ph,X in clifford():
        M=(SAB@np.kron(np.eye(n),X)).T
        herm=np.abs(M-M.conj().T).max()/np.abs(M).max()
        if herm>1e-8: continue
        ev=np.linalg.eigvalsh((M+M.conj().T)/2); sc=np.abs(ev).max()
        neg=ev.min()/sc
        if best is None or neg>best[0]: best=(neg,sub,ph)
    return best
def sdp(SAB,n):
    """M(X) is linear in the 32 real parameters of X. Restrict to the subspace on which M is Hermitian, then
    maximise lambda_min(M) subject to tr M = 1. Returns the best lambda_min/(tr M / dim): >= 0 means some X works."""
    basis=[]
    for k in range(32):
        E=np.zeros(16,complex);E[k%16]=1 if k<16 else 1j;E=E.reshape(4,4)
        basis.append((SAB@np.kron(np.eye(n),E)).T)
    B=np.array(basis); d=B.shape[1]
    A=(B-np.conj(np.transpose(B,(0,2,1)))).reshape(32,-1)          # anti-Hermitian part, linear in c
    Areal=np.concatenate([A.real,A.imag],1).T
    u,sv,vt=np.linalg.svd(Areal,full_matrices=False); null=vt[np.sum(sv>1e-9*sv.max()):]
    if len(null)==0: return None,0
    H=[np.tensordot(v,B,1) for v in null]; H=[(h+h.conj().T)/2 for h in H]
    # lambda_min(sum c_i H_i) is concave in c; maximise it on the hyperplane tr M = d (convex problem: local = global)
    from scipy.optimize import minimize
    tr=np.array([np.trace(h).real for h in H])
    if np.allclose(tr,0): return None,len(H)
    c0=tr/np.dot(tr,tr)*d; P=np.eye(len(H))-np.outer(tr,tr)/np.dot(tr,tr)
    Q=np.linalg.svd(P)[0][:,:len(H)-1]                       # coordinates on the hyperplane
    f=lambda y: -np.linalg.eigvalsh(sum(ci*h for ci,h in zip(c0+Q@y,H)))[0]
    best=np.inf; rng=np.random.default_rng(0)
    for trial in range(6):
        r=minimize(f,rng.normal(0,3,len(H)-1) if trial else np.zeros(len(H)-1),method='Powell',
                   options={'maxiter':20000,'xtol':1e-10,'ftol':1e-12})
        best=min(best,r.fun)
    return -best,len(H)
if __name__=="__main__":
    cases=[("control: axis-only Wilson r=1",1.0,1.0,0.0),
           ("control: time-mixed with r_half=1/2",1.0,0.5,1.0),
           ("Katz-Nogradi free action, r=1",1.0,1.0,1.0)]
    for L,Tm in [(2,8)]:
        for tag,ra,rh,wh in cases:
            for plane,lab in [(0,'integer-slice plane'),(1,'half-integer-slice plane')]:
                SAB,n=blocks(L,Tm,plane,0.5,ra,rh,wh)
                neg,sub,ph=clifford_scan(SAB,n)
                lam,dim=sdp(SAB,n)
                print(f"L={L} {tag:36s} {lab:24s}: best Clifford X {ph}*Gamma{sub}: lambda_min/scale {neg:+.2e} | "
                      f"all X ({dim}-dim Hermitian family): best lambda_min (mean eig = 1) {lam:+.2e}",flush=True)

def robustness():
    """X = gamma4 is the only reflection matrix giving a Hermitian Gram matrix for the Katz-Nogradi action (above);
    check that its violation is stable in lattice size, depth, mass and r."""
    for L,Tm in [(2,8),(3,8),(3,12)]:
        for m in [0.0,0.1,0.5]:
            for r in [1.0]:
                for plane in (0,1):
                    SAB,n=blocks(L,Tm,plane,m,r,r,1.0);M=(SAB@np.kron(np.eye(n),g[3])).T
                    ev=np.linalg.eigvalsh((M+M.conj().T)/2);sc=np.abs(ev).max()
                    print(f"  L={L} Tm={Tm} m={m} r={r} plane={'int' if plane==0 else 'half'}: herm {np.abs(M-M.conj().T).max()/sc:.0e}, "
                          f"#neg {np.sum(ev<-1e-8*sc)}/{len(ev)}, lambda_min/scale {ev.min()/sc:+.2e}",flush=True)
    for r in [0.5,0.75,1.5,2.0]:
        SAB,n=blocks(2,8,0,0.5,r,r,1.0); neg,sub,ph=clifford_scan(SAB,n); lam,dim=sdp(SAB,n)
        print(f"  r={r}: best Clifford X {ph}*Gamma{sub} lambda_min/scale {neg:+.2e}; all X ({dim}-dim family) best lambda_min {lam if lam is None else f'{lam:+.2e}'}",flush=True)
if __name__=="__main__":
    print("== robustness (Katz-Nogradi action, X = gamma4)"); robustness()
