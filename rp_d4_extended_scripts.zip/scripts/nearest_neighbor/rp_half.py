import numpy as np, rp
def run(L,T,shift):
    g=rp.build('D4s',L,T);P=g['P'];d2=g['d2'];plaqs=g['plaqs']
    G=d2@np.linalg.pinv(d2.T@d2,rcond=1e-10,hermitian=True)@d2.T
    idx={frozenset(v):i for i,v in enumerate(plaqs)}
    tval=lambda Xt:((Xt-shift+P[3]//2)%P[3])-P[3]//2
    pos=[p for p,v in enumerate(plaqs) if all(0<=tval(x[3])<P[3]//2-2 for x in v)]
    refl=lambda x:g['wrap'](np.array([x[0],x[1],x[2],2*shift-x[3]]))
    M=np.zeros((len(pos),len(pos)));cross=0
    for ia,a in enumerate(pos):
        rv=[refl(x) for x in plaqs[a]];b=idx[frozenset(rv)];w=plaqs[b];n=len(w);st=w.index(rv[0])
        eps=1 if all(w[(st+k)%n]==rv[k] for k in range(n)) else -1
        M[ia,:]=eps*G[b,pos]
    # crossing triangles: vertices on both sides; are they all mirror-symmetric?
    sym=0
    for v in plaqs:
        ts=[tval(x[3]) for x in v]
        if min(ts)<0<max(ts) and max(ts)-min(ts)<=2:   # straddles this plane (not the far, periodic one)
            cross+=1
            if frozenset(refl(x) for x in v)==frozenset(v): sym+=1
    ev=np.linalg.eigvalsh((M+M.T)/2)
    print(f"plane at t={shift/2}: crossing triangles={cross}, mirror-symmetric={sym} | min eig={ev.min():+.2e} #neg={np.sum(ev<-1e-9)}")
run(3,6,0); run(3,6,1)
