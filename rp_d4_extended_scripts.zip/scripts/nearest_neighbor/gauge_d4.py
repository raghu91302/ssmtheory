import importlib.util
sp=importlib.util.spec_from_file_location('gr',__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'gauge_rp.py'));gr=importlib.util.module_from_spec(sp);sp.loader.exec_module(gr)
for plane,lab in [(0,'integer plane'),(1,'half plane')]:
    gr.report(f"D4* r_half=1/2, w_half=1, {lab}, L=2",('D4s',2,10,plane,0.5,1.0,0.5,1.0,'same'),seeds=4)
    gr.report(f"D4* r_half=1 (control), {lab}, L=2",('D4s',2,10,plane,0.5,1.0,1.0,1.0,'same'),seeds=2)
gr.report("D4* r_half=1/2, w_half=1, integer plane, L=3",('D4s',3,8,0,0.5,1.0,0.5,1.0,'same'),seeds=2)
gr.report("D4* r_half=1/2, w_half=1, half plane, L=3",('D4s',3,8,1,0.5,1.0,0.5,1.0,'same'),seeds=2)
