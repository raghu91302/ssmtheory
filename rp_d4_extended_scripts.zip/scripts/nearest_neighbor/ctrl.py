import numpy as np, itertools
src=open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'exact_rp2.py')).read(); exec(src[:src.index('def gram(')])
tkeys=[canon(plane,(0,0,0,2)),canon(plane,(0,0,0,-2))]
akeys=[canon((1,1,1,1),(0,0,0,2)), canon((1,1,1,-1),(0,0,0,-2))]
def gram_k(m,ra,rh,wh,keys):
    G=np.zeros((len(obs),len(obs)),complex)
    for bits in itertools.product([1.0,-1.0],repeat=len(keys)):
        D=build(m,ra,rh,wh,dict(zip(keys,bits)));det=np.linalg.det(D);S=np.linalg.inv(D)[np.ix_(sel,sel)]
        a=np.einsum('ipq,pq->i',Chat,S);b=np.einsum('juv,vu->j',Mhat,S)
        T=np.einsum('pu,juv,vq->jpq',S,Mhat,S);X2=np.einsum('ipq,jpq->ij',Chat,T)
        G+=det*(-(np.outer(a,b)-X2))
    H=(G+G.conj().T)/2;ev=np.linalg.eigvalsh(H);sc=np.abs(ev).max()
    return float(ev.min()/sc),int(np.sum(ev<-1e-9*sc))
print("w_half=0, dynamical Z2 temporal links:",gram_k(0.5,1.0,0.5,0.0,tkeys+akeys))
print("w_half=1/6, only temporal links dynamical:",gram_k(0.5,1.0,0.5,1/6,tkeys+akeys))
print("w_half=1/6, free:",gram_k(0.5,1.0,0.5,1/6,[]))
