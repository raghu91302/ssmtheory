"""Free Wilson fermions on D4* at fixed spatial momentum p: a one-dimensional chain of 4-spinors on the slices
t = n/2 (n integer), open reflection-symmetric boundaries. Hops: axis temporal (dt=1) -k_a (r_a - g4 sgn),
time-mixed (dt=1/2), summed over the 8 spatial offsets s: -k_h sum_s e^{i p.s} (r_h - g.s - sgn g4/2),
spatial axis hops give the diagonal m + diag - k_a sum_j (r_a 2cos p_j - 2i sin p_j g_j) on each slice.
Gram matrix of psibar on slices n = 1..N against the reflected slices (site plane n=0 or link plane n=1/2 shifted)."""
import numpy as np, itertools
g=[np.array(M,complex) for M in [[[0,0,0,-1j],[0,0,-1j,0],[0,1j,0,0],[1j,0,0,0]],[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]],
   [[0,0,-1j,0],[0,0,0,1j],[1j,0,0,0],[0,-1j,0,0]],[[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]]]]
I4=np.eye(4)
def chain(p,m,ra,rh,wa,wh,Nt):
    N=2*wa+4*wh; ka,kh=wa/N,wh/N; n=2*Nt+1; D=np.zeros((4*n,4*n),complex)
    diag=(m+(8*wa*ra+16*wh*rh)/N)*I4 - ka*sum(ra*2*np.cos(p[j])*I4 - 2j*np.sin(p[j])*g[j] for j in range(3))
    for a in range(n):
        D[4*a:4*a+4,4*a:4*a+4]=diag
        for dt,b in [(2,a+2),(-2,a-2)]:
            if 0<=b<n: D[4*a:4*a+4,4*b:4*b+4]+=-ka*(ra*I4-np.sign(dt)*g[3])
        for dt,b in [(1,a+1),(-1,a-1)]:
            if 0<=b<n:
                M=sum(np.exp(1j*np.dot(p,np.array(s)/2))*(rh*I4-sum(s[j]/2*g[j] for j in range(3))-np.sign(dt)*0.5*g[3])
                      for s in itertools.product([1,-1],repeat=3))
                D[4*a:4*a+4,4*b:4*b+4]+=-kh*M
    return D
def gram(p,m,ra,rh,wa,wh,Nt=16,depth=8):
    D=chain(p,m,ra,rh,wa,wh,Nt);S=np.linalg.inv(D);c=Nt
    ix=lambda a: np.arange(4*a,4*a+4)
    A=np.concatenate([ix(c+k) for k in range(1,depth+1)]);B=np.concatenate([ix(c-k) for k in range(1,depth+1)])
    M=(S[np.ix_(A,B)]@np.kron(np.eye(depth),g[3])).T
    ev=np.linalg.eigvalsh((M+M.conj().T)/2);return ev.min()/np.abs(ev).max(),np.abs(M-M.conj().T).max()/np.abs(M).max(),int(np.sum(ev<-1e-10*np.abs(ev).max()))
if __name__=="__main__":
    for tag,ra,rh,wa,wh in [("axis-only r=1",1,0,1,0),("r_half=1/2",1,0.5,1,1),("Katz-Nogradi r=1",1,1,1,1)]:
        for p in [(0,0,0),(np.pi,0,0),(np.pi,np.pi,0),(np.pi,np.pi,np.pi),(0.7,0.3,0.1),(np.pi/2,0,0)]:
            lam,h,nn=gram(np.array(p),0.5,ra,rh,wa,wh)
            print(f"{tag:18s} p={np.round(p,3)}: lambda_min/scale {lam:+.3e}  #neg {nn}  herm {h:.0e}")

def zero_momentum_block(m,ra,rh,wa=1.0,wh=1.0,Nt=60):
    """<psi(t=1/2) psibar(t=-1/2)> at p=0 = G+ P+ + G- P-; with Theta psi = psibar gamma4 the Gram block of the slice
    t=1/2 has eigenvalues +G+(2) (on P+) and -G-(2) (on P-). G- = 0 exactly for axis-only and for r_h = 1/2."""
    D=chain(np.zeros(3),m,ra,rh,wa,wh,Nt);S=np.linalg.inv(D);c=Nt
    Sfw=S[4*(c+1):4*(c+1)+4,4*(c-1):4*(c-1)+4];g4=g[3]
    return np.trace((np.eye(4)+g4)/2@Sfw).real/2, np.trace((np.eye(4)-g4)/2@Sfw).real/2
def scan_r():
    print("== W(F4)-symmetric Wilson actions (r_a = r_h = r, equal weights) at p=0: full Gram lambda_min/scale, G-(2)")
    for r in [0.1,0.25,0.4,0.5,0.6,0.75,1.0,1.5,2.0]:
        for m in [0.5,0.0]:
            lam,h,nn=gram(np.zeros(3),m,r,r,1,1); Gp,Gm=zero_momentum_block(m,r,r)
            print(f"  r={r:4.2f} m={m:+.1f}: lambda_min/scale {lam:+.3e} (#neg {nn}, herm {h:.0e});  G+(2)={Gp:+.4f}  G-(2)={Gm:+.4e}")
    print("== two-parameter family r_a = 1, equal weights, scan r_h (m=0.5): lambda_min/scale at p=0")
    for rh in [0.3,0.4,0.45,0.5,0.55,0.6,0.75,1.0,1.5]:
        lam,h,nn=gram(np.zeros(3),0.5,1.0,rh,1,1); Gp,Gm=zero_momentum_block(0.5,1.0,rh)
        print(f"  r_h={rh:4.2f}: lambda_min/scale {lam:+.3e} (#neg {nn});  G-(2)={Gm:+.4e}")
if __name__=="__main__":
    scan_r()
