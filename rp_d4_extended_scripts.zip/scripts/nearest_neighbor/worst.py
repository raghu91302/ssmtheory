"""Worst-case gauge field for the kernel inequality.
Exact reduced condition (r_half=1/2): kappa_h^2 * G^dag (P- K P-)^{-1} G <= 2 kappa_a on P+ spinors at A sites,
G = sum_s Gamma_s U(y->y+s) T_s  (plane <- A), K = plane Dirac operator with plane links."""
import numpy as np, itertools
from scipy.optimize import minimize
import os; src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'kernel.py')).read(); exec(src[:src.rindex('if __name__')])
Pp=(I4+g4)/2;Pm=(I4-g4)/2
def ratio(phis,L,m,wh=1.0):
    P=2*L;n=2+4*wh;ka,kh=1/n,wh/n;on=m+(8+8*wh)/n
    pl=list(itertools.product(range(0,P,2),repeat=3));A=list(itertools.product(range(1,P,2),repeat=3))
    pi={y:i for i,y in enumerate(pl)};ai={x:i for i,x in enumerate(A)};it=iter(phis)
    K=np.zeros((4*len(pl),4*len(pl)),complex);G=np.zeros((4*len(pl),4*len(A)),complex)
    seen={}
    def ph(a,b):
        if (a,b) not in seen: v=np.exp(1j*next(it));seen[(a,b)]=v;seen[(b,a)]=np.conj(v)
        return seen[(a,b)]
    for y in pl:
        i=pi[y];K[4*i:4*i+4,4*i:4*i+4]+=on*I4
        for mu in range(3):
            for sg in (1,-1):
                e=np.zeros(3,int);e[mu]=2*sg;z=tuple(np.mod(np.array(y)+e,P))
                K[4*i:4*i+4,4*pi[z]:4*pi[z]+4]+=-ka*(I4-sg*g[mu])*ph(('p',)+y,('p',)+z)
        for s in itertools.product([1,-1],repeat=3):
            x=tuple(np.mod(np.array(y)+np.array(s),P));Gs=sum(0.5*s[k]*g[k] for k in range(3))
            G[4*i:4*i+4,4*ai[x]:4*ai[x]+4]+=Gs*ph(('p',)+y,('a',)+x)
    PmB=np.kron(np.eye(len(pl)),Pm);PpA=np.kron(np.eye(len(A)),Pp)
    KK=PmB@K@PmB+np.kron(np.eye(len(pl)),Pp)     # invert on P- block (P+ block padded with identity)
    Mx=kh**2*PpA@G.conj().T@PmB@np.linalg.inv(KK)@PmB@G@PpA
    lam=np.linalg.eigvalsh((Mx+Mx.conj().T)/2).max()
    return lam/(2*ka)          # condition: <= 1
def nphase(L): P=2*L; n_pl=(L**3); return n_pl*3+n_pl*8   # plane links + plane->A links (upper bound on count)
rng=np.random.default_rng(0)
for m in [-1.0,0.0,1.0,2.0,7/3]:
    L=2;N=nphase(L)
    free=ratio(np.zeros(N),L,m)
    best=-1;bx=None
    for trial in range(6):
        x0=rng.uniform(-np.pi,np.pi,N)
        r=minimize(lambda x:-ratio(x,L,m),x0,method='L-BFGS-B',options={'maxiter':300})
        if -r.fun>best: best=-r.fun;bx=r.x
    print(f"m={m:+.3f}: free-field ratio {free:.4f}  | worst found over gauge fields {best:.4f}  ({'holds' if best<=1+1e-9 else 'VIOLATED'})")
