"""Maximize the free-field RP score over all W(F4)-symmetric 4-shell Wilson actions (w1..w4 normalized, rho1..rho4 free).
Score = min over a momentum set of (smallest Gram eigenvalue / largest). Positive or zero = no violation detected."""
import sys, numpy as np
from scipy.optimize import minimize
from multishell import *
SMALL = [np.array(v) * t for t in (0.15, 0.4) for v in ([1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0.5, 0.2])] + [np.zeros(3)]
def unpack(x):
    w = np.array(x[:4]); n = normalization(w)
    if abs(n) < 1e-6: return None
    return w / n, np.array(x[4:])
def score(x, momenta, m=0.5):
    u = unpack(x)
    if u is None: return 1e3
    w, rho = u
    if np.abs(w).max() > 5: return 1e3
    try:
        s, h = rp_score(m, hops(w, rho), momenta=momenta, Nt=16, depth=8)
    except np.linalg.LinAlgError:
        return 1e3
    return -s
if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "small"
    mom = SMALL if which == "small" else SMALL + MOMENTA[::7]
    rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv) > 2 else 0)
    starts = [np.array([1/6, 0, 0, 0, 1, 1, 1.5, 2]), np.array([1/12, 1/24, 0, 0, 0.5, 1.08, 1.5, 2]),
              np.array([0, 1/12, 0, 0, 1, 1, 1.5, 2])] + [np.concatenate([rng.normal(0, .05, 4), rng.uniform(-1, 3, 4)]) for _ in range(9)]
    out = []
    for x0 in starts:
        r = minimize(score, x0, args=(mom,), method="Nelder-Mead", options={"maxiter": 1500, "xatol": 1e-6, "fatol": 1e-9})
        w, rho = unpack(r.x)
        out.append((-r.fun, np.round(w, 4), np.round(rho, 4)))
        print(f"best score {-r.fun:+.3e}  w={np.round(w,4)}  rho={np.round(rho,4)}", flush=True)
