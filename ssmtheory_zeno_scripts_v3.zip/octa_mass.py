#!/usr/bin/env python3
"""Section 7, dark matter: lowest bag mode of an octahedral cell of edge L_c, as a control.
Shape factor from dirac_cavity.py (octa_runs.log): octahedron/cuboctahedron ratio on the same grid (n=40 R=12 Mout=4,
n=48 R=16 Mout=3), times the cluster value 2.596 of cavity_modes.py. x is in units of the octahedron's circumradius L_c/sqrt2."""
import numpy as np
hbarc=197.327; rp=0.84075; Lc=rp/(0.5687*0.7290/0.7157)
ratio=np.mean([3.1461/2.6201, 3.1236/2.5485]); x=ratio*2.596; R=Lc/np.sqrt(2); E=x*hbarc/R
print('L_c=%.3f fm  oct circumradius=%.3f fm  x=%.3f  E=%.0f MeV'%(Lc,R,x,E))
for N in (2,3,4): M=np.sqrt(N*(N-1))*E; print('%d modes, center of mass removed: %.0f MeV (%+.0f%% vs 1719)'%(N,M,100*(M/1719-1)))
