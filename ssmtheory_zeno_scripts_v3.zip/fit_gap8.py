#!/usr/bin/env python3
"""2048 cells: fit mass^2 and mass against t/lam on 0.030 <= t <= 0.044 (two runs each, |gap|)."""
import re, numpy as np, collections
d=collections.defaultdict(list)
for l in open('gap_L8_all.log'):
    m=re.search(r't/lam=([\d.]+) .*gap=(-?[\d.]+)',l); d[float(m.group(1))].append(abs(float(m.group(2))))
for t in sorted(d): g=np.array(d[t]); print('t/lam=%.3f  mass=%.3f +- %.3f  mass^2=%.4f'%(t,g.mean(),g.std()/np.sqrt(2),g.mean()**2))
T=np.array([0.03,0.035,0.04,0.042,0.044]); G=np.array([np.mean(d[t]) for t in T]); W=1/np.array([max(np.std(d[t]),0.003) for t in T])
for name,y,w in (('mass^2',G**2,W*2*G**-1*0+1),('mass',G,np.ones(5))):
    (A,b),cov=np.polyfit(T,y,1,cov=True); r=y-(A*T+b); print('%-7s linear in t: t_c=%.4f  residuals %s  rms %.4f'%(name,-b/A,np.round(r,4),np.sqrt(np.mean(r**2))))
p=np.polyfit(np.log(0.0455-T),np.log(G),1); print('mass ~ (t_c - t)^a with t_c=0.0455: a=%.2f'%p[0])
for tc in (0.045,0.0455,0.046): print('  t_c=%.4f  exponent %.2f'%(tc,np.polyfit(np.log(tc-T),np.log(G),1)[0]))
