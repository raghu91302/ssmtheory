#!/usr/bin/env python3
"""Section 7, dark matter: explicit separating operators. In the FCC code each bond lies in exactly two octahedral cells,
so a Z-type operator is a set of edges in the graph whose vertices are octahedral cells and whose edges are bonds, and
its failed checks are the vertices of odd degree. The fewest flipped bonds that produce a given set S of failed checks is
a minimum S-join: a minimum-weight perfect matching of S under graph distance. We take the twelve failed checks of the
octahedral pattern and move (a) one of them, (b) two neighboring ones, to distance r along a cube axis, and report the
failed-check count n_f and the fewest flipped bonds w. In the bond-term estimate the cost is lam*n_f + h*w."""
import numpy as np, itertools as it, networkx as nx, sys
L=int(sys.argv[1]) if len(sys.argv)>1 else 8; P=2*L
nodes=[p for p in it.product(range(P),repeat=3) if sum(p)%2==0]
D=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
def octs_of(p,d):
    a=np.array(p); c=a+np.array(d); out=[]
    for e in [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]:
        o=a+np.array(e)
        if np.abs(c-o).sum()==1: out.append(tuple(o%P))
    return out
G=nx.Graph()
for p in nodes:
    for d in D:
        o1,o2=octs_of(p,d); G.add_edge(o1,o2)
dist=lambda a,b: nx.shortest_path_length(G,a,b)
def wmin(S):
    S=list(S); K=nx.Graph()
    for a,b in it.combinations(range(len(S)),2): K.add_edge(a,b,weight=-dist(S[a],S[b]))
    m=nx.max_weight_matching(K,maxcardinality=True); return -sum(K[a][b]['weight'] for a,b in m)
c=(1,0,0); nbr=sorted(G.neighbors(c)); assert len(nbr)==12
w0=wmin(nbr); print('L=%d  intact: n_f=12  fewest flipped bonds w=%d (the twelve-edge pattern itself has 12)'%(L,w0))
a=(1,1,1) if (1,1,1) in nbr else None
a=max(nbr); b=[x for x in nbr if x!=a and dist(x,a)==1][0]   # one failure, and a neighboring second one
print(' moved   r(L_c)   one failure: n_f  w     two neighboring failures: n_f  w')
for k in range(1,L//2):
    sh=np.array((2*k,0,0)); m=lambda o: tuple((np.array(o)+sh)%P)
    S1=[x for x in nbr if x!=a]+[m(a)]
    S2=[x for x in nbr if x not in (a,b)]+[m(a),m(b)]
    r=np.sqrt(2)*k
    print('  k=%d   %5.2f        %2d  %3d                       %2d  %3d'%(k,r,len(S1),wmin(S1),len(S2),wmin(S2)),flush=True)
