#!/usr/bin/env python3
"""Exact test in one dimension: the repetition code with checks Z_i Z_{i+1} (cost 2J_i to fail) and a term h X_i that
moves and pair-creates failed checks:  H = -sum_i J_i Z_i Z_{i+1} - sum_i h X_i.  Jordan-Wigner makes this a free
Majorana chain; the excitation energies are 2 x the singular values of the bidiagonal matrix with diagonal h and
superdiagonal J_i (on a ring, so no end modes). Uniform: E(k) = 2 sqrt(J^2 + h^2 - 2 J h cos k), gap 2|J-h|, speed 2h at J = h.
A region with J = h (checks balanced, massless) inside walls with J = h + D gives levels to compare with a Dirac field
with mass m(x) = 2(J(x) - h): bag levels E_n = (n+1/2) pi v / L for strong walls, and E_1 = (pi v/2)/(L + v/K), K = 2D."""
import numpy as np
from scipy.linalg import svdvals
def levels(Jin,Jout,h,L,pad=400,n=4):
    J=np.full(L+2*pad,Jout,float); J[pad:pad+L]=Jin          # J_i couples sites i,i+1
    N=len(J); M=np.diag(np.full(N,h))+np.diag(J[:-1],1); M[N-1,0]=J[-1]   # ring: no open ends
    return np.sort(2*svdvals(M))[:n]
h=1.0; v=2*h
print('massless region (J=h) inside walls J=h+D: E1*L/v and Zeno law (pi/2)*L/(L+v/K), K=2D')
for D in (0.5,1,2,4,8):
    K=2*D
    for L in (50,100,200,400):
        e=levels(h,h+D,h,L); print('  D=%-4g L=%-4d E1 L/v=%.4f  law=%.4f   E2/E1=%.3f E3/E1=%.3f'%(D,L,e[0]*L/v,np.pi/2*L/(L+v/K),e[1]/e[0],e[2]/e[0]))
print('walls of the other sign, J = h - D (checks weaker outside, mass -2D): E1*L/v')
for D in (0.5,0.9):
    for L in (100,400): e=levels(h,h-D,h,L); print('  D=%g L=%d  E1 L/v=%.4f'%(D,L,e[0]*L/v))
print('region with checks switched off inside (J=0, mass -2h) in walls J=2h (mass +2h): lowest levels')
for L in (10,20,40): print('  L=%d'%L, np.round(levels(0.0,2*h,h,L),8))
print('a potential cannot arise: the BdG spectrum is symmetric under E -> -E for every J(x), as a Majorana mass requires')
