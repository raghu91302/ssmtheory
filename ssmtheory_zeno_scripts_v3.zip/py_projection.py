#!/usr/bin/env python3
"""Peierls-Yoccoz projection of three quarks in the lowest cavity mode onto total momentum zero.
The quark mode u is the lowest positive-energy state of the lattice Dirac Hamiltonian of dirac_cavity.py:
   h = alpha.(-i grad) + beta [ M(x) + (r/2)(-Laplacian) ],  M = 0 inside the cavity, M_out outside, periodic box.
The three-quark state is the product Phi = u(r1) u(r2) u(r3) (spin-averaged overlaps). Its translate by a is Phi_a.
In the free-center picture the wall moves with the quarks, so the one-body energy between Phi and Phi_a uses the
average of the two walls:  h(a) = <u|T|u_a> + <u| beta (M(x) + M(x-a))/2 |u_a>,  T the translation-invariant part.
With n(a) = <u|u_a>:
   E_PY = 3 sum_a h(a) n(a)^2 / sum_a n(a)^3                       (energy of the P = 0 state)
   r_int^2 = sum_a (2/3)[q(a) n(a)^2 - d(a).d(a) n(a)] / sum_a n(a)^3   (mean square radius about the quarks' center)
with q(a) = <u|x^2|u_a>, d(a) = <u|x|u_a>. Without projection (a = 0 only): E = 3 e, r_int^2 = (2/3)<x^2>.
Usage: python3 py_projection.py sphere|cubo n R Mout"""
import numpy as np, scipy.sparse as sp, sys
from scipy.sparse.linalg import lobpcg, LinearOperator
shape=sys.argv[1]; n=int(sys.argv[2]); Rg=float(sys.argv[3]); Mout=float(sys.argv[4]); r=1.0
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); Z=np.zeros((2,2))
al=[np.block([[Z,s],[s,Z]]) for s in (s1,s2,s3)]; be=np.diag([1,1,-1,-1]).astype(complex)
c=(np.arange(n)-n/2+0.5); X,Y,Zc=np.meshgrid(c,c,c,indexing='ij')
if shape=='sphere': inside=X**2+Y**2+Zc**2<Rg**2
else:
    a=Rg/np.sqrt(2); inside=(np.abs(X)<a)&(np.abs(Y)<a)&(np.abs(Zc)<a)&(np.abs(X)+np.abs(Y)+np.abs(Zc)<2*a)
Mx=np.where(inside,0.0,Mout); N=n**3; I=sp.identity(N,format='csr')
def shift(d,s):
    idx=np.arange(N).reshape(n,n,n); j=np.roll(idx,-s,axis=d).ravel(); return sp.csr_matrix((np.ones(N),(np.arange(N),j)),shape=(N,N))
D=[];Lap=-6*I
for d in range(3):
    Sp,Sm=shift(d,1),shift(d,-1); D.append((Sp-Sm)/2); Lap=Lap+Sp+Sm
T=sp.kron(-0.5*r*Lap,be)
for d in range(3): T=T+sp.kron(-1j*D[d],al[d])
T=T.tocsr(); W=sp.kron(sp.diags(Mx.ravel()),be).tocsr(); H=(T+W).tocsr()
H2=LinearOperator(H.shape,matvec=lambda v: H@(H@v),dtype=complex)
rng=np.random.default_rng(0); X0=rng.random((H.shape[0],4))+0j
w,V=lobpcg(H2,X0,largest=False,tol=1e-9,maxiter=4000)
E=np.sqrt(w.real.min())
# positive-energy subspace: P+ v = (v + H v / E)/2 ; orthonormalize two vectors
U=[]
for i in range(V.shape[1]):
    v=V[:,i]; p=(v+H@v/E)/2
    for u in U: p=p-u*(u.conj()@p)
    if np.linalg.norm(p)>1e-3: U.append(p/np.linalg.norm(p))
    if len(U)==2: break
res=max(np.linalg.norm(H@u-E*u) for u in U)
def field(v): return v.reshape(n,n,n,4)
def corr(f,g):
    """C(a) = sum_x f(x)^dag g(x-a), all shifts a, summed over spinor components."""
    F=np.fft.fftn(f,axes=(0,1,2)); G=np.fft.fftn(g,axes=(0,1,2))
    return np.fft.ifftn((np.conj(F)*G).sum(-1),axes=(0,1,2))   # = sum_x f*(x) g(x+a); flip below
def corrA(f,g): C=corr(f,g); return np.roll(np.flip(C,axis=(0,1,2)),1,axis=(0,1,2))  # g(x-a)
xs=np.stack([X,Y,Zc],-1)
nA=0; hA=0; hT=0; qA=0; dA=[0,0,0]
S12=corrA(field(U[0]),field(U[1])); S11=corrA(field(U[0]),field(U[0]))
for u in U:   # spin average over the two degenerate modes
    uf=field(u); Tu=field(T@u); bMu=field(W@u)
    hT=hT+corrA(uf,Tu)/2
    nA=nA+corrA(uf,uf)/2; hA=hA+(corrA(uf,Tu)+0.5*(corrA(bMu,uf)+corrA(uf,bMu)))/2
    qA=qA+corrA(uf*(xs**2).sum(-1)[...,None],uf)/2
    for k in range(3): dA[k]=dA[k]+corrA(uf*xs[...,k][...,None],uf)/2
# check a = 0 and one direct shift
chk=abs(nA[0,0,0]-1); u=field(U[0]); a=(2,1,0); direct=(np.conj(u)*np.roll(u,a,axis=(0,1,2))).sum()
nn=field(U[0]); C0=corrA(nn,nn)
print('E=%.5f  residual=%.1e  n(0)-1=%.1e  h(0)/E=%.6f  shift check %.2e'%(E,res,chk,(hA[0,0,0]/E).real,abs(C0[a]-direct)))
n_=nA.real; h_=hA.real; q_=qA.real; d2=sum(dk.real**2 for dk in dA)
print('max |imag| n,h: %.1e %.1e'%(np.abs(nA.imag).max(),np.abs(hA.imag).max()))
hT_=hT.real; Tk=hT_[0,0,0]; Wk=e_=None
edge=max(abs(n_[0,:,:]).max(),abs(n_[:,0,:]).max(),abs(n_[:,:,0]).max(),abs(n_[n//2,:,:]).max())
print('  spin off-diagonal overlap max|S12|/max|S11| = %.2e   largest |n(a)| at half-box shift = %.2e'%(abs(S12).max()/abs(S11).max(), abs(n_[n//2,:,:]).max()))
Z3=(n_**3).sum(); EPYT=3*(hT_*n_**2).sum()/Z3; EPY=3*(h_*n_**2).sum()/Z3; rint2=((2/3)*(q_*n_**2-d2*n_)).sum()/Z3
rcav2=q_[0,0,0]; e=E
Ekin=3*Tk; Ewall=3*(e-Tk); Mkin=EPYT+Ewall
print('  per quark: kinetic <T>=%.4f e, wall <beta M>=%.4f e;  projected kinetic / unprojected = %.4f'%(Tk/e,(e-Tk)/e,EPYT/Ekin))
k_kin=Mkin*np.sqrt(rint2)
k_pin=3*e*np.sqrt(rcav2); k_free=np.sqrt(6)*e*np.sqrt((2/3)*rcav2); k_py=EPY*np.sqrt(rint2)
print('%s n=%d R=%g Mout=%g  e*R=%.4f  rms_cav/R=%.4f'%(shape,n,Rg,Mout,e*Rg,np.sqrt(rcav2)/Rg))
print('  E_PY/(3e)=%.4f   r_int/r_cav=%.4f   (sqrt6/3=%.4f, sqrt(2/3)=%.4f)'%(EPY/(3*e),np.sqrt(rint2/rcav2),np.sqrt(6)/3,np.sqrt(2/3)))
print('  M r_p in hbar c:  pinned 3E %.3f | free (sqrt6, sqrt2/3) %.3f | PY, symmetric wall %.3f | PY, kinetic projected %.3f'%(k_pin,k_free,k_py,k_kin))
hc=197.327; rp=0.84075
print('  masses (MeV) at r_p:  pinned %.0f | free %.0f | PY sym %.0f | PY kin %.0f'%(k_pin*hc/rp,k_free*hc/rp,k_py*hc/rp,k_kin*hc/rp))
