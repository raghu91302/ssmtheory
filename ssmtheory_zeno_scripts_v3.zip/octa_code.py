#!/usr/bin/env python3
"""Syndromes of tetrahedral and octahedral bond patterns in the periodic FCC code (box of L cubic cells).
Qubits on bonds. Node checks: Z on the 12 bonds of a node. Octahedral checks: X on the 12 edges of an octahedral cell.
A Z-type pattern fails the octahedral checks that contain an odd number of its bonds; an X-type pattern fails the node
checks with an odd number. A pattern with no failed checks is either a product of checks (pure vacuum) or a logical."""
import numpy as np, itertools as it
L=3; P=2*L
nodes=[p for p in it.product(range(P),repeat=3) if sum(p)%2==0]
D=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
w=lambda p:tuple(np.mod(p,P))
B=[frozenset((p,w(np.add(p,d)))) for p in nodes for d in D]; bi={b:i for i,b in enumerate(B)}
octc=[p for p in it.product(range(P),repeat=3) if sum(p)%2==1]
def overt(c): return [w(np.add(c,s*np.array(e))) for e in [(1,0,0),(0,1,0),(0,0,1)] for s in (1,-1)]
def edges(vs): return [frozenset(e) for e in it.combinations(vs,2) if frozenset(e) in bi]
OX=[set(edges(overt(c))) for c in octc]                     # oct check supports
NZ=[{b for b in B if p in b} for p in nodes]                 # node check supports
def bits(E): return sum(1<<bi[e] for e in E)
def rank2(rows):
    piv={}; r=0
    for x in rows:
        while x:
            h=x.bit_length()-1
            if h in piv: x^=piv[h]
            else: piv[h]=x; r+=1; break
    return r
RZ=[bits(s) for s in NZ]; RX=[bits(s) for s in OX]; rZ=rank2(RZ); rX=rank2(RX)
def classify(E,kind):
    E=set(E)
    if kind=='Z': fail=[i for i,s in enumerate(OX) if len(s&E)%2]; span,r=RZ,rZ
    else:         fail=[i for i,s in enumerate(NZ) if len(s&E)%2]; span,r=RX,rX
    if fail: return 'fails %d checks'%len(fail), fail
    return ('product of checks (vacuum)' if rank2(span+[bits(E)])==r else 'LOGICAL (no failed check, not a product)'), []
sub=lambda v:'A' if all(c%2==0 for c in v) else ('xy' if v[2]%2==0 else ('xz' if v[1]%2==0 else 'yz'))
tet=[(0,0,0),(1,1,0),(1,0,1),(0,1,1)]; oc=(1,0,0); ov=overt(oc)
print('box: %d nodes, %d qubits; k=%d'%(len(nodes),len(B),len(B)-rZ-rX))
print('tet corners  :',[sub(v) for v in tet]); print('oct corners  :',[sub(v) for v in ov])
pats={'lone color (one anchor bond)':edges(tet[:2]),
      'tet singlet (anchor star, 3 bonds)':[frozenset((tet[0],v)) for v in tet[1:]],
      'K4  (6 edges of a tet cell)':edges(tet),
      'K222 (12 edges of an oct cell)':edges(ov)}
for k,E in pats.items():
    for t in 'ZX': print('%-36s %s-type: %s'%(k,t,classify(E,t)[0]))
# fractions: proper nonempty sub-patterns of K222 and of K4 with no failed check, and the fewest failures of a fraction
for name,E in [('K4',edges(tet)),('K222',edges(ov))]:
    E=list(E)
    for t in 'ZX':
        free=[];mn=99
        for m in range(1,len(E)):
            for S in it.combinations(E,m):
                c,f=classify(S,t)
                if not f: free.append(m)
                else: mn=min(mn,len(f))
        print('%s %s-type: syndrome-free proper subsets %d (sizes %s); fewest failed checks of a fraction %d'%(name,t,len(free),sorted(set(free)),mn))
