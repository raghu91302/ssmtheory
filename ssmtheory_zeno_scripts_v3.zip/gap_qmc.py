#!/usr/bin/env python3
"""Exact (Monte Carlo) mass of a failed octahedral check in the FCC code with a bond term that moves failures:
   H = lam sum_o (1 - S_o)/2 - t sum_b Z_b      (node checks satisfied; no X_b term).
In the sector with every node check satisfied, Z_b = s_o s_o' for Ising spins on the octahedral cells (an FCC lattice,
12 neighbours) and S_o = sigma^x_o, so H is the transverse-field Ising model -t sum s s - (lam/2) sum sigma^x.
A failed check is a flipped sigma^x: its energy at t = 0 is lam. We sample the 3+1D path integral with the Wolff cluster
algorithm and read the gap (the mass of one failed check) from the zero-momentum imaginary-time correlator.
Usage: python3 gap_qmc.py L t_over_lam beta [dtau nmeas seed]   (lam = 1)"""
import numpy as np, itertools as it, sys, numba
L=int(sys.argv[1]); t=float(sys.argv[2]); beta=float(sys.argv[3])
dtau=float(sys.argv[4]) if len(sys.argv)>4 else 0.05; nmeas=int(sys.argv[5]) if len(sys.argv)>5 else 4000; seed=int(sys.argv[6]) if len(sys.argv)>6 else 1
lam=1.0; G=lam/2; P=2*L
pts=[p for p in it.product(range(P),repeat=3) if sum(p)%2==1]; idx={p:i for i,p in enumerate(pts)}; N=len(pts)
nbv=[d for d in it.product((-1,0,1),repeat=3) if sorted(map(abs,d))==[0,1,1]]
nb=np.array([[idx[tuple((np.add(p,d))%P)] for d in nbv] for p in pts],np.int64)
M=int(round(beta/dtau))
Ks=-0.5*np.log(np.tanh(dtau*G)); Kj=dtau*t
ps=1-np.exp(-2*Ks); pj=1-np.exp(-2*Kj)
@numba.njit(cache=True)
def sweep(s,nb,ps,pj,nclus):
    N,M=s.shape; stack=np.empty(N*M*2,np.int64); tot=0
    while tot<nclus*N*M:
        i=np.random.randint(N); k=np.random.randint(M); sg=s[i,k]; s[i,k]=-sg; top=0; stack[top]=i*M+k; top+=1; tot+=1
        while top>0:
            top-=1; x=stack[top]; i0=x//M; k0=x%M
            for dk in (-1,1):
                k1=(k0+dk)%M
                if s[i0,k1]==sg and np.random.random()<ps: s[i0,k1]=-sg; stack[top]=i0*M+k1; top+=1; tot+=1
            for j in range(12):
                i1=nb[i0,j]
                if s[i1,k0]==sg and np.random.random()<pj: s[i1,k0]=-sg; stack[top]=i1*M+k0; top+=1; tot+=1
    return tot
@numba.njit(cache=True)
def corr(s):
    N,M=s.shape; m=np.zeros(M)
    for k in range(M):
        a=0.0
        for i in range(N): a+=s[i,k]
        m[k]=a
    C=np.zeros(M)
    for d in range(M):
        a=0.0
        for k in range(M): a+=m[k]*m[(k+d)%M]
        C[d]=a/(M*N)
    return C
np.random.seed(seed); import numpy.random as nr; nr.seed(seed)
@numba.njit(cache=True)
def seedit(x): np.random.seed(x)
seedit(seed)
s=np.ones((N,M),np.int64)
for _ in range(100): sweep(s,nb,ps,pj,1)
C=np.zeros(M); Cs=[]
for n in range(nmeas):
    sweep(s,nb,ps,pj,1); c=corr(s); C+=c
    if (n+1)%(nmeas//10)==0: Cs.append(C/(n+1))
C/=nmeas
# effective gap from cosh fit on the first half: Delta(tau) = arccosh((C(tau-1)+C(tau+1))/(2C(tau)))/dtau
taus=np.arange(1,M//2)
eff=np.arccosh(np.clip((C[taus-1]+C[taus+1])/(2*C[taus]),1,None))/dtau
# plateau: average effective gap where C is still well above noise
blocks=np.array([cc for cc in Cs]); 
def gap(c,lo,hi): 
    tt=np.arange(lo,hi); return np.mean(np.arccosh(np.clip((c[tt-1]+c[tt+1])/(2*c[tt]),1,None))/dtau)
lo=int(1.0/dtau); hi=M//2
from scipy.optimize import curve_fit
tt=np.arange(lo,hi)*dtau; f=lambda x,A,D: A*np.cosh(D*(x-beta/2))
popt,_=curve_fit(f,tt,C[lo:hi],p0=(C[lo]*np.exp(-beta/2),1.0)); g=popt[1]
gb=[]
for cc in Cs:
    try: gb.append(curve_fit(f,tt,cc[lo:hi],p0=popt)[0][1])
    except Exception: pass
print('L=%d N=%d t/lam=%.4f beta=%.1f dtau=%.3f M=%d  gap=%.4f lam  (running %s)  C(0)=%.3f'%(L,N,t,beta,dtau,M,g,np.round(gb[-4:],3),C[0]),flush=True)
