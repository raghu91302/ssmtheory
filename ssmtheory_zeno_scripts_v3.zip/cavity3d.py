#!/usr/bin/env python3
"""Three dimensions, linearized: failed octahedral checks of the FCC code as Z2 charges on the octahedral cells (which
form an FCC lattice, twelve neighbors each). Check cost lam_o, and a bond term -t Z_b that moves and pair-creates the two
failures it touches. With x_o = b_o + b_o^dag the quadratic part is
   H = sum_o (lam_o/4)(x_o^2 + p_o^2) - t sum_<oo'> x_o x_o'  ,
so the mode frequencies are w^2 = eig( D^1/2 K D^1/2 ), D = diag(lam/2), K = diag(lam/2) - t A. Uniform lam gives
w^2 = (lam/2)(lam/2 - t gamma_k): a Klein-Gordon field whose mass^2 = (lam/2)(lam/2-12t) vanishes at lam_c = 24t, speed
v = sqrt(48) t (lengths in half-cells). A cavity at lam_c inside walls lam_c + Dlt: lowest mode x = w R / v, to compare with
the scalar hard-wall values pi (sphere) and 3.926 (cuboctahedron, Section 8 of the Zeno paper).
Usage: python3 cavity3d.py sphere|cubo L R Dlt"""
import numpy as np, scipy.sparse as sp, itertools as it, sys
from scipy.sparse.linalg import eigsh
shape=sys.argv[1]; L=int(sys.argv[2]); R=float(sys.argv[3]); Dlt=float(sys.argv[4]); t=1.0; P=2*L
pts=np.array([p for p in it.product(range(P),repeat=3) if sum(p)%2==1]); N=len(pts)
idx={tuple(p):i for i,p in enumerate(pts)}
nb=[d for d in it.product((-1,0,1),repeat=3) if sorted(map(abs,d))==[0,1,1]]
rows=[];cols=[]
for i,p in enumerate(pts):
    for d in nb: rows.append(i); cols.append(idx[tuple((p+d)%P)])
A=sp.csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(N,N))
c=np.array([L+1,L,L]); X=pts-c
if shape=='sphere': inside=(X**2).sum(1)<R**2
else:
    a=R/np.sqrt(2); inside=(np.abs(X)<a).all(1)&(np.abs(X).sum(1)<2*a)
lam=np.where(inside,24*t,24*t+Dlt)
d=np.sqrt(lam/2); S=sp.diags(d)@(sp.diags(lam/2)-t*A)@sp.diags(d)
w2=eigsh(S,k=2,which='SA',tol=1e-10)[0]; w=np.sqrt(max(w2.min(),0)); v=np.sqrt(48)*t
print('%s L=%d R=%.1f Dlt=%g sites_in=%d  w=%.5f  x=wR/v=%.4f'%(shape,L,R,Dlt,inside.sum(),w,w*R/v),flush=True)
