#!/usr/bin/env python3
"""Proton magnetic moment and axial charge from the lowest cavity mode (same lattice Dirac Hamiltonian as dirac_cavity.py).
For a quark in the spin-up state of the j = 1/2 doublet:
   mu_0 = (1/2) <u| (r x alpha)_z |u>   (moment per unit charge, length units),   gA_0 = <u| Sigma_z |u>.
SU(6) with three quarks in one mode gives mu_p = mu_0 (in units e) and g_A = (5/3) gA_0. In nuclear magnetons,
mu_p/mu_N = 2 m_p c^2 mu_0 / (hbar c). The cavity size is fixed by the charge radius as in Eq. (9), center fixed by the lattice.
MIT sphere check: mu_0 = R (4w-3)/(12 w (w-1)), gA_0 = 1 - (2/3)(1 - ... ); for w = 2.0428 g_A = 1.09.
Usage: python3 moments.py sphere|cubo n R Mout"""
import numpy as np, scipy.sparse as sp, sys
from scipy.sparse.linalg import lobpcg, LinearOperator
shape=sys.argv[1]; n=int(sys.argv[2]); Rg=float(sys.argv[3]); Mout=float(sys.argv[4]); r=1.0
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); Z=np.zeros((2,2))
al=[np.block([[Z,s],[s,Z]]) for s in (s1,s2,s3)]; be=np.diag([1,1,-1,-1]).astype(complex)
Sz=np.block([[s3,Z],[Z,s3]])
c=(np.arange(n)-n/2+0.5); X,Y,Zc=np.meshgrid(c,c,c,indexing='ij')
if shape=='sphere': inside=X**2+Y**2+Zc**2<Rg**2
else:
    a=Rg/np.sqrt(2); inside=(np.abs(X)<a)&(np.abs(Y)<a)&(np.abs(Zc)<a)&(np.abs(X)+np.abs(Y)+np.abs(Zc)<2*a)
Mx=np.where(inside,0.0,Mout); N=n**3; I=sp.identity(N,format='csr')
def shift(d,s):
    idx=np.arange(N).reshape(n,n,n); j=np.roll(idx,-s,axis=d).ravel(); return sp.csr_matrix((np.ones(N),(np.arange(N),j)),shape=(N,N))
D=[];Lap=-6*I
for d in range(3):
    Sp,Sm=shift(d,1),shift(d,-1); D.append((Sp-Sm)/2); Lap=Lap+Sp+Sm
H=sp.kron(sp.diags(Mx.ravel()),be)+sp.kron(-0.5*r*Lap,be)
for d in range(3): H=H+sp.kron(-1j*D[d],al[d])
H=H.tocsr()
H2=LinearOperator(H.shape,matvec=lambda v: H@(H@v),dtype=complex)
rng=np.random.default_rng(0); X0=rng.random((H.shape[0],4))+0j
w,V=lobpcg(H2,X0,largest=False,tol=1e-9,maxiter=4000); E=np.sqrt(w.real.min())
U=[]
for i in range(V.shape[1]):
    v=V[:,i]; p=(v+H@v/E)/2
    for u in U: p=p-u*(u.conj()@p)
    if np.linalg.norm(p)>1e-3: U.append(p/np.linalg.norm(p))
    if len(U)==2: break
U=np.array(U).T   # N*4 x 2
def op_spin(M4): return sp.kron(sp.identity(N),sp.csr_matrix(M4))
OSz=op_spin(Sz)
xr=sp.diags(X.ravel()); yr=sp.diags(Y.ravel())
Omu=0.5*(sp.kron(xr,al[1])-sp.kron(yr,al[0]))
A=U.conj().T@(OSz@U); w2,v2=np.linalg.eigh(A); up=U@v2[:,1]   # spin-up state of the doublet
gA0=(up.conj()@(OSz@up)).real; mu0=(up.conj()@(Omu@up)).real
rho=np.sqrt(((np.abs(up.reshape(N,4))**2).sum(1)*(X.ravel()**2+Y.ravel()**2+Zc.ravel()**2)).sum())/Rg
hc=197.327; rp=0.84075; mp=938.272
L=rp/rho                       # cavity size in fm from the charge radius (lattice-fixed center)
mu_fm=mu0/Rg*L; mup=2*mp*mu_fm/hc
print('%s n=%d R=%g Mout=%g  E*R=%.4f  rho=%.4f  gA0=%.4f  g_A=%.4f  mu0/R=%.4f  L=%.3f fm  mu_p=%.3f mu_N'%(shape,n,Rg,Mout,E*Rg,rho,gA0,5/3*gA0,mu0/Rg,L,mup),flush=True)
if shape=='sphere':
    wv=2.0428; print('   MIT exact sphere: mu0/R=%.4f  g_A=1.09'%((4*wv-3)/(12*wv*(wv-1))))
