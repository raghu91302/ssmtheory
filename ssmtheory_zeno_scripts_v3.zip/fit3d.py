#!/usr/bin/env python3
"""Extrapolate the 3D cavity values of cavity3d.py. A lattice region of N sites (density 1/2 per half-cell^3) is given the
radius of the continuum shape with the same volume, R_eff; then x = w R_eff / v is fitted to x_inf R/(R + d)."""
import re, numpy as np
from scipy.optimize import curve_fit
v=np.sqrt(48); vol={'sphere':4*np.pi/3,'cubo':5*np.sqrt(2)/3}; ref={'sphere':np.pi,'cubo':3.926}
rows=[re.match(r'(\w+) L=\d+ R=([\d.]+) Dlt=400 sites_in=(\d+)\s+w=([\d.]+)',l) for l in open('c3d_all.log')]
for s in ('sphere','cubo'):
    R=[];X=[]
    for m in rows:
        if m and m.group(1)==s:
            Re=(2*int(m.group(3))/vol[s])**(1/3); R.append(Re); X.append(float(m.group(4))*Re/v)
    R=np.array(R);X=np.array(X); o=np.argsort(R); R,X=R[o],X[o]
    (xi,d),cov=curve_fit(lambda r,a,b:a*r/(r+b),R,X,p0=(3,0.5))
    print('%-6s R_eff=%s\n       x=%s\n       fit x_inf=%.3f +- %.3f (d=%.2f)   hard-wall scalar value %.3f'%(s,np.round(R,2),np.round(X,3),xi,np.sqrt(cov[0,0]),d,ref[s]))
