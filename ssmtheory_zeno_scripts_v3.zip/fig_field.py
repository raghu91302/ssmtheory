#!/usr/bin/env python3
"""Fig.: from the code to the field.
(a) One dimension, exact: lowest level of a region at the balance point inside walls of cost lam_c + K, as E1 L/(hbar v),
    against L, with the Zeno law (pi/2) L/(L + v/K) (lines) and the bag value pi/2.
(b) Three dimensions, Monte Carlo: mass of a failed check against t/lam on 256, 864 and 2048 cells, with the linear theory
    sqrt(1 - 24 t/lam) and the confinement transition of the FCC code mapped to this model (2t/lam = h_c/lam ~ 0.10)."""
import re, numpy as np, collections, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.linalg import svdvals
def levels(Jin,Jout,h,L,pad=400):
    J=np.full(L+2*pad,Jout,float); J[pad:pad+L]=Jin; N=len(J)
    M=np.diag(np.full(N,h))+np.diag(J[:-1],1); M[N-1,0]=J[-1]; return np.sort(2*svdvals(M))[0]
fig,ax=plt.subplots(1,2,figsize=(9.5,3.6)); h=1.0; v=2*h
Ls=np.array([25,50,100,200,400])
for D,c in zip((0.5,2,8),('C0','C1','C2')):
    K=2*D; y=[levels(h,h+D,h,L)*L/v for L in Ls]
    ax[0].plot(Ls,y,'o',color=c,ms=4,label=r'$K=%g\,t$'%K); LL=np.linspace(20,420,100); ax[0].plot(LL,np.pi/2*LL/(LL+v/K),'-',color=c,lw=0.8)
ax[0].axhline(np.pi/2,color='k',ls=':',lw=0.8); ax[0].text(22,1.563,r'$\pi/2$',fontsize=8)
ax[0].set_xscale('log'); ax[0].set_xticks([25,50,100,200,400]); ax[0].set_xticklabels(['25','50','100','200','400']); ax[0].minorticks_off(); ax[0].set_xlabel('region size $L$ (sites)'); ax[0].set_ylabel(r'$E_1L/\hbar v$')
ax[0].set_title('(a) one dimension, exact',fontsize=9); ax[0].legend(fontsize=7,loc='lower right')
d=collections.defaultdict(list)
for f in ('gap.log','gap_L8_all.log'):
    try:
        for l in open(f):
            m=re.search(r'L=(\d) .*t/lam=([\d.]+) .*gap=(-?[\d.]+)',l)
            if m: d[(int(m.group(1)),float(m.group(2)))].append(abs(float(m.group(3))))
    except FileNotFoundError: pass
for L,mk,c,n in ((4,'s','C0',256),(6,'o','C1',864),(8,'^','C3',2048)):
    ts=sorted(t for (LL,t) in d if LL==L and t<=0.045)
    g=[np.mean(d[(L,t)]) for t in ts]; e=[np.std(d[(L,t)])/np.sqrt(len(d[(L,t)])) for t in ts]
    ax[1].errorbar(ts,g,yerr=e,fmt=mk,color=c,ms=4,capsize=2,mfc='none' if L!=8 else c,label='%d cells'%n)
tt=np.linspace(0,1/24,100); ax[1].plot(tt,np.sqrt(1-24*tt),'k--',lw=0.8,label='linear theory')
T8=np.array([0.03,0.035,0.04,0.042,0.044]); G8=np.array([np.mean(d[(8,t)]) for t in T8]); A,b=np.polyfit(T8,G8**2,1); tc=-b/A
tt2=np.linspace(0,tc,200); ax[1].plot(tt2,np.sqrt(np.clip(A*tt2+b,0,None)),':',color='C3',lw=1,label=r'$m^2\propto t_c-t$ (2048 cells)')
ax[1].axvspan(0.045,0.055,color='gray',alpha=0.18,lw=0); ax[1].text(0.0458,0.80,'confinement\ntransition\n(Fig. 4),\n$h/2\\lambda$',fontsize=7)
ax[1].set_xlabel(r'$t/\lambda$'); ax[1].set_ylabel(r'mass of a failed check ($\lambda$)'); ax[1].set_xlim(0,0.056); ax[1].set_ylim(0,1.05)
ax[1].set_title('(b) FCC code, quantum Monte Carlo',fontsize=9); ax[1].legend(fontsize=7,loc='lower left')
plt.tight_layout(); plt.savefig('fig_field.pdf'); print('ok')
