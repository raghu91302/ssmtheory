# electroweak_structure_scripts

Scripts for R. Kulkarni, "The electroweak structure of the E6 in the
Selection–Stitch Model: Chirality, the weak mixing angle, and the charge the
photon sees" (2026).

## Run

    python3 verify_electroweak_structure.py

Requires Python 3 and NumPy (tested with Python 3.13 and NumPy 2.5). It runs
in a few seconds and prints one PASS/FAIL line per check (62 in all), then a
verdict. It reads and writes no files.

## What it checks

Labels in the output refer to the theorems, propositions and sections of the
paper.

1. The 72-root E6 of the orientation unfold, as built in Kulkarni,
   Symmetry 18, 1813 (2026), https://doi.org/10.3390/sym18111813, with the
   flip F and the extended inversion X as automorphisms; the simple roots,
   color, su(3)_L, su(3)_R, the charge Q and the 27 of that paper.
2. Theorem 1: twelve roots commute with color; exactly four raise Q by one.
3. Theorem 2 and Proposition 1: the hypercharges of the 27 under the left
   placement (Table 2) and the four anomaly sums, in exact arithmetic.
4. Theorem 3, the worked examples and Proposition 2: F swaps the placements,
   maps the 27 onto the 27-bar, and shifts (T3, Y) on a hop.
5. Theorem 4 and Section 5.1: reversing the growth direction acts on the roots
   as F; the two stacking variants ABC and ACB differ by a proper rotation.
6. Theorems 5 and 6: Tr Y^2 / Tr T3^2 = 5/3; sin^2 theta_W = 3/(4(1+r^2)).
7. Theorems 7 and 8: the breaking chain to SU(3)_C x U(1)_Q.
8. Proposition 3: the charges a hop conserves; Q is the only unbroken one
   outside color.
9. Section 9: one-loop running with PDG 2024 inputs, matching scale near
   1.0e13 GeV.

## Figures

    python3 make_figures.py

Draws Figures 1, 2, 4, 5 and 7 of the paper (fig_fcc, fig_voids, fig_roots,
fig_weights, fig_running) as vector PDFs in ./figs. It runs
verify_electroweak_structure.py first and plots only the numbers that script
computes. Requires NumPy, Matplotlib and a LaTeX installation with cm-super.
Figures 3 and 6 are TikZ diagrams in the LaTeX source.
