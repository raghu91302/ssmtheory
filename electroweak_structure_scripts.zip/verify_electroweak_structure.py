#!/usr/bin/env python3
"""Checks for 'The electroweak structure of the E6 in the Selection-Stitch
Model: Chirality, the weak mixing angle, and the charge the photon sees'
(R. Kulkarni, 2026).

Builds the 72-root E6 of the orientation unfold exactly as in Kulkarni,
Symmetry 18, 1813 (2026), and checks every computed claim of the paper.
Labels refer to the theorems, propositions and sections of the paper.
Run: python3 verify_electroweak_structure.py   (Python 3, NumPy only; a few seconds)
"""
from fractions import Fraction
import numpy as np, itertools
from collections import Counter

ok = True
def check(name, cond):
    global ok
    ok &= bool(cond)
    print(("PASS  " if cond else "FAIL  ") + name)

# ---------------------------------------------------------------- E6 roots
longr = []
for i, j in itertools.combinations(range(4), 2):
    for si, sj in [(1, 1), (1, -1), (-1, 1), (-1, -1)]:
        v = np.zeros(4); v[i] = si; v[j] = sj; longr.append(v)
shortr = [s*np.eye(4)[i] for i in range(4) for s in (1, -1)] + \
         [np.array(s)/2. for s in itertools.product([1, -1], repeat=4)]
def cls(w):                       # glue class of a short weight: 0=[v], 1=[s], 2=[c]
    w = np.array(w)
    if abs(abs(w).max()-1) < 1e-9: return 0
    return 1 if np.prod(np.sign(w)) > 0 else 2
v3 = [np.array([np.cos(2*np.pi*k/3), np.sin(2*np.pi*k/3)]) for k in range(3)]
def unfold(orient_sign=1):
    R = [np.concatenate([l, [0, 0]]) for l in longr]
    for s in shortr:
        for eps in (1, -1):
            R.append(np.concatenate([s, orient_sign*eps*v3[cls(s)]]))
    return np.array(R)
R = unfold()
key = lambda x: tuple(np.round(x, 9))
Rset = {key(r) for r in R}
refl = lambda a, x: x - 2*(x@a)/(a@a)*a
F = np.diag([1, 1, 1, 1, -1, -1.])                 # orientation flip
X = np.diag([-1, -1, -1, 1, 1, -1.])               # extended inversion
check("E6: 72 roots of squared length 2, closed under reflection, rank 6",
      len(Rset) == 72 and all(abs(r@r-2) < 1e-9 for r in R) and
      all(key(refl(a, b)) in Rset for a in R for b in R) and np.linalg.matrix_rank(R) == 6)
check("F and X are automorphisms of the 72", all(key(F@r) in Rset and key(X@r) in Rset for r in R))

f = np.array([1.001, 0.618, 0.414, 0.302, 0.171, 0.093])
pos = [r for r in R if f@r > 0]; posset = {key(p) for p in pos}
simple = np.array([a for a in pos if not any(key(np.array(a)-b) in posset for b in pos if not np.allclose(a, b))])
C = np.array([[round(2*float(a@b)/float(b@b)) for b in simple] for a in simple])
theta = pos[int(np.argmax([f@p for p in pos]))]
marks = np.round(np.linalg.lstsq(simple.T, theta, rcond=None)[0]).astype(int)
check(f"simple roots as printed in the E6 paper; marks {tuple(int(m) for m in marks)}; det C = {round(np.linalg.det(C))}",
      round(np.linalg.det(C)) == 3 and tuple(marks) == (2, 3, 2, 2, 1, 1))
a = simple                                          # a[0..5] = alpha_1..alpha_6
groot = lambda p: [p[0], p[1], p[0]+p[1], -p[0], -p[1], -(p[0]+p[1])]
colr = [r for r in R if np.allclose(r[4:], 0) and any(np.allclose(r, x) for x in
        [np.array([0,1,-1,0,0,0.]), np.array([1,1,0,0,0,0.]), np.array([1,0,1,0,0,0.])]+
        [-np.array([0,1,-1,0,0,0.]), -np.array([1,1,0,0,0,0.]), -np.array([1,0,1,0,0,0.])])]
L = groot([a[3], a[5]]); Rf = groot([a[2], a[4]])
check("color = flip-fixed A2 with roots +-(e2-e3), +-(e1+e2), +-(e1+e3); L = <alpha_4, alpha_6>, R = <alpha_3, alpha_5>",
      len(colr) == 6 and all(key(F@x) == key(x) for x in colr) and
      {key(F@x) for x in L} == {key(x) for x in Rf} and
      all(abs(x@y) < 1e-9 for x in L for y in Rf+colr) and all(abs(x@y) < 1e-9 for x in Rf for y in colr))

Q = 2/3*np.array([-1, 1, 1, 0, 0, 0.])
check("Q = (2/3)(-e1+e2+e3) commutes with color, is X-odd and F-even (Theorem 7 of the E6 paper)",
      all(abs(Q@c) < 1e-9 for c in colr) and np.allclose(X@Q, -Q) and np.allclose(F@Q, Q))

# ---------------------------------------------------------------- the 27
CM = np.array([[2*float(a[i]@a[j])/float(a[j]@a[j]) for i in range(6)] for j in range(6)])
W = None
for e in range(6):
    om = np.linalg.solve(CM.T, np.eye(6)[e])@a
    orb = {key(om)}; fr = [om]
    while fr:
        new = []
        for x in fr:
            for s in a:
                y = x - round(2*float(x@s)/float(s@s))*s
                if key(y) not in orb: orb.add(key(y)); new.append(y)
        fr = new
    if len(orb) == 27:
        cand = [np.array(w) for w in orb]
        if key(np.array([-1, 0, 0, 0, 0, np.sqrt(3)/3])) in orb:      # first row of Table A3 of the E6 paper
            W = cand; break
spec = sorted(np.round([Q@w for w in W], 6)) if W else []
check("the 27 of Table A3 of the E6 paper, on which Q has the Standard Model trinification spectrum",
      W is not None and spec == sorted(np.round([2/3]*3+[-1/3]*6+[1/3]*6+[-2/3]*3+[1]*2+[0]*5+[-1]*2, 6)))
w3 = {(1, 0), (-1, 1), (0, -1)}; w3b = {(-x, -y) for x, y in w3}
lab = lambda mu, p: tuple(round(2*float(mu@s)/float(s@s)) for s in p)
rt = lambda l: '3' if l in w3 else ('3b' if l in w3b else ('1' if l == (0, 0) else '?'))
block = lambda mu: (rt(lab(mu, [np.array([0,1,-1,0,0,0.]), np.array([-1,-1,0,0,0,0.])])),
                    rt(lab(mu, [a[3], a[5]])), rt(lab(mu, [a[2], a[4]])))    # (color, L, R)
blocks = Counter(block(mu) for mu in W)
check(f"trinification blocks of the 27: {dict(blocks)}", sorted(blocks.values()) == [9, 9, 9])

# ---------------------------------------------------------------- Theorem 1: classification
orth = [r for r in R if all(abs(r@c) < 1e-9 for c in colr)]
raise_ = [r for r in orth if abs(Q@r-1) < 1e-9]
inL = lambda r: any(np.allclose(r, x) for x in L)
check(f"Thm 1: {len(orth)} roots commute with color (L and R); exactly {len(raise_)} raise Q by one unit, two in L and two in R",
      len(orth) == 12 and len(raise_) == 4 and sum(inL(r) for r in raise_) == 2)
def Y_of(beta): return Q - beta/2
check("Thm 1: for each of the four, Y = Q - T3 commutes with color and with its su(2)",
      all(all(abs(Y_of(b)@c) < 1e-9 for c in colr) and abs(Y_of(b)@b) < 1e-9 for b in raise_))
neutral = [r for r in orth if abs(Q@r) < 1e-9]
check("Thm 1: for the neutral roots (Q.beta = 0), Q - T3 fails to commute with the su(2): no hypercharge",
      len(neutral) == 4 and all(abs(Y_of(b)@b) > 0.5 for b in neutral))
bL = [r for r in raise_ if inL(r)]; bR = [r for r in raise_ if not inL(r)]
s = a[3]+a[5]
check("Thm 1: the two choices inside L are related by the Weyl reflection in alpha_4+alpha_6, which fixes Q ; likewise in R",
      abs(Q@s) < 1e-9 and any(np.allclose(refl(s, bL[0]), x) for x in bL[1:]) and
      abs(Q@(a[2]+a[4])) < 1e-9 and any(np.allclose(refl(a[2]+a[4], bR[0]), x) for x in bR[1:]))

# what the Weyl reflection in alpha_4+alpha_6 moves (text after Theorem 1)
moved = [(round(Q@mu, 3), round(mu@a[5]/2, 3), round(Y_of(a[5])@mu, 3), block(mu)[0] == '1')
         for mu in W if key(refl(s, mu)) != key(mu)]
mc = Counter(moved)
check("Thm 1 remark: the reflection moves 6 colored states of charge -1/3 (d <-> D) and 6 color-singlet states: the 2 neutral singlets <-> the upper (neutral) members of the 2 Y = -1/2 doublets, and e^c <-> the charged member of the Y = +1/2 doublet; the hypercharge values are unchanged",
      sum(v for k, v in mc.items() if not k[3]) == 6 and all(k[0] == -0.333 for k in mc if not k[3]) and
      mc[(0.0, 0.0, 0.0, True)] == 2 and mc[(0.0, 0.5, -0.5, True)] == 2 and
      mc[(1.0, 0.0, 1.0, True)] == 1 and mc[(1.0, 0.5, 0.5, True)] == 1 and
      sorted(round(Y_of(-a[3])@mu, 4) for mu in W) == sorted(round(Y_of(a[5])@mu, 4) for mu in W))

# ---------------------------------------------------------------- Theorem 2: the spectrum of Y_L
beta = a[5]                                       # alpha_6, an L root with Q.beta = 1
YL = Y_of(beta)
T3 = lambda mu: mu@beta/2
rows = Counter((block(mu), round(Q@mu, 4), round(T3(mu), 4), round(YL@mu, 4)) for mu in W)
isq = lambda b: b[0] != '1' and b[1] != '1'      # colored and L-charged: the quark block
isa = lambda b: b[0] != '1' and b[2] != '1'      # colored and R-charged: the antiquark block
quark = [(k[1], k[2], k[3]) for k in rows for _ in range(rows[k]) if isq(k[0])]
anti = [(k[1], k[2], k[3]) for k in rows for _ in range(rows[k]) if isa(k[0])]
lept = [(k[1], k[2], k[3]) for k in rows for _ in range(rows[k]) if k[0][0] == '1']
r = lambda x: round(x, 4)
check("Thm 2 quark block: per color one weak doublet (Q = 2/3, -1/3; Y = 1/6) and one singlet (Q = -1/3, Y = -1/3)",
      Counter(quark) == Counter({(r(2/3), .5, r(1/6)): 3, (r(-1/3), -.5, r(1/6)): 3, (r(-1/3), 0, r(-1/3)): 3}))
check("Thm 2 antiquark block: weak singlets with Y = Q: -2/3 (x3) and +1/3 (x6)",
      Counter(anti) == Counter({(r(-2/3), 0, r(-2/3)): 3, (r(1/3), 0, r(1/3)): 6}))
check("Thm 2 color-singlet block: two doublets with Y = -1/2, one with Y = +1/2, and singlets with Y = +1, 0, 0",
      Counter(lept) == Counter({(0., .5, -.5): 2, (-1., -.5, -.5): 2, (1., .5, .5): 1, (0., -.5, .5): 1,
                                (1., 0., 1.): 1, (0., 0., 0.): 2}))
check("Thm 2: Q = T3 + Y_L on every state; six doublets and fifteen singlets in the 27",
      all(abs(Q@mu - T3(mu) - YL@mu) < 1e-12 for mu in W) and
      sum(1 for mu in W if abs(T3(mu)) > 0.1) == 12 and sum(1 for mu in W if abs(T3(mu)) < 0.1) == 15)
check("Thm 2: the charged weak bosons carry Q = +-1 and the neutral one Q = 0", abs(Q@beta-1) < 1e-12)
from fractions import Fraction
def exact(x, den=6):                                            # every charge here is a multiple of 1/6
    n = round(den*x); assert abs(den*x - n) < 1e-6; return Fraction(n, den)
Yx = [exact(YL@mu) for mu in W]; T3x = [exact(T3(mu)) for mu in W]
col = [block(mu)[0] != '1' for mu in W]
TrY = sum(Yx); TrY3 = sum(y**3 for y in Yx)
A3 = sum(y for y, c in zip(Yx, col) if c)/2                     # SU(3)^2 Y  (index 1/2 per triplet)
A2 = sum(t**2*y for t, y in zip(T3x, Yx))                       # SU(2)^2 Y
check(f"Prop. 1 (anomalies of one left-handed 27, exact rational arithmetic): Tr Y = {TrY}, Tr Y^3 = {TrY3}, SU(3)^2 Y = {A3}, SU(2)^2 Y = {A2}",
      TrY == TrY3 == A3 == A2 == 0)

# ---------------------------------------------------------------- Theorem 3: the flip exchanges the two
YR = Y_of(F@beta)
check("Thm 3: F maps the L choice to an R choice (F alpha_6 raises Q by one) and Y_L to Y_R = Q - T3R",
      any(np.allclose(F@beta, x) for x in bR) and np.allclose(F@YL, YR))
W27 = {key(w) for w in W}
check("Thm 3: F maps the weights W of the 27 onto -W, the weights of the 27-bar, and no image lies in W",
      {key(F@w) for w in W} == {key(-w) for w in W} and not ({key(F@w) for w in W} & W27))
r3 = np.sqrt(3)
ex = {'u_L': (np.array([-1, 0, 0, 0, 0, r3/3]), np.array([1, 0, 0, 0, 0, r3/3]), (2/3, .5, 1/6), (-2/3, 0, -2/3), (2/3, 2/3)),
      'e_L': (np.array([.5, -.5, -.5, .5, -.5, -r3/6]), np.array([-.5, .5, .5, -.5, -.5, -r3/6]), (-1, -.5, -.5), (1, 0, 1), (-1, -1))}
def qty(m): return (Q@m, m@beta/2, YL@m)
okex = True
for name, (mu, nu, qmu, qnu, qF) in ex.items():
    okex &= key(mu) in W27 and key(nu) in W27 and np.allclose(F@mu, -nu)
    okex &= np.allclose(qty(mu), qmu) and np.allclose(qty(nu), qnu) and np.allclose((Q@(F@mu), YL@(F@mu)), qF)
    okex &= block(mu)[0] != '1' if name == 'u_L' else block(mu)[0] == '1'
    okex &= lab(F@mu, [np.array([0,1,-1,0,0,0.]), np.array([-1,-1,0,0,0,0.])]) == lab(mu, [np.array([0,1,-1,0,0,0.]), np.array([-1,-1,0,0,0,0.])])
check("Thm 3 examples: F u_L = -(weight of u^c), with Q = 2/3, Y = 2/3 and the color of u_L (u_R); F e_L = -(weight of e^c), with Q = -1, Y = -1 (e_R)", okex)
check("Thm 3 examples: all charges of F mu are evaluated with the fixed Q, T3L, Y_L; since F is an orthogonal involution, Y_L(F mu) = Y_R(mu) on every weight",
      np.allclose(F@F, np.eye(6)) and np.allclose(F.T, F) and all(abs(YL@(F@mu) - YR@mu) < 1e-9 for mu in W))
check("Thm 3: under the right placement (T3R) the quark block carries no weak doublet and the antiquark block does (the mirror assignment)",
      all(abs(mu@(F@beta)) < 1e-9 for mu in W if isq(block(mu))) and
      sum(1 for mu in W if isa(block(mu)) and abs(mu@(F@beta)) > 0.1) == 6)
check("Thm 3: none of the four hypercharges Q - beta/2 of Thm 1 is F-invariant (F maps the L pair onto the R pair)",
      all(not np.allclose(F@Y_of(b), Y_of(b)) for b in raise_) and
      {key(F@Y_of(b)) for b in bL} == {key(Y_of(b)) for b in bR})
FX = F@X
YRp = [Y_of(b) for b in bR]
check("Sec. 5: spatial inversion acts as FX; FX maps Y_L to minus a right-placement hypercharge, so it cannot select Y_L either",
      any(np.allclose(FX@YL, -y) for y in YRp))
# hop = F on the worldline (E6 paper, Sec. 8.3): Q and color are kept; Y and T3 shift oppositely
dY = [exact(YL@(F@mu)) - exact(YL@mu) for mu in W]
dT = [exact((F@mu)@beta/2) - exact(mu@beta/2) for mu in W]
check(f"Prop. 2 (hop): F keeps Q and color on all 27 states; dT3 = -dY; dY = +-1/2 on {sum(abs(d)==Fraction(1,2) for d in dY)}, 0 on {sum(d==0 for d in dY)}, +-1 on {sum(abs(d)==1 for d in dY)} states",
      all(abs(Q@(F@mu)-Q@mu) < 1e-9 and block(mu)[0] == rt(lab(F@mu, [np.array([0,1,-1,0,0,0.]), np.array([-1,-1,0,0,0,0.])])) for mu in W) and
      all(a_ == -b_ for a_, b_ in zip(dY, dT)) and
      (sum(abs(d)==Fraction(1,2) for d in dY), sum(d==0 for d in dY), sum(abs(d)==1 for d in dY)) == (16, 9, 2))
pairs = Counter((round(Q@mu, 3), exact(YL@mu), exact(YL@(F@mu))) for mu in W if isq(block(mu)))
lep = Counter((exact(YL@mu), exact(YL@(F@mu))) for mu in W if block(mu)[0] == '1' and abs(Q@mu+1) < 1e-9)
check("Prop. 2 (hop): the quark doublet goes to Y = 2/3 (u) and -1/3 (d), the right-handed values; one charge -1 lepton goes from Y = -1/2 to -1 (e)",
      pairs[(0.667, Fraction(1,6), Fraction(2,3))] == 3 and pairs[(-0.333, Fraction(1,6), Fraction(-1,3))] == 3 and
      lep[(Fraction(-1,2), Fraction(-1))] == 1)

dYof = lambda mu: exact(YL@(F@mu)) - exact(YL@mu)
dbl = []
for mu in W:
    if block(mu)[0] == '1' and abs(T3(mu)-.5) < 1e-9 and abs(YL@mu+.5) < 1e-9:
        lo = mu - beta
        assert key(lo) in W27
        dbl.append(sorted([abs(dYof(mu)), abs(dYof(lo))]))
check(f"Prop. 2 (hop): of the two Y = -1/2 doublets, exactly one has both members shifting by 1/2 (the lepton doublet); the other shifts by 0 and 1",
      sorted(map(tuple, dbl)) == [(0, 1), (Fraction(1,2), Fraction(1,2))])

# ---------------------------------------------------------------- Theorem 4: the growth direction is F-odd
nodes = {p for p in itertools.product(range(-4, 5), repeat=3) if sum(p) % 2 == 0}
nb = [np.array(d) for d in [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]]
tets = set()
for p in [q for q in nodes if max(map(abs, q)) <= 2]:
    P = np.array(p); ns = [tuple(P+d) for d in nb if tuple(P+d) in nodes]
    for x, y, z in itertools.combinations(ns, 3):
        if all(np.dot(np.subtract(u, v), np.subtract(u, v)) == 2 for u, v in ((x, y), (x, z), (y, z))):
            tets.add(frozenset((p, x, y, z)))
def orient(T, U):   # 'up' if the apex points along the growth direction U
    h = sorted(float(np.dot(v, U)) for v in T)
    return 'up' if abs(h[0]-h[1]) < 1e-9 else 'down'    # three vertices below, apex above: up
U = np.array([1, 1, 1.])
up = Counter(orient(T, U) for T in tets)
check(f"Thm 4: with growth along [111], the tetrahedral voids split into up and down: {dict(up)}",
      up['up'] == up['down'] and up['up'] > 0)
check("Thm 4: reversing the growth direction relabels every void, up <-> down",
      all(orient(T, U) != orient(T, -U) for T in tets))
def relabel(r):     # eps -> -eps on a lifted root (s, eps v); bond roots unchanged
    return r if np.allclose(r[4:], 0) else np.concatenate([r[:4], -r[4:]])
check("Thm 4: relabeling every orientation (eps -> -eps) acts on each of the 72 roots exactly as F (immediate from the construction)",
      all(np.allclose(relabel(r), F@r) for r in R) and {key(relabel(r)) for r in R} == Rset)
check("Thm 4: so reversing the growth direction (relabel on every root) maps Y_L to Y_R",
      np.allclose(sum(np.outer(relabel(r), r) for r in R)/24 @ YL, YR))

# ---------------------------------------------------------------- rank count
check("rank: color (2) + T3 + Y = 4 of the 6 Cartan directions; two further U(1) directions remain",
      np.linalg.matrix_rank(np.array([[0,1,-1,0,0,0.],[1,1,0,0,0,0.], beta, YL])) == 4)


# ================================================================ electroweak structure
beta = a[5]
T3 = lambda m: m @ beta / 2



def exact(x, den=36):
    n = round(den * x); assert abs(den * x - n) < 1e-6; return Fraction(n, den)

def proj(v, basis):
    B = np.array(basis).T
    return B @ np.linalg.lstsq(B, v, rcond=None)[0]

# ---------------------------------------------------------------- Section 5.1: the two stacking variants
nax = np.array([1., 1., 1.]) / np.sqrt(3)
Rot = 2 * np.outer(nax, nax) - np.eye(3)                       # rotation by 180 degrees about the [111] growth axis
fccpts = np.array([p for p in itertools.product(range(-4, 5), repeat=3) if sum(p) % 2 == 0], float)
def layer(P, k):
    L = P[np.isclose(P @ nax * np.sqrt(3), 2 * k)]
    return {tuple(np.round(x - (x @ nax) * nax, 4)) for x in L}
rotp = fccpts @ Rot.T
check("Sec. 5.1: the 180-degree rotation about the growth axis is proper (det = +1), fixes sheet A, and moves sheet B onto the sites of sheet C, so it maps ABC onto ACB",
      abs(np.linalg.det(Rot) - 1) < 1e-12 and layer(rotp, 0) == layer(fccpts, 0)
      and not (layer(rotp, 1) & layer(fccpts, 1)) and layer(rotp, 1) <= layer(fccpts, 2) | layer(fccpts, -1))

# ---------------------------------------------------------------- Theorem 5: normalization
yL = proj(YL, [a[3], a[5]]); yR = proj(YL, [a[2], a[4]])
check(f"Thm 5: Y_L lies in the Cartan of su(3)_L + su(3)_R: Y_L = y_L + y_R, with |y_L|^2 = {exact(yL@yL)}, |y_R|^2 = {exact(yR@yR)}, |Y_L|^2 = {exact(YL@YL)}, |T3|^2 = {exact(beta@beta/4)}",
      np.allclose(YL, yL + yR) and exact(yL@yL) == Fraction(1, 6) and exact(yR@yR) == Fraction(2, 3)
      and exact(YL@YL) == Fraction(5, 6) and exact(beta@beta/4) == Fraction(1, 2)
      and all(abs(YL@c) < 1e-9 for c in colr))
TrY2 = sum(exact(YL@m)**2 for m in W); TrT2 = sum(exact(T3(m))**2 for m in W)
check(f"Thm 5: on the 27, Tr Y^2 = {TrY2}, Tr T3^2 = {TrT2}, ratio {TrY2/TrT2}; equal to |Y_L|^2/|T3|^2 = {exact(YL@YL)/exact(beta@beta/4)}",
      TrY2 == 5 and TrT2 == 3 and TrY2 / TrT2 == Fraction(5, 3) == exact(YL@YL) / exact(beta@beta/4))
check("Thm 5: the same ratio holds for every hypercharge of Theorem 1 (all four placements)",
      all(abs(((Q - b/2)@(Q - b/2)) / (b@b/4) - 5/3) < 1e-9 for b in R
          if all(abs(b@c) < 1e-9 for c in colr) and abs(Q@b - 1) < 1e-9))

# ---------------------------------------------------------------- Theorem 6: the mixing angle
cL, cR = 2*(yL@yL), 2*(yR@yR)              # coefficients in 1/g_Y^2 = cL/gL^2 + cR/gR^2
check(f"Thm 6: 1/g_Y^2 = {exact(cL)}/g_L^2 + {exact(cR)}/g_R^2 (color does not enter)",
      exact(cL) == Fraction(1, 3) and exact(cR) == Fraction(4, 3))
s2 = lambda r: 1 / (1 + cL + cR * r**2)    # r = g_L/g_R
check(f"Thm 6: with g_L = g_R, sin^2 theta_W = {exact(s2(1.0), 8)} at the matching scale",
      exact(s2(1.0), 8) == Fraction(3, 8))
check(f"Thm 6: sin^2 theta_W = 3/(4(1+r^2)); r = 1.2 gives {s2(1.2):.3f}, r = 0.8 gives {s2(0.8):.3f}",
      all(abs(s2(r) - 3/(4*(1 + r*r))) < 1e-12 for r in np.linspace(0.5, 2, 16)))
check("Thm 6: F maps the coefficients of g_L and g_R into each other's places (F y_L lies in su(3)_R, F y_R in su(3)_L)",
      np.allclose(proj(F@yL, [a[2], a[4]]), F@yL) and np.allclose(proj(F@yR, [a[3], a[5]]), F@yR))

# ---------------------------------------------------------------- Theorem 7: the breaking chain
G3 = list(colr) + list(L) + list(Rf)       # roots of su(3)_C + su(3)_L + su(3)_R
def unbroken(ws):
    roots = [x for x in G3 if all(abs(x@w) < 1e-9 for w in ws)]
    return roots, 6 - np.linalg.matrix_rank(np.array(ws))
def count(roots, S): return sum(any(np.allclose(x, y) for y in roots) for x in S)
S = [m for m in W if block(m)[0] == '1' and abs(T3(m)) < 1e-9 and abs(YL@m) < 1e-9]
inv = [m for m in W if all(abs(m@c) < 1e-9 for c in colr) and abs(m@beta) < 1e-9 and abs(YL@m) < 1e-9]
check(f"Thm 7: exactly {len(inv)} weights of the 27 are invariant under SU(3)_C x SU(2)_L x U(1)_Y: the two neutral singlets",
      len(inv) == 2 and len(S) == 2 and {key(m) for m in inv} == {key(m) for m in S})
res = []
for s in S:
    r, rk = unbroken([s]); keptR = [x for x in Rf if any(np.allclose(x, y) for y in r)]
    res.append((count(r, colr), count(r, L), count(r, Rf), rk, keptR))
check("Thm 7: one singlet alone leaves SU(3)_C x SU(2)_L x SU(2)' x U(1) (6 + 2 + 2 roots, rank 5); the two singlets keep different SU(2)', generated by alpha_3 and by alpha_5",
      all(x[:4] == (6, 2, 2, 5) for x in res) and
      sorted([any(np.allclose(k, a[2]) or np.allclose(k, -a[2]) for k in x[4]) for x in res]) == [False, True] and
      sorted([any(np.allclose(k, a[4]) or np.allclose(k, -a[4]) for k in x[4]) for x in res]) == [False, True])
refl = lambda u, x: x - 2*(x@u)/(u@u)*u
s35 = a[2] + a[4]
nuL = [m for m in W if block(m)[0] == '1' and abs(Q@m) < 1e-9 and abs(T3(m) - .5) < 1e-9 and abs(YL@m + .5) < 1e-9 and abs(YL@(F@m)) < 1e-9][0]
eL = nuL - beta
S1 = [x for x in S if abs(x@a[2]) < 1e-9][0]; S2 = [x for x in S if abs(x@a[4]) < 1e-9][0]
check("Thm 7 remark: the Weyl reflection in alpha_3+alpha_5 fixes Q and Y_L and swaps S_1 and S_2, so the two left-right stages differ only by a relabeling",
      abs(Q@s35) < 1e-9 and abs(YL@s35) < 1e-9 and np.allclose(refl(s35, S1), S2))
check("Thm 7 remark: the lepton doublet (fixed by the hop) is a singlet of SU(2)' = <alpha_5> (the S_2 stage) and not of SU(2)' = <alpha_3> (the S_1 stage)",
      abs(nuL@a[4]) < 1e-9 and abs(eL@a[4]) < 1e-9 and abs(nuL@a[2]) > 0.5 and abs(eL@a[2]) > 0.5)
d21 = S2 - S1
Rset = {key(r) for r in R}
check("Thm 7 caveat: S_2 - S_1 = alpha_3 + alpha_5 is a root of su(3)_R that commutes with SU(3)_C x SU(2)_L x U(1)_Y, so in one copy of the 27 the two singlet values rotate into one; the Standard Model needs two copies",
      np.allclose(d21, a[2] + a[4]) and key(d21) in Rset and all(abs(d21@c) < 1e-9 for c in colr)
      and abs(d21@beta) < 1e-9 and abs(d21@YL) < 1e-9 and key(d21 + beta) not in Rset and key(d21 - beta) not in Rset)
check("Sec. 6: spatial inversion FX (the symmetry of the static crystal) also swaps su(3)_L and su(3)_R",
      {key(F@X@x) for x in L} == {key(x) for x in Rf})
r2, rk2 = unbroken(S)
M = np.array(S); null = np.linalg.svd(M)[2][np.linalg.matrix_rank(M):]
inspan = lambda v: np.allclose(null.T @ (null @ v), v)
check("Thm 7: both singlets leave exactly SU(3)_C x SU(2)_L x U(1)_Y (6 + 2 roots, rank 4, unbroken Cartan spanned by color, T3 and Y_L)",
      (count(r2, colr), count(r2, L), count(r2, Rf), rk2) == (6, 2, 0, 4) and
      any(np.allclose(beta, x) for x in r2) and inspan(YL) and inspan(beta) and
      all(inspan(np.array(c)) for c in ([0,1,-1,0,0,0.], [1,1,0,0,0,0.])))
check("Thm 7: the two broken Cartan directions are the two singlet weights, so the singlets remove exactly the two extra U(1) directions of Sec. 5",
      np.linalg.matrix_rank(np.array([[0,1,-1,0,0,0.], [1,1,0,0,0,0.], beta, YL] + S)) == 6)

# ---------------------------------------------------------------- Theorem 8: electroweak breaking
D = [m for m in W if block(m)[0] == '1' and abs(Q@m) < 1e-9 and abs(abs(T3(m)) - .5) < 1e-9]
lep = [m for m in D if abs(YL@m + .5) < 1e-9 and abs(YL@(F@m)) < 1e-9]     # lepton doublet: both members shift by 1/2 under F
out = []
for d in D:
    r, rk = unbroken(S + [d]); Md = np.array(S + [d]); nd = np.linalg.svd(Md)[2][np.linalg.matrix_rank(Md):]
    out.append((exact(YL@d, 6), exact(T3(d), 6), count(r, colr), len(r), rk, np.allclose(nd.T @ (nd @ Q), Q)))
check(f"Thm 8: the 27 has {len(D)} neutral doublet members, with (Y, T3) = (+1/2, -1/2) once and (-1/2, +1/2) twice",
      sorted((o[0], o[1]) for o in out) == sorted([(Fraction(1, 2), Fraction(-1, 2))] + [(Fraction(-1, 2), Fraction(1, 2))]*2))
check("Thm 8: adding any one of them to the singlets leaves exactly SU(3)_C x U(1)_Q (6 roots, rank 3, Q unbroken)",
      all(o[2:] == (6, 6, 3, True) for o in out))
check("Thm 8: the (T3, Y) of these vacuum directions equal the hop shifts of Sec. 5: (-1/2, +1/2) for u, (+1/2, -1/2) for d and e",
      {(o[1], o[0]) for o in out} == {(Fraction(-1, 2), Fraction(1, 2)), (Fraction(1, 2), Fraction(-1, 2))})
check("Thm 8: exactly one of the two Y = -1/2 doublets is the lepton doublet of Sec. 5; the other is H_d",
      len(lep) == 1)

# ---------------------------------------------------------------- Section 9: the matching scale (one loop, SM content)
ainv, s2Z, MZ = 127.930, 0.23129, 91.1880          # PDG 2024: alpha-hat^(5)(MZ)^-1, sin^2 theta-hat(MZ), MZ (GeV)
a1, a2 = 0.6 * (1 - s2Z) * ainv, s2Z * ainv         # alpha_1 (GUT-normalized, 5/3) and alpha_2 inverse at MZ
b1, b2 = 41/10, -19/6
t = (a1 - a2) * 2*np.pi / (b1 - b2); Mx = MZ*np.exp(t)
ax = a1 - b1/(2*np.pi)*t
check(f"Sec. 9: one-loop SM running gives alpha_1 = alpha_2 (sin^2 theta_W = 3/8) at M = {Mx:.2e} GeV, where alpha^-1 = {ax:.1f}",
      1e12 < Mx < 1e14 and abs(ax - (a2 - b2/(2*np.pi)*t)) < 1e-9)
check("Sec. 9: the 5/3 of Theorem 5 is the factor in alpha_1 = (5/3) alpha_Y, so alpha_1 = alpha_2 is the same condition as sin^2 theta_W = 3/8",
      abs(1/(1 + 5/3) - 3/8) < 1e-15)


# ---------------------------------------------------------------- Proposition 3: the charges a hop conserves
Wm = np.array(W)
check("Prop. 3: the 27 weights span R^6, so a Cartan direction v has v.(F mu) = v.mu on every state exactly when F v = v",
      np.linalg.matrix_rank(Wm) == 6)
C = np.array(colr); E = np.eye(6)
fixed = E[:4]                                             # F = diag(1,1,1,1,-1,-1) fixes e1..e4
Mfc = C @ fixed.T
ns = np.linalg.svd(Mfc)[2][np.linalg.matrix_rank(Mfc):] @ fixed   # F-fixed directions orthogonal to color
inP = lambda v, B: np.allclose(B.T @ np.linalg.lstsq(B.T, v, rcond=None)[0], v)
e4 = E[3]
check(f"Prop. 3: the hop-conserved directions that commute with color form a plane (dimension {len(ns)}) spanned by Q and e4",
      len(ns) == 2 and inP(Q, ns) and inP(e4, ns) and abs(Q@e4) < 1e-12)
check("Prop. 3: T3L and Y_L are not hop-conserved (F alpha_6 != alpha_6, F Y_L != Y_L); their sum Q is",
      not np.allclose(F@beta, beta) and not np.allclose(F@YL, YL) and np.allclose(F@Q, Q) and np.allclose(beta/2 + YL, Q))
SMcart = np.array([[0,1,-1,0,0,0.], [1,1,0,0,0,0.], beta/2, YL])
nsSM = np.linalg.svd(np.vstack([SMcart, -ns]).T)[2]
inter = [v for v in ns if inP(v, SMcart)]
# intersection of span(SM Cartan outside color: T3, Y) with the hop-conserved plane
B2 = np.array([beta/2, YL]); M2 = np.hstack([B2.T, -ns.T]); k = np.linalg.svd(M2)[2][np.linalg.matrix_rank(M2):]
vecs = [B2.T @ row[:2] for row in k]
check(f"Prop. 3: after the two singlets, the unbroken directions outside color (T3L, Y_L) meet the hop-conserved plane in a line ({len(vecs)} direction), the line of Q",
      len(vecs) == 1 and abs(abs(vecs[0]@Q) - np.linalg.norm(vecs[0])*np.linalg.norm(Q)) < 1e-9)
check("Prop. 3: the second hop-conserved direction e4 is broken by the singlet S_1 (e4.S_1 = -1) and is not broken by S_2",
      abs(e4@S1 + 1) < 1e-9 and abs(e4@S2) < 1e-9)
check("Prop. 3: Q survives every stage of the chain (orthogonal to S_1, S_2, H_u0, H_d0 and nu_L)",
      all(abs(Q@m) < 1e-9 for m in S + D))
shift = lambda m: (exact(T3(F@m) - T3(m), 6), exact(YL@(F@m) - YL@m, 6))
check("Prop. 3: on every state a hop changes (T3L, Y_L) by (t, -t), so it is neutral only under Q; for u, d and e the shift equals the (T3, Y) of H_u0 or H_d0",
      all(shift(m)[0] == -shift(m)[1] for m in W) and
      {(exact(T3(d), 6), exact(YL@d, 6)) for d in D} >= {(Fraction(-1, 2), Fraction(1, 2)), (Fraction(1, 2), Fraction(-1, 2))})

print("\nVERDICT:", "ALL PASS" if ok else "FAILURES")
