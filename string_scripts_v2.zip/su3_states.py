"""Gluonic states of SU(3) flux with the Casimir rule, below 6000 bits.
Voids and nodes are the sites of a bipartite graph, joined where a node is a vertex of a void; an SU(3) link variable
sits on every such incidence.  Physical states are singlets at every void and every node.  Energy: the count of the
occupied voids (288 per committed bond, each bond once, less 36 per occupied void) plus, for each void,
1692 x (1/2 sum_p C2(R_vp)/C2(3) - 1): a single fundamental line through a void costs nothing beyond the count.
Step 1: which representations and topologies are possible below 6000 bits.
Step 2: for configurations made of fundamental lines only (each occupied void carrying one line, in at one vertex and out
at another), the number of singlets at a node with i lines in and o lines out is computed by Weyl integration, and
the states are counted level by level; we report whether any node carries more than one line or a junction."""
import itertools, numpy as np
from collections import defaultdict
# --- SU(3) singlet multiplicity of 3^{(x)i} (x) 3bar^{(x)o} by Weyl integration on the torus
M=48
th=2*np.pi*np.arange(M)/M; T1,T2=np.meshgrid(th,th,indexing='ij'); z1=np.exp(1j*T1); z2=np.exp(1j*T2); z3=1/(z1*z2)
vd=abs((z1-z2)*(z1-z3)*(z2-z3))**2/6
from functools import lru_cache
@lru_cache(None)
def mult(i,o):
    chi=z1+z2+z3; return int(round(np.real(np.mean(vd*chi**i*np.conj(chi)**o))))
print("singlets in 3^i x 3bar^o:", {(i,o):mult(i,o) for i in range(4) for o in range(4) if mult(i,o)})
C2={'3':4/3,'8':3,'6':10/3,'10':6}
print("Casimir ratios C2(R)/C2(3):", {k:round(v/C2['3'],3) for k,v in C2.items()})
print("extra cost of a void: junction of three fundamental lines 1692*(3/2-1) =",1692*0.5,
      "; two lines through one void", 1692*1.0, "; one adjoint line", 1692*(C2['8']/C2['3']-1))
def tet(c):
    i,j,k=c; return tuple(sorted(p for p in itertools.product((i,i+1),(j,j+1),(k,k+1)) if sum(p)%2==0))
def edges(c): return {frozenset(e) for e in itertools.combinations(tet(c),2)}
def nbrs(c):
    out=set()
    for p in tet(c):
        for d in itertools.product(*[(q-1,q) for q in p]):
            if d!=c and p in tet(d): out.add(d)
    return out
def base(S): return 288*len(set().union(*[edges(c) for c in S]))-36*len(S)
o=(0,0,0); sets={frozenset([o])}; fr=[frozenset([o])]
for size in range(2,5):
    new=[]
    for S in fr:
        for c in S:
            for d in nbrs(c):
                T=S|{d}
                if d not in S and T not in sets: sets.add(T); new.append(T)
    fr=new
sets=[S for S in sets if len(S)>=2 and base(S)<6000]
print("void sets of 2-4 voids below 6000 bits:", len(sets), " minimal base by size:",
      {k:min(base(S) for S in sets if len(S)==k) for k in (2,3,4)})
# Step 2: fundamental lines.  Each void: ordered pair (in-vertex, out-vertex), distinct.  Node p: i = lines leaving p into
# a void, o = lines arriving at p from a void; singlets mult(o, i) (arriving lines carry 3, leaving carry 3bar).
def canon(items):
    pts=[x for it in items for x in (it[1],it[2])]; m=min(pts)
    sh=lambda p: tuple(a-b for a,b in zip(p,m))
    return tuple(sorted((tuple(a-b for a,b in zip(c,m)),sh(p),sh(q)) for c,p,q in items))
levels=defaultdict(dict); special=defaultdict(int)
for S in sets:
    S=sorted(S); E=base(S)
    cntv=defaultdict(int)
    for c in S:
        for p in tet(c): cntv[p]+=1
    opts=[[pq for pq in itertools.permutations(tet(c),2) if cntv[pq[0]]>=2 and cntv[pq[1]]>=2] for c in S]   # a node met by one void cannot be a singlet
    for choice in itertools.product(*opts):
        cnt_in=defaultdict(int); cnt_out=defaultdict(int)
        for c,(p,q) in zip(S,choice): cnt_out[p]+=1; cnt_in[q]+=1     # line enters void at p (leaves node p), exits at q
        nodes=set(cnt_in)|set(cnt_out); m=1; spec=False
        for p in nodes:
            mm=mult(cnt_in[p],cnt_out[p]); m*=mm
            if cnt_in[p]+cnt_out[p]>2: spec=True
        if m==0: continue
        key=canon([(c,p,q) for c,(p,q) in zip(S,choice)])
        if key not in levels[E]:
            levels[E][key]=m
            if spec: special[E]+=1
for E in sorted(levels):
    print(f"  {E}: {len(levels[E])} configurations up to translation (before closing under rotations), states {sum(levels[E].values())}, "
          f"with a node carrying more than one line or a junction: {special[E]}")

# Step 3: close each level under O_h and flux reversal, and count states (with the node multiplicities)
G=[]
for perm in itertools.permutations(range(3)):
    for sg in itertools.product((1,-1),repeat=3):
        Mx=np.zeros((3,3),int)
        for i in range(3): Mx[i,perm[i]]=sg[i]
        G.append(Mx)
def cube_of(center2): return tuple((x-1)//2 for x in center2)
def act(g,key,rev=False):
    items=[]
    for c,p,q in key:
        cen=tuple(int(x) for x in g@np.array([2*a+1 for a in c])); P=tuple(int(x) for x in g@np.array(p)); Q=tuple(int(x) for x in g@np.array(q))
        items.append((cube_of(cen),Q,P) if rev else (cube_of(cen),P,Q))
    return canon(items)
def node_mult(key):
    ci=defaultdict(int); co=defaultdict(int)
    for c,p,q in key: co[p]+=1; ci[q]+=1
    m=1; spec=False
    for p in set(ci)|set(co):
        m*=mult(ci[p],co[p]); spec|= ci[p]+co[p]>2
    return m,spec
print("\nlevels closed under O_h and flux reversal:")
summary={}
for E in sorted(levels):
    Sset=set(levels[E]); frn=list(Sset)
    while frn:
        k=frn.pop()
        for Q in [act(np.eye(3,dtype=int),k,True)]+[act(g,k) for g in G]:
            if Q not in Sset: Sset.add(Q); frn.append(Q)
    tot=0; simple=0; extra=0
    for k in Sset:
        m,spec=node_mult(k); tot+=m
        if spec: extra+=m
        else: simple+=m
    summary[E]=(tot,simple,extra)
    print(f"  {E} bits: {tot} states; simple loops (each node met by one line) {simple}; with a node carrying two lines or a junction {extra}")

# Step 4: composition of the levels: number of separate loops (components of the void graph joined through the nodes
# where lines pass) and nodes where three lines meet (junctions, singlet of 3x3x3 through the epsilon tensor)
print("\ncomposition (configurations closed under symmetry, weighted by node multiplicity):")
for E in sorted(levels):
    if E<5600: continue
    Sset=set(levels[E]); frn=list(Sset)
    while frn:
        k=frn.pop()
        for Q in [act(np.eye(3,dtype=int),k,True)]+[act(g,k) for g in G]:
            if Q not in Sset: Sset.add(Q); frn.append(Q)
    comp=defaultdict(int)
    for k in Sset:
        m,spec=node_mult(k)
        ci=defaultdict(int); co=defaultdict(int)
        for c,p,q in k: co[p]+=1; ci[q]+=1
        junction=any((ci[p],co[p]) in ((3,0),(0,3)) for p in set(ci)|set(co))
        two=any(ci[p]==2 and co[p]==2 for p in set(ci)|set(co))
        # components: voids linked when they share a node used by both
        par={c:c for c,_,_ in k}
        def f(x):
            while par[x]!=x: x=par[x]
            return x
        users=defaultdict(list)
        for c,p,q in k: users[p].append(c); users[q].append(c)
        for us in users.values():
            for a in us[1:]: par[f(a)]=f(us[0])
        ncomp=len({f(c) for c,_,_ in k})
        comp[("junctions" if junction else "two lines at a node" if two else "simple", ncomp)]+=m
    print(f"  {E}: "+", ".join(f"{a}, {n} component(s): {v}" for (a,n),v in sorted(comp.items())))
