"""Minimal energy 288|B| - 36|S| of connected sets of k tetrahedral voids (connected through shared edges),
k = 2..7, by exhaustive enumeration of edge-connected sets containing a given void."""
import itertools
def tet(c):
    i,j,k=c; return tuple(p for p in itertools.product((i,i+1),(j,j+1),(k,k+1)) if sum(p)%2==0)
def edges(c): return {frozenset(e) for e in itertools.combinations(tet(c),2)}
EN={}
def enb(c):
    if c not in EN:
        out=[]
        for d in itertools.product(*[(x-1,x,x+1) for x in c]):
            if d!=c and edges(c)&edges(d): out.append(d)
        EN[c]=out
    return EN[c]
o=(0,0,0); level={frozenset([o])}
for k in range(2,8):
    nxt=set()
    for S in level:
        for c in S:
            for d in enb(c):
                if d not in S: nxt.add(S|{d})
    level=nxt
    best=min(288*len(set().union(*[edges(c) for c in S]))-36*k for S in level)
    print(f"k={k}: {len(level)} edge-connected sets, minimal energy {best}  ({best/k:.0f} per void)", flush=True)
