# Scripts for "A mass gap without a continuum limit: string tension, string breaking and the lightest glueball from the FCC vacuum code" (version 2)

R. Kulkarni. Each script runs on its own with Python 3, NumPy, SciPy and Matplotlib.

| script | paper | what it does |
|---|---|---|
| `count_energy.py` | Sec. 5, Table 2, Prop. 1 | Units of a tetrahedral void; the proton count (K+1)K^2 - c_skew K = 1836 and the string void 1692; disjointness of consecutive voids and the additive count of chains (1692 n along a bond, 1404 per void along a cube axis); the closed string 3096 |
| `bond_hamiltonian.py` | Sec. 5 | H_count evaluated on the proton, string void, chains, every closed loop below 6000 bits and every open string of up to three further voids; check that no unoccupied void has all its edges committed |
| `string_numbers.py` | Secs. 6–8, Props. 2–4 | The tension, its direction dependence, the three repair thresholds, the breaking distance, the energy at the break (Casimir scaling, Prop. 3, multiplies the tension by C2(R)/C2(3)) |
| `string_paths.py` | Sec. 4, Lemmas 1–2, Table 1 | Void geometry (shared vertices and edges, the octahedron's parallel opposite edges) and the shortest-path search for the cheapest string by direction |
| `min_string.py` | Sec. 4 | Exhaustive search over strings of up to seven voids for the cheapest string at each separation, every shared bond counted once (about 20 min) |
| `closed_strings.py` | Sec. 9, Table 3 | Cycles of two, three and four tetrahedral voids and their minimal counts |
| `min_clusters.py` | Sec. 9 | Minimal energy of edge-connected sets of two to seven voids (five or more cost at least 7020) |
| `su3_states.py` | Sec. 9, Prop. 5 | SU(3) singlet multiplicities at a node by Weyl integration; extra cost of junctions, crossings and adjoint lines under the Casimir rule; physical states of each level below 6000 bits and their composition |
| `closed_jpc.py` | Sec. 9.1, Prop. 6 | Representation of O_h x {1,C} on the oriented closed loops of voids and its decomposition; check on a single plaquette of the cubic lattice |
| `su3_jpc.py` | Sec. 9.1, Table 4 | Basis of routed fundamental lines and epsilon junctions; decomposition of each level below 6000 bits under O_h x {1,C} (about 30 s) |
| `su3_haar_check.py` | Sec. 10 | Monte Carlo check of the SU(3) fusion coefficients used for the loop term |
| `loop_term.py` | Sec. 10 | Second-order effective Hamiltonian of the smallest loop term on the lowest level (writes H1.npy, H2.npy) |
| `loop_term_sectors.py` | Sec. 10, Table 5 | O_h x {1,C} sectors of that Hamiltonian and the energies as functions of lambda (run loop_term.py first) |
| `hagedorn.py` | Sec. 11, Prop. 7, Table 6 | Voids at a node and their shared edges; exact enumeration of strings without repeats up to six further voids with the energies of H_count (7.0e7 strings, about 5 min) and the temperatures T_n |
| `fig_background.py` | Figure 1 | Node and its twelve bonds; the proton's trapped node and colored edge pairs; the octahedral void |
| `fig_string2.py` | Figure 2 | The two string chains in the FCC lattice |
| `fig_repair.py` | Figure 3 | Repair threshold under linear, quadratic and bond-energy pricing |
| `fig_closed.py` | Figure 4 | The lightest gluonic state on one bond; the gluonic levels beside the SU(3) glueball masses |

Run, for example: `python3 su3_jpc.py`
