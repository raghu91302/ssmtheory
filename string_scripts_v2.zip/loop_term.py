"""The smallest gauge-invariant loop term,  H = H_count - lam * sum_gamma (Tr U_gamma + Tr U_gamma^dag),
in degenerate perturbation theory to second order in lam, on the lowest gluonic level (12 states at 3096 bits).

The smallest closed loops of the void--node graph are void-node-void-node: one per bond AB, through the two voids
that share it.  |gamma, s> = chi(U_gamma^s)|0> (s = +: fundamental, -: antifundamental) are the level's states.
V = -lam sum (Tr U + Tr U^dag) acting on |gamma,s> produces (exact SU(3) coefficients, checked in su3_haar_check.py):
  same loop:   Tr U^{-s}: vacuum (amp 1) + adjoint loop (amp 1);   Tr U^{s}: |gamma,-s> (amp 1) + sextet loop (amp 1)
  other loop gamma', no shared link: product state (amp 1)
  other loop sharing one link, traversed oppositely: merged loop (singlet on the link, amp 1/3) + adjoint on the link (amp sqrt(8/9))
  other loop sharing one link, traversed the same way: 3bar on the link, epsilon junctions (amp 1/sqrt3) + sextet (amp sqrt(2/3))
Energies of intermediate states from H_count with the Casimir rule (S6).  The effective Hamiltonian
  H_eff(g2,g1) = sum_n <g2|V|n><n|V|g1> / (3096 - E_n)
is built on zero-momentum states (bond direction d, sense s), relative to the vacuum's own second-order shift; the
contributions of far-apart loops cancel exactly (vacuum path +1/3096, product path -1/3096) and loops within a
radius are summed explicitly.  Output: first-order and second-order coefficients for each O_h x C sector."""
import itertools, numpy as np
from collections import defaultdict
K=12
def tet(c):
    i,j,k=c; return tuple(sorted(p for p in itertools.product((i,i+1),(j,j+1),(k,k+1)) if sum(p)%2==0))
def edges(c): return {frozenset(e) for e in itertools.combinations(tet(c),2)}
C2={'1':0,'3':4/3,'8':3.0,'6':10/3}
def cubes_on_bond(A,B):
    lo=[min(a,b) for a,b in zip(A,B)]; hi=[max(a,b) for a,b in zip(A,B)]
    out=[c for c in itertools.product(*[range(h-1,l+1) for l,h in zip(lo,hi)]) if A in tet(c) and B in tet(c)]
    assert len(out)==2; return sorted(out)
def loop(A,B,s):
    """incidences with traversal: +1 = node->void, -1 = void->node.  sense +: A->v1->B->v2->A"""
    v1,v2=cubes_on_bond(A,B); d={(v1,A):1,(v1,B):-1,(v2,B):1,(v2,A):-1}
    return {k:s*x for k,x in d.items()}
def energy(lines):
    """lines: dict incidence -> representation label of the flux on that link ('3','8','6' ...).
    occupied voids, committed bonds, Casimir excess per void"""
    vs=defaultdict(list)
    for (v,p),R in lines.items(): vs[v].append(R)
    B=set().union(*[edges(v) for v in vs]) if vs else set()
    E=288*len(B)-36*len(vs)
    for v,Rs in vs.items(): E+=1692*(0.5*sum(C2[R] for R in Rs)/C2['3']-1)
    return E
def fund(L): return {k:'3' for k in L}
E0=energy(fund(loop((0,0,0),(1,1,0),1))); assert abs(E0-3096)<1e-9
nn=[d for d in itertools.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==2]
dirs=[d for d in nn if d>tuple(-x for x in d)]                       # 6 bond directions
def bonds_near(Rmax):
    pts=[p for p in itertools.product(range(-Rmax,Rmax+1),repeat=3) if sum(p)%2==0]
    out=[]
    for p in pts:
        for d in dirs:
            q=tuple(a+b for a,b in zip(p,d)); out.append((p,q,d))
    return out
def V_on(A,B,s,near):
    """components of V|gamma,s> (in units of -lam): dict label -> (amp, energy)"""
    me=loop(A,B,s); out={}
    out[('vac',)]=(1.0,0.0)
    key=frozenset([A,B])
    out[('8',key)]=(1.0,E0+2*1692*(C2['8']/C2['3']-1))
    out[('6',key,s)]=(1.0,E0+2*1692*(C2['6']/C2['3']-1))
    out[('lvl',key,-s)]=(1.0,E0)                                        # first order, inside the level
    for (P,Q,d) in near:
        k2=frozenset([P,Q])
        if k2==key: continue
        for s2 in (1,-1):
            other=loop(P,Q,s2); shared=set(me)&set(other)
            pair=frozenset([(key,s),(k2,s2)])
            if not shared:
                lines=fund(me); 
                for k,x in other.items(): lines[k]='3'
                # a void crossed by both lines: count both lines' incidences
                vs=defaultdict(list)
                for k in me: vs[k[0]].append('3')
                for k in other: vs[k[0]].append('3')
                Bs=set().union(*[edges(v) for v in vs]); E=288*len(Bs)-36*len(vs)+sum(1692*(0.5*sum(C2[r] for r in Rs)/C2['3']-1) for Rs in vs.values())
                out[('prod',pair)]=(1.0,E)
            else:
                assert len(shared)==1; (inc,)=shared
                vs=defaultdict(list)
                for k in me:
                    if k!=inc: vs[k[0]].append('3')
                for k in other:
                    if k!=inc: vs[k[0]].append('3')
                def Ewith(R):
                    vv={v:list(r) for v,r in vs.items()}
                    if R!='1': vv.setdefault(inc[0],[]).append(R)
                    Bs=set().union(*[edges(v) for v in vv]); 
                    return 288*len(Bs)-36*len(vv)+sum(1692*(0.5*sum(C2[r] for r in Rs)/C2['3']-1) for Rs in vv.values())
                if me[inc]==-other[inc]:     # opposite traversal: 3 x 3bar = 1 + 8
                    merged=frozenset((k,x) for k,x in list(me.items())+list(other.items()) if k!=inc)
                    out[('merged',merged)]=(out.get(('merged',merged),(0,0))[0]+1/3, Ewith('1'))
                    out[('adj',pair)]=(np.sqrt(8/9),Ewith('8'))
                else:                         # same traversal: 3 x 3 = 3bar + 6
                    out[('junc',pair)]=(1/np.sqrt(3),Ewith('3'))   # link in 3bar: Casimir of 3bar = that of 3
                    out[('sext',pair)]=(np.sqrt(2/3),Ewith('6'))
    return out
# --- build the 12 x 12 zero-momentum effective Hamiltonian
def near_of(A,B,r):
    """bonds whose loops can differ from 'far' for the loop at AB: within distance r of A"""
    out=[]
    for p in itertools.product(*[range(a-r,a+r+1) for a in A]):
        if sum(p)%2: continue
        for d in dirs:
            q=tuple(x+y for x,y in zip(p,d)); out.append((p,q,d))
    return out
def far_check(A,B,s,r):
    """the product with every loop outside radius r must have energy 2 x 3096 (no shared bond or void)"""
    me=loop(A,B,s); vs={k[0] for k in me}; bs=set().union(*[edges(v) for v in vs])
    worst=0
    for (P,Q,d) in near_of(A,B,r+2):
        if max(abs(x-y) for x,y in zip(P,A))<=r: continue
        o=loop(P,Q,1); vo={k[0] for k in o}; bo=set().union(*[edges(v) for v in vo])
        if (vs&vo) or (bs&bo) or (set(me)&set(o)): worst+=1
    return worst
RN=2
print("loops outside radius", RN, "that still interact with the origin loop:", sum(far_check((0,0,0),tuple(d),1,RN) for d in dirs))
level=[(d,s) for d in dirs for s in (1,-1)]
idx={x:i for i,x in enumerate(level)}
H1=np.zeros((12,12)); H2=np.zeros((12,12))
O=(0,0,0)
cache={}
def comps(P,Q,s):
    k=(P,Q,s)
    if k not in cache: cache[k]=V_on(P,Q,s,near_of(P,Q,RN))
    return cache[k]
for d1 in dirs:
    A=O; B=tuple(a+b for a,b in zip(O,d1))
    for s1 in (1,-1):
        c1=comps(A,B,s1); i1=idx[(d1,s1)]
        H1[idx[(d1,-s1)],i1]+=1.0
        nb=len(near_of(A,B,RN))
        H2[i1,i1]+=2*nb/E0                       # minus the vacuum's shift from the same loops (both senses)
        for (P,Q,d2) in near_of(A,B,2*RN):
            for s2 in (1,-1):
                c2=comps(P,Q,s2)
                for n in set(c1)&set(c2):
                    if n[0]=='lvl': continue
                    if n[0]=='vac' and frozenset([P,Q])!=frozenset([A,B]):
                        # vacuum path to a different loop: cancels the product path when the loops are far;
                        # keep it only if a product/overlap path between them was generated (near pair)
                        pass
                    a1,En=c1[n]; a2,_=c2[n]
                    H2[idx[(d2,s2)],i1]+=a1*a2/(E0-En)
                # far pairs: vacuum path +1/E0 is counted above for every pair within 2*RN, product path only if
                # the pair is within RN of each other; remove the vacuum path for pairs with no product generated
                key1=frozenset([(frozenset([A,B]),s1),(frozenset([P,Q]),s2)])
                if frozenset([P,Q])!=frozenset([A,B]) and not any(n[0] in ('prod','adj','junc','sext') and n[1]==key1 for n in c1):
                    H2[idx[(d2,s2)],i1]-=1/E0
np.set_printoptions(precision=3,suppress=True,linewidth=200)
Cm=np.zeros((12,12))
for (d,s),i in idx.items(): Cm[idx[(d,-s)],i]=1
print("H2 symmetric:", np.allclose(H2,H2.T))
for Cv,name in ((1,'C=+'),(-1,'C=-')):
    Pc=(np.eye(12)+Cv*Cm)/2; Ev,Uv=np.linalg.eigh(Pc); Bc=Uv[:,Ev>0.5]
    h1=Bc.T@H1@Bc; h2=Bc.T@H2@Bc
    w,U=np.linalg.eigh(h2)
    print(f"{name}: first order {np.round(np.linalg.eigvalsh(h1),4)};  second order x1e4/bit: {np.round(w*1e4,4)}")
np.save('H1.npy',H1); np.save('H2.npy',H2)
