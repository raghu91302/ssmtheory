"""Energies of H_count (Section 5) on configurations given by their occupied voids.
A bond is committed when it is an edge of an occupied void; H_count = eps_b [288 x (committed bonds, each once)
- 36 x (occupied voids) + 144 x (trapped nodes)].  We check that this equals the count of the rules (F2), (S2) for the
proton, the string void, the chains, every closed loop of voids below 6000 bits and every open string of up to three
further voids, and that no unoccupied void has all six edges committed (so occupied voids are never created by accident).
The SU(3) physical states are enumerated in su3_states.py and su3_jpc.py."""
import itertools, numpy as np
K, cs = 12, 3
def tet(c):
    i,j,k=c; return frozenset(p for p in itertools.product((i,i+1),(j,j+1),(k,k+1)) if sum(p)%2==0)
def edges(V): return frozenset(frozenset(e) for e in itertools.combinations(V,2))
def cubes_at_edge(e):
    p,q=tuple(e); lo=[min(a,b) for a,b in zip(p,q)]; hi=[max(a,b) for a,b in zip(p,q)]
    rng=[range(h-1,l+1) for l,h in zip(lo,hi)]
    return [c for c in itertools.product(*rng) if e in edges(tet(c))]
def H(voids, nodes=()):
    B=set().union(*[edges(tet(v)) for v in voids])                 # committed bonds
    cand={c for e in B for c in cubes_at_edge(e)}                    # every tetrahedron touching a committed bond
    full={c for c in cand if edges(tet(c)) <= B}                     # o_v = 1
    E=2*K*K*len(B) - cs*K*len(full) + K*K*len([v for v in nodes if v in full])
    return E, full - set(voids)
def rule(voids, nodes=(), cyclic=False):
    n=len(voids); E=1692*n+144*len(nodes)
    pairs=[(voids[a],voids[a+1]) for a in range(n-1)]
    if cyclic and n>2: pairs.append((voids[-1],voids[0]))
    E-=288*sum(len(edges(tet(u))&edges(tet(v))) for u,v in pairs)
    return E
print("proton :", H([(0,0,0)],[(0,0,0)])[0], " string void:", H([(0,0,0)])[0])
for n in (2,5,10):
    a=[(i,i,0) for i in range(n)]; b=[(0,0,i) for i in range(n)]
    print(f"chain n={n}: bond direction H={H(a)[0]} rule={rule(a)};  cube axis H={H(b)[0]} rule={rule(b)}")
# all closed strings below 6000 bits, from the enumeration used for Table 4
exec(open('closed_jpc.py').read().split('# geometry of a state')[0])
bad=0; acc=0; seen=set()
for vs,ps in cyc:
    key=frozenset(vs)
    if key in seen: continue
    seen.add(key)
    r=cost(vs)
    if r>6000: continue
    e,extra=H(list(vs))
    if e!=r: bad+=1
    if extra: acc+=1
print(f"closed strings below 6000 bits: {len(seen)} void sets checked (all costs), mismatches with H among those below 6000: {bad}, with accidental voids: {acc}")
# open strings of up to 3 further voids (S5 rule), compare
def verts_c(c): return tet(c)
def voids_at(p): return [c for c in itertools.product(*[(q-1,q) for q in p]) if p in tet(c)]
start=(0,0,0); a0=sorted(tet(start))[0]
paths=[((start,),a0)]; mism=0; accd=0; tot=0
for n in range(1,4):
    new=[]
    for path,a in paths:
        u=path[-1]
        for b in tet(u):
            if b==a: continue
            for v in voids_at(b):
                if v==u or v in path: continue
                new.append((path+(v,),b))
    paths=new
    for path,_ in paths:
        tot+=1; e,extra=H(list(path)); r=rule(list(path))
        if extra: accd+=1
        if e!=r: mism+=1
print(f"open strings of 1-3 further voids: {tot} checked; accidental voids in {accd}; H is below the count that shares bonds only between consecutive voids in {mism} (strings that fold back and share a bond between non-consecutive voids)")
