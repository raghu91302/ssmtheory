"""Identify the O_h x C sectors of the second-order effective Hamiltonian of loop_term.py and print the energies
E(lam) = 3096 + e1*lam + e2*lam^2 for each J^PC (lowest spin of the O_h irrep)."""
import itertools, numpy as np
exec(open('loop_term.py').read().split('# --- build the 12 x 12')[0])
H1=np.load('H1.npy'); H2=np.load('H2.npy')
level=[(d,s) for d in dirs for s in (1,-1)]; idx={x:i for i,x in enumerate(level)}
G=[]
for perm in itertools.permutations(range(3)):
    for sg in itertools.product((1,-1),repeat=3):
        M=np.zeros((3,3),int)
        for i in range(3): M[i,perm[i]]=sg[i]
        G.append(M)
def image(g,d,s):
    L=loop((0,0,0),tuple(d),s)                        # incidences ((cube),node) -> traversal
    img={}
    for (c,p),x in L.items():
        cen=g@np.array([2*a+1 for a in c]); cc=tuple(int((y-1)//2) for y in cen); pp=tuple(int(y) for y in g@np.array(p))
        img[(cc,pp)]=x
    nodes=sorted({p for (_,p) in img})
    for X in nodes:
        Y=[q for q in nodes if q!=X][0]; dd=tuple(b-a for a,b in zip(X,Y))
        if dd in dirs:
            sh=lambda t: tuple(a-b for a,b in zip(t,X))
            T={(sh(c),sh(p)):x for (c,p),x in img.items()}
            for s2 in (1,-1):
                if T==loop((0,0,0),dd,s2): return (dd,s2)
    raise ValueError
Rg=[]
for g in G:
    M=np.zeros((12,12))
    for (d,s),i in idx.items(): M[idx[image(g,d,s)],i]=1
    Rg.append(M)
Cm=np.zeros((12,12))
for (d,s),i in idx.items(): Cm[idx[(d,-s)],i]=1
for M in Rg: assert np.allclose(M@H2,H2@M) and np.allclose(M@H1,H1@M)
def oclass(gp):
    tr=int(np.trace(gp))
    if tr==3: return 'E'
    if tr==0: return 'C3'
    if tr==1: return 'C4'
    return 'C2' if np.array_equal(np.abs(gp),np.eye(3,dtype=int)) else "C2p"
CH={'A1':dict(E=1,C3=1,C2=1,C4=1,C2p=1),'A2':dict(E=1,C3=1,C2=1,C4=-1,C2p=-1),'E':dict(E=2,C3=-1,C2=2,C4=0,C2p=0),
    'T1':dict(E=3,C3=0,C2=-1,C4=1,C2p=-1),'T2':dict(E=3,C3=0,C2=-1,C4=-1,C2p=1)}
J={'A1':0,'A2':3,'E':2,'T1':1,'T2':2}
res=[]
for irr,ch in CH.items():
    for Pv in (1,-1):
        Pr=sum(ch[oclass(g*round(np.linalg.det(g)))]*(Pv if round(np.linalg.det(g))==-1 else 1)*M for g,M in zip(G,Rg))*ch['E']/48
        for Cv in (1,-1):
            P=Pr@(np.eye(12)+Cv*Cm)/2
            if np.trace(P)<0.5: continue
            w,U=np.linalg.eigh((P+P.T)/2); B=U[:,w>0.5]
            e1=np.linalg.eigvalsh(B.T@H1@B); e2=np.linalg.eigvalsh(B.T@H2@B)
            # V carries -lam: first order energy is -lam * (H1 eigenvalue); second order lam^2 * H2
            res.append((f"{irr}{'+' if Pv>0 else '-'}{'+' if Cv>0 else '-'}", J[irr], Pv, Cv, -e1[0], e2[0], B.shape[1]))
print("sector  J^PC   dim   E = 3096 + e1*lam + e2*lam^2   (e2 per bit)")
for name,j,P,C,e1,e2,dim in sorted(res,key=lambda r:(r[4],r[5])):
    print(f"{name:7s} {j}{'+' if P>0 else '-'}{'+' if C>0 else '-'}   {dim:2d}   e1 = {e1:+.0f}   e2 = {e2*1e4:+.3f}e-4")
me=0.51099895; sqs=450.5
print("\nlam (bits)  E(0++)  E(2++:E)  E(2++:T2)  E(1+-)  E(2+-)  ratios to 0++   [lattice: 2++ 1.437, 1+- 1.781]")
for lam in (50,100,150,200,250):
    E={n:3096+e1*lam+e2*lam**2 for n,j,P,C,e1,e2,dim in res}
    print(f"  {lam:4d}   {E['A1++']:7.0f} {E['E++']:8.0f} {E['T2++']:8.0f} {E['T1+-']:8.0f} {E['T2+-']:8.0f}   "
          f"{E['E++']/E['A1++']:.3f} {E['T2++']/E['A1++']:.3f} {E['T1+-']/E['A1++']:.3f} {E['T2+-']/E['A1++']:.3f}")
