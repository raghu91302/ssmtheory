"""Background figure: (a) an FCC node and its twelve bonds; (b) the proton: a node trapped in a tetrahedral void,
the void's three pairs of opposite edges in three colors; (c) an octahedral void, whose opposite edges are parallel."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 9, "mathtext.fontset": "cm"})
def setview(dv):
    global R
    d = np.array(dv, float); d /= np.linalg.norm(d)
    u = np.cross(d, [0, 0, 1.0]); u /= np.linalg.norm(u); w = np.cross(d, u); R = np.vstack([u, w])
setview([0.574, -0.579, -0.579])
P = lambda v: R @ np.asarray(v, float)
def seg(ax, a, b, **k):
    pa, pb = P(a), P(b); ax.plot([pa[0], pb[0]], [pa[1], pb[1]], solid_capstyle="round", **k)
def dot(ax, v, **k):
    p = P(v); ax.scatter([p[0]], [p[1]], **k)
fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.7))
# (a) node with 12 bonds
ax = axes[0]
nn = [np.array(v)/2 for v in itertools.product((-1, 0, 1), repeat=3) if sum(abs(x) for x in v) == 2]
for a in nn:
    for b in nn:
        if abs(np.linalg.norm(a-b) - np.sqrt(0.5)) < 1e-9 and tuple(a) < tuple(b): seg(ax, a, b, color="#9fb3c8", lw=0.6, zorder=0)
for v in nn: seg(ax, np.zeros(3), v, color="#2b6cb0", lw=1.6, zorder=1); dot(ax, v, s=24, c="#2b6cb0", edgecolors="k", linewidths=0.5, zorder=3)
dot(ax, np.zeros(3), s=70, c="white", edgecolors="k", zorder=4)
ax.set_title("(a) a node of the vacuum and its twelve bonds", fontsize=12)
# (b) proton: trapped node in a tetrahedral void
ax = axes[1]; setview([0.30, -0.90, 0.32])
V = [np.array(v, float) for v in [(0, 0, 0), (1, 1, 0), (1, 0, 1), (0, 1, 1)]]; T = sum(V)/4
cols = ["#d62728", "#2ca02c", "#1f77b4"]
for (e1, e2), c in zip([((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2))], cols):
    for a, b in (e1, e2): seg(ax, V[a], V[b], color=c, lw=2.6, zorder=1)
for v in V: seg(ax, v, T, color="#e6550d", lw=1.4, ls=(0, (3, 2)), zorder=2)
for v in V: dot(ax, v, s=70, c="#3182bd", edgecolors="k", linewidths=0.6, zorder=3)
dot(ax, T, s=200, c="#fdd835", edgecolors="#8a6d00", marker="*", zorder=4)
pt = P(T); ax.text(pt[0]+0.07, pt[1]+0.04, "trapped node", fontsize=11)
ax.set_title("(b) the proton: a node trapped in a tetrahedral void\nopposite-edge pairs = the three colors", fontsize=12)
# (c) octahedral void
ax = axes[2]; setview([0.42, -0.80, 0.43])
O = [np.array(v, float)/2 for v in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]]
E = [(a, b) for a, b in itertools.combinations(range(6), 2) if abs(np.linalg.norm(O[a]-O[b]) - np.sqrt(0.5)) < 1e-9]
hl = [E[0], next(e for e in E if set(e).isdisjoint(E[0]) and np.linalg.norm(np.cross(O[e[1]]-O[e[0]], O[E[0][1]]-O[E[0][0]])) < 1e-9)]
for a, b in E: seg(ax, O[a], O[b], color="0.55", lw=1.3, zorder=1)
for a, b in hl: seg(ax, O[a], O[b], color="#7b3294", lw=3.0, zorder=2)
for v in O: dot(ax, v, s=60, c="#3182bd", edgecolors="k", linewidths=0.6, zorder=3)
ax.set_title("(c) an octahedral void: each edge is parallel\nto its opposite (one pair in purple), so no color", fontsize=12)
for a in axes: a.set_aspect("equal"); a.axis("off")
axes[0].set_xlim(-0.8, 0.8); axes[0].set_ylim(-0.75, 0.75)
plt.tight_layout(); fig.savefig("fig_background.pdf", bbox_inches="tight"); fig.savefig("fig_background.png", dpi=170, bbox_inches="tight"); print("ok")
