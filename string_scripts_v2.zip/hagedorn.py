"""Hagedorn temperature of the void strings (Section 10).
A string leaves a given void through a vertex other than its entry vertex, enters another tetrahedral void at that
vertex, and never revisits a void (S5).  Its energy is that of the bond Hamiltonian of Section 5: 288 bits per committed
bond, each bond counted once wherever it is shared, less 36 per void whose six edges are committed.  Exact depth-first
enumeration of all strings of up to NMAX further voids (NMAX = 6: 7.0e7 strings, about 5 minutes), histogram of
energies, and the temperature T_n at which Z_n = Z_{n-1}.  Also: the voids at a node and the step weight w(T)."""
import itertools, math, sys, numpy as np
from collections import Counter
from scipy.optimize import brentq
R=7
def tet(c):
    i,j,k=c; return tuple(p for p in itertools.product((i,i+1),(j,j+1),(k,k+1)) if sum(p)%2==0)
cubes=list(itertools.product(range(-R,R),repeat=3)); cid={c:i for i,c in enumerate(cubes)}
E_id={}; vedges=[]; vverts=[]
for c in cubes:
    V=tet(c); vverts.append(V); es=[]
    for e in itertools.combinations(V,2):
        k=frozenset(e)
        if k not in E_id: E_id[k]=len(E_id)
        es.append(E_id[k])
    vedges.append(tuple(es))
edge_voids={}
for i,es in enumerate(vedges):
    for e in es: edge_voids.setdefault(e,[]).append(i)
vert_voids={}
for i,V in enumerate(vverts):
    for p in V: vert_voids.setdefault(p,[]).append(i)
NMAX=int(sys.argv[1]) if len(sys.argv)>1 else 6     # 7 takes about 1.5 hours
hist=[Counter() for _ in range(NMAX+1)]
sys.setrecursionlimit(10000)
def dfs(path, entry, bonds, full, E, depth):
    hist[depth][E]+=1
    if depth==NMAX: return
    u=path[-1]
    for b in vverts[u]:
        if b==entry: continue
        for v in vert_voids[b]:
            if v in path: continue
            new=[e for e in vedges[v] if e not in bonds]
            nb=bonds.union(new); comp=0; nf=full
            for e in new:
                for c in edge_voids[e]:
                    if c not in nf and all(x in nb for x in vedges[c]): nf=nf|{c}; comp+=1
            dfs(path+(v,), b, nb, nf, E+288*len(new)-36*comp, depth+1)
s=cid[(0,0,0)]
dfs((s,), vverts[s][0], frozenset(vedges[s]), frozenset([s]), 1692, 0)
me=0.51099895; Lc=0.84075; hc=197.3269804; sqs=math.sqrt(1692*me/Lc*hc)
def Z(n,T): return sum(c*math.exp(-E/T) for E,c in hist[n].items())
print("strings by n:", [sum(h.values()) for h in hist])
p=(0,0,0); at=vert_voids[p]; u=at[0]
print("tetrahedral voids at a node:", len(at), "; of the other seven, sharing an edge with one of them:", sum(1 for v in at if v!=u and set(vedges[u])&set(vedges[v])))
for n in range(2,NMAX+1):
    T=brentq(lambda T: Z(n,T)/Z(n-1,T)-1, 50, 5000)
    print(f"  n={n}: T_n = {T:.1f} bits, T_n/sqrt(sigma) = {T*me/sqs:.4f}", flush=True)
T=[brentq(lambda T: Z(n,T)/Z(n-1,T)-1, 50, 5000)*me/sqs for n in range(2,NMAX+1)]
inv=np.array([1/n for n in range(NMAX-2,NMAX+1)]); fit=np.polyfit(inv,np.array(T[-3:]),1)
print(f"linear fit in 1/n over the last three: T_H/sqrt(sigma) -> {fit[1]:.4f};  SU(3): 0.629(3), 0.6462(30)")
import json; json.dump({str(n):{str(k):v for k,v in hist[n].items()} for n in range(NMAX+1)}, open(f"hagedorn_hist_{NMAX}.json","w"))
