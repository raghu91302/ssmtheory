"""Figure 4: (a) the lightest gluonic state, two tetrahedral voids on one bond, with one of its four flux routes;
(b) the gluonic levels of Table 4 with some of the J^PC they contain and their number of states, beside the SU(3) glueball masses."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
plt.rcParams.update({"font.size": 9, "mathtext.fontset": "cm"})
skew = ["#d62728", "#2ca02c", "#1f77b4"]
def tetra(c):
    i, j, k = c
    return [np.array(p, float) for p in itertools.product((i, i+1), (j, j+1), (k, k+1)) if sum(p) % 2 == 0]
fig = plt.figure(figsize=(12.5, 5.2))
ax = fig.add_subplot(1, 2, 1, projection="3d")
nodes = [np.array(p) for p in itertools.product(range(-1, 3), range(-1, 3), range(-1, 2)) if sum(p) % 2 == 0]
segs = [(p, q) for p, q in itertools.combinations(nodes, 2) if abs(np.sum((p-q)**2) - 2) < 1e-9]
ax.add_collection3d(Line3DCollection(segs, colors="0.85", linewidths=0.5))
P = np.array(nodes); ax.scatter(*P.T, s=8, c="0.65", depthshade=False)
U = tetra((0, 0, 0)); Vv = tetra((0, 0, -1))
for T, fc in ((U, "#fdae6b"), (Vv, "#9ecae1")):
    faces = [[T[a], T[b], T[c]] for a, b, c in itertools.combinations(range(4), 3)]
    ax.add_collection3d(Poly3DCollection(faces, facecolor=fc, edgecolor="none", alpha=0.35))
    for (e1, e2), col in zip([((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2))], skew):
        for a, b in (e1, e2): ax.plot(*zip(T[a], T[b]), color=col, lw=1.2, alpha=0.8)
A = np.array([0., 0, 0]); B = np.array([1., 1, 0]); C = np.array([1., 0, 1]); D = np.array([1., 0, -1])
ax.plot(*zip(A, B), color="k", lw=4, alpha=0.75)
route = [A, C, B, D, A]
for p, q in zip(route[:-1], route[1:]):
    m = p + 0.55*(q-p)
    ax.plot(*zip(p, q), color="#6a3d9a", lw=2.6)
    ax.quiver(*(p + 0.35*(q-p)), *(0.25*(q-p)), color="#6a3d9a", lw=2.2, arrow_length_ratio=0.6)
for lab, p, off in (("A", A, (-0.18, -0.1, 0.05)), ("B", B, (0.08, 0.08, 0.05)), ("C", C, (0.05, -0.05, 0.08)), ("D", D, (0.05, -0.05, -0.15))):
    ax.scatter(*p, s=40, c="#3182bd", edgecolors="k", depthshade=False); ax.text(*(p + np.array(off)), lab, fontsize=11)
ax.set_box_aspect((1, 1, 1)); ax.set_xlim(-0.6, 1.6); ax.set_ylim(-0.6, 1.6); ax.set_zlim(-1.1, 1.1)
ax.view_init(elev=14, azim=-62); ax.set_axis_off()
ax.set_title("(a) lightest closed string: two voids on one bond AB", fontsize=10)
# (b) spectrum
bx = fig.add_subplot(1, 2, 2)
me, sqs = 0.51099895, 450.5
levels = [(3096, r"$0^{++},2^{++};\ 1^{+-},2^{+-}$  (12)"), (4500, r"$0^{++},2^{++},1^{++},1^{-+},0^{--}\ldots$ (no $0^{-+}$)  (48)"),
          (5076, r"$0^{++},2^{++},1^{-+},0^{--}\ldots$  (16)"), (5616, r"$0^{++},2^{++},1^{-+},0^{--}\ldots$ (no $0^{-+}$)  (156)"),
          (5904, r"first $0^{-+}$  (840)")]
for c, lab in levels:
    y = c*me/sqs; bx.hlines(y, 0.05, 0.95, color="#6a3d9a", lw=2); bx.text(0.05, y+0.07, lab, fontsize=8, color="#6a3d9a")
lat = [("0^{++}", 3.405, 0.021), ("2^{++}", 4.894, 0.022), ("0^{-+}", 5.276, 0.045), ("1^{+-}", 6.065, 0.040), ("2^{-+}", 6.32, 0.09), ("3^{++}", 7.71, 0.09)]
for k, (lab, y, e) in enumerate(lat):
    x = 1.25 + 0.12*(k % 2)
    bx.errorbar(x+0.25, y, yerr=e, fmt="s", color="k", ms=4, capsize=2); bx.text(x+0.33, y-0.06, f"${lab}$", fontsize=9)
bx.set_xlim(0, 2.0); bx.set_ylim(3.0, 8.0); bx.set_xticks([0.5, 1.55]); bx.set_xticklabels(["gluonic states, $H_{\\rm count}$", "SU(3) lattice, continuum"])
bx.set_ylabel(r"$m/\sqrt{\sigma}$"); bx.set_title("(b) levels and their lowest $J^{PC}$", fontsize=10)
for s in ("top", "right"): bx.spines[s].set_visible(False)
plt.tight_layout(); plt.savefig("fig_closed.pdf", bbox_inches="tight"); plt.savefig("fig_closed.png", dpi=110, bbox_inches="tight")
