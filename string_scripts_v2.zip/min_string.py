"""Section 4: cheapest string between voids under the bond Hamiltonian (bonds counted once anywhere): exhaustive search over
strings of up to NMAX further voids; minimal energy to reach each end void, versus its distance."""
import itertools, math, sys
exec(open('hagedorn.py').read().split('NMAX=')[0])
NMAX=int(sys.argv[1]) if len(sys.argv)>1 else 6
best={}
def dfs(path, entry, bonds, full, E, depth):
    v=path[-1]
    if E<best.get(v,1e18): best[v]=E
    if depth==NMAX: return
    for b in vverts[v]:
        if b==entry: continue
        for w in vert_voids[b]:
            if w in path: continue
            new=[e for e in vedges[w] if e not in bonds]; nb=bonds.union(new); comp=0; nf=full
            for e in new:
                for c in edge_voids[e]:
                    if c not in nf and all(x in nb for x in vedges[c]): nf=nf|{c}; comp+=1
            dfs(path+(w,), b, nb, nf, E+288*len(new)-36*comp, depth+1)
s=cid[(0,0,0)]
for a0 in vverts[s]:
    dfs((s,), a0, frozenset(vedges[s]), frozenset([s]), 1692, 0)
L=math.sqrt(2); c0=[x+0.5 for x in cubes[s]]
rows=[]
for v,E in best.items():
    c=[x+0.5 for x in cubes[v]]; d=math.dist(c,c0)/L
    if d>=2.5: rows.append((E/d, d, E, cubes[v]))
rows.sort()
print("lowest energy per bond length of separation (separation >= 2.5 L):")
for r in rows[:6]: print(f"  {r[0]:8.1f} bits per L   separation {r[1]:.3f} L   E = {r[2]}   end void {r[3]}")
