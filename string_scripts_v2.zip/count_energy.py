"""The count as an energy: the combinatorial method of the proton count, the string void, and the additivity
that makes a string of n voids cost 1692 n bits.

Labels.  A structural unit u of a defect disrupts K^2 bond states: the K bonds of each of its K neighbors
(ordered pairs, so with multiplicity).  The effective Hamiltonian H = eps_b * sum_a Pi_a has one commuting projector
per bond-state label a = (u; n, b); its eigenvalue on a configuration is eps_b times the number of disrupted labels.
Units of a tetrahedral void: the 12 committed bond-ends (vertex, edge of the void at that vertex), plus the trapped
node when present.  Labels of the two units on the ends of a skew pair of edges overlap in K states (published
rule, F2); a bond shared by two voids has its two bond-ends counted once (S2)."""
import itertools, numpy as np
K, c_skew = 12, 3
def tet(c):
    i, j, k = c
    return [p for p in itertools.product((i, i+1), (j, j+1), (k, k+1)) if sum(p) % 2 == 0]
def edges(V): return [frozenset(e) for e in itertools.combinations(V, 2)]
def bond_ends(V): return {(v, e) for e in edges(V) for v in e}          # committed bond-ends: (vertex, edge)
def is_bond(p, q): return sum((a-b)**2 for a, b in zip(p, q)) == 2
V0 = tet((0, 0, 0))
assert all(is_bond(p, q) for p, q in itertools.combinations(V0, 2))
skew = [(e, f) for e, f in itertools.combinations(edges(V0), 2) if not (e & f)]
print(f"void: 4 vertices, {len(edges(V0))} edges, {len(bond_ends(V0))} committed bond-ends, {len(skew)} skew pairs = c_skew")
print(f"each vertex commits {sum(1 for (v, e) in bond_ends(V0) if v == V0[0])} of its K = {K} bonds")
proton = (len(bond_ends(V0)) + 1)*K*K - c_skew*K
void   = len(bond_ends(V0))*K*K - c_skew*K
print(f"proton: (12 + 1) x {K*K} - {c_skew} x {K} = {proton}")
print(f"string void (no trapped node): 12 x {K*K} - {c_skew} x {K} = {void} = {proton} - {K*K}")
def chain_cost(cubes):
    """count of a chain of voids: each void's own count, less 2 x 144 for each bond shared with its predecessor"""
    total, shared_ends = 0, 0
    for a, c in enumerate(cubes):
        total += void
        if a:
            common = set(edges(tet(cubes[a-1]))) & set(edges(tet(c)))
            total -= 2*K*K*len(common); shared_ends += 2*len(common)
    return total, shared_ends
print("\nchain along a bond direction (each void the previous one moved by one bond):")
for n in (1, 2, 3, 5, 10, 20):
    cubes = [(i, i, 0) for i in range(n)]
    for a in range(1, n):                                                  # geometry: one shared vertex, no shared bond
        Va, Vb = tet(cubes[a-1]), tet(cubes[a])
        assert len(set(Va) & set(Vb)) == 1 and not (set(edges(Va)) & set(edges(Vb)))
        assert not (bond_ends(Va) & bond_ends(Vb))                         # committed bond-ends disjoint -> labels disjoint
    C, s = chain_cost(cubes)
    # span: distance between the first void's far vertex and the last void's far vertex along the chain, in bond lengths
    print(f"   n = {n:2d}: count {C:6d} = {C//n} x n,  shared bond-ends {s},  advance n bond lengths")
print("   => E(r) - E_vac = 1692 eps_b r / L_c + O(1) at r = n L_c, from additivity alone (no linear-pricing rule)")
print("\nchain along a cube axis (consecutive voids share an edge):")
for n in (2, 5, 10):
    cubes = [(0, 0, i) for i in range(n)]
    C, s = chain_cost(cubes)
    print(f"   n = {n:2d}: count {C} = {void} n - 288 (n-1);  per void -> {void-2*K*K}")
print(f"\nlightest closed string: 2 x {void} - 2 x {K*K} = {2*void-2*K*K}")
me, Lc, hc = 0.51099895, 0.84075, 197.3269804
s = void*me/Lc
print(f"sigma = {void} m_e c^2 / L_c = {s:.1f} MeV/fm = {s*hc/1e6:.4f} GeV^2, sqrt = {np.sqrt(s*hc):.1f} MeV")
