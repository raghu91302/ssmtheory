"""Monte Carlo check of the SU(3) coefficients used for the loop term:
<Tr(A B)| Tr(A W) Tr(W^dag B)> = 1/3 (merged loop), weight of 3bar in Tr(AW)Tr(BW) = 1/3, and <chi_3bar|chi_3 chi_3> = 1."""
import numpy as np
rng=np.random.default_rng(1)
def haar(n):
    z=(rng.normal(size=(n,3,3))+1j*rng.normal(size=(n,3,3)))/np.sqrt(2)
    q,r=np.linalg.qr(z); d=np.diagonal(r,axis1=1,axis2=2); q=q*(d/abs(d))[:,None,:]
    det=np.linalg.det(q); return q/(det**(1/3))[:,None,None]
N=400000
A,B,W=haar(N),haar(N),haar(N)
tr=lambda X: np.trace(X,axis1=1,axis2=2)
Wd=np.conj(np.transpose(W,(0,2,1)))
f=tr(A@W)*tr(Wd@B); mu=tr(A@B)
print("overlap merged loop:", np.mean(np.conj(mu)*f).real, "(1/3)")
U=haar(N); print("<chi3bar|chi3 chi3> =", np.mean(np.conj(np.conj(tr(U)))*tr(U)*tr(U)).real, "(1)")
print("<chi3|chi3> =", np.mean(abs(tr(U))**2), "(1)")
# weight of the 3bar part of Tr(AW)Tr(BW) in W: project with the epsilon structure: 3bar part equals
# 1/2[Tr(AW)Tr(BW) - Tr(AWBW)];  its norm^2 should be 1/3
g=tr(A@W)*tr(B@W); h=0.5*(g-tr(A@W@B@W))
print("norm^2 of the 3bar part:", np.mean(abs(h)**2), "(1/3);  of the 6 part:", np.mean(abs(g-h)**2), "(2/3)")
