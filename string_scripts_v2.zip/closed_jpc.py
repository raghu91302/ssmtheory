"""Spin, parity and charge conjugation of the closed strings.
A closed string (S4) is an oriented cycle  void_0 -p_0-> void_1 -p_1-> ... -> void_0, with p_a a vertex shared by
consecutive voids and all p_a distinct (the flux enters and leaves each void through different vertices); its cost is
1692 per void less 288 per edge shared by consecutive voids (S2).  At zero momentum a state is an oriented cycle up to
lattice translation.  The cubic group O_h about a node maps the lattice to itself; reversing the orientation is charge
conjugation C.  For each cost level of cycles of up to four voids we build the permutation representation of
O_h x {1, C} on the states and decompose it into irreps R^{PC} (R of the rotation group O, P = +/-, C = +/-)."""
import itertools, numpy as np
from collections import defaultdict
def verts(c):
    i,j,k=c; return frozenset(p for p in itertools.product((i,i+1),(j,j+1),(k,k+1)) if sum(p)%2==0)
def edges(V): return {frozenset(e) for e in itertools.combinations(V,2)}
R=2; cubes=list(itertools.product(range(-R,R+1),repeat=3)); V={c:verts(c) for c in cubes}; E={c:edges(V[c]) for c in cubes}
nb={c:[d for d in cubes if d!=c and V[c]&V[d]] for c in cubes}
def cost(vs):
    n=len(vs); pairs=[(vs[0],vs[1])] if n==2 else [(vs[a],vs[(a+1)%n]) for a in range(n)]
    return 1692*n-sum(288*len(E[u]&E[v]) for u,v in pairs)
o=(0,0,0)
# enumerate oriented cycles through o (voids distinct), with all choices of distinct shared vertices
cyc=[]
def rec(path,nmax):
    n=len(path)
    if n>=2 and V[path[-1]]&V[o]:
        shared=[sorted(V[path[a]]&V[path[(a+1)%n]]) for a in range(n)]
        for ch in itertools.product(*shared):
            if len(set(ch))==n: cyc.append((tuple(path),tuple(ch)))
    if n==nmax: return
    for d in nb[path[-1]]:
        if d not in path: rec(path+[d],nmax)
rec([o],4)
# geometry of a state: list of points  [center(void_0), p_0, center(void_1), p_1, ...]  (center = cube + 1/2)
def pts(vs,ps):
    out=[]
    for v,p in zip(vs,ps): out+= [tuple(2*x+1 for x in v), tuple(2*x for x in p)]   # doubled coordinates, integer
    return tuple(out)
def canon(P):
    """canonical form of an oriented closed polygon up to FCC translation and cyclic rotation (by void steps)"""
    best=None; n=len(P)
    for r in range(0,n,2):
        Q=P[r:]+P[:r]
        node=min(Q[1::2]); Q=tuple(tuple(a-b for a,b in zip(q,node)) for q in Q)
        if best is None or Q<best: best=Q
    return best
def reverse(P):
    # reversed orientation: voids in reverse order, each shared vertex still between its two voids
    n=len(P)//2; vs=[P[2*a] for a in range(n)]; ps=[P[2*a+1] for a in range(n)]
    vs2=vs[::-1]; ps2=[ps[(n-2-a)%n] for a in range(n)]
    out=[]
    for v,p in zip(vs2,ps2): out+=[v,p]
    return tuple(out)
levels=defaultdict(set)
for vs,ps in cyc: levels[cost(vs)].add(canon(pts(vs,ps)))
G=[]
for perm in itertools.permutations(range(3)):
    for s in itertools.product((1,-1),repeat=3):
        M=np.zeros((3,3),int)
        for i in range(3): M[i,perm[i]]=s[i]
        G.append(M)
def act(g,P): return canon(tuple(tuple(int(x) for x in g@np.array(q)) for q in P))
def oclass(gp):
    tr=int(np.trace(gp))
    if tr==3: return 'E'
    if tr==0: return 'C3'
    if tr==1: return 'C4'
    return 'C2' if np.array_equal(np.abs(gp),np.eye(3,dtype=int)) else "C2'"
CH={'A1':dict(E=1,C3=1,C2=1,C4=1,C2p=1),'A2':dict(E=1,C3=1,C2=1,C4=-1,C2p=-1),'E':dict(E=2,C3=-1,C2=2,C4=0,C2p=0),
    'T1':dict(E=3,C3=0,C2=-1,C4=1,C2p=-1),'T2':dict(E=3,C3=0,C2=-1,C4=-1,C2p=1)}
JMIN={'A1':0,'A2':3,'E':2,'T1':1,'T2':2}
me=0.51099895; sqs=450.5
print("cost   m/sqrt(s)  states  content  (lowest J for each O irrep: A1->0, T1->1, E,T2->2, A2->3)")
for c in sorted(levels):
    if c>6000: break
    S=set(levels[c])
    # close under the group and reversal
    frontier=list(S)
    while frontier:
        P=frontier.pop(); 
        for Q in [reverse(P)]+[act(g,P) for g in G]:
            Q=canon(Q)
            if Q not in S: S.add(Q); frontier.append(Q)
    S=sorted(S); idx={P:i for i,P in enumerate(S)}; N=len(S)
    Cm=np.zeros((N,N))
    for P in S: Cm[idx[canon(reverse(P))],idx[P]]=1
    terms=[]
    for Cv in (1,-1):
        Pc=(np.eye(N)+Cv*Cm)/2
        for irr in CH:
            for Pv in (1,-1):
                m=0
                for g in G:
                    det=round(np.linalg.det(g)); cl=oclass(g*det).replace("'","p")
                    Rg=np.zeros((N,N))
                    for P in S: Rg[idx[act(g,P)],idx[P]]=1
                    m+=CH[irr][cl]*(Pv if det==-1 else 1)*np.trace(Rg@Pc)
                m=round(m/48)
                if m: terms.append(f"{m if m>1 else ''}{irr}{'+' if Pv>0 else '-'}{'+' if Cv>0 else '-'}")
    print(f"{c:5d}  {c*me/sqs:6.2f}  {N:5d}   "+" + ".join(terms))

# check against the strong-coupling analogue: the six states of one plaquette of the cubic lattice
sq={0:[(0,0,0),(0,1,0),(0,1,1),(0,0,1)],1:[(0,0,0),(0,0,1),(1,0,1),(1,0,0)],2:[(0,0,0),(1,0,0),(1,1,0),(0,1,0)]}
def canon_sq(P):
    best=None
    for Q0 in (P,):
        for r in range(4):
            Q=Q0[r:]+Q0[:r]; m=min(Q); Q=tuple(tuple(a-b for a,b in zip(q,m)) for q in Q)
            if best is None or Q<best: best=Q
    return best
S=set()
for k in sq:
    for P in (tuple(sq[k]),tuple(sq[k][::-1])): S.add(canon_sq(P))
fr=list(S)
while fr:
    P=fr.pop()
    for g in G:
        Q=canon_sq(tuple(tuple(int(x) for x in g@np.array(q)) for q in P))
        if Q not in S: S.add(Q); fr.append(Q)
S=sorted(S); idx={P:i for i,P in enumerate(S)}; N=len(S)
Cm=np.zeros((N,N))
for P in S: Cm[idx[canon_sq(P[::-1])],idx[P]]=1
terms=[]
for Cv in (1,-1):
    Pc=(np.eye(N)+Cv*Cm)/2
    for irr in CH:
        for Pv in (1,-1):
            m=0
            for g in G:
                det=round(np.linalg.det(g)); cl=oclass(g*det).replace("'","p")
                Rg=np.zeros((N,N))
                for P in S: Rg[idx[canon_sq(tuple(tuple(int(x) for x in g@np.array(q)) for q in P))],idx[P]]=1
                m+=CH[irr][cl]*(Pv if det==-1 else 1)*np.trace(Rg@Pc)
            m=round(m/48)
            if m: terms.append(f"{irr}{'+' if Pv>0 else '-'}{'+' if Cv>0 else '-'}")
print(f"\nsingle plaquette of the cubic lattice ({N} states): "+" + ".join(terms))
