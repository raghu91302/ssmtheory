"""Spin, parity and charge conjugation of the SU(3) gluonic levels below 6000 bits (Table 4).
A state is a configuration of fundamental lines through voids (each occupied void carries one line, in at one vertex,
out at another; other flux costs at least 846 bits more under the Casimir rule and stays above 6000) together with a
basis element of the singlets at each node: where k lines arrive and k leave (k <= 3) the k! ways of joining arriving
to leaving lines are a basis; where three lines arrive or three leave, the epsilon tensor.  These states are traces of
products of link variables around the routed loops, so the symmetries permute them with sign +1.  We close each level
under O_h and flux reversal C and decompose."""
import itertools, numpy as np
from collections import defaultdict
exec(open('su3_states.py').read().split('# Step 2')[0])
def routings(S, choice):
    ins=defaultdict(list); outs=defaultdict(list)
    for c,(p,q) in zip(S,choice): outs[p].append(c); ins[q].append(c)        # node p: line leaves p into void c; q: arrives from c
    per_node=[]
    for p in set(ins)|set(outs):
        a,b=ins[p],outs[p]
        if len(a)==len(b):
            per_node.append([tuple(('t',p,x,y) for x,y in zip(a,perm)) for perm in itertools.permutations(b)])
        elif (len(a),len(b)) in ((3,0),(0,3)):
            per_node.append([(('j',p,len(a)),)])
        else: return []
    return [sum(r,()) for r in itertools.product(*per_node)]
def canon_state(lines, turns):
    pts=[x for _,p,q in lines for x in (p,q)]; m=min(pts)
    sh=lambda p: tuple(a-b for a,b in zip(p,m)); sc=lambda c: tuple(a-b for a,b in zip(c,m))
    L=tuple(sorted((sc(c),sh(p),sh(q)) for c,p,q in lines))
    T=tuple(sorted(((t[0],sh(t[1]),sc(t[2]),sc(t[3])) if t[0]=='t' else (t[0],sh(t[1]),t[2])) for t in turns))
    return (L,T)
G=[]
for perm in itertools.permutations(range(3)):
    for sg in itertools.product((1,-1),repeat=3):
        Mx=np.zeros((3,3),int)
        for i in range(3): Mx[i,perm[i]]=sg[i]
        G.append(Mx)
def tc(g,c):  # transform a void (cube index) by g about the origin node
    cen=tuple(int(x) for x in g@np.array([2*a+1 for a in c])); return tuple((x-1)//2 for x in cen)
def tp(g,p): return tuple(int(x) for x in g@np.array(p))
def act(g,st,rev=False):
    L,T=st; lines=[]; turns=[]
    for c,p,q in L:
        lines.append((tc(g,c),tp(g,q),tp(g,p)) if rev else (tc(g,c),tp(g,p),tp(g,q)))
    for t in T:
        if t[0]=='t': turns.append(('t',tp(g,t[1]),tc(g,t[3]),tc(g,t[2])) if rev else ('t',tp(g,t[1]),tc(g,t[2]),tc(g,t[3])))
        else: turns.append(('j',tp(g,t[1]),3-t[2] if rev else t[2]))
    return canon_state(lines,turns)
levels2=defaultdict(set)
for S in sets:
    S=sorted(S); E=base(S)
    cntv=defaultdict(int)
    for c in S:
        for p in tet(c): cntv[p]+=1
    opts=[[pq for pq in itertools.permutations(tet(c),2) if cntv[pq[0]]>=2 and cntv[pq[1]]>=2] for c in S]
    for choice in itertools.product(*opts):
        for r in routings(S,choice):
            levels2[E].add(canon_state([(c,p,q) for c,(p,q) in zip(S,choice)], r))
def oclass(gp):
    tr=int(np.trace(gp))
    if tr==3: return 'E'
    if tr==0: return 'C3'
    if tr==1: return 'C4'
    return 'C2' if np.array_equal(np.abs(gp),np.eye(3,dtype=int)) else "C2p"
CH={'A1':dict(E=1,C3=1,C2=1,C4=1,C2p=1),'A2':dict(E=1,C3=1,C2=1,C4=-1,C2p=-1),'E':dict(E=2,C3=-1,C2=2,C4=0,C2p=0),
    'T1':dict(E=3,C3=0,C2=-1,C4=1,C2p=-1),'T2':dict(E=3,C3=0,C2=-1,C4=-1,C2p=1)}
me=0.51099895; sqs=450.5; I3=np.eye(3,dtype=int)
print("bits  m/sqrt(s)  states  content")
for E in sorted(levels2):
    St=set(levels2[E]); fr=list(St)
    while fr:
        k=fr.pop()
        for Q in [act(I3,k,True)]+[act(g,k) for g in G]:
            if Q not in St: St.add(Q); fr.append(Q)
    St=sorted(St); idx={s:i for i,s in enumerate(St)}; N=len(St)
    Cm=np.zeros((N,N))
    for s in St: Cm[idx[act(I3,s,True)],idx[s]]=1
    R={}
    for gi,g in enumerate(G):
        Mx=np.zeros((N,N))
        for s in St: Mx[idx[act(g,s)],idx[s]]=1
        R[gi]=Mx
    terms=[]
    for Cv in (1,-1):
        Pc=(np.eye(N)+Cv*Cm)/2
        for irr in CH:
            for Pv in (1,-1):
                m=sum(CH[irr][oclass(g*round(np.linalg.det(g)))]*(Pv if round(np.linalg.det(g))==-1 else 1)*np.trace(R[gi]@Pc) for gi,g in enumerate(G))
                m=round(m/48)
                if m: terms.append(f"{m if m>1 else ''}{irr}{'+' if Pv>0 else '-'}{'+' if Cv>0 else '-'}")
    print(f"{E:5d}  {E*me/sqs:5.2f}  {N:5d}  "+" + ".join(terms), flush=True)
