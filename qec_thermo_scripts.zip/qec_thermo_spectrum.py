#!/usr/bin/env python3
"""
qec_thermo_spectrum.py -- the temperature of the ledger.

Derives, from pure boundary-bit counting and nothing else:

(1) THE HAWKING TEMPERATURE. The horizon ledger holds S(M) = A/4 l_P^2 bits
    (times ln 2), with A = 16 pi G^2 M^2 / c^4 -- in the companion paper this
    count IS the severed-bond census, RT-calibrated. Emitting energy eps
    shrinks the ledger by dS = (dS/dE) eps. The ledger's own temperature,
    1/T = dS/dE, evaluates to
        T = hbar c^3 / (8 pi G M k_B)  --  exactly Hawking's,
    with no quantum field theory: T_H is the exchange rate of the previous
    section made explicit, k_B T ln2 = energy per boundary bit healed.

(2) THE BOLTZMANN CHARACTER. With equal a priori weight per ledger
    microstate, the probability of an emission that heals Delta N bits is
        P(eps) ~ 2^(-Delta N) = exp(-eps / k_B T_H):
    the thermal exponential from bookkeeping alone. Factorization
    P(e1)P(e2) = P(e1+e2) is exact because bit counts add -- the ledger
    enforces a perfect exponential, verified numerically below.

(3) CLOSURE WITH THE GEOMETRIC CHANNEL. The companion evaporation channel
    releases one quantum per RT cell, mean energy eps_bar = M c^2 A_1/A.
    Computed against the ledger temperature: eps_bar = 2 ln2 * k_B T_H --
    the geometric channel's per-quantum energy is order-one in the ledger's
    own temperature, closing the two descriptions on each other.

NOT derived, stated plainly: the Planck occupation form 1/(e^x - 1)
(requires bosonic mode structure), greybody factors (require wave
scattering in the induced metric), and the Hawking flux law (the model's
geometric channel gives tau ~ M^2, not M^3 -- a stated, testable
difference). The spectrum established here is Boltzmann-weighted geometric
emission at exactly the Hawking temperature.
"""
import numpy as np

hbar = 1.054571817e-34; c = 2.99792458e8; G = 6.674e-11
kB = 1.380649e-23; lP2 = hbar*G/c**3
Msun = 1.989e30

print("== (1) T_H from the ledger: 1/T = dS/dE with S = A/4 l_P^2 ==")
print(f"{'M/Msun':>8s} {'T_ledger [K]':>14s} {'T_Hawking [K]':>14s} {'ratio':>10s}")
for Mf in (1.0, 10.0, 1e-10):
    M = Mf*Msun
    dE = M*c**2*1e-9
    S = lambda m: (16*np.pi*G**2*m**2/c**4)/(4*lP2)          # in nats (k_B=1)
    dSdE = (S(M+dE/c**2/1) - S(M-dE/c**2/1))/(2*dE)*c**2/c**2
    # careful: S is a function of M; dS/dE = (dS/dM)/c^2
    dSdE = (S(M*(1+1e-9)) - S(M*(1-1e-9)))/(2*M*1e-9*c**2)
    T_led = 1.0/(kB*dSdE)
    T_H = hbar*c**3/(8*np.pi*G*M*kB)
    print(f"{Mf:8.1e} {T_led:14.4e} {T_H:14.4e} {T_led/T_H:10.6f}")
print("the ledger's own temperature IS the Hawking temperature -- from bit")
print("counting, no field theory. Exchange rate: k_B T ln2 per bit healed:")
M = Msun
print(f"  solar mass: energy per boundary bit = {kB*hbar*c**3/(8*np.pi*G*M*kB)*np.log(2):.3e} J")

print("\n== (2) Boltzmann character and exact factorization ==")
T_H = hbar*c**3/(8*np.pi*G*Msun*kB)
def P(eps):                                # weight ~ 2^{-Delta N_bits}
    dN = eps/(kB*T_H*np.log(2))
    return 2.0**(-dN)
eps = kB*T_H*np.array([0.5, 1.0, 1.7])
lhs = P(eps[0])*P(eps[1])*P(eps[2])
rhs = P(eps.sum())
print(f"  P(e1)P(e2)P(e3) = {lhs:.6e}  vs  P(e1+e2+e3) = {rhs:.6e}"
      f"   (ratio {lhs/rhs:.12f})")
print("  bit counts add, so the exponential is exact: e^(-eps/kT_H) from the ledger.")

print("\n== (3) closure with the geometric channel ==")
# eps_bar = M c^2 A_1/A with A_1 = 4 l_P^2 ln2 (one ebit per RT cell)
for Mf in (1.0, 1e-10):
    M = Mf*Msun
    A = 16*np.pi*G**2*M**2/c**4
    A1 = 4*lP2*np.log(2)
    eps_bar = M*c**2*A1/A
    T_H = hbar*c**3/(8*np.pi*G*M*kB)
    print(f"  M = {Mf:.1e} Msun: eps_bar/(k_B T_H) = {eps_bar/(kB*T_H):.6f}"
          f"   [analytic: 2 ln2 = {2*np.log(2):.6f}]")
print("the geometric channel's mean quantum is 2 ln2 * k_B T_H at every mass:")
print("thermal-scale emission is a theorem of the ledger, not an estimate.")
print("\nNOT derived: Planck occupation (needs bosonic modes), greybody factors")
print("(need wave scattering in the induced metric), and whether a parallel")
print("field-theoretic channel coexists. The flux law is NOT on that list: the")
print("companion DERIVES the model's own, tau ~ M^2 from boundary bond release;")
print("Hawking's M^3 is a competing prediction whose discriminator the companion")
print("already quantifies (shifted PBH survival cutoff; ~ms bursts at threshold")
print("mass). Boltzmann-weighted geometric emission at")
print("T_H; no more claimed.")


# ------------------------------------------------- provenance decomposition
print("\n== provenance: what is calibration-independent? ==")
print("Vary the entropy coefficient eta (S = eta*A) and the area exponent n")
print("(A ~ M^n); recompute eps_bar/(k_B T) = ln2 * dlnA/dlnM:")
for eta_mult, n in [(1.0,2),(3.0,2),(0.1,2),(1.0,3)]:
    M = Msun
    eta = eta_mult/(4*lP2)
    Aof = lambda m: (16*np.pi*G**2/c**4)*Msun**(2-n)*m**n   # A ~ M^n
    S = lambda m: eta*Aof(m)
    dSdE = (S(M*(1+1e-9))-S(M*(1-1e-9)))/(2*M*1e-9*c**2)
    T = 1.0/(kB*dSdE)
    A1 = np.log(2)/eta
    eps_bar = M*c**2*A1/Aof(M)
    print(f"  eta x{eta_mult:4.1f}, A~M^{n}:  eps_bar/(k_B T) = {eps_bar/(kB*T):.6f}"
          f"   [n ln2 = {n*np.log(2):.6f}]")
print("the ratio is n*ln2 exactly: independent of the entropy coefficient and")
print("of Newton's constant; it needs only S ~ A and the scaling A ~ M^2.")
print("PROVENANCE SUMMARY: the VALUE of T_H inherits the companion's two")
print("calibrations (the RT-calibrated 1/4 and the G_N-matched A(M)); what the")
print("ledger itself supplies is S ~ A, the exact Boltzmann exponential, and")
print("the calibration-independent identity eps_bar = 2 ln2 k_B T.")
