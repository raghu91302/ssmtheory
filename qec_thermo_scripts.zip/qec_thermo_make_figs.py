import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":9,"figure.dpi":150,"savefig.bbox":"tight"})
fig,ax=plt.subplots(1,2,figsize=(8.2,3.2))
a=ax[0]
beta=np.linspace(0,0.995,200)
a.plot(beta,np.sqrt(1-beta**2),c="#1f77b4",lw=1.6,label=r"$1/\gamma$ (special relativity)")
bp=[0.1,0.5,0.9,0.99]
a.plot(bp,[np.sqrt(1-b**2) for b in bp],"o",c="crimson",ms=6,
       label="worldline phase integration")
a.set_xlabel(r"$\beta=v/c$"); a.set_ylabel(r"cycle rate ratio $N_{\rm moving}/N_{\rm rest}$")
a.set_title("(a) kinematic dilation of the cycle"); a.legend()
a=ax[1]
hs=np.logspace(-2,4,50); g=9.80665; c=2.99792458e8
a.loglog(hs,g*hs/c**2,c="#1f77b4",lw=1.6,label=r"$gh/c^2$ (cycle prediction)")
pts=[(0.33,"Chou et al. 2010\n(optical clocks)"),(8848,"Everest")]
for hh,lab in pts:
    a.plot([hh],[g*hh/c**2],"o",c="crimson",ms=6)
    a.annotate(lab,xy=(hh,g*hh/c**2),xytext=(hh*0.05,g*hh/c**2*3),fontsize=7.5,
               arrowprops=dict(arrowstyle="-",lw=0.7))
a.set_xlabel("height difference $h$ [m]"); a.set_ylabel(r"fractional rate shift $\Delta\nu/\nu$")
a.set_title("(b) gravitational dilation of the cycle")
a.legend(loc="lower right")
fig.tight_layout(); fig.savefig("../figs/fig2_dilation.pdf"); print("fig2 done")
