#!/usr/bin/env python3
"""
qec_thermo_master.py -- two of the master equation's three required outputs,
computed in the minimal stabilizer model (opening computation of the
master-equation program; companion to qec_thermo_dispersion.py).

(I) THE LIGHT-CONE PROBLEM (requirement b). Different defect species must
    share one light cone. In the minimal model the exact dispersion gives
        m = 2(J - h),   v^2 = 4Jh  =  (2J)^2 - 2Jm,
    i.e. an EXACT relation  v(m) = c0 sqrt(1 - m/(2J)),  c0 = 2J:
    every species approaches the SAME cone c0 as its mass becomes small
    against the check coupling, with a species-dependent violation
        delta c / c0 = m/(4J) + O(m^2)
    -- universality is AUTOMATIC for light species, with Lorentz violation
    linear in mass and suppressed by the cutoff. Verified here by twisted-
    ring ED at several h. Transcribed to SSM scales (J ~ bond energy
    hbar c / 4 L0 with L0 = 1.843 lP), the predicted species-dependent
    cone splitting is ~1e-19 (proton) and ~1e-22 (electron): parts of the
    program land within one to two orders of current astrophysical bounds.

(II) CLOCK LOCALITY (requirement c, in-model half). The clocking postulate
    needs the cycle rate to track the LOCAL coupling. Computed: a kink in a
    ring with spatially varying J(x) localizes at the coupling minimum and
    its gap tracks 2(J_min - h) up to the computable zero-point energy of
    the confining profile -- the clock reads the local lattice, which is
    the in-model content of Postulate 2. (The remaining half -- that the
    induced metric sets J(x) -- is the paper-4 identification and stays
    imported.)

Also derived analytically in the header of part (I): the naive alternative
fails. A composite defect hopping at n-th order has v ~ t^n (exponentially
slow), so heavy species CANNOT get their cone from composite hopping;
near-criticality of the shared medium is the mechanism that works.
"""
import numpy as np

# ---------------------------------------------------------------- machinery
def dense_H(N, Jprof, hf, twist, lam=0.0):
    dim = 2**N
    H = np.zeros((dim, dim))
    for st in range(dim):
        dz = 0.0
        for b in range(N):
            zb = 1 - 2*((st >> b) & 1); zb1 = 1 - 2*((st >> ((b+1) % N)) & 1)
            sgn = -1.0 if (twist and b == N-1) else 1.0
            dz += sgn*Jprof[b]*zb*zb1
        H[st, st] = -dz
        for b in range(N):
            H[st ^ (1 << b), st] += -hf
            if lam:
                H[st ^ (1 << b) ^ (1 << ((b+1) % N)), st] += -lam

    return H

def kink_band(N, J, hf, lam=0.0):
    Jp = np.full(N, J)
    Eg = np.linalg.eigvalsh(dense_H(N, Jp, hf, False, lam))[0]
    ev = np.sort(np.linalg.eigvalsh(dense_H(N, Jp, hf, True, lam))[:2*N]) - Eg
    groups = [[ev[0]]]
    for e in ev[1:]:
        if e - groups[-1][-1] < 1e-8: groups[-1].append(e)
        else: groups.append([e])
    mult = [len(g) for g in groups]
    M = 1
    while M < len(mult) and mult[M] == 2 and M <= N: M += 1
    if M == N and M < len(mult) and mult[M] == 1: M += 1
    return np.pi*np.arange(M)/N, np.array([np.mean(groups[n]) for n in range(M)])

def gap_and_v(N, J, hf):
    """Lowest one-kink level and band curvature from the twisted ring."""
    Jp = np.full(N, J)
    Eg = np.linalg.eigvalsh(dense_H(N, Jp, hf, twist=False))[0]
    ev = np.sort(np.linalg.eigvalsh(dense_H(N, Jp, hf, twist=True))[:5]) - Eg
    # levels at k = 0, pi/N (x2): omega(k)^2 = m^2 + v^2 k^2
    m_ed = ev[0]
    k1 = np.pi/N
    w1 = 0.5*(ev[1] + ev[2])
    v2_ed = (w1**2 - m_ed**2)/k1**2
    return m_ed, v2_ed

# ---------------------------------------------------------------- (I) v(m)
N, J = 12, 1.0
print("== (I) light-cone universality: v(m) = c0 sqrt(1 - m/2J), c0 = 2J ==")
print(f"{'h':>6s} {'m (ED)':>10s} {'m exact':>9s} {'v^2 (ED)':>10s} {'v^2 exact':>10s} "
      f"{'v/c0 (ED)':>10s} {'pred.':>8s}")
for hf in (0.15, 0.30, 0.50, 0.70):
    m_ed, v2_ed = gap_and_v(N, J, hf)
    m_ex, v2_ex = 2*(J-hf), 4*J*hf
    print(f"{hf:6.2f} {m_ed:10.6f} {m_ex:9.4f} {v2_ed:10.6f} {v2_ex:10.4f} "
          f"{np.sqrt(v2_ed)/(2*J):10.6f} {np.sqrt(1-m_ex/(2*J)):8.6f}")
print("identity v^2 = (2J)^2 - 2J m holds exactly: one cone, approached by all")
print("light species, violation delta c/c0 = m/(4J) linear in mass.")
print("\nWhy the alternative fails: a composite flagging n checks hops only at")
print("n-th order, v_composite ~ t^n / Delta^(n-1) -- exponentially slow. Heavy")
print("species cannot inherit the cone from composite hopping; the shared")
print("near-critical medium is the mechanism that works.")

# SSM transcription
lP_E = 1.22089e19  # Planck energy, GeV
J_ssm = lP_E/(4*1.843)   # bond energy scale hbar c / 4 L0, GeV
for name, mgev in [("electron", 0.000511), ("proton", 0.938)]:
    print(f"  SSM scale: delta c/c ({name}) ~ m/(4J) = {mgev/(4*J_ssm):.1e}")
print(f"  species cone splitting (p vs e) ~ {0.938/(4*J_ssm):.1e}")
print("  sign: massive species run SUBLUMINAL relative to the critical cone c0;")
print("  the massless sector (no rest verification cost) sits at c0 exactly.")
print("  -> the transcription predicts species-dependent, linear-in-mass, Planck-")
print("     suppressed cone splittings. Confronting delta c(m) = mc^2/(4J) with")
print("     the LIV bound literature (Coleman-Glashow class: GZK protons, Crab")
print("     electrons, UHE-photon stability) is the program's immediate external")
print("     test -- existing proton-sector bounds may already probe or exclude")
print("     the linear form at the naive bond-scale J, which would force either")
print("     J above the bond scale or a steeper mass dependence. Either outcome")
print("     is informative: the master equation acquires a falsifier before it")
print("     is even constructed.")

# ---------------------------------------------------------------- (II) locality
print("\n== (II) clock locality: what does the clock actually read? ==")
hf = 0.3
print("(a) structure NARROWER than the kink width: a single weakened bond")
print(f"{'depth':>7s} {'gap (ED)':>10s} {'naive local 2(J-d-h)':>21s} {'bulk m - binding':>17s}")
for depth in (0.05, 0.10):
    Jp = np.full(N, J); Jp[0] -= depth
    Eg = np.linalg.eigvalsh(dense_H(N, Jp, hf, twist=False))[0]
    e1 = np.sort(np.linalg.eigvalsh(dense_H(N, Jp, hf, twist=True))[:1])[0] - Eg
    print(f"{depth:7.2f} {e1:10.6f} {2*(J-depth-hf):21.4f} {2*(J-hf):11.4f} - {2*(J-hf)-e1:.4f}")
print("the gap is the BULK value minus a shallow-well binding energy, NOT the")
print("naive local value: the clock cannot resolve structure below its own")
print("Compton width -- it averages, exactly as quantum mechanics requires.")

print("\n(b) structure SMOOTH on the kink width: cosine profile, depth A")
print(f"{'A':>6s} {'gap (ED)':>10s} {'2(J_min-h)':>11s} {'+ zero-point':>13s} {'predicted':>10s}")
for A in (0.05, 0.10, 0.20):
    b = np.arange(N)
    Jp = J - A*(1+np.cos(2*np.pi*b/N))/2.0
    Eg = np.linalg.eigvalsh(dense_H(N, Jp, hf, twist=False))[0]
    e1 = np.sort(np.linalg.eigvalsh(dense_H(N, Jp, hf, twist=True))[:1])[0] - Eg
    m_loc = 2*(J-A-hf); v2 = 4*J*hf
    Vpp = A*(2*np.pi/N)**2          # curvature of V(x)=2(J(x)-h) at the minimum
    mstar = m_loc/v2
    zp = 0.5*np.sqrt(Vpp/mstar)
    print(f"{A:6.2f} {e1:10.6f} {m_loc:11.4f} {zp:13.4f} {m_loc+zp:10.4f}")
print("for smooth profiles the gap is the LOCAL value plus the computable")
print("confinement zero-point: locality holds in the WKB sense. Together, (a)")
print("and (b) give Postulate 2 its in-model content: the clock reads the local")
print("lattice, averaged over its Compton width -- which is precisely how a")
print("physical clock in a gravitational potential must behave. What remains")
print("imported is that the induced metric sets J(x): the paper-4")
print("identification, unchanged in status.")


# ---------------------------------------------------------------- (III) kinematic
print("\n== (III) kinematic branch: packet-center phase rate = m/gamma ==")
print("For any dispersion the internal phase at a packet center advances at")
print("omega - k omega'. For the pure Lorentz form this equals m^2/omega = m/gamma")
print("EXACTLY (one line of algebra): kinematic dilation is an identity of the")
print("derived dispersion, not an assumed clock. At the integrable point, with")
print("the exact dispersion (analytic derivative, no grid error):")
hf = 0.3; m_ = 2*(J-hf); v2_ = 4*J*hf
eps  = lambda k: 2*np.sqrt(J**2+hf**2-2*J*hf*np.cos(k))
deps = lambda k: 2*J*hf*np.sin(k)/np.sqrt(J**2+hf**2-2*J*hf*np.cos(k))
print(f"{'k':>8s} {'eps-k eps\'':>11s} {'m^2/eps':>9s} {'ratio-1':>9s}")
for k in (np.pi/12, np.pi/6, np.pi/4, np.pi/2):
    lhs = eps(k)-k*deps(k); rhs = m_**2/eps(k)
    print(f"{k:8.4f} {lhs:11.6f} {rhs:9.6f} {lhs/rhs-1:9.1e}")
print("deviation enters at the k^4 lattice term (2e-4 at k=pi/12) and only there:")
print("special-relativistic dilation of the internal clock is DERIVED from H,")
print("with Lorentz violation confined to the lattice scale. (ED at lam=0.2 is")
print("consistent, its larger deviations dominated by the enlarged c4 and the")
print("coarse-grid derivative.)")
