#!/usr/bin/env python3
"""
qec_thermo_numbers.py -- the Compton-clock table and the Margolus-Levitin
anchor. The postulate nu = m c^2 / h saturates the ML bound nu <= 2E/h up to
the factor 2 (orthogonalization vs full cycle); mass ratios ARE frequency
ratios, so the companion papers' m_p/m_e = 1836 is a ratio of clock rates.
"""
import numpy as np
c=2.99792458e8; h=6.62607015e-34; eV=1.602176634e-19
tU=4.35e17
parts=[("electron",0.51099895e6),("muon",105.6583755e6),
       ("proton",938.27208816e6),("neutron",939.56542052e6)]
print(f"{'particle':10s} {'m c^2':>14s} {'nu = mc^2/h [Hz]':>18s} {'ticks/s':>12s} {'ticks per t_univ':>18s}")
for name,E in parts:
    nu=E*eV/h
    print(f"{name:10s} {E/1e6:11.4f} MeV {nu:18.4e} {nu:12.3e} {nu*tU:18.3e}")
nue=parts[0][1]*eV/h; nup=parts[2][1]*eV/h
print(f"\nnu_p/nu_e = {nup/nue:.3f}   (companion mass formula: 1836.15)")
print("ML bound: t_orth >= h/(4E) -> nu_max = 4E/h; the Compton clock runs at")
print("nu = E/h, a factor 4 inside the bound: the cycle is ML-allowed with margin.")
print("\nExperimental anchor: the Compton clock is not hypothetical --")
print("Lan et al., Science 339, 554 (2013) operated a Cs Compton-clock")
print("interferometer referenced to nu = mc^2/h. This paper supplies a")
print("microscopic mechanism for the clock those experiments read out.")
