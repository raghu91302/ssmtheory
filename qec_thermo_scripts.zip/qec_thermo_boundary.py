#!/usr/bin/env python3
"""
qec_thermo_boundary.py -- the void-mass puzzle, quantified.

If mass is verification cost, a black hole's mass should be the maintenance
cost of its boundary (a void has no interior to verify). This script measures
how every static boundary verification quantity scales with vacancy size,
using the punctured-code data of the companion paper (pbh_revised_vacancy_L8.json):
severed bonds, boundary-localized modes, truncated-check estimates. All scale
as AREA (R^2), while Schwarzschild requires M proportional to R. The gap --
cost/M growing linearly in R -- is the sharpest current statement of the
open mass-assignment problem, stated here as a constraint any resolution
must satisfy: the R-linear quantity is not among the static ones.
"""
import json, numpy as np
v = json.load(open("pbh_revised_vacancy_L8.json"))
R  = np.array([x["ReffL0"] for x in v])
A  = np.array([x["A_L0"]   for x in v])
sev= np.array([x["sever"]  for x in v])
bmod=np.array([x["w1Z"] + 2*x["w2Z"] for x in v])   # edges hosting boundary modes (upper est.)
kl = np.array([x["klost"]  for x in v])
def fit(y, name):
    m = (R > 1.0)
    a = np.polyfit(np.log(R[m]), np.log(y[m]), 1)[0]
    print(f"  {name:34s} ~ R^{a:.2f}")
    return a
print("scaling of static boundary quantities with vacancy radius (L=8 data):")
fit(sev,  "severed bonds")
fit(bmod, "boundary-localized mode support")
fit(kl,   "logical deficit k0 - k'")
print(f"\nSchwarzschild requires M ~ R^1.00")
print("gap: every static boundary cost grows super-linearly (R^1.7-R^2.9);")
print("none is linear in R, so cost/M grows with R.")
print("Constraint on any resolution: the R-linear 'mass' quantity of a void")
print("is dynamical (a rate or flux at the boundary), not a static census --")
print("consistent with mass-as-verification-COST being power, not structure.")
