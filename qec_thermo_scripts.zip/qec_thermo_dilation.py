#!/usr/bin/env python3
"""
qec_thermo_dilation.py -- the verification cycle inherits both relativistic
dilations (Theorem 1 of the paper).

Model: a defect's cycle is clocked by the local proper time of the emergent
metric. Phase advance per coordinate time dt at position x, speed v:
    dphi = (m c^2 / hbar) * sqrt(1 + 2 Phi(x)/c^2 - v^2/c^2) dt
with Phi the induced Newtonian potential of the companion black-hole paper
(Sec. 3.4 there). Two computations:

(A) Gravitational: static defect clocks at different heights. Predicted
    fractional rate difference g h / c^2, compared against the optical-clock
    benchmark (Chou et al. 2010: 33 cm), then verified by explicit phase
    integration in the induced potential of the Earth.

(B) Kinematic: a moving defect's cycle rate in the lattice frame is
    m c^2/(gamma h) -- the de Broglie internal clock -- verified by numerical
    worldline phase integration, including the round-trip (twin) asymmetry
    as an accumulated cycle-count deficit.
"""
import numpy as np
c = 2.99792458e8; hbar = 1.054571817e-34; G = 6.674e-11; h = 6.62607015e-34
me = 9.1093837e-31

print("== (A) gravitational dilation of the Compton clock ==")
g = 9.80665
for hh, label in [(0.33, "Chou et al. optical-clock lift (33 cm)"),
                  (1.0, "1 m"), (8848.0, "Everest")]:
    print(f"  dnu/nu = g h/c^2 = {g*hh/c**2:.3e}   ({label})")
M = 5.972e24; R = 6.371e6
nu0 = me*c**2/h
print(f"  electron Compton clock nu0 = {nu0:.4e} Hz")
# explicit high-precision phase integration (a 1e-17 shift needs > double precision)
from mpmath import mp, mpf, sqrt as msqrt
mp.dps = 50
cc, GG, MM, RR = mpf(c), mpf(G), mpf(M), mpf(R)
n0 = mpf(me)*cc**2/mpf(h)
def rate(r): return n0*msqrt(1 + 2*(-GG*MM/r)/cc**2)
n_lo = rate(RR); n_hi = rate(RR + mpf('0.33'))
print(f"  cycles in 1 s, ground vs +33 cm: differ by {float(n_hi-n_lo):.3f} cycles")
print(f"  fractional = {float((n_hi-n_lo)/n_lo):.4e}  vs  GM h/(R^2 c^2) = "
      f"{float(GG*MM*mpf('0.33')/(RR**2*cc**2)):.4e}")

print("\n== (B) kinematic dilation: worldline phase integration ==")
def cycles(v_of_t, T, dt=1e-6):
    t = np.arange(0, T, dt); v = v_of_t(t)
    return np.sum(np.sqrt(1-(v/c)**2))*dt*nu0
for beta in [0.1, 0.5, 0.9, 0.99]:
    Nmove = cycles(lambda t: beta*c*np.ones_like(t), 1.0)
    gam = 1/np.sqrt(1-beta**2)
    print(f"  beta={beta}: N_moving/N_rest = {Nmove/nu0:.6f}  vs 1/gamma = {1/gam:.6f}")
beta = 0.8
Ntrav = cycles(lambda t: beta*c*np.ones_like(t), 1.0)
print(f"  twin (0.8c, 1 s): traveler proper time {Ntrav/nu0*1e3:.3f} ms vs 1000 ms;")
print(f"  deficit {(nu0-Ntrav):.3e} cycles -- aging IS the cycle count.")
print("\nBoth dilations are inherited because the cycle is clocked by local")
print("proper time of the induced metric; no new postulate enters.")
