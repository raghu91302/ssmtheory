#!/usr/bin/env python3
"""
Verification script for the so(8) -> f4 -> e6 chain of the
Selection-Stitch Model (computational core of the planned Paper 9):

  1. F4: bonds (24 long) + matter weights (24 short) close as F4.
  2. E6 unfold: doubling every short root by void ORIENTATION, with the
     three GLUE CLASSES at 120 degrees in a new 2-plane, closes as E6
     (72 roots, all squared length 2, rank 6, Cartan det 3).
     The charge-based doubling FAILS closure: one competitor eliminated.
  3. The fold: the orientation flip is an automorphism of the 72 whose
     fixed roots are exactly the 24 bonds: f4 is the orientation-
     symmetric shadow of e6 (and C = P is the folded statement).
  4. Trinification: deleting the mark-3 node gives three orthogonal
     su(3)'s; the orientation flip swaps two and fixes one (color).
  5. The 27 branches as (3,3b,1)+(1,3,3b)+(3b,1,3); the color-singlet
     block is the 9-dimensional lepton-family block.
  6. Fold consistency: folding the 27 under (color, diagonal of the
     swapped pair) reproduces the f4-level 26-branching
     (3,3b)+(3b,3)+(1,8) plus one extra singlet: the horizontal octet
     is the folded lepton bifundamental.

Requires numpy only.  Run: python3 verify_e6_chain.py
Expected: 23x PASS, then ALL PASS.  Runtime: ~1 minute
(the 72x72 reflection-closure tests dominate).
"""
import numpy as np, itertools
from collections import Counter

ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)

# ---- link 1: F4 from bonds + matter ----
longr=[]
for i,j in itertools.combinations(range(4),2):
    for si,sj in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v=np.zeros(4); v[i]=si; v[j]=sj; longr.append(v)
shortr=[s*np.eye(4)[i] for i in range(4) for s in(1,-1)] + \
       [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
F4=np.array(longr+shortr); F4set={tuple(np.round(r,6)) for r in F4}
refl=lambda a,x: x-2*(x@a)/(a@a)*a
# ---- Theorem 1: static orientation blindness (the inversion pairing) ----
_a1=np.array([1.0,0.0]); _a2=np.array([0.5,np.sqrt(3)/2])
_oA=np.zeros(2); _oB=(_a1+_a2)/3; _oC=2*(_a1+_a2)/3
_nodes={p for p in itertools.product(range(-4,5),repeat=3) if sum(p)%2==0}
_nb=[np.array(d) for d in [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]]
_tets=set()
for _p in [q for q in _nodes if max(map(abs,q))<=2]:
    _P=np.array(_p); _ns=[tuple(_P+d) for d in _nb if tuple(_P+d) in _nodes]
    for _x,_y,_z in itertools.combinations(_ns,3):
        if all(np.dot(np.subtract(u,v),np.subtract(u,v))==2 for u,v in ((_x,_y),(_x,_z),(_y,_z))): _tets.add(frozenset((_p,_x,_y,_z)))
_U=np.array([1,1,1.])
def _orient(T):
    h=sorted(float(np.dot(v,_U)) for v in T); return 'down' if abs(h[0]-h[1])<1e-9 else 'up'   # three atoms low = base down
_tset={frozenset(T) for T in _tets}
_inv=[(T,frozenset(tuple(-np.array(v)) for v in T)) for T in _tets]
check("Theorem 1: inversion through a node maps every tetrahedral void onto a void of the other orientation; o_A + o_C = 2 o_B",
      np.allclose(_oA+_oC,2*_oB) and all((I in _tset or not all(max(map(abs,v))<=2 for v in I)) and _orient(I)!=_orient(T) for T,I in _inv))
# ---- Theorem 2: on the orientation doublet, sigma_y is the unique Pauli generator odd under P and even under PT ----
_sx=np.array([[0,1],[1,0]],complex); _sy=np.array([[0,-1j],[1j,0]]); _sz=np.array([[1,0],[0,-1]],complex)
_Pop=lambda A: _sx@A@_sx                 # P: exchange of the two sheets
_PTop=lambda A: _sx@A.conj()@_sx         # PT: exchange composed with complex conjugation (antiunitary T)
_odd_even=[n for n,A in (("x",_sx),("y",_sy),("z",_sz)) if np.allclose(_Pop(A),-A) and np.allclose(_PTop(A),A)]
check("Theorem 2: sigma_y is the unique Pauli generator odd under P and even under PT", _odd_even==["y"])

check("F4: 48 roots closed under own reflections",
      all(tuple(np.round(refl(a,b),6)) in F4set for a in F4 for b in F4))

# ---- link 2: E6 unfold with dead competitor ----
def cls(w):
    w=np.array(w)
    if abs(abs(w).max()-1)<1e-9: return 0
    return 1 if np.prod(np.sign(w))>0 else 2
b1=np.array([0,1,-1,0.]); b2=np.array([0,0,1,-1.])
b3=np.array([0,0,0,1.]);  b4=np.array([1,-1,-1,-1.])/2
Sm=np.array([b1,b2,b3,b4]).T
qof=lambda mu: int(round(np.linalg.solve(Sm,mu)[1]))%3
v3=[np.array([np.cos(2*np.pi*k/3), np.sin(2*np.pi*k/3)]) for k in range(3)]
def build(label):
    R=[np.concatenate([l,[0,0]]) for l in longr]
    for s in shortr:
        for eps in (1,-1):
            R.append(np.concatenate([s, eps*v3[label(np.array(s))]]))
    return np.array(R)
def closes(R):
    Rs={tuple(np.round(r,9)) for r in R}
    return len(Rs)==72 and all(abs(r@r-2)<1e-9 for r in R) and \
        all(tuple(np.round(refl(a,b),9)) in Rs for a in R for b in R) and \
        np.linalg.matrix_rank(R)==6
check("E6: orientation x glue-class doubling closes (72, len^2=2, rank 6)",
      closes(build(cls)))
check("competitor dead: orientation x charge doubling fails closure",
      not closes(build(qof)))
R=build(cls); Rset={tuple(np.round(r,9)) for r in R}
flip=lambda r: np.concatenate([r[:4],-r[4:]])
check("fold: flip is automorphism; fixed roots = the 24 bonds",
      all(tuple(np.round(flip(r),9)) in Rset for r in R) and
      sum(1 for r in R if np.allclose(r[4:],0))==24)

# ---- link 3: E6 structure ----
f=np.array([1.001,0.618,0.414,0.302,0.171,0.093])
pos=[r for r in R if f@r>0]; posset={tuple(np.round(p,9)) for p in pos}
simple=np.array([a for a in pos if not any(
    tuple(np.round(np.array(a)-b,9)) in posset
    for b in pos if not np.allclose(a,b))])
C=np.array([[round(2*float(a@b)/float(b@b)) for b in simple] for a in simple])
check("E6 Cartan matrix: node degrees {1,1,1,2,2,3}, det = 3",
      sorted((np.abs(C[i])>0).sum()-1 for i in range(6))==[1,1,1,2,2,3]
      and round(np.linalg.det(C))==3)
theta=pos[int(np.argmax([f@p for p in pos]))]
marks=np.round(np.linalg.lstsq(simple.T,theta,rcond=None)[0]).astype(int)
check("marks (1,1,2,2,2,3)", sorted(marks.tolist())==[1,1,2,2,2,3])

# ---- link 4: trinification and the flip action ----
cnode=int(np.argmax(marks)); legs=[i for i in range(6) if i!=cnode]
pairs=[]; used=set()
for i in legs:
    for j in legs:
        if j>i and C[i][j]!=0:
            pairs.append([simple[i],simple[j]]); used|={i,j}
left=[i for i in legs if i not in used]
pairs.append([simple[left[0]], -np.array(theta)])
groot=lambda p:[p[0],p[1],p[0]+p[1],-p[0],-p[1],-(p[0]+p[1])]
check("three mutually orthogonal A2's from the mark-3 deletion",
      len(pairs)==3 and
      all(round(2*float(a@b)/float(b@b))==-1 for a,b in pairs) and
      all(abs(float(x@y))<1e-9 for i in range(3) for j in range(i+1,3)
          for x in groot(pairs[i]) for y in groot(pairs[j])))
img=[]
for k in range(3):
    fr={tuple(np.round(flip(x),9)) for x in groot(pairs[k])}
    img.append([k2 for k2 in range(3)
        if fr=={tuple(np.round(x,9)) for x in groot(pairs[k2])}][0])
fixedf=[k for k in range(3) if img[k]==k]
check("orientation flip swaps two su(3)'s and fixes one",
      sorted(img)==[0,1,2] and len(fixedf)==1)
cF=fixedf[0]; sw=[k for k in range(3) if k!=cF]

# ---- link 5: the 27 ----
CM=np.array([[2*float(simple[i]@simple[j])/float(simple[j]@simple[j])
              for i in range(6)] for j in range(6)])
ends=[i for i in range(6) if (np.abs(C[i])>0).sum()-1==1]
orbit=None
for e in ends:
    om=np.linalg.solve(CM.T, np.eye(6)[e])@simple
    orb={tuple(np.round(om,9))}; fr=[om]
    while fr:
        new=[]
        for x in fr:
            for a in simple:
                y=x-round(2*float(x@a)/float(a@a))*a
                k=tuple(np.round(y,9))
                if k not in orb: orb.add(k); new.append(y)
        fr=new
    if len(orb)==27: orbit=orb; break
check("27-dimensional minuscule orbit found", orbit is not None)
w3={(1,0),(-1,1),(0,-1)}; w3b={(-a,-b) for a,b in w3}
lab=lambda mu,p: tuple(round(2*float(np.array(mu)@a)/float(a@a)) for a in p)
def rt(l):
    return '3' if l in w3 else ('3b' if l in w3b else ('1' if l==(0,0) else '?'))
tri=Counter(tuple(rt(lab(mu,pairs[k])) for k in range(3)) for mu in orbit)
check("27 = (3,3b,1)+(1,3,3b)+(3b,1,3), 9 states each",
      sorted(tri.values())==[9,9,9] and
      all(sorted(t)==['1','3','3b'] for t in tri))
check("lepton block: 9 states singlet under the flip-fixed (color) factor",
      sum(v for t,v in tri.items() if t[cF]=='1')==9)

# ---- link 6: fold consistency with the f4-level 26-branching ----
fold=Counter()
for mu in orbit:
    lc=rt(lab(mu,pairs[cF]))
    l1=lab(mu,pairs[sw[0]]); l2=lab(mu,pairs[sw[1]])
    fold[(lc,(l1[0]+l2[0], l1[1]+l2[1]))]+=1
w8=Counter([(1,1),(2,-1),(-1,2),(-2,1),(1,-2),(-1,-1),(0,0),(0,0)])
exp=Counter()
for hw in w3b:
    for _ in range(3): exp[('3',hw)]+=1
for hw in w3:
    for _ in range(3): exp[('3b',hw)]+=1
for hw,m in (w8+Counter({(0,0):1})).items(): exp[('1',hw)]+=m
check("fold of 27 = 26-branching (3,3b)+(3b,3)+(1,8) + one (1,1): "
      "the octet is the folded lepton bifundamental", fold==exp)

# ---- link 7: discriminant derivation of the class plane ----
g1=np.array([.5,.5,.5,.5]); g2=np.array([0,0,0,1.]); g3=np.array([.5,.5,.5,-.5])
inD4=lambda x: np.allclose(x,np.round(x)) and int(round(x.sum()))%2==0
check("glue classes satisfy [1]+[2]+[3]=0 (each pair sums to the third)",
      inD4(g1+g3-g2) and inD4(g1+g2-g3) and inD4(g2+g3-g1))
check("discriminant norms: all three classes have q=1",
      all(abs(float(g@g)-1)<1e-9 for g in (g1,g2,g3)))
check("unit norms + zero sum force the 120-degree plane (Gram -1/2)",
      np.allclose(sum(v3),0) and
      all(abs(float(v3[i]@v3[j])+0.5)<1e-9
          for i in range(3) for j in range(3) if i!=j))

# ---- link 8: the charge fence ----
th0=0.0
refl56=np.array([[np.cos(2*th0),np.sin(2*th0)],[np.sin(2*th0),-np.cos(2*th0)]])
Cop=np.zeros((6,6)); Cop[:3,:3]=-np.eye(3); Cop[3,3]=1; Cop[4:,4:]=refl56
check("charge conjugation (extended inversion) is an automorphism of the 72",
      all(tuple(np.round(Cop@r,9)) in Rset for r in R))
check("color factor roots have zero components in the class plane",
      all(abs(x[4])<1e-9 and abs(x[5])<1e-9 for x in groot(pairs[cF])))
# ---- link 8: the charge selected by the geometric C and P ----
# admissible charges: commute with color, odd under C, even under the flip P
Fp=np.diag([1,1,1,1,-1,-1.])
colr=groot(pairs[cF])
Madm=np.vstack([np.array(colr),Cop+np.eye(6),Fp-np.eye(6)])
radm=np.linalg.matrix_rank(Madm,1e-9); dadm=np.linalg.svd(Madm)[2][radm:]
check("admissible charges (color-commuting, X-odd, F-even) form a single ray", len(dadm)==1)
dvec=dadm[0]
u6=np.concatenate([np.array([1,1,1,0.])/np.sqrt(3),[0,0]])
check("correction: the (1,1,1,0) direction used in the first version does not commute with color",
      not np.allclose([u6@c for c in colr],0))
from fractions import Fraction as Fr
blk=lambda mu: rt(lab(mu,pairs[cF]))
lepv=[dvec@np.array(mu) for mu in orbit if blk(mu)=='1']
hQ=dvec/max(abs(x) for x in lepv)
spec={b:Counter(Fr(round(float(hQ@np.array(mu))*3),3) for mu in orbit if blk(mu)==b) for b in ('3','3b','1')}
smq=Counter({Fr(2,3):3,Fr(-1,3):6}); smqb=Counter({Fr(-2,3):3,Fr(1,3):6}); sml=Counter({Fr(-1):2,Fr(1):2,Fr(0):5})
check("on that ray the 27 carries the Standard Model trinification charges, integer unit included",
      {tuple(sorted(spec['3'].items())),tuple(sorted(spec['3b'].items()))}=={tuple(sorted(smq.items())),tuple(sorted(smqb.items()))}
      and spec['1']==sml)
if spec['3']!=smq: hQ=-hQ
# uniqueness: among all SM charge operators built from the two non-color su(3)'s, exactly +-hQ are C-odd and P-even
def cow(p):
    P=np.array(p); return [P.T@np.linalg.solve(P@P.T,np.eye(2)[i]) for i in range(2)]
wa=cow(pairs[sw[0]]); wb=cow(pairs[sw[1]]); smops=[]
for c4 in itertools.product([-1,0,1],repeat=4):
    q=c4[0]*wa[0]+c4[1]*wa[1]+c4[2]*wb[0]+c4[3]*wb[1]
    sp={b:Counter(Fr(round(float(q@np.array(mu))*3),3) for mu in orbit if blk(mu)==b) for b in ('3','3b','1')}
    if ((sp['3']==smq and sp['3b']==smqb) or (sp['3']==smqb and sp['3b']==smq)) and sp['1']==sml: smops.append(q)
sel_ok=[q for q in smops if np.allclose(Cop@q,-q) and np.allclose(Fp@q,q)]
check("of the %d Standard Model charge operators, exactly two (+-Q) are X-odd and F-even"%len(smops),
      len(sel_ok)==2 and all(np.allclose(q,hQ) or np.allclose(q,-hQ) for q in sel_ok))

# ---- revision checks (referee round 1) ----
Cexp=np.array([[2,-1,0,0,0,0],[-1,2,-1,-1,0,0],[0,-1,2,0,-1,0],[0,-1,0,2,0,-1],[0,0,-1,0,2,0],[0,0,0,-1,0,2]])
check("explicit Cartan matrix as printed in the paper", np.array_equal(C,Cexp))
fx=sum(1 for r in R if np.allclose(flip(r),r)); pr=(72-fx)//2
check("fold decomposition: 24 fixed + 24 pairs + 4 fixed-Cartan = 52 = dim F4", fx==24 and pr==24 and fx+pr+4==52)
cwQ=np.array([hQ@a for a in simple])
target=np.array([0,2/3,-1,-1,1,1])
check("the selected charge in coweights: Q = +-((2/3)w2 - w3 - w4 + w5 + w6)",
      np.allclose(cwQ,target,atol=1e-9) or np.allclose(cwQ,-target,atol=1e-9))
def vv_at(tv):
    a=np.array([1,0]); b=np.array([tv,np.sqrt(max(0,1-tv*tv))])
    try: w=np.linalg.solve(np.array([a,b]),np.array([tv,tv]))
    except Exception: return None
    return np.array([a,b,w]) if abs(w@w-1)<1e-9 else None
check("120 degrees forced: three planar unit vectors with equal pairwise dot exist only at t=-1/2",
      vv_at(-0.5) is not None and all(vv_at(tv) is None for tv in (0.5,0.0,-1/3,-1/np.sqrt(2),-0.9)))
def lab_sign(w): w=np.array(w); return 0 if abs(abs(w).max()-1)<1e-9 else (1 if w[0]>0 else 2)
def lab_idx(w):  w=np.array(w); return 0 if abs(abs(w).max()-1)<1e-9 else (1 if int(np.argmax(np.abs(w)))%2==0 else 2)
check("labeling scan: first-component-sign and index-parity doublings both fail closure",
      not closes(build(lab_sign)) and not closes(build(lab_idx)))


# ---- Section 8.1-8.2, made auditable (revision of September 2026) ----
_F=np.diag([1,1,1,1,-1,-1.]); _X=Cop.copy(); _col=np.array(groot(pairs[cF]))
_dim=lambda *Ms: 6-np.linalg.matrix_rank(np.vstack(Ms),1e-9)
check("Section 8.1: color has rank 2; the conditions leave dimensions 4, 2, 1 in turn",
      np.linalg.matrix_rank(_col)==2 and _dim(_col)==4 and _dim(_col,_X+np.eye(6))==2 and _dim(_col,_X+np.eye(6),_F-np.eye(6))==1)
check("Section 8.1: dropping either the odd or the even condition leaves a two-dimensional family",
      _dim(_col,_F-np.eye(6))==2 and _dim(_col,_X+np.eye(6))==2)
_M=np.vstack([_col,_X+np.eye(6),_F-np.eye(6)]); _r=np.linalg.matrix_rank(_M,1e-9); _d=np.linalg.svd(_M)[2][_r:][0]
_lep=[_d@np.array(mu) for mu in orbit if rt(lab(np.array(mu),pairs[cF]))=='1']; _q=_d/min(abs(x) for x in _lep if abs(x)>1e-9)
check("Section 8.1: the single normalization (smallest nonzero singlet charge = 1) gives the charge Q",
      np.allclose(_q,hQ) or np.allclose(_q,-hQ))
_M2=np.vstack([_col,_X@_F+np.eye(6),_F-np.eye(6)]); _d2=np.linalg.svd(_M2)[2][-1]
check("Section 8.2: taking FX instead of X as the odd condition gives the same ray",
      _dim(_col,_X@_F+np.eye(6),_F-np.eye(6))==1 and abs(abs(_d2@_d)-1)<1e-9)
_even_other=[sum(1 for q in smops if np.allclose(C_@q,-q) and np.allclose(E_@q,q)) for C_,E_ in ((_F,_X),(_F,_X@_F),(_X,_X@_F),(_X@_F,_X))]
check("Section 8.2: with the even condition X or FX instead of F, none of the eighteen passes",
      len(smops)==18 and all(n==0 for n in _even_other))

# ---- Section 8.3 and Table A2 (revision of September 2026) ----
import itertools as _it
_vec=[np.array(v) for v in _it.product([-1,0,1],repeat=4) if sum(abs(x) for x in v)==1]
_spin=[np.array(v)/2 for v in _it.product([-1,1],repeat=4)]
_cls=lambda v: 'v' if all(abs(x-round(x))<1e-9 for x in v) else ('s' if sum(1 for x in v if x<0)%2==0 else 'c')
_I3=np.diag([-1,-1,-1,1.])
check("Section 8.3: inverting three coordinates fixes the vector class and swaps the two spinor classes",
      all(_cls(_I3@v)=='v' for v in _vec) and all(_cls(_I3@v)!=_cls(v) for v in _spin))
_FX=_F@_X; _Rs={tuple(np.round(r,9)) for r in R}
check("Section 8.3: geometric inversion acts as FX, an automorphism of the 72, and Q is odd under it",
      all(tuple(np.round(_FX@r,9)) in _Rs for r in R) and np.allclose(_FX@hQ,-hQ))
_xo=[q for q in smops if np.allclose(_X@q,-q)]; _fe_only=[q for q in smops if np.allclose(_F@q,q) and not np.allclose(_X@q,-q)]
check("Table A2: within the eighteen, X-oddness alone singles out +-Q; four others are F-even only",
      len(_xo)==2 and all(np.allclose(q,hQ) or np.allclose(q,-hQ) for q in _xo) and len(_fe_only)==4)

check("Section 8.1: in the coordinates of Section 5, F = diag(1,1,1,1,-1,-1) and X = diag(-1,-1,-1,1,1,-1)",
      np.allclose(_F,np.diag([1,1,1,1,-1,-1.])) and np.allclose(_X,np.diag([-1,-1,-1,1,1,-1.])))

def _partial(doubled):
    Rp=[np.concatenate([l,[0,0]]) for l in longr]
    for s_ in shortr:
        k_=cls(np.array(s_))
        for eps in ((1,-1) if k_ in doubled else (1,)):
            Rp.append(np.concatenate([s_,eps*v3[k_]]))
    return np.array(Rp)
_pd=[(D,len(_partial(D)),closes(_partial(D))) for D in [(0,),(1,),(2,),(0,1),(0,2),(1,2)]]
check("Section 5: partial doublings of one or two glue classes give 56 or 64 roots and fail closure",
      all(n in (56,64) and not c for _,n,c in _pd))

_colr9=np.array(groot(pairs[cF])); _bond9=[np.array(r) for r in R if np.allclose(np.array(r)[4:],0)]
_ob=[b for b in _bond9 if all(abs(b@c)<1e-9 for c in _colr9)]; _oa=[r for r in R if all(abs(np.array(r)@c)<1e-9 for c in _colr9)]
check("Section 9: no su(2) commutes with color in the bond algebra so(8); in e6, six do, all in the swapped pair",
      len(_ob)==0 and len(_oa)==12 and all(any(np.allclose(np.array(r),x) or np.allclose(np.array(r),-x) for P_ in [pairs[k_] for k_ in sw] for x in groot(P_)) for r in _oa))

# ---- Appendix A.3: the vacuum code, rebuilt from the lattice (L = 4 torus) ----
L=4; nodes=[p for p in itertools.product(range(L),repeat=3) if sum(p)%2==0]; nid={p:i for i,p in enumerate(nodes)}
NN=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]; edges={}
for p in nodes:
    for d in NN:
        q=tuple((p[i]+d[i])%L for i in range(3)); e=frozenset((p,q))
        if e not in edges: edges[e]=len(edges)
n_code=len(edges); n=n_code; HZ=np.zeros((len(nodes),n),np.uint8)
for e,j in edges.items():
    for p in e: HZ[nid[p],j]=1
octs=[p for p in itertools.product(range(L),repeat=3) if sum(p)%2==1]; HX=np.zeros((len(octs),n),np.uint8)
for r,c in enumerate(octs):
    vs=[tuple((c[i]+s*(1 if i==a else 0))%L for i in range(3)) for a in range(3) for s in (1,-1)]
    for u,v in itertools.combinations(vs,2):
        e=frozenset((u,v))
        if e in edges: HX[r,edges[e]]=1
def rref(M):
    M=M.copy()%2; piv=[]; r=0
    for c in range(M.shape[1]):
        p=next((i for i in range(r,M.shape[0]) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(M.shape[0]):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
    return M[:r],piv
def in_rowspace(v,R,piv):
    v=v.copy()
    for row,c in zip(R,piv):
        if v[c]: v^=row
    return not v.any()
def min_logical(Hcomm,Hstab,maxw=3):
    """smallest weight vector commuting with Hcomm (zero syndrome) that is not a stabilizer (not in rowspace of Hstab)"""
    R,piv=rref(Hstab)
    for w in range(1,maxw+1):
        for idx in itertools.combinations(range(n),w):
            v=np.zeros(n,np.uint8); v[list(idx)]=1
            if not ((Hcomm.astype(int)@v)%2).any() and not in_rowspace(v,R,piv): return w
    return None

check("Appendix A.3: the FCC code on the L=4 torus has 192 edge qubits and weight-12 vertex and octahedral checks, and is CSS (H_X H_Z^T = 0)",
      n==192 and set(HZ.sum(1).tolist())=={12} and set(HX.sum(1).tolist())=={12} and not ((HX.astype(int)@HZ.T.astype(int))%2).any())
_RX,_=rref(HX); _RZ,_=rref(HZ)
check("Appendix A.3: k = n - rank H_X - rank H_Z = 130 = 2L^3 + 2", n-len(_RX)-len(_RZ)==130)
check("Appendix A.3: minimum distance 3 (no logical operator of weight 1 or 2 of either type; one of weight 3 exists)",
      min_logical(HX,HZ)==3 and min_logical(HZ,HX)==3)
print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
