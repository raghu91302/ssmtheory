#!/usr/bin/env python3
"""
Verification script for the so(8) -> f4 -> e6 chain of the
Selection-Stitch Model (computational core of the planned Paper 9):

  1. F4: bonds (24 long) + matter weights (24 short) close as F4.
  2. E6 unfold: doubling every short root by void ORIENTATION, with the
     three GLUE CLASSES at 120 degrees in a new 2-plane, closes as E6
     (72 roots, all squared length 2, rank 6, Cartan det 3).
     The charge-based doubling FAILS closure: one competitor eliminated.
  3. The fold: the orientation flip is an automorphism of the 72 whose
     fixed roots are exactly the 24 bonds: f4 is the orientation-
     symmetric shadow of e6 (and C = P is the folded statement).
  4. Trinification: deleting the mark-3 node gives three orthogonal
     su(3)'s; the orientation flip swaps two and fixes one (color).
  5. The 27 branches as (3,3b,1)+(1,3,3b)+(3b,1,3); the color-singlet
     block is the 9-dimensional lepton-family block.
  6. Fold consistency: folding the 27 under (color, diagonal of the
     swapped pair) reproduces the f4-level 26-branching
     (3,3b)+(3b,3)+(1,8) plus one extra singlet: the horizontal octet
     is the folded lepton bifundamental.

Requires numpy only.  Run: python3 verify_e6_chain.py
Expected: 12x PASS, then ALL PASS.  Runtime: ~1 minute
(the 72x72 reflection-closure tests dominate).
"""
import numpy as np, itertools
from collections import Counter

ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)

# ---- link 1: F4 from bonds + matter ----
longr=[]
for i,j in itertools.combinations(range(4),2):
    for si,sj in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v=np.zeros(4); v[i]=si; v[j]=sj; longr.append(v)
shortr=[s*np.eye(4)[i] for i in range(4) for s in(1,-1)] + \
       [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
F4=np.array(longr+shortr); F4set={tuple(np.round(r,6)) for r in F4}
refl=lambda a,x: x-2*(x@a)/(a@a)*a
check("F4: 48 roots closed under own reflections",
      all(tuple(np.round(refl(a,b),6)) in F4set for a in F4 for b in F4))

# ---- link 2: E6 unfold with dead competitor ----
def cls(w):
    w=np.array(w)
    if abs(abs(w).max()-1)<1e-9: return 0
    return 1 if np.prod(np.sign(w))>0 else 2
b1=np.array([0,1,-1,0.]); b2=np.array([0,0,1,-1.])
b3=np.array([0,0,0,1.]);  b4=np.array([1,-1,-1,-1.])/2
Sm=np.array([b1,b2,b3,b4]).T
qof=lambda mu: int(round(np.linalg.solve(Sm,mu)[1]))%3
v3=[np.array([np.cos(2*np.pi*k/3), np.sin(2*np.pi*k/3)]) for k in range(3)]
def build(label):
    R=[np.concatenate([l,[0,0]]) for l in longr]
    for s in shortr:
        for eps in (1,-1):
            R.append(np.concatenate([s, eps*v3[label(np.array(s))]]))
    return np.array(R)
def closes(R):
    Rs={tuple(np.round(r,9)) for r in R}
    return len(Rs)==72 and all(abs(r@r-2)<1e-9 for r in R) and \
        all(tuple(np.round(refl(a,b),9)) in Rs for a in R for b in R) and \
        np.linalg.matrix_rank(R)==6
check("E6: orientation x glue-class doubling closes (72, len^2=2, rank 6)",
      closes(build(cls)))
check("competitor dead: orientation x charge doubling fails closure",
      not closes(build(qof)))
R=build(cls); Rset={tuple(np.round(r,9)) for r in R}
flip=lambda r: np.concatenate([r[:4],-r[4:]])
check("fold: flip is automorphism; fixed roots = the 24 bonds",
      all(tuple(np.round(flip(r),9)) in Rset for r in R) and
      sum(1 for r in R if np.allclose(r[4:],0))==24)

# ---- link 3: E6 structure ----
f=np.array([1.001,0.618,0.414,0.302,0.171,0.093])
pos=[r for r in R if f@r>0]; posset={tuple(np.round(p,9)) for p in pos}
simple=np.array([a for a in pos if not any(
    tuple(np.round(np.array(a)-b,9)) in posset
    for b in pos if not np.allclose(a,b))])
C=np.array([[round(2*float(a@b)/float(b@b)) for b in simple] for a in simple])
check("E6 Cartan matrix: node degrees {1,1,1,2,2,3}, det = 3",
      sorted((np.abs(C[i])>0).sum()-1 for i in range(6))==[1,1,1,2,2,3]
      and round(np.linalg.det(C))==3)
theta=pos[int(np.argmax([f@p for p in pos]))]
marks=np.round(np.linalg.lstsq(simple.T,theta,rcond=None)[0]).astype(int)
check("marks (1,1,2,2,2,3)", sorted(marks.tolist())==[1,1,2,2,2,3])

# ---- link 4: trinification and the flip action ----
cnode=int(np.argmax(marks)); legs=[i for i in range(6) if i!=cnode]
pairs=[]; used=set()
for i in legs:
    for j in legs:
        if j>i and C[i][j]!=0:
            pairs.append([simple[i],simple[j]]); used|={i,j}
left=[i for i in legs if i not in used]
pairs.append([simple[left[0]], -np.array(theta)])
groot=lambda p:[p[0],p[1],p[0]+p[1],-p[0],-p[1],-(p[0]+p[1])]
check("three mutually orthogonal A2's from the mark-3 deletion",
      len(pairs)==3 and
      all(round(2*float(a@b)/float(b@b))==-1 for a,b in pairs) and
      all(abs(float(x@y))<1e-9 for i in range(3) for j in range(i+1,3)
          for x in groot(pairs[i]) for y in groot(pairs[j])))
img=[]
for k in range(3):
    fr={tuple(np.round(flip(x),9)) for x in groot(pairs[k])}
    img.append([k2 for k2 in range(3)
        if fr=={tuple(np.round(x,9)) for x in groot(pairs[k2])}][0])
fixedf=[k for k in range(3) if img[k]==k]
check("orientation flip swaps two su(3)'s and fixes one",
      sorted(img)==[0,1,2] and len(fixedf)==1)
cF=fixedf[0]; sw=[k for k in range(3) if k!=cF]

# ---- link 5: the 27 ----
CM=np.array([[2*float(simple[i]@simple[j])/float(simple[j]@simple[j])
              for i in range(6)] for j in range(6)])
ends=[i for i in range(6) if (np.abs(C[i])>0).sum()-1==1]
orbit=None
for e in ends:
    om=np.linalg.solve(CM.T, np.eye(6)[e])@simple
    orb={tuple(np.round(om,9))}; fr=[om]
    while fr:
        new=[]
        for x in fr:
            for a in simple:
                y=x-round(2*float(x@a)/float(a@a))*a
                k=tuple(np.round(y,9))
                if k not in orb: orb.add(k); new.append(y)
        fr=new
    if len(orb)==27: orbit=orb; break
check("27-dimensional minuscule orbit found", orbit is not None)
w3={(1,0),(-1,1),(0,-1)}; w3b={(-a,-b) for a,b in w3}
lab=lambda mu,p: tuple(round(2*float(np.array(mu)@a)/float(a@a)) for a in p)
def rt(l):
    return '3' if l in w3 else ('3b' if l in w3b else ('1' if l==(0,0) else '?'))
tri=Counter(tuple(rt(lab(mu,pairs[k])) for k in range(3)) for mu in orbit)
check("27 = (3,3b,1)+(1,3,3b)+(3b,1,3), 9 states each",
      sorted(tri.values())==[9,9,9] and
      all(sorted(t)==['1','3','3b'] for t in tri))
check("lepton block: 9 states singlet under the flip-fixed (color) factor",
      sum(v for t,v in tri.items() if t[cF]=='1')==9)

# ---- link 6: fold consistency with the f4-level 26-branching ----
fold=Counter()
for mu in orbit:
    lc=rt(lab(mu,pairs[cF]))
    l1=lab(mu,pairs[sw[0]]); l2=lab(mu,pairs[sw[1]])
    fold[(lc,(l1[0]+l2[0], l1[1]+l2[1]))]+=1
w8=Counter([(1,1),(2,-1),(-1,2),(-2,1),(1,-2),(-1,-1),(0,0),(0,0)])
exp=Counter()
for hw in w3b:
    for _ in range(3): exp[('3',hw)]+=1
for hw in w3:
    for _ in range(3): exp[('3b',hw)]+=1
for hw,m in (w8+Counter({(0,0):1})).items(): exp[('1',hw)]+=m
check("fold of 27 = 26-branching (3,3b)+(3b,3)+(1,8) + one (1,1): "
      "the octet is the folded lepton bifundamental", fold==exp)

print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
