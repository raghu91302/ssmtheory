Verification scripts for the so(8) -> f4 -> e6 chain of the
Selection-Stitch Model (computational core of the planned Paper 9:
the E6 unfold, trinification, and the lepton families).

Contents:
  verify_e6_chain.py   reproduces the full chain in 12 labeled checks:
                       F4 closure; the E6 unfold by void orientation x
                       glue class (with the charge-based competitor
                       shown to fail); the fold (flip automorphism,
                       fixed part = bonds); E6 Cartan matrix and marks;
                       trinification; the flip's swap-two-fix-one
                       action; the 27 and its branching; the lepton
                       block; and the fold consistency with the
                       f4-level 26-branching (octet = folded leptons).

Requirements: Python 3 with numpy. No other dependencies.
Run:          python3 verify_e6_chain.py
Expected:     12x PASS, then ALL PASS.
Runtime:      about one minute.
