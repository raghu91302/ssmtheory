Verification scripts for the so(8) -> f4 -> e6 chain of the
Selection-Stitch Model (companion to the paper
"From F4 to E6: The Worldline Unfolds the Vacuum - Chirality, Lepton
Families, and Trinification", R. Kulkarni, 2026).

Contents:
  verify_e6_chain.py   reproduces the full chain in 18 labeled checks:
                       F4 closure; the E6 unfold by void orientation x
                       glue class (with the charge-based competitor
                       shown to fail); the fold (flip automorphism,
                       fixed part = bonds); E6 Cartan matrix and marks;
                       trinification; the flip's swap-two-fix-one
                       action; the 27 and its branching; the lepton
                       block; and the fold consistency with the
                       f4-level 26-branching (octet = folded leptons); the discriminant
                       derivation of the class plane; and the charge
                       fence (C as an automorphism, the admissible ray,
                       and the no-solution scan).

Requirements: Python 3 with numpy. No other dependencies.
Run:          python3 verify_e6_chain.py
Expected:     18x PASS, then ALL PASS.
Runtime:      about one minute.
