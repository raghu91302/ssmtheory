#!/usr/bin/env python3
"""
Independent check of Section 8 (Theorem 7) of "From F4 to E6"
(R. Kulkarni, Symmetry manuscript symmetry-4567866), October 2026.

This script shares no code with verify_e6_chain.py. It rebuilds the 72
roots from their definition and works in exact rational arithmetic:
the sixth coordinate y is stored as t = 2y/sqrt(3), so every number is
a Fraction and the inner product is
   (a,b) = a1 b1 + ... + a5 b5 + (3/4) t_a t_b .
Requires the Python standard library only.  Run: python3 verify_sec8_exact.py
Expected: 15x PASS, then ALL PASS (a few seconds).
"""
import itertools
from fractions import Fraction as Fr
from collections import Counter

ok=True
def check(name,cond):
    global ok; print(("PASS  " if cond else "FAIL  ")+name); ok&=bool(cond)

H=Fr(1,2)
def dot(a,b): return sum(a[i]*b[i] for i in range(5))+Fr(3,4)*a[5]*b[5]
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def mul(k,a): return tuple(k*x for x in a)
def refl(a,x): return sub(x,mul(2*dot(x,a)/dot(a,a),a))
# class-plane vectors at 120 degrees: (1,0), (-1/2, sqrt3/2), (-1/2,-sqrt3/2) -> t = 0, 1, -1
V3=[(Fr(1),Fr(0)),(-H,Fr(1)),(-H,Fr(-1))]
def cls(s):
    if max(abs(x) for x in s)==1: return 0
    return 1 if sum(1 for x in s if x<0)%2==0 else 2
longr=[]
for i,j in itertools.combinations(range(4),2):
    for a,b in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v=[Fr(0)]*6; v[i]=Fr(a); v[j]=Fr(b); longr.append(tuple(v))
shortr=[tuple(Fr(s) if k==i else Fr(0) for k in range(4)) for i in range(4) for s in (1,-1)]+\
       [tuple(x*H for x in s) for s in itertools.product([1,-1],repeat=4)]
R=list(longr)
for s in shortr:
    for e in (1,-1):
        c=V3[cls(s)]; R.append(tuple(s)+(e*c[0],e*c[1]))
Rset=set(R)
def rank(vs):
    M=[list(v) for v in vs]; r=0; cols=len(M[0]) if M else 0
    for c in range(cols):
        p=next((i for i in range(r,len(M)) if M[i][c]!=0),None)
        if p is None: continue
        M[r],M[p]=M[p],M[r]
        for i in range(len(M)):
            if i!=r and M[i][c]!=0:
                f=M[i][c]/M[r][c]; M[i]=[x-f*y for x,y in zip(M[i],M[r])]
        r+=1
    return r
def nullspace(rows,n=6):
    M=[list(r) for r in rows]; piv=[]; r=0
    for c in range(n):
        p=next((i for i in range(r,len(M)) if M[i][c]!=0),None)
        if p is None: continue
        M[r],M[p]=M[p],M[r]; M[r]=[x/M[r][c] for x in M[r]]
        for i in range(len(M)):
            if i!=r and M[i][c]!=0:
                f=M[i][c]; M[i]=[x-f*y for x,y in zip(M[i],M[r])]
        piv.append(c); r+=1
    free=[c for c in range(n) if c not in piv]; basis=[]
    for fcol in free:
        v=[Fr(0)]*n; v[fcol]=Fr(1)
        for k,pc in enumerate(piv): v[pc]=-M[k][fcol]
        basis.append(tuple(v))
    return basis
# the inner product is not the Euclidean one in these coordinates; a linear
# condition "h orthogonal to x" reads sum_i h_i G_ii x_i = 0 with G = diag(1,1,1,1,1,3/4)
G=(1,1,1,1,1,Fr(3,4))
def orth_row(x): return tuple(G[i]*x[i] for i in range(6))

check("the 72 roots: 72 distinct vectors of squared length 2, rank 6",
      len(Rset)==72 and all(dot(r,r)==2 for r in R) and rank(R)==6)
check("the 72 roots are closed under all 72 x 72 reflections (exact)",
      all(refl(a,b) in Rset for a in R for b in R))
# printed simple roots (sixth coordinate converted to t = 2y/sqrt3)
al=[(0,1,-1,0,0,0),(0,0,1,-1,0,0),(H,-H,-H,H,-H,1),(H,-H,-H,H,H,-1),(-H,H,H,H,-H,-1),(-H,H,H,H,H,1)]
al=[tuple(Fr(x) for x in a) for a in al]
A=[[2*dot(a,b)/dot(b,b) for b in al] for a in al]
Aexp=[[2,-1,0,0,0,0],[-1,2,-1,-1,0,0],[0,-1,2,0,-1,0],[0,-1,0,2,0,-1],[0,0,-1,0,2,0],[0,0,0,-1,0,2]]
check("printed simple roots give the printed Cartan matrix",A==Aexp)
# express each root in simple roots: solve via Gram system
def coords(x):
    Gm=[[dot(a,b) for b in al]+[dot(a,x)] for a in al]
    n=6
    for c in range(n):
        p=next(i for i in range(c,n) if Gm[i][c]!=0); Gm[c],Gm[p]=Gm[p],Gm[c]
        Gm[c]=[v/Gm[c][c] for v in Gm[c]]
        for i in range(n):
            if i!=c and Gm[i][c]!=0:
                f=Gm[i][c]; Gm[i]=[v-f*w for v,w in zip(Gm[i],Gm[c])]
    return [Gm[i][n] for i in range(n)]
cf=[coords(r) for r in R]
check("every root is an integer combination of the simple roots, all of one sign",
      all(all(c.denominator==1 for c in v) and (all(c>=0 for c in v) or all(c<=0 for c in v)) for v in cf))
F=lambda x: x[:4]+(-x[4],-x[5])
X=lambda x: (-x[0],-x[1],-x[2],x[3],x[4],-x[5])
check("F = diag(1,1,1,1,-1,-1) and X = diag(-1,-1,-1,1,1,-1) are automorphisms of the 72",
      all(F(r) in Rset for r in R) and all(X(r) in Rset for r in R))
# trinification: delete the mark-3 node from the extended diagram
pos=[r for r,c in zip(R,cf) if all(x>=0 for x in c)]
theta=max(pos,key=lambda r: sum(coords(r))); marks=coords(theta)
cn=marks.index(3); ext=[al[i] for i in range(6) if i!=cn]+[mul(-1,theta)]
adj={i:[j for j in range(6) if j!=i and dot(ext[i],ext[j])!=0] for i in range(6)}
comps=[];seen=set()
for i in range(6):
    if i in seen: continue
    st=[i];c=set()
    while st:
        k=st.pop()
        if k not in c: c.add(k); st+=adj[k]
    seen|=c; comps.append(sorted(c))
fac=[{ext[c[0]],ext[c[1]],add(ext[c[0]],ext[c[1]]),mul(-1,ext[c[0]]),mul(-1,ext[c[1]]),mul(-1,add(ext[c[0]],ext[c[1]]))} for c in comps]
fixed=[f for f in fac if {F(x) for x in f}==f]
check("mark-3 deletion gives three A2 factors; the flip F fixes exactly one",len(fac)==3 and len(fixed)==1)
col=fixed[0]
colexp={mul(s,tuple(Fr(x) for x in v)) for v in [(0,1,-1,0,0,0),(1,1,0,0,0,0),(1,0,1,0,0,0)] for s in (1,-1)}
check("the flip-fixed (color) factor has roots +-(e2-e3), +-(e1+e2), +-(e1+e3)",col==colexp)
colb=[tuple(Fr(x) for x in (0,1,-1,0,0,0)),tuple(Fr(x) for x in (-1,-1,0,0,0,0))]   # a simple system of color
e12=tuple(Fr(x) for x in (1,1,0,0,0,0))
I6=[tuple(Fr(1) if i==j else Fr(0) for j in range(6)) for i in range(6)]
rowsA=[orth_row(x) for x in colb]
rowsB=[tuple(X(e)[i]+e[i] for e in I6) for i in range(6)]   # (X+1)h = 0
rowsC=[tuple(F(e)[i]-e[i] for e in I6) for i in range(6)]   # (F-1)h = 0
dims=[len(nullspace(rowsA)),len(nullspace(rowsA+rowsB)),len(nullspace(rowsA+rowsB+rowsC))]
check("Theorem 7: conditions (a), (a)+(b), (a)+(b)+(c) leave dimensions 4, 2, 1",dims==[4,2,1])
check("Theorem 7: dropping (b) or dropping (c) leaves dimension 2",
      len(nullspace(rowsA+rowsC))==2 and len(nullspace(rowsA+rowsB))==2)
ray=nullspace(rowsA+rowsB+rowsC)[0]
check("Theorem 7: the selected line is spanned by c = -e1+e2+e3",
      rank([ray,tuple(Fr(x) for x in (-1,1,1,0,0,0))])==1)
# 27: Weyl orbit of the fundamental weight of an end node of mark 1
Ginv_rows=[]
def fund_weight(k):
    # omega_k with (omega_k, alpha_j) = delta_kj; solve in coordinates via the Gram matrix
    n=6; Gm=[[dot(al[i],al[j]) for j in range(n)]+[Fr(1 if i==k else 0)] for i in range(n)]
    for c in range(n):
        p=next(i for i in range(c,n) if Gm[i][c]!=0); Gm[c],Gm[p]=Gm[p],Gm[c]
        Gm[c]=[v/Gm[c][c] for v in Gm[c]]
        for i in range(n):
            if i!=c and Gm[i][c]!=0:
                f=Gm[i][c]; Gm[i]=[v-f*w for v,w in zip(Gm[i],Gm[c])]
    co=[Gm[i][n] for i in range(n)]
    v=tuple(Fr(0) for _ in range(6))
    for i in range(n): v=add(v,mul(co[i],al[i]))
    return v
minus=[i for i in range(6) if marks[i]==1]
om=fund_weight(minus[0]); orb={om}; fr=[om]
while fr:
    nf=[]
    for x in fr:
        for a in al:
            y=refl(a,x)
            if y not in orb: orb.add(y); nf.append(y)
    fr=nf
check("the Weyl orbit of a mark-1 fundamental weight has 27 elements",len(orb)==27)
Q=mul(Fr(2,3),tuple(Fr(x) for x in (-1,1,1,0,0,0)))
Qof=lambda mu: dot(Q,mu)
lab=lambda mu: tuple(2*dot(mu,b)/dot(b,b) for b in colb)
blk=lambda mu: '1' if lab(mu)==(0,0) else ('A' if lab(mu) in {(1,0),(-1,1),(0,-1)} else 'B')
spec={b:Counter(Qof(mu) for mu in orb if blk(mu)==b) for b in 'AB1'}
up=Counter({Fr(2,3):3,Fr(-1,3):6}); anti=Counter({Fr(-2,3):3,Fr(1,3):6})
check("Theorem 7: Q = (2/3)(-mu1+mu2+mu3) gives +2/3 x3, -1/3 x6 in one colored block, the conjugates in the other, and -1 x2, 0 x5, +1 x2 on the singlets",
      {frozenset(spec['A'].items()),frozenset(spec['B'].items())}=={frozenset(up.items()),frozenset(anti.items())}
      and spec['1']==Counter({Fr(-1):2,Fr(0):5,Fr(1):2})
      and all(Qof(mu)==Fr(2,3)*(-mu[0]+mu[1]+mu[2]) for mu in orb))
check("Theorem 7: the pairings of Q with the printed simple roots are (0, 2/3, -1, -1, 1, 1)",
      [dot(Q,a) for a in al]==[0,Fr(2,3),-1,-1,1,1])
acc=tuple(Fr(x) for x in (2,2,2,0,0,0))
check("correction: the first version's vector (2,2,2,0;0,0) pairs to 4 with the color root e1+e2, violating (a)",
      dot(acc,e12)==4 and [dot(acc,a) for a in al]==[0,2,-1,-1,1,1])
w=lambda x: (-x[0],x[1],x[2],x[3],x[4],-x[5])
geo={mul(s,tuple(Fr(x) for x in v)) for v in [(1,-1,0,0,0,0),(0,1,-1,0,0,0),(1,0,-1,0,0,0)] for s in (1,-1)}
geob=[tuple(Fr(x) for x in (1,-1,0,0,0,0)),tuple(Fr(x) for x in (0,1,-1,0,0,0))]
rayg=nullspace([orth_row(x) for x in geob]+rowsB+rowsC)
Qg=w(Q)
check("frame independence: w = diag(-1,1,1,1,1,-1) is an automorphism of the 72 commuting with F and X, maps color to the geometric A2, and the conditions with the geometric A2 select w(c) = (1,1,1,0;0,0) with the same charges on the 27",
      all(w(r) in Rset for r in R) and all(w(F(r))==F(w(r)) and w(X(r))==X(w(r)) for r in R)
      and {w(x) for x in col}==geo and len(rayg)==1 and rank([rayg[0],w(tuple(Fr(x) for x in (-1,1,1,0,0,0)))])==1
      and Counter(dot(Qg,mu) for mu in orb)==Counter(dot(Q,mu) for mu in orb))
print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
