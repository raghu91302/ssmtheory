Verification script for "From F4 to E6" (R. Kulkarni, 2026; Symmetry
manuscript symmetry-4567866, revision 1).
Run: python3 verify_e6_chain.py   Requires numpy.
Expected: 23x PASS then ALL PASS (~1 min). Checks 19-23 are the
referee-round additions: the printed Cartan matrix, the 24+24+4=52
fold decomposition, the integer coweight fence ray, the forced 120
degrees, and the extended labeling scan.
