Verification script for "From F4 to E6" (R. Kulkarni, 2026; Symmetry
manuscript symmetry-4567866). Corrected version.
Run: python3 verify_e6_chain.py   Requires numpy.
Expected: 26x PASS then ALL PASS (~1 min).

Correction. The first version's link 8 ("the charge fence") scanned the
direction (1,1,1,0), which does not commute with the flip-fixed color
factor, and concluded that no admissible Cartan charge supplies the
integer unit. That conclusion was wrong. Link 8 now computes the
admissible charges directly: those commuting with color, odd under the
geometric C and even under the flip P form a single ray; on it the 27
carries the Standard Model trinification charges, integer unit included;
and of the 18 Standard Model charge operators built from the two
non-color su(3) factors, exactly two (+-Q) satisfy the geometric C and P.
In the fundamental-coweight basis, Q = +-((2/3)w2 - w3 - w4 + w5 + w6).
One check records the error explicitly: the (1,1,1,0) direction used in
the first version does not commute with color.
