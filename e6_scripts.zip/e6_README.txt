Verification script for "From F4 to E6" (R. Kulkarni, 2026; Symmetry
manuscript symmetry-4567866). Revised version, September 2026.

Run:       python3 verify_e6_chain.py        Requires numpy only.
Expected:  42x PASS, then ALL PASS (about one minute).

Correction. The first version's charge section scanned the direction
(1,1,1,0), which does not commute with the flip-fixed color factor, and
concluded that no admissible Cartan charge supplies the integer unit.
That conclusion was wrong. Section 8 now computes the admissible charges
directly. With F the orientation flip and X the extended inversion, the
Cartan charges that commute with color, are odd under X and even under
F form a single ray; on it the 27 carries the Standard Model
trinification charges, integer unit included. Of the 18 operators built
from the two non-color su(3) factors that reproduce that spectrum,
exactly two (+-Q) pass. In the fundamental-coweight basis,
Q = +-((2/3)w2 - w3 - w4 + w5 + w6). Check 21 records the error
explicitly: the (1,1,1,0) direction does not commute with color.

Checks, with the theorem or section each supports:

 1  Theorem 1 (Section 3)      Theorem 1: inversion through a node maps every tetrahedral void onto a void of the other orientation; o_A + o_C = 2 o_B
 2  Theorem 2 (Section 4)      Theorem 2: sigma_y is the unique Pauli generator odd under P and even under PT
 3  Section 5; Appendix A.1    F4: 48 roots closed under own reflections
 4  Theorem 3 (Section 5)      E6: orientation x glue-class doubling closes (72, len^2=2, rank 6)
 5  Theorem 3 (Section 5)      competitor dead: orientation x charge doubling fails closure
 6  Theorem 4 (Section 5)      fold: flip is automorphism; fixed roots = the 24 bonds
 7  Theorem 3 (Section 5)      E6 Cartan matrix: node degrees {1,1,1,2,2,3}, det = 3
 8  Theorem 3 (Section 5)      marks (1,1,2,2,2,3)
 9  Theorem 5 (Section 6)      three mutually orthogonal A2's from the mark-3 deletion
10  Theorem 5 (Section 6)      orientation flip swaps two su(3)'s and fixes one
11  Theorem 6 (Section 7)      27-dimensional minuscule orbit found
12  Theorem 6 (Section 7)      27 = (3,3b,1)+(1,3,3b)+(3b,1,3), 9 states each
13  Theorem 6 (Section 7)      lepton block: 9 states singlet under the flip-fixed (color) factor
14  Theorem 6 (Section 7)      fold of 27 = 26-branching (3,3b)+(3b,3)+(1,8) + one (1,1): the octet is the folded lepton bifundamental
15  Section 5; Appendix A.1    glue classes satisfy [1]+[2]+[3]=0 (each pair sums to the third)
16  Section 5; Appendix A.1    discriminant norms: all three classes have q=1
17  Section 5                  unit norms + zero sum force the 120-degree plane (Gram -1/2)
18  Section 8.1                charge conjugation (extended inversion) is an automorphism of the 72
19  Section 8.1                color factor roots have zero components in the class plane
20  Section 8.1                admissible charges (color-commuting, X-odd, F-even) form a single ray
21  Section 8 (correction)     correction: the (1,1,1,0) direction used in the first version does not commute with color
22  Section 8.1                on that ray the 27 carries the Standard Model trinification charges, integer unit included
23  Section 8.2                of the 18 Standard Model charge operators, exactly two (+-Q) are X-odd and F-even
24  Section 5                  explicit Cartan matrix as printed in the paper
25  Theorem 4 (Section 5)      fold decomposition: 24 fixed + 24 pairs + 4 fixed-Cartan = 52 = dim F4
26  Section 8.1                the selected charge in coweights: Q = +-((2/3)w2 - w3 - w4 + w5 + w6)
27  Section 5                  120 degrees forced: three planar unit vectors with equal pairwise dot exist only at t=-1/2
28  Section 5                  labeling scan: first-component-sign and index-parity doublings both fail closure
29  Section 8.1                Section 8.1: color has rank 2; the conditions leave dimensions 4, 2, 1 in turn
30  Section 8.1                Section 8.1: dropping either the odd or the even condition leaves a two-dimensional family
31  Section 8.1                Section 8.1: the single normalization (smallest nonzero singlet charge = 1) gives the charge Q
32  Section 8.2                Section 8.2: taking FX instead of X as the odd condition gives the same ray
33  Section 8.2                Section 8.2: with the even condition X or FX instead of F, none of the eighteen passes
34  Section 8.3                Section 8.3: inverting three coordinates fixes the vector class and swaps the two spinor classes
35  Section 8.3                Section 8.3: geometric inversion acts as FX, an automorphism of the 72, and Q is odd under it
36  Table A2 (Appendix A.4)    Table A2: within the eighteen, X-oddness alone singles out +-Q; four others are F-even only
37  Section 8.1                Section 8.1: in the coordinates of Section 5, F = diag(1,1,1,1,-1,-1) and X = diag(-1,-1,-1,1,1,-1)
38  Section 5                  Section 5: partial doublings of one or two glue classes give 56 or 64 roots and fail closure
39  Section 9                  Section 9: no su(2) commutes with color in the bond algebra so(8); in e6, six do, all in the swapped pair
40  Appendix A.3               Appendix A.3: the FCC code on the L=4 torus has 192 edge qubits and weight-12 checks, and is CSS
41  Appendix A.3               Appendix A.3: k = n - rank H_X - rank H_Z = 130 = 2L^3 + 2
42  Appendix A.3               Appendix A.3: minimum distance 3 (no logical of weight 1 or 2; one of weight 3)
