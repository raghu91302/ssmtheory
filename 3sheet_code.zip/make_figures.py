"""Figures for the revised three-sheet multiplexing paper.

fig1_triad.pdf      the triad decomposition and shared-ancilla layout
fig2_tradeoff.pdf   the headline: 33% qubit saving vs 1.3x threshold cost
fig3_scaling.pdf    sub-threshold distance scaling, with binomial error bars
"""
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 9,
    "axes.linewidth": 0.8, "axes.labelsize": 9, "axes.titlesize": 9.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8,
    "legend.frameon": False, "pdf.fonttype": 42,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})

C_XY, C_XZ, C_YZ = "#c0392b", "#1e8449", "#1a6fb5"
C_MUX, C_SEP, C_GRAY = "#117733", "#888888", "#95a5a6"

# ---------------------------------------------------------------- data
SHOTS = {4: 30000, 6: 30000, 8: 20000}
KLOG = {4: 8, 6: 12, 8: 16}
RATES = {
    4: {1e-4: 3.6667e-4, 3e-4: 1.0208e-3, 5e-4: 2.0167e-3, 1e-3: 5.0000e-3,
        2e-3: 1.3137e-2, 3e-3: 2.4842e-2, 5e-3: 5.6688e-2},
    6: {1e-4: 5.5556e-6, 3e-4: 2.5000e-5, 5e-4: 1.2500e-4, 1e-3: 4.0556e-4,
        2e-3: 2.6472e-3, 3e-3: 7.8528e-3, 5e-3: 3.0172e-2},
    8: {5e-4: 1.5625e-5, 1e-3: 7.1875e-5,
        2e-3: 6.6250e-4, 3e-3: 2.9094e-3, 5e-3: 1.9609e-2},
}


# 95% shot-level bootstrap intervals from bootstrap_stats.py, as reported in
# Table 6 of the manuscript. Asymmetric, so stored as (low, high).
BOOT = {
    4: {1e-4: (2.87e-4, 4.46e-4), 3e-4: (8.96e-4, 1.146e-3),
        5e-4: (1.833e-3, 2.208e-3), 1e-3: (4.721e-3, 5.300e-3),
        2e-3: (1.266e-2, 1.365e-2), 3e-3: (2.418e-2, 2.552e-2),
        5e-3: (5.569e-2, 5.769e-2)},
    6: {1e-4: (0.0, 1.389e-5), 3e-4: (1.111e-5, 4.167e-5),
        5e-4: (9.167e-5, 1.639e-4), 1e-3: (3.389e-4, 4.722e-4),
        2e-3: (2.475e-3, 2.822e-3), 3e-3: (7.553e-3, 8.153e-3),
        5e-3: (2.957e-2, 3.079e-2)},
    8: {5e-4: (3.125e-6, 3.125e-5), 1e-3: (4.375e-5, 1.000e-4),
        2e-3: (5.781e-4, 7.531e-4), 3e-3: (2.725e-3, 3.106e-3),
        5e-3: (1.905e-2, 2.013e-2)},
}


def err(L, p):
    """Asymmetric bootstrap error bar about the point estimate."""
    v = RATES[L][p]
    lo, hi = BOOT[L][p]
    return max(v - lo, 0.0), max(hi - v, 0.0)


# ---------------------------------------------------------------- fig 1
def fig_triad():
    """Panels (a) and (b) follow build_construction_fig.py from the original
    release: true 3D so the three sheets are visibly orthogonal. A 2D
    projection collapses S_xz onto S_yz and is misleading. Panel (c) is the
    multiplex cycle, which is this paper's subject."""
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    from itertools import combinations

    sheet = {"xy": [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0)],
             "xz": [(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1)],
             "yz": [(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]}
    col = {"xy": C_XY, "xz": C_XZ, "yz": C_YZ}
    lab = {"xy": r"$S_{xy}$: $(\pm1,\pm1,0)$",
           "xz": r"$S_{xz}$: $(\pm1,0,\pm1)$",
           "yz": r"$S_{yz}$: $(0,\pm1,\pm1)$"}
    allv = sum(sheet.values(), [])

    fig = plt.figure(figsize=(7.2, 2.55))

    # (a) cuboctahedral K = 12 neighborhood
    ax = fig.add_subplot(131, projection="3d")
    for v in allv:
        ax.plot([0, v[0]], [0, v[1]], [0, v[2]], color="#8a8a8a", lw=1.1,
                alpha=0.9)
        ax.scatter(*v, s=22, facecolor="white", edgecolor="black",
                   lw=0.7, depthshade=False, zorder=4)
    for tri in combinations(allv, 3):
        a, b, c = (np.array(x) for x in tri)
        if all(abs(np.linalg.norm(u - w) - np.sqrt(2)) < 0.1
               for u, w in ((a,b), (b,c), (a,c))):
            ax.add_collection3d(Poly3DCollection([tri], alpha=0.05,
                                facecolor="#3498db", edgecolor="none"))
    ax.scatter(0, 0, 0, s=55, color="black", depthshade=False, zorder=6)
    ax.set_axis_off(); ax.set_box_aspect([1, 1, 1])
    ax.view_init(elev=35, azim=45)
    ax.set_title("(a) $K=12$ neighborhood", y=0.97, fontsize=9)

    # (b) the three triad sheets
    ax = fig.add_subplot(132, projection="3d")
    for s_, disps in sheet.items():
        for v in disps:
            ax.plot([0, v[0]], [0, v[1]], [0, v[2]], color=col[s_], lw=2.0)
            ax.scatter(*v, s=20, facecolor="white", edgecolor=col[s_],
                       lw=0.8, depthshade=False, zorder=4)
    ax.scatter(0, 0, 0, s=55, color="black", depthshade=False, zorder=6)
    ax.set_axis_off(); ax.set_box_aspect([1, 1, 1])
    ax.view_init(elev=35, azim=45)
    ax.set_title("(b) Three triad sheets", y=0.97, fontsize=9)
    handles = [plt.Line2D([0], [0], color=col[s_], lw=2, label=lab[s_])
               for s_ in ("xy", "xz", "yz")]
    ax.legend(handles=handles, loc="lower center", fontsize=6.4,
              bbox_to_anchor=(0.5, -0.10), handlelength=1.2,
              labelspacing=0.22)

    # (c) the multiplex cycle
    ax = fig.add_subplot(133)
    names = [r"$S_{xy}$", r"$S_{xz}$", r"$S_{yz}$"]
    cols = [C_XY, C_XZ, C_YZ]
    for r in range(3):
        for s_ in range(3):
            active = (r == s_)
            ax.add_patch(plt.Rectangle((r, 2 - s_), 0.92, 0.82,
                         facecolor=cols[s_] if active else "#eeeeee",
                         edgecolor="#666666", lw=0.6,
                         alpha=0.85 if active else 1.0))
            ax.text(r + 0.46, 2 - s_ + 0.41,
                    "measure" if active else "idle\n$2p$",
                    ha="center", va="center", fontsize=6.4,
                    color="white" if active else "#666666")
    for s_ in range(3):
        ax.text(-0.10, 2 - s_ + 0.41, names[s_], ha="right", va="center",
                fontsize=8, color=cols[s_])
    for r in range(3):
        ax.text(r + 0.46, -0.20, f"round {r+1}", ha="center", fontsize=6.8)
    ax.set_xlim(-0.75, 3.05); ax.set_ylim(-0.55, 3.05)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_title("(c) Three-round multiplex cycle", y=0.97, fontsize=9)

    fig.subplots_adjust(wspace=0.02, left=0.0, right=1.0, top=0.99,
                        bottom=0.01)
    fig.savefig("fig1_triad.pdf")
    plt.close(fig)
    print("  fig1_triad.pdf")


# ---------------------------------------------------------------- fig 2
def fig_tradeoff():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 2.9))

    Ls = np.array([4, 6, 8])
    mux = 4 * Ls ** 3
    sep = 6 * Ls ** 3
    w = 0.34
    x = np.arange(len(Ls))
    ax1.bar(x - w/2, sep, w, color=C_SEP, edgecolor='black', lw=0.5,
            label=r"three separate blocks, $6L^3$")
    ax1.bar(x + w/2, mux, w, color=C_MUX, edgecolor='black', lw=0.5,
            label=r"ancilla-shared multiplex, $4L^3$")
    for i, (a, b) in enumerate(zip(sep, mux)):
        ax1.text(i, max(a, b) * 1.06, f"$-${(1-b/a):.0%}", ha='center',
                 fontsize=8, color=C_MUX)
    ax1.set_xticks(x); ax1.set_xticklabels([f"$L={L}$" for L in Ls])
    ax1.set_ylabel("physical qubits (data + ancilla)")
    ax1.set_title("(a) Ancilla sharing saves one third")
    ax1.set_ylim(0, sep.max() * 1.25)
    ax1.legend(loc="upper left")

    # threshold against the idle ratio: all four measured points
    ratios = [0, 1, 2, 4]
    vals = [1.13, 0.97, 0.86, 0.71]
    errs = [0.08, 0.08, 0.06, 0.05]
    cols = [C_SEP, '#7fb069', C_MUX, '#0b5d2e']
    xs = range(len(ratios))
    ax2.bar(xs, vals, 0.62, yerr=errs, capsize=4, color=cols,
            edgecolor='black', lw=0.5)
    for i, (v, e) in enumerate(zip(vals, errs)):
        ax2.text(i, v + e + 0.035, f"{v:.2f}", ha='center', fontsize=8)
    ax2.annotate("", xy=(2, 1.36), xytext=(0, 1.36),
                 arrowprops=dict(arrowstyle='<->', color='#555555', lw=0.9))
    ax2.text(1.0, 1.385, r"$1.3\times$ across the cycle", ha='center',
             fontsize=7.5, color='#555555')
    ax2.set_xticks(list(xs))
    ax2.set_xticklabels([r"$r=0$" + "\nno idle", r"$r=1$", r"$r=2$" + "\ncycle",
                         r"$r=4$"], fontsize=7.5)
    ax2.set_xlabel(r"idle-to-gate ratio $r = p_{\mathrm{idle}}/p_{2q}$",
                   fontsize=8)
    ax2.set_ylabel("simulated threshold (%)")
    ax2.set_title("(b) The price: threshold")
    ax2.set_ylim(0, 1.56)

    for ax in (ax1, ax2):
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(alpha=0.25, axis='y')
    fig.tight_layout(w_pad=2.0)
    fig.savefig("fig2_tradeoff.pdf")
    plt.close(fig)
    print("  fig2_tradeoff.pdf")


# ---------------------------------------------------------------- fig 3
def fig_scaling():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 2.9))
    cols = {4: '#1a6fb5', 6: '#117733', 8: '#c0392b'}
    marks = {4: 'o', 6: 's', 8: '^'}

    for L in (4, 6, 8):
        ps = sorted(RATES[L])
        y = [RATES[L][p] for p in ps]
        lo = [err(L, p)[0] for p in ps]
        hi = [err(L, p)[1] for p in ps]
        ax1.errorbar([p * 100 for p in ps], y, yerr=[lo, hi], fmt=marks[L] + '-',
                     color=cols[L], ms=4.5, lw=1.5, capsize=2.5,
                     label=f"$L={L}$")
    # No threshold marker here: the measured threshold is 0.86%, off the
    # right edge of this sweep, which reaches only 0.5%. The whole panel is
    # sub-threshold by construction; see Table 4 for the crossings.
    ax1.text(0.011, 1.6e-2, "entire sweep is below\nthreshold (0.86%)",
             fontsize=6.8, color='#666666', va='top')
    ax1.set_xscale('log'); ax1.set_yscale('log')
    ax1.set_xlabel("physical error rate $p$ (%)")
    ax1.set_ylabel("per-logical error rate")
    ax1.set_title("(a) Sub-threshold scaling")
    ax1.legend(loc='lower right')
    ax1.grid(alpha=0.3, which='both')

    # suppression factors with propagated uncertainty
    for (a, b), c, m in [((4, 6), '#1a6fb5', 'o'), ((6, 8), '#c0392b', 's')]:
        ps, lam, lam_e = [], [], []
        for p in sorted(set(RATES[a]) & set(RATES[b])):
            va, vb = RATES[a][p], RATES[b][p]
            if va == 0 or vb == 0:
                continue
            L_ = va / vb
            ea = max(err(a, p)); eb = max(err(b, p))
            rel = math.hypot(ea/va, eb/vb)
            ps.append(p * 100); lam.append(L_); lam_e.append(L_ * rel)
        ax2.errorbar(ps, lam, yerr=lam_e, fmt=m + '-', color=c, ms=4.5,
                     lw=1.5, capsize=2.5,
                     label=rf"$\Lambda({a}\!\to\!{b})$")
    ax2.axhline(1.0, color=C_GRAY, ls=':', lw=1.0)
    ax2.text(0.0115, 3.2, r"$\Lambda=1$: no suppression", fontsize=7,
             color='#666666')
    ax2.set_xscale('log')
    ax2.set_xlabel("physical error rate $p$ (%)")
    ax2.set_ylabel(r"suppression factor $\Lambda$")
    ax2.set_title("(b) Suppression, with uncertainty")
    ax2.legend(loc='upper right')
    ax2.grid(alpha=0.3, which='both')
    ax2.set_ylim(0, 60)

    for ax in (ax1, ax2):
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(w_pad=2.0)
    fig.savefig("fig3_scaling.pdf")
    plt.close(fig)
    print("  fig3_scaling.pdf")


if __name__ == "__main__":
    print("Generating figures...")
    fig_triad()
    fig_tradeoff()
    fig_scaling()
    print("Done.")
