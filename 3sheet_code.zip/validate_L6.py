"""validate_L6.py: explicit three-sheet circuit vs effective 2p model at L=6,
around the crossing region, with bootstrap confidence intervals on the ratio.

Reviewer 2 (round 2) point 1: validation at L=4 only, 8000 shots, few p values,
does not establish that the effective model reproduces crossing locations.
This runs both circuits at L=6 across p = 0.005..0.010, 4000 shots each, and
reports the ratio explicit/effective with a 95% bootstrap CI per point.
Writes results_validate_L6.jsonl incrementally so it survives interruption.
"""
import sys, json, time
sys.path.insert(0, '.')
import numpy as np, stim, pymatching
from _fcc_3sheet import build_3sheet_circuit
from _fcc_circuit import build_sheet_circuit_multiplex

SEED = 20260827; SHOTS = 4000; L = 6
PS = [0.005, 0.006, 0.007, 0.008, 0.009, 0.010]

def per_shot(circ, shots, seed):
    dem = circ.detector_error_model(decompose_errors=True, approximate_disjoint_errors=True)
    m = pymatching.Matching.from_detector_error_model(dem)
    det, obs = circ.compile_detector_sampler(seed=seed).sample(shots, separate_observables=True)
    return (m.decode_batch(det) != obs).mean(axis=1)   # per-shot mean over observables

rng = np.random.default_rng(SEED)
for p in PS:
    t0 = time.time()
    seed = SEED + int(round(p*1e6))
    c_exp, _, _ = build_3sheet_circuit(L, p, p_idle_ratio=1.0)
    c_eff, _, _ = build_sheet_circuit_multiplex(L, p, rounds=L, multiplex_factor=2.0)
    a = per_shot(c_exp, SHOTS, seed); b = per_shot(c_eff, SHOTS, seed + 7)
    ra, rb = float(a.mean()), float(b.mean())
    idx = rng.integers(0, SHOTS, size=(2000, SHOTS))
    boot = a[idx].mean(1) / np.maximum(b[idx].mean(1), 1e-12)
    lo, hi = np.percentile(boot, [2.5, 97.5])
    rec = dict(L=L, p=p, explicit=ra, effective=rb, ratio=ra/rb, ci=[float(lo), float(hi)], shots=SHOTS, secs=round(time.time()-t0))
    with open('results_validate_L6.jsonl', 'a') as f: f.write(json.dumps(rec) + '\n')
    print(f"p={p:.3f} explicit {ra:.4f} effective {rb:.4f} ratio {ra/rb:.3f} [{lo:.3f},{hi:.3f}] {rec['secs']}s", flush=True)
print("DONE")
