"""
fcc_threshold.py: Threshold of the FCC sheet code measured with the actual
custom circuit, not a rotated-surface-code proxy.

Section 6 of the manuscript previously quoted crossings obtained from Stim's
built-in surface_code:rotated_memory_z at odd distances, on the grounds that
one sheet layer is "close to" a rotated surface code. That is a proxy: a layer
is a rotated TORIC code (k = 2, periodic), not a surface code (k = 1, open).
This script removes the proxy. It sweeps the real FCC sheet-code circuit built
by build_sheet_circuit_multiplex(), at the even lattice sizes the construction
requires, with and without the multiplex idle penalty, and locates the
pairwise crossings directly.

Metric: per-logical error rate, matching Section 7. Using per-logical rather
than block rate is what makes sizes with different k = 2L comparable.

Run: python3 fcc_threshold.py
"""

from __future__ import annotations
import os
import time
import numpy as np

from _fcc_circuit import build_sheet_circuit_multiplex, sample_circuit

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "results_fcc_threshold")
os.makedirs(OUT, exist_ok=True)

SEED = 20260827
LATTICES = [4, 6, 8]
P_SWEEP = [0.0060, 0.0070, 0.0080, 0.0090, 0.0100,
           0.0110, 0.0120, 0.0130, 0.0140]
SHOTS = 20_000


def point_seed(L, p, idle):
    return SEED + 1000 * L + int(round(p * 1e6)) + (700000 if idle else 0)


def sweep(idle_factor, label):
    print(f"\n{'=' * 74}")
    print(f"  {label}   (idle rate = {idle_factor} x p)")
    print(f"{'=' * 74}")
    print(f"  {'p (%)':>7}" + "".join(f"{'L=' + str(L):>15}" for L in LATTICES))
    print("  " + "-" * 54)
    res = {}
    for p in P_SWEEP:
        row = []
        for L in LATTICES:
            circ, _, _ = build_sheet_circuit_multiplex(
                L, p, rounds=L, multiplex_factor=idle_factor)
            per_log = sample_circuit(circ, SHOTS,
                                     seed=point_seed(L, p, idle_factor > 0))
            res[(L, p)] = per_log
            row.append(f"{per_log:>15.4e}")
        print(f"  {100*p:>7.2f}" + "".join(row))
    return res


def crossings(res):
    """Pairwise crossing of per-logical curves, by linear interpolation."""
    out = []
    for i in range(len(LATTICES) - 1):
        for j in range(i + 1, len(LATTICES)):
            a, b = LATTICES[i], LATTICES[j]
            prev = None
            hit = None
            for p in P_SWEEP:
                d = res[(a, p)] - res[(b, p)]
                if prev is not None and prev[1] * d < 0:
                    p0, d0 = prev
                    hit = p0 + (p - p0) * abs(d0) / (abs(d0) + abs(d))
                    break
                prev = (p, d)
            out.append((a, b, hit))
    return out


def report(res, label):
    print(f"\n  Pairwise crossings, {label}:")
    vals = []
    for a, b, hit in crossings(res):
        if hit is None:
            print(f"    L={a} vs L={b}:  no sign change in the swept range")
        else:
            print(f"    L={a} vs L={b}:  {100*hit:.3f}%")
            vals.append(hit)
    if vals:
        m = float(np.mean(vals))
        s = float(np.std(vals))
        print(f"    -> threshold estimate {100*m:.2f}% +/- {100*s:.2f}%")
    return vals


if __name__ == "__main__":
    t0 = time.time()
    single = sweep(0.0, "Single-sheet operation, actual FCC circuit")
    v_single = report(single, "single sheet")
    multi = sweep(2.0, "Three-sheet multiplexing, actual FCC circuit")
    v_multi = report(multi, "three-sheet multiplex")

    with open(f"{OUT}/fcc_threshold.txt", "w") as f:
        f.write("# Threshold from the actual FCC sheet-code circuit\n")
        f.write("# per-logical error rate, MWPM via PyMatching\n")
        f.write(f"{'p':>10}")
        for tag in ("single", "mux"):
            for L in LATTICES:
                f.write(f"  {tag}_L{L:<2}      ")
        f.write("\n")
        for p in P_SWEEP:
            f.write(f"{p:>10.5f}")
            for res in (single, multi):
                for L in LATTICES:
                    f.write(f"  {res[(L, p)]:>12.5e}")
            f.write("\n")
    print(f"\n  Wrote {OUT}/fcc_threshold.txt")

    if v_single and v_multi:
        print(f"\n  Ratio single/multiplex = "
              f"{np.mean(v_single)/np.mean(v_multi):.2f}")
    print(f"  Total runtime {time.time()-t0:.0f} s")
