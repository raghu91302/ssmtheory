"""X-basis memory circuit, dual to _fcc_circuit.py."""
from __future__ import annotations
import numpy as np
import stim
import pymatching
from fcc_code import (build_sheet_code_xy, to_matrix,
                      find_logical_Z_basis as find_logical_basis)


def build_sheet_circuit_xmem(L, p, rounds, multiplex_factor=2.0):
    """X-basis memory: detectors on X-stabilizers, X-basis readout.

    Dual of build_sheet_circuit_multiplex, used to check that the reported
    threshold is not specific to the Z sector.

    Original docstring: idle-decoherence penalty
    on every data qubit before each round of stabilizer extraction.
    
    multiplex_factor: 0.0 for single-sheet, 2.0 for 3-sheet multiplexing.
    """
    n_data, Z_stabs, X_stabs = build_sheet_code_xy(L)
    HX = to_matrix(X_stabs, n_data)
    HZ = to_matrix(Z_stabs, n_data)
    L_X = find_logical_basis(HZ, HX)
    
    n_z = len(Z_stabs)
    n_x = len(X_stabs)
    z_anc = list(range(n_data, n_data + n_z))
    x_anc = list(range(n_data + n_z, n_data + n_z + n_x))
    
    p_idle = multiplex_factor * p
    
    c = stim.Circuit()
    c.append("RX", list(range(n_data)))          # data in the X basis
    c.append("R", list(range(n_data, n_data + n_z + n_x)))
    if p > 0:
        c.append("Z_ERROR", list(range(n_data)), p)
    
    for r in range(rounds):
        # Multiplex idle penalty: data qubits decohere while OTHER sheets
        # are being measured
        if p_idle > 0:
            c.append("DEPOLARIZE1", list(range(n_data)), p_idle)
        
        # Z-stab extraction
        c.append("R", z_anc)
        if p > 0:
            c.append("X_ERROR", z_anc, p)
        for i, stab in enumerate(Z_stabs):
            for d in stab:
                c.append("CX", [d, z_anc[i]])
                if p > 0:
                    c.append("DEPOLARIZE2", [d, z_anc[i]], p)
        if p > 0:
            c.append("X_ERROR", z_anc, p)
        c.append("M", z_anc)
        
        # X-stab extraction
        c.append("R", x_anc)
        if p > 0:
            c.append("X_ERROR", x_anc, p)
        c.append("H", x_anc)
        if p > 0:
            c.append("DEPOLARIZE1", x_anc, p)
        for i, stab in enumerate(X_stabs):
            for d in stab:
                c.append("CX", [x_anc[i], d])
                if p > 0:
                    c.append("DEPOLARIZE2", [x_anc[i], d], p)
        c.append("H", x_anc)
        if p > 0:
            c.append("DEPOLARIZE1", x_anc, p)
            c.append("X_ERROR", x_anc, p)
        c.append("M", x_anc)
        
        # Detectors on X-stabs (X memory)
        n_per_round = n_z + n_x
        if r == 0:
            for i in range(n_x):
                c.append("DETECTOR", [stim.target_rec(-n_x + i)])
        else:
            for i in range(n_x):
                off_now = -n_x + i
                c.append("DETECTOR",
                         [stim.target_rec(off_now),
                          stim.target_rec(off_now - n_per_round)])
    
    # Final destructive measurement in the X basis
    if p > 0:
        c.append("Z_ERROR", list(range(n_data)), p)
    c.append("MX", list(range(n_data)))

    for i, stab in enumerate(X_stabs):
        x_offset = -n_data - n_x + i
        targets = [stim.target_rec(x_offset)]
        for d in stab:
            targets.append(stim.target_rec(-n_data + d))
        c.append("DETECTOR", targets)

    for k, lx in enumerate(L_X):
        targets = [stim.target_rec(-n_data + d) for d in range(n_data) if lx[d]]
        c.append("OBSERVABLE_INCLUDE", targets, k)

    return c, n_data, L_X


def run_with_pymatching(circ, num_shots, seed=None):
    dem = circ.detector_error_model(decompose_errors=True,
                                     approximate_disjoint_errors=True)
    matcher = pymatching.Matching.from_detector_error_model(dem)
    sampler = circ.compile_detector_sampler(seed=seed)
    det, obs = sampler.sample(num_shots, separate_observables=True)
    pred = matcher.decode_batch(det)
    block_err = np.any(pred != obs, axis=1)
    per_obs_err = (pred != obs).mean(axis=0)
    return block_err.mean(), per_obs_err, int(block_err.sum()), num_shots




