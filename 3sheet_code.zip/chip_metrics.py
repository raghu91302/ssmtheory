"""chip_metrics.py: block-failure probabilities and bootstrap crossing CIs.

Reviewer 2 point 3: per-logical rates alone are insufficient for a chip-level
architecture; report per-sheet block failure and three-sheet any-failure
probabilities, especially at L = 6.

Reviewer 2 point 2: distinguish statistical uncertainty of crossing locations
from finite-size drift; give bootstrap CIs for the crossings.

Runs the effective r=2 circuit, keeps per-shot failure vectors, and derives:
  - per-logical rate (as before)
  - per-sheet block failure  P(any of the 2L observables fails in a shot)
  - three-sheet any-failure  1 - (1 - P_block)^3  (sheets fail independently
    in the simulated model; stated as such)
  - bootstrap 95% CI on each pairwise crossing location
Incremental output to results_chip_metrics.jsonl.
"""
import sys, json, time
sys.path.insert(0, '.')
import numpy as np, pymatching
from _fcc_circuit import build_sheet_circuit_multiplex

SEED = 20260827
SHOTS = {4: 6000, 6: 4000, 8: 2000}
PS = [0.001, 0.003, 0.005, 0.006, 0.007, 0.008, 0.009, 0.010, 0.011]

def fails(L, p):
    c, _, _ = build_sheet_circuit_multiplex(L, p, rounds=L, multiplex_factor=2.0)
    dem = c.detector_error_model(decompose_errors=True, approximate_disjoint_errors=True)
    m = pymatching.Matching.from_detector_error_model(dem)
    det, obs = c.compile_detector_sampler(seed=SEED + 1000*L + int(round(p*1e6))).sample(SHOTS[L], separate_observables=True)
    return (m.decode_batch(det) != obs)          # shots x k boolean

store = {}
for L in (4, 6, 8):
    for p in PS:
        t0 = time.time()
        F = fails(L, p)
        per_log = float(F.mean()); block = float(F.any(axis=1).mean())
        rec = dict(L=L, p=p, per_logical=per_log, block=block,
                   three_sheet_any=1 - (1 - block)**3, k=int(F.shape[1]), shots=int(F.shape[0]))
        store[(L, p)] = F.mean(axis=1)             # per-shot mean, for crossing bootstrap
        with open('results_chip_metrics.jsonl', 'a') as f: f.write(json.dumps(rec) + '\n')
        print(f"L={L} p={p:.3f} per-log {per_log:.4f} block {block:.4f} any3 {rec['three_sheet_any']:.4f} ({time.time()-t0:.0f}s)", flush=True)
np.save('results_chip_pershot.npy', {k: v for k, v in store.items()}, allow_pickle=True)

# bootstrap crossing locations on per-logical curves
def cross(rates, a, b):
    prev = None
    for p in PS:
        d = rates[(a, p)] - rates[(b, p)]
        if prev is not None and prev[1]*d < 0:
            p0, d0 = prev; return p0 + (p-p0)*abs(d0)/(abs(d0)+abs(d))
        prev = (p, d)
    return None
rng = np.random.default_rng(SEED)
out = {}
for a, b in ((4,6),(4,8),(6,8)):
    pts = []
    for _ in range(1000):
        rates = {}
        for (L, p), v in store.items():
            idx = rng.integers(0, len(v), len(v)); rates[(L, p)] = v[idx].mean()
        c = cross(rates, a, b)
        if c is not None: pts.append(c)
    point = cross({k: v.mean() for k, v in store.items()}, a, b)
    lo, hi = (np.percentile(pts, [2.5, 97.5]) if pts else (None, None))
    out[f"{a}v{b}"] = dict(point=point, ci=[float(lo), float(hi)], n_boot=len(pts))
    print(f"crossing L={a} vs L={b}: {100*point:.3f}%  95% CI [{100*lo:.3f}, {100*hi:.3f}]  ({len(pts)} resamples crossed)", flush=True)
with open('results_chip_crossings.json', 'w') as f: json.dump(out, f, indent=1)
print("DONE")
