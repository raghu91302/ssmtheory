"""_fcc_circuit.py: the FCC sheet-code memory circuit and its sampler.

Factored out of 3sheet_distance_scaling.py so that both the distance-scaling
experiment and the threshold sweep build the identical circuit.
"""

from __future__ import annotations
import numpy as np
import stim
import pymatching

from fcc_code import (
    build_sheet_code_xy, to_matrix, find_logical_Z_basis as find_logical_basis,
)


def build_sheet_circuit_multiplex(L, p, rounds, multiplex_factor=2.0):
    """Build a sheet-code memory circuit with idle-decoherence penalty
    on every data qubit before each round of stabilizer extraction.
    
    multiplex_factor: 0.0 for single-sheet, 2.0 for 3-sheet multiplexing.
    """
    n_data, Z_stabs, X_stabs = build_sheet_code_xy(L)
    HX = to_matrix(X_stabs, n_data)
    HZ = to_matrix(Z_stabs, n_data)
    L_Z = find_logical_basis(HX, HZ)
    
    n_z = len(Z_stabs)
    n_x = len(X_stabs)
    z_anc = list(range(n_data, n_data + n_z))
    x_anc = list(range(n_data + n_z, n_data + n_z + n_x))
    
    p_idle = multiplex_factor * p
    
    c = stim.Circuit()
    c.append("R", list(range(n_data + n_z + n_x)))
    if p > 0:
        c.append("X_ERROR", list(range(n_data)), p)
    
    for r in range(rounds):
        # Multiplex idle penalty: data qubits decohere while OTHER sheets
        # are being measured
        if p_idle > 0:
            c.append("DEPOLARIZE1", list(range(n_data)), p_idle)
        
        # Z-stab extraction
        c.append("R", z_anc)
        if p > 0:
            c.append("X_ERROR", z_anc, p)
        for i, stab in enumerate(Z_stabs):
            for d in stab:
                c.append("CX", [d, z_anc[i]])
                if p > 0:
                    c.append("DEPOLARIZE2", [d, z_anc[i]], p)
        if p > 0:
            c.append("X_ERROR", z_anc, p)
        c.append("M", z_anc)
        
        # X-stab extraction
        c.append("R", x_anc)
        if p > 0:
            c.append("X_ERROR", x_anc, p)
        c.append("H", x_anc)
        if p > 0:
            c.append("DEPOLARIZE1", x_anc, p)
        for i, stab in enumerate(X_stabs):
            for d in stab:
                c.append("CX", [x_anc[i], d])
                if p > 0:
                    c.append("DEPOLARIZE2", [x_anc[i], d], p)
        c.append("H", x_anc)
        if p > 0:
            c.append("DEPOLARIZE1", x_anc, p)
            c.append("X_ERROR", x_anc, p)
        c.append("M", x_anc)
        
        # Detectors on Z-stabs
        n_per_round = n_z + n_x
        if r == 0:
            for i in range(n_z):
                offset = -(n_per_round) + i
                c.append("DETECTOR", [stim.target_rec(offset)])
        else:
            for i in range(n_z):
                off_now = -(n_per_round) + i
                off_prev = off_now - n_per_round
                c.append("DETECTOR",
                         [stim.target_rec(off_now),
                          stim.target_rec(off_prev)])
    
    # Final destructive measurement
    if p > 0:
        c.append("X_ERROR", list(range(n_data)), p)
    c.append("M", list(range(n_data)))
    
    for i, stab in enumerate(Z_stabs):
        z_offset = -n_data - (n_z + n_x) + i
        targets = [stim.target_rec(z_offset)]
        for d in stab:
            targets.append(stim.target_rec(-n_data + d))
        c.append("DETECTOR", targets)
    
    for k, lz in enumerate(L_Z):
        targets = [stim.target_rec(-n_data + d) for d in range(n_data) if lz[d]]
        c.append("OBSERVABLE_INCLUDE", targets, k)
    
    return c, n_data, L_Z


def run_with_pymatching(circ, num_shots, seed=None):
    dem = circ.detector_error_model(decompose_errors=True,
                                     approximate_disjoint_errors=True)
    matcher = pymatching.Matching.from_detector_error_model(dem)
    sampler = circ.compile_detector_sampler(seed=seed)
    det, obs = sampler.sample(num_shots, separate_observables=True)
    pred = matcher.decode_batch(det)
    block_err = np.any(pred != obs, axis=1)
    per_obs_err = (pred != obs).mean(axis=0)
    return block_err.mean(), per_obs_err, int(block_err.sum()), num_shots




def sample_circuit(circ, num_shots, seed=None):
    """Per-logical error rate: mean disagreement rate per observable."""
    dem = circ.detector_error_model(decompose_errors=True,
                                    approximate_disjoint_errors=True)
    matcher = pymatching.Matching.from_detector_error_model(dem)
    sampler = circ.compile_detector_sampler(seed=seed)
    det, obs = sampler.sample(num_shots, separate_observables=True)
    pred = matcher.decode_batch(det)
    return float((pred != obs).mean(axis=0).mean())
