"""
idle_sensitivity.py: threshold as a function of the idle-to-gate noise ratio.

Both referees asked whether the reported 1.3x threshold reduction is an
artifact of fixing the idle rate at exactly 2p. This script sweeps the ratio
r = p_idle / p_2q over {0, 1, 2, 4} and locates the threshold for each, so the
trade-off is reported as a trend rather than a single model point.

r = 0  single-sheet operation, no idling
r = 1  one idle round per measurement round
r = 2  the three-round multiplex cycle used in the manuscript
r = 4  a pessimistic case, e.g. slow transport or a six-round cycle

Metric and circuit are identical to fcc_threshold.py; only the idle factor
changes. Seeded, so results reproduce exactly.
"""
from __future__ import annotations
import os, time
import numpy as np

from _fcc_circuit import build_sheet_circuit_multiplex, sample_circuit

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "results_idle_sensitivity")
os.makedirs(OUT, exist_ok=True)

SEED = 20260827
LATTICES = [4, 6, 8]
RATIOS = [0.0, 1.0, 2.0, 4.0]
SHOTS = 20_000
# wide enough to bracket every crossing from r = 0 down to r = 4
P_SWEEP = [0.0040, 0.0050, 0.0060, 0.0070, 0.0080, 0.0090,
           0.0100, 0.0110, 0.0120, 0.0130, 0.0140]


def point_seed(L, p, r):
    return SEED + 1000 * L + int(round(p * 1e6)) + int(round(r * 1e5))


def crossings(res, ratio):
    out = []
    for i in range(len(LATTICES) - 1):
        for j in range(i + 1, len(LATTICES)):
            a, b = LATTICES[i], LATTICES[j]
            prev = None
            hit = None
            for p in P_SWEEP:
                d = res[(a, p)] - res[(b, p)]
                if prev is not None and prev[1] * d < 0:
                    p0, d0 = prev
                    hit = p0 + (p - p0) * abs(d0) / (abs(d0) + abs(d))
                    break
                prev = (p, d)
            out.append((a, b, hit))
    return out


if __name__ == "__main__":
    t0 = time.time()
    summary = {}
    rows = []
    for r in RATIOS:
        print(f"\n{'=' * 70}")
        print(f"  idle ratio r = p_idle / p_2q = {r}")
        print(f"{'=' * 70}")
        print(f"  {'p (%)':>7}" + "".join(f"{'L=' + str(L):>14}" for L in LATTICES))
        res = {}
        for p in P_SWEEP:
            line = []
            for L in LATTICES:
                circ, _, _ = build_sheet_circuit_multiplex(
                    L, p, rounds=L, multiplex_factor=r)
                v = sample_circuit(circ, SHOTS, seed=point_seed(L, p, r))
                res[(L, p)] = v
                line.append(f"{v:>14.4e}")
            print(f"  {100*p:>7.2f}" + "".join(line))
        cs = [c for _, _, c in crossings(res, r) if c is not None]
        if cs:
            m, s = float(np.mean(cs)), float(np.std(cs))
            summary[r] = (m, s, len(cs))
            print(f"  crossings: " +
                  ", ".join(f"{100*c:.3f}%" for c in cs))
            print(f"  -> threshold {100*m:.2f}% +/- {100*s:.2f}%  ({len(cs)}/3)")
        else:
            summary[r] = (None, None, 0)
            print("  no crossings inside the swept range")
        for p in P_SWEEP:
            rows.append([r, p] + [res[(L, p)] for L in LATTICES])

    print(f"\n{'=' * 70}")
    print("  SENSITIVITY OF THE THRESHOLD TO THE IDLE MODEL")
    print(f"{'=' * 70}")
    print(f"  {'r':>5} {'threshold':>18} {'ratio to r=0':>14}")
    base = summary.get(0.0, (None,))[0]
    for r in RATIOS:
        m, s, n = summary[r]
        if m is None:
            print(f"  {r:>5.1f} {'not bracketed':>18}")
        else:
            rel = f"{base/m:.2f}x" if base else "--"
            print(f"  {r:>5.1f} {100*m:>10.2f}% +/- {100*s:.2f}% {rel:>14}")

    with open(f"{OUT}/idle_sensitivity.txt", "w") as f:
        f.write("# idle-ratio sensitivity, per-logical error rate\n")
        f.write("# r  p  " + "  ".join(f"L{L}" for L in LATTICES) + "\n")
        for row in rows:
            f.write(f"{row[0]:>5.1f} {row[1]:>8.4f}" +
                    "".join(f"  {v:>12.5e}" for v in row[2:]) + "\n")
        f.write("\n# thresholds\n")
        for r in RATIOS:
            m, s, n = summary[r]
            f.write(f"r={r:<4} " + (f"{m:.6f} +/- {s:.6f} ({n}/3)\n"
                                    if m else "not bracketed\n"))
    print(f"\n  wrote {OUT}/idle_sensitivity.txt")
    print(f"  runtime {time.time()-t0:.0f} s")
