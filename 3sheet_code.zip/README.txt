Three-sheet multiplexed FCC sheet code: simulation code and data
================================================================

Companion archive for "Ancilla-Shared Time Multiplexing of Three FCC Sheet
Codes: a One-Third Qubit Saving at a 1.5x Threshold Cost".

Released under the MIT license.


Requirements
------------

    pip install -r requirements.txt

stim >= 1.15, pymatching >= 2.3, numpy >= 1.24, matplotlib >= 3.7.
Tested with Python 3.10 to 3.13 on Linux.


Quick start
-----------

    python3 verify_construction.py     # a few seconds, no simulation
    python3 make_figures.py            # a few seconds, regenerates Figures 1-3

verify_construction.py checks every algebraic claim in the paper by exact
GF(2) computation and prints Table 1. It needs only numpy.


Files
-----

fcc_code.py
    Lattice construction. Enumerates FCC nodes, edges, octahedral voids and
    the triad-sheet assignment of each edge; builds the weight-4 sheet-code
    stabilizers; provides GF(2) utilities and the logical-Z basis finder.
    Every other script imports from here.

verify_construction.py
    Static verification at L = 4, 6, 8. Confirms n = L^3,
    rank(H_Z) = rank(H_X) = (L^3 - 2L)/2, k = 2L per sheet and 6L across
    three sheets, and CSS validity. Reproduces Table 1.

multiplex_threshold.py
    Threshold sweep at L = 3, 5, 7, 9, 11, with and without the multiplex
    idle penalty. Supports the 0.68% and 0.44% crossings behind Figure 2b.
    Runtime a few minutes.

3sheet_distance_scaling.py
    The central experiment. Full circuit-level memory runs at L = 4, 6, 8
    under the DEPOLARIZE1(2p) idle penalty, MWPM decoding. Reproduces
    Tables 2 and 3. Runtime a few minutes.

surface_code_baseline.py
    Rotated surface code [[16,1,4]] under matched noise, giving the
    per-logical comparison value in Section 7.

make_figures.py
    Regenerates Figures 1 to 3 as vector PDF with TrueType fonts.

Results are written to results_multiplex/ and results_3sheet_scaling/,
created next to the scripts.


A note on reproducibility
-------------------------

All three sampling scripts fix a base seed, SEED = 20260827, defined at the
top of each file. Each (L, p) point derives its own seed from it, so points
draw independent samples while the sweep as a whole is deterministic.
Re-running any script gives bit-identical numbers on the same machine and
library versions.

Stim's seeding is described in its documentation as PARTIALLY determining
results: identical output requires the same Stim version and the same CPU
instruction set, since AVX and SSE code paths consume randomness
differently. Across machines, expect agreement within binomial error rather
than exact equality.

Tables 2 and 3 of the manuscript are the output of this seeded sweep. Running
3sheet_distance_scaling.py reproduces them entry for entry: 5.00e-3, 4.06e-4
and 7.19e-5 at p = 1e-3 for L = 4, 6, 8, giving Lambda(4->6) = 12.3 and
Lambda(6->8) = 5.6.

make_figures.py plots those same values rather than resampling, so the
figures match the paper exactly. Uncertainties shown in the figures are
computed from the rates and the shot counts.

Two points in Table 2 sit at the shot floor and are labelled as such in the
paper: L = 6 at p = 1e-4 rests on a single observed logical error, and L = 8
at p = 1e-4 observed none.
