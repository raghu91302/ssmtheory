"""
bootstrap_stats.py: shot-level resampling and Wilson intervals.

Both referees objected to two things in the original statistics:

  (a) treating N = shots x k as the binomial sample size, which assumes the
      k logical observables fail independently within a shot;
  (b) symmetric Gaussian error bars at points with very few or zero observed
      failures, where the normal approximation is invalid.

This script addresses both. It resamples whole shots with replacement, so any
correlation between observables inside a shot is preserved, and it reports
Wilson score intervals for the per-observable rates, which stay inside [0,1]
and behave correctly at zero counts.

Output: results_bootstrap/bootstrap.txt
"""
from __future__ import annotations
import os, json, sys
import numpy as np
import stim, pymatching

from _fcc_circuit import build_sheet_circuit_multiplex

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "results_bootstrap")
os.makedirs(OUT, exist_ok=True)

SEED = 20260827
SHOTS = {4: 30000, 6: 30000, 8: 20000}
P_LIST = [0.0001, 0.0003, 0.0005, 0.001, 0.002, 0.003, 0.005]
NBOOT = 2000


def failures_per_shot(L, p, shots, seed):
    """Boolean array (shots x k): did observable j fail on shot i?"""
    circ, _, _ = build_sheet_circuit_multiplex(L, p, rounds=L,
                                               multiplex_factor=2.0)
    dem = circ.detector_error_model(decompose_errors=True,
                                    approximate_disjoint_errors=True)
    m = pymatching.Matching.from_detector_error_model(dem)
    s = circ.compile_detector_sampler(seed=seed)
    det, obs = s.sample(shots, separate_observables=True)
    return m.decode_batch(det) != obs


def wilson(k, n, z=1.96):
    """Wilson score interval; correct at k = 0."""
    if n == 0:
        return (0.0, 0.0)
    ph = k / n
    d = 1 + z * z / n
    c = (ph + z * z / (2 * n)) / d
    h = z * np.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def analyse(fail, rng):
    """Point estimate, Wilson CI, and shot-level bootstrap CI."""
    shots, k = fail.shape
    per_shot = fail.mean(axis=1)          # per-shot mean over observables
    point = float(per_shot.mean())
    nfail = int(fail.sum())
    lo, hi = wilson(nfail, shots * k)     # naive N = shots x k
    idx = rng.integers(0, shots, size=(NBOOT, shots))
    boot = per_shot[idx].mean(axis=1)
    blo, bhi = np.percentile(boot, [2.5, 97.5])
    # correlation diagnostic: variance ratio vs the independence assumption
    var_obs = per_shot.var(ddof=1)
    var_ind = point * (1 - point) / k if 0 < point < 1 else 0.0
    infl = (var_obs / var_ind) if var_ind > 0 else float('nan')
    return dict(point=point, nfail=nfail, shots=shots, k=k,
                wilson=(lo, hi), boot=(float(blo), float(bhi)),
                boot_se=float(boot.std(ddof=1)), inflation=float(infl))


if __name__ == "__main__":
    Ls = [int(x) for x in sys.argv[1:]] or [4, 6, 8]
    rng = np.random.default_rng(SEED)
    path = f"{OUT}/bootstrap.jsonl"
    for L in Ls:
        for p in P_LIST:
            seed = SEED + 1000 * L + int(round(p * 1e6))
            fail = failures_per_shot(L, p, SHOTS[L], seed)
            r = analyse(fail, rng)
            r.update(L=L, p=p)
            with open(path, "a") as f:
                f.write(json.dumps(r) + "\n")
            print(f"  L={L} p={p:.4f}  rate={r['point']:.4e}  "
                  f"fails={r['nfail']:>5}  boot95=[{r['boot'][0]:.3e},"
                  f"{r['boot'][1]:.3e}]  var-inflation={r['inflation']:.2f}",
                  flush=True)
