import json, numpy as np, collections
L=lambda n:[json.loads(l) for l in open(f"results/{n}.jsonl")]
def row(rs,f):
    v=np.array([r[f] for r in rs],float); return f"{v.mean():.4f}±{(v.std(ddof=1)/np.sqrt(len(v)) if len(v)>1 else 0):.4f}"
print("== SIZE: variant N | bulk fcc | bulk hcp | all fcc | lift frac | iso | z_up_frac | zmin zmax")
for name in ["size","size_axis","size_radial"]:
    g=collections.OrderedDict()
    for r in L(name):
        if r['key']['N'] in (1000,10000,100000,1000000): g.setdefault(r['key']['N'],[]).append(r)
    for N in sorted(g):
        rs=g[N]
        print(f"{name:12s} {N:8d} n={len(rs):2d} {row(rs,'bulk_fcc')} {row(rs,'bulk_hcp')} {row(rs,'all_fcc')} {row(rs,'lift_fraction')} {row(rs,'iso')} {row(rs,'z_up_frac') if 'z_up_frac' in rs[0] else '-'} {np.mean([r.get('zmin',np.nan) for r in rs]):.1f} {np.mean([r.get('zmax',np.nan) for r in rs]):.1f}")
print("== DEPTH N=1e6 (fcc, hcp at depth 0..8)")
for name in ["size","size_axis","size_radial"]:
    big=[r for r in L(name) if r['key']['N']==10**6]
    print(name, [f"{np.mean([r['depth_profile'][str(d)][1] for r in big]):.3f}" for d in range(9)], "deep hcp", f"{np.mean([np.mean([r['depth_profile'][str(d)][2] for d in range(4,9)]) for r in big]):.5f}", "tets6", np.mean([r['bulk_tets_hist'][6]/sum(r['bulk_tets_hist']) for r in big]).round(4))
print("== EVOLUTION N=1e6: t | fcc | meanK | tets/node | K4frac")
for name in ["size","size_axis","size_radial"]:
    big=[r for r in L(name) if r['key']['N']==10**6]
    out=[]
    for t in [100,1000,10000,100000,1000000]:
        e=[r['evolution'][str(t)] for r in big]
        out.append(f"t={t}: fcc={np.mean([x['fcc'] for x in e if x['fcc'] is not None]):.3f} K={np.mean([x['mean_k'] for x in e]):.2f} tet={np.mean([x['tets_all'] for x in e]):.2f}")
    print(name, " | ".join(out))
print("== LIFT SWEEP both vs axis (w | lift frac | fcc | hcp | iso)")
for name in ["lift","lift_axis"]:
    g=collections.OrderedDict()
    for r in sorted(L(name),key=lambda r:r['key']['w_site']): g.setdefault(r['key']['w_site'],[]).append(r)
    for w,rs in g.items(): print(f"{name:10s} w={w:<7} {row(rs,'lift_fraction')} {row(rs,'bulk_fcc')} {row(rs,'bulk_hcp')} {row(rs,'iso')}")
