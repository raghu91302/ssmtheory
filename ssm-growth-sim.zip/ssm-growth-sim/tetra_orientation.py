from tetlib import *
import numpy as np
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import H
for mode in ['both','axis']:
    for s in [10,11]:
        r=grow_slab(32,32,450,seed=s,lift_dir=mode); up,dn=per_pair(r['adj'],r['deg'],r['pos'][:,2],H,500)
        a,b=300,400
        print(mode,s,'layers 300-400 (down-up)/total = %+.1fe-4'%(1e4*(dn-up)[a:b].sum()/(dn+up)[a:b].sum()), ' upper: up',int(up[a:b].sum()),'down',int(dn[a:b].sum()))
