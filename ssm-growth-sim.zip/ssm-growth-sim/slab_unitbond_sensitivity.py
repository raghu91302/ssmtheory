"""Sensitivity of slab growth to the settings of the unit-bond condition (cap and Gauss-Newton steps).
32x32 slabs, 300 layers, axis lift, seeds 0 and 1. Writes results/slab_unitbond_sensitivity.json."""
import sys, os, json, time, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import analyse_slab, height_profile
CFGS = [dict(rcap=0.02, rsteps=4), dict(rcap=0.01, rsteps=4), dict(rcap=0.04, rsteps=4),
        dict(rcap=0.02, rsteps=2), dict(rcap=0.02, rsteps=8)]
out = []
for cfg in CFGS:
    for seed in (0, 1):
        t = time.time()
        r = grow_slab(32, 32, 300, seed=seed, lift_dir="axis", **cfg)
        a = analyse_slab(r); p = height_profile(r)
        P = r["pos"]; adj, deg = r["adj"], r["deg"]
        # bond-length error over all bonds (minimum image in x, y)
        Lx, Ly = r["box"]; errs = []
        for i in range(len(deg)):
            for k in range(deg[i]):
                j = adj[i, k]
                if j > i:
                    d = P[j] - P[i]; d[0] -= Lx * np.round(d[0] / Lx); d[1] -= Ly * np.round(d[1] / Ly)
                    errs.append(abs(np.sqrt((d * d).sum()) - 1.0))
        errs = np.array(errs)
        rec = dict(cfg=cfg, seed=seed, lift_fraction=a["stats"]["lift_fraction"] if "stats" in a else r["stats"]["lift_fraction"],
                   on_lattice=a["on_lattice_frac"], interior_fcc=a["interior_fcc"],
                   final_imbalance=abs(a["twin_abc"] - a["twin_acb"]) / max(1e-12, a["twin_abc"] + a["twin_acb"]),
                   min_bin_on_lattice=min(x["on_lattice"] for x in p),
                   bond_err_median=float(np.median(errs)), bond_err_max=float(errs.max()), t=time.time() - t)
        out.append(rec); print(rec, flush=True)
json.dump(out, open("results/slab_unitbond_sensitivity.json", "w"), indent=1)
