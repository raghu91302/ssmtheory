import sys, json; sys.path.insert(0,'.')
import numpy as np
from ssmsim.core import grow
from ssmsim.analysis import cna, bulk_mask
out=[]
for seed,w in [(0,None),(1,None),(2,None),(3,None),(0,0.2),(1,0.2)]:
    r=grow(100000,seed=seed,refine=True,**({} if w is None else dict(w_site=w))); P,op,par=r['pos'],r['op'],r['parent']
    a1=P[1]-P[0]; a2=P[2]-P[0]; L=int(np.argmax(op==2)); a3=P[L]-P[par[L,0]]
    M=np.linalg.inv(np.array([a1,a2,a3]).T); f=(M@(P-P[0]).T).T; on=np.all(np.abs(f-np.rint(f))<0.02,axis=1)
    idx=np.arange(3,len(P)); tri_on=on[par[idx,0]]&on[par[idx,1]]&on[par[idx,2]]
    st=idx[(op[idx]==1)&tri_on]; li=idx[(op[idx]==2)&tri_on]
    c=cna(P); m=bulk_mask(P)
    res=dict(seed=seed,w=w if w else 0.0225,on=float(on.mean()),stitch_n=int(len(st)),stitch_off=int((~on[st]).sum()),
             lift_on=int(on[li].sum()),lift_off=int((~on[li]).sum()),hcp=float((c[m]==2).mean()))
    out.append(res); print(res)
json.dump(out,open('results/lattice_check.json','w'))
