"""Production sweeps. Appends one JSON line per run to results/<sweep>.jsonl (resumable)."""
import sys, os, json, time, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from ssmsim.core import grow, lift_weight_from_delta
from ssmsim.analysis import cna, bulk_mask, summarize, depth_from_surface, tets_per_node, prefix_degrees

os.makedirs("results", exist_ok=True)

def done(path):
    if not os.path.exists(path): return set()
    return {json.dumps(json.loads(l)["key"]) for l in open(path)}

def record(path, key, res):
    with open(path, "a") as f:
        f.write(json.dumps({"key": key, **res}) + "\n")

def one(N, seed, **kw):
    t = time.time()
    kw.setdefault("refine", False)   # the published cluster sweeps were run without the unit-bond condition
    r = grow(N, seed=seed, **kw)
    tg = time.time() - t
    P, deg = r["pos"], r["deg"]
    codes = cna(P); mask = bulk_mask(P)
    s = summarize(P, deg, codes, mask)
    s.update(r["stats"]); s["t_grow"] = tg
    ext = P.max(0) - P.min(0); ev = np.linalg.eigvalsh(np.cov((P - P.mean(0)).T))
    s["extent"] = ext.tolist(); s["iso"] = float(ev[0] / ev[2])
    s["zmin"] = float(P[:, 2].min()); s["zmax"] = float(P[:, 2].max())
    s["z_up_frac"] = float((P[:, 2] > 0).mean())
    return r, codes, mask, s

SWEEPS = {}

# A: finite-size scaling at the geometric lift weight (delta = 0.05, both directions)
SWEEPS["size"] = [dict(N=N, seed=s) for N, ns in [(1000, 32), (3000, 32), (10000, 32), (30000, 32),
                                                  (100000, 16), (300000, 8), (1000000, 4)] for s in range(ns)]
# B: lift-weight sweep (per-direction site weight) at N = 1e5
W = [0.0005, 0.001, 0.002, 0.005, 0.0113, 0.0225, 0.045, 0.1, 0.2, 0.5, 1.0]
SWEEPS["lift"] = [dict(N=100000, seed=s, w_site=w) for w in W for s in range(8)]
# C: exclusion-radius sweep at N = 3e4
SWEEPS["rex"] = [dict(N=30000, seed=s, r_ex=round(x, 2)) for x in np.arange(0.50, 1.025, 0.02) for s in range(4)]
# D: legacy per-step operator choice, for comparison with the published numbers
SWEEPS["step"] = [dict(N=100000, seed=s, mode="step", p_step=p) for p in [0.01, 0.02, 0.05, 0.1, 0.2, 0.4] for s in range(8)]

# E: the two cosmological variants of lift orientation
for _d in ["axis", "radial"]:
    SWEEPS[f"size_{_d}"] = [dict(N=N, seed=s, lift_dir=_d) for N, ns in
                            [(1000, 16), (10000, 16), (100000, 8), (1000000, 4)] for s in range(ns)]
SWEEPS["lift_axis"] = [dict(N=100000, seed=s, w_site=w, lift_dir="axis") for w in W for s in range(8)]

if __name__ == "__main__":
    names = sys.argv[1:] or list(SWEEPS)
    for name in names:
        path = f"results/{name}.jsonl"; have = done(path)
        for key in SWEEPS[name]:
            if json.dumps(key) in have: continue
            kw = dict(key); N = kw.pop("N"); seed = kw.pop("seed")
            r, codes, mask, s = one(N, seed, **kw)
            if name.startswith("size") and N >= 100000:
                # depth profile and growth-time evolution (prefixes are exact past states)
                depth = depth_from_surface(r["pos"])
                prof = {}
                for d in range(0, 12):
                    m = depth == d
                    if m.sum() > 50:
                        prof[d] = [int(m.sum()), float((codes[m] == 1).mean()), float((codes[m] == 2).mean())]
                s["depth_profile"] = prof
                tets = tets_per_node(r["adj"], r["deg"])
                s["bulk_tets_mean"] = float(tets[mask].mean())
                s["bulk_tets_hist"] = np.bincount(tets[mask], minlength=21)[:21].tolist()
                evo = {}
                for t in [30, 100, 300, 1000, 3000, 10000, 30000, 100000, 300000, 1000000]:
                    if t > N: break
                    Pt = r["pos"][:t]; mt = bulk_mask(Pt); ct = cna(Pt); dt = prefix_degrees(r["adj"], r["deg"], t)
                    tt = tets_per_node(r["adj"], r["deg"], t)
                    evo[t] = dict(n_bulk=int(mt.sum()),
                                  fcc=float((ct[mt] == 1).mean()) if mt.sum() else None,
                                  hcp=float((ct[mt] == 2).mean()) if mt.sum() else None,
                                  mean_k=float(dt.mean()), k4_frac=float((dt == 4).mean()),
                                  tets_all=float(tt.mean()),
                                  tets_bulk=float(tt[mt].mean()) if mt.sum() else None,
                                  lift_frac=float((r["op"][:t] == 2).mean()))
                s["evolution"] = evo
            record(path, key, s)
            print(name, key, f"fcc={s['bulk_fcc']:.3f} hcp={s['bulk_hcp']:.4f} lift={s['lift_fraction']:.4f} t={s['t_grow']:.1f}s", flush=True)
