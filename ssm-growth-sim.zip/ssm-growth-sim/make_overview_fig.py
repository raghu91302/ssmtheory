"""Overview schematic of the SSM (Figure 1 of the revised paper)."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, Polygon

plt.rcParams.update({"font.size": 9, "font.family": "DejaVu Sans", "mathtext.fontset": "dejavusans"})
NODE = "#2f5d8a"; QB = "#e8a33d"; BOND = "#555555"; ACC = "#c0392b"; OK = "#2e8b57"; GREY = "#bbbbbb"

fig, axs = plt.subplots(2, 2, figsize=(6.6, 5.6))
axs = axs.ravel()
for a in axs:
    a.set_aspect("equal"); a.axis("off")

def wavy(ax, p, q, n=6, amp=0.045, **kw):
    p, q = np.array(p), np.array(q); t = np.linspace(0, 1, 200)
    d = q - p; L = np.hypot(*d); nrm = np.array([-d[1], d[0]]) / L
    pts = p[None] + t[:, None] * d[None] + (amp * np.sin(2 * np.pi * n * t))[:, None] * nrm[None]
    ax.plot(pts[:, 0], pts[:, 1], **kw)

# (a) Bell-pair bonds and nodes holding qubits
ax = axs[0]
P = {0: (0.0, 0.0), 1: (1.0, 0.0), 2: (0.5, np.sqrt(3) / 2)}
for i, j in [(0, 1), (1, 2), (2, 0)]:
    p, q = np.array(P[i]), np.array(P[j]); u = (q - p) / np.hypot(*(q - p))
    a_, b_ = p + 0.13 * u, q - 0.13 * u
    wavy(ax, a_, b_, color=BOND, lw=1.1)
    for c in (a_, b_):
        ax.add_patch(Circle(c, 0.045, color=QB, zorder=4))
for k, c in P.items():
    ax.add_patch(Circle(c, 0.22, fc="none", ec=NODE, lw=1.6, zorder=3))
ax.text(0.5, -0.33, r"bond = Bell pair $|\Phi^+\rangle$" "\n" "(one qubit at each end)", ha="center", va="top", fontsize=8)
ax.annotate("node", xy=(0.5 + 0.15, np.sqrt(3) / 2 + 0.15), xytext=(0.95, 1.12), fontsize=8, color=NODE,
            arrowprops=dict(arrowstyle="-", color=NODE, lw=0.8))
ax.annotate("qubit", xy=(0.17, 0.0), xytext=(-0.35, 0.45), fontsize=8, color="#a06a10",
            arrowprops=dict(arrowstyle="-", color="#a06a10", lw=0.8))
ax.set_xlim(-0.45, 1.45); ax.set_ylim(-0.75, 1.3)
ax.set_title("(a) Network", fontsize=9, loc="left")

# (b) stitch and lift
ax = axs[1]
a, b, c = np.array([0, 0.0]), np.array([1, 0.0]), np.array([0.5, np.sqrt(3) / 2])
x = a + b - c
ax.add_patch(Polygon([a, b, c], fc="#dfe8f1", ec=NODE, lw=1.3))
ax.plot([a[0], x[0], b[0]], [a[1], x[1], b[1]], ls="--", color=OK, lw=1.1)
ax.add_patch(Circle(x, 0.07, color=OK, zorder=4))
for pnt, lab, off in [(a, "a", (-0.14, 0.0)), (b, "b", (0.14, 0.0)), (c, "c", (0.0, 0.14))]:
    ax.add_patch(Circle(pnt, 0.06, color=NODE, zorder=4)); ax.text(pnt[0] + off[0], pnt[1] + off[1], lab, fontsize=8, ha="center", va="center")
ax.text(x[0] + 0.12, x[1] - 0.02, r"stitch: $\mathbf{x}=\mathbf{a}+\mathbf{b}-\mathbf{c}$", fontsize=8, color=OK, va="center")
g = (a + b + c) / 3
ax.add_patch(Circle(g, 0.07, fc="white", ec=ACC, lw=1.4, zorder=5))
ax.text(g[0], g[1], r"$\odot$", ha="center", va="center", fontsize=6, color=ACC, zorder=6)
ax.text(g[0] + 0.45, g[1] + 0.62, "lift: apex at\nheight $\\sqrt{2/3}\\,L$\nabove or below", fontsize=8, color=ACC, ha="left")
ax.add_patch(FancyArrowPatch(g + [0.35, 0.55], g + [0.08, 0.08], arrowstyle="-|>", mutation_scale=8, color=ACC, lw=0.8))
ax.set_xlim(-0.3, 2.3); ax.set_ylim(-1.15, 1.3)
ax.set_title("(b) Growth operators", fontsize=9, loc="left")

# (c) exclusion and bonding
ax = axs[2]
cand = np.array([0.0, 0.0])
ax.add_patch(Circle(cand, 1.05, fc="#e9f5ee", ec=OK, lw=1.0, ls="--"))
ax.add_patch(Circle(cand, 0.95, fc="white", ec=ACC, lw=1.0))
ax.add_patch(Circle(cand, 0.95, fc=ACC, alpha=0.10, ec="none"))
ax.add_patch(Circle(cand, 0.07, fc="white", ec="black", lw=1.2, zorder=5))
for ang in [20, 80, 145, 215]:
    p = np.array([np.cos(np.radians(ang)), np.sin(np.radians(ang))]) * 1.0
    ax.plot([0, p[0]], [0, p[1]], color=BOND, lw=1.0); ax.add_patch(Circle(p, 0.07, color=NODE, zorder=4))
p = np.array([np.cos(np.radians(320)), np.sin(np.radians(320))]) * 1.32
ax.add_patch(Circle(p, 0.07, color=GREY, zorder=4)); ax.text(p[0]+0.12, p[1]-0.05, "too far:\nno bond", fontsize=7, color="#777777", va="top")
ax.text(0.12, -0.42, r"no node within $r_{\rm ex}=0.95L$", ha="center", fontsize=7.5, color=ACC)
ax.text(0.0, 1.17, r"bonds to all nodes within $r_{\rm b}=1.05L$", ha="center", fontsize=7.5, color=OK)
ax.text(0.0, -1.42, r"bond length $L(1\pm\delta)$, $\delta=0.05$", ha="center", fontsize=8)
ax.set_xlim(-1.6, 1.9); ax.set_ylim(-1.65, 1.4)
ax.set_title("(c) Acceptance", fontsize=9, loc="left")

# (d) checks
ax = axs[3]
cen = np.array([-0.65, 0.15])
for k in range(6):
    ang = np.radians(60 * k + 30); p = cen + 0.55 * np.array([np.cos(ang), np.sin(ang)])
    ax.plot([cen[0], p[0]], [cen[1], p[1]], color=NODE, lw=1.8); ax.add_patch(Circle(p, 0.05, color=GREY, zorder=4))
    ax.text(*(cen + 0.33 * np.array([np.cos(ang), np.sin(ang)])), "Z", fontsize=6.5, color=NODE, ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.08", fc="white", ec="none"))
ax.add_patch(Circle(cen, 0.07, color=NODE, zorder=5))
ax.text(cen[0], -0.6, "node check:\n" r"$\prod Z$ over" "\nits bonds", ha="center", fontsize=7.5, va="top")
t0 = np.array([0.65, -0.1]); tri = [t0, t0 + [0.8, 0], t0 + [0.4, 0.69]]
for i in range(3):
    p, q = tri[i], tri[(i + 1) % 3]
    ax.plot([p[0], q[0]], [p[1], q[1]], color=ACC, lw=1.8)
    m = (p + q) / 2
    ax.text(m[0], m[1], "X", fontsize=6.5, color=ACC, ha="center", va="center", bbox=dict(boxstyle="round,pad=0.08", fc="white", ec="none"))
for p in tri:
    ax.add_patch(Circle(p, 0.05, color=GREY, zorder=4))
ax.text(1.05, -0.6, "loop check:\n" r"$\prod X$ around" "\na loop", ha="center", fontsize=7.5, va="top")
ax.set_xlim(-1.4, 1.75); ax.set_ylim(-1.45, 0.95)
ax.set_title("(d) Checks", fontsize=9, loc="left")

plt.subplots_adjust(left=0.01, right=0.99, top=0.95, bottom=0.01, wspace=0.05, hspace=0.12)
import sys
out = sys.argv[1] if len(sys.argv) > 1 else "figures/fig_overview.pdf"
fig.savefig(out); fig.savefig(out.replace(".pdf", ".png"), dpi=200)
print("wrote", out)
