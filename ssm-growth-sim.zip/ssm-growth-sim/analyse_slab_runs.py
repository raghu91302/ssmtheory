import json, numpy as np, collections
R=[json.loads(l) for l in open("results/slab2.jsonl")]
g=collections.defaultdict(list)
for r in R: g[(r['key']['nx'],r['key']['lift_dir'])].append(r)
print("size mode | n | tilted grain seen | tilted grain wins | final ABC-ACB imbalance | ABC wins | interior fcc | (down-up)/total")
for k in sorted(g):
    rs=g[k]; seen=win=0; imb=[]; abcw=0; ud=[]; fcc=[]
    for r in rs:
        p=[b for b in r['profile'][1:-2]]        # drop substrate bin and the rough top
        onl=np.array([b['on_lattice'] for b in p])
        seen+= onl.min()<0.98; win+= onl[-3:].mean()<0.5
        last=[b for b in p if b['abc'] is not None][-3:]
        a=np.mean([b['abc'] for b in last]); c=np.mean([b['acb'] for b in last])
        imb.append(abs(a-c)/(a+c)); abcw+= a>c
        ud.append((r['tets_down']-r['tets_up'])/(r['tets_down']+r['tets_up'])); fcc.append(r['interior_fcc'])
    print(k, len(rs), seen, win, f"{np.mean(imb):.2f}", f"{abcw}/{len(rs)}", f"{np.mean(fcc):.3f}", f"{np.mean(ud):.5f}±{np.std(ud)/np.sqrt(len(ud)):.5f}")
print("\ncoarsening: mean |ABC-ACB|/(ABC+ACB) vs height (bins of 10 layers)")
for n in [32,48,64]:
    rs=g[(n,'axis')]+g[(n,'both')]
    H=min(len(r['profile']) for r in rs)-2
    row=[]
    for i in [1,2,3,5,8,12,20,30,40,59]:
        if i>=H: break
        v=[abs(r['profile'][i]['abc']-r['profile'][i]['acb'])/(r['profile'][i]['abc']+r['profile'][i]['acb']) for r in rs if r['profile'][i]['abc'] is not None and r['profile'][i]['on_lattice']>0.9]
        row.append(f"L{i*10}:{np.mean(v):.2f}")
    print(n, " ".join(row))
