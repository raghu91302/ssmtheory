import sys, json; sys.path.insert(0,'.')
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import registry, H
src=open('make_paper_figs.py').read(); exec(src[:src.index("# ---------------- Figure 1")])
exec(open('gather_figs.py').read().split("for name,(mode,seed)")[0].split("# 2) slab twin slices")[1])   # defines variant()
fig=plt.figure(figsize=(7.2,4.2)); gsp=fig.add_gridspec(2,2,width_ratios=[1.7,1],hspace=0.6,wspace=0.3)
cmap={0:"#bbbbbb",1:CA,2:CB,3:CH,-1:CT}
for i,(pl,title) in enumerate(((False,"standard rules: sheets advance from step edges"),(True,"sheet-by-sheet variant: sheets start only from lifted nodes"))):
    r=grow_slab(64,64,100,seed=301,lift_dir='axis',planar=pl); P=r['pos']; Lx,Ly=r['box']
    v=variant(r); sl=(P[:,0]%Lx)<0.9
    ax=fig.add_subplot(gsp[i,0])
    for k,lab in ((1,"ABC"),(2,"ACB"),(3,"other registry"),(0,"substrate")):
        m=(v==k)&sl
        if m.any(): ax.scatter(P[m,2]/H,P[m,1]%Ly,s=.8,c=cmap[k],lw=0,label=lab,rasterized=True)
    ax.set_xlim(-1,100); ax.set_ylim(0,55.5); ax.set_xlabel("height (layers)"); ax.set_ylabel(r"$y$ ($L$)")
    ax.set_title(title,loc="left",fontsize=8)
    if i==0: ax.legend(markerscale=7,ncol=4,frameon=False,loc="lower center",bbox_to_anchor=(0.5,1.12),fontsize=7)
    tag(ax,"ab"[i],-0.1,1.03)
R=[json.loads(l) for l in open('results/planar.jsonl')]
ax=fig.add_subplot(gsp[:,1])
labels=["FCC","hcp","layer fill"]; keys=["fcc","hcp","layer_fill"]; x=np.arange(3); w=0.38
for j,(pl,col,lab) in enumerate(((False,CF,"standard"),(True,CH,"sheet-by-sheet"))):
    vals=[np.mean([r[k] for r in R if r['planar']==pl]) for k in keys]; err=[np.std([r[k] for r in R if r['planar']==pl])/np.sqrt(8) for k in keys]
    ax.bar(x+(j-.5)*w,vals,w,yerr=err,capsize=2,color=col,label=lab)
ax.set_xticks(x); ax.set_xticklabels(labels); ax.set_ylim(0,1.1); ax.set_ylabel("fraction (interior)"); ax.legend(frameon=False,fontsize=7,loc="upper left")
ax.set_title("8 slabs each (32² and 64²)",fontsize=8); tag(ax,"c",-0.25,1.01)
save(fig,"fig6_sheets")
