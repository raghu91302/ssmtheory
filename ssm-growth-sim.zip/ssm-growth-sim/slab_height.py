import sys; sys.path.insert(0,'.')
import numpy as np
from scipy.spatial import cKDTree
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import cna_periodic, _wrap, H
def profile(r, step=20):
    P=r['pos']; box=r['box']; z=P[:,2]; c=cna_periodic(P,box)
    Q,B=_wrap(P,box); t=cKDTree(Q,boxsize=B)
    nb=t.query_ball_point(Q,1.1)
    inplane=np.array([sum(abs(Q[j,2]-Q[i,2])<0.05 for j in nb[i] if j!=i) for i in range(len(Q))])
    on=np.abs(z/H-np.rint(z/H))<0.05
    nxy=r['stats']['n_substrate']
    out=[]
    for lo in range(0,int(z.max()/H),step):
        m=(z>=lo*H-0.4)&(z<(lo+step)*H-0.4)
        if m.sum()==0: break
        f=c[m]==1
        out.append((lo, m.sum()/(step*nxy), on[m].mean(), f.mean(), (c[m]==2).mean(), (inplane[m][f]==6).mean() if f.any() else np.nan))
    return out
for d in ['axis','both']:
    r=grow_slab(48,48,300,seed=4,lift_dir=d)
    print(d,'layer | density | on-lattice z | fcc | hcp | fcc nodes with [111]||z')
    for row in profile(r): print('  %4d  %.3f  %.3f  %.3f  %.4f  %.3f'%row)
