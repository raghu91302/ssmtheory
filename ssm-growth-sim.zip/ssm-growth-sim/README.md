# SSM growth simulations

Code, data and figures for

> R. Kulkarni, *Million-Node Simulations of K=12 Growth in the Selection-Stitch Model:
> Why the Stacking Is FCC and Which Voids Trap Matter* (2026).

The simulator grows the Selection-Stitch Model (SSM) lattice node by node with the two
growth rules, stitch and lift, and analyses the result. It reaches 10^6 nodes in about
20 s on one CPU core.

## Install and test

    pip install -r requirements.txt
    python tests/test_basic.py

All scripts are run from the repository root.

## Package (`ssmsim/`)

| File | Contents |
| --- | --- |
| `core.py` | Cluster grown from a three-node seed: `grow(N, seed, delta, w_site, lift_dir, refine, ...)` |
| `slab.py` | Periodic slab (a patch) grown upward from a complete close-packed sheet: `grow_slab(...)`, including the sheet-by-sheet variant (`planar=True`) |
| `analysis.py` | Common neighbour analysis (fcc / hcp / icosahedral), bulk mask, depth below surface, bonded-tetrahedron counts |
| `slab_analysis.py` | Layer registry (A/B/C), twin variants (ABC/ACB), periodic CNA, tetrahedron orientation, height profiles |
| `remnant.py` | Remnant-node trapping test: drop-and-settle onto the growing surface and classify the final site |

Key options: `lift_dir` = `"both"`, `"axis"` (one global orientation) or `"radial"`;
`mode` = `"site"` (geometric lift weight per site) or `"step"` (legacy fixed per-step
probability); `refine=True` applies the least-squares unit-bond condition (default).
Each node's index equals its creation time, and `grow` returns the triangle each node was
built on (`parent`).

## Scripts, by section of the paper

| Section | Script | Output |
| --- | --- | --- |
| 3.2 Monte Carlo check of the lift rate | `gather_figs.py` (MC part) | `figures/figdata.npz` |
| 5.1–5.6 Cluster sweeps (size, lift weight, legacy rule, exclusion radius, lift orientation) | `run_sweeps.py size lift step rex size_axis size_radial lift_axis` | `results/*.jsonl` |
| 5.x tables | `aggregate.py`, `compare.py` | printed tables |
| 5.5 Coordination dwell times | `k4check.py` | printed |
| 6.1–6.3 Slab production runs, twin coarsening, tilted grains | `run_slab2.py`, `analyse_slab_runs.py` | `results/slab2.jsonl` |
| 6.4 Void bias against depth | `depthbias.py`; layer-pair tetrahedron counts: `tetra_orientation.py` (uses `tetlib.py`) | printed |
| 6.5 Remnant trapping | `run_remnant.py` | `results/remnant.jsonl` |
| 6.6 How new sheets form; sheet-by-sheet variant | `nucleation.py`, `planar_test.py`, `planar_w.py` | `results/planar*.jsonl` |
| 6.7 Why the stacking is ABC (lattice check) | `lattice_check.py` | `results/lattice_check.json` |
| 7 Kinetic schemes | `validate.py` | printed |
| 7 Unit-bond condition (4 seeds at 10^6), CNA cutoff, bonding radius | `robust_checks.py` | `results/robust_checks.json` |
| Appendix A Instability of the bare rule | `slab_height.py` | printed |
| Appendix B Earlier implementation | `comparison/attrib.py` (copy `ssm_sim.py` from the main repository into `comparison/` and run there) | printed |
| Figures 1–5, 8 | `gather_figs.py`, then `make_paper_figs.py` | `figures/` |
| Figure 7 | `fig6.py` | `figures/fig6_sheets.*` |

Notes:

* The cluster sweeps of Section 5 were run without the unit-bond condition;
  `run_sweeps.py` sets `refine=False` to reproduce them. All slab runs, the remnant test,
  the sheet-formation runs and the lattice check use it.
* `results/superseded/slab_norefine.jsonl` holds the 48 slab runs made before the
  unit-bond condition was introduced; they are kept for the record (Appendix A).
* `run_sweeps.py`, `run_slab2.py` and `run_remnant.py` append to their output files and
  skip runs already present, so they can be resumed.

## Interactive visualizations (`viz/`)

* `lattice_growth.html` — both growth cases, node by node.
* `step_edge_sheet.html` — how a new sheet starts at a step edge (Figure 6).

The growth viewer is built from `viz/head.html`, `viz/data.json` and `viz/tail.html`;
`export_viz.py` regenerates `viz/data.json`, and

    cat viz/head.html viz/data.json viz/tail.html > viz/lattice_growth.html

rebuilds the page. Both pages load three.js r128 from a CDN.
