# SSM growth simulations

Code, data and figures for

> R. Kulkarni, *From the First Triangle to an Error-Correcting Lattice:
> Simulations of a Growing Bell-Pair Network* (2026).

The simulator grows the Selection-Stitch Model (SSM) lattice node by node with the two
growth rules, stitch and lift, and analyzes the result. It reaches 10^6 nodes in about
20 s on one CPU core.

## Install and test

    pip install -r requirements.txt
    python tests/test_basic.py

Further tests for the exact results: `tests/test_gf2_torus.py`, `tests/test_triangle.py`,
`tests/test_classical_exclusion.py`, `tests/test_bonds_checked.py`, `tests/test_bell_to_edge.py`,
`tests/test_deterministic_prep.py` (the last three take a minute or two).

All scripts are run from the repository root.

## Package (`ssmsim/`)

| File | Contents |
| --- | --- |
| `core.py` | Cluster grown from a three-node seed: `grow(N, seed, delta, w_site, lift_dir, refine, ...)` |
| `slab.py` | Periodic slab (a patch) grown upward from a complete close-packed sheet: `grow_slab(...)` |
| `analysis.py` | Common neighbor analysis (fcc / hcp / icosahedral), bulk mask, depth below surface, bonded-tetrahedron counts |
| `slab_analysis.py` | Layer registry (A/B/C), twin variants (ABC/ACB), periodic CNA, tetrahedron orientation, height profiles |
| `remnant.py` | Remnant-node trapping test: drop-and-settle onto the growing surface and classify the final site |

Key options: `lift_dir` = `"both"`, `"axis"` (one global orientation) or `"radial"`;
`mode` = `"site"` (geometric lift weight per site) or `"step"` (legacy fixed per-step
probability); `refine=True` applies the least-squares unit-bond condition (default), with
`rcap` (largest allowed move, default 0.02) and `rsteps` (Gauss-Newton steps, default 4).
Each node's index equals its creation time, and `grow` returns the triangle each node was
built on (`parent`).

## Scripts, by section of the paper

| Section | Script | Output |
| --- | --- | --- |
| 2.3 Lemmas 1–3: classical pure joint states are products; Bell-pair monogamy; triangle qubits maximally mixed | `tests/test_classical_exclusion.py` | printed |
| 2.4 With one qubit per bond, the triangle is the smallest simple network whose bonds check one another; GHZ state; octahedron = four triangles | `tests/test_triangle.py` | printed |
| 2.5 Every new node closes a triangle when it forms (no unchecked bonds) | `tests/test_bonds_checked.py` | printed |
| 4.2 Monte Carlo check of the lift rate (Table 5: 2e8 / 4e8 points, non-exclusive counting, standard errors) | `mc_check.py` | `results/mc_check.json` |
| 4.2 Monte Carlo points of Fig. 2b (4e7 points per value) | `gather_figs.py` (MC part) | `figures/figdata.npz` |
| 6.1–6.6 Cluster sweeps (size, lift weight, legacy rule, exclusion radius, lift orientation) | `run_sweeps.py size lift step rex size_axis size_radial lift_axis` | `results/*.jsonl` |
| 6.x tables | `aggregate.py`, `compare.py` | printed tables |
| 6.5 Coordination dwell times | `k4check.py` | printed |
| 7.1, 7.4–7.5 Slab production runs, twin coarsening, tilted grains | `run_slab2.py`, `analyse_slab_runs.py` | `results/slab2.jsonl` |
| 7.2 How new sheets form | `nucleation.py` | printed |
| 7.3 Why the stacking is ABC (lattice check) | `lattice_check.py` | `results/lattice_check.json` |
| 7.6 Void bias against depth | `depthbias.py`; layer-pair tetrahedron counts: `tetra_orientation.py` (uses `tetlib.py`; of its four slabs, the one taken over by a tilted grain is left out of the single-variant excess) | printed |
| 7.7 Remnant trapping | `run_remnant.py` | `results/remnant.jsonl` |
| 8.1 Bell-pair area law; 8.3–8.4 FCC stabilizer code on the grown graph (clusters and patches) | `quantum_lattice.py cluster N seed [w]`, `quantum_lattice.py slab nx layers seed` | `results/quantum_cluster_*.json`, `results/quantum_slab_*.json` |
| 8.2 Bell pairs to edge qubits: node parity checks give the edge-qubit code state; entropy S(A) = (cut − n_A − n_B + 1) ln 2 | `bellmap.py`; `tests/test_bell_to_edge.py`; deterministic preparation (measure, then repair) for every outcome: `tests/test_deterministic_prep.py` | printed |
| 8.3 Exact code parameters of patches (GF(2) ranks) | `quantum_gf2.py nx seed [w\|- [layers]]`; check against the published codes: `tests/test_gf2_torus.py` | `results/quantum_gf2_*.json` |
| 8 tables and Figure 8 | `aggregate_quantum.py`, `make_quantum_fig.py` | printed, `figures/fig_quantum.pdf` |
| 9 Kinetic schemes; Appendix B present-simulator rows | `validate.py` (uses the unit-bond condition by default; set `refine=False` in its `grow` calls to reproduce the bare-rule rows of Table A1) | printed |
| 9 Unit-bond condition (4 seeds at 10^6), CNA cutoff, bonding radius | `robust_checks.py` | `results/robust_checks.json` |
| 9 Settings of the unit-bond condition (Table 20: cap, number of steps, bare rule) | `unitbond_sensitivity.py` | `results/unitbond_sensitivity.json` |
| 9 Settings of the unit-bond condition on slabs (32x32x300, axis lift) | `slab_unitbond_sensitivity.py` | `results/slab_unitbond_sensitivity.json` |
| Appendix A Instability of the bare rule | `slab_height.py` | printed |
| Appendix B Earlier implementation | `comparison/attrib.py` (copy `ssm_sim.py` from the main repository into `comparison/` and run there) | printed |
| Figure 1 (overview schematic) | `make_overview_fig.py` | `figures/fig_overview.pdf` |
| Figures 2–4, 6–7, A1 | `gather_figs.py`, then `make_paper_figs.py` | `figures/` |

Figure files in `figures/` map to the paper as follows: `fig_overview` = Fig. 1, `fig1_model` = Fig. 2, `fig2_cluster` = Fig. 3, `fig3_lift_history` = Fig. 4, `fig7_stepedge` = Fig. 5 (step-edge schematic; static image, see `viz/step_edge_sheet.html` for the interactive version), `fig4_slab` = Fig. 6, `fig5_chiral` = Fig. 7, `fig_quantum` = Fig. 8, `figA1_instability` = Fig. A1.

Notes:

* The cluster sweeps of Section 6 were run without the unit-bond condition;
  `run_sweeps.py` sets `refine=False` to reproduce them. All slab runs, the remnant test,
  the sheet-formation runs, the lattice check, the quantum analysis of Section 8 and the
  coordination dwell-time run (`k4check.py`) use it.
* `results/superseded/slab_norefine.jsonl` holds the 48 slab runs made before the
  unit-bond condition was introduced; they are kept for the record (Appendix A).
* `run_sweeps.py`, `run_slab2.py` and `run_remnant.py` append to their output files and
  skip runs already present, so they can be resumed.

## Interactive visualizations (`viz/`)

* `lattice_growth.html` — both growth cases, node by node.
* `step_edge_sheet.html` — how a new sheet starts at a step edge (Figure 5).

The growth viewer is built from `viz/head.html`, `viz/data.json` and `viz/tail.html`;
`export_viz.py` regenerates `viz/data.json`, and

    cat viz/head.html viz/data.json viz/tail.html > viz/lattice_growth.html

rebuilds the page. Both pages load three.js r128 from a CDN.
