import sys,time,numpy as np; sys.path.insert(0,'.')
from ssmsim.core import grow
from ssmsim.analysis import summarize
for mode,kw in [("step",dict(p_step=0.05)),("site",dict(delta=0.05))]:
    rs=[summarize(r['pos'],r['deg']) | r['stats'] for r in (grow(1500,mode=mode,seed=s,**kw) for s in range(16))]
    f=np.array([x['bulk_fcc'] for x in rs]); h=np.array([x['bulk_hcp'] for x in rs]); lf=np.array([x['lift_fraction'] for x in rs])
    print(f"{mode}: N=1500 bulk fcc {100*f.mean():.1f}±{100*f.std()/4:.1f}%  hcp {100*h.mean():.1f}%  realized lift frac {100*lf.mean():.2f}%")
for N in [10**4,10**5,10**6]:
    t=time.time(); r=grow(N,seed=0); t1=time.time()-t; t=time.time(); s=summarize(r['pos'],r['deg']); t2=time.time()-t
    print(f"N={N}: grow {t1:.1f}s analyse {t2:.1f}s  bulk={s['n_bulk']} fcc={100*s['bulk_fcc']:.1f}% hcp={100*s['bulk_hcp']:.1f}% ico={100*s['bulk_ico']:.2f}% lift={100*r['stats']['lift_fraction']:.2f}% err={r['stats']['err']}")
