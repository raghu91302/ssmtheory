import sys; sys.path.insert(0,'.')
import numpy as np
from tetlib import per_pair
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import H
bins=[(0,1),(2,3),(4,5),(6,7),(8,9),(10,11),(12,19),(20,49),(50,99),(100,200)]
U=np.zeros(len(bins)); D=np.zeros(len(bins)); per_seed=[]
for s in range(6):
    r=grow_slab(32,32,260,seed=100+s,lift_dir='axis'); z=r['pos'][:,2]; n0=r['stats']['n_substrate']
    k=np.rint(z/H).astype(int); on=np.abs(z/H-k)<0.05
    cnt=np.bincount(k[on]); top=max(i for i in range(len(cnt)) if cnt[i]>=0.85*n0)
    up,dn=per_pair(r['adj'],r['deg'],z,H,len(cnt)+2)
    row=[]
    for b,(a,c) in enumerate(bins):
        sel=[top-1-d for d in range(a,c+1) if 1<=top-1-d]   # pair (lo,lo+1) with lo+1<=top
        u=up[sel].sum(); d_=dn[sel].sum(); U[b]+=u; D[b]+=d_; row.append((u-d_)/max(u+d_,1))
    per_seed.append(row)
print('depth (gaps below outermost complete layer) | along-growth bias (up-down)/total | n tetrahedra | seed spread')
ps=np.array(per_seed)
for b,(a,c) in enumerate(bins):
    print(f'{a:3d}-{c:<3d}  {(U[b]-D[b])/(U[b]+D[b]):+.4f}  n={int(U[b]+D[b]):7d}  sd/sqrt(n)={ps[:,b].std()/np.sqrt(len(ps)):.4f}')
