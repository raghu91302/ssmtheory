"""Figure 7 of the paper: quantum structure of the grown network (reads results/quantum_*.json)."""
import json, glob
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "serif", "mathtext.fontset": "cm", "font.size": 9, "axes.labelsize": 9,
                     "legend.fontsize": 7.5, "xtick.labelsize": 8, "ytick.labelsize": 8, "figure.dpi": 200,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.bbox": "tight"})
C1, C2, C3 = "#3b6ea5", "#c0392b", "#7a7a7a"
J = lambda f: json.load(open(f))
def tag(ax, s): ax.text(-0.16, 1.04, s, transform=ax.transAxes, fontweight="bold", fontsize=10, va="bottom")

fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.5), gridspec_kw=dict(wspace=0.85))

# (a) code quality against lift rate (mean over seeds at each lift weight)
ax = axs[0]
rows = [J(f) for f in sorted(glob.glob("results/quantum_cluster_100000_*.json"))]
ws = sorted({round(r["w_site"], 4) for r in rows})
def mse(v): v = np.array(v); return v.mean(), (v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0)
lf, npf, npe, exf, exe = [], [], [], [], []
for w in ws:
    rs = [r for r in rows if round(r["w_site"], 4) == w]
    lf.append(100 * np.mean([r["lift_fraction"] for r in rs]))
    m, e = mse([1 - r["interior_perfect"] for r in rs]); npf.append(m); npe.append(e)
    m, e = mse([10 * r["exposed_bond_fraction"] for r in rs]); exf.append(m); exe.append(e)
ax.errorbar(lf, npf, yerr=npe, fmt="o-", c=C1, ms=3.5, lw=1, capsize=2, label="nodes not code-perfect")
ax.errorbar(lf, exf, yerr=exe, fmt="s--", c=C2, ms=3.5, lw=1, capsize=2, label="exposed bonds ($\\times10$)")
ax.set_xlabel("realized lift fraction (%)"); ax.set_ylabel("fraction of interior")
ax.set_ylim(0, 0.165); ax.legend(frameon=False, loc="upper left", fontsize=7); tag(ax, "a")
dl = [np.pi / np.sqrt(2) * w for w in ws]
top = ax.twiny(); top.set_xlim(ax.get_xlim()); top.set_xticks([lf[i] for i in (2, 3, 4)])
top.set_xticklabels([f"{dl[i]:.2f}" for i in (2, 3, 4)], fontsize=7); top.set_xlabel("$\\delta$", fontsize=8, labelpad=2)
top.spines["top"].set_visible(True)

# (b) area law in clusters: crossing bonds per unit area against sphere radius
ax = axs[1]
for r in [r for r in rows if abs(r["w_site"] - 0.0225) < 1e-6]:
    a = r["area"]; ax.plot([x["R"] for x in a], [x["per_area"] for x in a], "-", c=C1, lw=0.8, alpha=0.8)
ax.axhline(3 * np.sqrt(2), c="k", ls="--", lw=0.8)
ax.text(0.97, 0.06, "ideal FCC $3\\sqrt{2}$", transform=ax.transAxes, ha="right", fontsize=7.5)
ax.set_xlabel("sphere radius $R$ ($L$)"); ax.set_ylabel("bonds cut per area ($L^{-2}$)")
ax.set_ylim(3.4, 4.6); tag(ax, "b")
ax2 = ax.twinx(); ax2.set_ylim(3.4 * np.log(2), 4.6 * np.log(2)); ax2.set_ylabel("$S/A$ (nats per $L^2$)")
ax2.spines["right"].set_visible(True)

# (c) patches: bonds cut by horizontal planes
ax = axs[2]
sl = [J(f) for f in sorted(glob.glob("results/quantum_slab_48_100_*.json"))]
m = [r["area"][0]["mean"] for r in sl]
ax.bar(range(len(sl)), m, yerr=[r["area"][0]["std"] for r in sl], color=C1, width=0.6, capsize=2, error_kw=dict(lw=0.8))
ax.axhline(2 * np.sqrt(3), c="k", ls="--", lw=0.8)
ax.text(len(sl) - 0.6, 2 * np.sqrt(3) + 0.05, "ideal (111) $2\\sqrt{3}$", ha="right", fontsize=7.5)
ax.set_xticks(range(len(sl))); ax.set_xticklabels([str(r["seed"]) for r in sl]); ax.set_xlabel("patch (seed)")
ax.set_ylim(2.8, 3.7); ax.set_ylabel("bonds cut per area ($L^{-2}$)"); tag(ax, "c")

fig.savefig("figures/fig_quantum.pdf"); fig.savefig("figures/fig_quantum.png", dpi=220)
