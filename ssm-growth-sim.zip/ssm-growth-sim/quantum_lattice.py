"""Quantum structure of the grown lattice.

For a grown cluster or patch this script measures
  * the FCC stabilizer code of Ref. [arXiv:2603.20294] on the grown bond graph:
      qubit on every bond, Z check on every node star, X check on every complete
      bonded octahedron (6 nodes, 12 bonds).  A node is "code-perfect" when it has
      12 bonds, sits on 6 complete octahedra and 8 bonded tetrahedra, as in ideal FCC;
  * CSS validity H_X H_Z^T = 0 (mod 2) on the grown graph;
  * the Bell-pair area law: with one Bell pair per bond, the entanglement entropy of a
    region is ln2 x (number of bonds that cross its boundary).  We count crossing bonds
    for spheres (clusters) and horizontal planes (patches) and compare with ideal FCC.

usage:  python quantum_lattice.py cluster N seed [w_site]
        python quantum_lattice.py slab nx layers seed
"""
import sys, os, json, time
import numpy as np
from numba import njit
from scipy.spatial import cKDTree
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmsim.core import grow
from ssmsim.slab import grow_slab
from ssmsim.analysis import tets_per_node

S2 = np.sqrt(2.0)


@njit(cache=True)
def _octahedra(pos, adj, deg, Lx, Ly):
    """All complete bonded octahedra.  Axis pair (i,j) at distance sqrt2 with exactly
    4 common neighbours forming a bonded square.  Returns rows of 6 sorted node ids."""
    n = len(deg)
    out = np.empty((6 * n + 10, 6), np.int64)
    m = 0
    mark = np.zeros(n, np.int64) - 1
    for i in range(n):
        for p in range(deg[i]):
            mark[adj[i, p]] = i
        # candidates j: neighbours of neighbours
        for p in range(deg[i]):
            b = adj[i, p]
            for q in range(deg[b]):
                j = adj[b, q]
                if j <= i or mark[j] == i:
                    continue
                dx = pos[j, 0] - pos[i, 0]; dy = pos[j, 1] - pos[i, 1]; dz = pos[j, 2] - pos[i, 2]
                if Lx > 0:
                    dx -= Lx * np.round(dx / Lx); dy -= Ly * np.round(dy / Ly)
                d = np.sqrt(dx * dx + dy * dy + dz * dz)
                if d < 1.25 or d > 1.6:
                    continue
                # common neighbours (process each j once: only via its smallest common nb)
                com = np.empty(12, np.int64); nc = 0; first = -1
                for r in range(deg[j]):
                    c = adj[j, r]
                    if mark[c] == i:
                        if nc < 12:
                            com[nc] = c
                        nc += 1
                        if first < 0 or c < first:
                            first = c
                if first != b or nc != 4:
                    continue
                ok = True
                for u in range(4):
                    k = 0
                    for v in range(4):
                        if u == v: continue
                        for r in range(deg[com[u]]):
                            if adj[com[u], r] == com[v]:
                                k += 1; break
                    if k != 2:
                        ok = False; break
                if not ok:
                    continue
                row = np.array([i, j, com[0], com[1], com[2], com[3]])
                row.sort()
                out[m] = row; m += 1
    return out[:m]


def octahedra(pos, adj, deg, box=None):
    Lx, Ly = (box if box is not None else (0.0, 0.0))
    o = _octahedra(pos, adj, deg, float(Lx), float(Ly))
    return np.unique(o, axis=0)


def depth(pos, box=None, r=2.0, threshold=42, max_depth=12):
    if box is not None:
        Lx, Ly = box
        P = pos.copy(); P[:, 0] %= Lx; P[:, 1] %= Ly; P[:, 2] -= P[:, 2].min()
        t = cKDTree(P, boxsize=[Lx, Ly, P[:, 2].max() * 3 + 10])
    else:
        P = pos; t = cKDTree(P)
    cnt = t.query_ball_point(P, r, return_length=True) - 1
    d = np.full(len(P), -1); surf = cnt < threshold; d[surf] = 0
    fr = np.where(surf)[0]; k = 0
    while len(fr) and k < max_depth:
        k += 1
        nb = t.query_ball_point(P[fr], 1.2)
        c = np.unique(np.concatenate([np.asarray(x, np.int64) for x in nb]))
        c = c[d[c] < 0]; d[c] = k; fr = c
    d[d < 0] = k + 1
    return d


def edge_list(adj, deg):
    n, K = adj.shape
    I = np.repeat(np.arange(n), K).reshape(n, K)
    msk = (np.arange(K)[None, :] < deg[:, None]) & (adj > I)
    return np.stack([I[msk], adj[msk]], 1)


def css_check(E, octs, nodes):
    """Max overlap parity between X checks (octahedra) and Z checks (stars of `nodes`)."""
    eid = {(int(a), int(b)): k for k, (a, b) in enumerate(E)}
    bad = 0
    nodeset = set(int(v) for v in nodes)
    for o in octs:
        oe = [eid.get((min(a, b), max(a, b))) for a in o for b in o if a < b]
        oe = [e for e in oe if e is not None]
        assert len(oe) == 12
        cnt = {}
        for e in oe:
            for v in E[e]:
                v = int(v)
                if v in nodeset:
                    cnt[v] = cnt.get(v, 0) + 1
        bad += sum(1 for c in cnt.values() if c % 2)
    return bad


def analyse(pos, adj, deg, box=None, dmin=3):
    t0 = time.time()
    E = edge_list(adj, deg)
    oc = octahedra(pos, adj, deg, box)
    noct = np.bincount(oc.ravel(), minlength=len(deg))
    ntet = tets_per_node(adj, deg)
    dep = depth(pos, box)
    inner = dep >= dmin
    perfect = (deg == 12) & (noct == 6) & (ntet == 8)
    # checks fully inside the interior region
    zin = inner
    xin = inner[oc].all(1)
    # per-node rates: ideal FCC has 6 qubits, 1 Z check, 1 X check per node
    ni = int(inner.sum())
    res = dict(n=int(len(deg)), n_interior=ni,
               interior_perfect=float(perfect[inner].mean()),
               interior_deg12=float((deg[inner] == 12).mean()),
               interior_oct6=float((noct[inner] == 6).mean()),
               interior_tet8=float((ntet[inner] == 8).mean()),
               x_density=float(noct[inner].mean() / 6),
               n_octahedra=int(len(oc)),
               qubits_per_interior_node=float(deg[inner].sum() / 2 / ni),
               deg_hist={int(k): int(v) for k, v in zip(*np.unique(deg[inner], return_counts=True))},
               noct_hist={int(k): int(v) for k, v in zip(*np.unique(noct[inner], return_counts=True))},
               ntet_hist={int(k): int(v) for k, v in zip(*np.unique(ntet[inner], return_counts=True))})
    # how many X checks (octahedra) cover each interior bond; ideal FCC: 2.
    # A bond in no X check is exposed: a Z error on it goes undetected.
    key = E[:, 0] * len(deg) + E[:, 1]
    oe = np.concatenate([np.minimum(oc[:, a], oc[:, b]) * len(deg) + np.maximum(oc[:, a], oc[:, b])
                         for a in range(6) for b in range(a + 1, 6)])
    srt = np.sort(key)
    pos_ = np.searchsorted(srt, oe)
    ok = (pos_ < len(srt)) & (srt[np.minimum(pos_, len(srt) - 1)] == oe)
    cov_sorted = np.bincount(pos_[ok], minlength=len(srt))
    cov = cov_sorted[np.searchsorted(srt, key)]
    ein = inner[E[:, 0]] & inner[E[:, 1]]
    res["bond_xcover_hist"] = {int(k): int(v) for k, v in zip(*np.unique(cov[ein], return_counts=True))}
    res["exposed_bond_fraction"] = float((cov[ein] == 0).mean())
    # geometric region (no structural mask, so vacancy pockets and twin walls count)
    if box is None:
        c = pos.mean(0); r = np.linalg.norm(pos - c, axis=1); Rg = 0.8 * np.median(r)
        reg = r < Rg; vol = 4 / 3 * np.pi * Rg ** 3
        octc = np.linalg.norm(pos[oc].mean(1) - c, axis=1) < Rg
    else:
        z = pos[:, 2] - pos[:, 2].min(); h = np.sqrt(2 / 3)
        z0, z1 = 3 * h, np.percentile(z, 90) - 8 * h
        reg = (z >= z0) & (z < z1); vol = box[0] * box[1] * (z1 - z0)
        zc = (pos[oc][:, :, 2] - pos[:, 2].min()).mean(1); octc = (zc >= z0) & (zc < z1)
    ideal_nodes = vol * S2                       # FCC number density sqrt2 / L^3
    breg = reg[E[:, 0]] & reg[E[:, 1]]
    ebr = reg[E[:, 0]] | reg[E[:, 1]]
    res["region"] = dict(
        fill=float(reg.sum() / ideal_nodes),
        deg12=float((deg[reg] == 12).mean()),
        perfect=float(perfect[reg].mean()),
        exposed_bond_fraction=float((cov[breg] == 0).mean()),
        xcover_hist={int(k): int(v) for k, v in zip(*np.unique(cov[breg], return_counts=True))},
        qubits_per_site=float((0.5 * ebr.sum() + 0.5 * breg.sum()) / ideal_nodes),
        z_per_site=float(reg.sum() / ideal_nodes),
        x_per_site=float(octc.sum() / ideal_nodes))
    q, zz, xx = res["region"]["qubits_per_site"], res["region"]["z_per_site"], res["region"]["x_per_site"]
    res["region"]["local_rate"] = float((q - zz - xx) / q)
    # CSS validity on a sample of octahedra
    samp = oc[np.random.default_rng(0).choice(len(oc), min(20000, len(oc)), replace=False)]
    res["css_odd_overlaps"] = css_check(E, samp, np.arange(len(deg)))
    res["css_octs_tested"] = int(len(samp))
    res["t_analyse"] = time.time() - t0
    return res, E, inner, perfect


def area_cluster(pos, E, n_r=12):
    """Bonds crossing spheres about the centroid, per unit area."""
    c = pos.mean(0)
    r = np.linalg.norm(pos - c, axis=1)
    rmax = np.median(r) * 0.8
    R = np.linspace(4, rmax, n_r)
    ra, rb = r[E[:, 0]], r[E[:, 1]]
    lo, hi = np.minimum(ra, rb), np.maximum(ra, rb)
    out = []
    for x in R:
        cut = int(((lo < x) & (hi >= x)).sum())
        out.append(dict(R=float(x), cut=cut, per_area=cut / (4 * np.pi * x * x)))
    return out


def area_slab(pos, E, box):
    """Bonds crossing horizontal planes, per unit area, at mid-layer and on-layer heights."""
    z = pos[:, 2]; A = box[0] * box[1]
    za, zb = z[E[:, 0]], z[E[:, 1]]
    lo, hi = np.minimum(za, zb), np.maximum(za, zb)
    h = np.sqrt(2 / 3)
    zt = np.percentile(z, 80)
    out = []
    for frac in (0.5, 0.25):
        Z = np.arange(h * (3 + frac), zt, h)
        v = np.array([((lo < x) & (hi >= x)).sum() / A for x in Z])
        out.append(dict(offset=frac, mean=float(v.mean()), std=float(v.std()), min=float(v.min()), n=len(v)))
    return out


def ideal_fcc_ball(R):
    g = np.arange(-int(R) - 3, int(R) + 4)
    X, Y, Z = np.meshgrid(g, g, g, indexing="ij")
    P = np.stack([X.ravel(), Y.ravel(), Z.ravel()], 1)
    P = P[(P.sum(1) % 2) == 0] / S2
    rot = np.linalg.qr(np.random.default_rng(1).normal(size=(3, 3)))[0]
    P = P @ rot.T + np.random.default_rng(2).uniform(-0.5, 0.5, 3)
    P = P[np.linalg.norm(P, axis=1) < R]
    t = cKDTree(P)
    E = np.array(sorted(t.query_pairs(1.05)))
    return P, E


if __name__ == "__main__":
    kind = sys.argv[1]
    os.makedirs("results", exist_ok=True)
    if kind == "cluster":
        N, seed = int(sys.argv[2]), int(sys.argv[3])
        w = float(sys.argv[4]) if len(sys.argv) > 4 else None
        t = time.time(); g = grow(N, seed=seed, refine=True, **({} if w is None else dict(w_site=w)))
        res, E, inner, perf = analyse(g["pos"], g["adj"], g["deg"])
        res.update(kind=kind, N=N, seed=seed, w_site=w if w is not None else 0.0225,
                   lift_fraction=g["stats"]["lift_fraction"], t_grow=time.time() - t)
        res["area"] = area_cluster(g["pos"], E)
        # ideal FCC reference at the largest radius
        Rm = res["area"][-1]["R"]
        P, Ei = ideal_fcc_ball(Rm + 2)
        res["area_ideal"] = area_cluster(P - P.mean(0) + 0, Ei, n_r=6)
        tag = f"cluster_{N}_{seed}_{res['w_site']:.4f}"
    else:
        nx, layers, seed = int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
        t = time.time(); g = grow_slab(nx=nx, ny=nx, layers=layers, seed=seed)
        res, E, inner, perf = analyse(g["pos"], g["adj"], g["deg"], g["box"])
        res.update(kind=kind, nx=nx, layers=layers, seed=seed,
                   lift_fraction=g["stats"]["lift_fraction"], t_grow=time.time() - t)
        res["area"] = area_slab(g["pos"], E, g["box"])
        # code density against height, bins of 10 layers (ideal: 1 node and 1 X check per site)
        P = g["pos"]; z = P[:, 2] - P[:, 2].min(); h = np.sqrt(2 / 3); A = g["box"][0] * g["box"][1]
        oc = octahedra(P, g["adj"], g["deg"], g["box"]); zc = (P[oc][:, :, 2] - P[:, 2].min()).mean(1)
        per = A / (np.sqrt(3) / 2)                 # sites per layer
        prof = []
        for b0 in range(1, layers - 10, 10):
            lo, hi = (b0 - 0.5) * h, (b0 + 9.5) * h
            prof.append(dict(layer=b0 + 5, fill=float(((z >= lo) & (z < hi)).sum() / (10 * per)),
                             x=float(((zc >= lo) & (zc < hi)).sum() / (10 * per))))
        res["profile"] = prof
        res["area_ideal_111"] = 2 * np.sqrt(3)
        tag = f"slab_{nx}_{layers}_{seed}"
    json.dump(res, open(f"results/quantum_{tag}.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in res.items() if k not in ("area", "area_ideal")}, indent=0))
    print("area", res["area"][:3] if kind == "cluster" else res["area"])
    if kind == "cluster":
        print("ideal", res["area_ideal"][-2:])
