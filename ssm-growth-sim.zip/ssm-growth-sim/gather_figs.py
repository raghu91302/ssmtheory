import sys; sys.path.insert(0,'.')
import numpy as np
from scipy.spatial import cKDTree
from ssmsim.core import grow
from ssmsim.analysis import cna, bulk_mask, depth_from_surface
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import registry, H, cna_periodic
out={}
# 1) cluster cross-section
r=grow(300000,seed=0,refine=True); P=r['pos']; c=cna(P); dep=depth_from_surface(P)
cen=P.mean(0); sl=np.abs(P[:,0]-cen[0])<0.45
out['cl_yz']=P[sl][:,1:]-cen[1:]; out['cl_code']=c[sl]; out['cl_depth']=dep[sl]
# 2) slab twin slices
def variant(res):
    P=res['pos']; z=P[:,2]; k=np.rint(z/H).astype(int); on=np.abs(z/H-k)<0.05
    reg,_=registry(P); v=np.full(len(P),-1)          # -1 tilted/off-lattice
    m=on&(k%3!=0); v[m&(reg==k%3)]=1; v[m&(reg==(-k)%3)]=2; v[m&(v<1)]=3   # 3 = other registry (stacking fault)
    A=np.where(on&(k%3==0))[0]; cl=np.where(v>=1)[0]
    Lx,Ly=res['box']; Q=P.copy(); Q[:,0]%=Lx; Q[:,1]%=Ly; Q[:,2]-=Q[:,2].min()
    t=cKDTree(Q[cl],boxsize=[Lx,Ly,Q[:,2].max()+50])
    _,nn=t.query(Q[A],k=6)
    for i,row in zip(A,nn):
        vals=v[cl[row]]; v[i]=np.bincount(vals,minlength=4).argmax()
    v[k<1]=0      # substrate
    return v
for name,(mode,seed) in {'slab_coarsen':('both',3),'slab_tilt':('axis',0)}.items():
    rs=grow_slab(64,64,300,seed=seed,lift_dir=mode); P=rs['pos']; Lx,Ly=rs['box']
    v=variant(rs); x=P[:,0]%Lx; sl=x<0.9
    out[name+'_yz']=np.c_[P[sl,1]%Ly,P[sl,2]]; out[name+'_v']=v[sl]
# 3) MC acceptance ratio vs delta
rng=np.random.default_rng(3)
A=np.array([0,0,0.]);B=np.array([1,0,0.]);C=np.array([.5,np.sqrt(3)/2,0])
ds=np.array([0.01,0.02,0.035,0.05,0.07,0.1]); rat=[]; err=[]
for d in ds:
    n3=n2=0
    for _ in range(4):
        Pm=rng.uniform([-1.2,-1.2,-1.2],[2.2,2.2,1.2],size=(10_000_000,3))
        ok=lambda X: np.abs(np.linalg.norm(Pm-X,axis=1)-1)<d
        a,b,cc=ok(A),ok(B),ok(C); n2+=(a&b).sum(); n3+=(a&b&cc).sum()
    rat.append(n3/n2); err.append(np.sqrt(n3)/n2)
out['mc_d']=ds; out['mc_r']=np.array(rat); out['mc_e']=np.array(err)
np.savez_compressed('figures/figdata.npz',**out)
print({k:np.shape(v) for k,v in out.items()}); print('MC',list(zip(ds,np.round(rat,4))))
