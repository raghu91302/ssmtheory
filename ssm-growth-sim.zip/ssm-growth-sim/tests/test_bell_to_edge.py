"""Section 8.2 (Bell pairs -> edge qubits).
(1) Triangle, explicit: Bell pairs on 3 bonds (6 virtual qubits), project each node onto even Z parity
    of its own two qubits; the result equals V^{x3} |GHZ>, with V|0>=|00>, V|1>=|11> per bond.
(2) Any connected graph: the projected state is pure (2E independent stabilizers), and for every node
    region A, S(A) = (|dA| - n_A - n_B + 1) ln2, with n_A, n_B the numbers of connected components
    of A and of its complement. Checked on random graphs and on a grown SSM cluster."""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, networkx as nx
from bellmap import generators, rank_rows, entropy
from ssmsim.core import grow

# (1) triangle, dense vectors. Qubit order: bond k has qubits (2k, 2k+1); bonds (0,1),(1,2),(2,0).
E = [(0, 1), (1, 2), (2, 0)]
bell = np.zeros(4); bell[0] = bell[3] = 2 ** -0.5
psi = bell
for _ in range(2): psi = np.kron(psi, bell)
Z = np.diag([1., -1.]); I = np.eye(2)
def op(ps):
    m = np.eye(1)
    for q in range(6): m = np.kron(m, ps.get(q, I))
    return m
for v in range(3):
    qs = [2 * k + (0 if E[k][0] == v else 1) for k in range(3) if v in E[k]]
    psi = (op({}) + op({q: Z for q in qs})) @ psi / 2
psi /= np.linalg.norm(psi)
ghz = np.zeros(8); ghz[0] = ghz[7] = 2 ** -0.5
Vemb = np.zeros((4, 2)); Vemb[0, 0] = Vemb[3, 1] = 1
V = Vemb
for _ in range(2): V = np.kron(V, Vemb)
assert abs(abs(psi @ (V @ ghz)) - 1) < 1e-12
print("triangle: projected Bell network = V^3 |GHZ>")

# (2) entropy formula
rng = np.random.default_rng(1)
def formula(G, A):
    B = set(G) - A
    cut = sum(1 for u, v in G.edges() if (u in A) != (v in A))
    return cut - (nx.number_connected_components(G.subgraph(A)) + nx.number_connected_components(G.subgraph(B)) - 1)
graphs = [nx.random_regular_graph(4, 14, seed=s) for s in range(3)] + [nx.octahedral_graph()]
g = grow(300, seed=0, refine=True)
FG = nx.Graph(); FG.add_nodes_from(range(len(g["deg"])))
for i in range(len(g["deg"])):
    for j in g["adj"][i, :g["deg"][i]]: FG.add_edge(i, int(j))
graphs.append(FG)
n_reg = 0
for G in graphs:
    _, _, n, rows, inc = generators(G)
    assert rank_rows(rows, range(n)) == n
    nodes = list(G)
    for t in range(15):
        if G is FG:
            P = g["pos"]; c = P[rng.integers(len(P))]
            A = set(np.where(np.linalg.norm(P - c, axis=1) < rng.uniform(1.5, 4))[0].tolist())
        else:
            A = set(rng.choice(nodes, size=rng.integers(1, len(nodes)), replace=False).tolist())
        if not A or len(A) == len(nodes): continue
        assert entropy(rows, n, [q for v in A for q in inc[v]]) == formula(G, A)
        n_reg += 1
print("entropy formula exact on", n_reg, "regions")
