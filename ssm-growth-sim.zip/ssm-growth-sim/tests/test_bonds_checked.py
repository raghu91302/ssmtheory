"""Section 2.5 check: every node joins with at least two bonds to earlier nodes, and two of those
earlier neighbours are bonded to each other, so each new node closes a triangle when it forms."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from ssmsim.core import grow
for seed in (0, 1):
    g = grow(20000, seed=seed, refine=True)
    adj, deg = g["adj"], g["deg"]
    nb = [set(int(x) for x in adj[i, :deg[i]]) for i in range(len(deg))]
    bad = 0
    for i in range(3, len(deg)):
        earlier = [j for j in nb[i] if j < i]
        if len(earlier) < 2 or not any(b in nb[a] for a in earlier for b in earlier if b > a):
            bad += 1
    print("seed", seed, "nodes not closing a triangle at birth:", bad)
    assert bad == 0
print("bond checks passed")
