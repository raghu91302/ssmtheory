"""Section 2.3, Lemmas 1-3.
1. Classical: every pure (extreme) state of a composite is a product, so it has zero mutual information.
2. Quantum monogamy: if A,B are in a Bell pair, then rho_AC = rho_A x rho_C for any third system C;
   classical perfect correlation, by contrast, can be shared with any number of partners.
3. The triangle (GHZ) state is pure while each of its qubits alone is maximally mixed."""
import itertools
import numpy as np

for X, Y in [(2, 2), (3, 4)]:
    for x, y in itertools.product(range(X), range(Y)):
        P = np.zeros((X, Y)); P[x, y] = 1
        assert np.allclose(P, np.outer(P.sum(1), P.sum(0)))

phi = np.zeros(4); phi[0] = phi[3] = 2 ** -0.5
rng = np.random.default_rng(0)
for _ in range(20):
    c = rng.normal(size=2) + 1j * rng.normal(size=2); c /= np.linalg.norm(c)
    R = np.outer(np.kron(phi, c), np.kron(phi, c).conj()).reshape([2] * 6)
    rAC = np.einsum('abcdbf->acdf', R).reshape(4, 4)
    rA = np.einsum('abcdbc->ad', R); rC = np.einsum('abcabf->cf', R)
    assert np.allclose(rAC, np.kron(rA, rC))
P = np.zeros((2, 2, 2)); P[0, 0, 0] = P[1, 1, 1] = 0.5
mi = lambda Q: sum(Q[i, j] * np.log2(Q[i, j] / (Q.sum(1)[i] * Q.sum(0)[j])) for i in range(2) for j in range(2) if Q[i, j] > 0)
assert abs(mi(P.sum(2)) - 1) < 1e-12 and abs(mi(P.sum(1)) - 1) < 1e-12

g = np.zeros(8); g[0] = g[7] = 2 ** -0.5
rho = np.outer(g, g)
assert abs(np.trace(rho @ rho) - 1) < 1e-12
r = rho.reshape([2] * 6)
for m in (np.einsum('abcdbc->ad', r), np.einsum('abcaec->be', r), np.einsum('abcabf->cf', r)):
    assert np.allclose(m, np.eye(2) / 2)
print("classical-exclusion lemmas passed")
