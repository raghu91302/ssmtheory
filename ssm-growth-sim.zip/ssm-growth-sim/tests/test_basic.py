import sys, numpy as np; sys.path.insert(0, '.')
from ssmsim.analysis import cna, bulk_mask
from ssmsim.core import grow, lift_weight_from_delta

def fcc_block(n=5):
    r = range(-n, n + 1)
    return np.array([(x, y, z) for x in r for y in r for z in r if (x + y + z) % 2 == 0]) / np.sqrt(2)

def hcp_block(n=6):
    pts = []
    a1 = np.array([1, 0, 0]); a2 = np.array([0.5, np.sqrt(3) / 2, 0]); h = np.sqrt(2 / 3)
    for k in range(-n, n + 1):
        shift = (a1 + a2) / 3 if k % 2 else np.zeros(3)
        for i in range(-n, n + 1):
            for j in range(-n, n + 1):
                pts.append(i * a1 + j * a2 + shift + np.array([0, 0, k * h]))
    return np.array(pts)

def ico13():
    phi = (1 + 5 ** 0.5) / 2
    v = []
    for a in (-1, 1):
        for b in (-phi, phi):
            v += [(0, a, b), (a, b, 0), (b, 0, a)]
    v = np.array(v, float); v /= np.linalg.norm(v[0])
    v *= 1.0 / np.linalg.norm(v[0] - v[np.argmin(np.linalg.norm(v[1:] - v[0], axis=1)) + 1]) * 1.0
    return np.vstack([[0, 0, 0], v * 0.97])

def test_fcc():
    P = fcc_block(); c = cna(P); inner = np.linalg.norm(P, axis=1) < 2.5
    assert (c[inner] == 1).all()

def test_hcp():
    P = hcp_block(); c = cna(P); inner = np.linalg.norm(P, axis=1) < 3.5
    assert (c[inner] == 2).all()

def test_ico():
    P = ico13(); c = cna(P); assert c[0] == 3

def test_bulk_fcc():
    P = fcc_block(6); m = bulk_mask(P); assert m[np.linalg.norm(P, axis=1) < 3].all()

def test_bonds_and_exclusion():
    r = grow(5000, seed=3); P = r['pos']
    from scipy.spatial import cKDTree
    d, _ = cKDTree(P).query(P, 2)
    assert d[:, 1].min() >= 0.95 - 1e-9
    a = r['adj']; deg = r['deg']
    for i in range(0, len(P), 97):
        for j in a[i, :deg[i]]:
            assert 0.95 - 1e-9 <= np.linalg.norm(P[i] - P[j]) < 1.05

def test_seed_and_determinism():
    r1 = grow(3000, seed=7); r2 = grow(3000, seed=7)
    assert np.array_equal(r1['pos'], r2['pos'])
    assert np.allclose(r1['pos'][2], [0.5, np.sqrt(3) / 2, 0])

def test_lift_weight():
    w = lift_weight_from_delta(0.05)
    assert abs(2 * w - 2 * np.sqrt(2) / np.pi * 0.05) < 1e-12

if __name__ == '__main__':
    for k, f in list(globals().items()):
        if k.startswith('test_'):
            f(); print('PASS', k)
