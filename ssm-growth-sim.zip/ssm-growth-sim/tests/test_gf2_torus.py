"""Check the GF(2) rank routine against the published [[192,130,3]] and [[648,434,3]] codes."""
import sys, os, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from quantum_gf2 import gf2_rank, packed

for L in (4, 6):
    nodes = [p for p in itertools.product(range(L), repeat=3) if sum(p) % 2 == 0]
    nid = {p: i for i, p in enumerate(nodes)}
    E = {}
    for p in nodes:
        for d in itertools.product((-1, 0, 1), repeat=3):
            if sorted(map(abs, d)) != [0, 1, 1]: continue
            q = tuple((p[k] + d[k]) % L for k in range(3))
            e = tuple(sorted((nid[p], nid[q])))
            E.setdefault(e, len(E))
    n = len(E)
    Z = [[] for _ in nodes]
    for (a, b), k in E.items(): Z[a].append(k); Z[b].append(k)
    X = []
    for o in itertools.product(range(L), repeat=3):
        if sum(o) % 2 == 0: continue
        vs = []
        for k in range(3):
            for s in (-1, 1):
                q = list(o); q[k] = (q[k] + s) % L; vs.append(nid[tuple(q)])
        X.append([E[tuple(sorted((a, b)))] for i, a in enumerate(vs) for b in vs[i + 1:] if tuple(sorted((a, b))) in E])
    assert all(len(x) == 12 for x in X)
    rz = gf2_rank(packed(Z, n)); rx = gf2_rank(packed(X, n))
    print(L, n, rz, rx, n - rz - rx)
    assert n - rz - rx == 2 * L**3 + 2
