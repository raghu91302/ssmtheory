"""Section 8.2: deterministic preparation by measurement and feed-forward.
For every allowed node-syndrome pattern s (product of outcomes = +1):
  (1) a correction X-string T with boundary(T) = {v: s_v = -1} exists, and applying it gives
      exactly the target state |psi_G> (same vector, no phase);
  (2) every operation commutes with the bond stabilizers Z_a Z_b, so the state stays in the
      encoded Bell-pair subspace;
  (3) all allowed patterns are equally likely, 2^-(N_V - 1), and patterns with odd numbers of -1
      never occur.
Checked with explicit state vectors on virtual qubits (two per bond) for the triangle, K4 and a
5-node bridgeless graph, over every syndrome pattern."""
import itertools
import numpy as np, networkx as nx

def apply_z(psi, qs, n):
    """Multiply by the product of Z on qubits qs (vector of length 2^n, qubit 0 = most significant)."""
    idx = np.arange(2 ** n); par = np.zeros(2 ** n, dtype=int)
    for j in qs: par ^= (idx >> (n - 1 - j)) & 1
    return psi * (1 - 2 * par)

def apply_x(psi, qs, n):
    mask = 0
    for j in qs: mask |= 1 << (n - 1 - j)
    return psi[np.arange(2 ** n) ^ mask]

def run(G):
    E = list(G.edges()); n = 2 * len(E)
    q = {}
    for k, (u, v) in enumerate(E): q[(k, u)] = 2 * k; q[(k, v)] = 2 * k + 1
    bell = np.zeros(4); bell[0] = bell[3] = 2 ** -0.5
    psi0 = np.ones(1)
    for _ in E: psi0 = np.kron(psi0, bell)
    Aq = {v: [q[(k, v)] for k, e in enumerate(E) if v in e] for v in G.nodes()}
    nodes = list(G.nodes()); probs = {}
    def project(psi, s):
        for v, sv in zip(nodes, s): psi = (psi + sv * apply_z(psi, Aq[v], n)) / 2
        return psi
    target = project(psi0, [1] * len(nodes)); target = target / np.linalg.norm(target)
    for s in itertools.product([1, -1], repeat=len(nodes)):
        out = project(psi0, s); p = float(out @ out)
        if np.prod(s) == -1:
            assert p < 1e-12; continue              # odd patterns never occur
        probs[s] = p; out = out / np.sqrt(p)
        inbell = lambda v: all(np.allclose(apply_z(v, [2 * k, 2 * k + 1], n), v) for k in range(len(E)))
        assert inbell(out)                          # still in the Bell-pair subspace
        D = {v for v, sv in zip(nodes, s) if sv == -1}
        T = set(); Dl = sorted(D)
        for a, b in zip(Dl[::2], Dl[1::2]):        # pair up defects, join by shortest paths
            path = nx.shortest_path(G, a, b)
            for x, y in zip(path, path[1:]):
                k = next(k for k, e in enumerate(E) if set(e) == {x, y}); T ^= {k}
        assert {v for v in nodes if sum(1 for k in T if v in E[k]) % 2} == D   # boundary of T = defects
        for k in T: out = apply_x(out, [2 * k, 2 * k + 1], n)
        assert inbell(out)
        assert np.allclose(out, target)             # exactly the same vector, no phase
    pv = np.array(list(probs.values()))
    assert np.allclose(pv, 2.0 ** -(len(nodes) - 1)) and abs(pv.sum() - 1) < 1e-12
    return len(probs)

for name, G in [("triangle", nx.complete_graph(3)), ("K4", nx.complete_graph(4)),
                ("C5+chord", nx.Graph([(0,1),(1,2),(2,3),(3,4),(4,0),(0,2)]))]:
    print(name, "allowed syndrome patterns all corrected exactly:", run(G))
