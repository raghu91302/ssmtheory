"""Section 2.4 checks: (1) the triangle is the smallest connected graph in which every bond lies on a loop
(so every single-bond error is detected by node Z checks and loop X checks); (2) its checks fix the GHZ state;
(3) each octahedral X check is the sum of four triangular faces."""
import itertools
import numpy as np
import networkx as nx

found = None
for m in range(1, 7):
    for n in range(2, m + 2):
        for es in itertools.combinations(itertools.combinations(range(n), 2), m):
            G = nx.Graph(); G.add_nodes_from(range(n)); G.add_edges_from(es)
            if nx.is_connected(G) and not list(nx.bridges(G)):
                found = (m, n, es); break
        if found: break
    if found: break
assert found[0] == 3 and found[1] == 3, found
for es in itertools.combinations(itertools.combinations(range(4), 2), 3):   # only the triangle among 3-bond graphs
    G = nx.Graph(); G.add_edges_from(es)
    assert bool(list(nx.bridges(G))) != (G.number_of_nodes() == 3), es

X = np.array([[0, 1], [1, 0]]); Z = np.diag([1, -1]); I = np.eye(2)
k = lambda a, b, c: np.kron(np.kron(a, b), c)
P = np.eye(8)
for s in (k(Z, Z, I), k(I, Z, Z), k(X, X, X)): P = P @ (np.eye(8) + s) / 2
assert round(np.trace(P)) == 1
w, v = np.linalg.eigh(P); psi = v[:, np.argmax(w)]
assert abs(abs(psi[0]) - 2 ** -0.5) < 1e-12 and abs(abs(psi[7]) - 2 ** -0.5) < 1e-12

V = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
dot = lambda a, b: sum(x * y for x, y in zip(V[a], V[b]))
E = [e for e in itertools.combinations(range(6), 2) if dot(*e) == 0]
F = [f for f in itertools.combinations(range(6), 3) if all(dot(a, b) == 0 for a, b in itertools.combinations(f, 2))]
cls = [f for f in F if np.prod(np.sum([V[i] for i in f], axis=0)) > 0]
cnt = {e: 0 for e in E}
for f in cls:
    for e in itertools.combinations(f, 2): cnt[e] += 1
assert len(E) == 12 and len(F) == 8 and len(cls) == 4 and set(cnt.values()) == {1}
print("triangle checks passed")
