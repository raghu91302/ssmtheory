import sys, json; sys.path.insert(0,'.')
from ssmsim.slab import grow_slab
exec(open('planar_test.py').read().split("out=open")[0])
out=open('results/planar_w.jsonl','a')
for w in [0.0225,0.002,0.0002,0.00002]:
    for s in range(2):
        r=grow_slab(32,32,80,seed=400+s,lift_dir='axis',planar=True,w_site=w); a=analyse(r)
        out.write(json.dumps(dict(w=w,seed=s,**a))+"\n")
        print(f"w={w:<8} seed {s}: nuclei/layer {a['nuclei_per_layer']:.1f}  fill {a['layer_fill']:.2f}  fcc {a['fcc']:.3f} hcp {a['hcp']:.3f}  lift frac {a['lift_fraction']:.3f}",flush=True)
