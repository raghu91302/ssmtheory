"""Slabs grown on a multi-layer ABC substrate (Reviewer 2, round 2).
The production slabs start from one complete close-packed sheet, whose first overlayer can occupy both
B and C hollows and so seeds both twin variants. Here the substrate is 3 complete layers stacked ABC.
Widths 32 and 48, 200 layers, axis lift, unit-bond condition, 8 seeds each; the 1-layer substrate is rerun
with the same settings for comparison. Writes results/abc_substrate.json."""
import sys, os, json, time, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import analyse_slab, height_profile
out = []
import glob
done = {}
log = os.environ.get("ABC_RESUME")
if log:
    for l in open(log):
        if l.startswith("{"):
            r = json.loads(l); done[(r["nsub"], r["width"], r["seed"])] = r
for nsub in (3, 1):
    for w in (32, 48):
        for seed in range(8):
            if (nsub, w, seed) in done:
                out.append(done[(nsub, w, seed)]); continue
            t = time.time(); r = grow_slab(w, w, 200, seed=seed, lift_dir="axis", nsub=nsub)
            a = analyse_slab(r); p = height_profile(r)
            imb = [abs(x["abc"] - x["acb"]) / max(1e-9, x["abc"] + x["acb"]) for x in p if x["on_lattice"] >= 0.9 and x["abc"] is not None and x["acb"] is not None]
            rec = dict(nsub=nsub, width=w, seed=seed, lift_fraction=r["stats"]["lift_fraction"],
                       on_lattice=a["on_lattice_frac"], interior_fcc=a.get("interior_fcc"),
                       twin_abc=a["twin_abc"], twin_acb=a["twin_acb"],
                       imbalance_first_bin=imb[0] if imb else None, imbalance_mean=float(np.mean(imb)) if imb else None,
                       min_bin_on_lattice=float(min(x["on_lattice"] for x in p)),
                       sequence_head=a["sequence"][:30], t=time.time() - t)
            out.append(rec); print(json.dumps(rec), flush=True)
json.dump(out, open("results/abc_substrate.json", "w"), indent=1)
