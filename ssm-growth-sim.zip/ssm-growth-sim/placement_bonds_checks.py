"""Bond lengths and code checks under off-site placement (second revision).
For the exact-site rule and the placement variants of random_placement.py (bare rule, N = 5e4, seeds 0 and 1),
measures in the geometric core: the spread of bond lengths, and the fraction of nodes that lie on all six
complete octahedra (the X checks of the FCC code), as in ideal FCC. Writes results/placement_bonds_checks.json."""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmsim.core import grow
from quantum_lattice import octahedra
CASES = [(0, 0.0), (1, 0.001), (1, 0.005), (1, 0.01), (1, 0.02), (1, 0.05), (2, 0.05)]
out = []
for jmode, eps in CASES:
    for seed in (0, 1):
        g = grow(50000, seed=seed, jmode=jmode, jamp=max(eps, 1e-9), refine=False)
        P, adj, deg = g["pos"], g["adj"], g["deg"]
        r = np.linalg.norm(P - P.mean(0), axis=1); core = r < 0.5 * r.max()
        L = []
        for i in np.where(core)[0]:
            for j in adj[i][:deg[i]]:
                if j > i or not core[j]: L.append(np.linalg.norm(P[i] - P[j]))
        L = np.abs(np.array(L) - 1.0)
        oc = octahedra(P, adj, deg)
        cnt = np.bincount(np.asarray(oc).ravel(), minlength=len(P)) if len(oc) else np.zeros(len(P), int)
        out.append(dict(jmode=jmode, eps=eps, seed=seed, core_nodes=int(core.sum()),
                        bond_dev_median=float(np.median(L)), bond_dev_max=float(L.max()),
                        frac_bonds_dev_gt_1e3=float((L > 1e-3).mean()),
                        core_six_octahedra=float((cnt[core] >= 6).mean()),
                        core_octahedra_per_node=float(cnt[core].mean() / 6)))
        print(json.dumps(out[-1]), flush=True)
json.dump(out, open("results/placement_bonds_checks.json", "w"), indent=1)
