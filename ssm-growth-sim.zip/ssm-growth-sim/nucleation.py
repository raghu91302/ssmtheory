import sys; sys.path.insert(0,'.')
import numpy as np
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import registry, H
from scipy.spatial import cKDTree
for nx,seed in [(32,1),(64,1)]:
    r=grow_slab(nx,nx,120,seed=seed,lift_dir='axis'); P=r['pos']; op=r['op']; n0=r['stats']['n_substrate']
    z=P[:,2]; k=np.rint(z/H).astype(int); on=np.abs(z/H-k)<0.05
    adj,deg=r['adj'],r['deg']
    first_op=[]; lifts=[]; tri_time=[]
    for L in range(1,100):
        idx=np.where(on&(k==L))[0]
        if len(idx)<0.85*n0: continue
        first=idx.min(); first_op.append(op[first])
        lifts.append((op[idx]==2).sum())
        # time (node index) when the first horizontal triangle forms in layer L, relative to first node
        S=set(idx.tolist()); t_tri=None
        for i in sorted(idx):
            nb=[j for j in adj[i,:deg[i]] if j in S and j<i]
            if any(b in set(adj[a,:deg[a]]) for a in nb for b in nb if a<b): t_tri=i; break
        tri_time.append(t_tri-first)
    first_op=np.array(first_op); lifts=np.array(lifts)
    print(f"{nx}x{nx}: layers={len(lifts)}  first node of a layer made by lift: {np.mean(first_op==2):.2f}  "
          f"lift-made nodes per layer: mean {lifts.mean():.1f} (median {np.median(lifts):.0f}) of {n0}  "
          f"placements between first node and first in-layer triangle: median {int(np.median(tri_time))}")
    # registry of lift-made nodes within one layer: do separate nuclei choose different stacking positions?
    L=20; idx=np.where(on&(k==L)&(op==2))[0]; reg,_=registry(P[idx])
    print(f"   layer {L}: lift-made nodes by lateral position A/B/C = {np.bincount(reg,minlength=3).tolist()}")
