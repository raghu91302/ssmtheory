import sys, json, time; sys.path.insert(0,'.')
import numpy as np
from ssmsim.core import grow
from ssmsim.analysis import cna, bulk_mask, summarize, depth_from_surface
out={}
# 1) unit-bond condition: 4 seeds at N=1e6, with and without
res={'with':[],'without':[]}
for s in range(4):
    for ref,k in ((True,'with'),(False,'without')):
        r=grow(1000000,seed=s,refine=ref); P=r['pos']; c=cna(P); m=bulk_mask(P); d=depth_from_surface(P)
        res[k].append(dict(bulk=float((c[m]==1).mean()), deep=float((c[d>=4]==1).mean()), hcp=float((c[m]==2).mean())))
    print('seed',s,res['with'][-1],res['without'][-1],flush=True)
out['unitbond']=res
# 2) CNA cutoff sensitivity on one refined 1e6 cluster
r=grow(1000000,seed=0,refine=True); P=r['pos']; m=bulk_mask(P); d=depth_from_surface(P)
cc={}
for rc in (1.15,(1+np.sqrt(2))/2,1.25,1.30):
    c=cna(P,rc=rc); cc[round(rc,3)]=dict(bulk=float((c[m]==1).mean()),deep=float((c[d>=4]==1).mean()),hcp=float((c[m]==2).mean()))
print('cutoff',cc,flush=True); out['cutoff']=cc
# 3) bonding radius sweep at N=3e4
rb={}
for x in (1.02,1.05,1.08,1.10):
    v=[]
    for s in range(4):
        r=grow(30000,seed=s,refine=True,r_b=x); P=r['pos']; c=cna(P); m=bulk_mask(P)
        v.append(float((c[m]==1).mean()))
    rb[x]=(float(np.mean(v)),float(np.std(v)/2))
print('r_b',rb,flush=True); out['rb']=rb
json.dump(out,open('results/robust_checks.json','w'))
