import json, numpy as np, collections
L=lambda n:[json.loads(l) for l in open(f"results/{n}.jsonl")]
def agg(rows,key,fields):
    g=collections.OrderedDict()
    for r in rows: g.setdefault(r['key'][key],[]).append(r)
    for k,rs in g.items():
        out=[f"{key}={k}", f"n={len(rs)}"]
        for f in fields:
            v=np.array([r[f] for r in rs],float); se=v.std(ddof=1)/np.sqrt(len(v)) if len(v)>1 else 0
            out.append(f"{f}={v.mean():.4f}±{se:.4f}")
        print("  ".join(out))
print("== SIZE"); agg(L("size"),"N",["bulk_fcc","bulk_hcp","bulk_ico","bulk_other","all_fcc","bulk_k12","mean_k","lift_fraction","iso"])
print("== LIFT (per-direction weight)"); agg(L("lift"),"w_site",["lift_fraction","bulk_fcc","bulk_hcp","bulk_other","iso"])
print("== STEP (legacy)"); agg(L("step"),"p_step",["lift_fraction","bulk_fcc","bulk_hcp"])
print("== REX"); 
g=collections.OrderedDict()
for r in L("rex"): g.setdefault(r['key']['r_ex'],[]).append(r)
for k,rs in g.items():
    print(f"r_ex={k:.2f} N={np.mean([r['n'] for r in rs]):.0f} mean_k={np.mean([r['mean_k'] for r in rs]):.2f} bulk_fcc={np.nanmean([r['bulk_fcc'] for r in rs]):.3f} all_fcc={np.mean([r['all_fcc'] for r in rs]):.3f} err={[r['err'] for r in rs]}")
big=[r for r in L("size") if r['key']['N']==1000000]
print("== DEPTH (N=1e6, mean over seeds): depth n fcc hcp")
for d in map(str,range(12)):
    xs=[r['depth_profile'][d] for r in big if d in r['depth_profile']]
    if xs: print(d, int(np.mean([x[0] for x in xs])), f"{np.mean([x[1] for x in xs]):.4f}", f"{np.mean([x[2] for x in xs]):.4f}")
print("== TETS per bulk node hist (N=1e6):", np.mean([r['bulk_tets_hist'] for r in big],0).round(0).astype(int).tolist(), "mean", np.mean([r['bulk_tets_mean'] for r in big]))
print("== EVOLUTION (N=1e6 runs, prefix t)")
for t in map(str,[30,100,300,1000,3000,10000,30000,100000,300000,1000000]):
    e=[r['evolution'][t] for r in big]
    f=lambda k: np.mean([x[k] for x in e if x[k] is not None]) if any(x[k] is not None for x in e) else float('nan')
    print(t, f"bulk={f('n_bulk'):.0f} fcc={f('fcc'):.3f} hcp={f('hcp'):.4f} meanK={f('mean_k'):.2f} K4frac={f('k4_frac'):.3f} tets/node={f('tets_all'):.2f} lift={f('lift_frac'):.4f}")
