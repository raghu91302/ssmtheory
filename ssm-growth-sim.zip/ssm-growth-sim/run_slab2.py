import sys, os, json, time, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import analyse_slab, height_profile, cna_periodic
TASKS = [dict(nx=n, ny=n, layers=L, seed=s, lift_dir=d)
         for n, L in [(32, 600), (48, 400), (64, 300)] for d in ["axis", "both"] for s in range(8)]
path = "results/slab2.jsonl"
have = {json.dumps(json.loads(l)["key"]) for l in open(path)} if os.path.exists(path) else set()
for key in TASKS:
    if json.dumps(key) in have: continue
    t = time.time(); r = grow_slab(**key); tg = time.time() - t
    a = analyse_slab(r); a["profile"] = height_profile(r); a["t_grow"] = tg
    a.pop("layers", None)
    with open(path, "a") as f: f.write(json.dumps({"key": key, **a}) + "\n")
    p = a["profile"]; print(key, "on_lattice top bins", [round(x["on_lattice"], 2) for x in p[-3:]], flush=True)
