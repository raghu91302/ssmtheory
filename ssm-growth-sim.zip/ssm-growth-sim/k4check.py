import sys; sys.path.insert(0,'.')
import numpy as np
from ssmsim.core import grow
r=grow(100000,seed=0,refine=True); adj,deg,op=r['adj'],r['deg'],r['op']; N=len(deg)
birth=np.array([(adj[i,:deg[i]]<i).sum() for i in range(N)])
print('degree at birth  stitch:',np.bincount(birth[op==1],minlength=7)[:7], '  lift:',np.bincount(birth[op==2],minlength=7)[:7])
# dwell time (in placements) at each degree K, for nodes born early enough to reach their final degree
dw={k:[] for k in range(2,12)}
for i in range(0,N//2):
    t=np.sort(adj[i,:deg[i]][adj[i,:deg[i]]>i])         # times when node i gains a bond
    k0=birth[i]; times=np.concatenate([[i],t])
    for s in range(len(t)):
        k=k0+s
        if 2<=k<12: dw[k].append(times[s+1]-times[s])
print('median dwell (placements) at each degree:', {k:int(np.median(v)) for k,v in dw.items() if v})
print('fraction of nodes (final K>=5) that ever had K=4:', np.mean([birth[i]<=4 for i in range(N//2) if deg[i]>=5]).round(3))
