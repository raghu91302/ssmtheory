import numpy as np, random, sys
import os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from ssmsim.analysis import summarize
import ssm_sim
src=open('ssm_sim.py').read()
variants={
 "original": src,
 "bond every step": src.replace("len(self.buffer) > 40","len(self.buffer) > 0"),
 "no z-axis stitch": src.replace("        else:\n            d = np.cross(p2 - p1, [0, 0, 1])","        else:\n            self.active_edges.discard((min(u,v), max(u,v)))\n            return False"),
}
variants["both fixes"]=variants["bond every step"].replace("        else:\n            d = np.cross(p2 - p1, [0, 0, 1])","        else:\n            self.active_edges.discard((min(u,v), max(u,v)))\n            return False")
for name,code in variants.items():
    ns={}; exec(compile(code,name,'exec'),ns)
    f=[]
    for s in range(8):
        random.seed(s); np.random.seed(s)
        sim=ns['SSMSim'](1500,0.05).run(); P=np.array(sim.nodes)
        f.append(summarize(P)['bulk_fcc'])
    print(f"{name:18s} bulk fcc {100*np.mean(f):.1f} ± {100*np.std(f)/np.sqrt(8):.1f}%")
