"""Tables for Section 7 (quantum structure) from results/quantum_*.json."""
import json, glob, collections
import numpy as np
J = lambda f: json.load(open(f))
ms = lambda v: (np.mean(v), np.std(v, ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0.0)

cl = [J(f) for f in glob.glob("results/quantum_cluster_100000_*.json")]
by = collections.defaultdict(list)
for r in cl: by[round(r["w_site"], 4)].append(r)
print("Lift sweep (clusters, N=1e5):")
print("w  delta  seeds  liftfrac  perfect(depth>=3)  perfect(region)  Xper site  exposed(region)  exposed(depth)  fill")
for w in sorted(by):
    rs = by[w]
    f = lambda k: ms([r[k] for r in rs]); g = lambda k: ms([r["region"][k] for r in rs])
    print(f"{w:.4f} {w*np.pi/np.sqrt(2):.3f} {len(rs)}  {f('lift_fraction')[0]:.4f}  "
          f"{f('interior_perfect')[0]:.3f}±{f('interior_perfect')[1]:.3f}  {g('perfect')[0]:.3f}±{g('perfect')[1]:.3f}  "
          f"{g('x_per_site')[0]:.3f}  {g('exposed_bond_fraction')[0]:.4f}±{g('exposed_bond_fraction')[1]:.4f}  "
          f"{f('exposed_bond_fraction')[0]:.4f}  {g('fill')[0]:.4f}  rate {g('local_rate')[0]:.4f}")

print("\nArea law, clusters (w=0.0225): bonds cut per L^2 at the largest radius, and mean over R>=8")
rs = by[0.0225]
last = [r["area"][-1]["per_area"] for r in rs]
mid = [np.mean([a["per_area"] for a in r["area"] if a["R"] >= 8]) for r in rs]
ideal = [np.mean([a["per_area"] for a in r["area_ideal"] if a["R"] >= 5]) for r in rs]
print("largest R", [round(r["area"][-1]["R"], 1) for r in rs], "per area", np.round(last, 3), "mean", ms(last))
print("mean R>=8", np.round(mid, 3), ms(mid), "ideal ball", ms(ideal), "theory", 3 * np.sqrt(2))

print("\nPatches:")
for f in sorted(glob.glob("results/quantum_slab_*.json")):
    r = J(f); g = r["region"]
    print(f.split("/")[-1], f"lift {r['lift_fraction']:.4f} perfect(depth) {r['interior_perfect']:.3f} "
          f"region perfect {g['perfect']:.3f} X/site {g['x_per_site']:.3f} exposed {g['exposed_bond_fraction']:.4f} "
          f"fill {g['fill']:.3f} rate {g['local_rate']:.4f} cut(111) {r['area'][0]['mean']:.3f}±{r['area'][0]['std']:.3f}")
    if "profile" in r:
        print("   X/site by height:", [(p["layer"], round(p["x"], 2)) for p in r["profile"]][::2])
s48 = [J(f) for f in glob.glob("results/quantum_slab_48_100_*.json")]
print("48-wide mean cut", ms([r["area"][0]["mean"] for r in s48]), "ideal", 2 * np.sqrt(3))

print("\nExact code parameters, 16x16 patches cut at 12 layers:")
for f in sorted(glob.glob("results/quantum_gf2_16_*.json")):
    r = J(f); g, i = r["grown"], r["ideal"]
    print(f"seed {r['seed']} w {r['w_site']}: nodes {g['nodes']}/{i['nodes']} qubits {g['n']}/{i['n']} "
          f"X {g['x_checks']}/{i['x_checks']} rankZ {g['rank_z']}/{i['rank_z']} rankX {g['rank_x']}/{i['rank_x']} "
          f"k {g['k']}/{i['k']} rate {g['rate']:.3f}/{i['rate']:.3f} odd {g['css_odd']}")
