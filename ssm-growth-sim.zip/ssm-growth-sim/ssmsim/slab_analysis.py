"""Layer-resolved analysis for periodic slabs (stacking axis = z = [111] of the substrate)."""
import numpy as np
from scipy.spatial import cKDTree
from .analysis import _cna, RC_CNA, _tets_per_node
from numba import njit

H = np.sqrt(2.0 / 3.0)


def _wrap(pos, box):
    Q = pos.copy(); Q[:, 0] %= box[0]; Q[:, 1] %= box[1]
    Q[:, 0] = np.minimum(Q[:, 0], np.nextafter(box[0], 0)); Q[:, 1] = np.minimum(Q[:, 1], np.nextafter(box[1], 0))
    Q[:, 2] -= Q[:, 2].min() - 1.0
    return Q, [box[0], box[1], Q[:, 2].max() + 10.0]


def cna_periodic(pos, box, rc=RC_CNA):
    Q, B = _wrap(pos, box)
    pairs = cKDTree(Q, boxsize=B).query_pairs(rc, output_type="ndarray")
    n = len(Q); i = np.concatenate([pairs[:, 0], pairs[:, 1]]); j = np.concatenate([pairs[:, 1], pairs[:, 0]])
    o = np.lexsort((j, i)); i, j = i[o], j[o]
    ptr = np.zeros(n + 1, np.int64); np.add.at(ptr, i + 1, 1)
    return _cna(np.cumsum(ptr), j.astype(np.int64))


def registry(pos):
    """Lateral close-packed registry of each node: 0 = A, 1 = B, 2 = C (substrate = A)."""
    x, y = pos[:, 0], pos[:, 1]
    v = y / (np.sqrt(3) / 2); u = x - 0.5 * v
    fu = np.mod(u, 1.0); fv = np.mod(v, 1.0)
    cands = np.array([[0, 0], [1 / 3, 1 / 3], [2 / 3, 2 / 3]])
    d = []
    for cu, cv in cands:
        du = np.mod(fu - cu + 0.5, 1) - 0.5; dv = np.mod(fv - cv + 0.5, 1) - 0.5
        d.append(du * du + dv * dv + du * dv)
    d = np.array(d)
    return np.argmin(d, 0), np.sqrt(np.min(d, 0))


@njit(cache=True)
def _tet_orient(adj, deg, z, H):
    """Count bonded tetrahedra by orientation along z: 3-in-a-layer + 1 above (up) or below (down)."""
    up = 0; down = 0; other = 0
    n = len(deg)
    zlist = np.zeros(4)
    for a in range(n):
        for p in range(deg[a]):
            b = adj[a, p]
            if b <= a: continue
            for q in range(deg[a]):
                c = adj[a, q]
                if c <= b: continue
                ok = False
                for r in range(deg[b]):
                    if adj[b, r] == c: ok = True; break
                if not ok: continue
                for s in range(deg[a]):
                    d = adj[a, s]
                    if d <= c: continue
                    o1 = False
                    for r in range(deg[b]):
                        if adj[b, r] == d: o1 = True; break
                    if not o1: continue
                    o2 = False
                    for r in range(deg[c]):
                        if adj[c, r] == d: o2 = True; break
                    if not o2: continue
                    zlist[0] = z[a]; zlist[1] = z[b]; zlist[2] = z[c]; zlist[3] = z[d]
                    zs = np.sort(zlist)
                    if zs[2] - zs[0] < 0.1 * H and abs(zs[3] - zs[2] - H) < 0.1 * H:
                        up += 1
                    elif zs[3] - zs[1] < 0.1 * H and abs(zs[1] - zs[0] - H) < 0.1 * H:
                        down += 1
                    else:
                        other += 1
    return up, down, other


def analyse_slab(res, full_frac=0.85):
    pos, box, deg, adj = res["pos"], res["box"], res["deg"], res["adj"]
    nx_ny = res["stats"]["n_substrate"]
    z = pos[:, 2]
    layer = np.rint(z / H).astype(int)
    on_lattice = np.abs(z / H - layer) < 0.05
    reg, rdist = registry(pos)
    codes = cna_periodic(pos, box)
    # complete layers: occupancy >= full_frac of a full close-packed layer, contiguous from substrate
    counts = np.bincount(np.clip(layer, 0, None)[on_lattice], minlength=layer.max() + 2)
    top = 0
    while top + 1 < len(counts) and counts[top + 1] >= full_frac * nx_ny:
        top += 1
    out = dict(stats=res["stats"], n_complete_layers=int(top),
               on_lattice_frac=float(on_lattice[pos[:, 2] <= top * H + 1e-6].mean()))
    per = []
    for k in range(0, top + 1):
        m = (layer == k) & on_lattice
        regc = np.bincount(reg[m], minlength=3) / max(1, m.sum())
        cc = np.bincount(codes[m], minlength=4) / max(1, m.sum())
        abc = float((reg[m] == k % 3).mean()) if (k % 3 and m.sum()) else None
        acb = float((reg[m] == (-k) % 3).mean()) if (k % 3 and m.sum()) else None
        per.append(dict(k=k, n=int(m.sum()), occ=float(m.sum() / nx_ny), reg=regc.tolist(), fcc=float(cc[1]),
                        hcp=float(cc[2]), other=float(cc[0]), ico=float(cc[3]), abc=abc, acb=acb))
    out["layers"] = per
    seq = [int(np.argmax(p["reg"])) for p in per]
    out["sequence"] = "".join("ABC"[s] for s in seq)
    out["purity"] = float(np.mean([max(p["reg"]) for p in per]))
    ab = [p["abc"] for p in per if p["abc"] is not None]; ac = [p["acb"] for p in per if p["acb"] is not None]
    out["twin_abc"] = float(np.mean(ab)) if ab else np.nan
    out["twin_acb"] = float(np.mean(ac)) if ac else np.nan
    trip = [(seq[i - 1], seq[i], seq[i + 1]) for i in range(1, len(seq) - 1)]
    out["frac_hcp_triplets"] = float(np.mean([a == c for a, b, c in trip])) if trip else np.nan
    # tetrahedron orientation in the complete-layer interior (exclude substrate and top 2 layers)
    sel = (layer >= 1) & (layer <= top - 2)
    idx = np.where(sel)[0]
    if len(idx):
        remap = -np.ones(len(pos), np.int64); remap[idx] = np.arange(len(idx))
        sub = adj[idx].copy(); valid = sub >= 0; sub[valid] = remap[sub[valid]]; sub[~valid] = -1
        sub = np.where(sub >= 0, sub, -1).astype(np.int32)
        sub_sorted = np.ascontiguousarray(np.sort(sub, axis=1)[:, ::-1]).astype(np.int32)
        dsub = (sub_sorted >= 0).sum(1).astype(np.int32)
        up, down, oth = _tet_orient(sub_sorted, dsub, z[idx], H)
        out["tets_up"], out["tets_down"], out["tets_other"] = int(up), int(down), int(oth)
        bulk = (layer >= 2) & (layer <= top - 2) & on_lattice
        out["interior_fcc"] = float((codes[bulk] == 1).mean()); out["interior_hcp"] = float((codes[bulk] == 2).mean())
        out["interior_other"] = float((codes[bulk] == 0).mean())
    # roughness of the growth front: height of highest node per lateral cell
    Q = pos.copy(); Q[:, 0] %= box[0]; Q[:, 1] %= box[1]
    cx = (Q[:, 0] // 2).astype(int); cy = (Q[:, 1] // 2).astype(int)
    key = cx * 100000 + cy
    hmax = {}
    for kk, zz in zip(key, z):
        if zz > hmax.get(kk, -1e9): hmax[kk] = zz
    hv = np.array(list(hmax.values()))
    out["front_mean"] = float(hv.mean()); out["front_rms"] = float(hv.std())
    return out


def height_profile(res, codes=None, bin_layers=10):
    """Profile in bins of `bin_layers` layers over the whole slab (no completeness requirement).
    on_lattice = fraction of nodes at a [111]||z layer height (substrate orientation);
    abc / acb = twin-variant fractions among on-lattice nodes in layers k % 3 != 0."""
    pos, box = res["pos"], res["box"]; n0 = res["stats"]["n_substrate"]
    z = pos[:, 2]; k = np.rint(z / H).astype(int); on = np.abs(z / H - k) < 0.05
    reg, _ = registry(pos)
    if codes is None:
        codes = cna_periodic(pos, box)
    out = []
    top = int(z.max() / H)
    for lo in range(0, top + 1, bin_layers):
        m = (z >= (lo - 0.5) * H) & (z < (lo + bin_layers - 0.5) * H)
        if m.sum() == 0:
            break
        mm = m & on & (k % 3 != 0)
        abc = float((reg[mm] == (k[mm] % 3)).mean()) if mm.any() else None
        acb = float((reg[mm] == ((-k[mm]) % 3)).mean()) if mm.any() else None
        out.append(dict(lo=lo, density=float(m.sum() / (bin_layers * n0)), on_lattice=float(on[m].mean()),
                        fcc=float((codes[m] == 1).mean()), hcp=float((codes[m] == 2).mean()), abc=abc, acb=acb))
    return out
