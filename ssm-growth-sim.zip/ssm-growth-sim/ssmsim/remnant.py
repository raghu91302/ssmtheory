"""
Remnant-node trapping test (Proposition 8 of 'One Chiral Bit').

A remnant node of the frozen foam is modelled as a small sphere that must stay at least
R = sqrt(3/8) L = 0.612 L from every lattice atom (its closest approach in a void).
At a randomly chosen growth time t, a remnant is dropped at a random lateral position
onto the surface formed by the first t nodes of a slab and settles under gravity (-z)
until it rests on its contacts (drop-and-roll with constraint projection).

The rest of the growth is then taken as it happened (passive-tracer approximation),
and the remnant's final environment is classified:
  tet_along   : 4 atoms at ~R, three below it and one above  (apex along growth, +z)
  tet_against : 4 atoms at ~R, one below and three above
  oct_like    : 3 atoms at ~R below, none above at ~R (open hollow -> octahedral side)
  uncovered   : nothing above it (still at the surface)
  conflict    : a later atom came closer than R - tol (growth would have been blocked)
"""
import numpy as np
from scipy.spatial import cKDTree

R = np.sqrt(3.0 / 8.0)


def _mi(d, box):
    d = d.copy()
    d[..., 0] -= box[0] * np.round(d[..., 0] / box[0])
    d[..., 1] -= box[1] * np.round(d[..., 1] / box[1])
    return d


def settle(xy, t, P, tree, box, zshift, rng, dz=0.01, max_iter=4000):
    """Drop a sphere of radius R at lateral position xy onto the first t nodes."""
    Lx, Ly = box
    near = tree.query_ball_point([xy[0] % Lx, xy[1] % Ly, 0.0], 0, p=2)  # unused placeholder
    # start just above the highest prefix atom in a 1.5 L column
    col = tree.query_ball_point(np.array([[xy[0] % Lx, xy[1] % Ly, z] for z in
                                          np.arange(0, P[:, 2].max() + 2, 1.0)]), 1.5)
    ids = {j for lst in col for j in lst if j < t}
    ztop = max(P[j, 2] for j in ids) if ids else 0.0
    c = np.array([xy[0] % Lx, xy[1] % Ly, ztop + R + 0.3])
    last = []
    for it in range(max_iter):
        c[2] -= dz
        for _ in range(6):
            idx = [j for j in tree.query_ball_point(c, R) if j < t]
            if not idx:
                break
            d = _mi(c[None, :] - P[idx], box)
            n = np.linalg.norm(d, axis=1)
            k = np.argmin(n)
            c = c + d[k] / n[k] * (R - n[k] + 1e-9)
        c[0] %= Lx; c[1] %= Ly
        last.append(c[2])
        if len(last) > 200 and abs(last[-200] - last[-1]) < 2e-4:
            break
    return c, it


def classify(c, t, P, tree, box, tol=0.04):
    idx = tree.query_ball_point(c, 0.75)
    d = _mi(P[idx] - c[None, :], box)
    n = np.linalg.norm(d, axis=1)
    idx = np.array(idx)
    contacts_before = int(((n < R + tol) & (idx < t)).sum())
    if np.any(n < R - tol):
        return "conflict", contacts_before
    close = n < R + tol
    above = int((close & (d[:, 2] > 0)).sum()); below = int((close & (d[:, 2] < 0)).sum())
    anything_above = tree.query_ball_point(c + np.array([0, 0, 1.0]), 1.0)
    if above == 1 and below == 3:
        return "tet_along", contacts_before
    if above == 3 and below == 1:
        return "tet_against", contacts_before
    if above == 0 and below == 3:
        return ("oct_like" if anything_above else "uncovered"), contacts_before
    return f"other_{below}b{above}a", contacts_before


def trap_experiment(res, n_remnants=200, min_layers_above=15, seed=0):
    rng = np.random.default_rng(seed)
    pos = res["pos"]; Lx, Ly = res["box"]; n0 = res["stats"]["n_substrate"]
    P = pos.copy(); P[:, 0] %= Lx; P[:, 1] %= Ly
    P[:, 0] = np.minimum(P[:, 0], np.nextafter(Lx, 0)); P[:, 1] = np.minimum(P[:, 1], np.nextafter(Ly, 0))
    zshift = 0.0
    tree = cKDTree(P, boxsize=[Lx, Ly, P[:, 2].max() + 50])
    N = len(P)
    t_lo = n0 * 5; t_hi = N - n0 * min_layers_above
    out = []
    for _ in range(n_remnants):
        t = int(rng.integers(t_lo, t_hi))
        xy = rng.uniform([0, 0], [Lx, Ly])
        c, it = settle(xy, t, P, tree, (Lx, Ly), zshift, rng)
        cls, nc = classify(c, t, P, tree, (Lx, Ly))
        out.append(dict(t=t, cls=cls, contacts=nc, z=float(c[2]), iters=it))
    return out
