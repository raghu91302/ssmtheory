"""
Slab ("patch") geometry for the SSM growth rules.

A patch of the observable universe far from any centre is modelled as a slab that is
periodic in x and y.  The initial condition is one complete close-packed layer of
Bell-pair bonds (the already-crystallized past) at z = 0; growth proceeds into z > 0.
The rules are identical to core.py (3 stitch + up to 2 lift sites per triangle,
hard-shell exclusion r_ex, proximity bonding r_b, each site tried once).

lift_dir = "axis": only the lift side whose normal has a +z component (one global
                   lift orientation, the 'patch' hypothesis)
lift_dir = "both": both lift sides (no preferred orientation)
Nothing may be placed below the substrate plane (z < -0.01).
"""
import numpy as np
from numba import njit

KMAX = 40
H_STITCH = np.sqrt(3.0) / 2.0
H_LIFT = np.sqrt(2.0 / 3.0)


@njit(cache=True)
def _mi(d, box):
    return d - box * np.floor(d / box + 0.5)


@njit(cache=True)
def _grow_slab(nx, ny, n_add, w_site, r_ex, r_b, seed, Gz, cap, lift_both, refine, planar):
    np.random.seed(seed)
    Lx = float(nx); Ly = ny * H_STITCH
    ncx = int(Lx / max(r_b, 1.0)); ncy = int(Ly / max(r_b, 1.0))
    csx = Lx / ncx; csy = Ly / ncy; csz = max(r_b, 1.0)
    n0 = nx * ny; N = n0 + n_add
    pos = np.zeros((N, 3)); op = np.zeros(N, np.int8)
    deg = np.zeros(N, np.int32); adj = -np.ones((N, KMAX), np.int32)
    grid = -np.ones((ncx, ncy, Gz, cap), np.int32); gcnt = np.zeros((ncx, ncy, Gz), np.int8)
    cap_t = 12 * N + 64; tri = np.zeros((cap_t, 3), np.int32); nt = 0
    capS = 4 * N + 64; capL = 4 * N + 64
    S = np.zeros(capS, np.int64); nS = 0; Lq = np.zeros(capL, np.int64); nL = 0
    err = 0
    newnb = np.zeros(KMAX, np.int32); cand = np.zeros(3)
    zoff = 2

    # ---- substrate: complete triangular layer ----
    for j in range(ny):
        for i in range(nx):
            m = j * nx + i
            pos[m, 0] = i + 0.5 * (j % 2); pos[m, 1] = j * H_STITCH; pos[m, 2] = 0.0
            gx = int(pos[m, 0] / csx) % ncx; gy = int(pos[m, 1] / csy) % ncy; gz = zoff
            grid[gx, gy, gz, gcnt[gx, gy, gz]] = m; gcnt[gx, gy, gz] += 1
            op[m] = 0
    for m in range(n0):
        for q in range(n0):
            if q <= m: continue
            dx = _mi(pos[q, 0] - pos[m, 0], Lx); dy = _mi(pos[q, 1] - pos[m, 1], Ly)
            if dx * dx + dy * dy < 1.0 + 1e-6:
                adj[m, deg[m]] = q; deg[m] += 1; adj[q, deg[q]] = m; deg[q] += 1
    for a in range(n0):
        for p in range(deg[a]):
            b = adj[a, p]
            if b <= a: continue
            for r in range(deg[a]):
                c = adj[a, r]
                if c <= b: continue
                bc = False
                for s_ in range(deg[b]):
                    if adj[b, s_] == c: bc = True; break
                if not bc: continue
                tri[nt, 0] = a; tri[nt, 1] = b; tri[nt, 2] = c
                for k in range(3):
                    S[nS] = 3 * nt + k; nS += 1
                ux = _mi(pos[b, 0] - pos[a, 0], Lx); uy = _mi(pos[b, 1] - pos[a, 1], Ly)
                vx = _mi(pos[c, 0] - pos[a, 0], Lx); vy = _mi(pos[c, 1] - pos[a, 1], Ly)
                nz_ = ux * vy - uy * vx
                Lq[nL] = 2 * nt + (0 if nz_ > 0 else 1); nL += 1      # +z side only (floor)
                nt += 1
    n = n0
    n_ok_s = 0; n_ok_l = 0; attempts = 0

    while n < N and attempts < 50_000_000:
        if nS == 0 and nL == 0: break
        attempts += 1
        wS = float(nS); wL = w_site * nL
        do_lift = np.random.random() * (wS + wL) < wL
        if do_lift:
            i = np.random.randint(nL); site = Lq[i]; nL -= 1; Lq[i] = Lq[nL]
            t = site // 2; sgn = 1.0 if site % 2 == 0 else -1.0
        else:
            i = np.random.randint(nS); site = S[i]; nS -= 1; S[i] = S[nS]
            t = site // 3
        a = tri[t, 0]; b = tri[t, 1]; c = tri[t, 2]
        if not do_lift:
            k = site % 3
            cc = tri[t, k]; aa = tri[t, (k + 1) % 3]; bb = tri[t, (k + 2) % 3]
            a = aa; b = bb; c = cc
        # unwrap b, c relative to a
        bx = pos[a, 0] + _mi(pos[b, 0] - pos[a, 0], Lx); by = pos[a, 1] + _mi(pos[b, 1] - pos[a, 1], Ly); bz = pos[b, 2]
        cx_ = pos[a, 0] + _mi(pos[c, 0] - pos[a, 0], Lx); cy_ = pos[a, 1] + _mi(pos[c, 1] - pos[a, 1], Ly); cz_ = pos[c, 2]
        ax = pos[a, 0]; ay = pos[a, 1]; az = pos[a, 2]
        if do_lift:
            ux = bx - ax; uy = by - ay; uz = bz - az; vx = cx_ - ax; vy = cy_ - ay; vz = cz_ - az
            nx_ = uy * vz - uz * vy; ny_ = uz * vx - ux * vz; nz_ = ux * vy - uy * vx
            nn = np.sqrt(nx_ * nx_ + ny_ * ny_ + nz_ * nz_)
            if nn < 1e-12: continue
            cand[0] = (ax + bx + cx_) / 3.0 + sgn * H_LIFT * nx_ / nn
            cand[1] = (ay + by + cy_) / 3.0 + sgn * H_LIFT * ny_ / nn
            cand[2] = (az + bz + cz_) / 3.0 + sgn * H_LIFT * nz_ / nn
        else:
            # here a,b = edge, c = third vertex (all unwrapped relative to a)
            mx = 0.5 * (ax + bx); my = 0.5 * (ay + by); mz = 0.5 * (az + bz)
            ex = bx - ax; ey = by - ay; ez = bz - az; el2 = ex * ex + ey * ey + ez * ez
            wx = mx - cx_; wy = my - cy_; wz = mz - cz_
            pr = (wx * ex + wy * ey + wz * ez) / el2
            wx -= pr * ex; wy -= pr * ey; wz -= pr * ez
            wn = np.sqrt(wx * wx + wy * wy + wz * wz)
            if wn < 1e-12: continue
            cand[0] = mx + H_STITCH * wx / wn; cand[1] = my + H_STITCH * wy / wn; cand[2] = mz + H_STITCH * wz / wn
        if cand[2] < -0.01: continue
        cand[0] = cand[0] % Lx; cand[1] = cand[1] % Ly
        if cand[0] >= Lx: cand[0] -= Lx
        if cand[1] >= Ly: cand[1] -= Ly
        gx = int(cand[0] / csx) % ncx; gy = int(cand[1] / csy) % ncy; gz = int(np.floor(cand[2] / csz)) + zoff
        if gz < 1 or gz > Gz - 2:
            err = 1; break
        blocked = False; nnb = 0
        for ddx in range(-1, 2):
            for ddy in range(-1, 2):
                for ddz in range(-1, 2):
                    hx = (gx + ddx) % ncx; hy = (gy + ddy) % ncy; hz = gz + ddz
                    for q in range(gcnt[hx, hy, hz]):
                        j = grid[hx, hy, hz, q]
                        dx = _mi(pos[j, 0] - cand[0], Lx); dy = _mi(pos[j, 1] - cand[1], Ly); dz = pos[j, 2] - cand[2]
                        d2 = dx * dx + dy * dy + dz * dz
                        if d2 < r_ex * r_ex:
                            blocked = True; break
                        if d2 < r_b * r_b and nnb < KMAX:
                            newnb[nnb] = j; nnb += 1
                    if blocked: break
                if blocked: break
            if blocked: break
        if blocked: continue
        if refine and nnb >= 3:
            # least-squares unit-bond refinement: minimise sum_j (|x - p_j| - 1)^2 (Gauss-Newton)
            x0 = cand[0]; y0 = cand[1]; z0 = cand[2]
            for it in range(4):
                JTJ = np.zeros((3, 3)); JTr = np.zeros(3)
                for q in range(nnb):
                    j = newnb[q]
                    dx = -_mi(pos[j, 0] - cand[0], Lx); dy = -_mi(pos[j, 1] - cand[1], Ly); dz = cand[2] - pos[j, 2]
                    d = np.sqrt(dx * dx + dy * dy + dz * dz)
                    g0 = dx / d; g1 = dy / d; g2 = dz / d; res_ = d - 1.0
                    JTJ[0, 0] += g0 * g0; JTJ[0, 1] += g0 * g1; JTJ[0, 2] += g0 * g2
                    JTJ[1, 1] += g1 * g1; JTJ[1, 2] += g1 * g2; JTJ[2, 2] += g2 * g2
                    JTr[0] += g0 * res_; JTr[1] += g1 * res_; JTr[2] += g2 * res_
                JTJ[1, 0] = JTJ[0, 1]; JTJ[2, 0] = JTJ[0, 2]; JTJ[2, 1] = JTJ[1, 2]
                if abs(np.linalg.det(JTJ)) < 1e-10: break
                st_ = np.linalg.solve(JTJ, JTr)
                cand[0] -= st_[0]; cand[1] -= st_[1]; cand[2] -= st_[2]
            shift = np.sqrt((cand[0] - x0) ** 2 + (cand[1] - y0) ** 2 + (cand[2] - z0) ** 2)
            okr = shift < 0.02
            if okr:
                for q in range(nnb):
                    j = newnb[q]
                    dx = _mi(pos[j, 0] - cand[0], Lx); dy = _mi(pos[j, 1] - cand[1], Ly); dz = pos[j, 2] - cand[2]
                    d2 = dx * dx + dy * dy + dz * dz
                    if d2 < r_ex * r_ex or d2 >= r_b * r_b:
                        okr = False; break
            if not okr:
                cand[0] = x0; cand[1] = y0; cand[2] = z0
            cand[0] = cand[0] % Lx; cand[1] = cand[1] % Ly
            if cand[0] >= Lx: cand[0] -= Lx
            if cand[1] >= Ly: cand[1] -= Ly
            gx = int(cand[0] / csx) % ncx; gy = int(cand[1] / csy) % ncy; gz = int(np.floor(cand[2] / csz)) + zoff
        if gcnt[gx, gy, gz] >= cap:
            err = 2; break
        attempts = 0
        m = n; n += 1
        pos[m, 0] = cand[0]; pos[m, 1] = cand[1]; pos[m, 2] = cand[2]
        op[m] = 2 if do_lift else 1
        if do_lift: n_ok_l += 1
        else: n_ok_s += 1
        grid[gx, gy, gz, gcnt[gx, gy, gz]] = m; gcnt[gx, gy, gz] += 1
        for q in range(nnb):
            j = newnb[q]
            if deg[m] >= KMAX or deg[j] >= KMAX:
                err = 3; break
            adj[m, deg[m]] = j; deg[m] += 1; adj[j, deg[j]] = m; deg[j] += 1
        if err: break
        for q1 in range(nnb):
            a = newnb[q1]
            for q2 in range(q1 + 1, nnb):
                b = newnb[q2]
                bonded = False
                for r in range(deg[a]):
                    if adj[a, r] == b: bonded = True; break
                if not bonded: continue
                if nt >= cap_t:
                    err = 4; break
                tri[nt, 0] = m; tri[nt, 1] = a; tri[nt, 2] = b
                if nS + 3 > capS:
                    S2 = np.zeros(2 * capS, np.int64); S2[:nS] = S[:nS]; S = S2; capS *= 2
                if nL + 2 > capL:
                    L2 = np.zeros(2 * capL, np.int64); L2[:nL] = Lq[:nL]; Lq = L2; capL *= 2
                ux = _mi(pos[a, 0] - pos[m, 0], Lx); uy = _mi(pos[a, 1] - pos[m, 1], Ly); uz = pos[a, 2] - pos[m, 2]
                vx = _mi(pos[b, 0] - pos[m, 0], Lx); vy = _mi(pos[b, 1] - pos[m, 1], Ly); vz = pos[b, 2] - pos[m, 2]
                nz_ = ux * vy - uy * vx
                if planar:
                    nx2 = uy * vz - uz * vy; ny2 = uz * vx - ux * vz
                    if abs(nz_) < 0.99 * np.sqrt(nx2 * nx2 + ny2 * ny2 + nz_ * nz_):
                        nt += 1          # tilted triangle: offers no growth sites in the planar variant
                        continue
                for k in range(3):
                    S[nS] = 3 * nt + k; nS += 1
                if lift_both:
                    Lq[nL] = 2 * nt; nL += 1; Lq[nL] = 2 * nt + 1; nL += 1
                elif nz_ > 1e-9:
                    Lq[nL] = 2 * nt; nL += 1
                elif nz_ < -1e-9:
                    Lq[nL] = 2 * nt + 1; nL += 1
                else:
                    Lq[nL] = 2 * nt; nL += 1; Lq[nL] = 2 * nt + 1; nL += 1
                nt += 1
            if err: break
        if err: break
    stats = np.array([n, nt, n_ok_s, n_ok_l, err, n0], np.int64)
    return pos[:n], op[:n], deg[:n], adj[:n], stats, Lx, Ly


def grow_slab(nx=48, ny=48, layers=100, delta=0.05, w_site=None, r_ex=0.95, r_b=1.05,
              seed=0, lift_dir="axis", refine=True, planar=False):
    """planar=True: growth sites only on triangles parallel to the substrate (sheet-by-sheet
    variant: stitch stays within a sheet, and a new sheet can start only from lifted nodes)."""
    """Grow `layers` layers' worth of nodes on a periodic nx-by-ny close-packed substrate."""
    assert ny % 2 == 0, "ny must be even for a rectangular periodic cell"
    if w_site is None:
        w_site = np.sqrt(2) / np.pi * delta
    n_add = layers * nx * ny
    Gz = int(layers * H_LIFT * 2.0 / max(r_b, 1.0)) + 16
    cap = 6
    while True:
        pos, op, deg, adj, st, Lx, Ly = _grow_slab(nx, ny, n_add, float(w_site), float(r_ex), float(r_b),
                                                   int(seed), Gz, cap, lift_dir == "both", bool(refine), bool(planar))
        if st[4] == 1: Gz = int(Gz * 1.5); continue
        if st[4] == 2: cap *= 2; continue
        break
    s = dict(zip(["n", "triangles", "stitch_ok", "lift_ok", "err", "n_substrate"], map(int, st)))
    s["lift_fraction"] = s["lift_ok"] / max(1, s["lift_ok"] + s["stitch_ok"])
    return dict(pos=pos, op=op, deg=deg, adj=adj, stats=s, box=(Lx, Ly))
