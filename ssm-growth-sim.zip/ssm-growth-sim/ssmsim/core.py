"""
SSM growth simulator (canonical implementation).

Model postulates
----------------
* Nodes are joined by Bell-pair bonds of unit length L = 1.
* Initial condition: three nodes joined by three Bell-pair bonds
  (equilateral triangle of side L).
* Growth proceeds only by two operators acting on existing triangles:
    STITCH  extend a triangle across one of its edges, in its own plane:
            new node at the equilateral apex, distance sqrt(3)/2 L from the
            edge midpoint, on the side opposite the triangle's third vertex.
    LIFT    place a node above OR below the triangle centroid at the
            tetrahedral height sqrt(2/3) L.  Each triangle offers two lift
            sites (both directions).
* Hard-shell exclusion: a candidate closer than r_ex to any node is rejected.
* Proximity bonding: a placed node bonds to every node within r_b.

Kinetics
--------
Every triangle contributes 3 stitch sites and 2 lift sites.  Because nodes
never move and exclusion is monotone, a blocked site stays blocked and a used
site is occupied, so each site is attempted exactly once and then retired.

mode = "site" (canonical):  each stitch site has weight 1 and each lift site
    weight w_site.  The geometric tolerance-volume argument gives, per
    direction, w_site = (sqrt(2)/pi) * delta  (both directions: 2*sqrt(2)/pi*delta).
mode = "step" (legacy, matches the published ssm_sim.py logic): at each step
    choose LIFT with fixed probability p, otherwise STITCH.

Node index equals creation time, so the state of the cluster at any earlier
time t is exactly the first t nodes and their mutual bonds.
"""
import numpy as np
from numba import njit

KMAX = 40          # adjacency capacity per node
H_STITCH = np.sqrt(3.0) / 2.0
H_LIFT = np.sqrt(2.0 / 3.0)


def lift_weight_from_delta(delta, exclusive=False):
    """Per-direction lift-site weight from the tolerance-volume ratio."""
    r = 2.0 * np.sqrt(2.0) / np.pi * delta          # both directions, per triangle vs per edge
    if exclusive:
        r = r / (1.0 - r)
    return r / 2.0


@njit(cache=True)
def _grow(N, mode, w_site, p_step, r_ex, r_b, seed, G, max_attempts, CELL_CAP, lift_dir, refine):
    np.random.seed(seed)
    cell = r_b if r_b > r_ex else r_ex
    if cell < 1.0:
        cell = 1.0
    off = G // 2
    pos = np.zeros((N, 3))
    op = np.zeros(N, np.int8)              # 0 seed, 1 stitch, 2 lift
    par = -np.ones((N, 3), np.int32)       # vertices of the triangle each node was built on
    deg = np.zeros(N, np.int32)
    adj = -np.ones((N, KMAX), np.int32)
    grid = -np.ones((G, G, G, CELL_CAP), np.int32)
    gcnt = np.zeros((G, G, G), np.int8)

    cap_t = 16 * N + 64
    tri = np.zeros((cap_t, 3), np.int32)
    nt = 0
    capS = 4 * N + 64
    capL = 4 * N + 64
    S = np.zeros(capS, np.int64); nS = 0
    Lq = np.zeros(capL, np.int64); nL = 0
    err = 0
    n = 0
    n_try_s = 0; n_try_l = 0; n_ok_s = 0; n_ok_l = 0

    cand = np.zeros(3)
    newnb = np.zeros(KMAX, np.int32)

    # ---- seed triangle (three Bell-pair bonds) ----
    seedpos = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.5, H_STITCH, 0.0]])
    for i in range(3):
        for d in range(3):
            pos[i, d] = seedpos[i, d]
        cx = int(np.floor(pos[i, 0] / cell)) + off
        cy = int(np.floor(pos[i, 1] / cell)) + off
        cz = int(np.floor(pos[i, 2] / cell)) + off
        grid[cx, cy, cz, gcnt[cx, cy, cz]] = i
        gcnt[cx, cy, cz] += 1
    for (a, b) in ((0, 1), (1, 2), (0, 2)):
        adj[a, deg[a]] = b; deg[a] += 1
        adj[b, deg[b]] = a; deg[b] += 1
    n = 3
    tri[0, 0] = 0; tri[0, 1] = 1; tri[0, 2] = 2; nt = 1
    for k in range(3):
        S[nS] = k; nS += 1
    if lift_dir == 0:
        for s in range(2):
            Lq[nL] = s; nL += 1
    else:
        Lq[nL] = 0; nL += 1          # seed normal (0,0,+1): keep the +z side only
    c0x = 0.5; c0y = H_STITCH / 3.0; c0z = 0.0

    attempts = 0
    while n < N and attempts < max_attempts:
        if nS == 0 and nL == 0:
            break
        attempts += 1
        # ---- choose operator ----
        if mode == 0:
            wS = float(nS); wL = w_site * nL
            do_lift = np.random.random() * (wS + wL) < wL
        else:
            do_lift = (np.random.random() < p_step and nL > 0) or nS == 0
        if do_lift:
            i = np.random.randint(nL); site = Lq[i]; nL -= 1; Lq[i] = Lq[nL]
            t = site // 2; sgn = 1.0 if site % 2 == 0 else -1.0
            a = tri[t, 0]; b = tri[t, 1]; c = tri[t, 2]
            ux = pos[b, 0] - pos[a, 0]; uy = pos[b, 1] - pos[a, 1]; uz = pos[b, 2] - pos[a, 2]
            vx = pos[c, 0] - pos[a, 0]; vy = pos[c, 1] - pos[a, 1]; vz = pos[c, 2] - pos[a, 2]
            nx_ = uy * vz - uz * vy; ny_ = uz * vx - ux * vz; nz_ = ux * vy - uy * vx
            nn = np.sqrt(nx_ * nx_ + ny_ * ny_ + nz_ * nz_)
            n_try_l += 1
            if nn < 1e-12:
                continue
            for d in range(3):
                cand[d] = (pos[a, d] + pos[b, d] + pos[c, d]) / 3.0
            cand[0] += sgn * H_LIFT * nx_ / nn
            cand[1] += sgn * H_LIFT * ny_ / nn
            cand[2] += sgn * H_LIFT * nz_ / nn
        else:
            i = np.random.randint(nS); site = S[i]; nS -= 1; S[i] = S[nS]
            t = site // 3; k = site % 3
            c = tri[t, k]; a = tri[t, (k + 1) % 3]; b = tri[t, (k + 2) % 3]
            n_try_s += 1
            mx = 0.5 * (pos[a, 0] + pos[b, 0]); my = 0.5 * (pos[a, 1] + pos[b, 1]); mz = 0.5 * (pos[a, 2] + pos[b, 2])
            ex = pos[b, 0] - pos[a, 0]; ey = pos[b, 1] - pos[a, 1]; ez = pos[b, 2] - pos[a, 2]
            el2 = ex * ex + ey * ey + ez * ez
            wx = mx - pos[c, 0]; wy = my - pos[c, 1]; wz = mz - pos[c, 2]
            pr = (wx * ex + wy * ey + wz * ez) / el2      # remove any along-edge component
            wx -= pr * ex; wy -= pr * ey; wz -= pr * ez
            wn = np.sqrt(wx * wx + wy * wy + wz * wz)
            if wn < 1e-12:
                continue
            cand[0] = mx + H_STITCH * wx / wn
            cand[1] = my + H_STITCH * wy / wn
            cand[2] = mz + H_STITCH * wz / wn

        # ---- exclusion + neighbour search ----
        cx = int(np.floor(cand[0] / cell)) + off
        cy = int(np.floor(cand[1] / cell)) + off
        cz = int(np.floor(cand[2] / cell)) + off
        if cx < 1 or cy < 1 or cz < 1 or cx > G - 2 or cy > G - 2 or cz > G - 2:
            err = 1
            break
        blocked = False
        nnb = 0
        for ddx in range(-1, 2):
            for ddy in range(-1, 2):
                for ddz in range(-1, 2):
                    gx = cx + ddx; gy = cy + ddy; gz = cz + ddz
                    for q in range(gcnt[gx, gy, gz]):
                        j = grid[gx, gy, gz, q]
                        dx = pos[j, 0] - cand[0]; dy = pos[j, 1] - cand[1]; dz = pos[j, 2] - cand[2]
                        d2 = dx * dx + dy * dy + dz * dz
                        if d2 < r_ex * r_ex:
                            blocked = True
                            break
                        if d2 < r_b * r_b:
                            if nnb < KMAX:
                                newnb[nnb] = j; nnb += 1
                    if blocked:
                        break
                if blocked:
                    break
            if blocked:
                break
        if blocked:
            continue
        if refine and nnb >= 3:
            # least-squares unit-bond refinement (Gauss-Newton), reverted if it breaks any constraint
            x0 = cand[0]; y0 = cand[1]; z0 = cand[2]
            for it in range(4):
                JTJ = np.zeros((3, 3)); JTr = np.zeros(3)
                for q in range(nnb):
                    j = newnb[q]
                    dx = cand[0] - pos[j, 0]; dy = cand[1] - pos[j, 1]; dz = cand[2] - pos[j, 2]
                    d = np.sqrt(dx * dx + dy * dy + dz * dz)
                    g0 = dx / d; g1 = dy / d; g2 = dz / d; rr = d - 1.0
                    JTJ[0, 0] += g0 * g0; JTJ[0, 1] += g0 * g1; JTJ[0, 2] += g0 * g2
                    JTJ[1, 1] += g1 * g1; JTJ[1, 2] += g1 * g2; JTJ[2, 2] += g2 * g2
                    JTr[0] += g0 * rr; JTr[1] += g1 * rr; JTr[2] += g2 * rr
                JTJ[1, 0] = JTJ[0, 1]; JTJ[2, 0] = JTJ[0, 2]; JTJ[2, 1] = JTJ[1, 2]
                if abs(np.linalg.det(JTJ)) < 1e-10:
                    break
                st_ = np.linalg.solve(JTJ, JTr)
                cand[0] -= st_[0]; cand[1] -= st_[1]; cand[2] -= st_[2]
            okr = (cand[0] - x0) ** 2 + (cand[1] - y0) ** 2 + (cand[2] - z0) ** 2 < 0.02 ** 2
            if okr:
                for q in range(nnb):
                    j = newnb[q]
                    dx = pos[j, 0] - cand[0]; dy = pos[j, 1] - cand[1]; dz = pos[j, 2] - cand[2]
                    d2 = dx * dx + dy * dy + dz * dz
                    if d2 < r_ex * r_ex or d2 >= r_b * r_b:
                        okr = False
                        break
            if not okr:
                cand[0] = x0; cand[1] = y0; cand[2] = z0
            cx = int(np.floor(cand[0] / cell)) + off
            cy = int(np.floor(cand[1] / cell)) + off
            cz = int(np.floor(cand[2] / cell)) + off
        if gcnt[cx, cy, cz] >= CELL_CAP:
            err = 2
            break

        # ---- accept ----
        attempts = 0
        m = n; n += 1
        for d in range(3):
            pos[m, d] = cand[d]
        op[m] = 2 if do_lift else 1
        par[m, 0] = a; par[m, 1] = b; par[m, 2] = c
        if do_lift:
            n_ok_l += 1
        else:
            n_ok_s += 1
        grid[cx, cy, cz, gcnt[cx, cy, cz]] = m
        gcnt[cx, cy, cz] += 1
        for q in range(nnb):
            j = newnb[q]
            if deg[m] >= KMAX or deg[j] >= KMAX:
                err = 3
                break
            adj[m, deg[m]] = j; deg[m] += 1
            adj[j, deg[j]] = m; deg[j] += 1
        if err:
            break
        # ---- new triangles (m, a, b) for bonded neighbour pairs ----
        for q1 in range(nnb):
            a = newnb[q1]
            for q2 in range(q1 + 1, nnb):
                b = newnb[q2]
                bonded = False
                for r in range(deg[a]):
                    if adj[a, r] == b:
                        bonded = True
                        break
                if not bonded:
                    continue
                if nt >= cap_t:
                    err = 4
                    break
                tri[nt, 0] = m; tri[nt, 1] = a; tri[nt, 2] = b
                if nS + 3 > capS:
                    S2 = np.zeros(2 * capS, np.int64); S2[:nS] = S[:nS]; S = S2; capS *= 2
                if nL + 2 > capL:
                    L2 = np.zeros(2 * capL, np.int64); L2[:nL] = Lq[:nL]; Lq = L2; capL *= 2
                for k in range(3):
                    S[nS] = 3 * nt + k; nS += 1
                if lift_dir == 0:
                    for s in range(2):
                        Lq[nL] = 2 * nt + s; nL += 1
                else:
                    ux = pos[a, 0] - pos[m, 0]; uy = pos[a, 1] - pos[m, 1]; uz = pos[a, 2] - pos[m, 2]
                    vx = pos[b, 0] - pos[m, 0]; vy = pos[b, 1] - pos[m, 1]; vz = pos[b, 2] - pos[m, 2]
                    nx_ = uy * vz - uz * vy; ny_ = uz * vx - ux * vz; nz_ = ux * vy - uy * vx
                    if lift_dir == 1:
                        dot = nz_
                    else:
                        gx_ = (pos[m, 0] + pos[a, 0] + pos[b, 0]) / 3.0 - c0x
                        gy_ = (pos[m, 1] + pos[a, 1] + pos[b, 1]) / 3.0 - c0y
                        gz_ = (pos[m, 2] + pos[a, 2] + pos[b, 2]) / 3.0 - c0z
                        dot = nx_ * gx_ + ny_ * gy_ + nz_ * gz_
                    if dot > 1e-9:
                        Lq[nL] = 2 * nt; nL += 1
                    elif dot < -1e-9:
                        Lq[nL] = 2 * nt + 1; nL += 1
                    else:                       # exactly tangent: allow both
                        Lq[nL] = 2 * nt; nL += 1
                        Lq[nL] = 2 * nt + 1; nL += 1
                nt += 1
            if err:
                break
        if err:
            break

    stats = np.array([n, nt, n_try_s, n_ok_s, n_try_l, n_ok_l, err, nS, nL], np.int64)
    return pos[:n], op[:n], deg[:n], adj[:n], stats, par[:n]


LIFT_DIRS = {"both": 0, "axis": 1, "radial": 2}


def grow(N, mode="site", w_site=None, delta=0.05, p_step=0.05, r_ex=0.95, r_b=1.05,
         seed=0, max_attempts=10_000_000, lift_dir="both", refine=True):
    """lift_dir: 'both'   lift above and below every triangle (growth from a centre)
                 'axis'   only the side whose normal has +z component (a patch with one
                          global lift orientation; planar-front idealisation)
                 'radial' only the side facing away from the seed (outward everywhere)"""
    """Grow a cluster.  Returns dict with positions, ops, degrees, adjacency, stats."""
    if w_site is None:
        w_site = lift_weight_from_delta(delta)
    rad = (3 * N / (4 * np.pi * 1.41)) ** (1 / 3) * 1.5 + 8
    G = int(2 * rad / max(r_b, r_ex, 1.0)) + 4
    cap = 6 if r_ex >= 0.8 else 40
    while True:
        pos, op, deg, adj, st, par = _grow(N, 0 if mode == "site" else 1, float(w_site), float(p_step),
                                      float(r_ex), float(r_b), int(seed), G, int(max_attempts), cap,
                                      LIFT_DIRS[lift_dir], bool(refine))
        if st[6] == 1:            # cluster left the grid: enlarge, rerun same seed (deterministic)
            G = int(G * 1.4); continue
        if st[6] == 2:            # grid cell overflow: raise capacity, rerun
            cap *= 2; continue
        break
    names = ["n", "triangles", "stitch_tries", "stitch_ok", "lift_tries", "lift_ok", "err",
             "open_stitch", "open_lift"]
    s = dict(zip(names, map(int, st)))
    s["lift_fraction"] = s["lift_ok"] / max(1, s["lift_ok"] + s["stitch_ok"])
    return dict(pos=pos, op=op, deg=deg, adj=adj, stats=s, parent=par)
