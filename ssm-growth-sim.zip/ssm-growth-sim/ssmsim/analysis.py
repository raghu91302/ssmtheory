"""Structure analysis: common neighbour analysis (CNA), bulk mask, summaries."""
import numpy as np
from numba import njit
from scipy.spatial import cKDTree

RC_CNA = (1.0 + np.sqrt(2.0)) / 2.0     # between first (L) and second (sqrt2 L) shells
LABELS = np.array(["other", "fcc", "hcp", "ico"])


def neighbor_csr(pos, rc):
    t = cKDTree(pos)
    pairs = t.query_pairs(rc, output_type="ndarray")
    n = len(pos)
    i = np.concatenate([pairs[:, 0], pairs[:, 1]])
    j = np.concatenate([pairs[:, 1], pairs[:, 0]])
    order = np.lexsort((j, i))
    i, j = i[order], j[order]
    ptr = np.zeros(n + 1, np.int64)
    np.add.at(ptr, i + 1, 1)
    return np.cumsum(ptr), j.astype(np.int64)


@njit(cache=True)
def _is_nb(ptr, idx, a, b):
    lo = ptr[a]; hi = ptr[a + 1]
    while lo < hi:                      # sorted neighbour lists -> binary search
        mid = (lo + hi) // 2
        if idx[mid] < b:
            lo = mid + 1
        else:
            hi = mid
    return lo < ptr[a + 1] and idx[lo] == b


@njit(cache=True)
def _cna(ptr, idx):
    n = len(ptr) - 1
    out = np.zeros(n, np.int8)
    com = np.zeros(16, np.int64)
    par = np.zeros(16, np.int64)
    ecount = np.zeros(16, np.int64)
    for i in range(n):
        if ptr[i + 1] - ptr[i] != 12:
            continue
        n421 = 0; n422 = 0; n555 = 0
        for p in range(ptr[i], ptr[i + 1]):
            j = idx[p]
            nc = 0
            for q in range(ptr[i], ptr[i + 1]):
                k = idx[q]
                if k != j and _is_nb(ptr, idx, j, k):
                    if nc < 16:
                        com[nc] = k
                    nc += 1
            if nc > 16:
                continue
            for u in range(nc):
                par[u] = u; ecount[u] = 0
            nb = 0
            for u in range(nc):
                for v in range(u + 1, nc):
                    if _is_nb(ptr, idx, com[u], com[v]):
                        nb += 1
                        ru = u
                        while par[ru] != ru:
                            ru = par[ru]
                        rv = v
                        while par[rv] != rv:
                            rv = par[rv]
                        if ru != rv:
                            par[rv] = ru
                            ecount[ru] += ecount[rv] + 1
                        else:
                            ecount[ru] += 1
            lc = 0
            for u in range(nc):
                if par[u] == u and ecount[u] > lc:
                    lc = ecount[u]
            if nc == 4 and nb == 2 and lc == 1:
                n421 += 1
            elif nc == 4 and nb == 2 and lc == 2:
                n422 += 1
            elif nc == 5 and nb == 5 and lc == 5:
                n555 += 1
        if n421 == 12:
            out[i] = 1
        elif n421 == 6 and n422 == 6:
            out[i] = 2
        elif n555 == 12:
            out[i] = 3
    return out


def cna(pos, rc=RC_CNA):
    """Per-node structure code: 0 other, 1 fcc, 2 hcp, 3 icosahedral."""
    ptr, idx = neighbor_csr(pos, rc)
    return _cna(ptr, idx)


def bulk_mask(pos, r=2.0, threshold=42):
    """Bulk-interior: all three FCC shells populated (>= 42 nodes within 2L)."""
    t = cKDTree(pos)
    cnt = t.query_ball_point(pos, r, return_length=True) - 1
    return cnt >= threshold


def depth_from_surface(pos, r=2.0, threshold=42, max_depth=50):
    """Graph-free depth: number of 1.2L hops from the nearest non-bulk node."""
    surf = ~bulk_mask(pos, r, threshold)
    t = cKDTree(pos)
    depth = np.full(len(pos), -1, np.int64)
    depth[surf] = 0
    frontier = np.where(surf)[0]
    d = 0
    while len(frontier) and d < max_depth:
        d += 1
        nb = t.query_ball_point(pos[frontier], 1.2)
        cand = np.unique(np.concatenate([np.asarray(x, np.int64) for x in nb])) if len(nb) else np.array([], np.int64)
        cand = cand[depth[cand] < 0]
        depth[cand] = d
        frontier = cand
    depth[depth < 0] = d + 1
    return depth


def summarize(pos, deg=None, codes=None, mask=None):
    if codes is None:
        codes = cna(pos)
    if mask is None:
        mask = bulk_mask(pos)
    m = mask.sum()
    res = {"n": len(pos), "n_bulk": int(m)}
    for c, name in enumerate(LABELS):
        res[f"bulk_{name}"] = float((codes[mask] == c).mean()) if m else np.nan
        res[f"all_{name}"] = float((codes == c).mean())
    if deg is not None:
        res["bulk_k12"] = float((deg[mask] == 12).mean()) if m else np.nan
        res["all_k12"] = float((deg == 12).mean())
        res["mean_k"] = float(deg.mean())
    return res


@njit(cache=True)
def _tets_per_node(adj, deg, t):
    """Number of 4-cliques (bonded tetrahedra) touching each node among the first t nodes."""
    cnt = np.zeros(t, np.int64)
    for a in range(t):
        for p in range(deg[a]):
            b = adj[a, p]
            if b <= a or b >= t: continue
            for q in range(deg[a]):
                c = adj[a, q]
                if c <= b or c >= t: continue
                bc = False
                for r in range(deg[b]):
                    if adj[b, r] == c: bc = True; break
                if not bc: continue
                for s in range(deg[a]):
                    d = adj[a, s]
                    if d <= c or d >= t: continue
                    ok1 = False
                    for r in range(deg[b]):
                        if adj[b, r] == d: ok1 = True; break
                    if not ok1: continue
                    ok2 = False
                    for r in range(deg[c]):
                        if adj[c, r] == d: ok2 = True; break
                    if ok2:
                        cnt[a] += 1; cnt[b] += 1; cnt[c] += 1; cnt[d] += 1
    return cnt


def prefix_degrees(adj, deg, t):
    """Degrees within the first t nodes (state of the cluster at time t)."""
    a = adj[:t]
    valid = (a >= 0) & (a < t)
    return valid.sum(1)


def tets_per_node(adj, deg, t=None):
    t = len(deg) if t is None else t
    return _tets_per_node(adj, deg, t)
