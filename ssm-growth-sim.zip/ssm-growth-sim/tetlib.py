import sys; sys.path.insert(0,'.')
import numpy as np
from numba import njit
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import H
@njit(cache=True)
def per_pair(adj, deg, z, H, kmax):
    up=np.zeros(kmax+2,np.int64); dn=np.zeros(kmax+2,np.int64); zl=np.zeros(4)
    n=len(deg)
    for a in range(n):
        for p in range(deg[a]):
            b=adj[a,p]
            if b<=a: continue
            for q in range(deg[a]):
                c=adj[a,q]
                if c<=b: continue
                ok=False
                for r in range(deg[b]):
                    if adj[b,r]==c: ok=True; break
                if not ok: continue
                for s in range(deg[a]):
                    d=adj[a,s]
                    if d<=c: continue
                    o1=False
                    for r in range(deg[b]):
                        if adj[b,r]==d: o1=True; break
                    if not o1: continue
                    o2=False
                    for r in range(deg[c]):
                        if adj[c,r]==d: o2=True; break
                    if not o2: continue
                    zl[0]=z[a];zl[1]=z[b];zl[2]=z[c];zl[3]=z[d]; zs=np.sort(zl)
                    lo=int(np.rint(zs[0]/H))
                    if lo<0 or lo>kmax: continue
                    if zs[2]-zs[0]<0.1*H and abs(zs[3]-zs[2]-H)<0.1*H: up[lo]+=1      # pair (lo, lo+1), base below
                    elif zs[3]-zs[1]<0.1*H and abs(zs[1]-zs[0]-H)<0.1*H: dn[lo]+=1    # pair (lo, lo+1), base above
    return up, dn
