import sys, json, time; sys.path.insert(0,'.')
import numpy as np
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import registry, H, cna_periodic, height_profile
def analyse(r):
    P=r['pos']; op=r['op']; n0=r['stats']['n_substrate']; adj,deg=r['adj'],r['deg']
    z=P[:,2]; k=np.rint(z/H).astype(int); on=np.abs(z/H-k)<0.05; reg,_=registry(P)
    codes=cna_periodic(P,r['box'])
    top=max(L for L in range(k.max()+1) if (on&(k==L)).sum()>=0.85*n0)
    first_lift=[]; nuclei=[]; fill=[]
    for L in range(1,top-1):
        idx=np.where(on&(k==L))[0]; S=set(idx.tolist()); isl=set(idx[op[idx]==2].tolist())
        first_lift.append(op[idx.min()]==2); fill.append(len(idx)/n0)
        # nuclei: in-layer triangles made only of lifted nodes
        cnt=0
        for i in isl:
            nb=[j for j in adj[i,:deg[i]] if j in isl and j>i]
            for a in range(len(nb)):
                for b in range(a+1,len(nb)):
                    if nb[b] in set(adj[nb[a],:deg[nb[a]]]): cnt+=1
        nuclei.append(cnt)
    sel=on&(k>=2)&(k<=top-2)
    prof=height_profile(r,codes=codes)
    imb=[abs(b['abc']-b['acb'])/(b['abc']+b['acb']) for b in prof[:-2] if b['abc'] is not None]
    return dict(top=int(top), first_lift=float(np.mean(first_lift)), nuclei_per_layer=float(np.mean(nuclei)),
                layer_fill=float(np.mean(fill)), fcc=float((codes[sel]==1).mean()), hcp=float((codes[sel]==2).mean()),
                on_lattice=float(on[k<=top].mean()), imb_first=imb[0], imb_last=imb[-1], imb=imb,
                lift_fraction=r['stats']['lift_fraction'])
out=open('results/planar.jsonl','a')
for n,layers in [(32,150),(64,100)]:
    for planar in [False,True]:
        for s in range(4):
            t=time.time(); r=grow_slab(n,n,layers,seed=300+s,lift_dir='axis',planar=planar); a=analyse(r)
            out.write(json.dumps(dict(n=n,planar=planar,seed=s,**a))+"\n"); out.flush()
            print(n,'planar' if planar else 'standard',s,{k:(round(v,3) if isinstance(v,float) else v) for k,v in a.items() if k!='imb'},f'{time.time()-t:.0f}s',flush=True)
