"""Exact code parameters (n, rank H_Z, rank H_X, k) of the FCC stabilizer code on a grown patch,
compared with a perfect ABC patch of the same size.

The grown patch is cut flat between two layer heights, well below its rough top, and compared with a
perfect ABC patch with the same number of layers: periodic in x and y, open at the bottom and the top.

usage: python quantum_gf2.py nx seed [w_site [layers]]
"""
import sys, os, json, time
import numpy as np
from numba import njit
from scipy.spatial import cKDTree
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmsim.slab import grow_slab
from quantum_lattice import _octahedra

H = np.sqrt(2 / 3)


def graph(P, box):
    Lx, Ly = box
    Q = P.copy(); Q[:, 0] %= Lx; Q[:, 1] %= Ly; Q[:, 2] -= Q[:, 2].min()
    t = cKDTree(Q, boxsize=[Lx, Ly, Q[:, 2].max() * 3 + 10])
    E = np.array(sorted(t.query_pairs(1.05)), np.int64)
    n = len(P); deg = np.bincount(E.ravel(), minlength=n)
    adj = -np.ones((n, 16), np.int64); fill = np.zeros(n, np.int64)
    for a, b in E:
        adj[a, fill[a]] = b; fill[a] += 1; adj[b, fill[b]] = a; fill[b] += 1
    return E, adj, deg.astype(np.int64)


@njit(cache=True)
def gf2_rank(M):
    """Rank over GF(2) of a bit-packed matrix (rows x words, uint64); destroys M."""
    r, w = M.shape
    rank = 0
    for col in range(w * 64):
        wd = col // 64; bit = np.uint64(1) << np.uint64(col % 64)
        piv = -1
        for i in range(rank, r):
            if M[i, wd] & bit:
                piv = i; break
        if piv < 0:
            continue
        if piv != rank:
            for k in range(w):
                t = M[piv, k]; M[piv, k] = M[rank, k]; M[rank, k] = t
        for i in range(r):
            if i != rank and (M[i, wd] & bit):
                for k in range(wd, w):
                    M[i, k] ^= M[rank, k]
        rank += 1
        if rank == r:
            break
    return rank


def packed(rows, ncols):
    w = (ncols + 63) // 64
    M = np.zeros((len(rows), w), np.uint64)
    for i, cols in enumerate(rows):
        for c in cols:
            M[i, c // 64] |= np.uint64(1) << np.uint64(c % 64)
    return M


def code_params(P, box):
    E, adj, deg = graph(P, box)
    eid = {(int(a), int(b)): k for k, (a, b) in enumerate(E)}
    n = len(E)
    Z = [[] for _ in range(len(P))]
    for k, (a, b) in enumerate(E):
        Z[a].append(k); Z[b].append(k)
    oc = np.unique(_octahedra(P, adj, deg, float(box[0]), float(box[1])), axis=0)
    X = [[eid[(min(a, b), max(a, b))] for ii, a in enumerate(o) for b in o[ii + 1:]
          if (min(a, b), max(a, b)) in eid] for o in oc]
    assert all(len(x) == 12 for x in X)
    # CSS validity
    MZ = packed(Z, n); MX = packed(X, n)
    odd = 0
    for x in X:
        v = np.bincount(E[x].ravel(), minlength=len(P))
        odd += int((v % 2).sum())
    rz = gf2_rank(MZ.copy()); rx = gf2_rank(MX.copy())
    return dict(nodes=len(P), n=n, z_checks=len(Z), x_checks=len(X), rank_z=int(rz), rank_x=int(rx),
                k=int(n - rz - rx), rate=float((n - rz - rx) / n), css_odd=odd)


def ideal_slab(nx, layers):
    s3 = np.sqrt(3) / 2
    off = [(0, 0), (0.5, s3 / 3), (1.0, 2 * s3 / 3)]
    P = []
    for L in range(layers):
        ox, oy = off[L % 3]
        for j in range(nx):
            for i in range(nx):
                P.append(((i + 0.5 * j + ox) % nx, j * s3 + oy, L * H))
    return np.array(P), (float(nx), nx * s3)


if __name__ == "__main__":
    nx, seed = int(sys.argv[1]), int(sys.argv[2])
    w = float(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3] != '-' else None
    g = grow_slab(nx=nx, ny=nx, layers=nx + 6, seed=seed, **({} if w is None else dict(w_site=w)))
    P = g["pos"]; z = P[:, 2] - P[:, 2].min()
    nfull = int(sys.argv[4]) if len(sys.argv) > 4 else (3 * nx) // 4   # layers kept, substrate included
    keep = z < (nfull - 0.5) * H
    G = P[keep]
    res = dict(nx=nx, seed=seed, w_site=w if w is not None else 0.0225, layers=int(nfull),
               lift_fraction=g["stats"]["lift_fraction"])
    t = time.time()
    res["grown"] = code_params(G, g["box"])
    Pi, bi = ideal_slab(nx, nfull)
    res["ideal"] = code_params(Pi, bi)
    res["t"] = time.time() - t
    os.makedirs("results", exist_ok=True)
    json.dump(res, open(f"results/quantum_gf2_{nx}_{seed}_{res['w_site']:.4f}.json", "w"), indent=1)
    print(json.dumps(res))
