"""Look one by one at the remnant sites classified 'one below, two above' (Reviewer 2, round 2).
Reruns the production remnant experiment (same seeds) and, for each such site, lists the distances and
heights of nearby nodes, so the site can be compared with an ideal tetrahedral void.
Writes results/remnant_irregular.json."""
import sys, os, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scipy.spatial import cKDTree
from ssmsim.slab import grow_slab
from ssmsim import remnant as rm
R = rm.R
out = []
for mode in ("axis", "both"):
    for s in range(4):
        r = grow_slab(32, 32, 150, seed=200 + s, lift_dir=mode)
        pos = r["pos"]; Lx, Ly = r["box"]; n0 = r["stats"]["n_substrate"]
        P = pos.copy(); P[:, 0] %= Lx; P[:, 1] %= Ly
        P[:, 0] = np.minimum(P[:, 0], np.nextafter(Lx, 0)); P[:, 1] = np.minimum(P[:, 1], np.nextafter(Ly, 0))
        tree = cKDTree(P, boxsize=[Lx, Ly, P[:, 2].max() + 50])
        rng = np.random.default_rng(s); N = len(P); t_lo = n0 * 5; t_hi = N - n0 * 15
        for _ in range(300):
            t = int(rng.integers(t_lo, t_hi)); xy = rng.uniform([0, 0], [Lx, Ly])
            c, it = rm.settle(xy, t, P, tree, (Lx, Ly), 0.0, rng)
            cls, nc = rm.classify(c, t, P, tree, (Lx, Ly))
            if cls.startswith("other") and nc == 3:
                idx = np.array(tree.query_ball_point(c, 1.0)); d = rm._mi(P[idx] - c[None, :], (Lx, Ly))
                n = np.linalg.norm(d, axis=1); o = np.argsort(n)
                nb = [dict(dist=float(n[k]), dz=float(d[k, 2]), placed_before=bool(idx[k] < t)) for k in o[:8]]
                out.append(dict(mode=mode, seed=s, t=t, cls=cls, z=float(c[2]), neighbors=nb))
                print(mode, s, cls, [(round(x["dist"], 3), round(x["dz"], 3), x["placed_before"]) for x in nb[:6]], flush=True)
json.dump(out, open("results/remnant_irregular.json", "w"), indent=1)
