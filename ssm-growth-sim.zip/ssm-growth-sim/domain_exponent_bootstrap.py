"""Uncertainty of the domain-growth exponent (Reviewer 2, round 2).
For each slab width (16 runs each), the height h_1/2 where the mean twin imbalance first reaches 0.5
(bins with on-lattice fraction < 0.9 left out), a power-law fit h_1/2 ~ W^a, and a bootstrap over runs.
Domains widen as height^(1/a). Writes results/domain_exponent.json."""
import json, collections, numpy as np
runs = [json.loads(l) for l in open("results/slab2.jsonl")]
byw = collections.defaultdict(list)
for r in runs: byw[r["key"]["nx"]].append(r)
def hhalf(rs):
    H = max(len(r["profile"]) for r in rs); c = []
    for b in range(H):
        v = [abs(r["profile"][b]["abc"] - r["profile"][b]["acb"]) / max(1e-9, r["profile"][b]["abc"] + r["profile"][b]["acb"])
             for r in rs if b < len(r["profile"]) and r["profile"][b]["on_lattice"] >= 0.9]
        c.append(np.mean(v) if v else np.nan)
    lo = [p["lo"] for p in max(rs, key=lambda r: len(r["profile"]))["profile"]]
    for i in range(1, len(c)):
        if c[i] >= 0.5 and c[i - 1] < 0.5:
            return lo[i - 1] + (0.5 - c[i - 1]) / (c[i] - c[i - 1]) * (lo[i] - lo[i - 1]) + 5
    return np.nan
W = sorted(byw); h = [hhalf(byw[w]) for w in W]
a = float(np.polyfit(np.log(W), np.log(h), 1)[0])
rng = np.random.default_rng(0); sl = []
for _ in range(2000):
    hb = [hhalf([byw[w][i] for i in rng.integers(0, len(byw[w]), len(byw[w]))]) for w in W]
    if np.all(np.isfinite(hb)): sl.append(np.polyfit(np.log(W), np.log(hb), 1)[0])
sl = np.array(sl); e = 1 / sl
out = dict(widths=W, h_half=h, a=a, domain_exponent=1 / a, pair_32_48=float(np.log(h[1] / h[0]) / np.log(48 / 32)),
           pair_48_64=float(np.log(h[2] / h[1]) / np.log(64 / 48)),
           exponent_68=np.percentile(e, [16, 84]).tolist(), exponent_95=np.percentile(e, [2.5, 97.5]).tolist(), n_boot=len(sl))
print(out); json.dump(out, open("results/domain_exponent.json", "w"), indent=1)
