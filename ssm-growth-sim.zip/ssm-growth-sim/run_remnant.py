import sys, json, time; sys.path.insert(0,'.')
import numpy as np, collections
from ssmsim.slab import grow_slab
from ssmsim.remnant import trap_experiment
out=open('results/remnant.jsonl','a')
for mode in ['axis','both']:
    for s in range(4):
        t=time.time(); r=grow_slab(32,32,150,seed=200+s,lift_dir=mode)
        rec=trap_experiment(r,n_remnants=300,seed=s)
        c=collections.Counter(x['cls'] for x in rec); cc=collections.Counter(x['contacts'] for x in rec)
        out.write(json.dumps(dict(mode=mode,seed=s,counts=c,contacts=cc,recs=rec))+"\n"); out.flush()
        print(mode,s,dict(c),'contacts at rest:',dict(cc),f'{time.time()-t:.0f}s',flush=True)
