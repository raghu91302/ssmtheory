"""Random placement within the acceptance region (Reviewer 2, round 2).
Each new node is placed at a random point near its close-packed site: uniform in a cube of half-width eps
around the site, kept only if its distances to the anchor nodes (the two edge ends for stitch, the three
corners for lift) lie within L(1 +/- eps). eps = delta = 0.05 is random placement over the acceptance region
near the site; smaller eps tests how precise placement must be. jmode 2 places stitch nodes at a random angle
on the full ring of unit distance from both edge ends. Three variants: bare rule; unit-bond condition at its
default settings (cap 0.02 L, 4 steps); and a stronger relaxation (cap 0.1 L, 8 steps).
Metrics use a geometric core (nodes within half the cluster radius of the centroid), because the 42-neighbor
bulk test is not robust to position noise. N = 5e4, seeds 0 and 1. Writes results/random_placement.json."""
import sys, os, json, time
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmsim.core import grow
from ssmsim.analysis import cna
VARIANTS = {"bare": dict(refine=False), "unit-bond": dict(refine=True), "relaxed": dict(refine=True, rcap=0.1, rsteps=8)}
CASES = [(0, 0.0)] + [(1, e) for e in (0.001, 0.005, 0.01, 0.02, 0.05)] + [(2, 0.05)]
out = []
for jmode, eps in CASES:
    for vname, v in VARIANTS.items():
        for seed in (0, 1):
            t = time.time(); g = grow(50000, seed=seed, jmode=jmode, jamp=max(eps, 1e-9), **v)
            P = g["pos"]; deg = g["deg"]; c = cna(P)
            r = np.linalg.norm(P - P.mean(0), axis=1); core = r < 0.5 * r.max()
            out.append(dict(jmode=jmode, eps=eps, variant=vname, seed=seed, lift_fraction=g["stats"]["lift_fraction"],
                            core_nodes=int(core.sum()), core_fcc=float((c[core] == 1).mean()),
                            core_hcp=float((c[core] == 2).mean()), core_mean_degree=float(deg[core].mean()),
                            radius=float(r.max()), t=time.time() - t))
            print(json.dumps(out[-1]), flush=True)
json.dump(out, open("results/random_placement.json", "w"), indent=1)
