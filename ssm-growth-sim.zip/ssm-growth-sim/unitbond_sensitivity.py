"""Reviewer check: sensitivity of the results to the unit-bond condition's settings
(move cap rcap, default 0.02 L; Gauss-Newton steps rsteps, default 4). N = 1e5 clusters, 2 seeds."""
import sys, os, json, time
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmsim.core import grow
from ssmsim.analysis import cna, bulk_mask, depth_from_surface
from quantum_lattice import edge_list
configs = [dict(rcap=0.02, rsteps=4), dict(rcap=0.01, rsteps=4), dict(rcap=0.04, rsteps=4),
           dict(rcap=0.02, rsteps=2), dict(rcap=0.02, rsteps=8), dict(refine=False)]
out = []
for cfg in configs:
    for seed in (0, 1):
        t = time.time(); g = grow(100000, seed=seed, **cfg)
        P = g["pos"]; c = cna(P); m = bulk_mask(P); d = depth_from_surface(P)
        E = edge_list(g["adj"], g["deg"]); L = np.linalg.norm(P[E[:, 0]] - P[E[:, 1]], axis=1)
        r = dict(cfg=cfg, seed=seed, lift_fraction=g["stats"]["lift_fraction"],
                 interior_fcc=float((c[d >= 4] == 1).mean()), bulk_fcc=float((c[m] == 1).mean()),
                 bulk_hcp=float((c[m] == 2).mean()), bond_err_median=float(np.median(np.abs(L - 1))),
                 bond_err_max=float(np.max(np.abs(L - 1))), t=time.time() - t)
        out.append(r); print(json.dumps(r), flush=True)
json.dump(out, open("results/unitbond_sensitivity.json", "w"), indent=1)
