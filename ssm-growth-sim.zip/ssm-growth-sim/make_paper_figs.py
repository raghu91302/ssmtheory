import sys, json, collections; sys.path.insert(0,'.')
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
plt.rcParams.update({"font.family":"serif","mathtext.fontset":"cm","font.size":9,"axes.labelsize":9,
    "axes.titlesize":9,"legend.fontsize":7.5,"xtick.labelsize":8,"ytick.labelsize":8,"figure.dpi":200,
    "axes.spines.top":False,"axes.spines.right":False,"savefig.bbox":"tight"})
CF,CH,CO,CI="#3b6ea5","#c0392b","#e0a526","#7b3fa0"     # fcc, hcp, other, ico
CA,CB,CT="#2f7fc1","#e8743b","#333333"                  # ABC, ACB, tilted
D=np.load('figures/figdata.npz'); OUT='figures/'
L=lambda n:[json.loads(l) for l in open(f"results/{n}.jsonl")]
def grp(rows,key):
    g=collections.OrderedDict()
    for r in sorted(rows,key=lambda r:r['key'][key]): g.setdefault(r['key'][key],[]).append(r)
    return g
def ms(rs,f):
    v=np.array([r[f] for r in rs],float); return v.mean(), (v.std(ddof=1)/np.sqrt(len(v)) if len(v)>1 else 0)
def tag(ax,s,x=-0.14,y=1.04): ax.text(x,y,s,transform=ax.transAxes,fontweight="bold",fontsize=10,va="bottom")
def save(fig,name): fig.savefig(OUT+name+".pdf"); fig.savefig(OUT+name+".png",dpi=220); plt.close(fig)

# ---------------- Figure 1: operators and lift rate ----------------
fig=plt.figure(figsize=(7.0,2.7)); gsp=fig.add_gridspec(1,3,width_ratios=[0.8,0.8,1.5],wspace=0.5)
A=np.array([0,0.]);B=np.array([1,0.]);C=np.array([.5,np.sqrt(3)/2]); S=np.array([.5,-np.sqrt(3)/2]); h=np.sqrt(2/3)
ax=fig.add_subplot(gsp[0])
ax.fill(*np.array([A,B,C]).T,fc="#cfd8e3",ec="k",lw=1)
ax.fill(*np.array([A,B,S]).T,fc="#e8f0d8",ec="#5a8a2f",lw=.9,ls="--")
for p in (A,B,C): ax.plot(*p,"o",c="k",ms=6)
ax.plot(*S,"o",c="#5a8a2f",ms=7); ax.text(S[0],S[1]-.22,"stitch",color="#5a8a2f",ha="center")
ax.annotate("",xy=S,xytext=(.5,0),arrowprops=dict(arrowstyle="->",color="#5a8a2f",lw=.8))
ax.text(.5,1.12,"top view",ha="center",fontsize=8); ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-.25,1.25); ax.set_ylim(-1.25,1.2)
ax.text(-.3,1.2,"a",fontweight="bold",fontsize=10)
ax=fig.add_subplot(gsp[1])
g=np.array([.5,0.]); base=[np.array([0,0.]),np.array([1,0.])]
ax.plot([0,1],[0,0],c="k",lw=2.5); ax.plot([0,.5,1],[0,0,0],"o",c="k",ms=6)
for sgn,col,lab in ((1,CH,"lift (+)"),(-1,CB,"lift (−)")):
    T=np.array([.5,sgn*h])
    for p in ([0,0],[1,0],[.5,0]): ax.plot([p[0],T[0]],[p[1],T[1]],c=col,ls="--",lw=.9)
    ax.plot(*T,"o",c=col,ms=7); ax.text(.62,T[1],lab,color=col,va="center")
ax.annotate("",xy=(-.12,h),xytext=(-.12,0),arrowprops=dict(arrowstyle="<->",lw=.7))
ax.text(-.15,h/2,r"$\sqrt{2/3}\,L$",ha="right",va="center",fontsize=7.5)
ax.text(.5,1.12,"side view",ha="center",fontsize=8); ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-.55,1.25); ax.set_ylim(-1.25,1.2)
ax=fig.add_subplot(gsp[2])
d=np.linspace(0,0.11,200); r=2*np.sqrt(2)/np.pi*d
ax.axvspan(0.018,0.052,color="#dfe7f1",zorder=0,label="Regge-closure range of δ")
ax.plot(d,r,c="k",lw=1.2,label=r"$(2\sqrt{2}/\pi)\,\delta$")
ax.plot(d,r/(1-r),c="k",lw=.8,ls=":",label="exclusive form $r/(1-r)$")
ax.errorbar(D['mc_d'],D['mc_r'],D['mc_e'],fmt="o",ms=4,c=CH,capsize=2,label="Monte Carlo")
ax.axhline(np.exp(-3),c="gray",lw=.7,ls="--"); ax.text(0.068,np.exp(-3)-.007,r"$e^{-3}$ (earlier value)",color="gray",fontsize=7)
ax.set_xlabel(r"bond tolerance $\delta$"); ax.set_ylabel(r"$P_{\rm lift}/P_{\rm stitch}$ (both directions)")
ax.set_xlim(0,0.105); ax.set_ylim(0,0.1); ax.legend(loc="upper left",frameon=False); tag(ax,"b",-0.2)
save(fig,"fig1_model")

# ---------------- Figure 2: cluster structure ----------------
fig,axs=plt.subplots(1,3,figsize=(7.2,2.5),gridspec_kw=dict(width_ratios=[1.05,1,1]))
ax=axs[0]; yz=D['cl_yz']; code=D['cl_code']
cols=np.array([CO,CF,CH,CI])[code]
for k,lab in ((1,"fcc"),(0,"other"),(2,"hcp")):
    m=code==k; ax.scatter(yz[m,0],yz[m,1],s=1.6,c=np.array([CO,CF,CH,CI])[k],lw=0,label=lab,rasterized=True)
ax.set_aspect("equal"); ax.set_xlabel(r"$y$ ($L$)"); ax.set_ylabel(r"$z$ ($L$)")
ax.legend(markerscale=6,loc="lower center",bbox_to_anchor=(0.5,1.0),ncol=3,frameon=False,handletextpad=.1,columnspacing=.8); tag(ax,"a",-0.32,1.0)
big=[r for r in L("size") if r['key']['N']==10**6]
dd=np.arange(12); f=[np.mean([r['depth_profile'][str(k)][1] for r in big]) for k in dd]; hh=[np.mean([r['depth_profile'][str(k)][2] for r in big]) for k in dd]
ax=axs[1]; ax.plot(dd,f,"o-",c=CF,ms=3.5,label="fcc"); ax.plot(dd,np.array(hh)*100,"s-",c=CH,ms=3,label="hcp × 100")
ax.set_xlabel("depth below surface (hops)"); ax.set_ylabel("fraction"); ax.set_ylim(0,1.03); ax.legend(frameon=False,loc="center right"); tag(ax,"b")
ax=axs[2]; gs=grp(L("size"),"N"); N=np.array(list(gs))
for fld,lab,mk,col in (("bulk_fcc","bulk","o",CF),("all_fcc","all nodes","s",CO)):
    y=np.array([ms(gs[n],fld) for n in N]); ax.errorbar(N,y[:,0],y[:,1],fmt=mk+"-",ms=3.5,c=col,capsize=2,label=lab)
y=1-np.array([ms(gs[n],"all_fcc")[0] for n in N]); p=np.polyfit(np.log(N),np.log(y),1)
ax.plot(N,1-np.exp(np.polyval(p,np.log(N))),"k:",lw=1,label=rf"fit $N^{{{p[0]:.2f}}}$")
ax.set_xscale("log"); ax.set_xlabel(r"$N$"); ax.set_ylabel("FCC fraction"); ax.legend(frameon=False,loc="lower right",bbox_to_anchor=(1.02,0.0)); tag(ax,"c")
fig.subplots_adjust(wspace=0.38); save(fig,"fig2_cluster")

# ---------------- Figure 3: lift-rate insensitivity and growth history ----------------
fig,axs=plt.subplots(1,2,figsize=(7.0,2.6))
ax=axs[0]
for name,lab,mk,col,key in (("lift","site rule, both","o",CF,"w_site"),("lift_axis","site rule, one orientation","D","#1b9e77","w_site"),("step","legacy per-step rule","^",CO,"p_step")):
    g=grp(L(name),key); x=[ms(g[w],"lift_fraction")[0] for w in g]; y=np.array([ms(g[w],"bulk_fcc") for w in g])
    ax.errorbar(x,y[:,0],y[:,1],fmt=mk+"-",ms=3.2,c=col,capsize=1.5,lw=1,label=lab)
gl=grp(L("lift"),"w_site"); x=[ms(gl[w],"lift_fraction")[0] for w in gl]; yh=[ms(gl[w],"bulk_hcp")[0]*10 for w in gl]
ax.plot(x,yh,"s--",ms=3,c=CH,lw=.9,label="hcp × 10 (site rule, both)")
lo=ms(gl[0.0113],"lift_fraction")[0]*0.8; hi=ms(gl[0.0225],"lift_fraction")[0]
ax.axvspan(0.0027,0.0066,color="#dfe7f1",zorder=0); ax.text(0.0042,1.04,"geometric range",ha="center",fontsize=7,color="#3b6ea5",clip_on=False)
ax.set_xscale("log"); ax.set_xlabel("realized lift fraction of placements"); ax.set_ylabel("bulk fraction"); ax.set_ylim(0,1.02)
ax.legend(frameon=False,loc="center left",bbox_to_anchor=(0.0,0.45),fontsize=7); tag(ax,"a")
ax=axs[1]; T=[100,300,1000,3000,10000,30000,100000,300000,1000000]
E=lambda k:np.array([np.mean([r['evolution'][str(t)][k] for r in big if r['evolution'][str(t)][k] is not None]) for t in T])
ax.plot(T,E("fcc"),"o-",c=CF,ms=3,label="bulk fcc fraction")
ax.plot(T,E("tets_all")/8,"s-",c=CI,ms=3,label="tetrahedra per node / 8 (FCC = 1)")
ax.plot(T,E("mean_k")/12,"^-",c=CO,ms=3,label="mean K / 12")
ax.plot(T,E("k4_frac"),"v-",c=CH,ms=3,label="fraction of nodes with K = 4")
ax.set_xscale("log"); ax.set_xlabel("growth time t (nodes placed)"); ax.set_ylim(0,1.02); ax.legend(frameon=False,loc="center right",bbox_to_anchor=(1.0,0.3),fontsize=7); tag(ax,"b")
fig.subplots_adjust(wspace=0.3); save(fig,"fig3_lift_history")

# ---------------- Figure 4: the slab ----------------
fig=plt.figure(figsize=(7.2,4.4)); gsp=fig.add_gridspec(2,2,height_ratios=[1,1],width_ratios=[1.6,1],hspace=0.55,wspace=0.28)
cmap={0:"#bbbbbb",1:CA,2:CB,3:CH,-1:CT}
for i,(name,title) in enumerate((("slab_coarsen","twin coarsening (64 × 64, lift both, seed 3)"),("slab_tilt","tilted-grain takeover (64 × 64, axis lift, seed 0)"))):
    ax=fig.add_subplot(gsp[i,0]); yz=D[name+"_yz"]; v=D[name+"_v"]
    for k,lab in ((1,"ABC"),(2,"ACB"),(3,"other registry"),(-1,"off-lattice (tilted)"),(0,"substrate")):
        m=v==k
        if m.any(): ax.scatter(yz[m,1]/np.sqrt(2/3),yz[m,0],s=.5,c=cmap[k],lw=0,label=lab,rasterized=True)
    ax.set_xlabel("height (layers)"); ax.set_ylabel(r"$y$ ($L$)"); ax.set_title(title,loc="left",fontsize=8)
    ax.set_xlim(-2,300); ax.set_ylim(0,55.5)
    if i==0: ax.legend(markerscale=10,ncol=5,frameon=False,loc="upper center",bbox_to_anchor=(0.62,1.42),fontsize=7,columnspacing=.8,handletextpad=.1)
    tag(ax,"ab"[i],-0.08,1.03)
ax=fig.add_subplot(gsp[:,1])
R=L("slab2")
for n,col in ((32,"#1b9e77"),(48,"#d95f02"),(64,"#7570b3")):
    rs=[r for r in R if r['key']['nx']==n]; nb=min(len(r['profile']) for r in rs)-2; y=[];e=[]
    for i in range(1,nb):
        v=[abs(r['profile'][i]['abc']-r['profile'][i]['acb'])/(r['profile'][i]['abc']+r['profile'][i]['acb']) for r in rs if r['profile'][i]['abc'] is not None and r['profile'][i]['on_lattice']>0.9]
        y.append(np.mean(v)); e.append(np.std(v)/np.sqrt(len(v)))
    x=np.arange(1,nb)*10; y=np.array(y); e=np.array(e)
    ax.plot(x,y,c=col,lw=1.3,label=f"width {n}"); ax.fill_between(x,y-e,y+e,color=col,alpha=.2,lw=0)
ax.set_xlabel("height (layers)"); ax.set_ylabel(r"twin imbalance $|f_{ABC}-f_{ACB}|/(f_{ABC}+f_{ACB})$"); ax.set_ylim(0,1.05)
ax.legend(frameon=False,loc="lower right"); tag(ax,"c",-0.2,1.01)
save(fig,"fig4_slab")

# ---------------- Figure 5: void classes and trapping ----------------
from matplotlib.lines import Line2D
fig=plt.figure(figsize=(7.3,3.0)); gsp=fig.add_gridspec(1,3,width_ratios=[1.15,1,1],wspace=0.5)
ax=fig.add_subplot(gsp[0]); a1=np.array([1,0.]);a2=np.array([.5,np.sqrt(3)/2])
pts=np.array([i*a1+j*a2 for i in range(-4,7) for j in range(-1,5)])
inside=lambda p:(0<=p[0]<=4.0)&(0<=p[1]<=2.7)
for p in pts:
    if inside(p): ax.add_patch(Circle(p,0.30,fc="#d9d9d9",ec="#777",lw=.6)); ax.plot(*p,"x",ms=3.5,c="k",mew=.7)
for p in pts:
    q=p+(a1+a2)/3; r_=p+2*(a1+a2)/3
    if inside(q): ax.add_patch(Circle(q,0.30,fc="none",ec=CA,lw=.8,ls="--")); ax.plot(*q,"o",ms=4.5,c=CA)
    if inside(r_): ax.plot(*r_,"o",ms=4.5,mfc="white",mec=CB,mew=1.1)
ax.set_xlim(-0.45,4.45); ax.set_ylim(-0.45,3.1); ax.set_aspect("equal"); ax.axis("off")
hd=[Line2D([],[],marker="o",ls="",c=CA,ms=4.5,label=r"covered hollow → tet. void along $\hat g$"),
    Line2D([],[],marker="o",ls="",mfc="white",mec=CB,ms=4.5,label="open hollow → octahedral side"),
    Line2D([],[],marker="x",ls="",c="k",ms=4,label="atop a surface atom: not held"),
    Line2D([],[],marker="o",ls="",mfc="none",mec=CA,ms=9,label="atom of the next layer (dashed)")]
ax.legend(handles=hd,loc="upper center",bbox_to_anchor=(0.5,0.02),frameon=False,fontsize=6.8,handletextpad=.3)
ax.set_title("surface layer, top view\n(growth $\\hat g$ out of page)",fontsize=8)
fig.text(0.1,0.92,"a",fontweight="bold",fontsize=10)
ax=fig.add_subplot(gsp[1])
bins=["0–1","2–3","4–5","6–7","8–9","10–11","12–19","20–49","50–99","100–200"]
b=np.array([0.0168,-0.0008,-0.0013,0.0018,0.0021,-0.0022,0.0,-0.0003,-0.0004,-0.0006]); e=np.array([.0033,.0015,.0012,.0009,.0009,.0008,.0003,.0001,.0001,.0001])
x=np.arange(len(b)); ax.axhline(0,c="gray",lw=.6)
ax.errorbar(x,b*100,e*100,fmt="o",c=CF,ms=4,capsize=2)
ax.set_xticks(x); ax.set_xticklabels(bins,rotation=50,fontsize=7); ax.set_xlabel("depth below the front (layer gaps)")
ax.set_ylabel("along-growth void bias (%)"); ax.set_ylim(-1,3); ax.set_title("one-way slab (6 runs)",fontsize=8); tag(ax,"b",-0.3)
ax=fig.add_subplot(gsp[2])
cats=["tet.,\nalong","oct.\nside","tet.,\nagainst","irreg."]; ax_v=[479,711,0,10]; bo_v=[498,698,0,4]
xx=np.arange(4); w=0.38
ax.bar(xx-w/2,ax_v,w,color="#1b9e77",label="one lift orientation"); ax.bar(xx+w/2,bo_v,w,color=CO,label="lift both directions")
ax.text(2,30,"0 of 2,400",ha="center",fontsize=8,color=CH,fontweight="bold")
ax.set_xticks(xx); ax.set_xticklabels(cats,fontsize=7); ax.set_ylabel("remnant nodes"); ax.set_ylim(0,950); ax.legend(frameon=False,fontsize=6.8,loc="upper right",ncol=1)
ax.set_title("final site of 2,400 remnant nodes",fontsize=8); tag(ax,"c",-0.3)
save(fig,"fig5_chiral")

# ---------------- Figure A1: instability ----------------
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import registry, H
fig,ax=plt.subplots(figsize=(3.4,2.4)); Ls=np.arange(5,150,5)
for ref,mk,col,lab in ((False,"o",CH,"bare rule"),(True,"s",CF,"with unit-bond condition")):
    r=grow_slab(32,32,150,seed=0,lift_dir="axis",refine=ref); P=r['pos']; z=P[:,2]; k=np.rint(z/H).astype(int)
    dev=np.maximum(np.abs(z-k*H),registry(P)[1]); ax.semilogy(Ls,[np.median(dev[k==L_]) for L_ in Ls],mk+"-",ms=3,c=col,label=lab)
ax.axhline(0.05,c="gray",ls="--",lw=.7); ax.text(5,0.08,"bond tolerance",fontsize=7,color="gray")
ax.set_xlabel("layer"); ax.set_ylabel("median deviation from\nideal lattice ($L$)"); ax.legend(frameon=False,loc="center right",bbox_to_anchor=(1.0,0.32))
save(fig,"figA1_instability")
print("done")
