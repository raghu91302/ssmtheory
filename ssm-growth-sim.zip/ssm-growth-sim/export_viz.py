import sys, json; sys.path.insert(0,'.')
import numpy as np
from scipy.spatial import cKDTree
from ssmsim.core import grow
from ssmsim.slab import grow_slab
from ssmsim.slab_analysis import registry, H
from ssmsim.analysis import cna
src=open('gather_figs.py').read(); exec(src.split("for name,(mode,seed)")[0].split("# 2) slab twin slices")[1])  # variant()
def bonds(adj,deg,P,box=None):
    out=[]
    for i in range(len(deg)):
        for j in adj[i,:deg[i]]:
            if j<i:
                d=P[i]-P[j]
                if box is not None and (abs(d[0])>1.5 or abs(d[1])>1.5): continue   # skip periodic wrap
                out.append((int(j),int(i)))
    out.sort(key=lambda b:b[1]); return out
data={}
# ---- seed case ----
r=grow(2500,seed=6,refine=True); P=r['pos']; op=r['op']; N=len(P)
P=P-P[:3].mean(0)
k=np.rint(P[:,2]/H).astype(int)
c=cna(P)
above=np.where(P[:,2]>0.5)[0]; below=np.where(P[:,2]<-0.5)[0]; fl=int(np.argmax(op==2))
data['seed']=dict(pos=(np.round(P*1000)).astype(int).ravel().tolist(), op=op.tolist(), layer=k.tolist(),
    cna=c.tolist(), bonds=[x for b in bonds(r['adj'],r['deg'],P) for x in b],
    stages=[dict(t=3,title="Seed triangle",text="Three nodes joined by three Bell-pair bonds. Every growth step starts from a triangle like this one."),
            dict(t=fl,title="Stitching makes a flat sheet",text="Stitch adds a node in the plane of a triangle, across one of its edges. With only stitching, growth stays in a single flat sheet."),
            dict(t=fl+1,title="First lift",text="A lift places one node above (or below) a triangle, at the apex of a regular tetrahedron. Here it is the red node."),
            dict(t=int(below[0])+1 if below[0]>fl else fl+4,title="The tetrahedron's tilted faces",text="The lifted node's tetrahedron has three tilted faces. Stitching on a tilted face carries growth into the layers above and below the sheet."),
            dict(t=int(above[7])+1,title="Second layer from step edges",text="The new layer grows outward from the lifted node by stitching on tilted faces at its edge. No second lift is needed."),
            dict(t=400,title="Layers on both sides",text="Layers grow above and below the original sheet. Lifts stay rare: most nodes are placed by stitching on tilted planes."),
            dict(t=N,title="A 3D crystal",text="After 2,500 placements the cluster is a single crystal. Its interior is face-centred cubic (FCC); colour by structure to see it.")])
# ---- patch case ----
rs=grow_slab(24,24,12,seed=9,lift_dir='axis'); P=rs['pos'].copy(); op=rs['op']; Lx,Ly=rs['box']; n0=rs['stats']['n_substrate']
P[:,0]%=Lx; P[:,1]%=Ly
v=variant(rs); kk=np.rint(P[:,2]/H).astype(int)
cnt=lambda L,t: int(((kk[:t]==L)).sum())
t1=int(np.argmax((kk==1)&(np.arange(len(P))>=n0)))
t1half=next(t for t in range(n0,len(P)) if cnt(1,t)>=n0//2)
t2=int(np.argmax(kk==2))
data['patch']=dict(pos=(np.round(P*1000)).astype(int).ravel().tolist(), op=op.tolist(), layer=kk.tolist(), variant=v.tolist(),
    box=[Lx,Ly], bonds=[x for b in bonds(rs['adj'],rs['deg'],P,box=True) for x in b],
    stages=sorted([dict(t=n0,title="The crystallized past",text="A patch far from any centre starts on one complete close-packed sheet, here 24 × 24 nodes, repeated sideways."),
            dict(t=t1+1,title="A lift starts the next layer",text="On a complete flat sheet there is nowhere to stitch, so the first nodes of the new layer must be lifted (red)."),
            dict(t=t2+1,title="The next layer starts at once",text="Within a few placements a node appears one layer higher still, by stitching on a tilted face of a lifted node's tetrahedron. Several layers grow at the same time."),
            dict(t=max(t1+40,t2+20),title="Layers spread from their edges",text="Stitching on the tilted faces at the edges of each new patch adds nodes to the same layer. Layers advance from their step edges; few further lifts are needed."),
            dict(t=t1half,title="Two stacking choices",text="Each new layer can sit in one of two positions over the one below. Colour by stacking variant to see the two mirror-image variants, ABC and ACB, growing side by side."),
            dict(t=len(P),title="A rough front of many layers",text="Growth proceeds layer upon layer from step edges. The two stacking variants meet at twin boundaries, and one slowly takes over as the patch grows.")],key=lambda d:d['t']))
data['patch']['n0']=n0
s=json.dumps(data,separators=(',',':'))
open('viz/data.json','w').write(s)
print(len(s)/1e6,'MB', 'seed bonds',len(data['seed']['bonds'])//2,'patch nodes',len(P),'patch bonds',len(data['patch']['bonds'])//2)
print([ (x['t'],x['title']) for x in data['seed']['stages']]); print([(x['t'],x['title']) for x in data['patch']['stages']])
