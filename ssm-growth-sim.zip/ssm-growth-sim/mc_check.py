"""Monte Carlo check of the acceptance volumes, with counts and counting (Poisson) error bars.
Counting rule: a point counts for stitch on edge AB if it is within delta of unit distance from A and B
(whatever its distance from C), and for lift if it is within delta of unit distance from A, B and C.
The lift region therefore lies inside the stitch region (non-exclusive counting); the ratio is compared
with the leading-order (2 sqrt2/pi) delta. The exclusive form r/(1-r) is printed for comparison."""
import json, numpy as np
rng = np.random.default_rng(11)
A = np.array([0, 0, 0.]); B = np.array([1, 0, 0.]); C = np.array([.5, np.sqrt(3) / 2, 0])
lo, hi = np.array([-1.2, -1.2, -1.2]), np.array([2.2, 2.2, 1.2]); Vbox = np.prod(hi - lo)
res = {}
for d, nchunk in [(0.05, 20), (0.02, 40)]:
    n2 = n3u = n3d = 0; N = 0
    for _ in range(nchunk):
        P = rng.uniform(lo, hi, size=(10_000_000, 3)); N += len(P)
        ok = lambda X: np.abs(np.linalg.norm(P - X, axis=1) - 1) < d
        a, b, cc = ok(A), ok(B), ok(C); s = a & b; l = s & cc
        n2 += int(s.sum()); n3u += int((l & (P[:, 2] > 0)).sum()); n3d += int((l & (P[:, 2] < 0)).sum())
    n3 = n3u + n3d
    vol = lambda n: (Vbox * n / N, Vbox * np.sqrt(n) / N)
    r = n3 / n2; er = r * np.sqrt(1 / n3 + 1 / n2)
    th = 2 * np.sqrt(2) / np.pi * d
    res[str(d)] = dict(N=N, n_stitch=n2, n_lift_up=n3u, n_lift_down=n3d,
                       V_stitch=vol(n2), V_lift_up=vol(n3u), V_lift_down=vol(n3d), V_lift=vol(n3),
                       ratio=(r, er), theory_leading=th, theory_exclusive=th / (1 - th),
                       theory_V_stitch=8 * np.pi * d * d, theory_V_lift_one=8 * np.sqrt(2) * d ** 3)
    print(d, json.dumps(res[str(d)]), flush=True)
json.dump(res, open("results/mc_check.json", "w"), indent=1)
