import numpy as np, glob, sys
h=np.sqrt(2/3)
def per_run(N, dlo=6, dhi=9, gmin=4):
    out=[]
    for f in sorted(glob.glob(f'far_{N}_*.npy')):
        z,r,c,nb,m=np.load(f).T; g=np.floor(z/h).astype(int); gout=np.where(g>=0,g,-g-1)
        along=np.where(g>=0,c==1,c==-1); B=nb>=42; outer=gout[B].max(); depth=outer-gout
        k=B&(depth>=dlo)&(depth<=dhi)&(gout>=gmin)
        a=np.sum(along[k]); t=np.sum(k)
        if t>=100: out.append(((2*a-t)/t, t))
    return out
for N in sys.argv[1:]:
    v=per_run(int(N))
    if not v: print(N,"no deep far-from-seed bulk"); continue
    x=np.array([a for a,_ in v]); n=np.array([t for _,t in v])
    binom=np.sqrt(1/n.sum()); scat=x.std(ddof=1)/np.sqrt(len(x)) if len(x)>1 else float('nan')
    print(f"N={N}: runs {len(x)}, per-run values {np.round(x,3)}, voids {n.sum()}")
    print(f"   weighted mean {np.average(x,weights=n):+.4f};  binomial error {binom:.4f};  run-scatter error {scat:.4f}")
