import numpy as np, itertools
from scipy.spatial import cKDTree
from trap_count import TrapSim
a1=np.array([1,0,0.]); a2=np.array([.5,np.sqrt(3)/2,0]); h=np.sqrt(2/3)
off=[np.zeros(3),(a1+a2)/3,2*(a1+a2)/3]
pts=[]
for k in range(-6,7):
    for i in range(-10,11):
        for j in range(-10,11):
            p=i*a1+j*a2+off[k%3]; p[2]=k*h; pts.append(p)
pts=np.array(pts); tr=cKDTree(pts); cls=TrapSim._classify
up=dn=0
for i,j in tr.query_pairs(1.01):
    pass
nbr=tr.query_ball_point(pts,1.01)
seen=set()
for i in range(len(pts)):
    if np.linalg.norm(pts[i][:2])>5 or abs(pts[i][2])>3.5*h: continue    # interior only
    for j,k,l in itertools.combinations([x for x in nbr[i] if x>i],3):
        if all(np.linalg.norm(pts[x]-pts[y])<1.01 for x,y in ((j,k),(j,l),(k,l))):
            q=frozenset((i,j,k,l))
            if q in seen: continue
            seen.add(q); dummy=type("D",(),{"mode":None,"step":0})(); r=cls(dummy,pts[list(q)])
            up+=r['cls']==1; dn+=r['cls']==-1
print(f"perfect FCC interior: apex-up {up}, apex-down {dn}, all layer-aligned faces found")
