import numpy as np, sys
from scipy.spatial import cKDTree
from trap_count import run
N=int(sys.argv[1]); sd=int(sys.argv[2])
s=run(N,sd); pos=np.array(s.nodes); tr=cKDTree(pos)
nb=np.array([len(tr.query_ball_point(p,2.0))-1 for p in pos])
rows=[]
for q,r in s.closed.items():
    if r['align']<=0.99: continue
    P=pos[list(q)]; c=P.mean(0)
    rows.append((c[2], np.hypot(c[0],c[1]), r['cls'], min(nb[j] for j in q), {'lift':0,'prox':1,'stitch':2}.get(r['mode'],3)))
np.save(f'far_{N}_{sd}.npy',np.array(rows))
print(N,sd,len(rows),flush=True)
