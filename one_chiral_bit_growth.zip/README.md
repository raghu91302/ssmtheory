# Void-class statistics in the SSM growth simulation

Question (Appendix A.7 of "One Chiral Bit"): does the growth direction make one
tetrahedral-void class more common? The observable universe is a small patch far
from the growth seed, where growth runs in one direction, so the relevant
measurement is the class balance relative to the local growth direction, deep in
the bulk and far from the seed.

## Method
- `ssm_sim.py` from the ssmtheory repository, unchanged (P_lift = 0.05,
  R_ex = 0.95 L). It reproduces the published K=12 fraction (about 24% at N=1000).
- `trap_count.py` subclasses it and records every regular tetrahedral void when it
  closes: class (apex up or down along the stacking axis z), closing event, position.
- "Along" means the apex points along the local growth direction: up above the
  seed plane, down below it.
- Voids are binned by whole layer gaps. A void pointing up sits 1/4 of the way up
  its gap and one pointing down sits 3/4 of the way up, so height cuts inside a gap
  bias the count. (An earlier version of this analysis made that mistake; its "no
  preference" conclusion is withdrawn.)
- "Bulk" uses the Matter paper's criterion (at least 42 neighbors within 2L).
- Depth is measured in gaps below the outermost bulk layer.
- Classifier check: perfect FCC crystal gives 633 up and 633 down.

## Results
1. The bias depends on depth below the growing surface, not on crystal size
   (N = 1000, 2000, 3000, 5000, 10000 fall on one curve). N = 10000, 6 runs:

   | depth (gaps) | bias (along - against)/total |
   |--------------|------------------------------|
   | 0-1          | +0.230 +- 0.048              |
   | 2-3          | +0.123 +- 0.020              |
   | 4-5          | +0.067 +- 0.013              |
   | 6-7          | +0.044 +- 0.011              |
   | 8-9          | +0.030 +- 0.010              |
   | 10-11        | +0.013 +- 0.009              |
   | 12+          | +0.025 +- 0.009              |

2. Deep (6-9 gaps below the surface) and far from the seed (at least 4 gaps):
   bias = +0.038 +- 0.007 (binomial error; run-to-run scatter gives +-0.003).
   All 11 independent runs are positive (sign test p = 0.0005).

3. Deeper still, the data do not decide between two descriptions:
   - a permanent floor, +0.016 +- 0.008, with a decay length of 2.8 gaps
     (chi2 = 1.6, 4 dof);
   - a slow power-law decay with no floor, exponent 1.13 (chi2 = 4.4, 5 dof),
     giving about 0.5% at depth 50.
   Separating them needs depths of 20+ gaps, i.e. N of order 10^5.

4. Lifts close only about 3% of voids and show no preference; proximity bonding
   closes the rest. The bias is not a lift effect.

5. The origin of the bias is not understood. A vacancy explanation (newer layers
   less complete) is not supported by a layer-completeness check, although that
   check is confounded by which nodes pass the bulk criterion.

6. A modified simulation (`directed_far.py`) changes one rule: every lift tries
   the upward side (+z) first, to give growth a preferred direction. The crystal
   still grows about equally up and down, because lateral stitching drives most
   growth. All bulk voids are counted, with no height cut.

   | model, N (runs)            | crystal-wide bulk (up - down)/total | along-growth bias, 2-5 gaps deep |
   |----------------------------|-------------------------------------|----------------------------------|
   | unchanged, 1000 (20)       | +0.000 +- 0.004                     | +0.129 +- 0.011                  |
   | unchanged, 2000 (10)       | -0.002 +- 0.005                     | +0.080 +- 0.005                  |
   | directed lifts, 1000 (12)  | +0.015 +- 0.007                     | +0.092 +- 0.012                  |
   | directed lifts, 2000 (6)   | +0.012 +- 0.003                     | +0.095 +- 0.010                  |

   Preferring upward lifts shifts the crystal-wide count by only about 1%.
   (An earlier analysis of this variant used a height cut that falls mid-gap;
   those numbers are withdrawn.)

7. Surface geometry (`surface_sites.py`, independent of the simulation). On a
   perfect (111) surface a leftover node, kept at least 0.612 L from every atom,
   has 3 bonds in either three-fold hollow and 1 bond atop an atom. After the next
   layer arrives, the covered hollow is a tetrahedral void pointing along the
   growth direction and the open hollow is an octahedral void, for both stacking
   choices. Proposition 8 of the paper; also checked in ew_chiral_check.py.

## What this means for the chiral bit
- These scripts count how many voids of each class exist. The count is nearly
  balanced: in the deep bulk the along-growth class leads by only a few percent.
- The count is not the trapping rate. On a growing surface a leftover node can be
  held only in a three-fold hollow, never atop an atom. The hollow the next layer
  covers becomes a tetrahedral void pointing along the growth direction; the other
  becomes an octahedral void. So in layer-by-layer growth in one direction, every
  node trapped in a tetrahedral void points along the growth direction. This is
  Proposition 8 of the paper, checked by ew_chiral_check.py (not by these scripts).
- This simulation grows in both directions with random lift directions, so it does
  not model a one-way front. It is used only for the void count.

## Files
- `ssm_sim.py`: the published growth simulation, unchanged.
- `trap_count.py`: subclass that records each tetrahedral void as it closes.
- `far_one.py N SEED`: runs the unchanged model and saves `far_<N>_<SEED>.npy`.
- `directed_far.py N SEED`: runs the directed-lift variant and saves
  `dirfar_<N>_<SEED>.npy`.
- `depth.py N [N ...]`, `deep.py N [N ...]`: bias by depth, and the deep pooled
  estimate, from the saved files.
- `fcc_check.py`: classifier check on a perfect FCC crystal.
- `mech.py N SEED`: node completeness layer by layer (result 5).
- `surface_sites.py`: surface-trapping geometry (result 7).
- Data: `far_<N>_<seed>.npy` for N = 1000, 2000, 3000, 5000, 10000, and
  `dirfar_<N>_<seed>.npy` for N = 1000, 2000.
- Each .npy row: void center z, lateral distance, class (+1 up / -1 down),
  smallest neighbor count of its four atoms within 2L, closing event
  (0 lift, 1 proximity, 2 stitch).
- Requires Python 3 with NumPy, SciPy and NetworkX.
