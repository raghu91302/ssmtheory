import numpy as np, random, sys, itertools
from scipy.spatial import cKDTree
from trap_count import run
h=np.sqrt(2/3)
N=int(sys.argv[1]); sd=int(sys.argv[2])
s=run(N,sd); pos=np.array(s.nodes); tr=cKDTree(pos)
nb=np.array([len(tr.query_ball_point(p,2.0))-1 for p in pos]); B=nb>=42
deg=np.array([s.G.degree(i) for i in range(len(pos))])
lay=np.round(pos[:,2]/h).astype(int)                      # layer index of each node
out=np.where(lay>=0,lay,-lay)                              # outward layer index
# node completeness per outward layer, bulk nodes only
res=[]
for L in range(1,out[B].max()+1):
    k=B&(out==L)
    if k.sum()>=30: res.append((L,k.sum(),(deg[k]==12).mean(),deg[k].mean()))
outer=out[B].max()
print(f"N={N} seed={sd}  outermost bulk layer {outer}")
print("  outward layer | depth | bulk nodes | fraction K=12 | mean K")
for L,n,f12,km in res: print(f"  {L:5d}         | {outer-L:4d}  | {n:6d}     | {f12:.3f}         | {km:.2f}")
