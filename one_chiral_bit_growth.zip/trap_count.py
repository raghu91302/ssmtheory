#!/usr/bin/env python3
"""Trapping statistics by void class in the SSM growth simulation.

Uses ssm_sim.py (the Matter paper's simulation) unchanged, and records every
tetrahedral void at the moment it closes (the sixth bond of a regular
tetrahedron appears). For each void it records:
  - the event that closed it: 'lift', 'stitch', or 'prox' (proximity bonding);
  - its class along the stacking axis z: the apex off the layer-parallel face
    points up (+1) or down (-1);
  - its side of the seed plane, so that 'outward' means apex pointing away
    from the seed (the local growth direction).
"""
import itertools, random, sys
import numpy as np
from ssm_sim import SSMSim

class TrapSim(SSMSim):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.mode = 'seed'
        self.closed = {}          # frozenset(4 nodes) -> record
        self.step = 0

    # tag each growth event
    def _lift_triangle(self, tri, tree):
        self.mode = 'lift'; ok = super()._lift_triangle(tri, tree); self.mode = None; return ok
    def _stitch_lateral(self, edge, tree):
        self.mode = 'stitch'; ok = super()._stitch_lateral(edge, tree); self.mode = None; return ok
    def _proximity_stitch(self, tree):
        self.mode = 'prox'; super()._proximity_stitch(tree); self.mode = None

    def _add_edge(self, u, v):
        new = not self.G.has_edge(u, v) and u != v
        super()._add_edge(u, v)
        if not new:
            return
        self.step += 1
        common = set(self.G.neighbors(u)) & set(self.G.neighbors(v))
        for w, x in itertools.combinations(common, 2):
            if not self.G.has_edge(w, x):
                continue
            q = frozenset((u, v, w, x))
            if q in self.closed:
                continue
            P = np.array([self.nodes[i] for i in q])
            d = [np.linalg.norm(P[i] - P[j]) for i, j in itertools.combinations(range(4), 2)]
            if max(d) > 1.06 or min(d) < 0.94:       # regular tetrahedron only
                continue
            self.closed[q] = self._classify(P)

    def _classify(self, P):
        # face most nearly parallel to the layers (normal closest to z)
        best = None
        for k in range(4):
            face = np.delete(P, k, axis=0)
            n = np.cross(face[1] - face[0], face[2] - face[0]); n /= np.linalg.norm(n)
            align = abs(n[2])
            if best is None or align > best[0]:
                best = (align, k, face)
        align, k, face = best
        apex_up = 1 if P[k][2] - face[:, 2].mean() > 0 else -1
        zc = P[:, 2].mean()
        return dict(mode=self.mode, cls=apex_up, align=align, zc=zc, step=self.step)

def run(N, seed, lift=0.05):
    random.seed(seed); np.random.seed(seed)
    s = TrapSim(N, lift); s.run()
    return s

if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    seeds = range(int(sys.argv[2]) if len(sys.argv) > 2 else 5)
    for sd in seeds:
        s = run(N, sd)
        recs = list(s.closed.values())
        print(sd, len(recs))
