"""Directed-lift variant: identical to ssm_sim.py except that each lift tries the
side with positive z first (one preferred growth direction). Saves every classified
void, like far_one.py, as dirfar_<N>_<seed>.npy."""
import numpy as np, random, sys
from scipy.spatial import cKDTree
from trap_count import TrapSim
from ssm_sim import LIFT_HEIGHT, UNIT_LENGTH
class Directed(TrapSim):
    def _lift_triangle(self, tri, tree):
        self.mode='lift'
        u,v,w=tri; p0,p1,p2=(self.nodes[i] for i in tri)
        c=(p0+p1+p2)/3; n=np.cross(p1-p0,p2-p0); L=np.linalg.norm(n)
        if L==0: self.active_triangles.discard(tri); self.mode=None; return False
        n/=L
        for sgn in ([1,-1] if n[2]>=0 else [-1,1]):
            cand=c+n*LIFT_HEIGHT*UNIT_LENGTH*sgn
            if self._is_valid(cand,tree):
                nid=self._add_node(cand); self._add_edge(nid,u); self._add_edge(nid,v); self._add_edge(nid,w)
                self.mode=None; return True
        self.active_triangles.discard(tri); self.mode=None; return False
N=int(sys.argv[1]); sd=int(sys.argv[2])
random.seed(sd); np.random.seed(sd); s=Directed(N,0.05); s.run()
pos=np.array(s.nodes); tr=cKDTree(pos); nb=np.array([len(tr.query_ball_point(p,2.0))-1 for p in pos])
rows=[]
for q,r in s.closed.items():
    if r['align']<=0.99: continue
    c=pos[list(q)].mean(0)
    rows.append((c[2],np.hypot(c[0],c[1]),r['cls'],min(nb[j] for j in q),{'lift':0,'prox':1,'stitch':2}.get(r['mode'],3)))
np.save(f'dirfar_{N}_{sd}.npy',np.array(rows)); print(N,sd,len(rows),round(pos[:,2].min(),1),round(pos[:,2].max(),1),flush=True)
