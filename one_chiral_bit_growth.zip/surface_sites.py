"""Where can a leftover node sit on a growing (111) surface, and which void traps it
when the next layer arrives? Checked for both stacking choices of the next layer."""
import numpy as np, itertools
from scipy.spatial import cKDTree, ConvexHull, Delaunay
a1=np.array([1,0,0.]); a2=np.array([.5,np.sqrt(3)/2,0]); h=np.sqrt(2/3)
shift={'A':np.zeros(3),'B':(a1+a2)/3,'C':2*(a1+a2)/3}
def layer(t,z): return np.array([i*a1+j*a2+shift[t]+[0,0,z] for i in range(-6,7) for j in range(-6,7)])
surf=layer('A',0.0)                                   # top layer of the grown crystal
tr=cKDTree(surf)
# candidate rest positions for a leftover node: above an atom (atop), above a B hollow, above a C hollow
sites={'atop':shift['A'][:2],'hollow B':shift['B'][:2],'hollow C':shift['C'][:2]}
dmin=np.sqrt(3/8)      # 0.612 L: closest approach of a trapped node to an atom (Matter paper)
def best_bonds(xy):
    best=0
    for z in np.linspace(0.01,1.2,400):
        d=np.linalg.norm(surf-np.r_[xy,z],axis=1)
        if d.min()>=dmin-1e-9: best=max(best,int(np.sum(d<=1.05)))   # no overlap with an atom
    return best
print("1) Support on the bare surface (bonds to surface atoms, no closer than 0.612 L to any atom):")
for name,xy in sites.items():
    b=best_bonds(xy)
    print(f"   {name:9s}: at most {b} surface bonds  ->  {'held' if b>=3 else 'not held'}")
print("\n2) After the next layer arrives, which void contains a leftover resting in each hollow?")
for nxt in ('B','C'):                                 # ABC stacking or a stacking fault
    top=layer(nxt,h); both=np.vstack([surf,top]); T=cKDTree(both)
    for name in ('hollow B','hollow C'):
        p=np.r_[sites[name],h/4]                         # remnant position inside the hollow (tetrahedral depth)
        idx=T.query(p,k=6)[1]; P=both[idx]
        # tetrahedral void: its 4 nearest atoms form a regular tetrahedron containing p
        q=both[T.query(p,k=4)[1]]
        d=[np.linalg.norm(q[i]-q[j]) for i,j in itertools.combinations(range(4),2)]
        inside=Delaunay(q).find_simplex(p)>=0 and max(d)<1.01
        if inside:
            apex_up=sum(q[:,2]>h/2)==1               # one atom in the new (upper) layer = apex along growth
            kind='tetrahedral, apex ALONG growth' if apex_up else 'tetrahedral, apex AGAINST growth'
        else:
            q6=both[T.query(p,k=6)[1]]; kind='octahedral' if Delaunay(q6).find_simplex(p)>=0 else 'other'
        print(f"   next layer on {nxt}: leftover in {name} -> {kind}")
