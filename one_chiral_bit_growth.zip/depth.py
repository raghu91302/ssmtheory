import numpy as np, glob, sys
h=np.sqrt(2/3)
def rows(N):
    out=[]
    for f in sorted(glob.glob(f'far_{N}_*.npy')):
        z,r,c,nb,m=np.load(f).T; g=np.floor(z/h).astype(int); gout=np.where(g>=0,g,-g-1)
        along=np.where(g>=0,c==1,c==-1); B=nb>=42
        outer=gout[B].max()
        out.append((gout,along,B,outer))
    return out
def by_depth_and_seedgap(N, dbins=((0,1),(2,3),(4,5),(6,7),(8,9),(10,11),(12,99)), far_from_seed=4):
    R=rows(N); print(f"N={N}, runs={len(R)}; outermost bulk gap {np.mean([o for *_,o in R]):.0f}")
    print("  depth below surface | all bulk gaps        | only gaps >= %d from the seed"%far_from_seed)
    for lo,hi in dbins:
        res=[]
        for sel in (lambda g,o:True, lambda g,o:g>=far_from_seed):
            a=b=0
            for gout,along,B,outer in R:
                depth=outer-gout; k=B&(depth>=lo)&(depth<=hi)&sel(gout,outer)
                a+=np.sum(along[k]); b+=np.sum(k)-np.sum(along[k])
            t=a+b; res.append(f"{(a-b)/t:+.3f} +- {1/np.sqrt(t):.3f} (n={t:5d})" if t>=50 else "        --          ")
        print(f"  {lo:2d}-{hi:2d}{'':15s}| {res[0]} | {res[1]}")
if __name__=='__main__':
    for N in sys.argv[1:]: by_depth_and_seedgap(int(N))
