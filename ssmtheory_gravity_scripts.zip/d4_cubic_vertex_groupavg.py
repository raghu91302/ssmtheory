#!/usr/bin/env python3
# =============================================================================
# D4 cubic graviton vertex -- EXACT point-group-averaged (zero sampling error).
#
# WHY THIS REPLACES THE MONTE-CARLO SYMMETRIZATION
# ------------------------------------------------
# d4_cubic_vertex_symmetrized.py averaged the translation-invariant vertex over
# random subdivisions.  That run (NTRI=64, DPS=80) PROVED the principle:
#   * flatness exact (max|O(k^0)| = 5.3e-65),
#   * the lattice-symmetry pair gap collapsed 142 -> 0.805 (subdivision artifact
#     being removed),
# but the estimator converges as 1/sqrt(N) against a per-subdivision spread of
# +-200..400, so the standard error stalled at ~12 (median) / ~52 (worst).
# Reaching stderr ~1 would need ~10^4 x more subdivisions (~weeks).  Monte Carlo
# is the wrong estimator.
#
# THE EXACT ESTIMATOR.  Symmetrizing the vertex over the D4 lattice point group G
# (acting on the kinematics) on a FIXED triangulation is a finite exact average,
# not a sample:
#     c2_sym(cfg) = (1/|G|) sum_{g in G} c2_single[ g.cfg ; T_fixed ],
#     g.cfg = ( g k_i ,  g eps_i g^T ).
# Because g is an integer (signed-permutation) lattice automorphism, every image
# is exact; the average has NO sampling error.  Validated: two configs related by
# a lattice automorphism R (cfg12, cfg22) have identical G-orbits, so their
# averages are bit-identical (difference exactly 0), and a 4-element subgroup
# already returns the clean value 50 where the raw triangulation gave 43 vs 37.
#
# WHAT IS REMOVED AND WHAT IS NOT.  Averaging over G = signed permutations (B4,
# order 384) removes every non-G-invariant part of the subdivision artifact and
# restores the lattice point group exactly.  It does NOT remove (i) a possible
# G-invariant part of the artifact -- caught by checking BASE-triangulation
# independence -- nor (ii) genuine hypercubic anisotropy (the 24-cell is a
# 5-design not a 6-design).  (i) varies between base triangulations; (ii) does
# not.  So: the part of c2_sym that AGREES across base triangulations is physical
# (EH + any genuine hypercubic remainder); base-to-base spread bounds the residual
# artifact.  The downstream fit then splits physical c2_sym into an O(4)-invariant
# (Einstein-Hilbert) part and a hypercubic-anisotropic remainder.
#
# SELF-CHECKS (refuses to certify on failure):
#   * flatness max|O(k^0)| ~ 0 on every base;
#   * EXACT lattice-symmetry: c2_sym(cfg0) and c2_sym(R.cfg0) must agree to
#     ~10^-(DPS) -- now a SHARP test (R in G makes them equal by construction;
#     any disagreement means a bug in the group action), not a statistical one;
#   * base independence: max |c2_sym(base_i) - c2_sym(base_j)| per config small.
#
# COST.  |G| x NCFG x 6 vertex evals per base.  With G=B4 (384) this is ~6x the
# 64-subdivision MC run (~6 h/base on 32 procs at DPS=80/RLEV=4) but EXACT.  Knobs
# below trade group size / base count / precision.  Recommended staged use: run
# ONE base full-B4 first (status PASS on flatness+pair) and do the EH fit; only if
# a hypercubic remainder appears, add a 2nd/3rd base to confirm it is physical.
# (A one-time third-derivative-tensor build per base would make the |G| sweep
# ~50x cheaper, but is NOT shipped here unvalidated; validate it against this
# exact reference before trusting it.)
#
# Pure Python + numpy + scipy + mpmath.  No internet.
# =============================================================================
import numpy as np, itertools as it, mpmath as mp, json, sys, time
from scipy.spatial import Delaunay
from collections import defaultdict
from fractions import Fraction

# ----------------------------------------------------------------- tunables
DPS        = 80
H0         = mp.mpf('1e-3')
RLEV       = 4
NCFG       = 40
SEED       = 20240611          # config-selection seed
BASE_SEEDS = [0]               # base triangulations; add e.g. [0,1,2] for the
                               # base-independence check (cost scales linearly)
GROUP_MODE = 'full'            # 'full'    = B4, all 384 signed permutations
                               #             (the physical run: removes the artifact,
                               #              restores the full lattice point group);
                               # 'preview' = <R_CHECK> only (order 4) -- validates the
                               #             plumbing fast, NOT a physical symmetrization.
mp.mp.dps  = DPS

# 90-deg rotation in the (3,4) plane: a signed permutation, lattice automorphism.
R_CHECK = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,-1],[0,0,1,0]], dtype=int)

# ----------------------------------------------------------------- point group B4
def _close(gens):
    """Closure of a generating set under multiplication (a genuine subgroup)."""
    I=np.eye(4,dtype=int); G={I.tobytes():I}; frontier=[I]+list(gens)
    for g in gens: G[g.tobytes()]=g
    changed=True
    while changed:
        changed=False
        cur=list(G.values())
        for a in cur:
            for b in cur:
                m=(a@b).astype(int); kb=m.tobytes()
                if kb not in G:
                    G[kb]=m; changed=True
    return list(G.values())

def point_group(mode):
    if mode=='preview':
        return _close([R_CHECK])                      # order 4, contains R
    G=[]
    for perm in it.permutations(range(4)):            # full B4 = 384
        for signs in it.product((1,-1),repeat=4):
            M=np.zeros((4,4),dtype=int)
            for i in range(4): M[i,perm[i]]=signs[i]
            G.append(M)
    return G

# ----------------------------------------------------------------- D4 star
def build_star(perm_seed):
    pts=[v for v in it.product(range(-3,4),repeat=4)
         if sum(v)%2==0 and sum(x*x for x in v)<=8]
    pts=np.array(sorted(pts),int)
    if perm_seed is not None:
        pts=pts[np.random.default_rng(perm_seed).permutation(len(pts))]
    O=int(np.where((pts==0).all(1))[0][0])
    simp=[tuple(s) for s in Delaunay(pts.astype(float),qhull_options='Qt').simplices]
    star=[s for s in simp if O in s]
    hinges=sorted({tuple(sorted(t)) for s in star
                   for t in it.combinations(s,3) if O in t})
    around=defaultdict(list)
    for s in simp:
        for t in it.combinations(sorted(s),3):
            if O in t: around[t].append(s)
    fk=lambda a,b:(min(a,b),max(a,b))
    edges=sorted({fk(a,b) for s in star for a,b in it.combinations(s,2)})
    L0={e:mp.mpf(int((pts[e[0]]-pts[e[1]])@(pts[e[0]]-pts[e[1]]))) for e in edges}
    return dict(pts=pts,O=O,hinges=hinges,around=around,fk=fk,edges=edges,L0=L0)

# ----------------------------------------------------------------- Regge action
def make_engine(st):
    fk,edges,L0,hinges,around,pts=st['fk'],st['edges'],st['L0'],st['hinges'],st['around'],st['pts']
    def dih(Ld,loc):
        Lm={(i,j):Ld[fk(loc[i],loc[j])] for i in range(5) for j in range(i+1,5)}
        xx=lambda i,j:(Lm[(0,i)] if i==j
                       else (Lm[(0,min(i,j))]+Lm[(0,max(i,j))]-Lm[(min(i,j),max(i,j))])/2)
        det=xx(1,1)*xx(2,2)-xx(1,2)**2
        def perp(a,b):
            ua,va=xx(1,a),xx(2,a); ub,vb=xx(1,b),xx(2,b)
            return xx(a,b)-((xx(2,2)*ua-xx(1,2)*va)*ub+(-xx(1,2)*ua+xx(1,1)*va)*vb)/det
        c=perp(3,4)/mp.sqrt(perp(3,3)*perp(4,4))
        c=mp.mpf(1) if c>1 else (mp.mpf(-1) if c<-1 else c)
        return mp.acos(c)
    def heron(a,b,c):
        H=2*a*b+2*b*c+2*c*a-a*a-b*b-c*c; return mp.sqrt(H)/4
    def action(Ld):
        S=mp.mpf(0)
        for h in hinges:
            i,j,k=h; d=2*mp.pi
            for s in around[h]:
                d-=dih(Ld,list(h)+[v for v in s if v not in h])
            S+=heron(Ld[fk(i,j)],Ld[fk(i,k)],Ld[fk(j,k)])*d
        return S
    def S3(v1,v2,v3):
        def mx(v):
            m=mp.mpf(0)
            for x in v.values():
                if abs(x)>m: m=abs(x)
            return m if m>0 else mp.mpf(1)
        s=[mx(v1),mx(v2),mx(v3)]
        n=[{e:v.get(e,mp.mpf(0))/si for e in edges} for v,si in zip((v1,v2,v3),s)]
        def D(step):
            tot=mp.mpf(0)
            for sg in it.product([1,-1],repeat=3):
                Ld={e:L0[e]+step*(sg[0]*n[0][e]+sg[1]*n[1][e]+sg[2]*n[2][e]) for e in edges}
                tot+=sg[0]*sg[1]*sg[2]*action(Ld)
            return tot/(2*step)**3
        Dk=[D(H0/2**k) for k in range(RLEV)]
        for m in range(1,RLEV):
            f=mp.mpf(4**m); Dk=[(f*Dk[i+1]-Dk[i])/(f-1) for i in range(len(Dk)-1)]
        return mp.re(Dk[0])*s[0]*s[1]*s[2]
    def modes(eps,kap):
        u={};y={};w={}
        for e in edges:
            Dv=pts[e[1]]-pts[e[0]]; p=mp.mpf(int(Dv@eps@Dv))
            ph=mp.mpf(int(kap@(pts[e[0]]+pts[e[1]])))/2
            u[e]=p; y[e]=p*ph; w[e]=p*ph*ph
        return u,y,w
    def c2(k1,k2,k3,e1,e2,e3):
        """Translation-invariant O(k^2) cubic coefficient for EXPLICIT polarizations
        (so they can be rotated by a group element)."""
        u1,y1,w1=modes(e1,k1); u2,y2,w2=modes(e2,k2); u3,y3,w3=modes(e3,k3)
        sq   = S3(w1,u2,u3)+S3(u1,w2,u3)+S3(u1,u2,w3)
        cross= 2*(S3(y1,y2,u3)+S3(u1,y2,y3)+S3(y1,u2,y3))
        c0   = S3(u1,u2,u3)
        return mp.mpf('-0.5')*(sq+cross), c0
    return c2

# ----------------------------------------------------------------- TT kinematics
def perp_int(k):
    for e in np.eye(4,dtype=int):
        w=e*int(k@k)-k*int(e@k)
        if np.any(w): return w
    return None
def TT(k):
    a=perp_int(k); b=None
    for e in np.eye(4,dtype=int):
        cand=e*int(k@k)-k*int(e@k); cand=cand*int(a@a)-a*int(a@cand)
        if np.any(cand): b=cand; break
    g=np.gcd.reduce(np.abs(b)) if np.any(b) else 1
    if g: b=b//g
    return np.outer(a,b)+np.outer(b,a)
def invariants(k1,k2,k3):
    e1,e2,e3=TT(k1),TT(k2),TT(k3)
    return [int(np.tensordot(e1,e2)),int(np.tensordot(e2,e3)),int(np.tensordot(e3,e1)),
            int(k2@e1@k2),int(k3@e2@k3),int(k1@e3@k1),
            int(k1@k2),int(k2@k3),int(k3@k1)]

# ----------------------------------------------------------------- group average
def group_average(c2, cfg, G):
    """Exact average of c2 over the G-orbit of cfg, deduplicated by orbit
    multiplicity (free speedup for symmetric configs)."""
    k1,k2,k3=cfg; e1,e2,e3=TT(k1),TT(k2),TT(k3)
    seen={}
    for g in G:
        gk1,gk2,gk3=g@k1,g@k2,g@k3
        ge1,ge2,ge3=g@e1@g.T,g@e2@g.T,g@e3@g.T
        key=(gk1.tobytes(),gk2.tobytes(),gk3.tobytes(),
             ge1.tobytes(),ge2.tobytes(),ge3.tobytes())
        if key in seen: seen[key][0]+=1
        else: seen[key]=[1,(gk1,gk2,gk3,ge1,ge2,ge3)]
    tot=mp.mpf(0); ntot=0; c0max=mp.mpf(0)
    for mult,args in seen.values():
        val,c0=c2(*args); tot+=mult*val; ntot+=mult
        if abs(c0)>c0max: c0max=abs(c0)
    return tot/ntot, c0max, len(seen)

def recog(x):
    scale=mp.mpf(10)**40
    approx=Fraction(int(mp.nint(x*scale)),int(scale)).limit_denominator(10**9)
    if abs(mp.mpf(approx.numerator)/approx.denominator-x)<mp.mpf(10)**(-15):
        return str(approx)
    return None

# ----------------------------------------------------------------- config sampling
def sample_configs(n,seed):
    rng=np.random.default_rng(seed); out=[]; tries=0
    while len(out)<n and tries<n*40:
        tries+=1
        k1=rng.integers(-1,2,4); k2=rng.integers(-1,2,4); k3=-k1-k2
        if np.max(np.abs(k3))>1: continue
        if not (np.any(k1) and np.any(k2) and np.any(k3)): continue
        out.append((k1,k2,k3))
    return out

# ----------------------------------------------------------------- main
def main():
    t0=time.time()
    G=point_group(GROUP_MODE)
    cfgs=sample_configs(NCFG,SEED)
    print(f"# D4 cubic vertex -- EXACT point-group average | DPS={DPS} RLEV={RLEV}")
    print(f"# group={GROUP_MODE} |G|={len(G)}  NCFG={NCFG}  bases={BASE_SEEDS}")

    per_base=[]          # per_base[b][i] = c2_sym for config i on base b
    c0max=mp.mpf(0)
    for b,seed in enumerate(BASE_SEEDS):
        st=build_star(seed); c2=make_engine(st)
        vals=[]
        for i,(a,bb,cc) in enumerate(cfgs):
            v,c0,norb=group_average(c2,(a,bb,cc),G)
            vals.append(v)
            if c0>c0max: c0max=c0
            if (i+1)%5==0 or i==NCFG-1:
                print(f"  base{b}(seed={seed}) cfg{i:2d}: c2_sym={mp.nstr(v,12)}"
                      f"  orbit={norb}  elapsed {time.time()-t0:.0f}s",flush=True)
        per_base.append(vals)

    # ---- self-checks ----
    flat_ok = c0max < mp.mpf('1e-12')
    # exact lattice-symmetry pair: c2_sym(cfg0) vs c2_sym(R.cfg0) on base 0
    st0=build_star(BASE_SEEDS[0]); c2_0=make_engine(st0)
    k1,k2,k3=cfgs[0]; probe=(R_CHECK@k1,R_CHECK@k2,R_CHECK@k3)
    pv,_,_=group_average(c2_0,probe,G)
    pair_gap=abs(per_base[0][0]-pv)
    pair_ok = pair_gap < mp.mpf('1e-10')
    # base independence
    if len(BASE_SEEDS)>1:
        base_spread=max(max(abs(per_base[b][i]-per_base[0][i]) for b in range(len(BASE_SEEDS)))
                        for i in range(NCFG))
        base_ok=base_spread<mp.mpf('1e-6')
    else:
        base_spread=None; base_ok=None

    print("\n# ---- self-checks ----")
    print(f"# flatness max|O(k^0)| = {mp.nstr(c0max,3)}   {'PASS' if flat_ok else 'FAIL'}")
    print(f"# EXACT lattice-symmetry pair |c2_sym(cfg0)-c2_sym(R.cfg0)| = {mp.nstr(pair_gap,3)}"
          f"   {'PASS' if pair_ok else 'FAIL (group-action bug)'}")
    if base_spread is not None:
        print(f"# base-independence max spread = {mp.nstr(base_spread,3)}"
              f"   {'PASS (artifact removed)' if base_ok else 'REVIEW (G-invariant residual)'}")
    else:
        print(f"# base-independence: single base ({BASE_SEEDS[0]}); add bases to test")

    status='PASS' if (flat_ok and pair_ok and (base_ok in (None,True))) else 'REVIEW'
    rows=[]
    for i,(a,bb,cc) in enumerate(cfgs):
        # average over bases (each exact); report mean and base spread
        bvals=[per_base[b][i] for b in range(len(BASE_SEEDS))]
        mean=sum(bvals)/len(bvals)
        spread=max(abs(v-mean) for v in bvals) if len(bvals)>1 else mp.mpf(0)
        rows.append({"k1":[int(x) for x in a],"k2":[int(x) for x in bb],"k3":[int(x) for x in cc],
                     "c2_sym":mp.nstr(mean,40),"c2_sym_rational":recog(mean),
                     "base_spread":mp.nstr(spread,6),
                     "invariants":invariants(a,bb,cc)})
    out=dict(method="exact_point_group_average",
             settings=dict(dps=DPS,rlev=RLEV,group_size=len(G),ncfg=NCFG,seed=SEED,
                           base_seeds=BASE_SEEDS,h0=mp.nstr(H0,3)),
             selfcheck=dict(flatness_maxabs=mp.nstr(c0max,3),
                            pair_gap=mp.nstr(pair_gap,6),pair_ok=bool(pair_ok),
                            base_spread=(mp.nstr(base_spread,6) if base_spread is not None else None),
                            base_ok=(bool(base_ok) if base_ok is not None else None)),
             status=status, rows=rows, elapsed_seconds=time.time()-t0)
    with open("d4_cubic_vertex_groupavg_data.json","w") as fh:
        json.dump(out,fh,indent=1)
    print(f"\n# status: {status}")
    print(f"# wrote d4_cubic_vertex_groupavg_data.json ({NCFG} configs, {time.time()-t0:.0f}s)")
    print("# c2_sym is the EXACT point-group-averaged O(k^2) coefficient (rational where")
    print("# recognized). Send the JSON back for the EH-vs-hypercubic decomposition +")
    print("# longitudinal-leg gauge check.")

if __name__=="__main__":
    main()
