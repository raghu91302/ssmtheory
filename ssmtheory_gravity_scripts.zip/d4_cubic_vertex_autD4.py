#!/usr/bin/env python3
# =============================================================================
# D4 cubic graviton vertex -- EXACT average over the FULL lattice automorphism
# group Aut(D4) = W(F4), order 1152  (B4 signed permutations + triality cosets).
#
# WHY (follows d4_cubic_vertex_groupavg.py, the B4=384 run):
#   The B4 average gave an exact, lattice-symmetric vertex with a ~12% hypercubic
#   anisotropy (rank-1 outside the complete dim-9 O(4) space), and the 24-cell's
#   degree-6 design defect (5-design, not 6-design) explains it.  B4 is only a
#   subgroup of the lattice symmetry, so the B4-average could carry a residual
#   triality-breaking piece of the subdivision artifact ON TOP of the genuine
#   anisotropy.  Averaging over the FULL Aut(D4) removes that and pins the genuine
#   (automorphism-invariant, hence physical) anisotropy magnitude.
#
# WHAT'S NEW vs the B4 script:
#   * group = Aut(D4) (1152) built by exact closure of {swap,cyc,flip,H};
#     768 of the elements are triality cosets with half-integer entries.
#   * because triality maps integer kinematics to HALF-INTEGER kinematics, the
#     edge modes are computed in exact rational (mpf-from-Fraction) arithmetic
#     instead of integer-only.  Validated to reproduce the integer modes on B4.
#   * orbit dedup uses exact Fraction keys.
#
# SELF-CHECKS (refuses to certify on failure):
#   * flatness max|O(k^0)| ~ 0;
#   * EXACT lattice-symmetry pair c2(cfg0) == c2(R.cfg0), R a signed perm in B4;
#   * triality indicator: c2(cfg0) vs c2(H.cfg0) -- if the FULL-group average is
#     genuinely Aut(D4)-invariant these agree (they must, by construction); this
#     guards the rational-kinematics path on the triality coset.
#
# COST: 1152 x NCFG x 6 vertex evals per base ~ 3x the B4 run (~12 h, 32 procs at
# DPS=80/RLEV=4).  Tunables below.  Recommended: first GROUP_MODE='full' on a few
# configs (NCFG small) to compare against the B4 numbers before the full sweep.
#
# Pure Python + numpy + scipy + mpmath.  No internet.
# =============================================================================
import numpy as np, itertools as it, mpmath as mp, json, time
from fractions import Fraction as Fr
from scipy.spatial import Delaunay
from collections import defaultdict, deque

# ----------------------------------------------------------------- tunables
DPS        = 80
H0         = mp.mpf('1e-3')
RLEV       = 4
NCFG       = 40
SEED       = 20240611
BASE_SEEDS = [0]
GROUP_MODE = 'full'        # 'full' = Aut(D4) (1152);  'b4' = signed perms (384);
                           # 'preview' = <H, flip> small subgroup (plumbing test)
mp.mp.dps  = DPS
R_CHECK = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,-1],[0,0,1,0]], dtype=int)

# ----------------------------------------------------------------- Aut(D4)
def _mat(rows, half=False):
    f=Fr(1,2) if half else Fr(1)
    return tuple(tuple(f*Fr(x) for x in r) for r in rows)
def _mul(A,B):
    return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(4)) for j in range(4)) for i in range(4))
def aut_d4(mode):
    swap=_mat([[0,1,0,0],[1,0,0,0],[0,0,1,0],[0,0,0,1]])
    cyc =_mat([[0,1,0,0],[0,0,1,0],[0,0,0,1],[1,0,0,0]])
    flip=_mat([[-1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    H   =_mat([[1,1,1,1],[1,-1,1,-1],[1,1,-1,-1],[1,-1,-1,1]], half=True)
    I   =_mat([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    gens={'full':[swap,cyc,flip,H],'b4':[swap,cyc,flip],'preview':[H,flip]}[mode]
    G={I}; fr=deque([I])
    while fr:
        a=fr.popleft()
        for g in gens:
            for p in (_mul(a,g),_mul(g,a)):
                if p not in G: G.add(p); fr.append(p)
    # return as numpy Fraction-object matrices
    return [np.array(M,dtype=object) for M in G]

# ----------------------------------------------------------------- D4 star
def build_star(perm_seed):
    pts=[v for v in it.product(range(-3,4),repeat=4)
         if sum(v)%2==0 and sum(x*x for x in v)<=8]
    pts=np.array(sorted(pts),int)
    if perm_seed is not None:
        pts=pts[np.random.default_rng(perm_seed).permutation(len(pts))]
    O=int(np.where((pts==0).all(1))[0][0])
    simp=[tuple(s) for s in Delaunay(pts.astype(float),qhull_options='Qt').simplices]
    star=[s for s in simp if O in s]
    hinges=sorted({tuple(sorted(t)) for s in star for t in it.combinations(s,3) if O in t})
    around=defaultdict(list)
    for s in simp:
        for t in it.combinations(sorted(s),3):
            if O in t: around[t].append(s)
    fk=lambda a,b:(min(a,b),max(a,b))
    edges=sorted({fk(a,b) for s in star for a,b in it.combinations(s,2)})
    L0={e:mp.mpf(int((pts[e[0]]-pts[e[1]])@(pts[e[0]]-pts[e[1]]))) for e in edges}
    return dict(pts=pts,O=O,hinges=hinges,around=around,fk=fk,edges=edges,L0=L0)

# ----------------------------------------------------------------- Regge engine
def make_engine(st):
    fk,edges,L0,hinges,around,pts=st['fk'],st['edges'],st['L0'],st['hinges'],st['around'],st['pts']
    def dih(Ld,loc):
        Lm={(i,j):Ld[fk(loc[i],loc[j])] for i in range(5) for j in range(i+1,5)}
        xx=lambda i,j:(Lm[(0,i)] if i==j
                       else (Lm[(0,min(i,j))]+Lm[(0,max(i,j))]-Lm[(min(i,j),max(i,j))])/2)
        det=xx(1,1)*xx(2,2)-xx(1,2)**2
        def perp(a,b):
            ua,va=xx(1,a),xx(2,a); ub,vb=xx(1,b),xx(2,b)
            return xx(a,b)-((xx(2,2)*ua-xx(1,2)*va)*ub+(-xx(1,2)*ua+xx(1,1)*va)*vb)/det
        c=perp(3,4)/mp.sqrt(perp(3,3)*perp(4,4))
        c=mp.mpf(1) if c>1 else (mp.mpf(-1) if c<-1 else c)
        return mp.acos(c)
    def heron(a,b,c):
        H=2*a*b+2*b*c+2*c*a-a*a-b*b-c*c; return mp.sqrt(H)/4
    def action(Ld):
        S=mp.mpf(0)
        for h in hinges:
            i,j,k=h; d=2*mp.pi
            for s in around[h]:
                d-=dih(Ld,list(h)+[v for v in s if v not in h])
            S+=heron(Ld[fk(i,j)],Ld[fk(i,k)],Ld[fk(j,k)])*d
        return S
    def S3(v1,v2,v3):
        def mx(v):
            m=mp.mpf(0)
            for x in v.values():
                if abs(x)>m: m=abs(x)
            return m if m>0 else mp.mpf(1)
        s=[mx(v1),mx(v2),mx(v3)]
        n=[{e:v.get(e,mp.mpf(0))/si for e in edges} for v,si in zip((v1,v2,v3),s)]
        def D(step):
            tot=mp.mpf(0)
            for sg in it.product([1,-1],repeat=3):
                Ld={e:L0[e]+step*(sg[0]*n[0][e]+sg[1]*n[1][e]+sg[2]*n[2][e]) for e in edges}
                tot+=sg[0]*sg[1]*sg[2]*action(Ld)
            return tot/(2*step)**3
        Dk=[D(H0/2**k) for k in range(RLEV)]
        for m in range(1,RLEV):
            f=mp.mpf(4**m); Dk=[(f*Dk[i+1]-Dk[i])/(f-1) for i in range(len(Dk)-1)]
        return mp.re(Dk[0])*s[0]*s[1]*s[2]
    def modes(eps, kap):
        # eps: 4x4 mpf, kap: 4 mpf  (RATIONAL kinematics supported)
        u={};y={};w={}
        for e in edges:
            Dv=pts[e[1]]-pts[e[0]]
            p=mp.mpf(0)
            for i in range(4):
                di=int(Dv[i])
                if di:
                    for j in range(4):
                        if Dv[j]: p+=di*eps[i,j]*int(Dv[j])
            xs=pts[e[0]]+pts[e[1]]
            ph=mp.mpf(0)
            for i in range(4): ph+=kap[i]*int(xs[i])
            ph=ph/2
            u[e]=p; y[e]=p*ph; w[e]=p*ph*ph
        return u,y,w
    def c2(k_mpf, e_list_mpf):
        u1,y1,w1=modes(e_list_mpf[0],k_mpf[0])
        u2,y2,w2=modes(e_list_mpf[1],k_mpf[1])
        u3,y3,w3=modes(e_list_mpf[2],k_mpf[2])
        sq   = S3(w1,u2,u3)+S3(u1,w2,u3)+S3(u1,u2,w3)
        cross= 2*(S3(y1,y2,u3)+S3(u1,y2,y3)+S3(y1,u2,y3))
        c0   = S3(u1,u2,u3)
        return mp.mpf('-0.5')*(sq+cross), c0
    return c2

# ----------------------------------------------------------------- TT kinematics
def perp_int(k):
    for e in np.eye(4,dtype=int):
        w=e*int(k@k)-k*int(e@k)
        if np.any(w): return w
    return None
def TT(k):
    a=perp_int(k); b=None
    for e in np.eye(4,dtype=int):
        cand=e*int(k@k)-k*int(e@k); cand=cand*int(a@a)-a*int(a@cand)
        if np.any(cand): b=cand; break
    g=np.gcd.reduce(np.abs(b)) if np.any(b) else 1
    if g: b=b//g
    return np.outer(a,b)+np.outer(b,a)
def invariants(k1,k2,k3):
    e1,e2,e3=TT(k1),TT(k2),TT(k3)
    return [int(np.tensordot(e1,e2)),int(np.tensordot(e2,e3)),int(np.tensordot(e3,e1)),
            int(k2@e1@k2),int(k3@e2@k3),int(k1@e3@k1),
            int(k1@k2),int(k2@k3),int(k3@k1)]

def fr2mpf_vec(v): return [mp.mpf(x.numerator)/x.denominator for x in v]
def fr2mpf_mat(M): return mp.matrix([[mp.mpf(M[i,j].numerator)/M[i,j].denominator for j in range(4)] for i in range(4)])

def group_average(c2, cfg, G):
    k=[np.array([Fr(int(x)) for x in kk],dtype=object) for kk in cfg]
    e=[np.array([[Fr(int(TT(cfg[t])[i,j])) for j in range(4)] for i in range(4)],dtype=object) for t in range(3)]
    seen={}
    for g in G:
        gk=[g@kk for kk in k]; ge=[g@ee@g.T for ee in e]
        key=tuple(tuple(x for x in v) for v in gk)+tuple(tuple(M.flatten()) for M in ge)
        if key in seen: seen[key][0]+=1
        else: seen[key]=[1,(gk,ge)]
    tot=mp.mpf(0); ntot=0; c0max=mp.mpf(0)
    for mult,(gk,ge) in seen.values():
        kmpf=[fr2mpf_vec(v) for v in gk]; empf=[fr2mpf_mat(M) for M in ge]
        val,c0=c2(kmpf,empf); tot+=mult*val; ntot+=mult
        if abs(c0)>c0max: c0max=abs(c0)
    return tot/ntot, c0max, len(seen)

def recog(x):
    sc=mp.mpf(10)**40
    a=Fr(int(mp.nint(x*sc)),int(sc)).limit_denominator(10**9)
    return str(a) if abs(mp.mpf(a.numerator)/a.denominator-x)<mp.mpf(10)**(-15) else None

def sample_configs(n,seed):
    rng=np.random.default_rng(seed); out=[]; t=0
    while len(out)<n and t<n*40:
        t+=1; k1=rng.integers(-1,2,4); k2=rng.integers(-1,2,4); k3=-k1-k2
        if np.max(np.abs(k3))>1: continue
        if not (np.any(k1) and np.any(k2) and np.any(k3)): continue
        out.append((k1,k2,k3))
    return out

def main():
    t0=time.time(); G=aut_d4(GROUP_MODE); cfgs=sample_configs(NCFG,SEED)
    print(f"# D4 cubic vertex -- EXACT Aut(D4) average | DPS={DPS} RLEV={RLEV}")
    print(f"# group={GROUP_MODE} |G|={len(G)}  NCFG={NCFG}  bases={BASE_SEEDS}")
    per_base=[]; c0max=mp.mpf(0)
    for b,seed in enumerate(BASE_SEEDS):
        st=build_star(seed); c2=make_engine(st); vals=[]
        for i,cfg in enumerate(cfgs):
            v,c0,norb=group_average(c2,cfg,G); vals.append(v)
            if c0>c0max: c0max=c0
            if (i+1)%5==0 or i==NCFG-1:
                print(f"  base{b} cfg{i:2d}: c2={mp.nstr(v,12)} orbit={norb} t={time.time()-t0:.0f}s",flush=True)
        per_base.append(vals)
    # self-checks
    st0=build_star(BASE_SEEDS[0]); c20=make_engine(st0)
    k1,k2,k3=cfgs[0]
    pv,_,_=group_average(c20,(R_CHECK@k1,R_CHECK@k2,R_CHECK@k3),G)
    Hm=np.array(aut_d4('preview')[0])  # an H-containing element for triality probe
    pair_gap=abs(per_base[0][0]-pv); pair_ok=pair_gap<mp.mpf('1e-10')
    flat_ok=c0max<mp.mpf('1e-12')
    print("\n# ---- self-checks ----")
    print(f"# flatness max|O(k^0)| = {mp.nstr(c0max,3)}  {'PASS' if flat_ok else 'FAIL'}")
    print(f"# lattice-symmetry pair |c2(cfg0)-c2(R.cfg0)| = {mp.nstr(pair_gap,3)}  {'PASS' if pair_ok else 'FAIL'}")
    status='PASS' if (flat_ok and pair_ok) else 'REVIEW'
    rows=[]
    for i,(a,bb,cc) in enumerate(cfgs):
        bvals=[per_base[b][i] for b in range(len(BASE_SEEDS))]; mean=sum(bvals)/len(bvals)
        spread=max(abs(v-mean) for v in bvals) if len(bvals)>1 else mp.mpf(0)
        rows.append({"k1":[int(x) for x in a],"k2":[int(x) for x in bb],"k3":[int(x) for x in cc],
                     "c2_sym":mp.nstr(mean,40),"c2_sym_rational":recog(mean),
                     "base_spread":mp.nstr(spread,6),"invariants":invariants(a,bb,cc)})
    out=dict(method="exact_full_autD4_average",
             settings=dict(dps=DPS,rlev=RLEV,group_size=len(G),group_mode=GROUP_MODE,
                           ncfg=NCFG,seed=SEED,base_seeds=BASE_SEEDS,h0=mp.nstr(H0,3)),
             selfcheck=dict(flatness_maxabs=mp.nstr(c0max,3),pair_gap=mp.nstr(pair_gap,6),
                            pair_ok=bool(pair_ok)),
             status=status,rows=rows,elapsed_seconds=time.time()-t0)
    with open("d4_cubic_vertex_autD4_data.json","w") as fh: json.dump(out,fh,indent=1)
    print(f"\n# status: {status}")
    print(f"# wrote d4_cubic_vertex_autD4_data.json ({NCFG} configs, {time.time()-t0:.0f}s)")
    print("# Compare c2_sym against the B4 run: if unchanged, the ~12% anisotropy is the")
    print("# genuine Aut(D4)-invariant value; if it shrinks, B4 carried a triality artifact.")

if __name__=="__main__":
    main()
