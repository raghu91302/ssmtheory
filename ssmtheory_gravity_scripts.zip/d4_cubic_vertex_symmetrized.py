#!/usr/bin/env python3
# =============================================================================
# D4 cubic graviton vertex -- translation-invariant and subdivision-symmetrized.
#
# WHY THIS REPLACES d4_cubic_vertex_exact.py
# ------------------------------------------
# The previous script computed the O(k^2) cubic coefficient as
#       c2 = -1/2 [ S3(w1,u2,u3) + S3(u1,w2,u3) + S3(u1,u2,w3) ],
#       w_i(e) = (eps_i:dd_e) (k_i . x_e)^2          (x_e = edge midpoint)
# i.e. it kept only the *sum of squared phases*.  Two defects were found:
#
#   (1) NOT TRANSLATION INVARIANT.  The momentum-conserving phase is
#       phi = k1.x_e + k2.x_e' + k3.x_e''  (sum k_i = 0 makes phi shift-invariant).
#       Expanding cos(phi) = 1 - 1/2 phi^2 + ... the O(k^2) piece is -1/2 phi^2,
#       and phi^2 carries CROSS terms 2(k_i.x)(k_j.x') that the old sum-of-squares
#       dropped.  Restoring them (via a linear-weighted mode y_i(e) =
#       (eps_i:dd_e)(k_i.x_e)) makes the vertex translation invariant -- one checks
#       the residual pieces cancel because sum k_i = 0 and S3[u,u,u] = 0 (flatness).
#
#   (2) SUBDIVISION DEPENDENCE.  The D4 Delaunay cells are regular 24-cells
#       (cospherical / degenerate); qhull triangulates them in an orientation-
#       dependent way that breaks the D4 point group.  The *single-triangulation*
#       cubic vertex is therefore not even point-group invariant: two kinematic
#       configs related by a lattice automorphism (e.g. a 90-deg rotation in a
#       coordinate 2-plane, a signed permutation) come out unequal, and the same
#       config evaluated under different point orderings spans an O(1) range.
#       (The quadratic/linearized term does NOT suffer this: it is protected by
#       the rank-4 bond-tensor isotropy -- the 24-cell is a spherical 4-design --
#       and is exactly triangulation independent.  Cubic order samples 6th
#       moments and is not protected.)
#
# FIX FOR (2): SYMMETRIZE OVER SUBDIVISIONS.  Averaging the translation-invariant
# vertex over many random point orderings (random subdivisions of the degenerate
# cells) projects onto the point-group-symmetric part and gives a well-defined
# value.  Configs related by a lattice automorphism then agree (verified online).
#
# WHAT REMAINS PHYSICS, NOT ARTIFACT.  Symmetrization removes the subdivision
# artifact but CANNOT remove a genuinely point-group-invariant anisotropy.  The
# 24-cell is a 5-design but NOT a 6-design, so the symmetrized O(k^2) vertex may
# still contain a hypercubic-invariant piece that no O(4)/Einstein-Hilbert tensor
# structure reproduces.  Whether it does is the open question this script is built
# to answer: it outputs symmetrized c2 + Lorentz invariants per config so the
# downstream fit can separate an isotropic (EH) part from any hypercubic remainder.
#
# SELF-CHECKS (the script refuses to certify a result that fails them):
#   * flatness: O(k^0) ~ 0 on every triangulation (uniform strain = affine = flat);
#   * raw single-triangulation spread is reported (documents the artifact);
#   * a lattice-automorphism pair (cfg vs R.cfg, R a signed permutation) must
#     agree to tolerance in the symmetrized average -- else FAIL;
#   * the running mean must converge (standard error below tol) -- else NOT_CONVERGED.
#
# Pure Python + numpy + scipy + mpmath.  No internet.  Tunables at top.
# =============================================================================
import numpy as np, itertools as it, mpmath as mp, json, sys, time
from scipy.spatial import Delaunay
from collections import defaultdict

# ----------------------------------------------------------------- tunables
DPS      = 80          # mpmath precision (digits); raise on a fast harness
H0       = mp.mpf('1e-3')
RLEV     = 4           # Richardson levels in the 3rd directional derivative
NTRI     = 64          # number of random subdivisions to average over (symmetrization)
NCFG     = 40          # kinematic configs
SEED     = 20240611    # config-selection seed (subdivision seeds are 0..NTRI-1)
CONV_TOL = mp.mpf('1e-3')   # required standard error of the mean to certify a config
PAIR_TOL = mp.mpf('5e-3')   # required |cfg - R.cfg| agreement (lattice-symmetry check)
mp.mp.dps = DPS

# a lattice automorphism of D4 used for the symmetry self-check:
# 90-degree rotation in the (3,4) coordinate plane, e3->e4, e4->-e3 (signed perm).
R_CHECK = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,-1],[0,0,1,0]], dtype=int)

# ----------------------------------------------------------------- D4 star
def build_star(perm_seed):
    pts=[v for v in it.product(range(-3,4),repeat=4)
         if sum(v)%2==0 and sum(x*x for x in v)<=8]
    pts=np.array(sorted(pts),int)
    if perm_seed is not None:
        pts=pts[np.random.default_rng(perm_seed).permutation(len(pts))]
    O=int(np.where((pts==0).all(1))[0][0])
    simp=[tuple(s) for s in Delaunay(pts.astype(float),qhull_options='Qt').simplices]
    star=[s for s in simp if O in s]
    hinges=sorted({tuple(sorted(t)) for s in star
                   for t in it.combinations(s,3) if O in t})
    around=defaultdict(list)
    for s in simp:
        for t in it.combinations(sorted(s),3):
            if O in t: around[t].append(s)
    fk=lambda a,b:(min(a,b),max(a,b))
    edges=sorted({fk(a,b) for s in star for a,b in it.combinations(s,2)})
    L0={e:mp.mpf(int((pts[e[0]]-pts[e[1]])@(pts[e[0]]-pts[e[1]]))) for e in edges}
    return dict(pts=pts,O=O,hinges=hinges,around=around,fk=fk,edges=edges,L0=L0)

# ----------------------------------------------------------------- Regge action
def make_action(st):
    fk,edges,L0,hinges,around,pts=st['fk'],st['edges'],st['L0'],st['hinges'],st['around'],st['pts']
    def dih(Ld,loc):
        Lm={(i,j):Ld[fk(loc[i],loc[j])] for i in range(5) for j in range(i+1,5)}
        xx=lambda i,j:(Lm[(0,i)] if i==j
                       else (Lm[(0,min(i,j))]+Lm[(0,max(i,j))]-Lm[(min(i,j),max(i,j))])/2)
        det=xx(1,1)*xx(2,2)-xx(1,2)**2
        def perp(a,b):
            ua,va=xx(1,a),xx(2,a); ub,vb=xx(1,b),xx(2,b)
            return xx(a,b)-((xx(2,2)*ua-xx(1,2)*va)*ub+(-xx(1,2)*ua+xx(1,1)*va)*vb)/det
        c=perp(3,4)/mp.sqrt(perp(3,3)*perp(4,4))
        c=mp.mpf(1) if c>1 else (mp.mpf(-1) if c<-1 else c)
        return mp.acos(c)
    def heron(a,b,c):
        H=2*a*b+2*b*c+2*c*a-a*a-b*b-c*c; return mp.sqrt(H)/4
    def action(Ld):
        S=mp.mpf(0)
        for h in hinges:
            i,j,k=h; d=2*mp.pi
            for s in around[h]:
                d-=dih(Ld,list(h)+[v for v in s if v not in h])
            S+=heron(Ld[fk(i,j)],Ld[fk(i,k)],Ld[fk(j,k)])*d
        return S
    def S3(v1,v2,v3):
        def mx(v):
            m=mp.mpf(0)
            for x in v.values():
                if abs(x)>m: m=abs(x)
            return m if m>0 else mp.mpf(1)
        s=[mx(v1),mx(v2),mx(v3)]
        n=[{e:v.get(e,mp.mpf(0))/si for e in edges} for v,si in zip((v1,v2,v3),s)]
        def D(step):
            tot=mp.mpf(0)
            for sg in it.product([1,-1],repeat=3):
                Ld={e:L0[e]+step*(sg[0]*n[0][e]+sg[1]*n[1][e]+sg[2]*n[2][e]) for e in edges}
                tot+=sg[0]*sg[1]*sg[2]*action(Ld)
            return tot/(2*step)**3
        Dk=[D(H0/2**k) for k in range(RLEV)]
        for m in range(1,RLEV):
            f=mp.mpf(4**m); Dk=[(f*Dk[i+1]-Dk[i])/(f-1) for i in range(len(Dk)-1)]
        return mp.re(Dk[0])*s[0]*s[1]*s[2]
    return S3

# ----------------------------------------------------------------- TT kinematics
def perp_int(k):
    for e in np.eye(4,dtype=int):
        w=e*int(k@k)-k*int(e@k)
        if np.any(w): return w
    return None
def TT(k):
    a=perp_int(k); b=None
    for e in np.eye(4,dtype=int):
        cand=e*int(k@k)-k*int(e@k); cand=cand*int(a@a)-a*int(a@cand)
        if np.any(cand): b=cand; break
    g=np.gcd.reduce(np.abs(b)) if np.any(b) else 1
    if g: b=b//g
    return np.outer(a,b)+np.outer(b,a)

def modes(st,eps,kap):
    """u (uniform strain), y (linear phase), w (quadratic phase) edge modes."""
    pts,edges=st['pts'],st['edges']
    u={}; y={}; w={}
    for e in edges:
        Dv=pts[e[1]]-pts[e[0]]; p=mp.mpf(int(Dv@eps@Dv))
        ph=mp.mpf(int(kap@(pts[e[0]]+pts[e[1]])))/2     # k . midpoint
        u[e]=p; y[e]=p*ph; w[e]=p*ph*ph
    return u,y,w

def c2_single(st,S3,k1,k2,k3):
    """Translation-invariant O(k^2) cubic coefficient on ONE triangulation:
       c2 = -1/2 [ sum_i S3(w_i,u_j,u_l) + 2 sum_{i<j} S3(y_i,y_j,u_l) ]."""
    e1,e2,e3=TT(k1),TT(k2),TT(k3)
    u1,y1,w1=modes(st,e1,k1); u2,y2,w2=modes(st,e2,k2); u3,y3,w3=modes(st,e3,k3)
    sq   = S3(w1,u2,u3)+S3(u1,w2,u3)+S3(u1,u2,w3)
    cross= 2*(S3(y1,y2,u3)+S3(u1,y2,y3)+S3(y1,u2,y3))
    c0   = S3(u1,u2,u3)                              # must be ~0 (flatness)
    return mp.mpf('-0.5')*(sq+cross), c0

def invariants(k1,k2,k3):
    e1,e2,e3=TT(k1),TT(k2),TT(k3)
    return [int(np.tensordot(e1,e2)),int(np.tensordot(e2,e3)),int(np.tensordot(e3,e1)),
            int(k2@e1@k2),int(k3@e2@k3),int(k1@e3@k1),
            int(k1@k2),int(k2@k3),int(k3@k1)]

# ----------------------------------------------------------------- config sampling
def sample_configs(n,seed):
    rng=np.random.default_rng(seed); out=[]; tries=0
    while len(out)<n and tries<n*40:
        tries+=1
        k1=rng.integers(-1,2,4); k2=rng.integers(-1,2,4); k3=-k1-k2
        if np.max(np.abs(k3))>1: continue
        if not (np.any(k1) and np.any(k2) and np.any(k3)): continue
        out.append((k1,k2,k3))
    return out

# ----------------------------------------------------------------- main
def main():
    t0=time.time()
    print(f"# D4 cubic graviton vertex (translation-invariant, subdivision-symmetrized)")
    print(f"# DPS={DPS} RLEV={RLEV} NTRI={NTRI} NCFG={NCFG}")
    cfgs=sample_configs(NCFG,SEED)
    # append the lattice-automorphism partner of cfg 0 as a dedicated symmetry probe
    k1,k2,k3=cfgs[0]
    probe=(R_CHECK@k1, R_CHECK@k2, R_CHECK@k3)

    # running accumulators (Welford) over triangulations
    nseen=0
    mean=[mp.mpf(0)]*NCFG; M2=[mp.mpf(0)]*NCFG
    pmean=mp.mpf(0); pM2=mp.mpf(0)             # probe accumulator
    raw0=[]                                     # raw cfg0 values (spread diagnostic)
    maxc0=mp.mpf(0)

    for s in range(NTRI):
        st=build_star(s); S3=make_action(st)
        for i,(a,b,c) in enumerate(cfgs):
            val,c0=c2_single(st,S3,a,b,c)
            if abs(c0)>maxc0: maxc0=abs(c0)
            n_i=nseen+1
            d=val-mean[i]; mean[i]=mean[i]+d/n_i; M2[i]=M2[i]+d*(val-mean[i])
            if i==0: raw0.append(val)
        pv,_=c2_single(st,S3,*probe)
        d=pv-pmean; pmean=pmean+d/(nseen+1); pM2=pM2+d*(pv-pmean)
        nseen+=1
        if (s+1)%8==0 or s==NTRI-1:
            se0=mp.sqrt(M2[0]/nseen/max(nseen-1,1))
            print(f"  [{nseen:3d} subdiv] <cfg0>={mp.nstr(mean[0],8)} +/- {mp.nstr(se0,3)}"
                  f"   <probe>={mp.nstr(pmean,8)}   elapsed {time.time()-t0:.0f}s",flush=True)

    # ---- self-checks ----
    def stderr(M2v): return mp.sqrt(M2v/nseen/max(nseen-1,1))
    se=[stderr(M2[i]) for i in range(NCFG)]
    pse=stderr(pM2)
    flat_ok = maxc0 < mp.mpf('1e-12')
    pair_gap= abs(mean[0]-pmean)
    pair_ok = pair_gap < PAIR_TOL + 2*(se[0]+pse)    # agree within tol + sampling error
    conv_ok = all(se[i] < CONV_TOL for i in range(NCFG))

    print("\n# ---- self-checks ----")
    print(f"# flatness  max|O(k^0)| = {mp.nstr(maxc0,3)}   {'PASS' if flat_ok else 'FAIL'}")
    print(f"# raw cfg0 single-subdivision spread: [{mp.nstr(min(raw0),6)}, {mp.nstr(max(raw0),6)}]"
          f"  (range {mp.nstr(max(raw0)-min(raw0),4)}) -- documents the artifact")
    print(f"# lattice-symmetry pair  |<cfg0> - <R.cfg0>| = {mp.nstr(pair_gap,3)}"
          f"   {'PASS' if pair_ok else 'FAIL'}")
    print(f"# convergence  max stderr = {mp.nstr(max(se),3)}"
          f"   {'PASS' if conv_ok else 'NOT_CONVERGED (raise NTRI/DPS/RLEV)'}")

    status = 'PASS' if (flat_ok and pair_ok and conv_ok) else 'REVIEW'
    rows=[]
    for i,(a,b,c) in enumerate(cfgs):
        rows.append({"k1":[int(x) for x in a],"k2":[int(x) for x in b],"k3":[int(x) for x in c],
                     "c2_mean":mp.nstr(mean[i],30),"c2_stderr":mp.nstr(se[i],8),
                     "invariants":invariants(a,b,c)})
    out=dict(method="translation_invariant_subdivision_symmetrized",
             settings=dict(dps=DPS,rlev=RLEV,ntri=NTRI,ncfg=NCFG,seed=SEED,h0=mp.nstr(H0,3)),
             selfcheck=dict(flatness_maxabs=mp.nstr(maxc0,3),
                            raw_cfg0_min=mp.nstr(min(raw0),8),raw_cfg0_max=mp.nstr(max(raw0),8),
                            pair_gap=mp.nstr(pair_gap,8),pair_ok=bool(pair_ok),
                            max_stderr=mp.nstr(max(se),8),converged=bool(conv_ok)),
             status=status, rows=rows, elapsed_seconds=time.time()-t0)
    with open("d4_cubic_vertex_symmetrized_data.json","w") as fh:
        json.dump(out,fh,indent=1)
    print(f"\n# status: {status}")
    print(f"# wrote d4_cubic_vertex_symmetrized_data.json ({NCFG} configs, {time.time()-t0:.0f}s)")
    print("# Each c2_mean is the subdivision-symmetrized, translation-invariant O(k^2)")
    print("# coefficient.  Send the JSON back: the downstream fit decomposes c2 into an")
    print("# O(4)-invariant (Einstein-Hilbert) part and any hypercubic-anisotropic remainder.")

if __name__=="__main__":
    main()
