#!/usr/bin/env python3
# =============================================================================
# d4_cubic_anisotropy_analysis.py
#
# Reproduces the analysis behind "Emergent Gravity from the Intrinsic D4 Lattice II".
# Given the exact Aut(D4)-averaged cubic-vertex data (d4_cubic_vertex_autD4_data.json),
# this script:
#   (1) reconstructs the transverse-traceless polarizations and checks them against
#       the invariants stored in the data;
#   (2) builds the COMPLETE basis of O(4)-invariant two-derivative cubic structures
#       and verifies its dimension is 9 on generic continuum kinematics;
#   (3) performs the EXACT (rational) rank test showing c2_sym lies outside that
#       space  -> the vertex is not Einstein-Hilbert;
#   (4) quantifies the fractional anisotropy and compares B4 vs Aut(D4);
#   (5) splits the anisotropy into off-shell (field-redefinition-removable) and
#       irreducible on-shell parts;
#   (6) computes the spherical-design ladder of the 24-cell (the origin of the effect).
#
# Inputs (same directory):
#   d4_cubic_vertex_autD4_data.json     (full Aut(D4), 1152)
#   d4_cubic_vertex_groupavg_data.json  (B4, 384; optional, for the comparison)
# =============================================================================
import json, numpy as np, itertools as it
from fractions import Fraction as Fr

# ----------------------------------------------------------------- TT polarizations
def perp_int(k):
    for e in np.eye(4, dtype=int):
        w = e*int(k@k) - k*int(e@k)
        if np.any(w): return w
def TT(k):
    a = perp_int(k); b = None
    for e in np.eye(4, dtype=int):
        cand = e*int(k@k) - k*int(e@k); cand = cand*int(a@a) - a*int(a@cand)
        if np.any(cand): b = cand; break
    g = np.gcd.reduce(np.abs(b)) if np.any(b) else 1
    if g: b = b//g
    return np.outer(a, b) + np.outer(b, a)

# ----------------------------------------------------------------- O(4) structure basis
def O4_structures(k, e, F=float):
    """Complete set of O(4)-invariant trilinear-eps bilinear-k scalars:
       (i) (eps_i:eps_j)(k_a.eps_l.k_b)   (ii) k_a.(eps_i eps_j eps_l).k_b
       (iii) tr(eps1 eps2 eps3)(k_a.k_b).  Spans a 9-dim space on continuum kinematics."""
    K, E, v = k, e, []
    tr = lambda A, B: F(int(np.tensordot(A, B))) if F is Fr else float(np.tensordot(A, B))
    sc = (lambda x: F(int(round(x))) if F is Fr else float(x))
    for l in range(3):
        i, j = [m for m in range(3) if m != l]
        for a in range(3):
            for b in range(3):
                v.append(tr(E[i], E[j]) * (F(int(K[a]@E[l]@K[b])) if F is Fr else float(K[a]@E[l]@K[b])))
    for perm in it.permutations((0, 1, 2)):
        M = E[perm[0]]@E[perm[1]]@E[perm[2]]
        for a in range(3):
            for b in range(3):
                v.append(F(int(K[a]@M@K[b])) if F is Fr else float(K[a]@M@K[b]))
    for perm in [(0, 1, 2), (0, 2, 1)]:
        t3 = int(np.tensordot(E[perm[0]]@E[perm[1]], E[perm[2]]))
        for a in range(3):
            for b in range(a, 3):
                v.append((F(t3)*F(int(K[a]@K[b]))) if F is Fr else float(t3)*float(K[a]@K[b]))
    return v

def hyperc_onshell(k, e):
    """Hypercubic (B4-invariant, non-O(4)) structures with momentum-polarization
       contractions: survive on shell."""
    K, E = k, e; D = lambda A: np.array([A[m, m] for m in range(4)])
    d = [D(E[0]), D(E[1]), D(E[2])]; v = []
    for l in range(3):
        i, j = [m for m in range(3) if m != l]
        for a in range(3):
            for b in range(3): v.append(float(sum(d[i]*d[j]*(E[l]@K[a])*K[b])))
    for i in range(3):
        j, l = [m for m in range(3) if m != i]
        for a in range(3):
            for b in range(3): v.append(float(sum(d[i]*(E[j]@K[a])*(E[l]@K[b]))))
    for i in range(3):
        for j in range(3):
            if i == j: continue
            l = [m for m in range(3) if m != i and m != j][0]
            for a in range(3):
                for b in range(3): v.append(float(sum(D(E[i]@E[j])*(E[l]@K[a])*K[b])))
    return v

def hyperc_offshell(k, e):
    """Hypercubic structures carrying a bare k_a.k_b factor: vanish on shell
       (field-redefinition / off-shell removable)."""
    K, E = k, e; D = lambda A: np.array([A[m, m] for m in range(4)])
    d = [D(E[0]), D(E[1]), D(E[2])]
    h0 = [float(sum(d[0]*d[1]*d[2])),
          float(sum(d[0]*D(E[1]@E[2]))), float(sum(d[1]*D(E[2]@E[0]))), float(sum(d[2]*D(E[0]@E[1]))),
          float(sum(D(E[0]@E[1]@E[2])))]
    v = []
    for a in range(3):
        for b in range(a, 3):
            kk = float(K[a]@K[b])
            for h in h0: v.append(kk*h)
    return v

# ----------------------------------------------------------------- exact rank
def rref_rank(A):
    A = [row[:] for row in A]; R = len(A)
    if R == 0: return 0
    C = len(A[0]); r = 0
    for c in range(C):
        pr = next((rr for rr in range(r, R) if A[rr][c] != 0), None)
        if pr is None: continue
        A[r], A[pr] = A[pr], A[r]; inv = A[r][c]; A[r] = [x/inv for x in A[r]]
        for rr in range(R):
            if rr != r and A[rr][c] != 0:
                f = A[rr][c]; A[rr] = [a - f*b for a, b in zip(A[rr], A[r])]
        r += 1
        if r == R: break
    return r

# ----------------------------------------------------------------- design ladder
def design_ladder(degrees=(2, 4, 6, 8, 10, 12), trials=4000, seed=0):
    mins = []
    for i, j in it.combinations(range(4), 2):
        for si in (1, -1):
            for sj in (1, -1):
                v = [0, 0, 0, 0]; v[i] = si; v[j] = sj; mins.append(v)
    mins = np.array(mins, float); rng = np.random.default_rng(seed); out = {}
    for d in degrees:
        vals = [np.sum((mins@(u/np.linalg.norm(u)))**d)
                for u in rng.standard_normal((trials, 4))]
        vals = np.array(vals); out[d] = abs(vals.std()/vals.mean())
    return out

# ----------------------------------------------------------------- main
def load(path):
    rows = json.load(open(path))['rows']
    cfgs = [[np.array(r[x]) for x in ('k1', 'k2', 'k3')] for r in rows]
    es = [[TT(k[0]), TT(k[1]), TT(k[2])] for k in cfgs]
    y = np.array([float(Fr(r['c2_sym_rational'])) for r in rows])
    return rows, cfgs, es, y

def analyze(path, label):
    rows, cfgs, es, y = load(path)
    # check TT reconstruction vs stored invariants
    ok = True
    for r, k, e in zip(rows, cfgs, es):
        inv = [int(np.tensordot(e[0], e[1])), int(np.tensordot(e[1], e[2])), int(np.tensordot(e[2], e[0])),
               int(k[1]@e[0]@k[1]), int(k[2]@e[1]@k[2]), int(k[0]@e[2]@k[0]),
               int(k[0]@k[1]), int(k[1]@k[2]), int(k[2]@k[0])]
        if inv != r['invariants']: ok = False
    Mf = np.array([O4_structures(cfgs[i], es[i], float) for i in range(len(rows))])
    coef, *_ = np.linalg.lstsq(Mf, y, rcond=None); resid = y - Mf@coef
    frac = np.linalg.norm(resid)/np.linalg.norm(y)
    # exact rank test
    Me = [O4_structures(cfgs[i], es[i], Fr) for i in range(len(rows))]
    ye = [Fr(rows[i]['c2_sym_rational']) for i in range(len(rows))]
    rO = rref_rank([row[:] for row in Me])
    rOy = rref_rank([Me[i] + [ye[i]] for i in range(len(Me))])
    print(f"[{label}]  TT_invariants_match={ok}  |G| from data: {json.load(open(path))['settings']['group_size']}")
    print(f"    exact rank: rank(O4)={rO}  rank([O4|c2])={rOy}  -> "
          f"{'NOT Einstein-Hilbert' if rOy > rO else 'consistent with O(4)'}")
    print(f"    fractional anisotropy = {frac:.4f}")
    # on-shell / off-shell split
    MS = np.array([hyperc_onshell(cfgs[i], es[i]) for i in range(len(rows))])
    ME = np.array([hyperc_offshell(cfgs[i], es[i]) for i in range(len(rows))])
    res = lambda A: np.linalg.norm(y - A@np.linalg.lstsq(A, y, rcond=None)[0])
    r0, rE, rB = res(Mf), res(np.hstack([Mf, ME])), res(np.hstack([Mf, MS, ME]))
    print(f"    O(4)+offshell residual: {rE:.3f} (off-shell removes {1-rE/r0:.0%}); "
          f"full hypercubic residual: {rB:.2e}")
    print(f"    => irreducible ON-SHELL (physical) fraction ~ {rE/r0:.0%}")
    return frac

if __name__ == "__main__":
    print("="*70)
    print("O(4)-invariant structure-space dimension on continuum kinematics:")
    rng = np.random.default_rng(1); rows = []
    for _ in range(60):
        k1 = rng.standard_normal(4); k2 = rng.standard_normal(4); k3 = -k1-k2
        def rTT(k):
            A = rng.standard_normal((4, 4)); A = (A+A.T)/2
            P = np.eye(4)-np.outer(k, k)/(k@k); A = P@A@P; A = A-np.trace(A)/np.trace(P)*P
            return P@A@P
        rows.append(O4_structures([k1, k2, k3], [rTT(k1), rTT(k2), rTT(k3)], float))
    sv = np.linalg.svd(np.array(rows), compute_uv=False)
    print(f"    numerical rank = {(sv > 1e-9*sv[0]).sum()}  (basis complete iff 9)")
    print("="*70)
    try:
        fa = analyze("d4_cubic_vertex_autD4_data.json", "Aut(D4) 1152")
    except FileNotFoundError:
        print("  (place d4_cubic_vertex_autD4_data.json here to run the Aut(D4) analysis)")
    try:
        fb = analyze("d4_cubic_vertex_groupavg_data.json", "B4 384")
    except FileNotFoundError:
        pass
    print("="*70)
    print("Spherical-design ladder of the 24-cell (relative moment anisotropy):")
    for d, a in design_ladder().items():
        tag = "isotropic (design holds)" if a < 1e-9 else "ANISOTROPIC"
        print(f"    degree {d:2d}: {a:.3e}   {tag}")
    print("    => 24-cell is a 5-design but not a 6-design; degree-4 (linear) exact,")
    print("       degree-6 (cubic vertex) anisotropic.")
