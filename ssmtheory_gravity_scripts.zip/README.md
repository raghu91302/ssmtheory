# Reproducibility scripts — *Emergent Gravity from the Intrinsic D₄ Lattice*

R. Kulkarni, SSMTheory Group, IDrive Inc.

This archive contains all code and data needed to reproduce every quantitative
result in the paper *Emergent Gravity from the Intrinsic D₄ Lattice: Exact
Linearized Einstein Gravity, and its Spherical-Design Obstruction at the Cubic
Graviton Vertex.* The two halves of the paper (the exact linearized theory and
the cubic-vertex obstruction) are reproduced by the two groups of scripts below.

## Dependencies

```
python >= 3.10
numpy, scipy, sympy      # linear-theory verifier (exact symbolic + numeric)
mpmath                   # cubic vertex, 80-digit arithmetic
matplotlib               # figures
```

Install: `pip install numpy scipy sympy mpmath matplotlib`

---

## Linearized theory (Sections 2–7, Appendix A)

### `linearized_gravity_verify.py`
Self-contained verifier for the entire linear half. Runs in a few seconds.
Reproduces: rank-four isotropy of the D₄ bond tensor; the vanishing of
R[∂u] for a pure displacement field; the transverse-traceless mode curvature;
the Schläfli identities and the embedded-vs-intrinsic deficit; the explicit
D₄ Regge → Fierz–Pauli computation (flat background, deficit-map kernel = the
four diffeomorphisms, isotropy of the kinetic coefficient, two-derivative
scaling, spin-2 polarization content); the **exact symbolic proof** that the
linearized Regge kinetic operator equals the linearized Einstein operator
(1100 rational Hessian entries; C(k,ε)+q_FP(k,ε) expands to zero identically);
the induced Newton constant; and the self-bound-vacuum cancellation.

```
python3 linearized_gravity_verify.py
```

---

## Cubic vertex and obstruction (Sections 8–13, Appendices B–C)

### `d4_cubic_vertex_autD4.py`
Computes the cubic (three-graviton) two-derivative vertex on the 169-point D₄
origin star (100 simplices, 125 hinges) and averages it over the automorphism
group. Third directional derivative via an 8-point sign-symmetric stencil with
four levels of Richardson extrapolation at 80-digit precision; the group average
is performed in exact rational arithmetic, orbit-deduplicated. Writes
`d4_cubic_vertex_autD4_data.json`.

Modes (set in the script / argument):
- `preview` — small subgroup, fast plumbing test;
- `b4`      — signed-permutation subgroup, |G| = 384  → 12.0% anisotropy;
- `full`    — full Aut(D₄) = W(F₄), |G| = 1152        → 12.7% anisotropy.

```
python3 d4_cubic_vertex_autD4.py          # full run (slow: 80-digit over 1152 elements)
```

### `d4_cubic_vertex_groupavg.py`
The B₄ signed-permutation average in isolation (the 12.0% figure) and the
group-averaging machinery used as a cross-check of the full run.

### `d4_cubic_vertex_symmetrized.py`
Random-subdivision Monte Carlo cross-check: confirms the anisotropy is
independent of the Delaunay subdivision choice once the group average is taken.

### `d4_cubic_anisotropy_analysis.py`
Consumes `d4_cubic_vertex_autD4_data.json` and performs: enumeration of the
complete nine-dimensional O(4)-invariant two-derivative structure basis; the
**exact rational rank test** rank(M)=9 < 10 = rank([M | c₂ˢʸᵐ]) over the 40
kinematic configurations (no floating-point tolerance); the anisotropy
decomposition; the on-shell projection (≈56%); and the spherical-design ladder.

```
python3 d4_cubic_anisotropy_analysis.py
```

### `d4_cubic_makefigs.py`
Generates `fig1_design_ladder.pdf` (the spherical-design ladder of the 24-cell)
and `fig2_anisotropy.pdf` (vertex vs. Einstein–Hilbert scatter; B₄→Aut(D₄)
stability bar chart).

```
python3 d4_cubic_makefigs.py
```

### `d4_cubic_vertex_autD4_data.json`
The numerical output of the full 1152-element automorphism-group average, included
so the analysis and figure scripts can be run without repeating the slow vertex
computation.

---

## Reproduction at a glance

| Result | Script |
|---|---|
| Exact linearized Einstein = Regge operator identity | `linearized_gravity_verify.py` |
| Induced G, self-bound vacuum | `linearized_gravity_verify.py` |
| Cubic vertex, exact Aut(D₄) average (12.7%) | `d4_cubic_vertex_autD4.py` |
| B₄ subgroup average (12.0%), stability | `d4_cubic_vertex_groupavg.py` |
| Subdivision-independence cross-check | `d4_cubic_vertex_symmetrized.py` |
| Rank test 9<10, on-shell fraction, design ladder | `d4_cubic_anisotropy_analysis.py` |
| Figures | `d4_cubic_makefigs.py` |
