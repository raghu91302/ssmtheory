#!/usr/bin/env python3
"""Main result: the cubic graviton vertex on the closed periodic D4 complex
equals the continuum Einstein-Hilbert cubic vertex, per lattice site.

Reproduces Section 6 of the paper: the double-precision comparison over forty
kinematic configurations, independence of the 16-cell spine assignment, and the
L = 6 convergence check.  The exact-arithmetic version of the same statement is
emergent_exact_vertex.py.

    python3 emergent_cubic_vertex.py
"""
import numpy as np, time
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine
from emergent_star import sample_configs, TT
from emergent_eh_vertex import eh_on_configs

TRI_SLOTS = [4, 1, 0]


def make_c2(pe):
    """Cubic vertex through the factorized third variation, Eq. (6)."""
    def c2(cfg):
        k = [np.array(x, float) for x in cfg]
        e = [TT(np.array(x)).astype(float) for x in cfg]
        ps, phs = [], []
        for i in range(3):
            p, ph = pe.mode_vals(e[i], k[i])
            ps.append(p); phs.append(ph)
        P, ts = pe.pair, TRI_SLOTS
        d2A, dA = pe.d2A[pe.owner], pe.dA[pe.owner]

        def S3(pw, cidx=0):
            V = [ps[i][P] * (phs[i] ** pw[i] if pw[i] else 1.0) for i in range(3)]
            a, b = [t for t in range(3) if t != cidx]
            va, vb, vc = V[a], V[b], V[cidx]
            return float((
                np.einsum('pij,pi,pj->p', d2A, va[:, ts], vc[:, ts])
                * (-np.einsum('pi,pi->p', pe.dth, vb))
                + np.einsum('pij,pi,pj->p', d2A, vb[:, ts], vc[:, ts])
                * (-np.einsum('pi,pi->p', pe.dth, va))
                + np.einsum('pi,pi->p', dA, vc[:, ts])
                * (-np.einsum('pij,pi,pj->p', pe.d2th, va, vb))).sum())
        return -0.5 * (S3((2, 0, 0)) + S3((0, 2, 0)) + S3((0, 0, 2))
                       + 2 * (S3((1, 1, 0)) + S3((0, 1, 1)) + S3((1, 0, 1))))
    return c2


if __name__ == "__main__":
    cfgs = sample_configs()
    vEH = eh_on_configs(cfgs, TT)
    t = time.time()
    cx = PeriodicD4(L=4, spine='axis0')
    pe = PeriodicEngine(cx).build_derivs()
    c2 = make_c2(pe)
    y = np.array([c2(c) / cx.nv for c in cfgs])
    print("L = 4, canonical complex: %d vertices, %d simplices, %d hinges (%.0fs)"
          % (cx.nv, len(cx.simp), cx.nh, time.time() - t))
    print("  max |c2/Nv - V_EH| = %.2e" % np.abs(y - vEH).max())
    print("  correlation        = %.10f" % float(np.corrcoef(y, vEH)[0, 1]))
    print()
    print("subdivision independence (16-cell spine assignment):")
    print("   spine      cfg0        cfg2        cfg6")
    for sp in ['axis0', 'axis1', 'axis2', 'axis3', 'random']:
        c = PeriodicD4(L=4, spine=sp, seed=7)
        p = PeriodicEngine(c).build_derivs()
        f = make_c2(p)
        v = [f(cfgs[i]) / c.nv for i in (0, 2, 6)]
        print("   %-9s %10.5f %11.5f %11.5f" % (sp, v[0], v[1], v[2]), flush=True)
    print("   %-9s %10.5f %11.5f %11.5f" % ("V_EH", vEH[0], vEH[2], vEH[6]))
    print()
    t = time.time()
    c6 = PeriodicD4(L=6, spine='axis0')
    p6 = PeriodicEngine(c6).build_derivs()
    f6 = make_c2(p6)
    print("L = 6 convergence check: %d vertices, %d simplices (%.0fs)"
          % (c6.nv, len(c6.simp), time.time() - t))
    for i in (0, 2, 6):
        print("   cfg%-2d  c2/Nv = %12.6f   V_EH = %8.1f" % (i, f6(cfgs[i]) / c6.nv, vEH[i]))
