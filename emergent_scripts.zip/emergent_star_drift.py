#!/usr/bin/env python3
"""Section 3: the open vertex star and its extensive drift.

Extracted from an open origin star, the Aut(D4)-averaged cubic vertex is not
well defined: it drifts linearly with the star's hinge count N_h, by amounts
comparable to the vertex itself, and the residue passes flatness, lattice-symmetry
and rationality checks unscathed.  This script reproduces the drift law and the
out-of-sample prediction.

    python3 emergent_star_drift.py            # linear-law scan (a few minutes)
    python3 emergent_star_drift.py full       # all 40 configs on two subdivisions
"""
import numpy as np, json, sys, time
from emergent_star import (build_star, Engine, aut_d4, sample_configs,
                           group_average, TT)

H0, RLEV = 0.02, 2


def scan(seeds=(2, None, 0, 5, 6), which=(0, 2, 6)):
    G = aut_d4('full')
    cfgs = sample_configs()
    rows = {}
    for s in seeds:
        st = build_star(s)
        eng = Engine(st)
        vals = [group_average(eng, cfgs[i], G, H0, RLEV)[0] for i in which]
        rows[eng.nh] = vals
        print("  seed %-5s N_h=%3d  %s" % (str(s), eng.nh,
              "  ".join("%11.5f" % v for v in vals)), flush=True)
    return rows


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "full":
        G = aut_d4('full')
        cfgs = sample_configs()
        for seed, name in ((0, "emergent_star_base0.json"),
                           (2, "emergent_star_base2.json")):
            eng = Engine(build_star(seed))
            out = {}
            t = time.time()
            for i in range(40):
                out[str(i)] = group_average(eng, cfgs[i], G, H0, RLEV)[0]
                json.dump(out, open(name, "w"))
                print("   %s cfg%2d  (%.0fs)" % (name, i, time.time() - t), flush=True)
        sys.exit()

    print("Aut(D4)-averaged vertex on open stars of different hinge count:")
    rows = scan()
    H = np.array(sorted(rows), float)
    print()
    print("linear fits  c2 = a + N_h b:")
    for j, lab in enumerate(("cfg0", "cfg2", "cfg6")):
        y = np.array([rows[int(h)][j] for h in H])
        A = np.polyfit(H, y, 1)
        r = np.abs(y - np.polyval(A, H)).max()
        print("   %s:  %+.6f * N_h %+10.4f    max|resid| = %.1e   zero at N_h = %.2f"
              % (lab, A[0], A[1], r, -A[1] / A[0]))
    json.dump({str(int(h)): rows[int(h)] for h in H},
              open("emergent_figdata_star.json", "w"))
    print()
    print("out-of-sample test at N_h = 145 (not used in the fit):")
    G = aut_d4('full')
    cfgs = sample_configs()
    eng = Engine(build_star(21))
    y130 = np.array(rows[130]); y120 = np.array(rows[120])
    pred = 2.5 * y130 - 1.5 * y120
    for j, i in enumerate((0, 2, 6)):
        m = group_average(eng, cfgs[i], G, H0, RLEV)[0]
        print("   cfg%-2d measured %12.5f   predicted %12.5f   diff %.1e"
              % (i, m, pred[j], abs(m - pred[j])), flush=True)
