#!/usr/bin/env python3
"""
Exact verification of the cubic vertex on the periodic D4 complex.

All algebraic numbers entering the third variation at the flat background lie in
the real quadratic field Q(sqrt 3):

  * the dihedral cosines satisfy cos^2(theta) in {0, 1/4}, so
    1 - cos^2 in {1, 3/4} and sqrt(1-cos^2) in {1, sqrt3/2};
  * the hinge Heron discriminants are H in {12, 16}, so
    the areas sqrt(H)/4 lie in {sqrt3/2, 1}.

Derivatives of theta = arccos(c) are obtained from the chain rule
    d_i theta   = -c_i / sqrt(1-c^2)
    d_ij theta  = -c_ij / sqrt(1-c^2) - c_i c_j c / (1-c^2)^{3/2}
with c a rational function of the ten local squared edge lengths, so c_i and c_ij
are exact rationals, computed symbolically.  Areas and their first two derivatives
are analytic.  Everything is then represented as a + b sqrt3 with a, b rational,
cleared to integers, and the contraction is carried out in exact integer
arithmetic.  The sqrt3 component of the final answer must vanish identically;
that it does is itself a check.
"""
import numpy as np, itertools as it, sympy as sp
from fractions import Fraction as Fr
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine

SLOT = {}
_q = 0
for _i in range(5):
    for _j in range(_i + 1, 5):
        SLOT[(_i, _j)] = _q
        _q += 1


def cos_expr(Lsym):
    """cos(dihedral) as a rational-in-sqrt expression of the 10 local lengths."""
    L = lambda i, j: Lsym[SLOT[(min(i, j), max(i, j))]]
    xx = {}
    for i in range(1, 5):
        xx[(i, i)] = L(0, i)
    for i in range(1, 5):
        for j in range(i + 1, 5):
            v = sp.Rational(1, 2) * (L(0, i) + L(0, j) - L(i, j))
            xx[(i, j)] = v
            xx[(j, i)] = v
    det = xx[(1, 1)] * xx[(2, 2)] - xx[(1, 2)] ** 2

    def perp(a, b):
        ua, va = xx[(1, a)], xx[(2, a)]
        ub, vb = xx[(1, b)], xx[(2, b)]
        return xx[(a, b)] - ((xx[(2, 2)] * ua - xx[(1, 2)] * va) * ub
                             + (-xx[(1, 2)] * ua + xx[(1, 1)] * va) * vb) / det
    return perp(3, 4) / sp.sqrt(perp(3, 3) * perp(4, 4))


def theta_derivs(Lint):
    """Exact d(theta) and d2(theta) at an integer configuration, returned as
    (a, b) pairs meaning a + b*sqrt(3)."""
    base = [sp.Integer(int(x)) for x in Lint]
    # c and its rational derivatives, restricting to the needed variables
    def c_at(sub_idx, syms):
        Ls = list(base)
        for k, sidx in enumerate(sub_idx):
            Ls[sidx] = syms[k]
        return sp.together(cos_expr(Ls))

    c0 = sp.nsimplify(c_at([], []))
    one_m = sp.Rational(1) - c0 ** 2
    r = sp.sqrt(one_m)                       # sqrt(1-c^2)

    d1 = [None] * 10
    x = sp.Symbol('x')
    ci = []
    for i in range(10):
        e = c_at([i], [x])
        ci.append(sp.simplify(sp.diff(e, x).subs(x, base[i])))
        d1[i] = sp.nsimplify(-ci[i] / r)
    d2 = [[None] * 10 for _ in range(10)]
    y = sp.Symbol('y')
    for i in range(10):
        for j in range(i, 10):
            if i == j:
                e = c_at([i], [x])
                cij = sp.simplify(sp.diff(e, x, 2).subs(x, base[i]))
            else:
                e = c_at([i, j], [x, y])
                cij = sp.simplify(sp.diff(e, x, y).subs({x: base[i], y: base[j]}))
            v = sp.nsimplify(-cij / r - ci[i] * ci[j] * c0 / one_m ** sp.Rational(3, 2))
            d2[i][j] = v
            d2[j][i] = v
    return d1, d2


def as_q3(e):
    """Write a sympy number as (a, b) with value a + b*sqrt(3), a,b Fractions."""
    e = sp.nsimplify(sp.expand(sp.radsimp(e)))
    p = sp.Poly(sp.expand(e.rewrite(sp.sqrt)), sp.sqrt(3)) if e.has(sp.sqrt(3)) else None
    if p is None:
        return (Fr(sp.Rational(e).p, sp.Rational(e).q), Fr(0))
    co = p.all_coeffs()
    co = [sp.Rational(c) for c in co]
    if len(co) == 1:
        a, b = co[0], sp.Rational(0)
    else:
        b, a = co[0], co[1]
    return (Fr(a.p, a.q), Fr(b.p, b.q))


def area_derivs(tri):
    """A, dA (3), d2A (3x3) for a hinge with squared lengths tri, exact."""
    a, b, c = [sp.Integer(int(t)) for t in tri]
    s = sp.symbols('a b c')
    H = 2 * s[0] * s[1] + 2 * s[1] * s[2] + 2 * s[2] * s[0] \
        - s[0] ** 2 - s[1] ** 2 - s[2] ** 2
    A = sp.sqrt(H) / 4
    sub = {s[0]: a, s[1]: b, s[2]: c}
    A0 = sp.nsimplify(A.subs(sub))
    dA = [sp.nsimplify(sp.diff(A, s[i]).subs(sub)) for i in range(3)]
    d2A = [[sp.nsimplify(sp.diff(A, s[i], s[j]).subs(sub)) for j in range(3)]
           for i in range(3)]
    return A0, dA, d2A


# ---------------------------------------------------------------- driver
if __name__ == "__main__":
    import time
    from math import lcm
    from emergent_periodic_d4 import PeriodicD4
    from emergent_periodic_engine import PeriodicEngine
    t0 = time.time()
    cx = PeriodicD4(L=4, spine='axis0')
    pe = PeriodicEngine(cx)
    Lp = cx.L0[pe.pair].astype(int)
    Lt = cx.L0[pe.tri].astype(int)
    cfgs_u, cidx = np.unique(Lp, axis=0, return_inverse=True)
    tris_u, tidx = np.unique(Lt, axis=0, return_inverse=True)
    print("congruence classes: %d local configurations, %d hinge triangles"
          % (len(cfgs_u), len(tris_u)), flush=True)
    TH1, TH2, AR = {}, {}, {}
    for ci, L in enumerate(cfgs_u):
        d1, d2 = theta_derivs(L)
        TH1[ci] = [as_q3(v) for v in d1]
        TH2[ci] = [[as_q3(d2[i][j]) for j in range(10)] for i in range(10)]
        print("  class %d done (%.0fs)" % (ci, time.time() - t0), flush=True)
    for ti, T in enumerate(tris_u):
        A, dA, d2A = area_derivs(T)
        AR[ti] = ([as_q3(v) for v in dA],
                  [[as_q3(d2A[i][j]) for j in range(3)] for i in range(3)])
    den = 1
    for ci in TH1:
        for a, b in TH1[ci]:
            den = lcm(den, a.denominator, b.denominator)
        for row in TH2[ci]:
            for a, b in row:
                den = lcm(den, a.denominator, b.denominator)
    for ti in AR:
        for a, b in AR[ti][0]:
            den = lcm(den, a.denominator, b.denominator)
        for row in AR[ti][1]:
            for a, b in row:
                den = lcm(den, a.denominator, b.denominator)
    print("common denominator DEN =", den, flush=True)
    I = lambda p: (int(p[0] * den), int(p[1] * den))
    n = len(cfgs_u); m = len(tris_u)
    D1A = np.array([[I(TH1[c][i])[0] for i in range(10)] for c in range(n)], dtype=object)
    D1B = np.array([[I(TH1[c][i])[1] for i in range(10)] for c in range(n)], dtype=object)
    D2A = np.array([[[I(TH2[c][i][j])[0] for j in range(10)] for i in range(10)]
                    for c in range(n)], dtype=object)
    D2B = np.array([[[I(TH2[c][i][j])[1] for j in range(10)] for i in range(10)]
                    for c in range(n)], dtype=object)
    dAA = np.array([[I(AR[t][0][i])[0] for i in range(3)] for t in range(m)], dtype=object)
    dAB = np.array([[I(AR[t][0][i])[1] for i in range(3)] for t in range(m)], dtype=object)
    d2AA = np.array([[[I(AR[t][1][i][j])[0] for j in range(3)] for i in range(3)]
                     for t in range(m)], dtype=object)
    d2AB = np.array([[[I(AR[t][1][i][j])[1] for j in range(3)] for i in range(3)]
                     for t in range(m)], dtype=object)
    np.save("emergent_exact_tensors.npy",
            np.array([D1A, D1B, D2A, D2B, dAA, dAB, d2AA, d2AB, cidx, tidx, den],
                     dtype=object), allow_pickle=True)
    print("wrote emergent_exact_tensors.npy  (%.0fs)" % (time.time() - t0))
