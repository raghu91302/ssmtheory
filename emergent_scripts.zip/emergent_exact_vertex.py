import numpy as np, time, sys
from fractions import Fraction as Fr
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine
from emergent_star import sample_configs, TT
from emergent_eh_vertex import eh_on_configs

D1A,D1B,D2A,D2B,dAA,dAB,d2AA,d2AB,cidx,tidx,den = np.load('emergent_exact_tensors.npy',allow_pickle=True)
den=int(den)
cx=PeriodicD4(L=4,spine='axis0'); pe=PeriodicEngine(cx)
cidx=np.asarray(cidx,int); tidx=np.asarray(tidx,int)
g=lambda X,idx: np.asarray(X,dtype=np.int64)[idx]
d1a,d1b = g(D1A,cidx), g(D1B,cidx)              # (P,10)
d2a,d2b = g(D2A,cidx), g(D2B,cidx)              # (P,10,10)
tinc = tidx[pe.owner]                            # triangle class per incidence
daa,dab = g(dAA,tinc), g(dAB,tinc)              # (P,3)
d2aa,d2ab = g(d2AA,tinc), g(d2AB,tinc)          # (P,3,3)
TS=[4,1,0]

def modes_int(eps,kap):
    """u (integer), 2*phase (integer) per (incidence, slot)."""
    p=np.einsum('ei,ij,ej->e',pe.evec,eps,pe.evec)
    p=np.rint(p).astype(np.int64)
    ph2=np.rint(2.0*np.einsum('pqi,i->pq',pe.mid,kap)).astype(np.int64)
    return p,ph2

def mul(a1,b1,a2,b2):
    return a1*a2+3*b1*b2, a1*b2+a2*b1

def S3_exact(V):
    """V = list of three (P,10) integer mode arrays; slot 0 is the eliminated one."""
    va,vb,vc = V[1],V[2],V[0]
    Ta,Tb,Tc = va[:,TS],vb[:,TS],vc[:,TS]
    A2ac_a=np.einsum('pij,pi,pj->p',d2aa,Ta,Tc); A2ac_b=np.einsum('pij,pi,pj->p',d2ab,Ta,Tc)
    A2bc_a=np.einsum('pij,pi,pj->p',d2aa,Tb,Tc); A2bc_b=np.einsum('pij,pi,pj->p',d2ab,Tb,Tc)
    A1c_a =np.einsum('pi,pi->p',daa,Tc);         A1c_b =np.einsum('pi,pi->p',dab,Tc)
    db_a=-np.einsum('pi,pi->p',d1a,vb); db_b=-np.einsum('pi,pi->p',d1b,vb)
    da_a=-np.einsum('pi,pi->p',d1a,va); da_b=-np.einsum('pi,pi->p',d1b,va)
    dab_a=-np.einsum('pij,pi,pj->p',d2a,va,vb); dab_b=-np.einsum('pij,pi,pj->p',d2b,va,vb)
    ra,rb=mul(A2ac_a,A2ac_b,db_a,db_b)
    xa,xb=mul(A2bc_a,A2bc_b,da_a,da_b); ra=ra+xa; rb=rb+xb
    xa,xb=mul(A1c_a,A1c_b,dab_a,dab_b); ra=ra+xa; rb=rb+xb
    return int(ra.sum()), int(rb.sum())

def c2_exact(cfg):
    ks=[np.array(x,float) for x in cfg]; es=[TT(np.array(x)).astype(np.int64) for x in cfg]
    P=[]; PH=[]
    for i in range(3):
        p,ph2=modes_int(es[i],ks[i]); P.append(p); PH.append(ph2)
    U=[P[i][pe.pair] for i in range(3)]                  # u
    Y=[U[i]*PH[i] for i in range(3)]                     # 2*y
    W=[U[i]*PH[i]*PH[i] for i in range(3)]               # 4*w
    A=B=0
    for trip in [(W[0],U[1],U[2]),(U[0],W[1],U[2]),(U[0],U[1],W[2])]:
        a,b=S3_exact(list(trip)); A+=a; B+=b
    for trip in [(Y[0],Y[1],U[2]),(U[0],Y[1],Y[2]),(Y[0],U[1],Y[2])]:
        a,b=S3_exact(list(trip)); A+=2*a; B+=2*b
    # c2 = -1/8 * (scaled sum) / den^2
    return Fr(-A,8*den*den), Fr(-B,8*den*den)

if __name__=="__main__":
    cfgs=sample_configs(); vEH=eh_on_configs(cfgs,TT); nv=cx.nv
    which=[int(x) for x in sys.argv[1:]] or [0,2,6]
    print('EXACT cubic vertex on the canonical periodic complex (L=4, N_v=%d)'%nv)
    print(' cfg    c2/N_v (exact)      sqrt3 part        V_EH')
    for i in which:
        t=time.time(); a,b=c2_exact(cfgs[i])
        print(f'  {i:2d}   {str(a/nv):>16s}   {str(b/nv):>10s}   {vEH[i]:8.1f}   ({time.time()-t:.0f}s)',flush=True)
