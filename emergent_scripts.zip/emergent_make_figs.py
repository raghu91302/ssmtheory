#!/usr/bin/env python3
"""Figures for the D4 cubic-vertex paper."""
import json, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['DejaVu Serif'],
    'mathtext.fontset': 'dejavuserif',
    'font.size': 9,
    'axes.labelsize': 9,
    'axes.titlesize': 9.5,
    'legend.fontsize': 8,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'axes.linewidth': 0.7,
    'xtick.major.width': 0.7,
    'ytick.major.width': 0.7,
    'lines.linewidth': 1.2,
    'figure.dpi': 200,
    'savefig.dpi': 400,
    'axes.grid': True,
    'grid.alpha': 0.18,
    'grid.linewidth': 0.5,
})

C = ['#1f4e79', '#c0392b', '#1e8449', '#7d3c98', '#b9770e']

star = json.load(open('emergent_figdata_star.json'))
per = json.load(open('emergent_figdata_periodic.json'))
vEH = np.array(per['vEH'])

# ---------------------------------------------------------------- Figure 1
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.9))

Nh = np.array(sorted(int(k) for k in star))
labels = [r'$\mathcal{K}_1$', r'$\mathcal{K}_2$', r'$\mathcal{K}_3$']
ehidx = [0, 2, 6]
for j in range(3):
    y = np.array([star[str(n)][j] for n in Nh])
    p = np.polyfit(Nh, y, 1)
    xs = np.linspace(115, 155, 100)
    ax[0].plot(xs, np.polyval(p, xs), '-', color=C[j], lw=1.0, alpha=0.8)
    ax[0].plot(Nh, y, 'o', color=C[j], ms=4.2, mec='white', mew=0.6,
               label=labels[j], zorder=3)
    ax[0].plot([150], [np.polyval(p, 150)], '*', color=C[j], ms=11,
               mec='white', mew=0.6, zorder=4)
ax[0].axvline(150, color='0.35', ls=':', lw=0.9)
ax[0].annotate(r'$N_h=150$', xy=(150, ax[0].get_ylim()[0]),
               xytext=(150.8, -78), fontsize=7.5, color='0.3')
ax[0].set_xlabel(r'origin-star hinge count $N_h$')
ax[0].set_ylabel(r'$c_2^{\rm sym}$  (open star)')
ax[0].set_title('(a) open star: extensive drift')
ax[0].legend(frameon=False, loc='upper right', handletextpad=0.4)
ax[0].xaxis.set_major_locator(MaxNLocator(integer=True, nbins=6))

mk = ['o', 's', '^', 'D', 'v']
for j, sp in enumerate(['axis0', 'axis1', 'axis2', 'axis3', 'random']):
    d = np.array(per['spines'][sp]) - vEH
    ax[1].plot(np.arange(40), d, mk[j], color=C[j], ms=3.4, mec='white',
               mew=0.4, alpha=0.85, zorder=3,
               label=('random spine' if sp == 'random' else 'spine ' + sp[-1]))
ax[1].axhline(0, color='0.4', lw=0.9, zorder=1)
ax[1].set_xlabel('kinematic configuration')
ax[1].set_ylabel(r'$c_2/N_v - V_{\rm EH}$')
ax[1].set_ylim(-1.2e-4, 1.2e-4)
ax[1].set_title('(b) closed torus: subdivision independent')
ax[1].legend(frameon=False, loc='lower left', ncol=3, handletextpad=0.25,
             columnspacing=0.9, borderpad=0.2)
ax[1].ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
fig.tight_layout(pad=0.6)
fig.savefig('emergent_fig1_drift.pdf', bbox_inches='tight')
print('fig1 written')

# ---------------------------------------------------------------- Figure 2
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.9))

y = np.array(per['spines']['axis0'])
lim = [min(y.min(), vEH.min()) - 6, max(y.max(), vEH.max()) + 6]
ax[0].plot(lim, lim, '-', color='0.55', lw=0.9, zorder=1)
ax[0].plot(vEH, y, 'o', color=C[0], ms=4.6, mec='white', mew=0.6, zorder=3)
ax[0].set_xlim(lim); ax[0].set_ylim(lim)
ax[0].set_aspect('equal')
ax[0].set_xlabel(r'Einstein--Hilbert vertex $V_{\rm EH}$')
ax[0].set_ylabel(r'lattice vertex $c_2/N_v$')
ax[0].set_title('(a) 40 kinematic configurations')
ax[0].text(0.05, 0.92, r'$\max|c_2/N_v-V_{\rm EH}|=4.8\times10^{-5}$',
           transform=ax[0].transAxes, fontsize=7.5, va='top')

names = ['open star\n' + r'$N_h=130$', 'open star\n' + r'$N_h=120$',
         'periodic\ntorus']
ystar0 = np.array([json.load(open('emergent_star_base0.json'))[str(i)]
                   for i in range(40)])
ystar2 = np.array([json.load(open('emergent_star_base2.json'))[str(i)]
                   for i in range(40)])


def aniso(v):
    import itertools as it
    from emergent_star import sample_configs, TT as TTf
    cfgs = sample_configs()
    cf = [[np.array(x) for x in c] for c in cfgs]
    es = [[TTf(k[0]), TTf(k[1]), TTf(k[2])] for k in cf]

    def O4(K, E):
        out = []
        for l in range(3):
            i, j = [m for m in range(3) if m != l]
            for a in range(3):
                for b in range(3):
                    out.append(float(np.tensordot(E[i], E[j]) * (K[a] @ E[l] @ K[b])))
        for perm in it.permutations((0, 1, 2)):
            M = E[perm[0]] @ E[perm[1]] @ E[perm[2]]
            for a in range(3):
                for b in range(3):
                    out.append(float(K[a] @ M @ K[b]))
        for perm in [(0, 1, 2), (0, 2, 1)]:
            t3 = float(np.tensordot(E[perm[0]] @ E[perm[1]], E[perm[2]]))
            for a in range(3):
                for b in range(a, 3):
                    out.append(t3 * float(K[a] @ K[b]))
        return out
    M = np.array([O4(cf[i], es[i]) for i in range(40)])
    r = v - M @ np.linalg.lstsq(M, v, rcond=None)[0]
    return np.linalg.norm(r) / np.linalg.norm(v)


vals = [aniso(ystar0), aniso(ystar2), aniso(y)]
bars = ax[1].bar(range(3), vals, color=[C[1], C[1], C[2]], width=0.55,
                 edgecolor='white', lw=0.8)
ax[1].set_yscale('log')
ax[1].set_xticks(range(3))
ax[1].set_xticklabels(names)
ax[1].set_ylabel(r'anisotropy $\|c_2-\Pi_{O(4)}c_2\|/\|c_2\|$')
ax[1].set_title('(b) departure from $O(4)$ invariance')
ax[1].set_ylim(1e-8, 1)
for b, v in zip(bars, vals):
    ax[1].text(b.get_x() + b.get_width() / 2, v * 1.7,
               (r'$%.3f$' % v) if v > 1e-3 else (r'$%.0f\times10^{-7}$' % (v * 1e7)),
               ha='center', fontsize=7.5)
fig.tight_layout(pad=0.6)
fig.savefig('emergent_fig2_result.pdf', bbox_inches='tight')
print('fig2 written', vals)
