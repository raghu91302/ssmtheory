#!/usr/bin/env python3
"""The complete O(4)-invariant two-derivative structure basis, and the rank test.

Builds the three topological families of Eq. (9), verifies the span is
nine-dimensional on continuum kinematics, and applies the exact rational rank test
to (i) the continuum Einstein-Hilbert vertex, (ii) the periodic lattice vertex, and
(iii) the open-star extraction, which is the one that fails.

    python3 emergent_o4_analysis.py
"""
import numpy as np, itertools as it, json, os
from fractions import Fraction as Fr
from emergent_star import sample_configs, TT
from emergent_eh_vertex import eh_on_configs


def O4_structures(K, E, F=float):
    """(eps_i:eps_j)(k_a.eps_l.k_b);  k_a.(eps_i eps_j eps_l).k_b;
       tr(eps1 eps2 eps3)(k_a.k_b).  Spans dimension 9 on continuum kinematics."""
    cast = (lambda x: Fr(int(round(x)))) if F is Fr else float
    v = []
    for l in range(3):
        i, j = [m for m in range(3) if m != l]
        for a in range(3):
            for b in range(3):
                v.append(cast(np.tensordot(E[i], E[j]) * (K[a] @ E[l] @ K[b])))
    for perm in it.permutations((0, 1, 2)):
        M = E[perm[0]] @ E[perm[1]] @ E[perm[2]]
        for a in range(3):
            for b in range(3):
                v.append(cast(K[a] @ M @ K[b]))
    for perm in [(0, 1, 2), (0, 2, 1)]:
        t3 = np.tensordot(E[perm[0]] @ E[perm[1]], E[perm[2]])
        for a in range(3):
            for b in range(a, 3):
                v.append(cast(t3 * (K[a] @ K[b])))
    return v


def rref_rank(A):
    A = [row[:] for row in A]
    R = len(A)
    if R == 0:
        return 0
    C = len(A[0]); r = 0
    for c in range(C):
        pr = next((rr for rr in range(r, R) if A[rr][c] != 0), None)
        if pr is None:
            continue
        A[r], A[pr] = A[pr], A[r]
        inv = A[r][c]; A[r] = [x / inv for x in A[r]]
        for rr in range(R):
            if rr != r and A[rr][c] != 0:
                f = A[rr][c]
                A[rr] = [a - f * b for a, b in zip(A[rr], A[r])]
        r += 1
        if r == R:
            break
    return r


def report(name, y, M, Me):
    res = np.linalg.norm(y - M @ np.linalg.lstsq(M, y, rcond=None)[0])
    ye = [Fr(int(round(v))) for v in y]
    r0 = rref_rank([q[:] for q in Me])
    r1 = rref_rank([Me[i] + [ye[i]] for i in range(len(Me))])
    print("  %-28s anisotropy %.2e   rank(M)=%d  rank([M|y])=%d   %s"
          % (name, res / np.linalg.norm(y), r0, r1,
             "in the O(4) space" if r1 == r0 else "OUTSIDE the O(4) space"))


if __name__ == "__main__":
    rng = np.random.default_rng(1); rows = []
    for _ in range(60):
        k1 = rng.standard_normal(4); k2 = rng.standard_normal(4); k3 = -k1 - k2

        def rTT(k):
            A = rng.standard_normal((4, 4)); A = (A + A.T) / 2
            P = np.eye(4) - np.outer(k, k) / (k @ k)
            A = P @ A @ P
            return P @ (A - np.trace(A) / np.trace(P) * P) @ P
        rows.append(O4_structures([k1, k2, k3], [rTT(k1), rTT(k2), rTT(k3)]))
    sv = np.linalg.svd(np.array(rows), compute_uv=False)
    print("O(4) structure space on continuum kinematics: dimension %d (expected 9)"
          % int((sv > 1e-9 * sv[0]).sum()))
    print()
    cfgs = sample_configs()
    cf = [[np.array(x) for x in c] for c in cfgs]
    es = [[TT(k[0]), TT(k[1]), TT(k[2])] for k in cf]
    M = np.array([O4_structures(cf[i], es[i]) for i in range(40)])
    Me = [O4_structures(cf[i], es[i], Fr) for i in range(40)]
    print("exact rational rank tests over the 40 configurations:")
    report("continuum Einstein-Hilbert", eh_on_configs(cfgs, TT), M, Me)
    for f, lab in [("emergent_periodic_values.json", "periodic complex (N_h=150)"),
                   ("emergent_star_base0.json", "open star, N_h=130"),
                   ("emergent_star_base2.json", "open star, N_h=120")]:
        if os.path.exists(f):
            d = json.load(open(f))
            y = np.array([d[str(i)] if not isinstance(d[str(i)], dict)
                          else d[str(i)]["c2"] for i in range(40)])
            report(lab, y, M, Me)
        else:
            print("  %-28s (run emergent_star_drift.py to generate %s)" % (lab, f))
