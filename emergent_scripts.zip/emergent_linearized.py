#!/usr/bin/env python3
"""Section 5: the linearized operator on the same periodic complex is Fierz-Pauli.

On a closed complex the Schlaefli identity reduces the second variation to
S2_ab = sum_h (dA/dL_a)(d delta/dL_b), symmetrized, with no restriction imposed by
hand.  Contracted with the plane-wave modes this is compared against the
Fierz-Pauli quadratic form, for generic and for transverse-traceless
polarizations, and across spine assignments.

    python3 emergent_linearized.py
"""
import numpy as np, itertools as it
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine
from emergent_star import TT

TRI_SLOTS = [4, 1, 0]


def qFP(k, e):
    kk = float(k @ k)
    a = k @ e
    return (0.5 * kk * float(np.tensordot(e, e)) - float(a @ a)
            + float(np.trace(e)) * float(k @ e @ k)
            - 0.5 * kk * float(np.trace(e)) ** 2)


def make_quad(pe):
    def quad(k, e1, e2):
        p1, ph1 = pe.mode_vals(e1, k)
        p2, ph2 = pe.mode_vals(e2, -np.asarray(k, float))
        P, ts, dA = pe.pair, TRI_SLOTS, pe.dA[pe.owner]

        def S2(n1, n2):
            v1 = p1[P] * (ph1 ** n1 if n1 else 1.0)
            v2 = p2[P] * (ph2 ** n2 if n2 else 1.0)
            return float((
                np.einsum('pi,pi->p', dA, v1[:, ts]) * (-np.einsum('pi,pi->p', pe.dth, v2))
                + np.einsum('pi,pi->p', dA, v2[:, ts]) * (-np.einsum('pi,pi->p', pe.dth, v1))
            ).sum()) / 2.0
        return -0.5 * (S2(2, 0) + S2(0, 2) + 2 * S2(1, 1))
    return quad


if __name__ == "__main__":
    cx = PeriodicD4(L=4, spine='axis0')
    pe = PeriodicEngine(cx).build_derivs()
    quad = make_quad(pe)

    # rank-four isotropy of the 24 minimal vectors
    V = []
    for i, j in it.combinations(range(4), 2):
        for si in (1, -1):
            for sj in (1, -1):
                v = [0, 0, 0, 0]; v[i] = si; v[j] = sj; V.append(v)
    V = np.array(V, float)
    T = np.einsum('ni,nj,nk,nl->ijkl', V, V, V, V)
    d = np.eye(4)
    S = (np.einsum('ij,kl->ijkl', d, d) + np.einsum('ik,jl->ijkl', d, d)
         + np.einsum('il,jk->ijkl', d, d))
    print("rank-four bond tensor: ||T - 4S|| = %.2e   T1111/T1122 = %.6f"
          % (np.abs(T - 4 * S).max(), T[0, 0, 0, 0] / T[0, 0, 1, 1]))
    print()
    print("transverse-traceless polarizations, ratio to -k^2(eps1:eps2)/2:")
    for kk in [(1, 1, 0, 0), (1, 0, 1, 0), (0, 1, 1, 0), (1, -1, 0, 0),
               (1, 1, 1, 1), (1, 1, -1, -1), (2, 1, 1, 0)]:
        k = np.array(kk, float); e = TT(np.array(kk)).astype(float)
        v = quad(k, e, e) / cx.nv
        fp = -0.5 * float(k @ k) * float(np.tensordot(e, e))
        print("   %-16s |k|^2=%d   ratio = %.7f" % (str(kk), int(k @ k), v / fp))
    print()
    rng = np.random.default_rng(0); r = []
    for _ in range(60):
        k = rng.standard_normal(4)
        A = rng.standard_normal((4, 4)); e = A + A.T
        r.append(quad(k, e, e) / cx.nv / qFP(k, e))
    r = np.array(r)
    print("generic (non-TT) polarizations, 60 random (k,eps):")
    print("   S2/Nv / q_FP = %.8f    spread = %.1e" % (r.mean(), r.std() / abs(r.mean())))
    print()
    print("subdivision independence, k = (1,1,1,1):")
    for sp in ['axis0', 'axis1', 'axis2', 'axis3', 'random']:
        c = PeriodicD4(L=4, spine=sp, seed=7)
        p = PeriodicEngine(c).build_derivs()
        f = make_quad(p)
        k = np.array([1, 1, 1, 1], float); e = TT(np.array([1, 1, 1, 1])).astype(float)
        print("   %-9s S2/Nv = %.7f   (Fierz-Pauli %.4f)"
              % (sp, f(k, e, e) / c.nv, qFP(k, e)), flush=True)
