import numpy as np, itertools as it, json
V=[]
for i,j in it.combinations(range(4),2):
    for si in (1,-1):
        for sj in (1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; V.append(v)
V=np.array(V,float)
a=np.array([0,0,0,1.0]); b=np.array([1,1,1,1.0])/2
b=b-(b@a)*a; b/=np.linalg.norm(b)
th=np.linspace(0,np.pi/2,241)
U=np.outer(np.cos(th),a)+np.outer(np.sin(th),b)
out={'theta':[float(x) for x in np.degrees(th)]}
for d in (2,4,6):
    M=np.sum((U@V.T)**d,axis=1)
    out['M%d'%d]=[float(x) for x in M]
    print('d=%d: min %.6f max %.6f spread/mean %.3e'%(d,M.min(),M.max(),(M.max()-M.min())/M.mean()),flush=True)

from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine, _theta
cx=PeriodicD4(L=4,spine='axis0'); pe=PeriodicEngine(cx).build_derivs()
F=np.zeros(pe.ne)
w=-(pe.A[pe.owner])[:,None]*pe.dth
np.add.at(F,pe.pair.ravel(),w.ravel())
out['schlaefli_closed']=[float(abs(x)) for x in F]
print('closed: max %.2e over %d edges'%(np.abs(F).max(),len(F)),flush=True)

# open star, same quantity
from emergent_star import build_star
st=build_star(0); pts=st['pts']; eidx=st['eidx']
fk=lambda x,y:(min(x,y),max(x,y))
rows=[];owner=[];tri=[]
for hi,h in enumerate(st['hinges']):
    for s in st['around'][h]:
        loc=list(h)+[v for v in s if v not in h]
        rows.append([eidx[fk(loc[i],loc[j])] for i in range(5) for j in range(i+1,5)])
        owner.append(hi)
    tri.append([eidx[fk(h[1],h[2])],eidx[fk(h[0],h[2])],eidx[fk(h[0],h[1])]])
rows=np.array(rows);owner=np.array(owner);tri=np.array(tri)
L0=np.asarray(st['L0'],float); base=L0[rows]; hh=1e-4
d1=np.zeros((len(rows),10))
for i in range(10):
    p=base.copy();p[:,i]+=hh; m=base.copy();m[:,i]-=hh
    d1[:,i]=(_theta(p)-_theta(m))/(2*hh)
A=L0[tri[:,0]];B=L0[tri[:,1]];C=L0[tri[:,2]]
H=2*A*B+2*B*C+2*C*A-A*A-B*B-C*C
area=np.sqrt(np.maximum(H,0))/4
Fs=np.zeros(len(st['edges']))
ws=-(area[owner])[:,None]*d1
np.add.at(Fs,rows.ravel(),ws.ravel())
out['schlaefli_star']=[float(abs(x)) for x in Fs]
print('open star: max %.3f over %d edges'%(np.abs(Fs).max(),len(Fs)),flush=True)
json.dump(out,open('emergent_figdata_design.json','w'))
print('saved')
