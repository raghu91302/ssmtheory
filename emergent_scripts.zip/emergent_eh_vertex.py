#!/usr/bin/env python3
"""
The continuum Einstein-Hilbert cubic graviton vertex, evaluated on the same
kinematic configurations as the lattice vertex.

Paper II establishes that c2_sym lies OUTSIDE the 9-dimensional space of
O(4)-invariant two-derivative structures.  It never checks the complementary and
much stronger question: is the part that lies INSIDE that space actually the
Einstein-Hilbert vertex?  Without that, "the vertex is not Einstein-Hilbert" is
consistent with the vertex having nothing to do with gravity at all.

Method.  Work with the first-order (Gamma-Gamma) form of the Einstein-Hilbert
Lagrangian,
    L = sqrt(g) g^{mu nu} ( Gamma^a_{mu b} Gamma^b_{nu a}
                            - Gamma^a_{mu nu} Gamma^b_{a b} ),
which differs from sqrt(g) R by a total derivative.  At cubic order a total
derivative contributes a factor (k1+k2+k3) = 0, so it drops out and L is exactly
the two-derivative object we want.

Set g = delta + H with H_{mu nu}(x) = sum_i t_i eps^i_{mu nu} exp(i k_i . x) and
extract the coefficient of t1 t2 t3.  Because only the multilinear monomial is
needed, all series are truncated to squarefree monomials in the three modes: a
quantity is a dict {subset of (0,1,2) -> 4x4 (or scalar) array}, and a monomial
with index set S carries total momentum K_S = sum_{i in S} k_i, so d_mu acting on
it is multiplication by i (K_S)_mu.  With traceless eps_i, tr H = 0 and
    sqrt(g) = 1 - (1/4) tr H^2 + (1/6) tr H^3,   g^{-1} = 1 - H + H^2 - H^3.

The overall normalization (Newton constant, field normalization relative to the
lattice edge-strain convention) is a single constant, fitted downstream.
"""
import numpy as np, itertools as it

IDX = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]


class Multi:
    """Squarefree polynomial in three formal mode amplitudes, tensor valued."""

    def __init__(self, shape, ks):
        self.shape = shape
        self.ks = ks
        self.d = {}

    def copy(self):
        m = Multi(self.shape, self.ks)
        m.d = {k: v.copy() for k, v in self.d.items()}
        return m

    def add(self, key, arr):
        key = tuple(sorted(key))
        if key in self.d:
            self.d[key] = self.d[key] + arr
        else:
            self.d[key] = np.array(arr, dtype=complex)
        return self

    def get(self, key):
        return self.d.get(tuple(sorted(key)))

    def mom(self, key):
        """Total momentum carried by a monomial."""
        k = np.zeros(4)
        for i in key:
            k = k + self.ks[i]
        return k


def mul(A, B, contract):
    """Multiply two Multis, combining only disjoint monomials.
    `contract(a, b)` performs the tensor operation on the coefficient arrays."""
    out = Multi(None, A.ks)
    for ka, va in A.d.items():
        sa = set(ka)
        for kb, vb in B.d.items():
            if sa & set(kb):
                continue
            key = tuple(sorted(ka + kb))
            if len(key) > 3:
                continue
            r = contract(va, vb)
            if key in out.d:
                out.d[key] = out.d[key] + r
            else:
                out.d[key] = r
    return out


def eh_cubic_vertex(ks, es):
    """Coefficient of t1 t2 t3 in the Gamma-Gamma Lagrangian.  Returns a real
    number (up to an overall normalization fitted downstream)."""
    ks = [np.asarray(k, float) for k in ks]
    es = [np.asarray(e, float) for e in es]
    d4 = np.eye(4)

    # ---- H and its first derivative  dH[mu]_{ab} = d_mu H_{ab}
    H = Multi(None, ks)
    for i in range(3):
        H.add((i,), es[i])

    def deriv(A):
        """d_mu A -> Multi whose arrays carry one extra LEADING index."""
        out = Multi(None, ks)
        for key, v in A.d.items():
            k = out.mom(key) if False else sum((ks[i] for i in key),
                                               np.zeros(4))
            out.d[key] = 1j * np.tensordot(k, v, axes=0)
        return out

    dH = deriv(H)                                    # index (mu, a, b)

    # ---- inverse metric  g^{-1} = 1 - H + H^2 - H^3
    matmul = lambda a, b: a @ b
    H2 = mul(H, H, matmul)
    H3 = mul(H2, H, matmul)
    ginv = Multi(None, ks)
    ginv.add((), d4)
    for key, v in H.d.items():
        ginv.add(key, -v)
    for key, v in H2.d.items():
        ginv.add(key, v)
    for key, v in H3.d.items():
        ginv.add(key, -v)

    # ---- sqrt(det g) = 1 - (1/4) tr H^2 + (1/6) tr H^3   (tr H = 0)
    sq = Multi(None, ks)
    sq.add((), np.array(1.0))
    for key, v in H2.d.items():
        sq.add(key, -0.25 * np.trace(v))
    for key, v in H3.d.items():
        sq.add(key, (1.0 / 6.0) * np.trace(v))

    # ---- Christoffel  Gamma^a_{mu nu}
    #      = 1/2 g^{a b} ( d_mu H_{b nu} + d_nu H_{b mu} - d_b H_{mu nu} )
    T = Multi(None, ks)          # T_{b mu nu}, the bracket
    for key, v in dH.d.items():
        # v[mu, a, b] = d_mu H_{ab}
        t = np.einsum('mbn->bmn', v) + np.einsum('nbm->bmn', v) \
            - np.einsum('bmn->bmn', v)
        T.add(key, t)

    Gam = mul(ginv, T, lambda gi, t: 0.5 * np.einsum('ab,bmn->amn', gi, t))

    # ---- L = sqrt(g) g^{mu nu} ( G^a_{mu b} G^b_{nu a} - G^a_{mu nu} G^b_{ab} )
    P1 = mul(Gam, Gam, lambda A, B: np.einsum('amb,bna->mn', A, B))
    P2 = mul(Gam, Gam, lambda A, B: np.einsum('amn,bab->mn', A, B))
    P = Multi(None, ks)
    for key, v in P1.d.items():
        P.add(key, v)
    for key, v in P2.d.items():
        P.add(key, -v)

    GP = mul(ginv, P, lambda gi, p: np.array(np.einsum('mn,mn->', gi, p)))
    L = mul(sq, GP, lambda s, g: np.array(s * g))

    val = L.get((0, 1, 2))
    if val is None:
        return 0.0
    val = complex(val)
    assert abs(val.imag) < 1e-8 * max(1.0, abs(val.real)), \
        f"EH vertex not real: {val}"
    return val.real


def eh_on_configs(cfgs, TT):
    """EH vertex on a list of integer momentum triples, using the same
    deterministic TT polarization construction as the lattice run."""
    out = []
    for cfg in cfgs:
        ks = [np.asarray(k, float) for k in cfg]
        es = [TT(np.asarray(k)).astype(float) for k in cfg]
        out.append(eh_cubic_vertex(ks, es))
    return np.array(out)
