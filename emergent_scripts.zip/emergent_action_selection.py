#!/usr/bin/env python3
"""Section 2.2: what flat-space stationarity fixes, and what it does not.

Takes a restricted constant-coefficient ansatz -- one constant per hinge congruence
class at the flat background, in the deficit sector and in an independent hinge-area
potential --

    S(g,v) = sum_c [ g_c sum_{h in c} delta_h + v_c sum_{h in c} A_h ] ,

with one free coefficient per hinge congruence class in each sector and no area
factor assumed.  Imposing dS/d(l_e^2) = 0 at the flat background for every edge
gives a linear system.  Its null space is one-dimensional and the surviving
direction is g_c proportional to A_c with v_c = 0: the Regge action is the unique
member of the family admitting a flat vacuum.

    python3 emergent_action_selection.py
"""
import numpy as np
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine


def selection(L=4, spine='axis0', seed=7, cosmological=True):
    cx = PeriodicD4(L=L, spine=spine, seed=seed)
    pe = PeriodicEngine(cx).build_derivs()
    tri = cx.L0[pe.tri].astype(int)
    cls, cidx = np.unique(tri, axis=0, return_inverse=True)
    nc = len(cls)
    Ac = np.array([pe.A[cidx == c][0] for c in range(nc)])
    ncol = 2 * nc if cosmological else nc
    M = np.zeros((pe.ne, ncol))
    for c in range(nc):                      # deficit sector
        m = (cidx[pe.owner] == c)
        acc = np.zeros(pe.ne)
        np.add.at(acc, pe.pair[m].ravel(), (-pe.dth[m]).ravel())
        M[:, c] = acc
    if cosmological:                         # cosmological sector
        for c in range(nc):
            hm = (cidx == c)
            acc = np.zeros(pe.ne)
            np.add.at(acc, pe.tri[hm].ravel(), pe.dA[hm].ravel())
            M[:, nc + c] = acc
    u, s, vt = np.linalg.svd(M)
    rank = int((s > 1e-6 * s[0]).sum())
    null = vt[rank:]
    return cls, Ac, M, s, rank, null


if __name__ == "__main__":
    cls, Ac, M, s, rank, null = selection()
    print("hinge congruence classes on the periodic D4 complex (L=4):")
    for t, a in zip(cls, Ac):
        print("   squared edge lengths %-10s area %.6f" % (tuple(int(x) for x in t), a))
    print()
    print("family: 4 deficit coefficients + 4 cosmological coefficients = 8")
    print("flat-space stationarity matrix: rank %d, null dimension %d"
          % (rank, M.shape[1] - rank))
    v = null[0] / np.abs(null[0]).max()
    nc = len(cls)
    print()
    print("   surviving deficit coefficients g_c :", np.round(np.abs(v[:nc]), 6))
    print("   hinge areas                    A_c :", np.round(Ac, 6))
    print("   ratio g_c / A_c                    :",
          np.round(np.abs(v[:nc]) / Ac / (abs(v[0]) / Ac[0]), 9))
    print("   cosmological coefficients      v_c :", np.round(v[nc:], 9))
    print()
    print("=> within this ansatz the deficit weights must be proportional to the")
    print("   BACKGROUND hinge areas, and the area potential must vanish.")
    print("   This does not fix the nonlinear dependence A_h(l); see the paper.")
    print()
    print("robustness:")
    for L, sp in ((4, 'axis0'), (4, 'axis1'), (4, 'random'), (6, 'axis0')):
        c2, A2, M2, s2, r2, n2 = selection(L=L, spine=sp)
        v2 = n2[0] / np.abs(n2[0]).max()
        rat = np.abs(v2[:len(c2)]) / A2
        print("   L=%d %-8s rank %d, null dim %d, g/A spread %.1e"
              % (L, sp, r2, M2.shape[1] - r2, rat.max() - rat.min()), flush=True)
