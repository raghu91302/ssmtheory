#!/usr/bin/env python3
"""The Schlaefli diagnostic: why a truncated complex fails.

Measures sum_h A_h d(delta_h)/dL_e on the open origin star and on the closed
periodic complex, verifies the per-simplex identity, and runs the slot-symmetry
test on the factorized third variation, which holds on the torus and fails on the
star.

    python3 emergent_schlaefli.py
"""
import numpy as np, itertools as it
from emergent_periodic_d4 import PeriodicD4
from emergent_periodic_engine import PeriodicEngine, _theta
from emergent_star import build_star, sample_configs, TT

if __name__ == "__main__":
    cx = PeriodicD4(L=4, spine='axis0')
    pe = PeriodicEngine(cx).build_derivs()
    print("closed periodic complex")
    theta = _theta(cx.L0[pe.pair])
    delta = np.full(pe.nh, 2 * np.pi)
    np.subtract.at(delta, pe.owner, theta)
    print("   flat-background deficit  max|delta_h| = %.2e" % np.abs(delta).max())
    print("   Schlaefli  max_e |sum_h A_h d_e delta_h| = %.2e" % pe.schlaefli())
    print()
    st = build_star(0)
    pts, eidx = st['pts'], st['eidx']
    fk = lambda a, b: (min(a, b), max(a, b))
    simp = {s for h in st['hinges'] for s in st['around'][h]}
    h = 1e-5

    def area(i, j, k):
        a = float((pts[j] - pts[k]) @ (pts[j] - pts[k]))
        b = float((pts[i] - pts[k]) @ (pts[i] - pts[k]))
        c = float((pts[i] - pts[j]) @ (pts[i] - pts[j]))
        H = 2 * a * b + 2 * b * c + 2 * c * a - a * a - b * b - c * c
        return np.sqrt(max(H, 0)) / 4
    worst = 0.0
    for s in list(simp)[:12]:
        s = list(s)
        ed = [(a, b) for a, b in it.combinations(s, 2)]
        L0 = {fk(a, b): float((pts[a] - pts[b]) @ (pts[a] - pts[b])) for a, b in ed}
        for ce in ed:
            tot = 0.0
            for tri in it.combinations(s, 3):
                other = [v for v in s if v not in tri]

                def th(delta):
                    Ld = dict(L0); Ld[fk(*ce)] = L0[fk(*ce)] + delta
                    loc5 = list(tri) + other
                    arr = np.array([[Ld[fk(loc5[i], loc5[j])]
                                     for i in range(5) for j in range(i + 1, 5)]])
                    return float(_theta(arr)[0])
                tot += area(*tri) * (th(h) - th(-h)) / (2 * h)
            worst = max(worst, abs(tot))
    print("open origin star")
    print("   per-simplex Schlaefli  max |sum_{h in s} A_h dtheta| = %.2e" % worst)
    print("   (the identity holds simplex by simplex; the star sum does not,")
    print("    because it discards the other hinges of those same simplices)")
