#!/usr/bin/env python3
"""
Fast float64 / numpy re-implementation of the D4 cubic-vertex engine.

The reference implementation (d4_cubic_vertex_autD4.py) uses mpmath at 80 digits
and costs ~21.5 s per vertex evaluation, i.e. ~7 h per configuration for the full
1152-element group on one core.  That makes the base-triangulation independence
check -- the one test the paper needs and never ran -- infeasible.

The published c2_sym values are exact rationals with denominators in {1,3,9} and
magnitudes <~ 300, so identifying them needs ~6 correct digits, not 80.  This
module reimplements the same mathematics in vectorized float64 and is validated
against the shipped exact rationals before being used for anything new.

Same conventions as the reference: intrinsic Regge action S = sum_h A_h delta_h
on the D4 origin star, third directional derivative by an 8-point sign-symmetric
stencil with Richardson extrapolation, and the translation-invariant vertex
    c2 = -1/2 [ sum_i S3(w_i,u_j,u_l) + 2 sum_{i<j} S3(y_i,y_j,u_l) ].
"""
import numpy as np, itertools as it
from scipy.spatial import Delaunay
from collections import defaultdict

TWO_PI = 2.0 * np.pi


# --------------------------------------------------------------------- star
def build_star(perm_seed=None):
    """D4 origin star.  perm_seed permutes the input points, which changes how
    qhull subdivides the degenerate (cospherical) 24-cell Delaunay cells --
    i.e. it selects a different base triangulation."""
    pts = [v for v in it.product(range(-3, 4), repeat=4)
           if sum(v) % 2 == 0 and sum(x * x for x in v) <= 8]
    pts = np.array(sorted(pts), int)
    if perm_seed is not None:
        pts = pts[np.random.default_rng(perm_seed).permutation(len(pts))]
    O = int(np.where((pts == 0).all(1))[0][0])
    simp = [tuple(s) for s in Delaunay(pts.astype(float),
                                       qhull_options='Qt').simplices]
    star = [s for s in simp if O in s]
    hinges = sorted({tuple(sorted(t)) for s in star
                     for t in it.combinations(s, 3) if O in t})
    around = defaultdict(list)
    for s in simp:
        for t in it.combinations(sorted(s), 3):
            if O in t:
                around[t].append(s)
    edges = sorted({(min(a, b), max(a, b)) for s in star
                    for a, b in it.combinations(s, 2)})
    eidx = {e: i for i, e in enumerate(edges)}
    L0 = np.array([float((pts[a] - pts[b]) @ (pts[a] - pts[b]))
                   for a, b in edges])
    return dict(pts=pts, O=O, hinges=hinges, around=around, edges=edges,
                eidx=eidx, L0=L0)


# --------------------------------------------------------------------- engine
class Engine:
    """Vectorized Regge action and its third directional derivative.

    dtype may be np.float64 (fast) or np.longdouble (80-bit extended, ~19 digits,
    used for the high-precision verification runs)."""

    def __init__(self, st, dtype=np.float64):
        self.dtype = dtype
        st = dict(st)
        st['L0'] = np.asarray(st['L0'], dtype=dtype)
        self.st = st
        pts, hinges, around, eidx = st['pts'], st['hinges'], st['around'], st['eidx']
        self.ne = len(st['edges'])
        fk = lambda a, b: (min(a, b), max(a, b))

        # hinge triangles -> 3 edge slots
        self.tri = np.array([[eidx[fk(h[0], h[1])], eidx[fk(h[0], h[2])],
                              eidx[fk(h[1], h[2])]] for h in hinges])
        self.nh = len(hinges)

        # (hinge, simplex) pairs -> 10 edge slots in canonical ordering.
        # loc = [h0,h1,h2, other, other]; Lm[(i,j)] = L[fk(loc[i],loc[j])].
        rows, owner = [], []
        for hi, h in enumerate(hinges):
            for s in around[h]:
                loc = list(h) + [v for v in s if v not in h]
                rows.append([eidx[fk(loc[i], loc[j])]
                             for i in range(5) for j in range(i + 1, 5)])
                owner.append(hi)
        self.pair = np.array(rows)          # (npair, 10)
        self.owner = np.array(owner)        # (npair,)
        # sparse (nh x npair) incidence for batched hinge reduction
        from scipy.sparse import csr_matrix
        npair = len(rows)
        self.R = csr_matrix((np.ones(npair), (self.owner, np.arange(npair))),
                            shape=(self.nh, npair))
        self.RT = np.asarray(self.R.T.todense())   # precomputed, hot path
        # precomputed edge vectors and midpoints for vectorized modes()
        self.D = np.array([pts[b] - pts[a] for a, b in st['edges']], dtype=dtype)
        self.X = np.array([(pts[a] + pts[b]) / 2.0 for a, b in st['edges']], dtype=dtype)
        self.RT = self.RT.astype(dtype)
        # position of (i,j) within the 10 upper-triangular slots of a 5-set
        self.slot = {}
        c = 0
        for i in range(5):
            for j in range(i + 1, 5):
                self.slot[(i, j)] = c
                c += 1

    def _Lm(self, Ld, i, j):
        a, b = min(i, j), max(i, j)
        return Ld[..., self.pair[:, self.slot[(a, b)]]]

    def action(self, Ld):
        """S = sum_h A_h delta_h.  Ld may be (ne,) or a batch (B, ne)."""
        L = self._Lm
        xx = {}
        for i in range(1, 5):
            xx[(i, i)] = L(Ld, 0, i)
        for i in range(1, 5):
            for j in range(i + 1, 5):
                v = 0.5 * (L(Ld, 0, i) + L(Ld, 0, j) - L(Ld, i, j))
                xx[(i, j)] = v
                xx[(j, i)] = v
        det = xx[(1, 1)] * xx[(2, 2)] - xx[(1, 2)] ** 2

        def perp(a, b):
            ua, va = xx[(1, a)], xx[(2, a)]
            ub, vb = xx[(1, b)], xx[(2, b)]
            return xx[(a, b)] - ((xx[(2, 2)] * ua - xx[(1, 2)] * va) * ub
                                 + (-xx[(1, 2)] * ua + xx[(1, 1)] * va) * vb) / det

        c = perp(3, 4) / np.sqrt(perp(3, 3) * perp(4, 4))
        theta = np.arccos(np.clip(c, self.dtype(-1), self.dtype(1)))
        delta = self.dtype(TWO_PI) - theta @ self.RT

        a, b, cc = (Ld[..., self.tri[:, 0]], Ld[..., self.tri[:, 1]],
                    Ld[..., self.tri[:, 2]])
        H = 2 * a * b + 2 * b * cc + 2 * cc * a - a * a - b * b - cc * cc
        area = np.sqrt(np.maximum(H, 0.0)) / 4.0
        return np.sum(area * delta, axis=-1)

    def S3(self, v1, v2, v3, h0=1e-2, rlev=2):
        """Third directional derivative of the action, Richardson extrapolated.
        Each direction is normalized before differencing and rescaled after,
        exactly as in the reference implementation."""
        s = []
        n = []
        for v in (v1, v2, v3):
            m = np.max(np.abs(v))
            m = m if m > 0 else 1.0
            s.append(m)
            n.append(v / m)
        L0 = self.st['L0']
        signs = np.array(list(it.product([1, -1], repeat=3)), float)
        par = signs[:, 0] * signs[:, 1] * signs[:, 2]
        dirs = signs @ np.stack(n)                      # (8, ne)

        def D(step):
            S = self.action(L0[None, :] + step * dirs)  # batched, one shot
            return float(par @ S) / (2 * step) ** 3

        Dk = [D(h0 / 2 ** k) for k in range(rlev)]
        for m in range(1, rlev):
            f = 4.0 ** m
            Dk = [(f * Dk[i + 1] - Dk[i]) / (f - 1) for i in range(len(Dk) - 1)]
        return Dk[0] * s[0] * s[1] * s[2]

    # ------------------------------------------------------------- modes
    def modes(self, eps, kap):
        """u = eps:d(x)d, y = u*(k.x_e), w = u*(k.x_e)^2 on every star edge."""
        eps = np.asarray(eps, dtype=self.dtype); kap = np.asarray(kap, dtype=self.dtype)
        u = np.einsum('ei,ij,ej->e', self.D, eps, self.D)
        ph = self.X @ kap
        return u, u * ph, u * ph * ph

    def c2(self, ks, es, h0=1e-2, rlev=2):
        """Translation-invariant O(k^2) cubic vertex plus the O(k^0) flatness
        residual.  All 6 third-derivatives x rlev steps x 8 sign combinations
        are evaluated in a single batched action call."""
        u1, y1, w1 = self.modes(es[0], ks[0])
        u2, y2, w2 = self.modes(es[1], ks[1])
        u3, y3, w3 = self.modes(es[2], ks[2])
        triples = [(w1, u2, u3), (u1, w2, u3), (u1, u2, w3),
                   (y1, y2, u3), (u1, y2, y3), (y1, u2, y3),
                   (u1, u2, u3)]
        signs = np.array(list(it.product([1, -1], repeat=3)), dtype=self.dtype)
        par = signs[:, 0] * signs[:, 1] * signs[:, 2]
        L0 = self.st['L0']
        h0 = self.dtype(h0)
        rows, scales = [], []
        for tri in triples:
            sc = [max(np.max(np.abs(v)), 1e-300) for v in tri]
            n = np.stack([v / m for v, m in zip(tri, sc)])
            dirs = signs @ n                                   # (8, ne)
            for kk in range(rlev):
                rows.append(L0[None, :] + (h0 / 2 ** kk) * dirs)
            scales.append(sc[0] * sc[1] * sc[2])
        S = self.action(np.concatenate(rows, axis=0))          # one shot
        S = S.reshape(len(triples), rlev, 8)
        out = []
        for t in range(len(triples)):
            Dk = [(par @ S[t, kk]) / (2 * (h0 / 2 ** kk)) ** 3
                  for kk in range(rlev)]
            for m in range(1, rlev):
                f = self.dtype(4) ** m
                Dk = [(f * Dk[i + 1] - Dk[i]) / (f - 1)
                      for i in range(len(Dk) - 1)]
            out.append(Dk[0] * scales[t])
        sq = out[0] + out[1] + out[2]
        cross = 2 * (out[3] + out[4] + out[5])
        return -0.5 * (sq + cross), out[6]


# --------------------------------------------------------------------- Aut(D4)
def aut_d4(mode='full'):
    """Aut(D4) = W(F4), order 1152, as exact half-integer matrices in float64
    (all entries are integers or halves, hence exactly representable)."""
    def M(rows, half=False):
        f = 0.5 if half else 1.0
        return tuple(tuple(f * x for x in r) for r in rows)
    swap = M([[0, 1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
    cyc = M([[0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1], [1, 0, 0, 0]])
    flip = M([[-1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
    H = M([[1, 1, 1, 1], [1, -1, 1, -1], [1, 1, -1, -1], [1, -1, -1, 1]], half=True)
    I = M([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
    gens = {'full': [swap, cyc, flip, H], 'b4': [swap, cyc, flip]}[mode]

    def mul(A, B):
        return tuple(tuple(sum(A[i][k] * B[k][j] for k in range(4))
                           for j in range(4)) for i in range(4))
    G = {I}
    fr = [I]
    while fr:
        a = fr.pop()
        for g in gens:
            for p in (mul(a, g), mul(g, a)):
                if p not in G:
                    G.add(p)
                    fr.append(p)
    return [np.array(m, float) for m in G]


# --------------------------------------------------------------------- TT
def perp_int(k):
    for e in np.eye(4, dtype=int):
        w = e * int(k @ k) - k * int(e @ k)
        if np.any(w):
            return w


def TT(k):
    a = perp_int(k)
    b = None
    for e in np.eye(4, dtype=int):
        cand = e * int(k @ k) - k * int(e @ k)
        cand = cand * int(a @ a) - a * int(a @ cand)
        if np.any(cand):
            b = cand
            break
    g = np.gcd.reduce(np.abs(b)) if np.any(b) else 1
    if g:
        b = b // g
    return np.outer(a, b) + np.outer(b, a)


def sample_configs(n=40, seed=20240611):
    """Identical config sampler to the reference run."""
    rng = np.random.default_rng(seed)
    out = []
    t = 0
    while len(out) < n and t < n * 40:
        t += 1
        k1 = rng.integers(-1, 2, 4)
        k2 = rng.integers(-1, 2, 4)
        k3 = -k1 - k2
        if np.max(np.abs(k3)) > 1:
            continue
        if not (np.any(k1) and np.any(k2) and np.any(k3)):
            continue
        out.append((k1, k2, k3))
    return out


def group_average(eng, cfg, G, h0=1e-2, rlev=2):
    """Exact finite average of c2 over the group orbit of the kinematics."""
    k = [np.array(x, float) for x in cfg]
    e = [TT(np.array(x)).astype(float) for x in cfg]
    seen = {}
    for g in G:
        gk = [g @ kk for kk in k]
        ge = [g @ ee @ g.T for ee in e]
        key = tuple(np.concatenate([np.concatenate(gk),
                                    np.concatenate([m.ravel() for m in ge])]))
        if key in seen:
            seen[key][0] += 1
        else:
            seen[key] = [1, (gk, ge)]
    tot = 0.0
    ntot = 0
    c0max = 0.0
    for mult, (gk, ge) in seen.values():
        v, c0 = eng.c2(gk, ge, h0, rlev)
        tot += mult * v
        ntot += mult
        c0max = max(c0max, abs(c0))
    return tot / ntot, c0max, len(seen)
