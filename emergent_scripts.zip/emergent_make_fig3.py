#!/usr/bin/env python3
"""Figure 3: the D4 spherical-design ladder and the Schlaefli diagnostic.

Panel (a): the moment M_d(u) = sum_v (v.u)^d over the 24 minimal vectors of D4,
as u sweeps a great circle from a coordinate axis to a body-type diagonal.  It is
exactly constant at d = 2 and d = 4 (the 24-cell is a spherical 4-design, hence
also a 5-design by symmetry) and varies at d = 6.  Exact values are marked.

Panel (b): the Schlaefli residual max_e |sum_h A_h d(delta_h)/dl_e^2| per edge,
on the open origin star and on the closed periodic complex, plotted as sorted
per-edge magnitudes on a log scale.

    python3 emergent_make_fig3.py
"""
import json, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['DejaVu Serif'],
    'mathtext.fontset': 'dejavuserif',
    'font.size': 9, 'axes.labelsize': 9, 'axes.titlesize': 9.5,
    'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'axes.linewidth': 0.7, 'xtick.major.width': 0.7, 'ytick.major.width': 0.7,
    'lines.linewidth': 1.3, 'figure.dpi': 200, 'savefig.dpi': 400,
    'axes.grid': True, 'grid.alpha': 0.18, 'grid.linewidth': 0.5,
})
C = ['#1f4e79', '#c0392b', '#1e8449', '#7d3c98']

d = json.load(open('emergent_figdata_design.json'))
th = np.array(d['theta'])

# Two panels, equal width, aspect fixed by figsize; no stretching applied.
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.85))

# ---------------------------------------------------------------- panel (a)
# d=2 and d=4 coincide exactly at 12; draw one solid and one dashed on top
sty = [dict(ls='-', lw=2.6, alpha=0.9), dict(ls=(0, (4, 3)), lw=1.4),
       dict(ls='-', lw=1.4)]
for i, deg in enumerate((2, 4, 6)):
    M = np.array(d['M%d' % deg])
    ax[0].plot(th, M, color=C[i], label=r'$d=%d$' % deg, **sty[i])
ax[0].axhline(12, color='0.55', lw=0.7, ls=':', zorder=1)
ax[0].set_xlim(0, 90)
ax[0].set_ylim(11.4, 15.5)
ax[0].set_xticks([0, 30, 60, 90])
ax[0].set_xlabel(r'direction $u$: $(0001)\rightarrow(1111)$  [deg]')
ax[0].set_ylabel(r'moment $M_d(u)=\sum_v (v\!\cdot\! u)^d$')
ax[0].set_title(r'(a) the 24-cell is a 4-design, not a 6-design')
ax[0].legend(frameon=False, loc='upper left', handletextpad=0.5,
             borderpad=0.2, labelspacing=0.25)
ax[0].text(0.50, 0.055,
           r'$d=2,4$ coincide, constant to $1.5\times10^{-15}$',
           ha='center', transform=ax[0].transAxes, fontsize=7.4, color='0.3')
M6 = np.array(d['M6'])
ax[0].annotate(r'$M_6=44/3$', xy=(90, M6[-1]), xytext=(64, 15.0),
               fontsize=7.4, color=C[2],
               arrowprops=dict(arrowstyle='-', lw=0.6, color=C[2]))
ax[0].annotate(r'$M_6=12$', xy=(45, 12.0), xytext=(38, 12.7),
               fontsize=7.4, color=C[2],
               arrowprops=dict(arrowstyle='-', lw=0.6, color=C[2]))

# ---------------------------------------------------------------- panel (b)
star = np.sort(np.array(d['schlaefli_star']))[::-1]
clos = np.sort(np.array(d['schlaefli_closed']))[::-1]
star = np.maximum(star, 1e-16)
clos = np.maximum(clos, 1e-16)
ax[1].semilogy(np.arange(1, len(star) + 1) / len(star), star, '-',
               color=C[1], label='open vertex star')
ax[1].semilogy(np.arange(1, len(clos) + 1) / len(clos), clos, '-',
               color=C[2], label='closed periodic complex')
ax[1].set_ylim(1e-13, 1e2)
ax[1].set_xlim(0, 1)
ax[1].set_xlabel('fraction of edges (sorted)')
ax[1].set_ylabel(r'$\left|\sum_h A_h\,\partial\delta_h/\partial\ell_e^{\,2}\right|$')
ax[1].set_title('(b) the Schl\u00e4fli identity, edge by edge')
ax[1].legend(frameon=False, loc='lower left', handletextpad=0.5,
             borderpad=0.2, labelspacing=0.25)
ax[1].text(0.97, 0.90, r'$2.5$', ha='right', transform=ax[1].transAxes,
           fontsize=7.6, color=C[1])
ax[1].text(0.97, 0.30, r'$6.1\times10^{-10}$', ha='right',
           transform=ax[1].transAxes, fontsize=7.6, color=C[2])

fig.tight_layout(pad=0.6)
fig.savefig('emergent_fig4_design.pdf', bbox_inches='tight')
print('emergent_fig4_design.pdf written')
