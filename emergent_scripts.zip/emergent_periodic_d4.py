#!/usr/bin/env python3
"""
D4 on a periodic 4-torus, with an explicit (non-qhull) triangulation.

Motivation.  The origin-star construction of Paper II fails three properties at
once: it has a boundary, its action is extensive in the star's share of the
complex, and the Schlaefli identity sum_h A_h d delta_h = 0 is broken (measured
value 2.5, nonzero on every edge) because the star keeps all simplices around each
origin hinge but discards the other hinges of those simplices.  A closed periodic
complex removes all three.

Geometry.  The Delaunay cells of D4 are 16-cells (4-dimensional cross-polytopes)
in two orbits:

  type A: centre c in Z^4 with sum(c) odd; vertices c +- e_i  (i = 0..3)
  type B: centre c in (Z+1/2)^4;           vertices c + s/2, s in {+-1}^4,
          restricted to the 8 sign patterns for which the vertex lies in D4

Each lattice point carries one type-A and two type-B cells (volumes 2/3 each,
totalling the covolume 2), i.e. 3 cells and 24 four-simplices per vertex.

Triangulation.  A 16-cell has four antipodal vertex pairs.  Coning from one chosen
pair ("spine") gives 8 four-simplices: {a, a', p1, p2, p3} with p_i one vertex from
each remaining pair.  Coning leaves the boundary tetrahedra unsubdivided, so any
per-cell choice of spine yields a globally consistent complex.  The spine choice
is therefore an explicit finite label (4 per cell) rather than an accident of point
ordering -- exactly the ambiguity we want to control.
"""
import numpy as np, itertools as it
from collections import defaultdict


def canon(ids, offs):
    """Translation-invariant canonical key for a set of (vertex id, offset)
    pairs: shift so the lowest-id member sits at the origin, then sort."""
    j = int(np.argmin(ids))
    base = offs[j]
    items = sorted((int(v), tuple(np.round(np.asarray(o) - base, 6)))
                   for v, o in zip(ids, offs))
    return tuple(items)


class PeriodicD4:
    def __init__(self, L=4, spine='axis0', seed=None):
        assert L % 2 == 0, "L must be even"
        self.L = L
        self.spine = spine
        self.rng = np.random.default_rng(seed)
        self._build_vertices()
        self._build_cells()
        self._triangulate()
        self._build_topology()

    # ---------------------------------------------------------------- vertices
    def key(self, v):
        return tuple(int(x) % self.L for x in v)

    def _build_vertices(self):
        L = self.L
        vs = [v for v in it.product(range(L), repeat=4) if sum(v) % 2 == 0]
        self.verts = sorted(vs)
        self.vidx = {v: i for i, v in enumerate(self.verts)}
        self.nv = len(self.verts)

    # ---------------------------------------------------------------- cells
    def _build_cells(self):
        """Each cell: (list of 8 vertex ids, list of 4 antipodal pairs as index
        pairs into that list, and the 8 offset vectors from the centre)."""
        L = self.L
        cells = []
        E = np.eye(4, dtype=int)
        # type A: centres at odd-sum integer points
        for c in it.product(range(L), repeat=4):
            if sum(c) % 2 == 0:
                continue
            offs = [E[i] for i in range(4)] + [-E[i] for i in range(4)]
            vids, pairs = [], []
            for i in range(4):
                a = self.vidx[self.key(np.array(c) + E[i])]
                b = self.vidx[self.key(np.array(c) - E[i])]
                pairs.append((len(vids), len(vids) + 1))
                vids += [a, b]
            cells.append(dict(kind='A', c=np.array(c, float), vids=vids,
                              pairs=pairs,
                              offs=[E[i] * 1.0 for i in range(4)
                                    for _ in (0,)] ))
            # rebuild offs in the same order as vids
            offs = []
            for i in range(4):
                offs += [E[i].astype(float), -E[i].astype(float)]
            cells[-1]['offs'] = offs
        # type B: centres at half-integer points
        halves = np.array([0.5, 0.5, 0.5, 0.5])
        for cint in it.product(range(L), repeat=4):
            c = np.array(cint, float) + halves
            signs = [np.array(s, float) for s in it.product([1, -1], repeat=4)]
            good = []
            for s in signs:
                v = c + s / 2.0
                if int(round(sum(v))) % 2 == 0:
                    good.append(s)
            if len(good) != 8:
                continue
            # group into antipodal pairs (s and -s)
            used, vids, pairs, offs = set(), [], [], []
            for s in good:
                ts = tuple(s)
                if ts in used:
                    continue
                used.add(ts); used.add(tuple(-s))
                for sgn in (s, -s):
                    vids.append(self.vidx[self.key(c + sgn / 2.0)])
                    offs.append(sgn / 2.0)
                pairs.append((len(vids) - 2, len(vids) - 1))
            if len(vids) == 8:
                cells.append(dict(kind='B', c=c, vids=vids, pairs=pairs,
                                  offs=offs))
        self.cells = cells

    # ---------------------------------------------------------------- triangulate
    def _spine_index(self, cell, ci):
        if self.spine == 'axis0':
            return 0
        if self.spine == 'axis1':
            return 1
        if self.spine == 'axis2':
            return 2
        if self.spine == 'axis3':
            return 3
        if self.spine == 'random':
            return int(self.rng.integers(0, 4))
        raise ValueError(self.spine)

    def _triangulate(self):
        """8 four-simplices per cell: (a, a', p1, p2, p3)."""
        simp = []
        simp_off = []
        for ci, cell in enumerate(self.cells):
            sp = self._spine_index(cell, ci)
            pairs = cell['pairs']
            a, ap = pairs[sp]
            rest = [pairs[i] for i in range(4) if i != sp]
            for pick in it.product(*rest):
                loc = [a, ap] + list(pick)
                simp.append(tuple(cell['vids'][i] for i in loc))
                simp_off.append((cell['c'], [cell['offs'][i] for i in loc]))
        self.simp = simp
        self.simp_off = simp_off

    # ---------------------------------------------------------------- topology
    def _build_topology(self):
        """Edges (as unordered vertex pairs with a definite displacement),
        hinges, and the simplices around each hinge."""
        edges = {}
        for (c, offs), s in zip(self.simp_off, self.simp):
            for i, j in it.combinations(range(5), 2):
                a, b = s[i], s[j]
                d = offs[j] - offs[i]           # true displacement, no wrap
                k = (min(a, b), max(a, b), tuple(np.round(d if a < b else -d, 6)))
                edges.setdefault(k, len(edges))
        self.edges = sorted(edges, key=lambda k: edges[k])
        self.eidx = {k: i for i, k in enumerate(self.edges)}
        self.ne = len(self.edges)
        self.evec = np.array([list(k[2]) for k in self.edges], float)
        self.L0 = np.einsum('ei,ei->e', self.evec, self.evec)

        around = defaultdict(list)
        for si, ((c, offs), s) in enumerate(zip(self.simp_off, self.simp)):
            for t in it.combinations(range(5), 3):
                ids = [s[i] for i in t]; oo = [offs[i] for i in t]
                j = int(np.argmin(ids)); base = oo[j]
                order = sorted(range(3), key=lambda q: (int(ids[q]),
                               tuple(np.round(np.asarray(oo[q]) - base, 6))))
                tcanon = tuple(t[q] for q in order)      # canonical vertex order
                around[canon(ids, oo)].append((si, tcanon))
        self.hinges = sorted(around)
        self.around = around
        self.nh = len(self.hinges)

    def edge_id(self, si, i, j):
        """Global edge index for local vertices i,j of simplex si."""
        c, offs = self.simp_off[si]; s = self.simp[si]
        a, b = s[i], s[j]
        d = offs[j] - offs[i]
        k = (min(a, b), max(a, b), tuple(np.round(d if a < b else -d, 6)))
        return self.eidx[k]

    def hinge_pairs(self):
        """For every (hinge, simplex) incidence, the 10 local edge indices in the
        canonical 5-set order loc = [h0,h1,h2,other,other]."""
        rows, owner, tri = [], [], []
        for hi, h in enumerate(self.hinges):
            first = True
            for (si, t) in self.around[h]:
                other = [i for i in range(5) if i not in t]
                loc = list(t) + other
                rows.append([self.edge_id(si, loc[i], loc[j])
                             for i in range(5) for j in range(i + 1, 5)])
                owner.append(hi)
                if first:
                    tri.append([self.edge_id(si, loc[1], loc[2]),
                                self.edge_id(si, loc[0], loc[2]),
                                self.edge_id(si, loc[0], loc[1])])
                    first = False
        return np.array(rows), np.array(owner), np.array(tri)

    # ---------------------------------------------------------------- checks
    def report(self):
        vols = []
        for (c, offs), s in zip(self.simp_off, self.simp):
            P = np.array(offs)
            vols.append(abs(np.linalg.det(P[1:] - P[0])))
        vols = np.array(vols)
        share = defaultdict(int)
        for (c, offs), s in zip(self.simp_off, self.simp):
            for t in it.combinations(range(5), 4):
                share[canon([s[i] for i in t], [offs[i] for i in t])] += 1
        cnt = defaultdict(int)
        for v in share.values():
            cnt[v] += 1
        return dict(nv=self.nv, ncells=len(self.cells), nsimp=len(self.simp),
                    nedges=self.ne, nhinges=self.nh,
                    minvol=float(vols.min()), maxvol=float(vols.max()),
                    total_vol=float(vols.sum() / 24.0),
                    facet_sharing=dict(cnt),
                    simp_per_vertex=len(self.simp) / self.nv,
                    edge_lengths=dict(zip(*[list(x) for x in
                                            np.unique(np.round(self.L0, 6),
                                                      return_counts=True)])))
