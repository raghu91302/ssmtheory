#!/usr/bin/env python3
"""
Regge variations on the closed periodic D4 complex.

Because the complex has no boundary, the Schlaefli identity sum_h A_h d delta_h = 0
holds exactly, which legitimises the elimination used to write the third variation
in the factorized form

    S3_abc = sum_h [ d_ac A  d_b delta + d_bc A  d_a delta + d_c A  d_ab delta ],

symmetric in (a,b,c).  Evaluating it with each slot in turn playing the role of c
must give the same number; on the open origin star it did not (-0.000001, 108.0,
108.0), and that inconsistency is what the periodic construction repairs.

Translation invariance.  On a torus the absolute edge midpoint is not well
defined, but the vertex only ever needs the momentum-conserving phase
phi = sum_i k_i . x_{e_i}, which with sum_i k_i = 0 depends only on RELATIVE
offsets inside one hinge cluster.  All phases below are therefore measured
relative to a per-hinge local origin.
"""
import numpy as np, itertools as it



def _theta(Lloc):
    """Dihedral angle at the hinge (local vertices 0,1,2) subtended by the
    four-simplex with apexes 3,4, as a function of the ten local squared edge
    lengths in (i<j) order."""
    slot = {}
    c = 0
    for i in range(5):
        for j in range(i + 1, 5):
            slot[(i, j)] = c
            c += 1
    L = lambda i, j: Lloc[..., slot[(min(i, j), max(i, j))]]
    xx = {}
    for i in range(1, 5):
        xx[(i, i)] = L(0, i)
    for i in range(1, 5):
        for j in range(i + 1, 5):
            v = 0.5 * (L(0, i) + L(0, j) - L(i, j))
            xx[(i, j)] = v
            xx[(j, i)] = v
    det = xx[(1, 1)] * xx[(2, 2)] - xx[(1, 2)] ** 2

    def perp(a, b):
        ua, va = xx[(1, a)], xx[(2, a)]
        ub, vb = xx[(1, b)], xx[(2, b)]
        return xx[(a, b)] - ((xx[(2, 2)] * ua - xx[(1, 2)] * va) * ub
                             + (-xx[(1, 2)] * ua + xx[(1, 1)] * va) * vb) / det
    cc = perp(3, 4) / np.sqrt(perp(3, 3) * perp(4, 4))
    return np.arccos(np.clip(cc, -1.0, 1.0))


class PeriodicEngine:
    def __init__(self, cx, hstep=1e-4):
        self.cx = cx
        self.h = hstep
        self.pair, self.owner, self.tri = cx.hinge_pairs()
        self.nh = cx.nh
        self.ne = cx.ne
        self.L0 = cx.L0
        self.npair = len(self.pair)
        # local offset of each edge midpoint, per (hinge,simplex) incidence,
        # measured from the hinge's own local origin
        self._build_midpoints()

    def _build_midpoints(self):
        cx = self.cx
        mids = np.zeros((self.npair, 10, 4))
        r = 0
        for hi, h in enumerate(cx.hinges):
            for (si, t) in cx.around[h]:
                other = [i for i in range(5) if i not in t]
                loc = list(t) + other
                c, offs = cx.simp_off[si]
                base = offs[loc[0]]
                q = 0
                for i in range(5):
                    for j in range(i + 1, 5):
                        mids[r, q] = 0.5 * ((offs[loc[i]] - base)
                                            + (offs[loc[j]] - base))
                        q += 1
                r += 1
        self.mid = mids                       # (npair, 10, 4)
        # edge direction vectors, indexed globally
        self.evec = cx.evec

    def build_derivs(self):
        base = self.L0[self.pair]
        h = self.h
        th = _theta
        d1 = np.zeros((self.npair, 10))
        for i in range(10):
            p = base.copy(); p[:, i] += h
            m = base.copy(); m[:, i] -= h
            d1[:, i] = (th(p) - th(m)) / (2 * h)
        d2 = np.zeros((self.npair, 10, 10))
        t0 = th(base)
        for i in range(10):
            p = base.copy(); p[:, i] += h
            m = base.copy(); m[:, i] -= h
            d2[:, i, i] = (th(p) - 2 * t0 + th(m)) / h ** 2
            for j in range(i + 1, 10):
                pp = base.copy(); pp[:, i] += h; pp[:, j] += h
                pm = base.copy(); pm[:, i] += h; pm[:, j] -= h
                mp = base.copy(); mp[:, i] -= h; mp[:, j] += h
                mm = base.copy(); mm[:, i] -= h; mm[:, j] -= h
                v = (th(pp) - th(pm) - th(mp) + th(mm)) / (4 * h ** 2)
                d2[:, i, j] = v
                d2[:, j, i] = v
        self.dth, self.d2th = d1, d2
        a, b, c = (self.L0[self.tri[:, 0]], self.L0[self.tri[:, 1]],
                   self.L0[self.tri[:, 2]])
        H = 2 * a * b + 2 * b * c + 2 * c * a - a * a - b * b - c * c
        rH = np.sqrt(H)
        gH = np.stack([2 * b + 2 * c - 2 * a, 2 * a + 2 * c - 2 * b,
                       2 * a + 2 * b - 2 * c], axis=1)
        self.A = rH / 4.0
        self.dA = gH / (8.0 * rH[:, None])
        hH = np.array([[-2., 2., 2.], [2., -2., 2.], [2., 2., -2.]])
        self.d2A = (hH[None] / (8.0 * rH[:, None, None])
                    - gH[:, :, None] * gH[:, None, :]
                    / (16.0 * rH[:, None, None] ** 3))
        return self

    # ------------------------------------------------------------ Schlaefli
    def schlaefli(self):
        """max_e | sum_h A_h d delta_h / dL_e |."""
        F = np.zeros(self.ne)
        w = -(self.A[self.owner])[:, None] * self.dth      # (npair,10)
        np.add.at(F, self.pair.ravel(), w.ravel())
        return np.abs(F).max()

    # ------------------------------------------------------------ modes
    def mode_vals(self, eps, kap):
        """p(e) = eps:d(x)d globally, and the local phase k.x for every
        (hinge,simplex,local-edge) slot."""
        p = np.einsum('ei,ij,ej->e', self.evec, eps, self.evec)
        ph = np.einsum('pqi,i->pq', self.mid, kap)
        return p, ph

    def _contract(self, specs):
        """specs: list of (p, phase-power) for the three slots.
        Returns S3 with each slot given weight p(e)*phase^n."""
        raise NotImplementedError

    def S3_phase(self, ps, phs, pows, apportion_mask=None):
        """S3(v1,v2,v3) with v_i(slot) = p_i(e) * (k_i . x)^{pows[i]},
        phases taken relative to the hinge-local origin."""
        P = self.pair
        # per-incidence slot values for each of the three modes
        V = []
        for i in range(3):
            val = ps[i][P] * (phs[i] ** pows[i] if pows[i] else 1.0)
            V.append(val)                                   # (npair,10)
        # triangle-edge (area) slots are the first three local edge slots:
        # local pairs (0,1),(0,2),(1,2) -> slot indices 0,1,4 ; Heron order (a,b,c)
        # a = L(1,2) slot 4, b = L(0,2) slot 1, c = L(0,1) slot 0
        tri_slots = [4, 1, 0]
        mask = None
        if apportion_mask is not None:
            mask = apportion_mask[P][:, tri_slots]
        out = 0.0
        for cidx in range(3):
            a, b = [t for t in range(3) if t != cidx]
            va, vb, vc = V[a], V[b], V[cidx]
            Ta = va[:, tri_slots]
            Tb = vb[:, tri_slots]
            Tc = vc[:, tri_slots]
            if mask is not None:
                Ta, Tb, Tc = Ta * mask, Tb * mask, Tc * mask
            # area factors live on the hinge; deficit factors on the incidence
            d2A = self.d2A[self.owner]
            dA = self.dA[self.owner]
            A2ac = np.einsum('pij,pi,pj->p', d2A, Ta, Tc)
            A2bc = np.einsum('pij,pi,pj->p', d2A, Tb, Tc)
            A1c = np.einsum('pi,pi->p', dA, Tc)
            db = -np.einsum('pi,pi->p', self.dth, vb)
            da = -np.einsum('pi,pi->p', self.dth, va)
            dab = -np.einsum('pij,pi,pj->p', self.d2th, va, vb)
            out += float((A2ac * db + A2bc * da + A1c * dab).sum())
        return out / 3.0

    def c2(self, ks, es, apportion_mask=None):
        ps, phs = [], []
        for i in range(3):
            p, ph = self.mode_vals(es[i], ks[i])
            ps.append(p); phs.append(ph)
        f = lambda pw: self.S3_phase(ps, phs, pw, apportion_mask)
        sq = f((2, 0, 0)) + f((0, 2, 0)) + f((0, 0, 2))
        cross = 2 * (f((1, 1, 0)) + f((0, 1, 1)) + f((1, 0, 1)))
        return -0.5 * (sq + cross), f((0, 0, 0))
