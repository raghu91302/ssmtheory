#!/usr/bin/env python3
"""Figure 1: the construction, and why truncating it fails.

Both panels are drawn in one dimension lower than the computation, and are labeled
as such: they show the mechanism, not the D4 geometry itself.

Panel (a): coning.  A 16-cell (4D cross-polytope) is coned from one antipodal
vertex pair into 8 four-simplices.  The 3D analogue, drawn here, is an octahedron
coned from an antipodal pair into 4 tetrahedra.  The construction leaves the
boundary faces whole, which is why neighbouring cells may choose their spines
independently and still agree.

Panel (b): the Schlaefli truncation.  In 2D Regge calculus the hinges are vertices
and the simplices are triangles, and the Schlaefli identity holds triangle by
triangle, summing over all three of its vertices.  The star of the origin keeps
every triangle touching O, but contributes only the O term of each; the other two
terms are discarded.  That is the incomplete cancellation measured in the paper.

    python3 emergent_make_fig1_construction.py
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyArrowPatch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['DejaVu Serif'],
    'mathtext.fontset': 'dejavuserif',
    'font.size': 9, 'axes.labelsize': 9, 'axes.titlesize': 9.5,
    'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'figure.dpi': 200, 'savefig.dpi': 400,
})
NAVY, RED, GREEN, GREY = '#1f4e79', '#c0392b', '#1e8449', '#8a8a8a'

fig = plt.figure(figsize=(7.0, 2.95))
axL = fig.add_subplot(1, 2, 1, projection='3d')
axR = fig.add_subplot(1, 2, 2)

# ------------------------------------------------------------------ panel (a)
V = {'n': np.array([0, 0, 1.0]), 's': np.array([0, 0, -1.0]),
     'a': np.array([1.0, 0, 0]), 'b': np.array([0, 1.0, 0]),
     'c': np.array([-1.0, 0, 0]), 'd': np.array([0, -1.0, 0])}
eq = ['a', 'b', 'c', 'd']
# the four tetrahedra of the coning: {n, s, e_i, e_{i+1}}
tets = [('n', 's', eq[i], eq[(i + 1) % 4]) for i in range(4)]
cols = [NAVY, '#5b8db8', NAVY, '#5b8db8']
alph = [0.34, 0.22, 0.34, 0.22]
for t, cc, al in zip(tets, cols, alph):
    P = [V[k] for k in t]
    faces = [[P[0], P[1], P[2]], [P[0], P[1], P[3]],
             [P[0], P[2], P[3]], [P[1], P[2], P[3]]]
    axL.add_collection3d(Poly3DCollection(faces, facecolor=cc, alpha=al,
                                          edgecolor='white', linewidth=0.45))
# the spine, drawn boldly
axL.plot(*zip(V['n'], V['s']), color=RED, lw=2.4, zorder=6)
# outer octahedron edges
for i in range(4):
    for p in ('n', 's'):
        axL.plot(*zip(V[eq[i]], V[p]), color=GREY, lw=0.9, alpha=0.9)
    axL.plot(*zip(V[eq[i]], V[eq[(i + 1) % 4]]), color=GREY, lw=0.9, alpha=0.9)
# internal coning edges from spine to equator
for i in range(4):
    for p in ('n', 's'):
        axL.plot(*zip(V[p], V[eq[i]]), color=NAVY, lw=0.8, ls=(0, (3, 2)),
                 alpha=0.75, zorder=5)
for k, v in V.items():
    axL.scatter(*v, s=17, color=RED if k in ('n', 's') else NAVY,
                depthshade=False, zorder=7, edgecolor='white', linewidth=0.5)
axL.text(0, 0, 1.20, 'spine', color=RED, fontsize=8.5, ha='center')
axL.text(0, 0, -1.28, '4 tetrahedra', color=NAVY, fontsize=8, ha='center')
axL.set_xlim(-0.85, 0.85); axL.set_ylim(-0.85, 0.85); axL.set_zlim(-1.0, 1.15)
axL.set_box_aspect((1, 1, 1.28))
axL.view_init(elev=20, azim=34)
axL.dist = 7.4 if hasattr(axL, 'dist') else None
axL.set_axis_off()
axL.set_title('(a) coning a cross-polytope\n3D analogue of the 16-cell',
              fontsize=9.5, pad=-14)

# ------------------------------------------------------------------ panel (b)
axR.set_aspect('equal')
O = np.array([0, 0])
ring = np.array([[np.cos(a), np.sin(a)] for a in np.linspace(0, 2 * np.pi, 7)[:6]])
for i in range(6):
    tri = np.array([O, ring[i], ring[(i + 1) % 6]])
    axR.add_patch(Polygon(tri, closed=True, facecolor=GREEN, alpha=0.13,
                          edgecolor='#4a4a4a', lw=1.0, zorder=1))
# outer ring of triangles, to show the star is a patch inside a larger complex
out = ring * 1.95
for i in range(6):
    for tri in (np.array([ring[i], ring[(i + 1) % 6], out[i]]),
                np.array([ring[(i + 1) % 6], out[i], out[(i + 1) % 6]])):
        axR.add_patch(Polygon(tri, closed=True, facecolor='none',
                              edgecolor=GREY, lw=0.6, alpha=0.45, zorder=0))
axR.scatter(*O, s=52, color=GREEN, zorder=5, edgecolor='white', linewidth=0.8)
axR.scatter(ring[:, 0], ring[:, 1], s=34, color=RED, zorder=5,
            edgecolor='white', linewidth=0.7)
axR.scatter(out[:, 0], out[:, 1], s=14, color=GREY, zorder=4, alpha=0.6)
axR.text(0.10, -0.20, r'$O$', color=GREEN, fontsize=10)
axR.annotate('kept: the $O$ term\nof every triangle', xy=(0, 0),
             xytext=(-2.35, 1.42), fontsize=7.8, color=GREEN,
             arrowprops=dict(arrowstyle='->', lw=0.8, color=GREEN,
                             shrinkB=6, connectionstyle='arc3,rad=0.22'))
axR.annotate('discarded: the other\ntwo terms of the same\ntriangles',
             xy=tuple(ring[1] * 1.0), xytext=(0.62, 1.62), fontsize=7.8,
             color=RED,
             arrowprops=dict(arrowstyle='->', lw=0.8, color=RED, shrinkB=6,
                             connectionstyle='arc3,rad=-0.2'))
axR.set_xlim(-2.45, 2.45); axR.set_ylim(-2.15, 2.35)
axR.set_axis_off()
axR.set_title('(b) what the vertex star discards\n2D analogue: hinges are vertices',
              fontsize=9.5)

fig.tight_layout(pad=0.5)
fig.subplots_adjust(wspace=0.02)
fig.savefig('emergent_fig1_construction.pdf', bbox_inches='tight')
print('emergent_fig1_construction.pdf written')
