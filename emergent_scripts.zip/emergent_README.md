# Emergent gravity from the intrinsic D4 lattice: the cubic graviton vertex

Scripts reproducing every quantitative result in *The Cubic Graviton Vertex Is
Einstein--Hilbert*. Python 3 with `numpy`, `scipy`, `sympy`, `matplotlib`. Flat
layout: run any script from this directory.

## Modules

| file | contents |
|---|---|
| `emergent_periodic_d4.py` | the closed periodic D4 complex on an L-torus: 16-cell Delaunay cells from the deep holes, coned triangulation with a selectable spine, topology and validation counts |
| `emergent_periodic_engine.py` | Regge variations on that complex: dihedral derivatives, areas, the Schlaefli residual, plane-wave modes with per-hinge local phases |
| `emergent_star.py` | the open origin star for comparison: Delaunay subdivision, Aut(D4) group average, TT polarizations, kinematic configurations |
| `emergent_eh_vertex.py` | the continuum Einstein--Hilbert cubic vertex from the Gamma-Gamma Lagrangian, independent of the lattice |
| `emergent_exact_tensors.py` | exact derivative tensors over Q(sqrt 3), one per congruence class; run as a script to build `emergent_exact_tensors.npy` |
| `emergent_exact_vertex.py` | the cubic vertex in exact integer arithmetic |

## Results

| file | reproduces |
|---|---|
| `emergent_action_selection.py` | Section 2.2: the Regge action is selected by flat-space stationarity |
| `emergent_linearized.py` | Section 5: rank-four isotropy, and the Fierz--Pauli identity on the periodic complex for generic and TT polarizations, across spine assignments |
| `emergent_cubic_vertex.py` | Section 6: c2/Nv = V_EH in double precision over 40 configurations, subdivision independence, L=6 convergence |
| `emergent_exact_vertex.py` | Eq. (13): the same identity in exact arithmetic, with vanishing sqrt3 component |
| `emergent_o4_analysis.py` | Eq. (9) and the exact rational rank tests: rank 9 = 9 for the periodic vertex, 9 vs 10 for the open star |
| `emergent_star_drift.py` | Section 3: the linear drift law and its out-of-sample prediction at N_h = 145 |
| `emergent_schlaefli.py` | the Schlaefli diagnostic: 6e-10 on the closed complex against 2.5 on the open star |
| `emergent_make_fig1_construction.py` | Figure 1: the coning construction and what the vertex star discards |
| `emergent_make_figs.py` | Figures 2 and 3: the drift, and the vertex against Einstein-Hilbert |
| `emergent_make_fig3_data.py` | data for Figure 4: the design ladder and the per-edge Schlaefli residual |
| `emergent_make_fig3.py` | Figure 4: the spherical-design ladder and the Schlaefli diagnostic |

## Order

```
python3 emergent_exact_tensors.py     # ~40 s, writes emergent_exact_tensors.npy
python3 emergent_exact_vertex.py      # exact identity, seconds
python3 emergent_action_selection.py  # seconds
python3 emergent_linearized.py        # seconds
python3 emergent_cubic_vertex.py      # ~1 min including L=6
python3 emergent_o4_analysis.py       # seconds
python3 emergent_schlaefli.py         # seconds
python3 emergent_star_drift.py        # minutes (Aut(D4) average on open stars)
python3 emergent_make_fig1_construction.py   # Figure 1
python3 emergent_make_figs.py                # Figures 2 and 3
python3 emergent_make_fig3_data.py           # data for Figure 4
python3 emergent_make_fig3.py                # Figure 4
```

`emergent_star_drift.py full` regenerates `emergent_star_base0.json` and
`emergent_star_base2.json` from scratch (about 20 minutes); both are included so
the analysis and figure scripts run immediately.

## Data

`emergent_star_base0.json`, `emergent_star_base2.json` (40 configurations on open
stars with N_h = 130 and 120), `emergent_periodic_values.json` (40 configurations
on the canonical periodic complex), `emergent_figdata_star.json`,
`emergent_figdata_periodic.json`, `emergent_figdata_design.json`,
`emergent_exact_tensors.npy`.

## Figures

`emergent_fig1_construction.pdf` (the coning construction, and what the vertex star
discards), `emergent_fig2_drift.pdf` (the extensive drift on open stars, and
subdivision independence on the closed torus), `emergent_fig3_result.pdf` (the
vertex against the continuum Einstein-Hilbert value, and the departure from O(4)
invariance), and `emergent_fig4_design.pdf` (the spherical-design ladder and the
per-edge Schlaefli residual). All four are included and are regenerated in place by
the scripts above. Figure numbering matches the paper.
