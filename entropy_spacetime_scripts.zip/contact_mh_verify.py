#!/usr/bin/env python3
"""Exact verification of the embedded contact-Hamiltonian chain.
Usage: python3 contact_mh_verify.py space.pkl [NCUT ...]"""
import sys, pickle, math, itertools, json
import numpy as np, scipy.sparse as sp
from scipy.sparse.csgraph import connected_components
from collections import Counter
from barlow import barlow_type

def build(D, NC, beta, rho):
    S = D['S']; keys = [k for k, s in S.items() if s['n'] <= NC]
    idx = {k: i for i, k in enumerate(keys)}; n = len(keys)
    B = np.array([S[k]['B'] for k in keys], float)
    W = {}; tot = np.zeros(n)
    for k in keys:
        i = idx[k]; w = {}
        if S[k]['n'] < NC:
            for k2, (st, li) in D['fwd'].get(k, {}).items():
                w[idx[k2]] = w.get(idx[k2], 0) + st + rho*li
        for k2, c in D['rev'].get(k, {}).items():
            w[idx[k2]] = w.get(idx[k2], 0) + c
        W[i] = w; tot[i] = sum(w.values()) + 1.0          # +1 hold proposal
    rows, cols, vals = [], [], []
    for i in range(n):
        for j, wij in W[i].items():
            qij = wij/tot[i]; qji = W[j][i]/tot[j]
            a = min(1.0, math.exp(beta*(B[j]-B[i])) * qji/qij)
            rows.append(i); cols.append(j); vals.append(qij*a)
    P = sp.csr_matrix((vals, (rows, cols)), shape=(n, n))
    P = P + sp.diags(1.0 - np.asarray(P.sum(1)).ravel())
    logw = beta*B; pi = np.exp(logw - logw.max()); pi /= pi.sum()
    F = sp.diags(pi) @ P
    db = abs(F - F.T).max(); stat = np.abs(pi @ P - pi).max()
    ncomp, _ = connected_components(P, directed=True, connection='strong')
    return keys, B, pi, db, stat, ncomp, P

def oct_count(P):
    P = np.asarray(P); D = np.linalg.norm(P[:, None]-P[None], axis=2); A = np.abs(D-1) < 1e-6
    c = 0
    for Sx in itertools.combinations(range(len(P)), 6):
        sub = A[np.ix_(Sx, Sx)]
        if sub.sum()//2 == 12 and (sub.sum(1) == 4).all(): c += 1
    return c

if __name__ == '__main__':
    D = pickle.load(open(sys.argv[1], 'rb'))
    cuts = [int(x) for x in sys.argv[2:]] or [D['N']]
    betas = [0, .25, .5, .75, 1, 1.25, 1.5, 2, 2.5, 3]
    out = {}
    for NC in cuts:
        keys, B, pi, db, stat, ncomp, _ = build(D, NC, 1.5, math.exp(-3))
        Bmax = B.max(); cnt = Counter((Bmax - B).astype(int))
        c0 = cnt[0]
        shat = max([math.log(cnt[m]/c0)/m for m in cnt if m > 0] or [0])
        pmax = {b: float(c0*math.exp(b*Bmax)/sum(c*math.exp(b*(Bmax-m)) for m, c in cnt.items())) for b in betas}
        kin = {}
        for rho in [1.0, 0.1, math.exp(-3)]:
            _, _, pr, dbr, str_, _, _ = build(D, NC, 1.5, rho)
            kin[round(rho, 4)] = (float(pr[B == Bmax].sum()), float(dbr), float(str_))
        maxP = [D['S'][k]['P'] for k, b in zip(keys, B) if b == Bmax]
        octs = sorted(Counter(oct_count(P) for P in maxP).items()) if NC >= 6 else []
        packing = sorted(Counter(barlow_type(P) for P in maxP).items())
        rec = dict(N=NC, states=len(keys), Bmax=int(Bmax), n_at_max=sorted(set(D['S'][k]['n'] for k, b in zip(keys, B) if b == Bmax)),
                   max_states=c0, s_hat=shat, pmax_beta_1_5=float(pi[B == Bmax].sum()),
                   db=float(db), stat=float(stat), strong_components=int(ncomp),
                   octahedra_in_maximizers=octs, packing_of_maximizers=packing, kinetic=kin, pmax_vs_beta=pmax,
                   deficit_counts={int(m): c for m, c in sorted(cnt.items())})
        out[NC] = rec
        print(json.dumps({k: v for k, v in rec.items() if k not in ('pmax_vs_beta', 'deficit_counts')}))
    json.dump(out, open(sys.argv[1].replace('.pkl', '_verify.json'), 'w'), indent=1)
