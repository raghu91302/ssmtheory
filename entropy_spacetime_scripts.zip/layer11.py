import sys, pickle, time, numpy as np
from embedded_contact_mh import forward_tuples, canonical_key, B_cont
D=pickle.load(open('space10.pkl','rb'))
par=[k for k,s in D['S'].items() if s['n']==10]; par.sort()
c,nc=int(sys.argv[1]),int(sys.argv[2]); mine=par[c::nc]
out={}; fb=0; t0=time.time()
for k in mine:
    P=np.array(D['S'][k]['P'])
    for apex,_ in forward_tuples(P):
        P2=np.vstack([P,apex]); k2,ok=canonical_key(P2); fb+=(not ok)
        if k2 not in out: out[k2]=(B_cont(P2), P2)
pickle.dump({'out':out,'fb':fb},open(f'l11_{c}.pkl','wb'))
print(c,len(mine),'parents ->',len(out),'children, fallbacks',fb,f'{time.time()-t0:.0f}s')
