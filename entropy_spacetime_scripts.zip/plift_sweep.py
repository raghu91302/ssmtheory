#!/usr/bin/env python3
"""Fine P_lift sweep of the matter-paper kinetic simulation (ssm_sim.py, unmodified).
Metrics fixed in advance: mean K; bulk-interior K=12 fraction (>=42 nodes within 2L,
the matter paper's criterion); fraction of nodes on the seed lattice.
Appends one JSON line per run to OUT.  Usage: plift_sweep.py OUT P SEED0 SEED1 [N]"""
import sys, json, random, time, numpy as np
from scipy.spatial import cKDTree
from ssm_sim import SSMSim
from stitch_inversion_analysis import on_lattice, LAM_P, LAM_M
out, p, s0, s1 = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
N = int(sys.argv[5]) if len(sys.argv) > 5 else 1000
for sd in range(s0, s1):
    t0 = time.time(); random.seed(sd); np.random.seed(sd)
    sim = SSMSim(N, p).run(); P = np.array(sim.nodes)
    deg = np.array([sim.G.degree(i) for i in range(len(P))])
    bulk = np.array([len(x) - 1 >= 42 for x in cKDTree(P).query_ball_point(P, 2.0 + 1e-6)])
    a, b = on_lattice(LAM_P, P), on_lattice(LAM_M, P)
    rec = dict(p=p, seed=sd, n=len(P), Kmean=float(deg.mean()), k12_all=float((deg == 12).mean()),
               nbulk=int(bulk.sum()), k12_bulk=float((deg[bulk] == 12).mean()) if bulk.any() else None,
               maj=float(max(a.mean(), b.mean())), secs=round(time.time() - t0, 1))
    open(out, 'a').write(json.dumps(rec) + '\n')
