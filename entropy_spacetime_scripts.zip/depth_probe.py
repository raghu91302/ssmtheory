import sys, time, numpy as np
from embedded_contact_mh import SEED, forward_tuples, is_move_apex, connected, canonical_key
def probe(NMAX, maxdepth, tlimit):
    k0,_=canonical_key(SEED); seen={k0}; frontier=[SEED]; t0=time.time()
    for d in range(1,maxdepth+1):
        nxt=[]
        for P in frontier:
            n=len(P); cands=[]
            if n<NMAX: cands += [np.vstack([P,a]) for a,_ in forward_tuples(P)]
            if n>3:
                for y in range(n):
                    Q=np.delete(P,y,axis=0)
                    if connected(Q) and is_move_apex(Q,P[y]): cands.append(Q)
            for C in cands:
                k,_=canonical_key(C)
                if k not in seen: seen.add(k); nxt.append(C)
        frontier=nxt
        byn={}
        for P in frontier: byn[len(P)]=byn.get(len(P),0)+1
        print(f"N={NMAX} depth {d}: new {len(nxt)} {dict(sorted(byn.items()))} total {len(seen)} ({time.time()-t0:.0f}s)",flush=True)
        if not nxt or time.time()-t0>tlimit: break
probe(int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3]))
