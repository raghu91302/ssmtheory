import sys, json, numpy as np, time
import ssm_bulk_analysis as B
from scipy.spatial import cKDTree
out,p,s0,s1=sys.argv[1],float(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4])
for sd in range(s0,s1):
    pos,adj,deg=B.grow_lattice(1000,seed=sd,p_lift=p); s=B.analyze_run(pos,adj,deg)
    open(out,'a').write(json.dumps(dict(p=p,seed=sd,Kmean=float(deg.mean()),k12_bulk=s['bulk_K12_frac'],k12_all=s['all_K12_frac']))+'\n')
