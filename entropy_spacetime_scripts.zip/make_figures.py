#!/usr/bin/env python3
"""Regenerate all figures of the paper from stored data, in one style.
Inputs (data/): deficit_counts.csv, kinetic_invariance.csv (history-resolved model),
embedded_deficit_counts.json (embedded contact model), plift_sweep_ssm_sim.jsonl."""
import csv, json, math, collections
import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 10, 'axes.labelsize': 10, 'legend.fontsize': 8.5,
                     'xtick.labelsize': 9, 'ytick.labelsize': 9, 'figure.dpi': 150,
                     'axes.grid': True, 'grid.alpha': 0.3, 'lines.linewidth': 1.4})
CMAP = plt.get_cmap('tab10'); MARK = 'osD^vP*X'
def col(N): return CMAP((N - 4) % 10)
def mk(N):  return MARK[(N - 4) % len(MARK)]
BETA = r'$\beta_T\epsilon$'; PMAX = r'$\pi_N(\Omega_{N,0})$'
def pmax(dc, b): return dc[0] / sum(c * math.exp(-b * m) for m, c in dc.items())

# history-resolved model: deficit counts and concentration
hist = collections.defaultdict(dict)
for r in csv.DictReader(open('data/deficit_counts.csv')):
    hist[int(r['N'])][int(r['deficit_m'])] = int(r['count'])
fig, ax = plt.subplots(figsize=(5.4, 3.5))
for N in sorted(hist):
    m = sorted(hist[N]); ax.semilogy(m, [hist[N][x] for x in m], marker=mk(N), ms=4, color=col(N), label=f'$N={N}$')
ax.set_xlabel(r'construction-bond deficit $m$'); ax.set_ylabel(r'$|\Omega_{N,m}|$')
ax.legend(frameon=False, ncol=2); fig.tight_layout(); fig.savefig('deficit_counts.pdf'); plt.close(fig)

b = np.linspace(0, 6, 300)
fig, ax = plt.subplots(figsize=(5.4, 3.5))
for N in sorted(hist):
    ax.plot(b, [pmax(hist[N], x) for x in b], color=col(N), label=f'$N={N}$')
ax.axvline(1.5, color='0.4', ls=':', lw=1)
ax.set_xlabel(BETA); ax.set_ylabel(PMAX); ax.set_ylim(0, 1.02)
ax.legend(frameon=False, loc='lower right'); fig.tight_layout(); fig.savefig('pmax_vs_beta.pdf'); plt.close(fig)

kin = collections.defaultdict(list)
for r in csv.DictReader(open('data/kinetic_invariance.csv')):
    kin[int(r['N'])].append((float(r['lift_weight']), float(r['pmax'])))
fig, ax = plt.subplots(figsize=(5.4, 3.5))
for N in sorted(kin):
    x, y = zip(*sorted(kin[N])); ax.semilogx(x, y, marker=mk(N), ms=5, color=col(N), label=f'$N={N}$')
ax.axvline(math.exp(-3), color='C3', ls='--', lw=1)
ax.text(math.exp(-3) * 1.08, 0.08, r'$\rho=e^{-3}$', color='C3', fontsize=9)
ax.set_xlabel(r'Lift proposal weight $\rho$'); ax.set_ylabel(PMAX + r' at ' + BETA + r'$=1.5$')
ax.set_xlim(0.03, 1.6); ax.set_ylim(0, 1.02); ax.legend(frameon=False, loc='center right'); fig.tight_layout()
fig.savefig('kinetic_invariance.pdf'); plt.close(fig)

# embedded contact model
emb = {int(N): {int(m): c for m, c in d.items()} for N, d in json.load(open('data/embedded_deficit_counts.json')).items()}
b = np.linspace(0, 10, 400)
fig, ax = plt.subplots(figsize=(5.4, 3.5))
for N in range(6, 12):
    ax.plot(b, [pmax(emb[N], x) for x in b], color=col(N), lw=2.0 if N >= 10 else 1.3,
            ls='-' if N >= 10 else '--', label=f'$N={N}$')
ax.set_xlabel(BETA); ax.set_ylabel(PMAX); ax.set_ylim(0, 1.02)
ax.legend(frameon=False, loc='lower right', ncol=2); fig.tight_layout(); fig.savefig('pmax_contact.pdf'); plt.close(fig)

# Lift-probability sweep
by = collections.defaultdict(list)
for l in open('data/plift_sweep_ssm_sim.jsonl'):
    r = json.loads(l); by[r['p']].append(r)
ps = np.array(sorted(by))
fig, axs = plt.subplots(1, 3, figsize=(11, 3.3))
for ax, (k, lab) in zip(axs, [('Kmean', r'mean coordination $\langle K\rangle$'),
                              ('k12_bulk', r'bulk-interior $K=12$ fraction'),
                              ('maj', 'fraction on seed lattice')]):
    v = [np.array([x[k] for x in by[p]]) for p in ps]
    ax.errorbar(ps, [a.mean() for a in v], yerr=[a.std(ddof=1) / np.sqrt(len(a)) for a in v],
                fmt='o-', ms=3.5, capsize=2, color='C0')
    ax.axvline(math.exp(-3), color='C3', ls='--', lw=1, label=r'$e^{-3}$')
    ax.set_xscale('log'); ax.set_xlabel(r'$P_{\rm lift}$'); ax.set_ylabel(lab)
axs[0].legend(frameon=False); fig.tight_layout(); fig.savefig('plift_sweep.pdf'); plt.close(fig)
print('figures written')
