#!/usr/bin/env python3
"""Exact assemblability test for a target point set.

Forward moves (stitch apex x_u+x_v-x_w, lift apexes) only add points, and
adding points only adds contact triangles, so the set of target points
reachable from a seed triangle by forward moves that stay inside the target
is a monotone closure, independent of move order. Target points are pairwise
>= L apart, so overlap exclusion never blocks a target point. A target T is
assemblable from seed S iff closure(S) == T.
"""
import itertools, numpy as np
from scipy.spatial import cKDTree
L=1.0; TOL=1e-6
def tet_apexes(a,b,c):
    cen=(a+b+c)/3; nv=np.cross(b-a,c-a); nv/=np.linalg.norm(nv); h=np.sqrt(2/3)
    return [cen+h*nv, cen-h*nv]
def closure(T, seed_idx):
    T=np.asarray(T,float); tree=cKDTree(T)
    have=set(seed_idx); nbr=[set() for _ in T]
    for i,j in tree.query_pairs(L+TOL):
        if abs(np.linalg.norm(T[i]-T[j])-L)<TOL: nbr[i].add(j); nbr[j].add(i)
    def lookup(p):
        d,k=tree.query(p); return k if d<TOL else None
    frontier=list(have)
    while frontier:
        new=[]
        for a in frontier:
            # every contact triangle containing a (all three present)
            for b,c in itertools.combinations(sorted(nbr[a]&have),2):
                if c not in nbr[b]: continue
                cands=tet_apexes(T[a],T[b],T[c])+[T[a]+T[b]-T[c],T[a]+T[c]-T[b],T[b]+T[c]-T[a]]
                for p in cands:
                    k=lookup(p)
                    if k is not None and k not in have: have.add(k); new.append(k)
        frontier=new
    return have
# ---------- lattices and clusters
def fcc_points(R):
    pts=[]
    r=int(np.ceil(R*np.sqrt(2)))+1
    for x,y,z in itertools.product(range(-r,r+1),repeat=3):
        if (x+y+z)%2==0:
            p=np.array([x,y,z])/np.sqrt(2)
            if np.linalg.norm(p)<=R+1e-9: pts.append(p)
    return np.array(pts)
def hcp_points(R):
    S3=np.sqrt(3); h=np.sqrt(2/3); pts=[]; r=int(R)+3
    for k in range(-r,r+1):
        off=(0,0) if k%2==0 else (.5,S3/6)
        for a,b in itertools.product(range(-2*r,2*r+1),repeat=2):
            p=np.array([a+.5*b+off[0], b*S3/2+off[1], k*h])
            if np.linalg.norm(p)<=R+1e-9: pts.append(p)
    return np.array(pts)
def cuboct(shells):
    P=fcc_points(shells+0.01); # all FCC points within max-norm "shell" metric
    # cuboctahedral shell k: points with FCC 'cuboctahedral norm' <= k
    Q=np.round(P*np.sqrt(2)).astype(int)
    m=np.maximum(np.abs(Q).max(1)* 1, (np.abs(Q).sum(1)+1)//2)
    return P[m<=shells]
def seed_triangle(T):
    c=np.argmin(np.linalg.norm(T,axis=1))
    d=np.linalg.norm(T-T[c],axis=1); nb=np.where(np.abs(d-L)<TOL)[0]
    for b,c2 in itertools.combinations(nb,2):
        if abs(np.linalg.norm(T[b]-T[c2])-L)<TOL: return [c,b,c2]
def test(name,T):
    s=seed_triangle(T); got=closure(T,s)
    print(f"{name:42s} n={len(T):5d}  reached {len(got):5d}  assemblable={len(got)==len(T)}")
    return got
if __name__=="__main__":
    for k in (1,2,3,4): test(f"FCC cuboctahedron, {k} shell(s)",cuboct(k))
    for R in (1.5,2.5,3.5,5.0): test(f"FCC ball radius {R}L",fcc_points(R))
    for R in (1.5,2.5,3.5,5.0): test(f"HCP ball radius {R}L",hcp_points(R))
