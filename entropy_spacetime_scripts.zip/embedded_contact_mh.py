#!/usr/bin/env python3
"""
Embedded, history-free stitch--lift chain with the contact Hamiltonian.

State: a finite point set X in R^3 (unit bond length L=1), identified up to
isometry including reflection, reachable from the unit seed triangle.
Contact triangle: three points with pairwise distances L.
Forward moves from X (only if |X| < N):
    lift   : either apex at distance L from all three points of a contact triangle
    stitch : x_u + x_v - x_w for a contact triangle (u,v,w) and each of its edges
  subject to overlap exclusion: no existing point closer than L to the apex.
State space: assemblable point sets, i.e. those obtainable from the seed by
  a sequence of forward moves (a property of the point set, not a stored
  history). Reverse moves: delete y (|X| > 3) when X\\{y} is assemblable and
  y is a forward-move apex of X\\{y}. Forward and reverse edges then pair
  exactly, and every state reaches the seed by deletions.
Proposal: each forward tuple (triangle, apex choice) has weight 1 (stitch) or
  rho (lift); each reverse candidate weight 1; one hold proposal of weight 1.
Acceptance: Metropolis--Hastings targeting pi(X) ~ exp(beta*eps*B_cont(X)).

Usage: python3 embedded_contact_mh.py NMAX OUT.pkl
"""
import sys, time, pickle, itertools
import numpy as np
from collections import defaultdict
from embedded_crossover_v1 import canonical_key, tet_apexes, dmat

L = 1.0; TOL = 1e-6
SEED = np.array([[0., 0., 0.], [1., 0., 0.], [0.5, np.sqrt(3)/2, 0.]])

def contact_matrix(P):
    return np.abs(dmat(P) - L) < TOL

def triangles(A):
    n = len(A)
    return [(i, j, k) for i, j, k in itertools.combinations(range(n), 3)
            if A[i, j] and A[i, k] and A[j, k]]

def forward_tuples(P):
    """Yield (apex, kind) for every forward tuple passing exclusion."""
    A = contact_matrix(P)
    for t in triangles(A):
        a, b, c = P[t[0]], P[t[1]], P[t[2]]
        for apex in tet_apexes(a, b, c):
            if np.min(np.linalg.norm(P - apex, axis=1)) >= L - TOL:
                yield apex, 'lift'
        for u, v, w in ((a, b, c), (a, c, b), (b, c, a)):
            apex = u + v - w
            if np.min(np.linalg.norm(P - apex, axis=1)) >= L - TOL:
                yield apex, 'stitch'

def is_move_apex(Q, y):
    """Is y a lift or stitch apex of some contact triangle of Q?"""
    d = np.linalg.norm(Q - y, axis=1)
    nb = np.where(np.abs(d - L) < TOL)[0]
    A = contact_matrix(Q)
    for i, j in itertools.combinations(nb, 2):
        if not A[i, j]: continue
        for k in np.where(A[i] & A[j])[0]:
            if k in nb:                                   # lift apex
                return True
            if abs(np.linalg.norm(Q[k] - y) - np.sqrt(3)*L) < TOL:
                return True                               # stitch apex, opposite k
    return False

def B_cont(P):
    return int(contact_matrix(P).sum() // 2)

def connected(P):
    A = contact_matrix(P); n = len(P); seen = {0}; st = [0]
    while st:
        i = st.pop()
        for j in np.where(A[i])[0]:
            if j not in seen: seen.add(j); st.append(j)
    return len(seen) == n

def enumerate_space(NMAX):
    """Assemblable configurations: point sets obtainable from the seed by a
    sequence of forward moves, with at most NMAX points. Reverse moves delete
    y when X\\{y} is itself assemblable and y is a forward-move apex of it.
    (Without the assemblability restriction the component is infinite: see
    depth_probe.py.)"""
    k0, _ = canonical_key(SEED)
    S = {k0: {'P': SEED, 'n': 3}}
    layers = {3: [k0]}; fwd = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    fallbacks = 0
    for n in range(3, NMAX):
        t0 = time.time(); new = []
        for k in layers[n]:
            P = S[k]['P']
            for apex, kind in forward_tuples(P):
                P2 = np.vstack([P, apex]); k2, ok = canonical_key(P2)
                fallbacks += (not ok)
                if k2 not in S:
                    S[k2] = {'P': P2, 'n': n+1}; new.append(k2)
                fwd[k][k2][0 if kind == 'stitch' else 1] += 1
        layers[n+1] = new
        print(f"  n={n+1}: {len(new)} states ({time.time()-t0:.0f}s)", flush=True)
    t0 = time.time()
    rev = defaultdict(lambda: defaultdict(int)); bad = 0
    for k, s in S.items():
        s['B'] = B_cont(s['P'])
        if s['n'] == 3: continue
        P = s['P']
        for y in range(len(P)):
            Q = np.delete(P, y, axis=0); kq, _ = canonical_key(Q)
            if kq in S and is_move_apex(Q, P[y]):
                rev[k][kq] += 1
    fwd = {k: dict(v) for k, v in fwd.items()}; rev = {k: dict(v) for k, v in rev.items()}
    bad = sum(1 for k, d in fwd.items() for k2 in d if k not in rev.get(k2, {})) + \
          sum(1 for k, d in rev.items() for k2 in d if k not in fwd.get(k2, {}))
    print(f"  reverse moves ({time.time()-t0:.0f}s)", flush=True)
    return S, fwd, rev, fallbacks, bad

if __name__ == '__main__':
    NMAX = int(sys.argv[1]); out = sys.argv[2]
    S, fwd, rev, fb, bad = enumerate_space(NMAX)
    for s in S.values(): s['P'] = s['P'].tolist()
    pickle.dump({'N': NMAX, 'S': S, 'fwd': fwd, 'rev': rev, 'fallbacks': fb, 'bad_rev': bad}, open(out, 'wb'))
    print(f"total states {len(S)}, canonicalization fallbacks {fb}, reverse-without-forward {bad}")
