#!/usr/bin/env python3
"""Assemblability of FCC balls (radius 5L) with interior vacancies.
Usage: python3 vacancy_tests.py sep|clu TRIALS RNGSEED
  sep: pairwise non-adjacent interior vacancies (2-79 requested)
  clu: one compact interior vacancy cluster of 1-12 sites
A configuration is assemblable if the monotone closure from some contact
triangle reaches every point (assemble.closure); the seed tried first is the
contact triangle nearest the centre, then up to 10 further triangles."""
import numpy as np, itertools, sys, time
from assemble import closure, fcc_points
from scipy.spatial import cKDTree
def triangles(T):
    tree=cKDTree(T); nb={}
    for i,j in tree.query_pairs(1+1e-6): nb.setdefault(i,set()).add(j); nb.setdefault(j,set()).add(i)
    for i in np.argsort(np.linalg.norm(T,axis=1)):
        for b,c in itertools.combinations(sorted(nb.get(i,())),2):
            if c in nb.get(b,()): yield [i,b,c]; break
def assemblable(T, tries=11):
    for k,s in enumerate(triangles(T)):
        if len(closure(T,s))==len(T): return True, k
        if k+1>=tries: break
    return False, tries
if __name__=="__main__":
    mode=sys.argv[1]; trials=int(sys.argv[2]); rng=np.random.default_rng(int(sys.argv[3]))
    B=fcc_points(5.0); tree=cKDTree(B); r=np.linalg.norm(B,axis=1)
    interior=[i for i in range(len(B)) if r[i]<3.5]
    nbrs={i:set(tree.query_ball_point(B[i],1+1e-6))-{i} for i in range(len(B))}
    ok=0; ks=[]; retried=0; t0=time.time()
    for t in range(trials):
        if mode=='sep':
            vac=[]; target=rng.integers(1,80)
            for i in rng.permutation(interior):
                if len(vac)>=target: break
                if not (nbrs[i]&set(vac)): vac.append(i)
        else:
            cl={int(rng.choice(interior))}
            for _ in range(rng.integers(1,12)): cl|={int(rng.choice(list(nbrs[int(rng.choice(list(cl)))])))}
            vac=[c for c in cl if r[c]<3.5]
        a,k=assemblable(np.delete(B,vac,axis=0)); ok+=a; retried+=(k>0); ks.append(len(vac))
    print(mode,f"{ok}/{trials} assemblable ({retried} needed a second seed), vacancies {min(ks)}-{max(ks)}, N={len(B)} ({time.time()-t0:.0f}s)")
