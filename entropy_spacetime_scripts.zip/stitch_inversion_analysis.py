#!/usr/bin/env python3
"""
Stitch-inversion analysis of the kinetic SSM growth simulation.

Uses the unmodified reference implementation ssm_sim.py of
R. Kulkarni, Physics Open 27 (2026) 100423, and measures:
  (1) stacking triplets (cubic vs hexagonal) of close-packed layers;
  (2) the move that nucleates each new layer;
  (3) the move that creates the first node off the seed lattice;
  (4) seed-plane twins;
  (5) seed-lattice fraction vs P_lift and vs distance from the seed,
      over all nodes and over bulk-interior nodes (>=42 nodes within 2L).
Moves are recorded by subclassing; no simulation rule is changed.

Usage: python3 stitch_inversion_analysis.py OUT.json P_LIFT SEED0 SEED1 [N]
"""
import sys, json, random
import numpy as np
from collections import Counter
from scipy.spatial import cKDTree
from ssm_sim import SSMSim

H = np.sqrt(2/3); S3 = np.sqrt(3)
E1 = np.array([1., 0, 0]); E2 = np.array([.5, S3/2, 0])
LAM_P = np.array([E1, E2, [.5, S3/6,  H]]).T   # lattice of the up-lift
LAM_M = np.array([E1, E2, [.5, S3/6, -H]]).T   # its mirror (down-lift)

def on_lattice(B, P, tol=1e-3):
    c = np.linalg.solve(B, P.T).T
    return np.all(np.abs(c - np.round(c)) < tol, axis=1)

class Traced(SSMSim):
    def __init__(s, *a, **k):
        super().__init__(*a, **k); s.origin = {}
    def _stitch_lateral(s, edge, tree):
        u, v = edge
        fb = not any(u in t and v in t for t in s.active_triangles)
        n0 = len(s.nodes); ok = super()._stitch_lateral(edge, tree)
        if ok: s.origin[n0] = ('stitch-fallback' if fb else 'stitch', edge)
        return ok
    def _lift_triangle(s, tri, tree):
        n0 = len(s.nodes); ok = super()._lift_triangle(tri, tree)
        if ok: s.origin[n0] = ('lift', tri)
        return ok

def registries(P, on):
    """Majority close-packed registry (0,1,2) of each horizontal layer."""
    k = np.round(P[:, 2] / H).astype(int)
    out = {}
    for L in np.unique(k[on]):
        m = on & (k == L)
        if m.sum() < 10: continue
        v = P[m, 1] / (S3/2); u = P[m, 0] - 0.5*v
        out[int(L)] = int(Counter(np.round(3*u).astype(int) % 3).most_common(1)[0][0])
    return out

def run(p, sd, N):
    random.seed(sd); np.random.seed(sd)
    sim = Traced(N, p).run(); P = np.array(sim.nodes)
    a, b = on_lattice(LAM_P, P), on_lattice(LAM_M, P)
    m = a if a.sum() >= b.sum() else b
    r = {'seed': sd, 'n': len(P), 'maj': float(m.mean()),
         'Kmean': float(np.mean([d for _, d in sim.G.degree()])),
         'moves': dict(Counter(v[0] for v in sim.origin.values()))}
    off = np.where(~m)[0]
    r['first_off'] = None
    if len(off):
        i = int(off[0]); kind, par = sim.origin.get(i, ('seed', ()))
        r['first_off'] = {'move': kind, 'parents_on_lattice': bool(all(m[j] for j in par))}
    # stacking measured on ALL nodes lying in horizontal layers
    # (independent of the lattice classification above)
    lay = np.round(P[:, 2] / H).astype(int)
    inlayer = np.abs(P[:, 2] / H - lay) < 0.05
    R = registries(P, inlayer)
    first = {}
    for i in range(len(P)):
        if inlayer[i]: first.setdefault(int(lay[i]), i)
    trip = []
    for L in sorted(R):
        if L-1 in R and L+1 in R:
            x, y, z = R[L-1], R[L], R[L+1]
            if x == y or y == z: continue
            trip.append({'layer': L, 'type': 'cubic' if x != z else 'hex'})
    r['triplets'] = trip
    r['layer_nucleation'] = dict(Counter(
        sim.origin[i][0] for L, i in first.items() if L != 0 and i in sim.origin))
    # radial seed-lattice fraction, all nodes and bulk interior
    rad = np.linalg.norm(P - P[:3].mean(0), axis=1)
    bulk = np.array([len(x) - 1 >= 42 for x in cKDTree(P).query_ball_point(P, 2.0 + 1e-6)])
    edges = [0, 2, 4, 6, 8, 1e9]; sh = np.digitize(rad, edges) - 1
    r['shells'] = [[int((sh == s).sum()), int(m[sh == s].sum()),
                    int((bulk & (sh == s)).sum()), int((m & bulk & (sh == s)).sum())]
                   for s in range(5)]
    return r

if __name__ == '__main__':
    out, p, s0, s1 = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    N = int(sys.argv[5]) if len(sys.argv) > 5 else 1000
    res = [run(p, sd, N) for sd in range(s0, s1)]
    json.dump({'p_lift': p, 'N': N, 'runs': res}, open(out, 'w'))
    print(out, 'done')
