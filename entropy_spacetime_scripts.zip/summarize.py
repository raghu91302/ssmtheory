import json, numpy as np
from collections import Counter
def load(fs):
    R=[]
    for f in fs: R+=json.load(open(f))['runs']
    return R
def summ(R, label):
    trip=Counter(); seedtrip=Counter(); nuc=Counter(); first=Counter(); moves=Counter()
    sh=np.zeros((5,4))
    for r in R:
        for t in r['triplets']:
            (seedtrip if t['layer']==0 else trip)[t['type']]+=1
        nuc.update(r['layer_nucleation']); moves.update(r['moves'])
        fo=r['first_off']; first[(fo['move'],fo['parents_on_lattice']) if fo else 'none']+=1
        sh+=np.array(r['shells'])
    maj=np.array([r['maj'] for r in R]); K=np.array([r['Kmean'] for r in R])
    print(f"== {label}: runs={len(R)}")
    allt=trip+seedtrip; c,h=allt['cubic'],allt['hex']
    print(f" triplets all: cubic {c}, hex {h}, cubic frac {c/(c+h):.3f}")
    print(f" non-seed: {dict(trip)}   seed-plane: {dict(seedtrip)}")
    print(f" layer nucleation: {dict(nuc)}")
    print(f" first off-lattice: {dict(first)}")
    print(f" moves: {dict(moves)}")
    print(f" maj {maj.mean():.3f} +/- {maj.std(ddof=1):.3f}  Kmean {K.mean():.2f} +/- {K.std(ddof=1):.2f}")
    for s,lab in enumerate(['0-2','2-4','4-6','6-8','>8']):
        n,m,nb,mb=sh[s]
        print(f"  r {lab}: all {m/max(n,1):.3f} (n={int(n)})  bulk {mb/max(nb,1):.3f} (n={int(nb)})")
summ(load(['r05_a.json','r05_b.json']),'P=0.05')
summ(load(['r01.json']),'P=0.01')
summ(load(['r20.json']),'P=0.20')
