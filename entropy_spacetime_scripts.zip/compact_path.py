#!/usr/bin/env python3
"""Shell-by-shell assembly of the FCC ball of radius 8L by monotone closure,
recording max over intermediate N>=20 of (6N-B)/N^(2/3) (the constant C_0)."""
import numpy as np, itertools
from scipy.spatial import cKDTree
from assemble import fcc_points, tet_apexes, seed_triangle
TOL=1e-6
T=fcc_points(8.0); tree=cKDTree(T); r=np.linalg.norm(T,axis=1)
nbr=[set() for _ in T]
for i,j in tree.query_pairs(1+TOL): nbr[i].add(j); nbr[j].add(i)
def lookup(p):
    d,k=tree.query(p); return k if d<TOL else None
have=set(seed_triangle(T)); B=3; N=3; worst=0
for R in np.arange(1.0,8.01,0.5):
    allowed=r<=R+1e-9; frontier=list(have)
    while frontier:
        new=[]
        for a in frontier:
            for b,c in itertools.combinations(sorted(nbr[a]&have),2):
                if c not in nbr[b]: continue
                for p in tet_apexes(T[a],T[b],T[c])+[T[a]+T[b]-T[c],T[a]+T[c]-T[b],T[b]+T[c]-T[a]]:
                    k=lookup(p)
                    if k is not None and allowed[k] and k not in have:
                        B+=len(nbr[k]&have); have.add(k); N+=1; new.append(k)
                        if N>=20: worst=max(worst,(6*N-B)/N**(2/3))
        frontier=new
print(f"assembled {N} of {len(T)}; C_0 = max (6N-B)/N^(2/3) over 20<=N<={N}: {worst:.2f}; final {(6*N-B)/N**(2/3):.2f}")
