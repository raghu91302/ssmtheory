# Scripts for "Entropy-Producing Crystallization Selects a Flat Spatial Vacuum"

Every script below is listed, with its SHA-256 hash, in Appendix D of the paper.
All files sit at the root of `https://github.com/raghu91302/ssmtheory`, which is where the paper links.
Three scripts carry an `entropy_` prefix because the root already holds different scripts with
their original names, which belong to another manuscript. This file is named
`entropy_spacetime_README.md` so that it does not replace the repository README.
Requirements: Python 3, NumPy, SciPy, NetworkX, Matplotlib.
Run all commands from this folder.

## Contents

| Paper item | Script | Command | Time |
|---|---|---|---|
| History-resolved model, Table 3, data for Figs. 2-4 | `entropy_run_finite_verification.py` (uses `entropy_finite_verification.py`) | `python3 entropy_run_finite_verification.py` | ~10 s |
| Construction vs contact bonds, Table 2 | `entropy_embedded_crossover.py` | `python3 entropy_embedded_crossover.py 11` (use `12` for n = 12: ~20 min, several GB) | ~2 min |
| Embedded contact model, state space | `embedded_contact_mh.py` | `python3 embedded_contact_mh.py 10 space10.pkl` | ~2 min |
| Embedded contact model, verification, Table 4 | `contact_mh_verify.py` (uses `barlow.py`) | `python3 contact_mh_verify.py space10.pkl 4 5 6 7 8 9 10` | ~4 min |
| Contact-deficit counts at n = 11 | `layer11.py` | `python3 layer11.py C 4` for C = 0,1,2,3 (needs `space10.pkl`) | ~75 s each |
| Infinite closure, Remark 3.7 | `depth_probe.py` | `python3 depth_probe.py 5 26 300` | ~1.5 min |
| Assemblability, Appendix B | `assemble.py` | `python3 assemble.py` | ~1 min |
| Vacancy tests, Appendix B | `vacancy_tests.py` | `python3 vacancy_tests.py sep 30 1` and `python3 vacancy_tests.py clu 30 2` | ~2 min each |
| Constant C_0, Appendix B | `compact_path.py` | `python3 compact_path.py` | ~15 s |
| Growth simulation, Section 15 | `stitch_inversion_analysis.py` (runs `ssm_sim.py` unmodified) | `python3 stitch_inversion_analysis.py r05_a.json 0.05 0 15` (see note) | ~10 s per run |
| Tables 5-6 from growth runs | `summarize.py` | `python3 summarize.py` | seconds |
| Lift-probability sweep, Fig. 6 | `plift_sweep.py` | `python3 plift_sweep.py OUT.jsonl P SEED0 SEED1` | ~1.5 s per run |
| Sweep, second implementation | `variant_sweep.py` (uses `ssm_bulk_analysis.py`) | `python3 variant_sweep.py OUT.jsonl P SEED0 SEED1` | ~8 s per run |
| All figures (including the move diagram, Fig. 1) | `make_figures.py` | `python3 make_figures.py` | seconds |

## Notes

- `ssm_sim.py` and `ssm_bulk_analysis.py` are the reference implementations from the companion
  matter paper (Physics Open 27, 100423). They are included unmodified and are identical to the copies already at the repository root. `ssm_bulk_analysis.py`
  is needed only by `variant_sweep.py` and is not listed in Appendix D.
- Growth runs used for Tables 5-6:
  `r05_a.json` (P = 0.05, seeds 0-14), `r05_b.json` (P = 0.05, seeds 15-29),
  `r01.json` (P = 0.01, seeds 0-14), `r20.json` (P = 0.20, seeds 0-14).
  The stored files are included, so `summarize.py` runs directly.
- Inputs of `make_figures.py`: `deficit_counts.csv` and `kinetic_invariance.csv` (history model),
  `embedded_deficit_counts.json` (embedded-model contact-deficit counts for N = 4-11), and
  `plift_sweep_ssm_sim.jsonl` (the 640-run lift sweep).
- Stored results: `space10_verify.json` and `space11_counts.json` (embedded-model verification)
  and `plift_sweep_bulk_script.jsonl` (sweep of the second implementation).
- All enumerations are exact and deterministic. All growth runs use fixed random seeds.
