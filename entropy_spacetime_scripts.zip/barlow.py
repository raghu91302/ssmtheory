import numpy as np, itertools
H=np.sqrt(2/3); S3=np.sqrt(3)
def barlow_type(P, tol=1e-5):
    """Return None if P is not a subset of any Barlow close packing; otherwise
    'fcc', 'hcp', 'mixed', or 'ambiguous' (fewer than 3 occupied adjacent layers),
    trying every contact triangle as a basal plane."""
    P=np.asarray(P); D=np.linalg.norm(P[:,None]-P[None],axis=2); A=np.abs(D-1)<1e-6
    found=set()
    for i,j,k in itertools.combinations(range(len(P)),3):
        if not(A[i,j] and A[i,k] and A[j,k]): continue
        e1=P[j]-P[i]; e2=P[k]-P[i]; nrm=np.cross(e1,e2); nrm/=np.linalg.norm(nrm)
        X=P-P[i]; z=X@nrm/H
        if np.any(np.abs(z-np.round(z))>tol): continue
        # lattice coords in the basal triangular lattice spanned by e1,e2
        M=np.array([e1,e2]).T; uv=np.linalg.lstsq(M,(X-np.outer(X@nrm,nrm)).T,rcond=None)[0].T
        t=3*uv
        if np.any(np.abs(t-np.round(t))>tol): continue
        t=np.round(t).astype(int)%3
        if np.any(t[:,0]!=t[:,1]): continue
        layer=np.round(z).astype(int); reg={}
        ok=True
        for L,r in zip(layer,t[:,0]):
            if reg.setdefault(L,r)!=r: ok=False;break
        if not ok: continue
        if any(L+1 in reg and reg[L]==reg[L+1] for L in reg): continue
        trip=[('c' if reg[L-1]!=reg[L+1] else 'h') for L in reg if L-1 in reg and L+1 in reg]
        typ='ambiguous' if not trip else ('fcc' if set(trip)=={'c'} else 'hcp' if set(trip)=={'h'} else 'mixed')
        found.add(typ)
    if not found: return 'not close-packed'
    if found-{'ambiguous'}: found-= {'ambiguous'}
    return '/'.join(sorted(found))
