# Architecture Paper — Repository-Side Verification & Sweep Scripts

This directory contains the verification and threshold-sweep scripts referenced from the architecture paper *"A Hybrid Atom-Array Architecture for Universal Quantum Computation"*. Together with the structural-verification scripts already bundled with the paper (`ribbon_construction.py`, `triangle_ribbon_analysis.py`), these scripts complete the paper's reproducibility chain.

## File inventory

### Lattice modules (imported by the verification scripts)
- `sheet_code_fcc_lattice.py` — FCC lattice and triad decomposition (toric).
- `sheet_code_planar_lattice.py` — planar variant of the FCC lattice.

### Structural verification scripts (exact; verified at L=4,6,8)
- `verify_css_isomorphism.py` — Computational Result 1: the threefold rotation R is a CSS isomorphism with a (2L)×(2L) symplectic-permutation logical action. Runs at L=4,6; pass `--with-L8` to also verify at L=8.

  ```
  python3 verify_css_isomorphism.py [--with-L8]
  ```

- `verify_layer_decomposition.py` — Theorem 2: each triad sheet decomposes into L disjoint 2D toric codes. Verifies at L=4,6,8 that each layer has parameters [[L², 2, L]] and that the full sheet has parameters [[L³, 2L, L]].

  ```
  python3 verify_layer_decomposition.py
  ```

- `verify_cross_sheet_reachability.py` — Computational Result 3: the triangle-product space has dimension 6L-3 modulo stabilizers, spanned by two-sheet-supported elements. Runs at L=4,6; pass `--with-L8` for L=8.

  ```
  python3 verify_cross_sheet_reachability.py [--with-L8]
  ```

### Threshold sweep scripts

- `sweep_memory_threshold.py` — Memory threshold sweep. **Exact**: by the layer decomposition theorem, each FCC triad sheet is L stacked 2D toric codes, so Stim's surface-code memory experiment is the correct circuit.

  ```
  python3 sweep_memory_threshold.py [--shots 10000] [--out memory_shots.json]
  ```

- `sweep_zz_merge_threshold.py` — Cross-sheet ZZ-merge threshold sweep. **Harness**: provides the sweep loop and JSON output format. The default circuit is a 2D surface-code proxy; to reproduce the paper's exact ZZ-merge thresholds (1.07% toric, 0.76% planar) replace `build_zz_merge_circuit()` with the FCC ribbon Stim circuit. See the docstring of that function for the required circuit structure.

  ```
  python3 sweep_zz_merge_threshold.py --variant toric  [--shots 10000]
  python3 sweep_zz_merge_threshold.py --variant planar [--shots 10000]
  ```

- `sweep_transversal_cnot_threshold.py` — Transversal-CNOT threshold sweep. **Harness**: same pattern as the ZZ-merge sweep. The default circuit is a 2D surface-code proxy; replace `build_transversal_cnot_circuit()` to reproduce the paper's exact numbers (memory threshold with CNOT layer approximately 1.04%; R3 distance scaling).

  ```
  python3 sweep_transversal_cnot_threshold.py [--no-cnot] [--shots 10000]
  ```

### Figure generation

- `make_fig_threshold.py` — Read the JSON outputs of the sweep scripts and produce Figure 2 (threshold simulation) of the architecture paper.

  ```
  python3 make_fig_threshold.py \
      --with-cnot transversal_cnot_with_cnot_shots.json \
      --without-cnot transversal_cnot_without_cnot_shots.json \
      --memory memory_shots.json \
      --out fig_threshold.pdf
  ```

## Dependencies

- Python 3.8+
- `numpy`, `matplotlib`
- `stim` 1.16+ (for threshold sweeps)
- `pymatching` 2.0+ (for threshold-sweep decoding)

The structural-verification scripts only need numpy.

## Status of each script

| Script | Status | What it verifies |
|---|---|---|
| `verify_css_isomorphism.py` | **Exact**, runs and passes at L=4,6,8 | Computational Result 1 |
| `verify_layer_decomposition.py` | **Exact**, runs and passes at L=4,6,8 | Theorem 2 |
| `verify_cross_sheet_reachability.py` | **Exact**, runs and passes at L=4,6 | Computational Result 3 |
| `sweep_memory_threshold.py` | **Exact** (per layer decomposition) | Memory threshold ~1% |
| `sweep_zz_merge_threshold.py` | **Harness with proxy default** | ZZ-merge threshold (paper: 1.07%/0.76%) — requires user's FCC ribbon circuit |
| `sweep_transversal_cnot_threshold.py` | **Harness with proxy default** | CNOT-layer threshold (paper: ~1.04%) — requires user's FCC transversal CNOT circuit |
| `make_fig_threshold.py` | **Exact** | Figure 2 reproduction from JSON sweep data |

The harness scripts print a clear runtime warning when the default proxy circuit is being used.

## Mapping to paper claims

| Paper claim | Verifying script |
|---|---|
| Computational Result 1 (CSS isomorphism) at L=4,6,8 | `verify_css_isomorphism.py` |
| Theorem 2 (layer decomposition into stacked 2D toric codes) at L=4,6,8 | `verify_layer_decomposition.py` |
| Computational Result 3 (cross-sheet reachability, 6L-3) at L=4,6 | `verify_cross_sheet_reachability.py` |
| Memory threshold ~ 1% | `sweep_memory_threshold.py` |
| ZZ-merge threshold (toric) 1.07(5)% | `sweep_zz_merge_threshold.py --variant toric` (after replacing the proxy circuit) |
| ZZ-merge threshold (planar) 0.76(5)% | `sweep_zz_merge_threshold.py --variant planar` (after replacing the proxy) |
| Transversal-CNOT layer preserves memory threshold (R1) | `sweep_transversal_cnot_threshold.py` (after replacing the proxy) |
| Distance scaling (R3) | `sweep_transversal_cnot_threshold.py` (after replacing the proxy) |
| Figure 2 reproduction | `make_fig_threshold.py` |
