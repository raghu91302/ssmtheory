import numpy as np, json, time
from fcc_surgery_circuit import build_zz_merge
from bposd_decode import make_decoder
def ler(L,p,shots,seed):
    c,_=build_zz_merge(L,p)
    dec,O=make_decoder(c)
    det,obs=c.compile_detector_sampler(seed=seed).sample(shots,separate_observables=True)
    ne=0
    for i in range(shots):
        eh=dec.decode(det[i].astype(np.uint8)); ne+=int(np.any((O@eh)%2!=obs[i]))
    return ne/shots,ne
t0=time.time()
ps=[0.006,0.008,0.010,0.012]
out={'p':ps,'curves':{},'decoder':'BP+OSD'}
for L,sh in [(4,2500),(6,1500),(8,700)]:
    row=[]
    for p in ps:
        r=ler(L,p,sh,seed=9000+L); row.append(dict(p=p,ler=r[0],nerr=r[1],shots=sh))
        print(f"surgery(BPOSD) L={L} p={p}: {r[0]:.4f}  [{time.time()-t0:.0f}s]",flush=True)
    out['curves'][str(L)]=row
json.dump(out,open('data_surgery_real.json','w'),indent=1)
print(f"done {time.time()-t0:.0f}s")
