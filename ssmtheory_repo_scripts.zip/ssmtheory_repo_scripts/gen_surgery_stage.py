import numpy as np, json, time, sys, os
from fcc_surgery_circuit import build_zz_merge
from bposd_decode import make_decoder
L=int(sys.argv[1]); shots=int(sys.argv[2]); ps=[float(x) for x in sys.argv[3:]]
PATH='data_surgery_real.json'
out=json.load(open(PATH)) if os.path.exists(PATH) else {'p':[0.006,0.008,0.010,0.011,0.012],'curves':{},'decoder':'BP+OSD'}
out.setdefault('curves',{}); cur={r['p']:r for r in out['curves'].get(str(L),[])}
t0=time.time()
for p in ps:
    c,_=build_zz_merge(L,p); dec,O=make_decoder(c)
    det,obs=c.compile_detector_sampler(seed=12000+L).sample(shots,separate_observables=True)
    ne=sum(int(np.any((O@dec.decode(det[i].astype(np.uint8)))%2!=obs[i])) for i in range(shots))
    cur[p]=dict(p=p,ler=ne/shots,nerr=ne,shots=shots)
    print(f"L={L} p={p}: {ne/shots:.4f} ({ne}/{shots})  [{time.time()-t0:.0f}s]",flush=True)
    out['curves'][str(L)]=[cur[k] for k in sorted(cur)]
    json.dump(out,open(PATH,'w'),indent=1)   # incremental save
print("saved")
