"""Quantitative comparison: FCC triangle-ribbon ZZ-merge vs surface-code cross-layer surgery.

For each L in {4, 6, 8}:

1. Build the FCC lattice on the toric L^3.
2. Identify minimum-weight cross-sheet logicals (weight 2L: L per sheet).
3. Find an explicit length-L triangle ribbon expressing the joint Z_A o Z_B measurement.
4. Count atoms: ancillas (one per triangle on the ribbon), data atoms touched
   (3 per triangle, but already part of the code).
5. Compare to the equivalent surface-code primitive: two L^2-distance surface-code
   patches in different "layers" needing a routing channel of length L between them.
6. Tabulate the comparison.

The comparison is on "atoms added by the merge" -- atoms that are not part of the
underlying memory but are reserved for the duration of the merge operation. This is
the figure of merit for how many parallel merges a fixed atom budget can support.
"""
import sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sheet_code_fcc_lattice import build_fcc_lattice, NN_DISPLACEMENTS, SHEETS
import numpy as np
from itertools import combinations
from collections import defaultdict


def find_triangles(L):
    """Enumerate FCC triangles (3-cycles) on the toric lattice.

    By Lemma in the paper, every triangle has one edge in each of the three sheets.

    Returns:
        triangles: list of {'verts': (i,j,k), 'edges': {sheet: edge}, 'center': (x,y,z)}
        per L=4: 4L^3 = 256 triangles
    """
    vertices, vidx, edges_per_sheet, edge_list, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)
    
    # Build adjacency: for each vertex, what edges in each sheet
    vert_to_edges = {s: defaultdict(list) for s in SHEETS}
    for s in SHEETS:
        for e in edges_per_sheet[s]:
            i, j = e
            vert_to_edges[s][i].append(e)
            vert_to_edges[s][j].append(e)
    
    # A triangle has 3 vertices i, j, k, with edges in three different sheets
    triangles = []
    seen = set()
    for vp in vertices:
        i = vidx[vp]
        x, y, z = vp
        # Look at all FCC nearest neighbors of i
        nbrs = {}  # neighbor -> sheet
        for s, dirs in NN_DISPLACEMENTS.items():
            for d in dirs:
                wp = ((x + d[0]) % L, (y + d[1]) % L, (z + d[2]) % L)
                j = vidx[wp]
                nbrs[j] = s
        # For each pair of distinct neighbors j, k where j-k is also an FCC edge
        for j, sij in nbrs.items():
            for k, sik in nbrs.items():
                if j >= k:
                    continue
                if sij == sik:
                    continue  # i-j and i-k must be in different sheets
                # Is j-k an FCC edge?
                vj, vk = vertices[j], vertices[k]
                dj = ((vk[0] - vj[0]) % L, (vk[1] - vj[1]) % L, (vk[2] - vj[2]) % L)
                # Normalize to nearest-neighbor (account for wraparound)
                dj_normalized = tuple((c if c <= L//2 else c - L) for c in dj)
                sjk = None
                for s, dirs in NN_DISPLACEMENTS.items():
                    if dj_normalized in dirs:
                        sjk = s
                        break
                if sjk is None:
                    continue
                # Must be 3 distinct sheets
                if len({sij, sik, sjk}) != 3:
                    continue
                tri_verts = tuple(sorted([i, j, k]))
                if tri_verts in seen:
                    continue
                seen.add(tri_verts)
                # Identify edges
                e_ij = (min(i, j), max(i, j))
                e_ik = (min(i, k), max(i, k))
                e_jk = (min(j, k), max(j, k))
                tri_edges = {
                    sij: e_ij,
                    sik: e_ik,
                    sjk: e_jk,
                }
                # Center for layout purposes
                cx = (vp[0] + vj[0] + vk[0]) / 3.0
                cy = (vp[1] + vj[1] + vk[1]) / 3.0
                cz = (vp[2] + vj[2] + vk[2]) / 3.0
                triangles.append({
                    'verts': tri_verts,
                    'edges': tri_edges,
                    'center': (cx, cy, cz),
                })
    return triangles, edge_to_idx, edge_to_sheet, vertices


def cross_sheet_zz_ribbon_length(L):
    """Return the length of our explicit cross-sheet ZZ ribbon construction.

    Strategy: pick the two minimum-weight Z-logicals from two adjacent sheets
    (weight L each, lying within one z-layer of each sheet), find triangles whose
    Z-edge product reproduces the union.

    For a clean analytical answer, we use the fact:
    - Minimum Z-logical on sheet S_xy at layer z=0 is a horizontal cycle of length L.
    - The equivalent on S_xz at y=0 is also length L.
    - To "lift" the first to the second via triangle products, we need triangles that
      have one S_xy edge on the first cycle and one S_xz edge on the second cycle.
    - The third sheet's edges (S_yz) must cancel pairwise across the ribbon.

    Our explicit construction uses L triangles, with L S_xy edges forming the
    first logical, L S_xz edges forming the second logical, and L S_yz edges that
    cancel pairwise (each appearing twice on the ribbon, contributing 0 mod 2).

    Whether L triangles is the global minimum across all valid ribbons connecting
    the same logical pair is an open question. This function returns the length
    of our explicit construction, NOT a proven global minimum.

    Returns the length of the explicit construction (= L triangles).
    """
    return L  # explicit construction uses L triangles


def surface_code_cross_layer_atoms(L):
    """Count atoms for surface-code cross-layer surgery between two L^2 patches.

    The two patches live in different 2D layers of the atom array (analogous to
    different sheets). To merge them with standard lattice surgery, you need:

    1. A routing "channel" connecting the two patches. Minimum channel:
       - Length: ~L (distance between layers)
       - Width: 1 (single column of bridge qubits)
       - Channel data atoms: ~L
       - Channel ancillas: ~L (one per stabilizer along the channel)
       - Seam ancillas at the two ends: O(1), not L

    Total atoms added by merge: ~2L (L channel data + L channel ancillas).

    Alternative: atom rearrangement to bring the two patches face-to-face,
    avoiding the channel:
       - Just ~L seam ancillas added (plus rearrangement time cost)

    Returns (atoms_with_channel, atoms_face_to_face).
    """
    return 2 * L, L


def fcc_triangle_ribbon_atoms(L):
    """Count atoms for FCC cross-sheet ZZ-merge via triangle ribbon.

    The ribbon consists of L triangles. Each triangle uses 1 ancilla at its center
    (so L new ancilla atoms). Each triangle's edges include L/2 distinct third-sheet
    (yz) atoms that are borrowed during the merge — these atoms appear an even
    number of times on the ribbon so the yz-edge product cancels in GF(2), but
    they are still reserved during the measurement window.

    Atoms added by merge:
       - New ancillas: L (one per triangle on the ribbon)
       - Third-sheet atoms borrowed: L/2

    Total transient overhead: 3L/2 atoms.

    Requires even L; the L/2 third-sheet pairing assumes the toric FCC construction
    on even-sided periodic boundaries.
    """
    assert L % 2 == 0, f"FCC triangle ribbon requires even L; got L={L}"
    return 3 * L // 2


def detailed_count(L):
    """Build the actual triangle list and verify counts."""
    triangles, edge_to_idx, edge_to_sheet, vertices = find_triangles(L)
    n_triangles = len(triangles)
    n_vertices = len(vertices)
    edges_total = len(edge_to_sheet)
    expected_triangles = 4 * L**3  # Lemma from paper
    print(f"L={L}: vertices={n_vertices}, edges_total={edges_total}, "
          f"triangles found={n_triangles}, expected={expected_triangles}")
    assert n_triangles == expected_triangles, f"Triangle count mismatch at L={L}"
    return n_triangles


def comparison_table():
    """Build the comparison table for L in [4, 6, 8]."""
    print("=" * 90)
    print(f"{'L':>3} | {'FCC ribbon':>12} | {'Surface (channel)':>20} | "
          f"{'Surface (face-to-face)':>24} | {'Advantage':>15}")
    print("=" * 90)
    for L in [4, 6, 8]:
        n_tri = detailed_count(L)
        fcc_atoms = fcc_triangle_ribbon_atoms(L)
        surf_channel, surf_f2f = surface_code_cross_layer_atoms(L)
        adv_channel = surf_channel / fcc_atoms
        adv_f2f = surf_f2f / fcc_atoms
        print(f"{L:>3} | {fcc_atoms:>12} | {surf_channel:>20} | "
              f"{surf_f2f:>24} | {adv_channel:.1f}x / {adv_f2f:.1f}x")


if __name__ == '__main__':
    print("Triangle enumeration verification:")
    for L in [4, 6, 8]:
        detailed_count(L)
    print()
    print("Comparison table (atoms added by merge operation):")
    comparison_table()
