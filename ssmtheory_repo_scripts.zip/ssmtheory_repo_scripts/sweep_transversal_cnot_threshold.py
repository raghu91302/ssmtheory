"""sweep_transversal_cnot_threshold.py
=========================================================================
THRESHOLD SWEEP HARNESS for the threefold-rotation transversal CNOT layer.

NOTE ON SCOPE
=============
This file is a HARNESS, not a complete reproduction script. It provides:
  - The sweep loop, sampling logic, and JSON output format.
  - A default smoke-test circuit (a 2D unrotated surface-code memory
    experiment) so the script runs out of the box.

It does NOT include the exact FCC three-sheet transversal CNOT Stim circuit
used to generate the values reported in the paper:
    memory threshold (with CNOT layer) = approximately 1.04%
    R3 distance scaling: LER scales ~ 2x per Delta L = 2 increment.

To reproduce the paper's exact numbers, replace `build_transversal_cnot_circuit`
below with the FCC three-sheet transversal-CNOT circuit-construction code
from `fcc_transversal_circuit.py` in this repository.

USAGE
=====
Smoke test (uses default proxy):
    python3 sweep_transversal_cnot_threshold.py --shots 200

Reproduction:
    1. Implement `build_transversal_cnot_circuit` (see docstring) to
       construct the three-sheet FCC transversal CNOT Stim circuit at
       distance L with noise rate p.
    2. Run:
       python3 sweep_transversal_cnot_threshold.py --shots 10000 \
           --out transversal_cnot_shots.json
"""
import argparse
import json
import time

import numpy as np
import stim
import pymatching


# =========================================================================
# CIRCUIT CONSTRUCTION
# Replace this function to reproduce the paper's exact numbers.
# =========================================================================

from fcc_transversal_circuit import build_transversal_cnot_circuit  # REAL circuit

# (The previous proxy implementation has been replaced by the real two-block
#  transversal-CNOT toric circuit in fcc_transversal_circuit.py, which is the
#  per-rotation-paired-logical reduction guaranteed by the layer-decomposition
#  theorem. include_cnot=False omits the CX layer for the R1 control run.)


# =========================================================================
# DECODER (PyMatching, standard)
# =========================================================================

def decode_shots(circuit, num_shots, seed=0):
    sampler = circuit.compile_detector_sampler(seed=seed)
    detection_events, observable_flips = sampler.sample(
        num_shots, separate_observables=True
    )
    matcher = pymatching.Matching.from_detector_error_model(
        circuit.detector_error_model(decompose_errors=True)
    )
    predictions = matcher.decode_batch(detection_events)
    # BLOCK logical error: a shot fails if ANY tracked observable is wrong.
    wrong = (predictions != observable_flips)
    block_err = int(np.any(wrong, axis=1).sum())
    per_obs = wrong.sum(axis=0).tolist()  # [control-block fails, target-block fails]
    return block_err / num_shots, block_err, per_obs


def sweep(Ls, ps, shots_per_point, include_cnot, out_path):
    label = 'with_cnot' if include_cnot else 'without_cnot'
    results = []
    total_start = time.time()
    for L in Ls:
        for p in ps:
            t0 = time.time()
            circuit = build_transversal_cnot_circuit(L, p, include_cnot=include_cnot)
            ler, n_err, per_obs = decode_shots(circuit, shots_per_point, seed=int(1e6 * p) + L)
            elapsed = time.time() - t0
            print(f"  L={L}, p={p:.5f}: LER = {ler:.5f} ({n_err}/{shots_per_point}), {elapsed:.1f}s")
            results.append({
                'L': L,
                'p': p,
                'include_cnot': include_cnot,
                'shots': shots_per_point,
                'logical_errors': n_err,
                'logical_error_rate': ler,
                'per_block_errors': per_obs,
            })
            with open(out_path, 'w') as f:
                json.dump({'circuit': f'transversal_cnot_{label}_REAL',
                           'results': results}, f, indent=2)
    print(f"\nTotal sweep time: {time.time() - total_start:.1f}s")
    print(f"Results written to {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--Ls', type=int, nargs='+', default=[4, 6, 8])
    parser.add_argument('--ps', type=float, nargs='+',
                        default=[0.003, 0.005, 0.007, 0.008, 0.009, 0.010, 0.011, 0.012, 0.015])
    parser.add_argument('--shots', type=int, default=10000)
    parser.add_argument('--no-cnot', action='store_true',
                        help='Run the control experiment without the transversal CNOT layer')
    parser.add_argument('--out', type=str, default=None)
    args = parser.parse_args()

    include_cnot = not args.no_cnot
    label = 'with_cnot' if include_cnot else 'without_cnot'
    if args.out is None:
        args.out = f'transversal_cnot_{label}_shots.json'

    print("TRANSVERSAL-CNOT THRESHOLD SWEEP  (REAL FCC circuit)")
    print("=" * 70)
    print("Circuit: real two-block transversal-CNOT toric circuit")
    print("         (fcc_transversal_circuit.py), the per-rotation-paired-logical")
    print("         reduction of the FCC three-sheet experiment. Decoder: MWPM.")
    print("=" * 70)
    print(f"  include_cnot = {include_cnot}")
    print(f"  Ls = {args.Ls}, ps = {args.ps}, shots = {args.shots}")
    print(f"  Stim {stim.__version__}, PyMatching {pymatching.__version__}")
    print()

    sweep(args.Ls, args.ps, args.shots, include_cnot, args.out)


if __name__ == '__main__':
    main()
