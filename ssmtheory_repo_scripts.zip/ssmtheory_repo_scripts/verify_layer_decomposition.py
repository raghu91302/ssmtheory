"""verify_layer_decomposition.py
=========================================================================
Verify Theorem 2 of the architecture paper: the FCC sheet code on a single
triad sheet decomposes as L disjoint 2D toric codes.

For each sheet T in {S_xy, S_xz, S_yz} and each L in {4, 6, 8}:
  (a) The L^3 edges of T partition into L layers based on a perpendicular
      coordinate. Each layer contains exactly L^2 edges.
  (b) Each Z-stabilizer of T is supported entirely within one layer.
  (c) Each X-stabilizer of T is supported entirely within one layer.
  (d) Within each layer, the resulting code has parameters [[L^2, 2, L]],
      i.e., k = 2 logical qubits per layer.
  (e) Total: rank(H_Z) = rank(H_X) = L * (L^2/2 - 1) and k = 2L per sheet.

Run:
    python3 verify_layer_decomposition.py

Exit code 0 iff all checks pass.
"""
import os
import sys
import numpy as np
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sheet_code_fcc_lattice import build_fcc_lattice, SHEETS
from verify_css_isomorphism import build_sheet_code, gf2_rank


# The perpendicular axis for each sheet: edges in S_{ab} have constant
# value of the perpendicular axis c.
PERP_AXIS = {'xy': 2, 'xz': 1, 'yz': 0}  # axes: x=0, y=1, z=2


def layer_of_edge(edge, sheet, vertices):
    """Return the layer index (constant perpendicular-axis value) of an edge."""
    i, j = edge
    vi = vertices[i]
    vj = vertices[j]
    axis = PERP_AXIS[sheet]
    assert vi[axis] == vj[axis], \
        f"Edge {edge} in sheet {sheet} crosses layers: {vi[axis]} vs {vj[axis]}"
    return vi[axis]


def check_layer_partition(L, sheet, stabilizers, vertices):
    """Verify the L^3 edges of sheet partition into L layers of L^2 edges each."""
    edges_s = stabilizers[sheet]['edges']
    by_layer = defaultdict(list)
    for e in edges_s:
        layer = layer_of_edge(e, sheet, vertices)
        by_layer[layer].append(e)

    assert len(by_layer) == L, \
        f"Sheet {sheet}: expected {L} layers, got {len(by_layer)}"
    for layer, es in by_layer.items():
        assert len(es) == L * L, \
            f"Sheet {sheet} layer {layer}: expected {L*L} edges, got {len(es)}"
    return dict(by_layer)


def check_stabilizers_layer_local(L, sheet, stabilizers, vertices, by_layer):
    """Verify every stabilizer of the sheet is supported within one layer."""
    edges_s = stabilizers[sheet]['edges']
    edge_idx_to_layer = {}
    for layer, es in by_layer.items():
        for e in es:
            edge_idx_to_layer[stabilizers[sheet]['edge_idx'][e]] = layer

    def check_matrix(H, name):
        for row_idx, row in enumerate(H):
            support = np.flatnonzero(row)
            if len(support) == 0:
                continue
            layers_used = set(edge_idx_to_layer[i] for i in support)
            assert len(layers_used) == 1, \
                f"Sheet {sheet} {name}[{row_idx}] spans layers {layers_used}, expected single layer"

    check_matrix(stabilizers[sheet]['HZ'], 'HZ')
    check_matrix(stabilizers[sheet]['HX'], 'HX')


def check_per_layer_2d_toric(L, sheet, stabilizers, vertices, by_layer):
    """For each layer, verify it's a 2D toric code with parameters [[L^2, 2, L]].

    We check:
      - L^2 data qubits in the layer (already verified by check_layer_partition).
      - The restriction of HZ to this layer is the toric code's Z-stabilizer
        matrix on an L x L periodic lattice: rank = L^2/2 - 1.
      - Same for HX.
      - k = L^2 - 2*(L^2/2 - 1) = 2 per layer.
    """
    edges_s = stabilizers[sheet]['edges']
    edge_idx_in_sheet = stabilizers[sheet]['edge_idx']
    edge_idx_to_layer = {}
    for layer, es in by_layer.items():
        for e in es:
            edge_idx_to_layer[edge_idx_in_sheet[e]] = layer

    HZ = stabilizers[sheet]['HZ']
    HX = stabilizers[sheet]['HX']

    for layer, es in by_layer.items():
        # Indices of this layer's edges within the sheet's edge ordering
        layer_cols = sorted(edge_idx_in_sheet[e] for e in es)
        # Find rows of HZ and HX whose support is in this layer (and nonempty)
        def restrict(H):
            rows_in_layer = []
            for row in H:
                support = np.flatnonzero(row)
                if len(support) == 0:
                    continue
                if all(edge_idx_to_layer[i] == layer for i in support):
                    sub_row = row[layer_cols]
                    rows_in_layer.append(sub_row)
            return np.array(rows_in_layer, dtype=np.int8) if rows_in_layer else \
                np.zeros((0, len(layer_cols)), dtype=np.int8)

        HZ_layer = restrict(HZ)
        HX_layer = restrict(HX)
        n_layer = len(layer_cols)
        rank_Z = gf2_rank(HZ_layer)
        rank_X = gf2_rank(HX_layer)
        k_layer = n_layer - rank_Z - rank_X
        expected_rank = L * L // 2 - 1  # 2D toric on L x L: L^2/2 - 1
        expected_k = 2

        assert n_layer == L * L, f"Sheet {sheet} layer {layer}: n = {n_layer} != L^2"
        assert rank_Z == expected_rank, \
            f"Sheet {sheet} layer {layer}: rank(HZ_layer) = {rank_Z}, expected {expected_rank}"
        assert rank_X == expected_rank, \
            f"Sheet {sheet} layer {layer}: rank(HX_layer) = {rank_X}, expected {expected_rank}"
        assert k_layer == expected_k, \
            f"Sheet {sheet} layer {layer}: k = {k_layer}, expected {expected_k}"


def check_full_sheet_parameters(L, sheet, stabilizers):
    """Verify rank(H_Z) = rank(H_X) = L * (L^2/2 - 1) and k = 2L per sheet."""
    HZ = stabilizers[sheet]['HZ']
    HX = stabilizers[sheet]['HX']
    n = stabilizers[sheet]['n_edges']
    rank_Z = gf2_rank(HZ)
    rank_X = gf2_rank(HX)
    k = n - rank_Z - rank_X

    expected_rank = L * (L * L // 2 - 1)
    expected_k = 2 * L
    expected_n = L ** 3

    assert n == expected_n, f"Sheet {sheet}: n = {n} != L^3 = {expected_n}"
    assert rank_Z == expected_rank, \
        f"Sheet {sheet}: rank(HZ) = {rank_Z}, expected {expected_rank}"
    assert rank_X == expected_rank, \
        f"Sheet {sheet}: rank(HX) = {rank_X}, expected {expected_rank}"
    assert k == expected_k, f"Sheet {sheet}: k = {k}, expected {expected_k}"


def verify_at_L(L):
    print(f"\n{'=' * 60}")
    print(f"L = {L}")
    print(f"{'=' * 60}")
    stabilizers, vertices, vidx, edge_list, edge_to_idx = build_sheet_code(L)

    for sheet in SHEETS:
        print(f"  Sheet {sheet}:")

        print("    (a) Partition edges into L layers of L^2 each...")
        by_layer = check_layer_partition(L, sheet, stabilizers, vertices)
        print(f"        PASS: {len(by_layer)} layers, each with {L*L} edges.")

        print("    (b,c) Each stabilizer is supported within one layer...")
        check_stabilizers_layer_local(L, sheet, stabilizers, vertices, by_layer)
        print("        PASS.")

        print("    (d) Each layer is a 2D toric code [[L^2, 2, L]]...")
        check_per_layer_2d_toric(L, sheet, stabilizers, vertices, by_layer)
        print(f"        PASS: each of {L} layers has k=2, rank(HZ)=rank(HX)={L*L//2-1}.")

        print("    (e) Full sheet: n=L^3, rank=L(L^2/2-1), k=2L...")
        check_full_sheet_parameters(L, sheet, stabilizers)
        print(f"        PASS: [[L^3={L**3}, 2L={2*L}, L]] per sheet.")


def main():
    print("Verification of Theorem 2 (layer decomposition):")
    print("  Each triad sheet decomposes as L disjoint 2D toric codes.")
    Ls = [4, 6, 8]
    for L in Ls:
        verify_at_L(L)
    print(f"\n{'=' * 60}")
    print(f"All checks PASS at L in {Ls}.")
    print(f"{'=' * 60}")


if __name__ == '__main__':
    main()
