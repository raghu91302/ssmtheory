"""fcc_feedforward_real.py
Circuit-level FEED-FORWARD decoder for the real FCC sheet transversal-CNOT
circuit (fcc_sheet_circuit.build_sheet_transversal_cnot).

Pipeline (per shot, vectorized):
  1. Decode the control sheet on its own detectors. A custom faults_matrix
     returns, in addition to the 2L control logicals, the predicted pre-CNOT
     X-parity of every control data qubit (identified via Stim circuit-error
     provenance: tick < cnot_tick and a single-X on a control data qubit).
  2. Propagate that estimate through the real pi pairing to the target qubits.
  3. Remove its detector footprint from the target syndrome (a static X
     appearing at the CNOT flips the target Z-stabs containing it in the first
     post-CNOT detector layer).
  4. Decode the target residual; fold the inherited logical contribution back
     into the target-logical prediction.
Compared against naive joint MWPM on the same shots.
"""
import numpy as np, stim, pymatching
from fcc_sheet_circuit import (build_sheet_transversal_cnot, _sheet_arrays,
                               _pairing_local)


def _meta(circuit):
    """Per-DEM-error metadata via provenance: detectors, observables, and the
    representative (qubit, pauli, tick)."""
    dem = circuit.detector_error_model(decompose_errors=True)
    expl = circuit.explain_detector_error_model_errors(
        reduce_to_one_representative_error=True)
    # build columns: each ExplainedError ~ one DEM error (graphlike component)
    cols = []
    for e in expl:
        dets = [t.dem_target.val for t in e.dem_error_terms
                if t.dem_target.is_relative_detector_id()]
        obs = [t.dem_target.val for t in e.dem_error_terms
               if t.dem_target.is_logical_observable_id()]
        q = None; pauli = None; tick = None
        if e.circuit_error_locations:
            loc = e.circuit_error_locations[0]
            tick = loc.tick_offset
            fpp = loc.flipped_pauli_product
            if fpp and len(fpp) == 1:
                q = fpp[0].gate_target.value
                pauli = fpp[0].gate_target.pauli_type
        cols.append(dict(dets=dets, obs=obs, q=q, pauli=pauli, tick=tick))
    return dem, cols


def _cnot_tick(circuit, ndC, ndT):
    """Number of TICKs before the transversal CX layer. The transversal CNOT is
    the unique CX whose target is a target-DATA qubit in [ndC, ndC+ndT); the
    syndrome-extraction CXs target ANCILLAS (index >= ndC+ndT), so they must be
    excluded."""
    t = 0
    for inst in circuit:
        if inst.name == "TICK":
            t += 1
        elif inst.name == "CX":
            tg = [x.value for x in inst.targets_copy()]
            for a, b in zip(tg[::2], tg[1::2]):
                if a < ndC and (ndC <= b < ndC + ndT):
                    return t
    return None


def build_decoders(L, p, ctrl='xy', tgt='xz'):
    circ, info = build_sheet_transversal_cnot(L, p, ctrl, tgt, include_cnot=True)
    ndC, ndT = info['ndC'], info['ndT']
    nlogC, nlogT = info['nlogC'], info['nlogT']
    eC, eidxC, vertC, zC, logZC, layC = _sheet_arrays(L, ctrl)
    eT, eidxT, vertT, zT, logZT, layT = _sheet_arrays(L, tgt)
    pair = _pairing_local(L, ctrl, tgt)
    naC, naT = len(zC), len(zT)
    rp = L  # rounds_pre default

    dem, cols = _meta(circ)
    ndet = circ.num_detectors
    ctick = _cnot_tick(circ, ndC, ndT)

    # detector labels: rounds 0..(2L-1) each emit [naC ctrl][naT tgt];
    # then final [naC ctrl][naT tgt].
    nrounds = 2 * L
    det_block = np.empty(ndet, dtype='U1'); det_round = np.empty(ndet, np.int64)
    det_k = np.empty(ndet, np.int64)
    idx = 0
    for r in range(nrounds + 1):  # +1 final layer
        for k in range(naC):
            det_block[idx] = 'C'; det_round[idx] = r; det_k[idx] = k; idx += 1
        for k in range(naT):
            det_block[idx] = 'T'; det_round[idx] = r; det_k[idx] = k; idx += 1
    assert idx == ndet, (idx, ndet)
    ctrlD = np.where(det_block == 'C')[0]
    tgtD = np.where(det_block == 'T')[0]

    # Build full detector incidence H (ndet x ncol) and obs incidence.
    ncol = len(cols)
    H = np.zeros((ndet, ncol), np.uint8)
    obsC = np.zeros((nlogC + ndC, ncol), np.uint8)  # rows: 2L ctrl logicals + ndC per-qubit preCNOT X
    obsT = np.zeros((nlogT, ncol), np.uint8)
    for j, col in enumerate(cols):
        for d in col['dets']:
            H[d, j] = 1
        for o in col['obs']:
            if o < nlogC:
                obsC[o, j] = 1
            else:
                obsT[o - nlogC, j] = 1
        # per-control-qubit pre-CNOT X provenance row
        if (col['q'] is not None and col['q'] < ndC and col['pauli'] == 'X'
                and col['tick'] is not None and ctick is not None
                and col['tick'] < ctick):
            obsC[nlogC + col['q'], j] = 1

    # control matcher: detectors restricted to control; columns that touch >=1 ctrl det
    ctrl_cols = np.where(H[ctrlD].any(0))[0]
    Hc = H[np.ix_(ctrlD, ctrl_cols)]
    Fc = obsC[:, ctrl_cols]
    wc = np.array([np.log((1 - min(max(p,1e-9),0.49)) / min(max(p,1e-9),0.49))] * len(ctrl_cols))
    mc = pymatching.Matching.from_check_matrix(Hc, weights=wc, faults_matrix=Fc)

    # target matcher: detectors restricted to target
    tgt_cols = np.where(H[tgtD].any(0))[0]
    Ht = H[np.ix_(tgtD, tgt_cols)]
    Ft = obsT[:, tgt_cols]
    wt = np.array([np.log((1 - min(max(p,1e-9),0.49)) / min(max(p,1e-9),0.49))] * len(tgt_cols))
    mt = pymatching.Matching.from_check_matrix(Ht, weights=wt, faults_matrix=Ft)

    # full naive matcher
    mfull = pymatching.Matching.from_detector_error_model(dem)

    # target logical supports (over target sheet edges) and pairing
    logZT_supp = [np.flatnonzero(r) for r in logZT]
    # map: target qubit -> list of (round=rp detector indices) it flips
    # target Z-stab k contains edges es; flip det (block T, round rp, k) if qt in es
    tgt_stab_edges = [set(es) for (_, es) in zT]
    # detector index for (T, round rp, k)
    def tdet(k):
        # find detector with block T, round rp, k
        return np.where((det_block == 'T') & (det_round == rp) & (det_k == k))[0][0]
    tgt_round_rp_det = np.array([tdet(k) for k in range(naT)])
    # incidence: target qubit -> which stabs (k) contain it
    qt_to_stabs = [[] for _ in range(ndT)]
    for k, es in enumerate(tgt_stab_edges):
        for e in es:
            qt_to_stabs[e].append(k)

    return dict(circ=circ, info=info, mc=mc, mt=mt, mfull=mfull,
                ctrlD=ctrlD, tgtD=tgtD, nlogC=nlogC, nlogT=nlogT,
                ndC=ndC, ndT=ndT, pair=pair, rp=rp, naT=naT,
                tgt_round_rp_det=tgt_round_rp_det, qt_to_stabs=qt_to_stabs,
                logZT_supp=logZT_supp)


def run(L, p, shots, seed=7):
    D = build_decoders(L, p)
    circ = D['circ']; nlogC = D['nlogC']
    det, obs = circ.compile_detector_sampler(seed=seed).sample(shots, separate_observables=True)
    ctrlD, tgtD = D['ctrlD'], D['tgtD']
    pair = D['pair']; ndC, ndT = D['ndC'], D['ndT']

    # --- naive joint ---
    predF = D['mfull'].decode_batch(det)
    w = (predF != obs)
    naive_ctrl = int(np.any(w[:, :nlogC], 1).sum())
    naive_tgt = int(np.any(w[:, nlogC:], 1).sum())

    # --- feed-forward ---
    fc = D['mc'].decode_batch(det[:, ctrlD])      # (shots, nlogC + ndC)
    aHat = fc[:, nlogC:]                            # predicted pre-CNOT X per control qubit
    # inherited estimate on target qubits
    eT = np.zeros((shots, ndT), np.uint8)
    eT[:, pair] = aHat                              # eT[pair[q]] = aHat[q]
    # remove footprint: flip target round-rp detector for each target stab
    # containing a qubit in eT  (parity over that stab's qubits)
    detsT = det[:, tgtD].astype(np.uint8).copy()
    # build target-stab incidence matrix (naT x ndT) once
    naT = D['naT']
    M = np.zeros((naT, ndT), np.uint8)
    for k, lst in enumerate(D['qt_to_stabs']):
        pass
    # qt_to_stabs maps qubit->stabs; invert to stab->qubits incidence
    for qt, ks in enumerate(D['qt_to_stabs']):
        for k in ks:
            M[k, qt] ^= 1
    stab_flip = (eT.astype(np.int32) @ M.T.astype(np.int32)) % 2   # (shots, naT)
    # locate target-round-rp detectors within the tgtD ordering
    # detsT columns correspond to tgtD order; map tgt_round_rp_det -> position in tgtD
    pos_in_tgt = {d: i for i, d in enumerate(tgtD)}
    rp_cols = np.array([pos_in_tgt[d] for d in D['tgt_round_rp_det']])
    detsT[:, rp_cols] ^= stab_flip.astype(np.uint8)
    predT = D['mt'].decode_batch(detsT)            # (shots, nlogT)
    # fold inherited logical contribution
    inh = np.zeros((shots, D['nlogT']), np.uint8)
    for li, supp in enumerate(D['logZT_supp']):
        inh[:, li] = (eT[:, supp].sum(1) % 2)
    predT ^= inh
    ff_tgt = int(np.any(predT != obs[:, nlogC:], 1).sum())
    # control under feed-forward = control logical part of fc
    ff_ctrl = int(np.any(fc[:, :nlogC] != obs[:, :nlogC], 1).sum())

    return dict(naive_ctrl=naive_ctrl/shots, naive_tgt=naive_tgt/shots,
                ff_ctrl=ff_ctrl/shots, ff_tgt=ff_tgt/shots)


if __name__ == "__main__":
    import sys
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    p = float(sys.argv[2]) if len(sys.argv) > 2 else 0.006
    shots = int(sys.argv[3]) if len(sys.argv) > 3 else 3000
    print(f"L={L} p={p}:", {k: round(v, 4) for k, v in run(L, p, shots).items()})


# =========================================================================
# Genie bound: use the TRUE control pre-CNOT X-state (via FlipSimulator) for
# the inherited-field removal. If the target recovers to the memory threshold
# under the genie, the circuit-level gap is purely decoder-estimate quality,
# i.e. R1 holds and full recovery is a decoder-engineering question.
# =========================================================================
def _split_at_cnot(circ, ndC, ndT):
    """Split right before the transversal CX (target = target-DATA qubit in
    [ndC, ndC+ndT)); extraction CXs target ancillas and are NOT the split."""
    pre = stim.Circuit(); post = stim.Circuit(); seen = False
    for inst in circ:
        if (not seen) and inst.name == "CX":
            tg = [x.value for x in inst.targets_copy()]
            if any((a < ndC and ndC <= b < ndC + ndT) for a, b in zip(tg[::2], tg[1::2])):
                seen = True
        (post if seen else pre).append(inst)
    return pre, post


def run_with_genie(L, p, shots, seed=7):
    D = build_decoders(L, p)
    circ = D['circ']; ndC, ndT = D['ndC'], D['ndT']
    nlogC, nlogT = D['nlogC'], D['nlogT']; pair = D['pair']
    pre, post = _split_at_cnot(circ, ndC, ndT)

    fs = stim.FlipSimulator(batch_size=shots, seed=seed,
                            disable_stabilizer_randomization=True,
                            num_qubits=circ.num_qubits)
    fs.do(pre)
    # true X-frame on all qubits, shape (num_qubits, shots): peek gives Pauli ints
    flips = fs.peek_pauli_flips()                  # list[shots] of stim.PauliString
    aTrue = np.zeros((shots, ndC), np.uint8)
    for s in range(shots):
        ps = flips[s]
        xs, zs = ps.to_numpy()
        aTrue[s, :] = xs[:ndC].astype(np.uint8)    # X on control data qubits
    fs.do(post)
    det = fs.get_detector_flips().T.astype(np.uint8)        # (shots, ndet)
    obs = fs.get_observable_flips().T.astype(np.uint8)      # (shots, nobs)

    tgtD = D['tgtD']
    # genie inherited estimate on target
    eT = np.zeros((shots, ndT), np.uint8); eT[:, pair] = aTrue
    naT = D['naT']
    M = np.zeros((naT, ndT), np.uint8)
    for qt, ks in enumerate(D['qt_to_stabs']):
        for k in ks: M[k, qt] ^= 1
    stab_flip = (eT.astype(np.int32) @ M.T.astype(np.int32)) % 2
    detsT = det[:, tgtD].astype(np.uint8).copy()
    pos_in_tgt = {d: i for i, d in enumerate(tgtD)}
    rp_cols = np.array([pos_in_tgt[d] for d in D['tgt_round_rp_det']])
    detsT[:, rp_cols] ^= stab_flip.astype(np.uint8)
    predT = D['mt'].decode_batch(detsT)
    inh = np.zeros((shots, nlogT), np.uint8)
    for li, supp in enumerate(D['logZT_supp']):
        inh[:, li] = (eT[:, supp].sum(1) % 2)
    predT ^= inh
    genie_tgt = int(np.any(predT != obs[:, nlogC:], 1).sum()) / shots
    # naive target for reference (full graph)
    predF = D['mfull'].decode_batch(det)
    naive_tgt = int(np.any((predF != obs)[:, nlogC:], 1).sum()) / shots
    ctrl = int(np.any((predF != obs)[:, :nlogC], 1).sum()) / shots
    return dict(ctrl=ctrl, naive_tgt=naive_tgt, genie_tgt=genie_tgt)
