import numpy as np, json, time
from fcc_feedforward_real import run
ps=[0.003,0.004,0.005]
row=[]; t0=time.time()
for p in ps:
    r=run(8,p,900,seed=2008)
    row.append(dict(p=p,**{k:round(v,5) for k,v in r.items()},shots=900))
    print(f"cnot L=8 p={p}: naive_tgt={r['naive_tgt']:.3f} ff_tgt={r['ff_tgt']:.3f} ctrl={r['naive_ctrl']:.3f} [{time.time()-t0:.0f}s]",flush=True)
json.dump({'p':ps,'row':row},open('data_cnot_real_8.json','w'),indent=1)
print("done")
