"""verify_cross_sheet_reachability.py
=========================================================================
Verify Computational Result 3 of the architecture paper: the space of
triangle products that commute with all stabilizers has dimension 6L - 3
modulo stabilizers, and every nonzero element of this space is supported on
exactly two of the three sheets.

For each L in {4, 6}:
  1. Enumerate all FCC triangles (each has one edge per sheet).
  2. Build the triangle-product space T = span of triangle indicator vectors
     over GF(2), each vector being a 3L^3 boolean over the full edge set.
  3. Intersect T with the centralizer of the joint stabilizer group S
     (i.e., commute with all X- and Z-stabilizers).
  4. Modulo S, check the quotient has dimension 6L - 3.
  5. For each basis element of the quotient, check that it is supported on
     exactly two sheets (i.e., its restriction to one sheet is zero).

Run:
    python3 verify_cross_sheet_reachability.py

Exit code 0 iff all checks pass.

Note: L=8 is computationally heavy and is omitted by default. Pass --with-L8
to attempt it (may take 5-10 minutes and substantial RAM).
"""
import os
import sys
import numpy as np
from collections import defaultdict
from itertools import combinations

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sheet_code_fcc_lattice import build_fcc_lattice, SHEETS
from verify_css_isomorphism import (
    build_sheet_code, gf2_rank, gf2_rref, gf2_kernel_basis, gf2_in_rowspace,
)


def enumerate_triangles(L, vertices, vidx, edges_per_sheet, edge_to_idx):
    """Enumerate all FCC triangles. Each triangle has one edge in each of the
    three sheets, forming a 3-cycle (i, j, k) of vertices. Returns a list of
    triangle dicts and a triangle indicator matrix T[t, e] over GF(2)."""
    n_edges = sum(len(es) for es in edges_per_sheet.values())
    # We'll build the indicator matrix in dense form
    triangles = []
    seen = set()

    # For each vertex i, look at its neighbors. For each pair of neighbors j, k
    # such that (i, j), (i, k), (j, k) all exist as edges (each in a different
    # sheet), we have a triangle.
    NN = [(1, 1, 0), (1, -1, 0), (-1, 1, 0), (-1, -1, 0),
          (1, 0, 1), (1, 0, -1), (-1, 0, 1), (-1, 0, -1),
          (0, 1, 1), (0, 1, -1), (0, -1, 1), (0, -1, -1)]

    def sheet_of(dx, dy, dz):
        if dz == 0: return 'xy'
        if dy == 0: return 'xz'
        if dx == 0: return 'yz'
        return None

    for i_idx, vi in enumerate(vertices):
        # Find all neighbors of vi
        neighbors = []
        for d in NN:
            nb = ((vi[0] + d[0]) % L, (vi[1] + d[1]) % L, (vi[2] + d[2]) % L)
            if nb in vidx:
                neighbors.append((vidx[nb], d))

        # For each pair of neighbors, check if they are also adjacent
        for (j_idx, d_ij), (k_idx, d_ik) in combinations(neighbors, 2):
            vj = vertices[j_idx]
            vk = vertices[k_idx]
            # Displacement j -> k
            d_jk = ((vk[0] - vj[0]) % L, (vk[1] - vj[1]) % L, (vk[2] - vj[2]) % L)
            d_jk_norm = tuple(dk if dk <= L // 2 else dk - L for dk in d_jk)
            if d_jk_norm not in NN:
                continue
            # Check the three edges are each in a different sheet
            s_ij = sheet_of(*d_ij)
            s_ik = sheet_of(*d_ik)
            s_jk = sheet_of(*d_jk_norm)
            if s_ij is None or s_ik is None or s_jk is None:
                continue
            if len({s_ij, s_ik, s_jk}) != 3:
                continue
            # Build the triangle as a canonical sorted-tuple of vertex indices
            triple = tuple(sorted([i_idx, j_idx, k_idx]))
            if triple in seen:
                continue
            seen.add(triple)
            # Compute the three edges
            a, b, c = triple
            e_ab = (a, b)
            e_ac = (a, c)
            e_bc = (b, c)
            triangles.append({
                'vertices': triple,
                'edges': [e_ab, e_ac, e_bc],
            })

    print(f"    Enumerated {len(triangles)} triangles (expected 4*L^3 = {4 * L**3}).")
    assert len(triangles) == 4 * L ** 3, \
        f"Triangle count mismatch: got {len(triangles)}, expected {4 * L**3}"

    # Build indicator matrix T: rows = triangles, columns = edges (global)
    T = np.zeros((len(triangles), n_edges), dtype=np.int8)
    for t_idx, tri in enumerate(triangles):
        for e in tri['edges']:
            T[t_idx, edge_to_idx[e]] = 1
    return triangles, T


def build_global_stabilizer_matrices(L, stabilizers, edges_per_sheet, edge_to_idx):
    """Build HZ and HX as matrices over the full edge set (concatenated across
    all three sheets)."""
    n_edges = sum(len(es) for es in edges_per_sheet.values())

    def lift(H, sheet):
        edges_s = edges_per_sheet[sheet]
        n_rows = H.shape[0]
        out = np.zeros((n_rows, n_edges), dtype=np.int8)
        for r in range(n_rows):
            for local_idx in np.flatnonzero(H[r]):
                e = edges_s[local_idx]
                out[r, edge_to_idx[e]] = 1
        return out

    HZ_blocks = [lift(stabilizers[s]['HZ'], s) for s in SHEETS]
    HX_blocks = [lift(stabilizers[s]['HX'], s) for s in SHEETS]
    HZ = np.vstack(HZ_blocks)
    HX = np.vstack(HX_blocks)
    return HZ, HX


def verify_at_L(L):
    print(f"\n{'=' * 60}")
    print(f"L = {L}")
    print(f"{'=' * 60}")
    print("  Building FCC sheet code...")
    stabilizers, vertices, vidx, edge_list, edge_to_idx = build_sheet_code(L)
    _, _, edges_per_sheet, _, _, _ = build_fcc_lattice(L)
    n_edges = sum(len(es) for es in edges_per_sheet.values())
    print(f"    Vertices: {len(vertices)}, Edges: {n_edges}.")

    print("  Enumerating triangles...")
    triangles, T = enumerate_triangles(L, vertices, vidx, edges_per_sheet, edge_to_idx)

    print("  Building global stabilizer matrices HZ, HX...")
    HZ, HX = build_global_stabilizer_matrices(L, stabilizers, edges_per_sheet, edge_to_idx)
    print(f"    HZ: {HZ.shape}, HX: {HX.shape}")

    # A triangle product is a Z-type cycle. To commute with all X-stabilizers,
    # the support must be in ker(HX). For triangles in our FCC code, single
    # triangles do not commute with X-stabilizers, but sums of triangles can.
    print("  Finding triangle products in ker(HX) (centralizer of X-stabilizers)...")
    # We want triangle products P = sum_t c_t * triangle_t such that HX P = 0
    # (mod 2). The matrix relating triangle coefficients c to syndrome is
    # syndrome = HX @ T.T (mod 2). We want c in ker(syndrome_matrix).
    syndrome_mat = (HX @ T.T) % 2  # shape: (n_X_stabs, n_triangles)
    print(f"    syndrome matrix shape: {syndrome_mat.shape}; computing kernel...")
    triangle_kernel = gf2_kernel_basis(syndrome_mat)
    print(f"    triangle kernel dim: {len(triangle_kernel)}")
    # Each row of triangle_kernel is a coefficient vector c. The corresponding
    # edge-support is (c @ T) mod 2.
    triangle_logical_support = (triangle_kernel @ T) % 2  # shape: (kernel_dim, n_edges)

    print("  Quotienting by Z-stabilizers (rowspace of HZ)...")
    rank_HZ = gf2_rank(HZ)
    print(f"    rank(HZ) = {rank_HZ}")

    # Find a basis for triangle-products modulo HZ. We do this by greedy
    # selection: include rows of triangle_logical_support that are independent
    # of HZ + previously-selected rows.
    M = HZ.copy().astype(np.int8)
    basis_quotient = []
    for row in triangle_logical_support:
        if not gf2_in_rowspace(M, row):
            basis_quotient.append(row)
            M = np.vstack([M, row.reshape(1, -1)])
    print(f"    quotient dimension (triangle products mod stabilizers): {len(basis_quotient)}")

    expected_dim = 6 * L - 3
    assert len(basis_quotient) == expected_dim, \
        f"L={L}: expected dim = 6L-3 = {expected_dim}, got {len(basis_quotient)}"
    print(f"    PASS: quotient dim = 6L - 3 = {expected_dim}")

    print("  Checking the quotient is spanned by two-sheet-supported triangle products...")
    # For each ordered pair (a, b) of sheets, find triangle products in ker(HX)
    # supported only on sheets {a, b}, then quotient by HZ.
    # The two-sheet-{a,b} subspace = triangle products whose projection to sheet c is zero
    # (where c is the missing third sheet).
    edge_to_sheet = {}
    for sheet in SHEETS:
        for e in edges_per_sheet[sheet]:
            edge_to_sheet[edge_to_idx[e]] = sheet

    sheet_pairs = [('xy', 'xz'), ('xy', 'yz'), ('xz', 'yz')]
    third_sheet = {('xy', 'xz'): 'yz', ('xy', 'yz'): 'xz', ('xz', 'yz'): 'xy'}

    # triangle_logical_support is a basis for triangle products in ker(HX).
    # For each pair (a, b), find linear combinations whose support on the
    # third sheet c is zero: solve a @ T_logical_support[:, sheet_c_cols] = 0.

    M_combined = HZ.copy().astype(np.int8)
    total_added = 0
    for pair in sheet_pairs:
        c = third_sheet[pair]
        c_cols = sorted(i for i, sh in edge_to_sheet.items() if sh == c)
        # restriction of basis to sheet c
        restriction = triangle_logical_support[:, c_cols].astype(np.int8)
        # Coefficient kernel: a @ restriction = 0
        # i.e., a in ker(restriction.T)
        coeff_kernel = gf2_kernel_basis(restriction.T)
        # Each row of coeff_kernel is a coefficient vector a; the corresponding
        # triangle-product-in-ker(HX)-with-zero-on-sheet-c is a @ triangle_logical_support
        two_sheet_elements = (coeff_kernel @ triangle_logical_support) % 2
        # Add each to M_combined if it's independent
        added_for_pair = 0
        for row in two_sheet_elements:
            if row.sum() == 0:
                continue
            # Sanity: should have zero on sheet c
            assert all(row[i] == 0 for i in c_cols), f"sanity: row has nonzero on {c}"
            if not gf2_in_rowspace(M_combined, row):
                M_combined = np.vstack([M_combined, row.reshape(1, -1)])
                added_for_pair += 1
                total_added += 1
        print(f"    Pair {pair} (no support on {c}): {added_for_pair} independent two-sheet products mod stabilizers and prior pairs")

    print(f"    Total two-sheet-supported dim mod HZ: {total_added}")
    assert total_added == expected_dim, \
        f"L={L}: two-sheet-supported subspace mod HZ has dim {total_added}, expected {expected_dim}"
    print(f"    PASS: the two-sheet-supported subspace mod HZ has dimension 6L - 3 = {expected_dim}")
    print(f"    => the quotient is spanned by two-sheet-supported triangle products.")


def main():
    print("Verification of Computational Result 3 (cross-sheet reachability):")
    print("  Triangle-product space has dim 6L-3 mod stabilizers,")
    print("  every element supported on exactly two sheets.")
    Ls = [4, 6]
    if '--with-L8' in sys.argv:
        Ls.append(8)

    for L in Ls:
        verify_at_L(L)

    print(f"\n{'=' * 60}")
    print(f"All checks PASS at L in {Ls}.")
    print(f"{'=' * 60}")


if __name__ == '__main__':
    main()
