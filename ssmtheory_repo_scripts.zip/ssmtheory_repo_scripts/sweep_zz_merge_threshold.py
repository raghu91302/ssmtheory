"""sweep_zz_merge_threshold.py
=========================================================================
THRESHOLD SWEEP HARNESS for the cross-sheet ZZ-merge primitive.

NOTE ON SCOPE
=============
This file is a HARNESS, not a complete reproduction script. It provides:
  - The sweep loop, sampling logic, and JSON output format.
  - A default smoke-test circuit (a 2D unrotated surface-code joint
    measurement) so the script runs out of the box.

It does NOT include the exact FCC triangle-ribbon Stim circuit used to
generate the threshold values reported in the paper:
    p_th (toric variant)  = 1.07(5)%
    p_th (planar variant) = 0.76(5)%

To reproduce the paper's exact thresholds, replace `build_zz_merge_circuit`
below with the FCC ribbon circuit-construction code from
`fcc_surgery_circuit.py` in this repository. The harness output format and
sweep parameters are designed to match what `make_fig_threshold.py` consumes.

USAGE
=====
Smoke test (uses default 2D surface-code proxy):
    python3 sweep_zz_merge_threshold.py --shots 200

Reproduction with the FCC ribbon circuit:
    1. Implement `build_zz_merge_circuit` (see docstring) to construct the
       FCC ribbon Stim circuit at distance L with noise rate p.
    2. Run:
       python3 sweep_zz_merge_threshold.py --shots 10000 --out zz_merge_toric.json
"""
import argparse
import json
import time

import numpy as np
import stim
import pymatching


# =========================================================================
# CIRCUIT CONSTRUCTION
# Replace this function to reproduce the paper's exact ZZ-merge thresholds.
# =========================================================================

def build_zz_merge_circuit(L, p, variant='toric', rounds=None):
    """Build the Stim circuit for a single ZZ-merge measurement at distance L.

    Inputs:
        L        : code distance
        p        : physical error rate per gate/measurement
        variant  : 'toric' or 'planar'
        rounds   : number of stabilizer-extraction rounds (default: L)

    Returns:
        A Stim Circuit that, when decoded, yields a single bit indicating
        whether the joint Z_A Z_B parity measurement was correctly recovered.

    DEFAULT IMPLEMENTATION (smoke test, NOT the FCC ZZ-merge circuit):
        Uses Stim's `surface_code:unrotated_memory_z` task as a stand-in.

    TO REPRODUCE the paper's thresholds:
        Replace this function body with an implementation that constructs
        the FCC ribbon Stim circuit. The structure of the actual circuit is:
          1. Initialize sheet A and sheet B logicals (e.g. in |+>|+>).
          2. Place L triangle ancillas along the ribbon.
          3. For `rounds` rounds, alternate:
             (a) Single-sheet stabilizer extraction within each sheet.
             (b) Triangle-ancilla extraction measuring
                   Z_{e_xy} (x) Z_{e_xz} (x) Z_{e_yz}
                 for each ribbon triangle (yz contributions cancel pairwise
                 as verified in ribbon_construction.py).
          4. Final perfect measurement of each sheet's data qubits and the
             ancillas; declare the joint Z_A Z_B parity from the product of
             the L triangle measurements modulo HZ-rowspace.
          5. Define the observable as the joint parity.
        See fcc_surgery_circuit.py for the canonical implementation.
    """
    if rounds is None:
        rounds = L
    task = 'unrotated_memory_z' if variant == 'toric' else 'rotated_memory_z'
    circuit = stim.Circuit.generated(
        f"surface_code:{task}",
        distance=L,
        rounds=rounds,
        after_clifford_depolarization=p,
        after_reset_flip_probability=p,
        before_measure_flip_probability=p,
        before_round_data_depolarization=p,
    )
    return circuit


# =========================================================================
# DECODER (PyMatching, standard)
# =========================================================================

def decode_shots(circuit, num_shots, seed=0):
    sampler = circuit.compile_detector_sampler(seed=seed)
    detection_events, observable_flips = sampler.sample(
        num_shots, separate_observables=True
    )
    matcher = pymatching.Matching.from_detector_error_model(
        circuit.detector_error_model(decompose_errors=True)
    )
    predictions = matcher.decode_batch(detection_events)
    num_errors = int(np.sum(predictions != observable_flips))
    return num_errors / num_shots, num_errors


def sweep(Ls, ps, shots_per_point, variant, out_path):
    results = []
    total_start = time.time()
    for L in Ls:
        for p in ps:
            t0 = time.time()
            circuit = build_zz_merge_circuit(L, p, variant=variant)
            ler, n_err = decode_shots(circuit, shots_per_point, seed=int(1e6 * p) + L)
            elapsed = time.time() - t0
            print(f"  L={L}, p={p:.5f}: LER = {ler:.5f} ({n_err}/{shots_per_point}), {elapsed:.1f}s")
            results.append({
                'L': L,
                'p': p,
                'variant': variant,
                'shots': shots_per_point,
                'logical_errors': n_err,
                'logical_error_rate': ler,
            })
            with open(out_path, 'w') as f:
                json.dump({'circuit': f'zz_merge_{variant}_HARNESS_PROXY',
                           'results': results}, f, indent=2)
    print(f"\nTotal sweep time: {time.time() - total_start:.1f}s")
    print(f"Results written to {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=['toric', 'planar'], default='toric')
    parser.add_argument('--Ls', type=int, nargs='+', default=[4, 6, 8])
    parser.add_argument('--ps', type=float, nargs='+',
                        default=[0.003, 0.005, 0.007, 0.008, 0.009, 0.010, 0.011, 0.012, 0.015])
    parser.add_argument('--shots', type=int, default=10000)
    parser.add_argument('--out', type=str, default=None)
    args = parser.parse_args()

    if args.out is None:
        args.out = f'zz_merge_{args.variant}_shots.json'

    print("ZZ-MERGE THRESHOLD SWEEP HARNESS")
    print("=" * 70)
    print("WARNING: The default circuit builder is a 2D-surface-code proxy.")
    print("         It does NOT reproduce the paper's exact ZZ-merge thresholds.")
    print("         To reproduce the paper, replace build_zz_merge_circuit()")
    print("         with the FCC ribbon circuit from fcc_surgery_circuit.py.")
    print("=" * 70)
    print(f"  variant = {args.variant}")
    print(f"  Ls = {args.Ls}, ps = {args.ps}, shots = {args.shots}")
    print(f"  Stim {stim.__version__}, PyMatching {pymatching.__version__}")
    print()

    sweep(args.Ls, args.ps, args.shots, args.variant, args.out)


if __name__ == '__main__':
    main()
