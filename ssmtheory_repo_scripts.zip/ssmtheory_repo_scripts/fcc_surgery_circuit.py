"""fcc_surgery_circuit.py
================================================================================
REAL circuit-level cross-sheet ZZ-merge (the file the old harness referenced but
never contained). Z-basis lattice surgery: measure the Z-vertex stabilizers of
all three sheets together with the L triangle Z-ancillas of the ribbon, for L
rounds, starting from |0...0>. The joint logical parity Z_A Z_B is the product of
the L triangle operators (yz-edges cancel pairwise; verified structurally).

Only Z-type operators are measured, so every measured operator commutes: there is
no seam X-stabilizer conflict in this basis. X-errors flip the Z-stabs/triangles
and are decoded by MWPM. The joint parity is the OBSERVABLE.
"""
import numpy as np, stim
from sheet_code_fcc_lattice import build_fcc_lattice, NN_DISPLACEMENTS, SHEETS
from verify_css_isomorphism import build_sheet_code
from ribbon_construction import build_lattice_full, construct_layer_cycle, find_ribbon


def _geometry(L):
    stab, verts, vidx, edge_list, edge_to_idx = build_sheet_code(L)
    V,vidx2,eps,el,eti,esheet,tris = build_lattice_full(L)
    ca = construct_layer_cycle(L,'xy',0); cb = construct_layer_cycle(L,'xz',0)
    ribbon, info = find_ribbon(L, ca, cb, tris)
    nE = len(edge_list)
    # Z-vertex stabilizers of all three sheets, in GLOBAL edge indices, each as an
    # ordered 4-tuple by NN-displacement (direction-ordered schedule, as in memory).
    zstabs = []
    for sheet in SHEETS:
        dirs = NN_DISPLACEMENTS[sheet]
        for vp in verts:
            i = vidx[vp]; x,y,z = vp; ordered=[]
            for (dx,dy,dz) in dirs:
                wp = ((x+dx)%L,(y+dy)%L,(z+dz)%L); j=vidx[wp]
                e=(min(i,j),max(i,j))
                if e in edge_to_idx: ordered.append(edge_to_idx[e])
            if len(ordered)==4: zstabs.append(ordered)
    # triangle Z-operators (weight 3) in global edge indices
    triangles = []
    for t_idx in ribbon:
        ebs = tris[t_idx]['edges_by_sheet']
        triangles.append([edge_to_idx[ebs[s]] for s in ('xy','xz','yz')])
    # joint logical support = product of triangles = cycle_a + cycle_b (global)
    joint = np.zeros(nE,np.int8)
    for e in ca: joint[edge_to_idx[e]]^=1
    for e in cb: joint[edge_to_idx[e]]^=1
    return nE, zstabs, triangles, np.flatnonzero(joint)


def build_zz_merge(L, p, rounds=None):
    if rounds is None: rounds = L
    nE, zstabs, triangles, joint_supp = _geometry(L)
    nZ, nT = len(zstabs), len(triangles)
    data = list(range(nE))
    zanc = list(range(nE, nE+nZ))
    tanc = list(range(nE+nZ, nE+nZ+nT))
    c = stim.Circuit()
    c.append("R", data); c.append("X_ERROR", data, p); c.append("TICK")
    mc=[0]; zrec=[]; trec=[]
    def rec(a): return stim.target_rec(a-mc[0])
    def rnd():
        c.append("R", zanc+tanc); c.append("X_ERROR", zanc+tanc, p)
        c.append("DEPOLARIZE1", data, p)
        for s in range(4):
            pairs=[]
            for k,st in enumerate(zstabs): pairs += [st[s], zanc[k]]
            for k,tr in enumerate(triangles):
                if s < 3: pairs += [tr[s], tanc[k]]     # weight-3: 3 steps
            c.append("CX", pairs); c.append("DEPOLARIZE2", pairs, p)
        c.append("X_ERROR", zanc+tanc, p); c.append("MR", zanc+tanc)
        base=mc[0]; zr={k:base+k for k in range(nZ)}; tr={k:base+nZ+k for k in range(nT)}
        mc[0]+=nZ+nT; c.append("TICK"); return zr,tr
    z0,t0=rnd(); zrec.append(z0); trec.append(t0)
    for k in range(nZ): c.append("DETECTOR",[rec(z0[k])])
    # round-0 triangle product = the merge outcome Z_A Z_B (the timelike observable)
    c.append("OBSERVABLE_INCLUDE",[rec(t0[k]) for k in range(nT)], 0)
    for _ in range(rounds-1):
        zp,tp=zrec[-1],trec[-1]; zc,tc=rnd(); zrec.append(zc); trec.append(tc)
        for k in range(nZ): c.append("DETECTOR",[rec(zc[k]),rec(zp[k])])
        for k in range(nT): c.append("DETECTOR",[rec(tc[k]),rec(tp[k])])
    c.append("X_ERROR", data, p); c.append("M", data)
    fb=mc[0]; mc[0]+=nE; dr={q:fb+q for q in range(nE)}
    zl,tl=zrec[-1],trec[-1]
    for k,st in enumerate(zstabs):
        c.append("DETECTOR",[rec(dr[e]) for e in st]+[rec(zl[k])])
    # triangle final consistency: data-read triangle vs last ancilla
    for k,tr in enumerate(triangles):
        c.append("DETECTOR",[rec(dr[e]) for e in tr]+[rec(tl[k])])
    return c, dict(nZ=nZ,nT=nT,nE=nE)


if __name__=="__main__":
    import sys
    L=int(sys.argv[1]) if len(sys.argv)>1 else 4
    c,info=build_zz_merge(L,0.005)
    print(f"L={L}: data={info['nE']} Zstabs={info['nZ']} triangles={info['nT']} "
          f"qubits={c.num_qubits} dets={c.num_detectors} obs={c.num_observables}")
    d,o=c.compile_detector_sampler().sample(2000,separate_observables=True)
    c0,_=build_zz_merge(L,0.0); d0,o0=c0.compile_detector_sampler().sample(2000,separate_observables=True)
    print(f"p=0: det={int(d0.sum())} obs={int(o0.sum())}  (both 0 expected)")
    print(f"joint-parity circuit distance d={len(c.shortest_graphlike_error())} (expect L={L})")
