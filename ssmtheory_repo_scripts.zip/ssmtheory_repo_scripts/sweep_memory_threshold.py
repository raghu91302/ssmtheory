"""sweep_memory_threshold.py
=========================================================================
Sweep the memory threshold of a single FCC triad sheet using Stim circuits
and PyMatching decoding.

A single FCC triad sheet decomposes into L independent 2D toric codes
(Theorem 2). So the memory threshold is exactly the 2D toric code threshold.
This script runs the standard rotated-toric memory benchmark at
distance d = L for L in {4, 6, 8}.

Usage:
    python3 sweep_memory_threshold.py [--shots 10000] [--out memory_shots.json]

Output:
    JSON file with logical error rates at each (L, p) point, ready for
    feeding into make_fig_threshold.py.

Notes:
    This script uses Stim's built-in surface code generator as a stand-in for
    the per-layer 2D toric code (the toric and surface code have the same
    bulk threshold; the planar variant has a slightly lower threshold due to
    boundary effects). If you want to benchmark the exact FCC sheet
    decomposition layer-by-layer, see the layer-aware variant in the
    architecture paper's bundle.
"""
import argparse
import json
import sys
import time

import numpy as np
import stim
import pymatching


def build_memory_circuit(L, p, rounds=None):
    """Build a Stim memory-experiment circuit for the 2D toric code at distance d=L.

    Uses Stim's surface code generator with `unrotated_memory_z` task, which
    matches the per-layer 2D toric structure (each layer of the FCC sheet
    decomposition is a 2D toric code).
    """
    if rounds is None:
        rounds = L  # standard: d rounds
    circuit = stim.Circuit.generated(
        "surface_code:unrotated_memory_z",
        distance=L,
        rounds=rounds,
        after_clifford_depolarization=p,
        after_reset_flip_probability=p,
        before_measure_flip_probability=p,
        before_round_data_depolarization=p,
    )
    return circuit


def decode_shots(circuit, num_shots, seed=0):
    """Run num_shots and decode with PyMatching. Returns logical error rate."""
    sampler = circuit.compile_detector_sampler(seed=seed)
    detection_events, observable_flips = sampler.sample(
        num_shots, separate_observables=True
    )
    matcher = pymatching.Matching.from_detector_error_model(
        circuit.detector_error_model(decompose_errors=True)
    )
    predictions = matcher.decode_batch(detection_events)
    num_errors = int(np.sum(predictions != observable_flips))
    return num_errors / num_shots, num_errors


def sweep(Ls, ps, shots_per_point, out_path):
    results = []
    total_start = time.time()
    for L in Ls:
        for p in ps:
            t0 = time.time()
            circuit = build_memory_circuit(L, p)
            ler, n_err = decode_shots(circuit, shots_per_point, seed=int(1e6 * p) + L)
            elapsed = time.time() - t0
            print(f"  L={L}, p={p:.5f}: LER = {ler:.5f} ({n_err}/{shots_per_point}), "
                  f"{elapsed:.1f}s")
            results.append({
                'L': L,
                'p': p,
                'shots': shots_per_point,
                'logical_errors': n_err,
                'logical_error_rate': ler,
            })
            # Flush after each point so partial runs aren't lost
            with open(out_path, 'w') as f:
                json.dump({'circuit': 'memory_toric', 'results': results}, f, indent=2)
    print(f"\nTotal sweep time: {time.time() - total_start:.1f}s")
    print(f"Results written to {out_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--Ls', type=int, nargs='+', default=[4, 6, 8],
                        help='Code distances to sweep')
    parser.add_argument('--ps', type=float, nargs='+',
                        default=[0.003, 0.005, 0.007, 0.008, 0.009, 0.010, 0.011, 0.012, 0.015],
                        help='Physical error rates to sweep')
    parser.add_argument('--shots', type=int, default=10000,
                        help='Shots per (L, p) point')
    parser.add_argument('--out', type=str, default='memory_shots.json',
                        help='Output JSON file')
    args = parser.parse_args()

    print(f"Memory threshold sweep")
    print(f"  Ls = {args.Ls}, ps = {args.ps}, shots = {args.shots}")
    print(f"  Stim {stim.__version__}, PyMatching {pymatching.__version__}")

    sweep(args.Ls, args.ps, args.shots, args.out)


if __name__ == '__main__':
    main()
