import numpy as np, json, time
from fcc_feedforward_real import run_with_genie
ps=[0.002,0.003,0.004,0.005,0.006,0.008]
out={'p':ps,'curves':{}}; t0=time.time()
for L,sh in [(4,5000),(6,3500)]:
    row=[]
    for p in ps:
        r=run_with_genie(L,p,sh,seed=3000+L)
        row.append(dict(p=p,**{k:round(v,5) for k,v in r.items()},shots=sh))
        print(f"genie L={L} p={p}: ctrl={r['ctrl']:.3f} naive_tgt={r['naive_tgt']:.3f} genie_tgt={r['genie_tgt']:.3f}",flush=True)
    out['curves'][str(L)]=row
json.dump(out,open('data_genie_real.json','w'),indent=1)
print(f"done {time.time()-t0:.0f}s")
