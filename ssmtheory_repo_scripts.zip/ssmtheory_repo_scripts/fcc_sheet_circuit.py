"""fcc_sheet_circuit.py
=========================================================================
REAL FCC sheet-code circuits (not the per-layer toric stand-in).

Built directly from the actual sheet stabilizers in sheet_code_fcc_lattice /
verify_css_isomorphism, and the real rotation pairing pi from
verify_css_isomorphism.rotation_permutation.

Milestone 1 here: a Z-basis memory circuit for one triad sheet.
  - data qubits  = the L^3 edges of the sheet
  - Z-ancilla    = one per weight-4 vertex Z-stabilizer
  - schedule     = 4 steps, step s couples every Z-ancilla to its edge in the
                   s-th canonical sheet direction (conflict-free: opposite
                   directions land in different steps, so no data qubit is in
                   two gates per step)
  - observables  = the real logical-Z operators (ker H_X / rowspace H_Z),
                   2L of them per sheet
By the layer decomposition + layer-local pairing, the sheet is L edge-disjoint
toric codes and NO gate links two layers; we assert this by construction.
"""
import numpy as np
import stim

from sheet_code_fcc_lattice import build_fcc_lattice, NN_DISPLACEMENTS, SHEETS
from verify_css_isomorphism import (build_sheet_code, extract_per_sheet_logicals,
                                     rotation_permutation)
from verify_layer_decomposition import PERP_AXIS, layer_of_edge


def _sheet_arrays(L, sheet):
    """Return geometry for one sheet:
       edges (list of (i,j)), edge_idx (dict), vertices, vidx,
       zstabs: list of (ancilla_vertex, [4 edge indices ordered by direction]),
       logical_Z (rows over sheet edges), layer_of[edge_idx].
    """
    stab, vertices, vidx, edge_list_all, edge_to_idx_all = build_sheet_code(L)
    edges = stab[sheet]['edges']
    eidx = stab[sheet]['edge_idx']
    dirs = NN_DISPLACEMENTS[sheet]            # canonical 4 directions for schedule
    # Z-stabs: one per vertex; order its 4 edges by direction index
    zstabs = []
    for vp in vertices:
        i = vidx[vp]
        x, y, z = vp
        ordered = []
        for (dx, dy, dz) in dirs:
            wp = ((x + dx) % L, (y + dy) % L, (z + dz) % L)
            j = vidx[wp]
            e = (min(i, j), max(i, j))
            if e in eidx:
                ordered.append(eidx[e])
        if len(ordered) == 4:
            zstabs.append((i, ordered))
    logical_Z, logical_X = extract_per_sheet_logicals(stab, sheet)
    layer_of = {eidx[e]: layer_of_edge(e, sheet, vertices) for e in edges}
    return edges, eidx, vertices, zstabs, logical_Z, layer_of


def build_sheet_memory_circuit(L, p, sheet='xy', rounds=None):
    if rounds is None:
        rounds = L
    edges, eidx, vertices, zstabs, logical_Z, layer_of = _sheet_arrays(L, sheet)
    ndata = len(edges)
    nanc = len(zstabs)

    # --- assert decoupling by construction: every Z-stab is layer-local ---
    for (_, es) in zstabs:
        assert len({layer_of[e] for e in es}) == 1, "Z-stab crosses layers!"

    data_q = list(range(ndata))
    anc_q = list(range(ndata, ndata + nanc))

    c = stim.Circuit()
    c.append("R", data_q)
    c.append("X_ERROR", data_q, p)
    c.append("TICK")

    meas_count = [0]
    round_recs = []

    def rec(absidx):
        return stim.target_rec(absidx - meas_count[0])

    def extraction_round():
        c.append("R", anc_q)
        c.append("X_ERROR", anc_q, p)
        c.append("DEPOLARIZE1", data_q, p)
        for s in range(4):
            pairs = []
            for k, (_, es) in enumerate(zstabs):
                pairs += [es[s], anc_q[k]]      # CX(data_control -> ancilla_target)
            c.append("CX", pairs)
            c.append("DEPOLARIZE2", pairs, p)
        c.append("X_ERROR", anc_q, p)
        c.append("MR", anc_q)
        base = meas_count[0]
        recs = {k: base + k for k in range(nanc)}
        meas_count[0] += nanc
        c.append("TICK")
        return recs

    r0 = extraction_round(); round_recs.append(r0)
    for k in range(nanc):
        c.append("DETECTOR", [rec(r0[k])])
    for _ in range(rounds - 1):
        rprev = round_recs[-1]; rcur = extraction_round(); round_recs.append(rcur)
        for k in range(nanc):
            c.append("DETECTOR", [rec(rcur[k]), rec(rprev[k])])

    # final perfect-ish data readout
    c.append("X_ERROR", data_q, p)
    c.append("M", data_q)
    fbase = meas_count[0]; meas_count[0] += ndata
    drec = {q: fbase + q for q in range(ndata)}

    last = round_recs[-1]
    for k, (_, es) in enumerate(zstabs):
        c.append("DETECTOR", [rec(drec[e]) for e in es] + [rec(last[k])])

    # observables: real logical-Z operators over final data measurements
    for li, lz in enumerate(logical_Z):
        supp = np.flatnonzero(lz)
        c.append("OBSERVABLE_INCLUDE", [rec(drec[int(q)]) for q in supp], li)

    return c, dict(ndata=ndata, nanc=nanc, nlog=len(logical_Z))


if __name__ == "__main__":
    import sys
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    p = float(sys.argv[2]) if len(sys.argv) > 2 else 0.005
    c, info = build_sheet_memory_circuit(L, p)
    print(f"L={L} sheet=xy: data={info['ndata']} anc={info['nanc']} "
          f"logicals={info['nlog']} (expect 2L={2*L})")
    print(f"qubits={c.num_qubits} detectors={c.num_detectors} observables={c.num_observables}")
    dem = c.detector_error_model(decompose_errors=True)
    print("DEM OK:", dem.num_detectors, "detectors")


# =========================================================================
# Milestone 2: real transversal CNOT between sheet T (control) and R(T)
# (target), paired by the actual rotation permutation pi.
# =========================================================================
def _pairing_local(L, ctrl='xy', tgt='xz'):
    """Map control-sheet local edge index -> target-sheet local edge index,
    using the real rotation permutation pi (ctrl edges -> R(ctrl)=tgt edges)."""
    stab, vertices, vidx, edge_list_all, edge_to_idx_all = build_sheet_code(L)
    pi = rotation_permutation(L, vertices, vidx, edge_list_all, edge_to_idx_all)
    eC = stab[ctrl]['edges']; eidxC = stab[ctrl]['edge_idx']
    eidxT = stab[tgt]['edge_idx']
    pair = np.zeros(len(eC), dtype=np.int64)
    for e in eC:
        g = edge_to_idx_all[e]
        g_img = int(pi[g])
        e_img = edge_list_all[g_img]
        pair[eidxC[e]] = eidxT[e_img]
    return pair


def build_sheet_transversal_cnot(L, p, ctrl='xy', tgt='xz',
                                 rounds_pre=None, rounds_post=None,
                                 include_cnot=True, pC=None, pT=None, pCX=None):
    # per-block noise rates (default to p). pC=control, pT=target, pCX=cnot layer.
    if pC is None: pC = p
    if pT is None: pT = p
    if pCX is None: pCX = p
    if rounds_pre is None: rounds_pre = L
    if rounds_post is None: rounds_post = L

    eC, eidxC, vertC, zC, logZC, layC = _sheet_arrays(L, ctrl)
    eT, eidxT, vertT, zT, logZT, layT = _sheet_arrays(L, tgt)
    pair = _pairing_local(L, ctrl, tgt)

    ndC, naC = len(eC), len(zC)
    ndT, naT = len(eT), len(zT)
    dataC = list(range(ndC))
    dataT = list(range(ndC, ndC + ndT))
    ancC = list(range(ndC + ndT, ndC + ndT + naC))
    ancT = list(range(ndC + ndT + naC, ndC + ndT + naC + naT))

    c = stim.Circuit()
    c.append("R", dataC + dataT)
    c.append("X_ERROR", dataC, pC); c.append("X_ERROR", dataT, pT)
    c.append("TICK")
    meas_count = [0]; round_recs = []
    def rec(a): return stim.target_rec(a - meas_count[0])

    def extraction():
        c.append("R", ancC + ancT)
        c.append("X_ERROR", ancC, pC); c.append("X_ERROR", ancT, pT)
        c.append("DEPOLARIZE1", dataC, pC); c.append("DEPOLARIZE1", dataT, pT)
        for st in range(4):
            pairsC = []; pairsT = []
            for k, (_, es) in enumerate(zC): pairsC += [dataC[es[st]], ancC[k]]
            for k, (_, es) in enumerate(zT): pairsT += [dataT[es[st]], ancT[k]]
            c.append("CX", pairsC + pairsT)
            if pC > 0: c.append("DEPOLARIZE2", pairsC, pC)
            if pT > 0: c.append("DEPOLARIZE2", pairsT, pT)
        c.append("X_ERROR", ancC, pC); c.append("X_ERROR", ancT, pT)
        c.append("MR", ancC + ancT)
        base = meas_count[0]
        recs = {('C', k): base + k for k in range(naC)}
        recs.update({('T', k): base + naC + k for k in range(naT)})
        meas_count[0] += naC + naT
        c.append("TICK")
        return recs

    r0 = extraction(); round_recs.append(r0)
    for k in range(naC): c.append("DETECTOR", [rec(r0[('C', k)])])
    for k in range(naT): c.append("DETECTOR", [rec(r0[('T', k)])])
    for _ in range(rounds_pre - 1):
        rp = round_recs[-1]; rc = extraction(); round_recs.append(rc)
        for k in range(naC): c.append("DETECTOR", [rec(rc[('C', k)]), rec(rp[('C', k)])])
        for k in range(naT): c.append("DETECTOR", [rec(rc[('T', k)]), rec(rp[('T', k)])])

    if include_cnot:
        cx = []
        for lc in range(ndC):
            cx += [dataC[lc], dataT[int(pair[lc])]]   # CX(control_edge -> target_edge)
        c.append("CX", cx)
        if pCX > 0: c.append("DEPOLARIZE2", cx, pCX)
        c.append("TICK")

    for _ in range(rounds_post):
        rp = round_recs[-1]; rc = extraction(); round_recs.append(rc)
        for k in range(naC): c.append("DETECTOR", [rec(rc[('C', k)]), rec(rp[('C', k)])])
        for k in range(naT): c.append("DETECTOR", [rec(rc[('T', k)]), rec(rp[('T', k)])])

    c.append("X_ERROR", dataC, pC); c.append("X_ERROR", dataT, pT)
    c.append("M", dataC + dataT)
    fbase = meas_count[0]; meas_count[0] += ndC + ndT
    drecC = {q: fbase + q for q in range(ndC)}
    drecT = {q: fbase + ndC + q for q in range(ndT)}
    last = round_recs[-1]
    for k, (_, es) in enumerate(zC):
        c.append("DETECTOR", [rec(drecC[e]) for e in es] + [rec(last[('C', k)])])
    for k, (_, es) in enumerate(zT):
        c.append("DETECTOR", [rec(drecT[e]) for e in es] + [rec(last[('T', k)])])

    obs_id = 0
    for lz in logZC:
        supp = np.flatnonzero(lz)
        c.append("OBSERVABLE_INCLUDE", [rec(drecC[int(q)]) for q in supp], obs_id); obs_id += 1
    for lz in logZT:
        supp = np.flatnonzero(lz)
        c.append("OBSERVABLE_INCLUDE", [rec(drecT[int(q)]) for q in supp], obs_id); obs_id += 1

    return c, dict(nlogC=len(logZC), nlogT=len(logZT), ndC=ndC, ndT=ndT)
