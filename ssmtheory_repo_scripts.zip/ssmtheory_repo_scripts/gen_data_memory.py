import numpy as np, pymatching, json, time
from fcc_sheet_circuit import build_sheet_memory_circuit as BM
def ler(L,p,shots,seed):
    c,_=BM(L,p)
    d,o=c.compile_detector_sampler(seed=seed).sample(shots,separate_observables=True)
    m=pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    pred=m.decode_batch(d)
    nerr=int(np.any(pred!=o,axis=1).sum())
    return nerr/shots, nerr, shots
t0=time.time()
ps=[0.006,0.008,0.010,0.011,0.012,0.014]
out={'p':ps,'curves':{}}
for L,shots in [(4,8000),(6,8000),(8,2500)]:
    row=[]
    for p in ps:
        r=ler(L,p,shots,seed=1000+L)
        row.append(dict(p=p,ler=r[0],nerr=r[1],shots=r[2]))
        print(f"mem L={L} p={p}: {r[0]:.4f}",flush=True)
    out['curves'][str(L)]=row
json.dump(out,open('data_memory_real.json','w'),indent=1)
print(f"done {time.time()-t0:.0f}s")
