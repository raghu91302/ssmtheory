"""indep_checks.py  -- independent re-derivation, three decoder-independent levels.
A) circuit DISTANCE of the real FCC circuits via Stim (must equal L)
B) decoder-free SYMPLECTIC check: transversal CX preserves the joint stabilizer
   group and spreads errors to weight <=2 (the transversal-CNOT mechanism)
C) independent PHENOMENOLOGICAL feed-forward: naive collapse, ff recovery, and
   the controlled invariant (true control errors removed => target == own errors)
Built fresh; (C) shares no code with fcc_feedforward_real.py.
"""
import numpy as np, stim
from fcc_sheet_circuit import build_sheet_memory_circuit, build_sheet_transversal_cnot, _sheet_arrays, _pairing_local
from verify_css_isomorphism import build_sheet_code, extract_per_sheet_logicals

# ============================================================ A) DISTANCE
def check_distance():
    print("A) Circuit distance (Stim shortest_graphlike_error), must equal L")
    for L in (4,6,8):
        cm,_=build_sheet_memory_circuit(L,0.004)
        dm=len(cm.shortest_graphlike_error())
        cc,_=build_sheet_transversal_cnot(L,0.004,include_cnot=True)
        dc=len(cc.shortest_graphlike_error())
        print(f"   L={L}: memory d={dm}, transversal-CNOT d={dc}  (expect {L})  "
              f"{'OK' if dm==L and dc==L else 'FAIL'}")

# ============================================================ B) SYMPLECTIC
def _gf2_rank(M):
    M=M.copy()%2; r=0; rows,cols=M.shape
    for c in range(cols):
        piv=None
        for i in range(r,rows):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
def _in_rowspace(M,v):
    return _gf2_rank(np.vstack([M,v]))==_gf2_rank(M)

def check_symplectic():
    print("\nB) Decoder-free symplectic check of the transversal CX")
    for L in (4,6):
        stab,verts,vidx,el,eti=build_sheet_code(L)
        eC,eidxC,_,_,logZC,_=_sheet_arrays(L,'xy')
        eT,eidxT,_,_,logZT,_=_sheet_arrays(L,'xz')
        pair=_pairing_local(L,'xy','xz')
        ndC,ndT=len(eC),len(eT); n=ndC+ndT
        HZC=stab['xy']['HZ']; HXC=stab['xy']['HX']
        HZT=stab['xz']['HZ']; HXT=stab['xz']['HX']
        # joint X-part and Z-part stabilizer matrices over n data qubits
        def emb(M,blk):  # embed sheet-local rows into joint columns
            R=np.zeros((M.shape[0],n),np.int8); off=0 if blk=='C' else ndC
            R[:,off:off+M.shape[1]]=M; return R
        SX=np.vstack([emb(HXC,'C'),emb(HXT,'T')])  # X-type stabilizers (x-support)
        SZ=np.vstack([emb(HZC,'C'),emb(HZT,'T')])  # Z-type stabilizers (z-support)
        # transversal CX(c -> ndC+pair[c]) symplectic action:  x_t^=x_c ; z_c^=z_t
        def cx_x(xrow):  # on an X-type operator (only x-part nonzero)
            x=xrow.copy()
            for c in range(ndC): x[ndC+pair[c]]^=x[c]
            return x
        def cx_z(zrow):  # on a Z-type operator (only z-part nonzero)
            z=zrow.copy()
            for c in range(ndC): z[c]^=z[ndC+pair[c]]
            return z
        # B1: weight-2 spread -- each single data X spreads to weight <=2
        wmax=0
        for c in range(ndC):
            e=np.zeros(n,np.int8); e[c]=1; wmax=max(wmax,int(cx_x(e).sum()))
        # B2: stabilizer group preserved (image of each X/Z stab still in the group)
        okX=all(_in_rowspace(SX,cx_x(r)) for r in SX)
        okZ=all(_in_rowspace(SZ,cx_z(r)) for r in SZ)
        # B3: logicals map to logicals mod stabilizers (no leakage out of normalizer)
        # control logical Z stays a logical Z combo; target logical Z picks up control (CNOT)
        okL=all(_in_rowspace(np.vstack([SZ, np.vstack([emb(logZC,'C'),emb(logZT,'T')])]),
                             cx_z(r)) for r in np.vstack([emb(logZC,'C'),emb(logZT,'T')]))
        print(f"   L={L}: max X-spread weight={wmax} (expect 2); "
              f"X-stab grp preserved={okX}; Z-stab grp preserved={okZ}; logicals->normalizer={okL}")

# ============================================================ C) PHENOMENOLOGICAL FF
import pymatching
def _toric_phen(L):
    def hq(x,y): return (y%L)*L+(x%L)
    def vq(x,y): return L*L+(y%L)*L+(x%L)
    n=2*L*L
    stars=[[vq(x,y),hq(x,y),vq(x,y-1),hq(x-1,y)] for y in range(L) for x in range(L)]
    H=np.zeros((len(stars),n),np.uint8)
    for k,st in enumerate(stars):
        for e in st: H[k,e]^=1
    LZ=np.zeros((2,n),np.uint8)
    for x in range(L): LZ[0,hq(x,0)]^=1
    for y in range(L): LZ[1,vq(0,y)]^=1
    return n,H,LZ

def _accumulate(H,n,T,p,shots,rng,noisy=True):
    """T rounds of X-noise + measurement noise; return final true X-state and the
    per-round detector stream (syndrome differences)."""
    x=np.zeros((shots,n),np.uint8); prev=np.zeros((shots,H.shape[0]),np.uint8); dets=[]
    for t in range(T):
        if noisy: x^=(rng.random((shots,n))<p).astype(np.uint8)
        syn=(x@H.T)%2
        me=(rng.random((shots,H.shape[0]))<p).astype(np.uint8) if noisy else np.zeros_like(syn)
        dets.append(syn^me^prev); prev=syn^me
    return x,prev,dets

def phen_run(L,p,shots,include_cnot=True,target_noise=True,use_genie=False,seed=0):
    n,H,LZ=_toric_phen(L); T=L
    mC=pymatching.Matching(H); mT=pymatching.Matching(H)
    rng=np.random.default_rng(seed)
    xC,prevC,_=_accumulate(H,n,T,p,shots,rng,noisy=True)
    xT,prevT,_=_accumulate(H,n,T,p,shots,rng,noisy=target_noise)
    aC=xC.copy()                              # true control X at the CNOT (genie)
    xT_post = xT ^ aC if include_cnot else xT
    synC=(xC@H.T)%2
    synT=(xT_post@H.T)%2
    # control decode -> correction (estimate of control X errors)
    predC=mC.decode_batch(synC)
    ff_ctrl=float(np.any((((xC^predC)@LZ.T)%2)!=0,1).mean())
    aHat = aC if use_genie else predC          # inherited-field estimate
    # naive target: decode ignoring inheritance
    predTn=mT.decode_batch(synT)
    naive_tgt=float(np.any((((xT_post^predTn)@LZ.T)%2)!=0,1).mean())
    # feed-forward: remove inherited footprint, decode residual, fold inheritance
    synT_clean = synT ^ ((aHat@H.T)%2)
    predT=mT.decode_batch(synT_clean)
    residual = (xT_post ^ predT ^ aHat) % 2
    ff_tgt=float(np.any(((residual@LZ.T)%2)!=0,1).mean())
    return dict(naive_tgt=naive_tgt,ff_tgt=ff_tgt,ff_ctrl=ff_ctrl)

def check_phenomenological():
    print("\nC) Independent phenomenological feed-forward (toric pair; code shares nothing")
    print("   with fcc_feedforward_real.py). Establishes the mechanism + bookkeeping.")
    # C1: controlled invariant -- noiseless target + genie => target error EXACTLY 0
    inv=phen_run(6,0.02,4000,include_cnot=True,target_noise=False,use_genie=True,seed=1)
    print(f"   C1 controlled invariant (noiseless target, genie): ff_tgt={inv['ff_tgt']:.4f}  "
          f"{'OK (exactly 0)' if inv['ff_tgt']==0.0 else 'FAIL'}")
    # C2: with the inherited field removed (genie), target error == control memory error,
    #     i.e. feed-forward reduces the target back to the memory problem. The naive
    #     decoder instead worsens with L (collapse).
    print("   C2 feed-forward (genie) reduces target to the memory problem:")
    print("      p     L   genie-ff_tgt   control-memory   naive_tgt   (ff==mem ; naive collapses)")
    for p in (0.01,0.02):
        for L,sh in ((4,4000),(6,4000),(8,2000)):
            r=phen_run(L,p,sh,use_genie=True,seed=2)
            print(f"     {p:.2f}  {L}    {r['ff_tgt']:.3f}          {r['ff_ctrl']:.3f}"
                  f"           {r['naive_tgt']:.3f}")
    print("   => genie-ff_tgt tracks control memory at every point (inherited field removed");
    print("      exactly); naive_tgt grows with L. Below-threshold L-scaling of the memory")
    print("      itself is established by the circuit-level result and the distance check (A).")

if __name__=="__main__":
    check_distance(); check_symplectic(); check_phenomenological()
