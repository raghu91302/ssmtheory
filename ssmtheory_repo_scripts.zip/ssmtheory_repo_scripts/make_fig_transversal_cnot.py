"""Publication-quality figure: transversal-CNOT threshold on the real FCC sheet code.
(a) memory threshold  (b) naive MWPM target collapse  (c) feed-forward recovery."""
import json, numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator

mpl.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "font.size": 9,
    "axes.linewidth": 0.7,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.top": True, "ytick.right": True,
    "xtick.major.size": 3.5, "ytick.major.size": 3.5,
    "xtick.minor.size": 2, "ytick.minor.size": 2,
    "legend.frameon": False, "legend.handlelength": 1.6,
    "lines.linewidth": 1.1, "lines.markersize": 4.2,
    "figure.dpi": 200,
})

# Okabe-Ito colorblind-safe
C = {4: "#0072B2", 6: "#D55E00", 8: "#009E73"}
MK = {4: "o", 6: "s", 8: "^"}

def berr(ler, n):
    return np.sqrt(np.maximum(ler, 1e-9) * (1 - np.maximum(ler, 1e-9)) / n)

mem = json.load(open("data_memory_real.json"))
c46 = json.load(open("data_cnot_real_4_6.json"))
c8 = json.load(open("data_cnot_real_8.json"))
gen = json.load(open("data_genie_real.json"))

fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.55))

# ---------- (a) memory threshold ----------
for L in (4, 6, 8):
    row = mem["curves"][str(L)]
    p = np.array([r["p"] for r in row]) * 100
    y = np.array([r["ler"] for r in row])
    n = np.array([r["shots"] for r in row])
    ax[0].errorbar(p, y, yerr=berr(y, n), color=C[L], marker=MK[L],
                   mfc=C[L], mec=C[L], capsize=1.5, lw=1.1,
                   label=fr"$L={L}$")
ax[0].axvline(1.1, color="0.55", lw=0.7, ls=(0, (4, 3)))
ax[0].text(1.13, 0.011, r"$p_{\rm th}\!\approx\!1.1\%$", color="0.35",
           fontsize=7.5, rotation=90, va="bottom", ha="left")
ax[0].set_title(r"(a) Memory", fontsize=9)
ax[0].set_xlabel(r"physical error rate $p$ (%)")
ax[0].set_ylabel("logical error rate")

# ---------- (b) naive MWPM target collapse ----------
for L in (4, 6):
    row = c46["curves"][str(L)]
    p = np.array([r["p"] for r in row]) * 100
    y = np.array([r["naive_tgt"] for r in row]); n = np.array([r["shots"] for r in row])
    ax[1].errorbar(p, y, yerr=berr(y, n), color=C[L], marker=MK[L], mfc="white",
                   mec=C[L], capsize=1.5, lw=1.1, ls=(0, (4, 2)), label=fr"$L={L}$")
p8 = np.array(c8["p"]) * 100
y8 = np.array([r["naive_tgt"] for r in c8["row"]]); n8 = 900
ax[1].errorbar(p8, y8, yerr=berr(y8, n8), color=C[8], marker=MK[8], mfc="white",
               mec=C[8], capsize=1.5, lw=1.1, ls=(0, (4, 2)), label=r"$L=8$")
ax[1].set_title(r"(b) Transversal CNOT, naive MWPM", fontsize=9)
ax[1].set_xlabel(r"physical error rate $p$ (%)")
ax[1].annotate("worsens\nwith $L$", xy=(0.52, 0.40), xytext=(0.52, 0.40),
               xycoords="axes fraction", fontsize=7.5, color="0.3", ha="center")

# ---------- (c) feed-forward recovery ----------
for L in (4, 6):
    row = c46["curves"][str(L)]
    p = np.array([r["p"] for r in row]) * 100
    y = np.array([r["ff_tgt"] for r in row]); n = np.array([r["shots"] for r in row])
    ax[2].errorbar(p, y, yerr=berr(y, n), color=C[L], marker=MK[L], mfc=C[L],
                   mec=C[L], capsize=1.5, lw=1.1, label=fr"$L={L}$")
y8f = np.array([r["ff_tgt"] for r in c8["row"]])
ax[2].errorbar(p8, y8f, yerr=berr(y8f, n8), color=C[8], marker=MK[8], mfc=C[8],
               mec=C[8], capsize=1.5, lw=1.1, label=r"$L=8$")
# memory reference (L=6 control) as thin grey
g6 = gen["curves"]["6"]
pg = np.array([r["p"] for r in g6]) * 100
ax[2].plot(pg, [r["ctrl"] for r in g6], color="0.6", lw=0.9, ls=":",
           label=r"memory ($L{=}6$)", zorder=1)
ax[2].set_title(r"(c) Transversal CNOT, feed-forward", fontsize=9)
ax[2].set_xlabel(r"physical error rate $p$ (%)")
ax[2].annotate("improves\nwith $L$", xy=(0.30, 0.74), xytext=(0.30, 0.74),
               xycoords="axes fraction", fontsize=7.5, color="0.3", ha="center")

for a in ax:
    a.set_yscale("log")
    a.set_ylim(5e-4, 1.0)
    a.set_xlim(0.15, 1.45) if a is not ax[0] else a.set_xlim(0.55, 1.45)
    a.grid(True, which="both", lw=0.3, color="0.9")
    a.legend(loc="lower right", fontsize=7.3)
ax[0].set_xlim(0.55, 1.45)
ax[1].set_xlim(0.15, 0.85)
ax[2].set_xlim(0.15, 0.85)

fig.tight_layout(pad=0.5, w_pad=1.0)
fig.savefig("fig_transversal_cnot.pdf", bbox_inches="tight")
fig.savefig("fig_transversal_cnot.png", bbox_inches="tight", dpi=200)
print("wrote fig_transversal_cnot.pdf/.png")
