"""feedforward_R1_test.py  -- definitive test of architecture claim R1.

Qubit-resolved phenomenological model (Z-memory / X-error sector of the toric
code) so every error mechanism's identity is known and the feed-forward
propagation is exact.  Two toric blocks A(control), B(target); a transversal
CX between rounds_pre-1 and rounds_pre copies A's X-state onto aligned B qubits.

Decoders compared on the TARGET logical:
  naive : decode B on its own space-time graph, inherited field NOT removed.
  ff    : decode A, estimate A's X-pattern at the CNOT (via a per-qubit
          faults_matrix that returns predicted pre-CNOT parity per qubit),
          copy to B, remove its detector footprint, decode the residual,
          fold the inherited logical contribution back in.
  genie : ff but using A's TRUE pattern (decoder upper bound).
"""
import numpy as np, pymatching, argparse, time


def toric_maps(L):
    qH, qV = {}, {}; qid = 0
    for x in range(L):
        for y in range(L): qH[(x, y)] = qid; qid += 1
    for x in range(L):
        for y in range(L): qV[(x, y)] = qid; qid += 1
    pid = {}; k = 0
    for x in range(L):
        for y in range(L): pid[(x, y)] = k; k += 1
    nq = 2 * L * L
    pq = [None] * nq
    for (x, y), q in qH.items(): pq[q] = (pid[(x, y)], pid[(x, (y - 1) % L)])
    for (x, y), q in qV.items(): pq[q] = (pid[(x, y)], pid[((x - 1) % L, y)])
    return qH, qV, pid, np.array(pq), nq


def build_decoder(L, R, p, pq, nq, logical_qubits, per_qubit_pre_rounds=None):
    """Space-time toric matcher. faults_matrix rows:
        row 0            : logical observable (data mechs on logical_qubits, all t)
        rows 1..nq       : (optional) per-qubit parity over t < per_qubit_pre_rounds
    """
    nplaq = L * L
    ndet = nplaq * (R + 1)
    pw = min(max(p, 1e-9), 0.49)
    det = lambda pl, t: pl * (R + 1) + t
    rows, cols, weights = [], [], []
    nfrows = 1 + (nq if per_qubit_pre_rounds is not None else 0)
    frows, fcols = [], []
    logset = set(logical_qubits)
    col = 0
    data_mech = {}
    for t in range(R):
        for q in range(nq):
            p1, p2 = pq[q]
            rows += [det(p1, t), det(p2, t)]; cols += [col, col]
            weights.append(np.log((1 - pw) / pw))
            if q in logset:
                frows.append(0); fcols.append(col)
            if per_qubit_pre_rounds is not None and t < per_qubit_pre_rounds:
                frows.append(1 + q); fcols.append(col)
            data_mech[(q, t)] = col; col += 1
    for t in range(R):
        for pl in range(nplaq):
            rows += [det(pl, t), det(pl, t + 1)]; cols += [col, col]
            weights.append(np.log((1 - pw) / pw)); col += 1
    ncol = col
    H = np.zeros((ndet, ncol), np.uint8); H[rows, cols] = 1
    F = np.zeros((nfrows, ncol), np.uint8)
    if frows: F[frows, fcols] = 1
    m = pymatching.Matching.from_check_matrix(H, weights=np.array(weights), faults_matrix=F)
    return m, det


def run(L, p, rp, rpost, shots, rng):
    R = rp + rpost
    qH, qV, pid, pq, nq = toric_maps(L)
    nplaq = L * L
    Inc = np.zeros((nq, nplaq), np.int32)
    for q in range(nq):
        Inc[q, pq[q][0]] ^= 1; Inc[q, pq[q][1]] ^= 1
    synd = lambda x: (x.astype(np.int32) @ Inc) % 2
    logical = [qH[(x, 0)] for x in range(L)]
    logmask = np.zeros(nq, np.uint8); logmask[logical] = 1

    mA, det = build_decoder(L, R, p, pq, nq, logical, per_qubit_pre_rounds=rp)
    mB, _ = build_decoder(L, R, p, pq, nq, logical, per_qubit_pre_rounds=None)

    detsA = np.zeros((shots, nplaq * (R + 1)), np.uint8)
    detsB = np.zeros((shots, nplaq * (R + 1)), np.uint8)
    xA = np.zeros((shots, nq), np.uint8); xB = np.zeros((shots, nq), np.uint8)
    sAp = np.zeros((shots, nplaq), np.uint8); sBp = np.zeros((shots, nplaq), np.uint8)
    detcols = [[det(pl, t) for pl in range(nplaq)] for t in range(R + 1)]

    def layer(t, sp, x, dets):
        x ^= (rng.random((shots, nq)) < p).astype(np.uint8)
        s = synd(x)
        smeas = s ^ (rng.random((shots, nplaq)) < p).astype(np.uint8)
        dets[:, detcols[t]] = smeas ^ sp
        return smeas

    for t in range(rp):
        sAp = layer(t, sAp, xA, detsA); sBp = layer(t, sBp, xB, detsB)
    aTrue = xA.copy()
    xB ^= xA
    xA ^= (rng.random((shots, nq)) < p).astype(np.uint8)
    xB ^= (rng.random((shots, nq)) < p).astype(np.uint8)
    for tt in range(rpost):
        t = rp + tt
        sAp = layer(t, sAp, xA, detsA); sBp = layer(t, sBp, xB, detsB)
    detsA[:, detcols[R]] = synd(xA) ^ sAp
    detsB[:, detcols[R]] = synd(xB) ^ sBp
    trueA = (xA & logmask).sum(1) % 2
    trueB = (xB & logmask).sum(1) % 2

    # ----- decode A: row0 = logical, rows1.. = per-qubit pre-CNOT parity -----
    fA = mA.decode_batch(detsA)             # (shots, 1+nq)
    predA_log = fA[:, 0]
    aHat = fA[:, 1:]                         # (shots, nq) predicted pre-CNOT X-pattern
    errA = int((predA_log != trueA).sum())

    # ----- target naive -----
    predB_naive = mB.decode_batch(detsB)[:, 0]
    errB_naive = int((predB_naive != trueB).sum())

    # ----- feed-forward & genie -----
    def ff(est):
        # remove inherited footprint (static X appearing at layer rp) from detsB
        d = detsB.copy()
        # for each qubit q with est=1, flip D(B,p1,rp) and D(B,p2,rp)
        flip = np.zeros((shots, nplaq * (R + 1)), np.uint8)
        c1 = np.array([det(pq[q][0], rp) for q in range(nq)])
        c2 = np.array([det(pq[q][1], rp) for q in range(nq)])
        np.bitwise_xor.at(flip, (np.repeat(np.arange(shots), nq).reshape(shots, nq), np.tile(c1, (shots, 1))), est)
        np.bitwise_xor.at(flip, (np.repeat(np.arange(shots), nq).reshape(shots, nq), np.tile(c2, (shots, 1))), est)
        d ^= flip
        predB_res = mB.decode_batch(d)[:, 0]
        inh_log = (est & logmask).sum(1) % 2
        pred = predB_res ^ inh_log
        return int((pred != trueB).sum())

    errB_ff = ff(aHat.astype(np.uint8))
    errB_genie = ff(aTrue.astype(np.uint8))
    return dict(errA=errA / shots, errB_naive=errB_naive / shots,
                errB_ff=errB_ff / shots, errB_genie=errB_genie / shots)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument('--Ls', type=int, nargs='+', default=[4, 6, 8])
    ap.add_argument('--ps', type=float, nargs='+',
                    default=[0.01, 0.02, 0.03, 0.04, 0.05])
    ap.add_argument('--shots', type=int, default=4000)
    a = ap.parse_args()
    rng = np.random.default_rng(2025)
    print("Phenomenological R1 test: control(A) / target naive / target ff / target genie")
    for p in a.ps:
        line = f"p={p:.3f}  "
        for L in a.Ls:
            r = run(L, p, L, L, a.shots, rng)
            line += f"| L{L}: A={r['errA']:.3f} naive={r['errB_naive']:.3f} ff={r['errB_ff']:.3f} gen={r['errB_genie']:.3f} "
        print(line)
