"""bposd_decode.py -- decode a Stim circuit's DEM with BP+OSD (handles the
weight-3 triangle hyperedges that MWPM cannot decompose)."""
import numpy as np, stim
from ldpc import BpOsdDecoder

def dem_to_matrices(dem):
    nD=dem.num_detectors; nO=dem.num_observables
    cols=[]  # (det_list, obs_list, prob)
    def recurse(d, off):
        for inst in d:
            if inst.type=="error":
                pr=inst.args_copy()[0]
                ds=[]; os=[]
                for t in inst.targets_copy():
                    if t.is_relative_detector_id(): ds.append(t.val+off[0])
                    elif t.is_logical_observable_id(): os.append(t.val)
                cols.append((ds,os,pr))
            elif inst.type=="repeat":
                # expand
                body=inst.body_copy(); reps=inst.repeat_count
                for _ in range(reps):
                    recurse(body, off)
                    off[0]+=body.num_detectors
            elif inst.type=="shift_detectors":
                off[0]+=inst.targets_copy()[0]
    recurse(dem.flattened(), [0])
    nE=len(cols)
    H=np.zeros((nD,nE),np.uint8); O=np.zeros((nO,nE),np.uint8); pri=np.zeros(nE)
    for j,(ds,os,pr) in enumerate(cols):
        for d in ds: H[d,j]=1
        for o in os: O[o,j]=1
        pri[j]=max(pr,1e-9)
    return H,O,pri

def make_decoder(circuit):
    dem=circuit.detector_error_model()   # no decompose -> keeps hyperedges
    H,O,pri=dem_to_matrices(dem)
    pri=np.clip(pri,1e-9,0.5)
    dec=BpOsdDecoder(H, error_channel=list(pri), max_iter=30,
                     bp_method="ms", ms_scaling_factor=0.625,
                     osd_method="osd0", osd_order=0)
    return dec,O

def decode_shots(circuit, shots, seed=0):
    dec,O=make_decoder(circuit)
    det,obs=circuit.compile_detector_sampler(seed=seed).sample(shots,separate_observables=True)
    nerr=0
    for i in range(shots):
        eh=dec.decode(det[i].astype(np.uint8))
        pred=(O@eh)%2
        nerr+= int(np.any(pred!=obs[i]))
    return nerr/shots, nerr
