"""Construct an explicit length-L triangle ribbon for cross-sheet ZZ-merge.

For each L in {4, 6, 8}, we:
1. Identify a representative minimum-weight Z-logical on sheet xy (a horizontal
   cycle of length L in layer z=0).
2. Identify the partner minimum-weight Z-logical on sheet xz (a horizontal
   cycle of length L in layer y=0).
3. Construct a chain of L triangles whose Z-edges cover the union of these
   two cycles, with the third-sheet (yz) edges cancelling pairwise in GF(2).
4. Verify that the triangle-product Z operator equals the union of the two
   target logicals modulo stabilizers.
"""
import sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sheet_code_fcc_lattice import build_fcc_lattice, NN_DISPLACEMENTS, SHEETS
import numpy as np
from collections import defaultdict
from itertools import product


def build_lattice_full(L):
    """Build the FCC lattice with full triangle enumeration."""
    vertices, vidx, edges_per_sheet, edge_list, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)

    # Map each edge to which sheet it's in
    edge_sheet = {}
    for s, es in edges_per_sheet.items():
        for e in es:
            edge_sheet[e] = s

    # Build triangle list (3-cycles)
    vert_set = set(range(len(vertices)))
    triangles = []
    seen = set()
    for vp in vertices:
        i = vidx[vp]
        x, y, z = vp
        # nearest neighbors with sheet labels
        nbrs = []
        for s, dirs in NN_DISPLACEMENTS.items():
            for d in dirs:
                wp = ((x + d[0]) % L, (y + d[1]) % L, (z + d[2]) % L)
                j = vidx[wp]
                nbrs.append((j, s))
        # try all pairs
        for ii in range(len(nbrs)):
            for jj in range(ii + 1, len(nbrs)):
                j, sj = nbrs[ii]
                k, sk = nbrs[jj]
                if j == k or sj == sk:
                    continue
                e_jk = (min(j, k), max(j, k))
                if e_jk not in edge_to_idx:
                    continue
                sjk = edge_sheet[e_jk]
                if sjk == sj or sjk == sk:
                    continue
                tri = tuple(sorted([i, j, k]))
                if tri in seen:
                    continue
                seen.add(tri)
                e_ij = (min(i, j), max(i, j))
                e_ik = (min(i, k), max(i, k))
                triangles.append({
                    'verts': tri,
                    'edges_by_sheet': {sj: e_ij, sk: e_ik, sjk: e_jk}
                })
    return vertices, vidx, edges_per_sheet, edge_list, edge_to_idx, edge_sheet, triangles


def construct_layer_cycle(L, sheet, layer_coord):
    """Construct a length-L Z-logical on the given sheet, in the given layer.

    For sheet 'xy' at z=z0: horizontal cycle going around the x direction at y=0, z=z0.
    Edges of the cycle are (x,y,z)-(x+1,y+1,z) and (x+1,y+1,z)-(x+2,y,z) etc.

    For a clean cycle, we pick: y oscillates between 0 and 1, x increments by 1
    each edge; total of L edges.
    """
    vertices, vidx, edges_per_sheet, _, edge_to_idx, edge_sheet, _ = build_lattice_full(L)
    cycle_edges = []

    if sheet == 'xy':
        # Layer z = layer_coord, cycle in x going around the torus
        z = layer_coord
        for x in range(L):
            y0 = (x + z) % 2  # parity constraint: x+y+z must be even
            y1 = 1 - y0
            # Pick a step that's in xy: dx=±1, dy=±1, dz=0
            v1 = (x, y0, z)
            v2 = ((x + 1) % L, y1, z)
            if v1 in vidx and v2 in vidx:
                i, j = vidx[v1], vidx[v2]
                e = (min(i, j), max(i, j))
                if e in edge_to_idx and edge_sheet[e] == 'xy':
                    cycle_edges.append(e)
    elif sheet == 'xz':
        # Layer y = layer_coord, cycle in x going around the torus
        y = layer_coord
        for x in range(L):
            z0 = (x + y) % 2
            z1 = 1 - z0
            v1 = (x, y, z0)
            v2 = ((x + 1) % L, y, z1)
            if v1 in vidx and v2 in vidx:
                i, j = vidx[v1], vidx[v2]
                e = (min(i, j), max(i, j))
                if e in edge_to_idx and edge_sheet[e] == 'xz':
                    cycle_edges.append(e)
    return cycle_edges


def verify_cycle_is_closed(L, sheet, cycle_edges):
    """Check that the cycle edges form a closed 1-cycle (every vertex has even degree).

    NOTE: This is a NECESSARY but NOT SUFFICIENT condition for being a non-trivial
    logical operator.  A closed cycle could be:
      (a) a stabilizer element (trivial logical, i.e., contractible),
      (b) a non-trivial logical (non-contractible), or
      (c) a sum of (a) and (b).

    To distinguish (a) from (b), one would additionally need to check that the
    cycle does not lie in rowspace(H_X) -- i.e., that it represents a non-trivial
    homology class.  We do not perform that check here; the closed-cycle test
    is sufficient for our usage in find_ribbon below because the source cycles
    cycle_a and cycle_b are constructed by hand to be non-trivial winding loops
    of weight L (see construct_layer_cycle).
    """
    vert_count = defaultdict(int)
    for e in cycle_edges:
        i, j = e
        vert_count[i] += 1
        vert_count[j] += 1
    # All vertex counts must be even (closed cycle)
    for v, c in vert_count.items():
        if c % 2 != 0:
            return False, f"Vertex {v} has odd count {c}"
    return True, f"OK: closed cycle of weight {len(cycle_edges)}"


# Backwards-compatible alias (deprecated) for older scripts that may import it
verify_cycle_is_logical = verify_cycle_is_closed


def find_ribbon(L, cycle_a, cycle_b, triangles):
    """Find the explicit ribbon subset used by the construction: for each xy edge of
    cycle_a, pick the (first matching) triangle whose xy edge equals it and whose xz
    edge lies on cycle_b.  This produces a valid length-L ribbon whose Z-edge product
    equals cycle_a + cycle_b mod 2, with yz contributions cancelling pairwise.  It does
    NOT minimize the number of triangles globally across all valid ribbons -- it
    produces the specific length-L construction analyzed in the paper.

    We need: sum_{t in ribbon} (triangle_t edges) = cycle_a + cycle_b (mod 2).

    With third-sheet (yz) edges cancelling pairwise.

    Strategy: For each (x,y,z)=adjacent pair in the joint cycle, find a triangle
    whose two non-yz edges are an edge of cycle_a (xy) and an edge of cycle_b (xz).
    """
    # Build edge_to_triangle index
    edge_to_tris = defaultdict(list)
    for t_idx, t in enumerate(triangles):
        for s, e in t['edges_by_sheet'].items():
            edge_to_tris[e].append(t_idx)

    cycle_a_set = set(cycle_a)
    cycle_b_set = set(cycle_b)
    # For each xy edge in cycle_a, find triangles containing it
    ribbon = []
    used_yz_edges = defaultdict(int)
    used_xz_edges = defaultdict(int)

    for ea in cycle_a:
        candidates = edge_to_tris[ea]
        # Each candidate triangle has one xy edge (= ea), one xz edge, one yz edge
        # We want to pick one whose xz edge is in cycle_b
        chosen = None
        for t_idx in candidates:
            t = triangles[t_idx]
            ebs = t['edges_by_sheet']
            if 'xz' in ebs and ebs['xz'] in cycle_b_set:
                chosen = t_idx
                break
        if chosen is None:
            return None, f"No triangle found containing xy edge {ea} and matching cycle_b"
        ribbon.append(chosen)
        ebs = triangles[chosen]['edges_by_sheet']
        if 'yz' in ebs:
            used_yz_edges[ebs['yz']] += 1
        if 'xz' in ebs:
            used_xz_edges[ebs['xz']] += 1

    # Tally distinct atoms touched by the ribbon, per sheet. This is the "atoms reserved
    # during the merge" count from Table 5 of the paper.
    distinct_xy = set()
    distinct_xz = set()
    distinct_yz = set()
    for t_idx in ribbon:
        ebs = triangles[t_idx]['edges_by_sheet']
        if 'xy' in ebs: distinct_xy.add(ebs['xy'])
        if 'xz' in ebs: distinct_xz.add(ebs['xz'])
        if 'yz' in ebs: distinct_yz.add(ebs['yz'])

    # Check: each yz edge used even number of times, each xz edge in cycle_b used odd
    yz_residual = [e for e, c in used_yz_edges.items() if c % 2 == 1]
    xz_residual_in_cycle = sum(1 for e, c in used_xz_edges.items() if c % 2 == 1 and e in cycle_b_set)
    xz_residual_out_cycle = sum(1 for e, c in used_xz_edges.items() if c % 2 == 1 and e not in cycle_b_set)

    return ribbon, {
        'n_triangles': len(ribbon),
        'yz_residual_count': len(yz_residual),
        'xz_residual_in_cycle': xz_residual_in_cycle,
        'xz_residual_out_cycle': xz_residual_out_cycle,
        'yz_residual_edges': yz_residual[:5],
        'distinct_xy_atoms': len(distinct_xy),
        'distinct_xz_atoms': len(distinct_xz),
        'distinct_yz_atoms': len(distinct_yz),
    }


def main():
    print("Triangle ribbon analysis for cross-sheet ZZ-merge")
    print("=" * 75)
    results = {}
    for L in [4, 6, 8]:
        print(f"\nL = {L}")
        print("-" * 50)
        vertices, vidx, edges_per_sheet, edge_list, edge_to_idx, edge_sheet, triangles = build_lattice_full(L)
        print(f"  Lattice: {len(vertices)} vertices, {len(edge_list)} edges, {len(triangles)} triangles")

        # Construct two cross-sheet logicals
        cycle_a = construct_layer_cycle(L, 'xy', 0)
        cycle_b = construct_layer_cycle(L, 'xz', 0)
        print(f"  Z-logical on sheet xy (layer z=0): {len(cycle_a)} edges")
        print(f"  Z-logical on sheet xz (layer y=0): {len(cycle_b)} edges")

        ok_a, msg_a = verify_cycle_is_closed(L, 'xy', cycle_a)
        ok_b, msg_b = verify_cycle_is_closed(L, 'xz', cycle_b)
        print(f"  Cycle A: {msg_a}")
        print(f"  Cycle B: {msg_b}")

        # Find a ribbon
        ribbon, info = find_ribbon(L, cycle_a, cycle_b, triangles)
        if ribbon is None:
            print(f"  Ribbon search failed: {info}")
            continue
        print(f"  Ribbon: {info['n_triangles']} triangles")
        print(f"  yz-edge residual (should be 0 for clean cancellation): {info['yz_residual_count']}")
        if info['yz_residual_count'] != 0:
            print(f"    First few residual yz edges: {info['yz_residual_edges']}")
        print(f"  xz-edge match: {info['xz_residual_in_cycle']} in cycle_b (want {len(cycle_b)}), "
              f"{info['xz_residual_out_cycle']} outside")
        # Table 5 verification: distinct atoms touched per sheet
        print(f"  Distinct atoms touched per sheet (Table 5):")
        print(f"    S_xy: {info['distinct_xy_atoms']} (expect L = {L})")
        print(f"    S_xz: {info['distinct_xz_atoms']} (expect L = {L})")
        print(f"    S_yz: {info['distinct_yz_atoms']} (expect L/2 = {L // 2})")
        # Assertions matching the paper's Table 5 row values
        assert info['n_triangles'] == L, \
            f"Ribbon length should be L={L}, got {info['n_triangles']}"
        assert info['yz_residual_count'] == 0, \
            f"yz residual should be 0, got {info['yz_residual_count']}"
        assert info['distinct_xy_atoms'] == L, \
            f"distinct S_xy atoms should be L={L}, got {info['distinct_xy_atoms']}"
        assert info['distinct_xz_atoms'] == L, \
            f"distinct S_xz atoms should be L={L}, got {info['distinct_xz_atoms']}"
        assert info['distinct_yz_atoms'] == L // 2, \
            f"distinct S_yz atoms should be L/2={L//2}, got {info['distinct_yz_atoms']}"

        results[L] = {
            'n_triangles': info['n_triangles'],
            'cycle_a_weight': len(cycle_a),
            'cycle_b_weight': len(cycle_b),
            'yz_residual': info['yz_residual_count'],
            'distinct_yz': info['distinct_yz_atoms'],
        }

    print("\n" + "=" * 75)
    print("Summary (matches Table 5 of the paper):")
    print(f"{'L':>3} | {'cycle_a':>8} | {'cycle_b':>8} | {'ribbon':>7} | {'yz_residual':>12} | {'S_yz atoms (L/2)':>18}")
    for L in sorted(results.keys()):
        r = results[L]
        print(f"{L:>3} | {r['cycle_a_weight']:>8} | {r['cycle_b_weight']:>8} | "
              f"{r['n_triangles']:>7} | {r['yz_residual']:>12} | {r['distinct_yz']:>18}")

if __name__ == '__main__':
    main()
