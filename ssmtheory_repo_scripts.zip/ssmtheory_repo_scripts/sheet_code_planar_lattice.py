"""Planar variant of the FCC sheet code lattice.

Open-boundary FCC lattice (no modular wraparound), with boundary edges/vertices
and per-sheet stabilizer construction. Boundary vertices have lower-weight
stabilizers (typically 2 instead of 4).

Per-sheet logical count for the planar variant: L per sheet (one per layer),
compared to 2L for the toric variant (two homology cycles per layer).
"""
import numpy as np
from itertools import product
from sheet_code_fcc_lattice import NN_DISPLACEMENTS, SHEETS


def build_fcc_lattice_planar(L):
    """Build the planar (open-boundary) FCC lattice in [0, L-1]^3.

    Returns
    -------
    vertices : list of (x, y, z)
        Vertex positions with x+y+z even.
    vidx : dict
        position -> vertex index.
    edges : list of (i, j)
        Sorted list of edge endpoint pairs.
    edges_dup : same as `edges`
        Kept for tuple-arity compatibility with the toric counterpart.
    edge_to_idx : dict
        edge -> flat index.
    edge_to_sheet : list
        Sheet label for each edge, same order as `edges`.
    """
    vertices = []
    vidx = {}
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x + y + z) % 2 == 0:
                    vidx[(x, y, z)] = len(vertices)
                    vertices.append((x, y, z))

    edges_set = set()
    edge_sheet_map = {}

    for v1_pos in vertices:
        x1, y1, z1 = v1_pos
        for sheet, displacements in NN_DISPLACEMENTS.items():
            for d in displacements:
                dx, dy, dz = d
                x2, y2, z2 = x1 + dx, y1 + dy, z1 + dz
                if not (0 <= x2 < L and 0 <= y2 < L and 0 <= z2 < L):
                    continue
                v2_pos = (x2, y2, z2)
                if v2_pos not in vidx:
                    continue
                i1, i2 = vidx[v1_pos], vidx[v2_pos]
                edge = (min(i1, i2), max(i1, i2))
                if edge in edges_set:
                    continue
                edges_set.add(edge)
                edge_sheet_map[edge] = sheet

    edges = sorted(edges_set)
    edge_to_idx = {e: i for i, e in enumerate(edges)}
    edge_to_sheet = [edge_sheet_map[e] for e in edges]
    return vertices, vidx, edges, edges, edge_to_idx, edge_to_sheet


def fcc_triangles_planar(L):
    """Enumerate triangles whose all 3 edges lie in the planar lattice.

    A triangle is a 3-cycle in the FCC nearest-neighbor graph. In the planar
    (open-boundary) variant, triangles that would cross the boundary are dropped.

    Returns
    -------
    triangles : list of ((vi, vj, vk), [e_ij_idx, e_ik_idx, e_jk_idx])
        Each triangle is (sorted vertex indices, list of three edge indices).
    B : np.ndarray, shape (n_triangles, n_edges), dtype=int8
        Triangle-incidence matrix: B[t, e] = 1 iff edge e is in triangle t.
    """
    vertices, vidx, edges, _, edge_to_idx, _ = build_fcc_lattice_planar(L)
    n_edges = len(edges)

    triangles = []
    for vi, v_pos in enumerate(vertices):
        x, y, z = v_pos
        nn_list = []
        for sheet, dlist in NN_DISPLACEMENTS.items():
            for d in dlist:
                v2 = (x + d[0], y + d[1], z + d[2])
                if not (0 <= v2[0] < L and 0 <= v2[1] < L and 0 <= v2[2] < L):
                    continue
                if v2 in vidx:
                    nn_list.append(vidx[v2])
        for ii, na in enumerate(nn_list):
            for nb in nn_list[ii + 1:]:
                if vi >= na or vi >= nb:
                    continue
                if na >= nb:
                    continue
                e_ab = (min(na, nb), max(na, nb))
                if e_ab not in edge_to_idx:
                    continue
                e_va = (min(vi, na), max(vi, na))
                e_vb = (min(vi, nb), max(vi, nb))
                if e_va not in edge_to_idx or e_vb not in edge_to_idx:
                    continue
                tri = tuple(sorted([vi, na, nb]))
                triangles.append((tri, [edge_to_idx[e_va], edge_to_idx[e_vb],
                                        edge_to_idx[e_ab]]))

    B = np.zeros((len(triangles), n_edges), dtype=np.int8)
    for ti, (_, edge_idxs) in enumerate(triangles):
        for ei in edge_idxs:
            B[ti, ei] = 1
    return triangles, B


if __name__ == '__main__':
    for L in [4, 6]:
        vertices, vidx, edges, _, _, edge_to_sheet = build_fcc_lattice_planar(L)
        triangles, B = fcc_triangles_planar(L)
        from collections import Counter
        sheet_counts = Counter(edge_to_sheet)
        print(f"L={L}: {len(vertices)} vertices, {len(edges)} edges, "
              f"{len(triangles)} triangles")
        print(f"  edges per sheet: {dict(sheet_counts)}")
