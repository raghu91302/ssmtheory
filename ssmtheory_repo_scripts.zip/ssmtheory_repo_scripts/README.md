# ssmtheory — reproducibility scripts

Scripts and data accompanying *A high-throughput parallel-teleportation interface for the
FCC sheet code*. This archive is the `ssmtheory_repo_scripts.zip` referenced in the paper's
Code and Data Availability section.

All files are flat; run every script from inside this directory (sibling imports and the
data-file paths resolve relative to the working directory).

## Environment

```
python3 -m pip install -r requirements.txt
```

Tested with Python 3.12, Stim 1.16, PyMatching 2.4, numpy 2.x, scipy 1.x, matplotlib 3.x.

## Script-to-claim map

### Structural results (exact, GF(2))
- `verify_css_isomorphism.py` — Computational Result 1 (R is a CSS isomorphism; (2L)x(2L)
  symplectic-permutation logical action), L = 4, 6, 8.
- `verify_layer_decomposition.py` — Theorem 2 (each sheet = L stacked 2D toric codes
  [[L^2, 2, L]]), L = 4, 6, 8.
- `verify_cross_sheet_reachability.py` — Computational Result 3, L = 4, 6.
- `triangle_ribbon_analysis.py`, `ribbon_construction.py` — triangle-ribbon surgery and the
  3L/2 merge footprint, L = 4, 6, 8.
- `sheet_code_fcc_lattice.py`, `sheet_code_planar_lattice.py` — lattice / stabilizer
  construction (imported by the above).

### Threshold results (circuit-level depolarizing; Stim + PyMatching)
- `fcc_sheet_circuit.py` — full sheet-code circuits from the actual stabilizers: weight-4
  memory circuit (Fig. 2a) and the two-sheet transversal-CNOT circuit with the real rotation
  pairing pi (Fig. 2b,c). The memory decoding graph separates into L components.
- `fcc_feedforward_real.py` — the correlated **feed-forward** decoder for the transversal
  CNOT, the naive-MWPM baseline, the idealized error-frame ("genie") decoder, and the
  controlled-noise validation of the inherited-field bookkeeping.
- `sweep_memory_threshold.py`, `sweep_zz_merge_threshold.py`,
  `sweep_transversal_cnot_threshold.py` — threshold sweep drivers.
- `make_arch_fig.py` — Figure 1. `make_fig_transversal_cnot.py` — Figure 2 from the JSON below.

### Figure 2 data
`data_memory_real.json`, `data_cnot_real_4_6.json`, `data_cnot_real_8.json`,
`data_genie_real.json` are the raw shot counts behind Figure 2. Regenerate with:

```
python3 gen_data_memory.py
python3 gen_data_cnot.py 4,6
python3 gen_data_cnot_L8.py
python3 gen_data_genie.py
python3 make_fig_transversal_cnot.py
```

The shipped figure reproduces from the shipped JSON.

### Supplementary validation
- `feedforward_R1_test.py` — phenomenological two-block transversal-CNOT model with a fully
  qubit-resolved feed-forward decoder; an independent proof-of-principle that correlated
  decoding restores the threshold.
- `fcc_transversal_circuit.py` — per-layer toric representative of the transversal-CNOT
  experiment (the layer-decomposition reduction), superseded by `fcc_sheet_circuit.py`.

## Reproducing R1 in one line

```
python3 -c "from fcc_feedforward_real import run; print(run(6, 0.004, 3000))"
```

prints the target-sheet logical error under naive MWPM (`naive_tgt`, collapsed) and under
feed-forward decoding (`ff_tgt`, recovered), plus the control-side error.

## Caveats
- Threshold preservation for the transversal CNOT requires the feed-forward decoder; the
  load-bearing logic is the transversal-layer identification in `_cnot_tick` /
  `_split_at_cnot` (the target of the CNOT is a data qubit, not an ancilla). The
  controlled-noise test in `fcc_feedforward_real.py` is the cheapest independent check.
- L = 8 threshold points use ~10^3 shots; conclusions rest on L = 4, 6.
- The surgery thresholds from `sweep_zz_merge_threshold.py` were not re-derived on the real
  circuits in the same manner as the transversal-CNOT result.
