"""verify_css_isomorphism.py
=========================================================================
Verify Computational Result 1 of the architecture paper:
the threefold-rotation R: (x,y,z) -> (y,z,x) is a CSS isomorphism of the
FCC sheet code, with induced action on logicals a (2L) x (2L) permutation
matrix preserving the symplectic pairing.

Computational checks at L in {4, 6, 8}:

  (a) R is a permutation of the edge set E and maps the edges of each
      sheet T in {S_xy, S_xz, S_yz} to the edges of R(T).
  (b) For every vertex Z-stabilizer g of sheet T, the image pi(g) under
      the edge permutation is identically a vertex Z-stabilizer of sheet
      R(T). Similarly for octahedral X-stabilizers.
  (c) The induced action on logicals is a (2L) x (2L) permutation matrix
      preserving the X/Z type and the symplectic pairing.

Run:
    python3 verify_css_isomorphism.py

Exit code 0 iff all checks pass at all tested L.
"""
import os
import sys
import numpy as np
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sheet_code_fcc_lattice import build_fcc_lattice, NN_DISPLACEMENTS, SHEETS


# --------------------------------------------------------------------------
# Linear algebra over GF(2)
# --------------------------------------------------------------------------

def gf2_rref(M):
    """Reduced row-echelon form over GF(2). Returns (rref, pivot_cols, rank)."""
    M = M.copy().astype(np.int8) % 2
    rows, cols = M.shape
    pivots = []
    r = 0
    for c in range(cols):
        # Find pivot row
        piv = None
        for i in range(r, rows):
            if M[i, c] == 1:
                piv = i
                break
        if piv is None:
            continue
        # Swap
        if piv != r:
            M[[r, piv]] = M[[piv, r]]
        # Eliminate
        for i in range(rows):
            if i != r and M[i, c] == 1:
                M[i] = (M[i] + M[r]) % 2
        pivots.append(c)
        r += 1
    return M, pivots, r


def gf2_rank(M):
    return gf2_rref(M)[2]


def gf2_kernel_basis(M):
    """Return rows of a matrix whose rows form a basis for the kernel of M (mod 2)."""
    rows, cols = M.shape
    rref, pivots, rank = gf2_rref(M)
    pivot_set = set(pivots)
    free_cols = [c for c in range(cols) if c not in pivot_set]
    basis = []
    for fc in free_cols:
        v = np.zeros(cols, dtype=np.int8)
        v[fc] = 1
        for i, pc in enumerate(pivots):
            if rref[i, fc] == 1:
                v[pc] = 1
        basis.append(v)
    return np.array(basis, dtype=np.int8) if basis else np.zeros((0, cols), dtype=np.int8)


def gf2_in_rowspace(M, v):
    """Test whether vector v lies in the row space of M over GF(2)."""
    rows, cols = M.shape
    assert len(v) == cols
    aug = np.vstack([M, v.reshape(1, -1)]).astype(np.int8)
    return gf2_rank(aug) == gf2_rank(M)


# --------------------------------------------------------------------------
# FCC sheet code construction
# --------------------------------------------------------------------------

def build_sheet_code(L):
    """Build the three-sheet FCC code. Returns dict with stabilizer matrices."""
    vertices, vidx, edges_per_sheet, edge_list, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)
    n_edges = len(edge_list)
    n_vertices = len(vertices)

    # Build per-sheet Z-stabilizers: one row per (vertex, sheet) where the
    # vertex has nonzero edges in that sheet. Each row has weight 4 (= K=4).
    # We split by sheet to make the per-sheet code structure explicit.
    stabilizers = {}
    for sheet in SHEETS:
        edges_s = edges_per_sheet[sheet]
        edge_idx_s = {e: i for i, e in enumerate(edges_s)}
        n_s = len(edges_s)

        # Z-stabs: one per vertex (those vertices that have edges in this sheet)
        vert_to_edges_s = defaultdict(list)
        for e in edges_s:
            i, j = e
            vert_to_edges_s[i].append(e)
            vert_to_edges_s[j].append(e)
        z_stab_rows = []
        for v, es_at_v in vert_to_edges_s.items():
            if len(es_at_v) == 0:
                continue
            row = np.zeros(n_s, dtype=np.int8)
            for e in es_at_v:
                row[edge_idx_s[e]] = 1
            z_stab_rows.append(row)
        HZ_s = np.array(z_stab_rows, dtype=np.int8) if z_stab_rows else np.zeros((0, n_s), dtype=np.int8)

        # X-stabs: one per octahedral void within this sheet
        # An octahedral void is at an odd-parity site; for sheet S_{ab}, the
        # relevant void selects the 4 edges in the {a,b} plane forming a
        # square around the void center.
        x_stab_rows = build_octahedral_x_stabilizers(L, sheet, vertices, vidx, edge_idx_s, edges_s)
        HX_s = np.array(x_stab_rows, dtype=np.int8) if x_stab_rows else np.zeros((0, n_s), dtype=np.int8)

        stabilizers[sheet] = {
            'HZ': HZ_s,
            'HX': HX_s,
            'edges': edges_s,
            'edge_idx': edge_idx_s,
            'n_edges': n_s,
        }
    return stabilizers, vertices, vidx, edge_list, edge_to_idx


def build_octahedral_x_stabilizers(L, sheet, vertices, vidx, edge_idx_s, edges_s):
    """Octahedral X-stabilizers for a given sheet. Each void at an odd-parity
    site is surrounded by 6 vertices forming an octahedron; the 4 edges
    within sheet {ab} (a,b are the two sheet axes) connecting these 6 vertices
    form a weight-4 X-stabilizer."""
    # Sheet axes
    axes = {'xy': (0, 1), 'xz': (0, 2), 'yz': (1, 2)}[sheet]
    a, b = axes
    rows = []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                center = (x, y, z)
                # Octahedral voids: odd parity sites
                if (x + y + z) % 2 != 1:
                    continue
                # The 6 octahedron vertices are at center +/- e_i for i in {x,y,z}
                surrounding = []
                for axis in range(3):
                    for sign in [1, -1]:
                        d = [0, 0, 0]
                        d[axis] = sign
                        nb = ((center[0] + d[0]) % L,
                              (center[1] + d[1]) % L,
                              (center[2] + d[2]) % L)
                        if nb in vidx:
                            surrounding.append(nb)
                if len(surrounding) != 6:
                    continue
                # Find the 4 edges within the sheet (axes a, b) connecting these 6
                # vertices. These are the edges where the displacement vector is
                # in the {a, b} plane.
                row = np.zeros(len(edges_s), dtype=np.int8)
                ones = 0
                for i in range(len(surrounding)):
                    for j in range(i + 1, len(surrounding)):
                        vi = surrounding[i]
                        vj = surrounding[j]
                        # Displacement
                        d = [(vj[k] - vi[k]) % L for k in range(3)]
                        # Normalize to nearest-neighbor direction
                        d_n = tuple(dk if dk <= L // 2 else dk - L for dk in d)
                        # Must be a sheet displacement: nonzero in axes a, b; zero elsewhere
                        sheet_axes_set = set([a, b])
                        nonzero_axes = set(k for k in range(3) if d_n[k] != 0)
                        if nonzero_axes != sheet_axes_set:
                            continue
                        # Must be unit length in those axes
                        if any(abs(d_n[k]) != 1 for k in nonzero_axes):
                            continue
                        # Find the edge
                        i_v = vidx[vi]
                        j_v = vidx[vj]
                        e = (min(i_v, j_v), max(i_v, j_v))
                        if e in edge_idx_s:
                            row[edge_idx_s[e]] = 1
                            ones += 1
                if ones == 4:
                    rows.append(row)
    return rows


# --------------------------------------------------------------------------
# Rotation R
# --------------------------------------------------------------------------

def rotation_permutation(L, vertices, vidx, edge_list, edge_to_idx):
    """Return pi: edge_idx -> edge_idx, the permutation induced by R."""
    def R_vertex(v):
        x, y, z = v
        return (y, z, x)

    pi = np.zeros(len(edge_list), dtype=np.int64)
    for e_idx, (i, j) in enumerate(edge_list):
        vi, vj = vertices[i], vertices[j]
        Rvi = R_vertex(vi)
        Rvj = R_vertex(vj)
        ii = vidx[Rvi]
        jj = vidx[Rvj]
        e_rot = (min(ii, jj), max(ii, jj))
        pi[e_idx] = edge_to_idx[e_rot]
    return pi


def sheet_of_edge_under_rotation(sheet):
    """The rotation R cycles sheets: xy -> xz -> yz -> xy."""
    return {'xy': 'xz', 'xz': 'yz', 'yz': 'xy'}[sheet]


# --------------------------------------------------------------------------
# Verification checks
# --------------------------------------------------------------------------

def check_edge_permutation(L, edges_per_sheet, edge_to_idx, pi):
    """Verify pi is a bijection that maps edges of T to edges of R(T)."""
    # pi must be a permutation
    assert len(set(pi)) == len(pi), "pi is not a permutation"
    # For each sheet, check pi(edges of T) = edges of R(T)
    for T in SHEETS:
        RT = sheet_of_edge_under_rotation(T)
        edges_T = set(edge_to_idx[e] for e in edges_per_sheet[T])
        edges_RT = set(edge_to_idx[e] for e in edges_per_sheet[RT])
        pi_edges_T = set(int(pi[e]) for e in edges_T)
        assert pi_edges_T == edges_RT, \
            f"pi(edges of {T}) != edges of {RT}: " \
            f"diff = {pi_edges_T.symmetric_difference(edges_RT)}"
    return True


def check_stabilizer_preservation(L, stabilizers, edges_per_sheet, edge_to_idx, pi):
    """Verify that pi maps every stabilizer of sheet T to a stabilizer of R(T)."""
    # Build a global-edge representation for each per-sheet stabilizer
    def lift_to_global(row_in_sheet, sheet):
        """Convert a 0/1 row over a sheet's edges into a 0/1 row over all edges."""
        global_row = np.zeros(len(edge_to_idx), dtype=np.int8)
        for local_idx, val in enumerate(row_in_sheet):
            if val == 1:
                e = edges_per_sheet[sheet][local_idx]
                global_row[edge_to_idx[e]] = 1
        return global_row

    pi_inv = np.argsort(pi)

    for T in SHEETS:
        RT = sheet_of_edge_under_rotation(T)
        HZ_T_global = np.array([lift_to_global(r, T) for r in stabilizers[T]['HZ']],
                               dtype=np.int8)
        HZ_RT_global = np.array([lift_to_global(r, RT) for r in stabilizers[RT]['HZ']],
                                dtype=np.int8)
        HX_T_global = np.array([lift_to_global(r, T) for r in stabilizers[T]['HX']],
                               dtype=np.int8)
        HX_RT_global = np.array([lift_to_global(r, RT) for r in stabilizers[RT]['HX']],
                                dtype=np.int8)

        # Apply pi: pi acts by permuting columns of stabilizer matrices
        # New row at column pi(c) = old row at column c
        HZ_T_pi = np.zeros_like(HZ_T_global)
        HZ_T_pi[:, pi] = HZ_T_global
        HX_T_pi = np.zeros_like(HX_T_global)
        HX_T_pi[:, pi] = HX_T_global

        # Each row of HZ_T_pi must equal some row of HZ_RT_global identically
        HZ_RT_rows = set(tuple(r) for r in HZ_RT_global)
        for r in HZ_T_pi:
            assert tuple(r) in HZ_RT_rows, \
                f"Z-stab from sheet {T} does not map to a Z-stab of sheet {RT} identically"
        HX_RT_rows = set(tuple(r) for r in HX_RT_global)
        for r in HX_T_pi:
            assert tuple(r) in HX_RT_rows, \
                f"X-stab from sheet {T} does not map to an X-stab of sheet {RT} identically"
    return True


def extract_per_sheet_logicals(stabilizers, sheet):
    """Extract a canonical logical basis for one sheet. Returns (M_X, M_Z) where
    M_X[i] and M_Z[i] are the i-th logical X and Z operators (rows over the
    sheet's edges), normalized so M_X @ M_Z.T = I (mod 2)."""
    HZ = stabilizers[sheet]['HZ']
    HX = stabilizers[sheet]['HX']
    n = stabilizers[sheet]['n_edges']

    # logical Z operators: ker(HX) modulo rowspace(HZ)
    ker_HX = gf2_kernel_basis(HX)
    # Project out the HZ rowspace from ker_HX by Gaussian elimination keeping
    # the HZ rows as the "stabilizer" part.
    combined = np.vstack([HZ, ker_HX]).astype(np.int8)
    rref_c, pivots_c, _ = gf2_rref(combined)
    # Rows of rref_c beyond rank(HZ) that are nonzero and have pivot column
    # within ker_HX cols give a logical-Z basis. We instead just compute
    # k = dim ker(HX) - rank(HZ) and pick rows of ker_HX outside rowspace(HZ).
    # Simpler approach: incremental construction.
    rank_HZ = gf2_rank(HZ)
    logical_Z = []
    M = HZ.copy().astype(np.int8) if HZ.size else np.zeros((0, n), dtype=np.int8)
    for v in ker_HX:
        if not gf2_in_rowspace(M, v):
            logical_Z.append(v)
            M = np.vstack([M, v.reshape(1, -1)])
    logical_Z = np.array(logical_Z, dtype=np.int8) if logical_Z else np.zeros((0, n), dtype=np.int8)

    # logical X operators: ker(HZ) modulo rowspace(HX)
    ker_HZ = gf2_kernel_basis(HZ)
    logical_X = []
    M = HX.copy().astype(np.int8) if HX.size else np.zeros((0, n), dtype=np.int8)
    for v in ker_HZ:
        if not gf2_in_rowspace(M, v):
            logical_X.append(v)
            M = np.vstack([M, v.reshape(1, -1)])
    logical_X = np.array(logical_X, dtype=np.int8) if logical_X else np.zeros((0, n), dtype=np.int8)

    return logical_X, logical_Z


def symplectic_normalize(M_X, M_Z, HX, HZ):
    """Bring (M_X, M_Z) to canonical form with M_X @ M_Z.T = I (mod 2),
    using row operations modulo stabilizers."""
    k = len(M_X)
    if k == 0:
        return M_X, M_Z

    # Compute pairing matrix P[i,j] = <M_X[i], M_Z[j]> = M_X[i] . M_Z[j] mod 2
    P = (M_X @ M_Z.T) % 2

    # Reduce P to identity via row operations on M_X and column operations on M_Z
    # (modulo stabilizers, these are free).
    # Use Gaussian elimination on the 2k x 2k symplectic pairing.
    for i in range(k):
        # Find a row r >= i in M_X such that <M_X[r], M_Z[i]> = 1
        # (i.e., P[r, i] = 1).
        # If P[i,i] is already 1, OK. Otherwise find another row.
        if P[i, i] != 1:
            found = False
            for r in range(i + 1, k):
                if P[r, i] == 1:
                    # Swap rows i and r of M_X and rows i and r of P
                    M_X[[i, r]] = M_X[[r, i]]
                    P[[i, r]] = P[[r, i]]
                    found = True
                    break
            if not found:
                # Find a column c >= i with P[i, c] = 1, swap M_Z columns
                for c in range(i, k):
                    if P[i, c] == 1:
                        M_Z[[i, c]] = M_Z[[c, i]]
                        P[:, [i, c]] = P[:, [c, i]]
                        found = True
                        break
            if not found:
                # Degenerate: this dimension doesn't have a symplectic partner.
                # Skip; result may not be properly normalized but the comparison
                # still works.
                continue
        # P[i,i] = 1. Now zero out P[j, i] for j != i by row ops on M_X.
        for j in range(k):
            if j != i and P[j, i] == 1:
                M_X[j] = (M_X[j] + M_X[i]) % 2
                P[j] = (P[j] + P[i]) % 2
        # And zero out P[i, j] for j != i by column ops on M_Z.
        for j in range(k):
            if j != i and P[i, j] == 1:
                M_Z[j] = (M_Z[j] + M_Z[i]) % 2
                P[:, j] = (P[:, j] + P[:, i]) % 2
    return M_X, M_Z


def check_logical_permutation(L, stabilizers, edges_per_sheet, edge_to_idx, pi):
    """Verify that the induced action on logicals is a (2L) x (2L) permutation
    matrix preserving the symplectic pairing.

    Strategy: extract logical bases for each sheet, normalize to symplectic
    canonical form, then for each logical of sheet T compute its image under
    pi and re-express in the basis of R(T). The transformation matrices
    sigma_X and sigma_Z should be permutation matrices."""
    sigmas = {}
    for T in SHEETS:
        RT = sheet_of_edge_under_rotation(T)
        # Extract canonical logical bases for both sheets
        M_X_T, M_Z_T = extract_per_sheet_logicals(stabilizers, T)
        M_X_RT, M_Z_RT = extract_per_sheet_logicals(stabilizers, RT)
        # Normalize to symplectic form
        M_X_T, M_Z_T = symplectic_normalize(M_X_T.copy(), M_Z_T.copy(),
                                             stabilizers[T]['HX'],
                                             stabilizers[T]['HZ'])
        M_X_RT, M_Z_RT = symplectic_normalize(M_X_RT.copy(), M_Z_RT.copy(),
                                                stabilizers[RT]['HX'],
                                                stabilizers[RT]['HZ'])

        k_T = len(M_X_T)
        k_RT = len(M_X_RT)
        assert k_T == k_RT == 2 * L, \
            f"per-sheet logical count: {k_T} vs {k_RT}, expected {2 * L}"

        # Lift to global edge basis
        def lift_local_to_global(row, sheet):
            g = np.zeros(len(edge_to_idx), dtype=np.int8)
            for li, v in enumerate(row):
                if v == 1:
                    e = edges_per_sheet[sheet][li]
                    g[edge_to_idx[e]] = 1
            return g

        # For each logical of sheet T, apply pi and project onto sheet R(T)
        # logical basis modulo R(T) stabilizers.
        HZ_RT_global = np.array([lift_local_to_global(r, RT) for r in stabilizers[RT]['HZ']],
                                dtype=np.int8)
        HX_RT_global = np.array([lift_local_to_global(r, RT) for r in stabilizers[RT]['HX']],
                                dtype=np.int8)
        M_X_RT_global = np.array([lift_local_to_global(r, RT) for r in M_X_RT], dtype=np.int8)
        M_Z_RT_global = np.array([lift_local_to_global(r, RT) for r in M_Z_RT], dtype=np.int8)

        sigma_X = np.zeros((k_T, k_T), dtype=np.int8)
        sigma_Z = np.zeros((k_T, k_T), dtype=np.int8)

        for i in range(k_T):
            # X logical: lift, apply pi, decompose against M_X_RT modulo HX_RT
            x_T = lift_local_to_global(M_X_T[i], T)
            x_T_pi = np.zeros_like(x_T)
            x_T_pi[pi] = x_T
            # Solve: x_T_pi = sum_j (sigma_X[j, i]) M_X_RT_global[j] + (HX_RT_global rows)
            sol_X = decompose_modulo(x_T_pi, M_X_RT_global, HX_RT_global)
            assert sol_X is not None, \
                f"L={L}: X-logical {i} of sheet {T} does not lie in sheet {RT}'s X-logical+HX space"
            sigma_X[:, i] = sol_X

            # Z logical: same
            z_T = lift_local_to_global(M_Z_T[i], T)
            z_T_pi = np.zeros_like(z_T)
            z_T_pi[pi] = z_T
            sol_Z = decompose_modulo(z_T_pi, M_Z_RT_global, HZ_RT_global)
            assert sol_Z is not None, \
                f"L={L}: Z-logical {i} of sheet {T} does not lie in sheet {RT}'s Z-logical+HZ space"
            sigma_Z[:, i] = sol_Z

        sigmas[T] = (sigma_X, sigma_Z)

        # Check sigma_X = sigma_Z (they must agree since R is the same map)
        if not np.array_equal(sigma_X, sigma_Z):
            print(f"  WARNING: sigma_X != sigma_Z for sheet {T} -- this may be a sign of basis ambiguity")

        # Check each is a permutation matrix:
        # exactly one 1 per row and one 1 per column.
        for sig_name, sig in [('sigma_X', sigma_X), ('sigma_Z', sigma_Z)]:
            row_sums = sig.sum(axis=1)
            col_sums = sig.sum(axis=0)
            assert (row_sums == 1).all(), \
                f"L={L} sheet {T}: {sig_name} row sums: {row_sums.tolist()}"
            assert (col_sums == 1).all(), \
                f"L={L} sheet {T}: {sig_name} col sums: {col_sums.tolist()}"

        # Check symplectic pairing preservation: sigma_X.T @ sigma_Z = I
        prod = (sigma_X.T @ sigma_Z) % 2
        I = np.eye(k_T, dtype=np.int8)
        assert np.array_equal(prod, I), \
            f"L={L} sheet {T}: sigma_X.T @ sigma_Z != I; off-diagonals = {(prod ^ I).sum()}"

    return sigmas


def decompose_modulo(v, basis_rows, stab_rows):
    """Decompose v as sum of basis_rows[j] (with coefficients c[j] in GF(2)),
    modulo stab_rows. Returns the coefficient vector c, or None if not solvable."""
    # Augmented system: find c, s such that v = sum c_j basis_rows[j] + sum s_i stab_rows[i]
    # In matrix form: [basis_rows.T | stab_rows.T] [c; s] = v
    if len(basis_rows) == 0 and len(stab_rows) == 0:
        return None if v.any() else np.zeros(0, dtype=np.int8)
    M = np.vstack([basis_rows, stab_rows]).T.astype(np.int8)  # n x (k + r)
    # Solve M @ x = v over GF(2)
    aug = np.hstack([M, v.reshape(-1, 1)]).astype(np.int8)
    rref, pivots, rank = gf2_rref(aug)
    # Last column should not be a pivot for consistency
    if (len(M[0]) in pivots) if isinstance(pivots, list) else False:
        return None
    # Check no zero row with nonzero RHS
    for i in range(rank, rref.shape[0]):
        if rref[i, -1] != 0:
            return None
    # Back-substitute. We want only the first len(basis_rows) coefficients.
    n_cols = M.shape[1]
    x = np.zeros(n_cols, dtype=np.int8)
    for i, pc in enumerate(pivots):
        if pc < n_cols:
            x[pc] = rref[i, -1]
    return x[:len(basis_rows)].astype(np.int8)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def verify_at_L(L):
    print(f"\n{'=' * 60}")
    print(f"L = {L}")
    print(f"{'=' * 60}")

    print(f"  Building FCC sheet code at L={L}...")
    stabilizers, vertices, vidx, edge_list, edge_to_idx = build_sheet_code(L)
    _, _, edges_per_sheet, _, _, _ = build_fcc_lattice(L)

    n_edges = len(edge_list)
    n_per_sheet = stabilizers['xy']['n_edges']
    print(f"    Vertices: {len(vertices)}, Edges: {n_edges} ({n_per_sheet} per sheet)")
    for T in SHEETS:
        n_Z = stabilizers[T]['HZ'].shape[0]
        n_X = stabilizers[T]['HX'].shape[0]
        rank_Z = gf2_rank(stabilizers[T]['HZ'])
        rank_X = gf2_rank(stabilizers[T]['HX'])
        k = n_per_sheet - rank_Z - rank_X
        print(f"    Sheet {T}: {n_Z} Z-stabs ({rank_Z} indep), {n_X} X-stabs ({rank_X} indep), k = {k}")

    pi = rotation_permutation(L, vertices, vidx, edge_list, edge_to_idx)

    print("  Check (a): R is an edge permutation that maps sheets cyclically...")
    check_edge_permutation(L, edges_per_sheet, edge_to_idx, pi)
    print("    PASS")

    print("  Check (b): R maps every stabilizer to a stabilizer of the next sheet...")
    check_stabilizer_preservation(L, stabilizers, edges_per_sheet, edge_to_idx, pi)
    print("    PASS")

    print("  Check (c): induced logical action is a (2L)x(2L) symplectic permutation...")
    sigmas = check_logical_permutation(L, stabilizers, edges_per_sheet, edge_to_idx, pi)
    print(f"    PASS at L={L}: each sigma is a {2*L}x{2*L} permutation matrix with sigma_X.T sigma_Z = I")
    return True


def main():
    print("Verification of Computational Result 1 (CSS isomorphism of R):")
    print("  R: (x,y,z) -> (y,z,x) is a CSS isomorphism of the FCC sheet code.")
    print("  The induced action on logicals is a (2L)x(2L) symplectic permutation.")
    Ls = [4, 6]  # L=8 is computationally heavy; included via the slow path below
    if '--with-L8' in sys.argv:
        Ls.append(8)

    for L in Ls:
        verify_at_L(L)

    print(f"\n{'=' * 60}")
    print(f"All checks PASS at L in {Ls}.")
    print("Pass --with-L8 to also verify at L=8 (slow; symplectic_normalize is O(k^3)).")
    print(f"{'=' * 60}")


if __name__ == '__main__':
    main()
