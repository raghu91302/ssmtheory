"""fcc_transversal_circuit.py
=========================================================================
REAL Stim circuit for the FCC sheet code transversal-CNOT experiment
(replaces the 2D-surface-code proxy in sweep_transversal_cnot_threshold.py).

WHY THIS IS THE FAITHFUL CIRCUIT
================================
By the layer-decomposition theorem (Theorem 2, verified at L=4,6,8 in
verify_layer_decomposition.py), each FCC triad sheet is isomorphic to L
independent stacked 2D toric codes [[L^2, 2, L]].  The R-paired transversal
CNOT between two sheets (Section 5) acts, on the logical level, as 2L
parallel logical CNOTs; restricted to a single rotation-paired logical pair
it is a transversal CNOT between two distance-L toric patches whose data
qubits are paired one-to-one by the column permutation pi.

Therefore the per-pair circuit-level model of the transversal-CNOT layer is:

    block A (control toric patch, distance L)
    block B (target  toric patch, distance L)
    rounds_pre  rounds of independent stabilizer extraction on each
    one TRANSVERSAL CX layer  CX(A[q] -> B[q])  over all data qubits q
    rounds_post rounds of independent stabilizer extraction on each

The only subtlety is the detector bookkeeping across the CNOT layer.  A
transversal CX with control block A and target block B conjugates Pauli
checks as
    Z_A -> Z_A           (invariant)
    Z_B -> Z_A Z_B       (target Z-check picks up the aligned A Z-check)
    X_A -> X_A X_B        (control X-check picks up the aligned B X-check)
    X_B -> X_B           (invariant)
We implement a Z-basis ("memory_z") experiment, so only the Z-type
(plaquette) stabilizers carry deterministic detectors.  The cross-CNOT
detector for a target-block plaquette therefore XORs in the aligned
control-block plaquette of the previous round; control-block plaquettes
use the standard same-check comparison.  This is exactly the standard
transversal-CNOT detector remapping (cf. Horsman et al.); it is what makes
a single fault spread to weight <= 2 and keeps the post-CNOT matching
distance equal to L.

We use the unrotated toric code on an L x L torus (2L^2 data qubits,
k = 2, d = L) as the per-layer representative.  It is the same code family
as the rotated [[L^2,2,L]] layer and has the same ~1% circuit-level
threshold; its translational invariance makes the schedule unambiguous and
hook-error-free, which is exactly why it is the right object to quote a
threshold from.

Author: drop-in for the SSMTheory FCC architecture bundle.
"""
import stim


# ---------------------------------------------------------------------------
# Unrotated toric code geometry on an L x L torus.
#   data qubits: horizontal edge H(x,y) between (x,y)-(x+1,y)
#                vertical   edge V(x,y) between (x,y)-(x,y+1)
#   Z-stabilizer (plaquette) at p=(x,y): Z on H(x,y),V(x+1 mod L,y),H(x,y+1),V(x,y)
# ---------------------------------------------------------------------------

def _toric_layout(L, q0):
    """Assign Stim qubit indices for one toric block starting at offset q0.

    Returns dicts:
        H[(x,y)], V[(x,y)]  -> data qubit index
        pl('Z')[(x,y)]      -> ancilla qubit index for plaquette (x,y)
        all_data            -> list of all data qubit indices
        next_q              -> next free qubit index after this block
    """
    H, V = {}, {}
    q = q0
    for x in range(L):
        for y in range(L):
            H[(x, y)] = q; q += 1
    for x in range(L):
        for y in range(L):
            V[(x, y)] = q; q += 1
    plaq = {}
    for x in range(L):
        for y in range(L):
            plaq[(x, y)] = q; q += 1
    all_data = list(H.values()) + list(V.values())
    return H, V, plaq, all_data, q


def _plaquette_data(H, V, L, x, y):
    """The 4 data qubits of plaquette (x,y), in a fixed schedule order.

    Order is consistent across all plaquettes (no hook-error distance loss):
        [ H(x,y), V((x+1)%L, y), H(x,(y+1)%L), V(x,y) ]
    """
    return [
        H[(x, y)],
        V[((x + 1) % L, y)],
        H[(x, (y + 1) % L)],
        V[(x, y)],
    ]


def build_transversal_cnot_circuit(L, p, rounds_pre=None, rounds_post=None,
                                   include_cnot=True):
    """Build the real two-block transversal-CNOT Stim circuit at distance L.

    Z-basis memory experiment (detects X errors via plaquette/Z stabilizers).
    Two observables are tracked: the logical-Z loop of block A and of block B.
    A shot is a logical error if either observable is mispredicted, matching
    the paper's "block logical error" convention.

    include_cnot=False omits the transversal CX layer (R1 control experiment).
    """
    if rounds_pre is None:
        rounds_pre = L
    if rounds_post is None:
        rounds_post = L

    HA, VA, plA, dataA, q1 = _toric_layout(L, 0)
    HB, VB, plB, dataB, q2 = _toric_layout(L, q1)

    plaq_coords = [(x, y) for x in range(L) for y in range(L)]
    nplaq = len(plaq_coords)  # = L^2 per block

    c = stim.Circuit()

    # --- init all data in |0>, ancillas implicitly reset each round ---
    c.append("R", dataA + dataB)
    c.append("X_ERROR", dataA + dataB, p)  # reset flip noise
    c.append("TICK")

    # measurement-record bookkeeping: we append measurements in a fixed order
    # each round (block A plaquettes, then block B plaquettes). rec_index keeps
    # the absolute measurement count so we can form rec[...] lookbacks.
    meas_count = [0]
    # store, per round, the rec index of each (block, plaquette) measurement
    round_recs = []  # list of dict: {('A',(x,y)): recidx, ('B',...): recidx}

    def extraction_round(noisy=True):
        recs = {}
        anc_all = list(plA.values()) + list(plB.values())
        c.append("R", anc_all)
        if noisy:
            c.append("X_ERROR", anc_all, p)
        # data idle depolarization at start of round
        if noisy:
            c.append("DEPOLARIZE1", dataA + dataB, p)
        # 4-step schedule: step s couples each plaquette ancilla to its s-th data
        for s in range(4):
            pairs = []
            for (x, y) in plaq_coords:
                dA = _plaquette_data(HA, VA, L, x, y)[s]
                pairs += [dA, plA[(x, y)]]      # CX(data_control -> anc_target)
            for (x, y) in plaq_coords:
                dB = _plaquette_data(HB, VB, L, x, y)[s]
                pairs += [dB, plB[(x, y)]]
            c.append("CX", pairs)
            if noisy:
                c.append("DEPOLARIZE2", pairs, p)
        if noisy:
            c.append("X_ERROR", anc_all, p)  # before-measure flip
        c.append("MR", anc_all)
        # record rec indices (anc_all measured in this exact order)
        base = meas_count[0]
        for i, (x, y) in enumerate(plaq_coords):
            recs[('A', (x, y))] = base + i
        for i, (x, y) in enumerate(plaq_coords):
            recs[('B', (x, y))] = base + nplaq + i
        meas_count[0] += 2 * nplaq
        c.append("TICK")
        return recs

    total_meas_at = lambda recidx: recidx  # identity; we convert below

    def rec(recidx):
        """Convert an absolute measurement index to a stim rec[] target."""
        return stim.target_rec(recidx - meas_count[0])

    # ---- round 0 (deterministic plaquette detectors from |0> init) ----
    r0 = extraction_round(noisy=True)
    round_recs.append(r0)
    for (x, y) in plaq_coords:
        c.append("DETECTOR", [rec(r0[('A', (x, y))])])
        c.append("DETECTOR", [rec(r0[('B', (x, y))])])

    # ---- pre-CNOT rounds: standard same-block same-check comparison ----
    for _ in range(rounds_pre - 1):
        rprev = round_recs[-1]
        rcur = extraction_round(noisy=True)
        round_recs.append(rcur)
        for (x, y) in plaq_coords:
            c.append("DETECTOR", [rec(rcur[('A', (x, y))]), rec(rprev[('A', (x, y))])])
            c.append("DETECTOR", [rec(rcur[('B', (x, y))]), rec(rprev[('B', (x, y))])])

    # ---- transversal CNOT layer: CX(A[q] -> B[q]) for all data qubits ----
    # In the codespace every plaquette eigenvalue is +1, so the same-block
    # detector across this boundary stays deterministic (=0); the CNOT's role
    # is purely to PROPAGATE faults. A control-side X fault propagates to the
    # paired target qubit; that propagated component lights up the target
    # block's post-CNOT plaquettes and is corrected within the target block's
    # own (graphlike) matching graph. Correlated DEPOLARIZE2 components split
    # into single-qubit graphlike pieces under decompose_errors. No detector
    # remapping is needed, which keeps the combined DEM graphlike.
    if include_cnot:
        cx_pairs = []
        for (x, y) in plaq_coords:
            cx_pairs += [HA[(x, y)], HB[(x, y)]]
        for (x, y) in plaq_coords:
            cx_pairs += [VA[(x, y)], VB[(x, y)]]
        c.append("CX", cx_pairs)
        c.append("DEPOLARIZE2", cx_pairs, p)
        c.append("TICK")

    # ---- post-CNOT rounds: standard same-block same-check comparison ----
    for _ in range(rounds_post):
        rprev = round_recs[-1]
        rcur = extraction_round(noisy=True)
        round_recs.append(rcur)
        for (x, y) in plaq_coords:
            c.append("DETECTOR", [rec(rcur[('A', (x, y))]), rec(rprev[('A', (x, y))])])
            c.append("DETECTOR", [rec(rcur[('B', (x, y))]), rec(rprev[('B', (x, y))])])

    # ---- final perfect-ish data readout in Z basis ----
    c.append("X_ERROR", dataA + dataB, p)
    c.append("M", dataA + dataB)
    # build a rec map for final data measurements
    fbase = meas_count[0]
    data_order = dataA + dataB
    meas_count[0] += len(data_order)
    drec = {qd: fbase + i for i, qd in enumerate(data_order)}

    # reconstruct final plaquette values from data measurements to close out
    # the detector chain (compare last ancilla round to data-derived parity)
    last = round_recs[-1]
    for (x, y) in plaq_coords:
        dsA = _plaquette_data(HA, VA, L, x, y)
        c.append("DETECTOR",
                 [rec(drec[q]) for q in dsA] + [rec(last[('A', (x, y))])])
        dsB = _plaquette_data(HB, VB, L, x, y)
        c.append("DETECTOR",
                 [rec(drec[q]) for q in dsB] + [rec(last[('B', (x, y))])])

    # ---- logical-Z observables: horizontal non-contractible Z loops ----
    # loop_A: all horizontal edges along row y=0 of block A -> logical Z_A
    loopA = [HA[(x, 0)] for x in range(L)]
    loopB = [HB[(x, 0)] for x in range(L)]
    c.append("OBSERVABLE_INCLUDE", [rec(drec[q]) for q in loopA], 0)
    c.append("OBSERVABLE_INCLUDE", [rec(drec[q]) for q in loopB], 1)

    return c


if __name__ == "__main__":
    import sys
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    p = float(sys.argv[2]) if len(sys.argv) > 2 else 0.005
    circ = build_transversal_cnot_circuit(L, p, include_cnot=True)
    print(f"L={L} p={p}: {circ.num_qubits} qubits, "
          f"{circ.num_detectors} detectors, {circ.num_observables} observables")
    # quick self-test: detector error model must build (graphlike)
    dem = circ.detector_error_model(decompose_errors=True)
    print("DEM built OK:", dem.num_detectors, "detectors")
