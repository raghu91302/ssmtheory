import numpy as np, json, time, sys
from fcc_feedforward_real import run
Ls=[int(x) for x in sys.argv[1].split(',')]
shots_map={4:5000,6:3500,8:1200}
ps=[0.002,0.003,0.004,0.005,0.006,0.008]
t0=time.time()
out={'p':ps,'curves':{}}
for L in Ls:
    sh=shots_map[L]; row=[]
    for p in ps:
        r=run(L,p,sh,seed=2000+L)
        row.append(dict(p=p,**{k:round(v,5) for k,v in r.items()},shots=sh))
        print(f"cnot L={L} p={p}: naive_tgt={r['naive_tgt']:.3f} ff_tgt={r['ff_tgt']:.3f} ctrl={r['naive_ctrl']:.3f}",flush=True)
    out['curves'][str(L)]=row
json.dump(out,open(f'data_cnot_real_{"_".join(map(str,Ls))}.json','w'),indent=1)
print(f"done {time.time()-t0:.0f}s")
