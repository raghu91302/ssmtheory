"""make_fig_threshold.py
=========================================================================
Generate Figure 2 (threshold simulation) of the architecture paper from the
JSON output of the threshold-sweep scripts.

Reads JSON files from the sweep_*_threshold.py scripts and produces a
log-log plot of logical error rate vs physical error rate for several L
values, with optional "with-CNOT vs without-CNOT" overlay for the
transversal CNOT experiment.

Usage:
    python3 make_fig_threshold.py \
        --with-cnot transversal_cnot_with_cnot_shots.json \
        --without-cnot transversal_cnot_without_cnot_shots.json \
        --out fig_threshold.pdf

If only one file is provided, plots a single set of curves.
"""
import argparse
import json
import sys
from collections import defaultdict

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


COLORS = {4: '#1f77b4', 6: '#d62728', 8: '#2ca02c'}
MARKERS = {4: 'o', 6: 's', 8: '^'}


def load_shots(path):
    with open(path) as f:
        data = json.load(f)
    by_L = defaultdict(list)
    for r in data['results']:
        by_L[r['L']].append((r['p'], r['logical_error_rate'], r['shots']))
    for L in by_L:
        by_L[L].sort()
    return data.get('circuit', 'unknown'), by_L


def plot_one(ax, by_L, linestyle='-', label_suffix=''):
    for L in sorted(by_L.keys()):
        ps = np.array([row[0] for row in by_L[L]])
        lers = np.array([row[1] for row in by_L[L]])
        shots = np.array([row[2] for row in by_L[L]])
        # 1-sigma binomial error bars
        n_err = lers * shots
        err = np.sqrt(np.maximum(n_err, 1) * (1 - lers) / shots)
        ax.errorbar(ps, lers, yerr=err,
                    color=COLORS.get(L, 'k'),
                    marker=MARKERS.get(L, 'x'),
                    markersize=6,
                    linestyle=linestyle,
                    linewidth=1.5,
                    label=f'$L={L}${label_suffix}',
                    capsize=3)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--with-cnot', type=str, default=None,
                        help='JSON file from transversal-CNOT sweep (with CNOT)')
    parser.add_argument('--without-cnot', type=str, default=None,
                        help='JSON file from transversal-CNOT sweep (without CNOT, control)')
    parser.add_argument('--memory', type=str, default=None,
                        help='JSON file from memory threshold sweep')
    parser.add_argument('--out', type=str, default='fig_threshold.pdf',
                        help='Output PDF path')
    parser.add_argument('--title', type=str, default=None)
    args = parser.parse_args()

    fig, ax = plt.subplots(figsize=(6.5, 4.5))

    plotted_anything = False
    if args.memory:
        circuit, by_L = load_shots(args.memory)
        plot_one(ax, by_L, linestyle='-', label_suffix=' (memory)')
        plotted_anything = True

    if args.with_cnot:
        circuit, by_L = load_shots(args.with_cnot)
        plot_one(ax, by_L, linestyle='-', label_suffix=' (with CNOT)')
        plotted_anything = True

    if args.without_cnot:
        circuit, by_L = load_shots(args.without_cnot)
        plot_one(ax, by_L, linestyle='--', label_suffix=' (no CNOT)')
        plotted_anything = True

    if not plotted_anything:
        print("ERROR: no input files provided. Pass at least one of --memory, --with-cnot, --without-cnot.")
        sys.exit(1)

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('Physical error rate $p$')
    ax.set_ylabel('Logical error rate')
    if args.title:
        ax.set_title(args.title)
    ax.grid(True, which='both', alpha=0.3)
    ax.legend(loc='best', fontsize=9)
    fig.tight_layout()
    fig.savefig(args.out, bbox_inches='tight')
    # also save PNG companion
    png_out = args.out.rsplit('.', 1)[0] + '.png'
    fig.savefig(png_out, bbox_inches='tight', dpi=200)
    print(f"Wrote {args.out} and {png_out}")


if __name__ == '__main__':
    main()
