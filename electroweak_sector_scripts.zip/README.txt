Verification scripts for:
  "The Electroweak Sector from the Verification Front: Parity Violation,
   the Integer Charge Unit, the su(2)+u(1) Algebra, and the Breaking
   Sector of the Vacuum Code"  (R. Kulkarni, 2026)

Contents:
  fcc_code.py                     rebuilds and verifies the [[192,130,3]] code
  verify_electroweak_sector.py    one pipeline, seven parts:
                                  (A) front asymmetry, controls, robustness,
                                      winding, skin effect, transmission
                                      chirality, two exclusions
                                  (B) spectral flow and its quantization
                                  (C) su(2)+u(1) closure, boson charges,
                                      doublet quantum numbers, conjugation
                                  (D) monopole cells at the tetrahedral voids
                                  (E) the gate: Y = +-1/2 constraint and the
                                      frozen counts
                                  (F) the lepton doublet with the quark control
                                  (G) the link-phase parity theorem
                                  (35 checks)
  PL_protocol.md                  the pre-registration with all dated
                                  amendments (seven registered constructions)
  PL_extraction.md                the execution record with every verdict

Requirements: Python 3 with numpy.
Run:          python3 verify_electroweak_sector.py
Expected:     35x PASS, then ALL PASS. Runtime: ~4 minutes.
