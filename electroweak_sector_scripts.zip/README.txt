Verification scripts for:
  "The Electroweak Sector from the Verification Front: Parity Violation,
   the Integer Charge Unit, and the su(2)+u(1) Algebra of the Vacuum Code"
  (R. Kulkarni, 2026)

Contents:
  fcc_code.py                     rebuilds and verifies the [[192,130,3]] code
  verify_electroweak_sector.py    one pipeline, three parts: (A) the front
                                  asymmetry, controls, robustness, winding,
                                  skin effect, transmission chirality, and
                                  both exclusions; (B) the spectral flow and
                                  its quantization; (C) the su(2)+u(1)
                                  closure, boson charges, doublet quantum
                                  numbers, and conjugation (23 checks)
  PL_protocol.md                  the pre-registration with all dated
                                  amendments (four hypotheses)
  PL_extraction.md                the execution record with every verdict

Requirements: Python 3 with numpy.
Run:          python3 verify_electroweak_sector.py
Expected:     23x PASS, then ALL PASS. Runtime: ~3 minutes.
