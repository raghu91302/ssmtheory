Verification scripts for:
  "The Electroweak Sector from the Verification Front: Parity Violation,
   the Integer Charge Unit, and the su(2)+u(1)_Y Algebra of the Vacuum Code"  (R. Kulkarni, 2026)

Contents:
  fcc_code.py                     rebuilds and verifies the [[192,130,3]] code
  verify_electroweak_sector.py    one pipeline, seven parts:
                                  (A) the edge-hop rule and its metric
                                      wall; front asymmetry for both void
                                      orientations, controls, closed form,
                                      frontier placement, winding, skin
                                      effect, transmission chirality,
                                      two exclusions
                                  (B) spectral flow on the alternating
                                      worldline and its quantization
                                  (C) su(2)+u(1)_Y closure and its center, boson charges,
                                      doublet quantum numbers, conjugation
                                  (D) monopole cells at the tetrahedral voids
                                  (E) constraints on the breaking sector:
                                      Y = +-1/2 and the frozen counts
                                  (F) the lepton doublet with the quark control
                                  (G) the link-phase parity theorem
                                  (43 checks)
  PL_protocol.md                  the pre-registration with all dated
                                  amendments; Amendments 8 and 9 record
                                  the geometry correction and the
                                  adoption of the published hop rule
  PL_extraction.md                the execution record with every verdict,
                                  and the corrected values

Hops: a trapped node moves only across the edges of its void, following
R. Kulkarni, Symmetry 18, 1571 (2026). Geometry: heights along the
stacking axis are measured from the defect by minimum-image
displacements on the torus; the results agree on the L = 4 and L = 8
tori.

Requirements: Python 3 with numpy.
Run:          python3 verify_electroweak_sector.py
Expected:     43x PASS, then ALL PASS. Runtime: ~6 minutes.
