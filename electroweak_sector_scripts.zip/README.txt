Verification scripts for:
  "The Electroweak Sector from the Verification Front: Parity Violation,
   the Integer Charge Unit, the su(2)+u(1) Algebra, and the Breaking
   Sector of the Vacuum Code"  (R. Kulkarni, 2026)

Contents:
  fcc_code.py                     rebuilds and verifies the [[192,130,3]] code
  verify_electroweak_sector.py    one pipeline, seven parts:
                                  (A) front asymmetry for both void
                                      orientations, controls, robustness,
                                      frontier placement, winding, skin
                                      effect, transmission chirality,
                                      two exclusions
                                  (B) spectral flow and its quantization
                                  (C) su(2)+u(1) closure, boson charges,
                                      doublet quantum numbers, conjugation
                                  (D) monopole cells at the tetrahedral voids
                                  (E) constraints on the breaking sector:
                                      Y = +-1/2 and the frozen counts
                                  (F) the lepton doublet with the quark control
                                  (G) the link-phase parity theorem
                                  (39 checks)
  PL_protocol.md                  the pre-registration with all dated
                                  amendments; Amendment 8 records the
                                  correction of the front geometry
  PL_extraction.md                the execution record with every verdict,
                                  and the corrected values

Geometry: heights along the stacking axis are measured from the defect
by minimum-image displacements on the torus; the results agree on the
L = 4 and L = 8 tori.

Requirements: Python 3 with numpy.
Run:          python3 verify_electroweak_sector.py
Expected:     39x PASS, then ALL PASS. Runtime: ~6 minutes.
