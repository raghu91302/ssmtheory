#!/usr/bin/env python3
"""FCC CSS code rebuild + verification (PL protocol, Prerequisite 2).
Built from the published spec (arXiv:2603.20294): qubits on edges,
Z-checks on vertices (12 incident edges), X-checks on octahedral
voids (12 edges among the 6 surrounding vertices)."""
import numpy as np
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
    (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
def build(L):
    nodes,nidx=[],{}
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z)%2==0:
                    nidx[(x,y,z)]=len(nodes); nodes.append((x,y,z))
    edges=[]
    for i,(x,y,z) in enumerate(nodes):
        for dx,dy,dz in NN:
            nb=((x+dx)%L,(y+dy)%L,(z+dz)%L)
            if nb in nidx and i<nidx[nb]: edges.append((i,nidx[nb]))
    octs=[]
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z)%2==1:
                    nbs=[nidx[((x+d[0])%L,(y+d[1])%L,(z+d[2])%L)]
                         for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),
                                   (0,0,1),(0,0,-1)]
                         if ((x+d[0])%L,(y+d[1])%L,(z+d[2])%L) in nidx]
                    if len(nbs)==6: octs.append(nbs)
    ne=len(edges)
    HZ=np.zeros((len(nodes),ne),dtype=np.int8)
    for ei,(i,j) in enumerate(edges): HZ[i,ei]=1; HZ[j,ei]=1
    HX=np.zeros((len(octs),ne),dtype=np.int8)
    for oi,nbs in enumerate(octs):
        s=set(nbs)
        for ei,(i,j) in enumerate(edges):
            if i in s and j in s: HX[oi,ei]=1
    return HZ,HX,edges,nodes,octs
def gf2rank(M):
    M=M.copy().astype(np.int8); r=0
    for c in range(M.shape[1]):
        piv=next((row for row in range(r,M.shape[0]) if M[row,c]),None)
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for row in range(M.shape[0]):
            if row!=r and M[row,c]: M[row]=(M[row]+M[r])%2
        r+=1
    return r
if __name__=="__main__":
    ok=True
    def check(n,c):
        global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)
    HZ,HX,edges,nodes,octs=build(4)
    check("lattice: 32 nodes, 192 edges, 32 octahedral voids",
          len(nodes)==32 and len(edges)==192 and len(octs)==32)
    check("CSS validity: HX.HZ^T = 0 over GF(2)",
          int(((HX@HZ.T)%2).sum())==0)
    check("all stabilizer weights = 12",
          set(HZ.sum(1))=={12} and set(HX.sum(1))=={12})
    rZ,rX=gf2rank(HZ),gf2rank(HX)
    check("ranks 31+31; k = 130 = 2L^3+2", rZ==31 and rX==31
          and 192-rZ-rX==130)
    check("distance lower bound: no weight-1 in ker(HZ) or ker(HX)",
          all(HZ[:,i].any() for i in range(192)) and
          all(HX[:,i].any() for i in range(192)))
    w2=sum(1 for i in range(192) for j in range(i+1,192)
           if not ((HZ[:,i]+HZ[:,j])%2).any())
    w2x=sum(1 for i in range(192) for j in range(i+1,192)
            if not ((HX[:,i]+HX[:,j])%2).any())
    check("no weight-2 in ker(HZ) or ker(HX): d >= 3", w2==0 and w2x==0)
    print("\nPREREQUISITE 2:", "COMPLETE - [[192,130,3]] verified"
          if ok else "FAILED")
