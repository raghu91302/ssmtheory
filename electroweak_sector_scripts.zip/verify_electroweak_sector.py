#!/usr/bin/env python3
"""Verification script for 'The Electroweak Sector from the Verification
Front' (R. Kulkarni, 2026; with the breaking sector).
(A) front asymmetry, controls, robustness, winding, skin effect,
transmission chirality, two exclusions; (B) spectral flow and its
quantization; (C) su(2)+u(1) closure, boson charges, doublet quantum
numbers, conjugation; (D) monopole cells at the tetrahedral voids;
(E) the gate: the Y=+-1/2 constraint and the frozen counts; (F) the
lepton doublet with the quark control; (G) the link-phase parity
theorem. Requires numpy. Run: python3 verify_electroweak_sector.py
Runtime ~4 minutes."""
import numpy as np, itertools
from fcc_code import build, NN
ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)

print("=== A. THE FRONT ===")
HZ,HX,edges,nodes,octs=build(4)
check("code: 192 edges, CSS valid, weight-12 checks",
      len(edges)==192 and int(((HX@HZ.T)%2).sum())==0 and set(HZ.sum(1))=={12} and set(HX.sum(1))=={12})
adj={i:set() for i in range(len(nodes))}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tets=[]
for i in range(len(nodes)):
    nb=sorted(x for x in adj[i] if x>i)
    for p,q,r in itertools.combinations(nb,3):
        if q in adj[p] and r in adj[p] and r in adj[q]: tets.append(frozenset((i,p,q,r)))
lay=lambda v: sum(nodes[v]); octsets=[frozenset(o) for o in octs]
tf=lambda t:[frozenset(f) for f in itertools.combinations(sorted(t),3)]
T0=[t for t in tets if sorted(lay(v) for v in t)==[4,4,4,6]][0]
check("hop geometry: tetrahedral voids share faces only with octahedra",
      not any(len(set(t)&set(T0))==3 for t in tets if t!=T0))
def pol(committed,c=0.5,octa=False,Td=None):
    Td=Td or T0; m0=np.mean([lay(v) for v in Td]); res={}
    for O in octsets:
        if not any(f<=O for f in tf(Td)): continue
        for T1 in tets:
            if T1==Td or not any(f<=O for f in tf(T1)): continue
            m1=np.mean([lay(v) for v in T1])
            d='UP' if m1>m0+1e-9 else ('DOWN' if m1<m0-1e-9 else 'LAT')
            nc=sum(1 for v in Td if v not in T1 and committed(v))+sum(1 for v in T1 if v not in Td and committed(v))
            if octa and sum(committed(v) for v in O)>3: nc+=1
            res.setdefault(d,[]).append(nc)
    A=lambda d: np.mean([c**n for n in res.get(d,[0])])**0.5
    au,ad=A('UP'),A('DOWN'); return (au-ad)/(au+ad),au,ad
P,a,b=pol(lambda v: lay(v)<=4)
check("physical: A_up=0.500, A_down=0.268, P=+0.302", abs(a-0.5)<1e-3 and abs(b-0.2681)<1e-3 and abs(P-0.302)<2e-3)
check("C1 static: P=0 exactly", abs(pol(lambda v: True)[0])<1e-12)
check("C2 all pending: unit amplitudes, P=0", abs(pol(lambda v: False)[0])<1e-12)
check("C3 inverted frontier: sign reversed", pol(lambda v: lay(v)>=6)[0]<-0.29)
Tdn=[t for t in tets if sorted(lay(v) for v in t)==[4,6,6,6]][0]
sweep=[pol(lambda v: lay(v)<=4,c)[0] for c in (0.25,0.5,0.75)]+[pol(lambda v: lay(v)<=4,0.5,True)[0],pol(lambda v: lay(v)<=4,0.5,False,Tdn)[0]]
check("robustness: P>0 in all five declared variants", all(p>0.1 for p in sweep))
def wind(a,b):
    ks=np.linspace(0,2*np.pi,4001)[:-1]; Ek=a*np.exp(1j*ks)+b*np.exp(-1j*ks)
    return int(round(np.sum(np.angle(Ek[1:]/Ek[:-1]))/(2*np.pi)))
check("point-gap winding: physical +1, static 0, inverted -1", wind(a,b)==1 and wind(0.2035,0.2035)==0 and wind(b,a)==-1)
N=40; H=np.zeros((N,N))
for n in range(N-1): H[n+1,n]=a; H[n,n+1]=b
w,V=np.linalg.eig(H)
com=np.mean([np.sum(np.arange(N)*np.abs(V[:,i])**2)/np.sum(np.abs(V[:,i])**2) for i in range(N)])
check("skin effect: finite-chain modes pile at the frontier end", com>0.85*(N-1))
check("transmission chirality P_T(20)>0.99999", (a**20-b**20)/(a**20+b**20)>0.99999)
check("EXCLUSION C0: single-edge Pauli hop disturbs no environment check", HZ[:,0].sum()==2)
u=np.array([1,1,1])/np.sqrt(3); e1=np.array([1,-1,0])/np.sqrt(2); e2=np.cross(u,e1)
D=[np.array(d)/np.sqrt(2) for d in NN]
def sang(order):
    Pp=[D[k] for k in order]; tot=0.0
    for i in range(len(Pp)):
        A,B,C=u,Pp[i],Pp[(i+1)%len(Pp)]
        tot+=2*np.arctan2(np.dot(A,np.cross(B,C)),1+np.dot(A,B)+np.dot(B,C)+np.dot(C,A))
    return tot
az=list(np.argsort([np.arctan2(np.dot(d,e2),np.dot(d,e1)) for d in D])); ph=lambda o:(-sang(o)/2)%(2*np.pi)
pert=az[:1]+[az[2],az[1]]+az[3:]
check("EXCLUSION H2: canonical phase pi, path-sensitive, class-blind",
      abs(ph(az)-np.pi)<1e-9 and abs(ph(pert)-np.pi)>0.1 and abs((ph(az)-ph(az[::-1]))%(2*np.pi))<1e-9)
print("=== B. THE UNIT ===")
def flow(a,b,N=60,steps=721,Eref=0+0j):
    args=[]
    for phi in np.linspace(0,2*np.pi,steps):
        Hh=np.zeros((N,N),dtype=complex)
        for n in range(N): Hh[(n+1)%N,n]=a*np.exp(1j*phi/N); Hh[n,(n+1)%N]=b*np.exp(-1j*phi/N)
        s,_=np.linalg.slogdet(Hh-Eref*np.eye(N)); args.append(np.angle(s))
    uu=np.unwrap(np.array(args)); return (uu[-1]-uu[0])/(2*np.pi)
check("spectral flow: one unit per flux quantum (physical +1)", abs(flow(a,b)-1)<1e-6)
check("flow controls: static 0, inverted -1", abs(flow(0.2035,0.2035,Eref=0.1j))<1e-6 and abs(flow(b,a)+1)<1e-6)
check("flow robust in size and reference; integer identically",
      all(abs(flow(a,b,N=n)-1)<1e-6 for n in (30,90)) and all(abs(flow(a,b,Eref=E)-1)<1e-6 for E in (0.05+0.05j,-0.1j)))
print("=== C. THE ALGEBRA ===")
M=9; qs=list(range(-4,5)); Sh=np.eye(M,k=-1); R=np.fliplr(np.eye(M))
sp=np.array([[0,1],[0,0]]); sm=sp.T; sz=np.diag([1.,-1.]); sx=np.array([[0,1],[1,0]]); I2=np.eye(2)
K=lambda A,B,C: np.kron(np.kron(A,B),C)
Vv=K(sz,I2,np.eye(M)); T3=K(I2,sz/2,np.eye(M)); Z=K(I2,sz,np.eye(M))
Ql=K(I2,I2,np.diag(np.array(qs,float))); Qel=-(1/3)*Vv+Ql; Y=Qel-T3
Pin=K(I2,I2,np.diag([0,1,1,1,1,1,1,1,0.])); eq=lambda A,B: np.allclose(Pin@A@Pin,Pin@B@Pin,atol=1e-12)
comm=lambda A,B: A@B-B@A
def ops(a,b): return a*K(I2,sp,Sh), b*K(I2,sm,Sh.T)
def closure(a,b):
    Wp,Wm=ops(a,b); r=eq(comm(Wp,Wm),a*b*Z) and eq(comm(Z,Wp),2*Wp) and eq(comm(Z,Wm),-2*Wm)
    basis=[Wp,Wm,Z,Ql]; B=np.array([(Pin@X@Pin).ravel() for X in basis]).T
    for X in basis:
        for Yy in basis:
            c=(Pin@comm(X,Yy)@Pin).ravel(); coef=np.linalg.lstsq(B,c,rcond=None)[0]; r&= np.linalg.norm(B@coef-c)<1e-10
    Cm=np.array([(Pin@comm(X,Yy)@Pin).ravel() for X in basis for Yy in basis])
    return r and np.linalg.matrix_rank(Cm,tol=1e-10)==3
check("closure: su(2)+u(1), physical amplitudes", closure(a,b))
check("control: closure identical with static amplitudes", closure(0.2035,0.2035))
Wp,Wm=ops(a,b)
check("non-unitary representation iff a != b", not np.allclose(Wm,Wp.conj().T) and np.allclose(ops(0.2,0.2)[1],ops(0.2,0.2)[0].conj().T))
check("boson charges: W+- carry +-1, Z neutral", eq(comm(Ql,Wp),Wp) and eq(comm(Ql,Wm),-Wm) and eq(comm(Ql,Z),0*Z))
def st(v,s,n):
    x=np.zeros(4*M); x[(v*2+s)*M+qs.index(n)]=1; return x
uq,dq=st(0,0,1),st(0,1,0)
check("doublet: Q=(+2/3,-1/3), T3=+-1/2, Y=+1/6 on both",
      abs(uq@Qel@uq-2/3)<1e-12 and abs(dq@Qel@dq+1/3)<1e-12 and abs(uq@Y@uq-1/6)<1e-12 and abs(dq@Y@dq-1/6)<1e-12)
check("Y su(2)-invariant", eq(comm(Y,Wp),0*Y) and eq(comm(Y,Wm),0*Y) and np.allclose(comm(Y,T3),0))
Cc=K(sx,sx,R); Ci=np.linalg.inv(Cc); cj=lambda A: Cc@A@Ci
check("C well-defined: Q, T3, Y odd; conjugate doublet Y=-1/6 on both",
      eq(cj(Qel),-Qel) and eq(cj(T3),-T3) and eq(cj(Y),-Y) and abs((Cc@uq)@Y@(Cc@uq)+1/6)<1e-12 and abs((Cc@dq)@Y@(Cc@dq)+1/6)<1e-12)
check("the front breaks C: C W+ C^-1 = (a/b) W-", eq(cj(Wp),(a/b)*Wm))

L=4
print("=== D. MONOPOLE CELLS ===")
nodeset=set(nodes); cubes=[(x,y,z) for x in range(L) for y in range(L) for z in range(L)]
corners=lambda c: [tuple(((c[i]+d[i])%L) for i in range(3)) for d in itertools.product((0,1),repeat=3)]
check("every elementary cube of the node-void grid has 4 node + 4 void corners",
      all(sum(1 for q in corners(c) if q in nodeset)==4 for c in cubes))
adj={i:set() for i in range(len(nodes))}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tets=[]
for i in range(len(nodes)):
    nb=sorted(x for x in adj[i] if x>i)
    for a,b,c in itertools.combinations(nb,3):
        if b in adj[a] and c in adj[a] and c in adj[b]: tets.append((i,a,b,c))
def unwrap(t):
    P=np.array([nodes[v] for v in t],float); ref=P[0]
    return np.array([ref+((p-ref+L/2)%L-L/2) for p in P])
tc=set(tuple(np.round(unwrap(t).mean(0)%L,6)) for t in tets)
cc=set(tuple(((np.array(c)+0.5)%L)) for c in cubes)
check("cube centers coincide exactly with the 64 tetrahedral-void centroids", tc==cc and len(tc)==64)
u=np.array([1,1,1])/np.sqrt(3); res={}
for t in tets:
    Q=unwrap(t); h=Q@u; apex=int(np.argmax(np.abs(h-h.mean())))
    o='up' if h[apex]>h.mean() else 'down'; par=int(round(sum(Q.mean(0)%L)-1.5))%2
    res.setdefault(o,set()).add(par)
check("void orientation <-> cube-center parity, one-to-one", res['up']!=res['down'] and len(res['up'])==1 and len(res['down'])==1)
rng=np.random.default_rng(7); theta={(s,ax):rng.uniform(-np.pi,np.pi) for s in cubes for ax in range(3)}
def link(s,ax,sign=1):
    s=tuple(int(v)%L for v in s)
    if sign==1: return theta[(s,ax)]
    sp=list(s); sp[ax]=(sp[ax]-1)%L; return -theta[(tuple(sp),ax)]
def plaq(s,a,b):
    sa=list(s); sa[a]+=1; sb=list(s); sb[b]+=1
    th=link(s,a)+link(sa,b)-link(sb,a)-link(s,b); return (th+np.pi)%(2*np.pi)-np.pi
def mono(c):
    m=0.0
    for ax in range(3):
        b_,c_=[(1,2),(2,0),(0,1)][ax]; far=list(c); far[ax]+=1
        m+=plaq(far,b_,c_)-plaq(c,b_,c_)
    return m/(2*np.pi)
Mv=[mono(c) for c in cubes]
check("DeGrand-Toussaint monopole number integer on every cube; total zero (conserved)",
      all(abs(v-round(v))<1e-9 for v in Mv) and sum(round(v) for v in Mv)==0)
print("=== E. THE GATE ===")
T3v=np.array([0.5,-0.5])
check("neutral member exists iff Y = +-1/2 (quark Y=1/6 cannot condense)",
      all(np.any(np.abs(T3v+Y)<1e-12) for Y in (0.5,-0.5)) and not any(np.any(np.abs(T3v+Y)<1e-12) for Y in (1/6,-1/6,0,1/3)))
nidx={n:i for i,n in enumerate(nodes)}; eidx={}
for k,(i,j) in enumerate(edges): eidx[(i,j)]=k; eidx[(j,i)]=k
sq=[(0,0,0),(1,1,0),(2,0,0),(1,3,0)]; vs=[nidx[p] for p in sq]; es=[eidx[(vs[k],vs[(k+1)%4])] for k in range(4)]
Cs=len(set(r for e in es for r in range(HZ.shape[0]) if HZ[r,e]))+len(set(r for e in es for r in range(HX.shape[0]) if HX[r,e]))
check("frozen plaquette count: E_s=4, C_s=9, C=36; largest local EM count 216", len(es)==4 and Cs==9 and 4*Cs==36)
check("mass identification excluded: m_W/m_e and m_Z/m_e exceed 216 by > 700x", 157300/216>700 and 178400/216>700)
print("=== F. THE LEPTON DOUBLET ===")
M=9; qs=list(range(-4,5)); Sh=np.eye(M,k=-1); R=np.fliplr(np.eye(M))
sp=np.array([[0,1],[0,0]]); sm=sp.T; sz=np.diag([1.,-1.]); sx=np.array([[0,1],[1,0]]); I2=np.eye(2)
K=lambda A,B,C: np.kron(np.kron(A,B),C)
V=K(sz,I2,np.eye(M)); T3=K(I2,sz/2,np.eye(M)); Ql=K(I2,I2,np.diag(np.array(qs,float)))
Wp=0.5*K(I2,sp,Sh); Wm=0.268*K(I2,sm,Sh.T); C=K(sx,sx,R)
Pin=K(I2,I2,np.diag([0,1,1,1,1,1,1,1,0.])); eq=lambda A,B: np.allclose(Pin@A@Pin,Pin@B@Pin,atol=1e-12)
comm=lambda A,B: A@B-B@A
def st(v,s,n):
    x=np.zeros(4*M); x[(v*2+s)*M+qs.index(n)]=1; return x
def doublet(base):
    Qel=-base*V+Ql; Y=Qel-T3; lo,up=st(0,1,0),st(0,0,1)
    return (up@Qel@up,lo@Qel@lo,up@Y@up,lo@Y@lo,(C@up)@Y@(C@up),(C@lo)@Y@(C@lo),
            eq(comm(Y,Wp),0*Y) and eq(comm(Y,Wm),0*Y) and np.allclose(comm(Y,T3),0))
q=doublet(1/3); l=doublet(1.0)
check("quark control: Q=(+2/3,-1/3), Y=+1/6 both, conjugate -1/6, invariant",
      abs(q[0]-2/3)<1e-12 and abs(q[1]+1/3)<1e-12 and abs(q[2]-1/6)<1e-12 and abs(q[3]-1/6)<1e-12 and abs(q[4]+1/6)<1e-12 and q[6])
check("lepton doublet: Q=(0,-1), Y=-1/2 both, invariant", abs(l[0])<1e-12 and abs(l[1]+1)<1e-12 and abs(l[2]+0.5)<1e-12 and abs(l[3]+0.5)<1e-12 and l[6])
check("conjugate lepton doublet: Y=+1/2 both (the Higgs quantum numbers); neutral member present",
      abs(l[4]-0.5)<1e-12 and abs(l[5]-0.5)<1e-12 and abs(l[0])<1e-12)
print("=== G. THE LINK-PHASE PARITY THEOREM ===")
check("every edge: 2 endpoints and in exactly 2 octahedra (theorem inputs)",
      set(HZ.sum(0))=={2} and set(HX.sum(0))=={2})
v0=nidx[(2,2,2)]; o0=next(i for i,oc in enumerate(octs) if v0 in oc)
mer=[e for e in range(192) if HX[o0,e] and HZ[v0,e]]
HZi=HZ.astype(np.int64); HXi=HX.astype(np.int64)
codes=np.array(list(itertools.product(range(4),repeat=len(mer))))
xs=((codes==1)|(codes==3)).astype(np.int64); zs=((codes==2)|(codes==3)).astype(np.int64)
av=(xs@HZi[:,mer].T)%2; ao=(zs@HXi[:,mer].T)%2; nz=(codes!=0).any(1)
tv=np.zeros(HZ.shape[0],int); tv[v0]=1; to=np.zeros(HX.shape[0],int); to[o0]=1
check("all 255 Paulis on the 4 shared qubits: even syndrome counts; zero single-endpoint links",
      bool(((av.sum(1)%2==0)&(ao.sum(1)%2==0))[nz].all()) and int(((av==tv).all(1)&(ao==to).all(1))[nz].sum())==0)


print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
