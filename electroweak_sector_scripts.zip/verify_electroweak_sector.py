#!/usr/bin/env python3
"""Verification script for 'The Electroweak Sector from the Verification
Front' (R. Kulkarni, 2026). One pipeline, three parts: (A) the front
asymmetry, controls, robustness, point-gap winding, skin effect,
transmission chirality, and the two exclusions; (B) the spectral flow
under flux and its quantization; (C) the su(2)+u(1) closure, boson
charges, doublet quantum numbers, and conjugation. Requires numpy.
Run: python3 verify_electroweak_sector.py   (about 3 minutes)"""
import numpy as np, itertools
from fcc_code import build, NN
ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)
print("=== A. THE FRONT ===")
HZ,HX,edges,nodes,octs=build(4)
check("code: 192 edges, CSS valid, weight-12 checks",
      len(edges)==192 and int(((HX@HZ.T)%2).sum())==0 and set(HZ.sum(1))=={12} and set(HX.sum(1))=={12})
adj={i:set() for i in range(len(nodes))}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tets=[]
for i in range(len(nodes)):
    nb=sorted(x for x in adj[i] if x>i)
    for p,q,r in itertools.combinations(nb,3):
        if q in adj[p] and r in adj[p] and r in adj[q]: tets.append(frozenset((i,p,q,r)))
lay=lambda v: sum(nodes[v]); octsets=[frozenset(o) for o in octs]
tf=lambda t:[frozenset(f) for f in itertools.combinations(sorted(t),3)]
T0=[t for t in tets if sorted(lay(v) for v in t)==[4,4,4,6]][0]
check("hop geometry: tetrahedral voids share faces only with octahedra",
      not any(len(set(t)&set(T0))==3 for t in tets if t!=T0))
def pol(committed,c=0.5,octa=False,Td=None):
    Td=Td or T0; m0=np.mean([lay(v) for v in Td]); res={}
    for O in octsets:
        if not any(f<=O for f in tf(Td)): continue
        for T1 in tets:
            if T1==Td or not any(f<=O for f in tf(T1)): continue
            m1=np.mean([lay(v) for v in T1])
            d='UP' if m1>m0+1e-9 else ('DOWN' if m1<m0-1e-9 else 'LAT')
            nc=sum(1 for v in Td if v not in T1 and committed(v))+sum(1 for v in T1 if v not in Td and committed(v))
            if octa and sum(committed(v) for v in O)>3: nc+=1
            res.setdefault(d,[]).append(nc)
    A=lambda d: np.mean([c**n for n in res.get(d,[0])])**0.5
    au,ad=A('UP'),A('DOWN'); return (au-ad)/(au+ad),au,ad
P,a,b=pol(lambda v: lay(v)<=4)
check("physical: A_up=0.500, A_down=0.268, P=+0.302", abs(a-0.5)<1e-3 and abs(b-0.2681)<1e-3 and abs(P-0.302)<2e-3)
check("C1 static: P=0 exactly", abs(pol(lambda v: True)[0])<1e-12)
check("C2 all pending: unit amplitudes, P=0", abs(pol(lambda v: False)[0])<1e-12)
check("C3 inverted frontier: sign reversed", pol(lambda v: lay(v)>=6)[0]<-0.29)
Tdn=[t for t in tets if sorted(lay(v) for v in t)==[4,6,6,6]][0]
sweep=[pol(lambda v: lay(v)<=4,c)[0] for c in (0.25,0.5,0.75)]+[pol(lambda v: lay(v)<=4,0.5,True)[0],pol(lambda v: lay(v)<=4,0.5,False,Tdn)[0]]
check("robustness: P>0 in all five declared variants", all(p>0.1 for p in sweep))
def wind(a,b):
    ks=np.linspace(0,2*np.pi,4001)[:-1]; Ek=a*np.exp(1j*ks)+b*np.exp(-1j*ks)
    return int(round(np.sum(np.angle(Ek[1:]/Ek[:-1]))/(2*np.pi)))
check("point-gap winding: physical +1, static 0, inverted -1", wind(a,b)==1 and wind(0.2035,0.2035)==0 and wind(b,a)==-1)
N=40; H=np.zeros((N,N))
for n in range(N-1): H[n+1,n]=a; H[n,n+1]=b
w,V=np.linalg.eig(H)
com=np.mean([np.sum(np.arange(N)*np.abs(V[:,i])**2)/np.sum(np.abs(V[:,i])**2) for i in range(N)])
check("skin effect: finite-chain modes pile at the frontier end", com>0.85*(N-1))
check("transmission chirality P_T(20)>0.99999", (a**20-b**20)/(a**20+b**20)>0.99999)
check("EXCLUSION C0: single-edge Pauli hop disturbs no environment check", HZ[:,0].sum()==2)
u=np.array([1,1,1])/np.sqrt(3); e1=np.array([1,-1,0])/np.sqrt(2); e2=np.cross(u,e1)
D=[np.array(d)/np.sqrt(2) for d in NN]
def sang(order):
    Pp=[D[k] for k in order]; tot=0.0
    for i in range(len(Pp)):
        A,B,C=u,Pp[i],Pp[(i+1)%len(Pp)]
        tot+=2*np.arctan2(np.dot(A,np.cross(B,C)),1+np.dot(A,B)+np.dot(B,C)+np.dot(C,A))
    return tot
az=list(np.argsort([np.arctan2(np.dot(d,e2),np.dot(d,e1)) for d in D])); ph=lambda o:(-sang(o)/2)%(2*np.pi)
pert=az[:1]+[az[2],az[1]]+az[3:]
check("EXCLUSION H2: canonical phase pi, path-sensitive, class-blind",
      abs(ph(az)-np.pi)<1e-9 and abs(ph(pert)-np.pi)>0.1 and abs((ph(az)-ph(az[::-1]))%(2*np.pi))<1e-9)
print("=== B. THE UNIT ===")
def flow(a,b,N=60,steps=721,Eref=0+0j):
    args=[]
    for phi in np.linspace(0,2*np.pi,steps):
        Hh=np.zeros((N,N),dtype=complex)
        for n in range(N): Hh[(n+1)%N,n]=a*np.exp(1j*phi/N); Hh[n,(n+1)%N]=b*np.exp(-1j*phi/N)
        s,_=np.linalg.slogdet(Hh-Eref*np.eye(N)); args.append(np.angle(s))
    uu=np.unwrap(np.array(args)); return (uu[-1]-uu[0])/(2*np.pi)
check("spectral flow: one unit per flux quantum (physical +1)", abs(flow(a,b)-1)<1e-6)
check("flow controls: static 0, inverted -1", abs(flow(0.2035,0.2035,Eref=0.1j))<1e-6 and abs(flow(b,a)+1)<1e-6)
check("flow robust in size and reference; integer identically",
      all(abs(flow(a,b,N=n)-1)<1e-6 for n in (30,90)) and all(abs(flow(a,b,Eref=E)-1)<1e-6 for E in (0.05+0.05j,-0.1j)))
print("=== C. THE ALGEBRA ===")
M=9; qs=list(range(-4,5)); Sh=np.eye(M,k=-1); R=np.fliplr(np.eye(M))
sp=np.array([[0,1],[0,0]]); sm=sp.T; sz=np.diag([1.,-1.]); sx=np.array([[0,1],[1,0]]); I2=np.eye(2)
K=lambda A,B,C: np.kron(np.kron(A,B),C)
Vv=K(sz,I2,np.eye(M)); T3=K(I2,sz/2,np.eye(M)); Z=K(I2,sz,np.eye(M))
Ql=K(I2,I2,np.diag(np.array(qs,float))); Qel=-(1/3)*Vv+Ql; Y=Qel-T3
Pin=K(I2,I2,np.diag([0,1,1,1,1,1,1,1,0.])); eq=lambda A,B: np.allclose(Pin@A@Pin,Pin@B@Pin,atol=1e-12)
comm=lambda A,B: A@B-B@A
def ops(a,b): return a*K(I2,sp,Sh), b*K(I2,sm,Sh.T)
def closure(a,b):
    Wp,Wm=ops(a,b); r=eq(comm(Wp,Wm),a*b*Z) and eq(comm(Z,Wp),2*Wp) and eq(comm(Z,Wm),-2*Wm)
    basis=[Wp,Wm,Z,Ql]; B=np.array([(Pin@X@Pin).ravel() for X in basis]).T
    for X in basis:
        for Yy in basis:
            c=(Pin@comm(X,Yy)@Pin).ravel(); coef=np.linalg.lstsq(B,c,rcond=None)[0]; r&= np.linalg.norm(B@coef-c)<1e-10
    Cm=np.array([(Pin@comm(X,Yy)@Pin).ravel() for X in basis for Yy in basis])
    return r and np.linalg.matrix_rank(Cm,tol=1e-10)==3
check("closure: su(2)+u(1), physical amplitudes", closure(a,b))
check("control: closure identical with static amplitudes", closure(0.2035,0.2035))
Wp,Wm=ops(a,b)
check("non-unitary representation iff a != b", not np.allclose(Wm,Wp.conj().T) and np.allclose(ops(0.2,0.2)[1],ops(0.2,0.2)[0].conj().T))
check("boson charges: W+- carry +-1, Z neutral", eq(comm(Ql,Wp),Wp) and eq(comm(Ql,Wm),-Wm) and eq(comm(Ql,Z),0*Z))
def st(v,s,n):
    x=np.zeros(4*M); x[(v*2+s)*M+qs.index(n)]=1; return x
uq,dq=st(0,0,1),st(0,1,0)
check("doublet: Q=(+2/3,-1/3), T3=+-1/2, Y=+1/6 on both",
      abs(uq@Qel@uq-2/3)<1e-12 and abs(dq@Qel@dq+1/3)<1e-12 and abs(uq@Y@uq-1/6)<1e-12 and abs(dq@Y@dq-1/6)<1e-12)
check("Y su(2)-invariant", eq(comm(Y,Wp),0*Y) and eq(comm(Y,Wm),0*Y) and np.allclose(comm(Y,T3),0))
Cc=K(sx,sx,R); Ci=np.linalg.inv(Cc); cj=lambda A: Cc@A@Ci
check("C well-defined: Q, T3, Y odd; conjugate doublet Y=-1/6 on both",
      eq(cj(Qel),-Qel) and eq(cj(T3),-T3) and eq(cj(Y),-Y) and abs((Cc@uq)@Y@(Cc@uq)+1/6)<1e-12 and abs((Cc@dq)@Y@(Cc@dq)+1/6)<1e-12)
check("the front breaks C: C W+ C^-1 = (a/b) W-", eq(cj(Wp),(a/b)*Wm))
print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
