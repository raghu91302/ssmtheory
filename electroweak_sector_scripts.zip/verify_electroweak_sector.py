#!/usr/bin/env python3
"""Verification script for 'The Electroweak Sector from the Verification
Front' (R. Kulkarni, 2026; with the breaking sector).
(A) front asymmetry, controls, robustness, winding, skin effect,
transmission chirality, two exclusions; (B) spectral flow and its
quantization; (C) su(2)+u(1) closure, boson charges, doublet quantum
numbers, conjugation; (D) monopole cells at the tetrahedral voids;
(E) the gate: the Y=+-1/2 constraint and the frozen counts; (F) the
lepton doublet with the quark control; (G) the link-phase parity
theorem. Requires numpy. Run: python3 verify_electroweak_sector.py
Hops follow the edge-channel rule of Defect Migration (Symmetry 18, 1571);
geometry is computed with minimum-image displacements on the torus.
Runtime ~6 minutes."""
import numpy as np, itertools
from fcc_code import build, NN
ok=True
def check(n,c):
    global ok; print(("PASS  " if c else "FAIL  ")+n); ok&=bool(c)

print("=== A. THE FRONT ===")
HZ,HX,edges,nodes,octs=build(4)
check("code: 192 edges, CSS valid, weight-12 checks",
      len(edges)==192 and int(((HX@HZ.T)%2).sum())==0 and set(HZ.sum(1))=={12} and set(HX.sum(1))=={12})
adj={i:set() for i in range(len(nodes))}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tets=[]
for i in range(len(nodes)):
    nb=sorted(x for x in adj[i] if x>i)
    for p,q,r in itertools.combinations(nb,3):
        if q in adj[p] and r in adj[p] and r in adj[q]: tets.append(frozenset((i,p,q,r)))
# ---- the hop rule of Defect Migration (Symmetry 18, 1571): edge hops only ----
# A trapped node leaves its tetrahedral void only across one of the six edges, into
# the void that shares that edge; face exits are closed by the metric wall. Heights
# along the stacking axis are measured from the defect by minimum-image displacements.
U=np.array([1,1,1.])
def torus(Lt):
    HZt,HXt,ed,nd,oc=build(Lt); Xt=np.array(nd,float)
    ad={i:set() for i in range(len(nd))}
    for p,q in ed: ad[p].add(q); ad[q].add(p)
    ts=set()
    for p in range(len(nd)):
        for q,r,w in itertools.combinations(sorted(ad[p]),3):
            if r in ad[q] and w in ad[q] and w in ad[r]: ts.add(frozenset((p,q,r,w)))
    return dict(L=Lt,X=Xt,tets=list(ts))
def mi(d,Lt): return (d+Lt/2)%Lt-Lt/2
def cen(g,T):
    p0=g['X'][next(iter(T))]; return p0+np.mean([mi(g['X'][v]-p0,g['L']) for v in T],axis=0)
def height(g,T):
    c0=cen(g,T); return lambda v: mi(g['X'][v]-c0,g['L'])@U
def orient(g,T):
    hh=height(g,T); hs=sorted(hh(v) for v in T); return 'base-down' if abs(hs[0]-hs[1])<1e-9 else 'base-up'
def edge_nbrs(g,T): return [t for t in g['tets'] if len(t&T)==2]
def hops(g,Td,committed):
    c0=cen(g,Td); res={'UP':[],'DOWN':[],'LAT':[]}
    for T1 in edge_nbrs(g,Td):
        dh=mi(cen(g,T1)-c0,g['L'])@U
        d='UP' if dh>1e-9 else ('DOWN' if dh<-1e-9 else 'LAT')
        res[d].append(sum(committed(v) for v in (Td^T1)))
    return res
def amps(g,Td,mode='physical',c=0.5,shift=0):
    hh=height(g,Td); hs=sorted(hh(v) for v in Td); base,top=hs[0],hs[-1]
    com={'physical':lambda v: hh(v)<=base+shift+1e-9,'static':lambda v:True,'pending':lambda v:False,
         'inverted':lambda v: hh(v)>=top-1e-9}[mode]
    r=hops(g,Td,com); A=lambda d: np.mean([c**n for n in r[d]])**0.5
    au,ad=A('UP'),A('DOWN'); return au,ad,(au-ad)/(au+ad),r
G4=torus(4); G8=torus(8)
# the metric wall (exclusion rule of the Matter paper): a node may not lie within L/sqrt3 of
# all three vertices of a triangle at once. Face centroids sit exactly on it; edge paths never meet it.
def wall_check(g,T,samples=201):
    X,Lt=g['X'],g['L']; c0=cen(g,T); Lb=np.sqrt(2); wall=Lb/np.sqrt(3)
    near=lambda x: sorted(np.linalg.norm(np.array([mi(X[v]-x,Lt) for v in range(len(X))]),axis=1))
    faces=[frozenset(f) for f in itertools.combinations(sorted(T),3)]
    face_on_wall=all(abs(near(c0+np.mean([mi(X[v]-c0,Lt) for v in f],axis=0))[2]-wall)<1e-9 for f in faces)
    edge_ok=True
    for T1 in edge_nbrs(g,T):
        d=mi(cen(g,T1)-c0,Lt)
        for s_ in np.linspace(0,1,samples):
            if near(c0+s_*d)[2] < wall-1e-9: edge_ok=False
    return face_on_wall, edge_ok
fw,eo=wall_check(G8,next(iter(G8['tets'])))
check("metric wall: every face centroid lies exactly L/sqrt3 from its three atoms (face exits closed)", fw)
check("metric wall: along every edge path at most two atoms come within L/sqrt3 (edge exits open)", eo)
defect={o:next(t for t in G8['tets'] if orient(G8,t)==o) for o in ('base-down','base-up')}
geo=all(len(edge_nbrs(Gt,T))==6 and all(orient(Gt,t)!=orient(Gt,T) for t in edge_nbrs(Gt,T)) for Gt in (G4,G8) for T in Gt['tets'][:64])
check("hop rule: six edge neighbours per void, every one of the opposite orientation (L=4 and L=8)", geo)
split={o:{k:len(v) for k,v in amps(G8,defect[o])[3].items()} for o in defect}
check("each void has 3 up-hops, 3 down-hops and no lateral hop along the stacking axis, both orientations",
      all(split[o]=={'UP':3,'DOWN':3,'LAT':0} for o in defect))
inv_ok=True
for o in defect:
    ref=tuple(np.round(amps(G8,defect[o])[:2],9))
    for Gt in (G4,G8):
        inv_ok&={tuple(np.round(amps(Gt,t)[:2],9)) for t in Gt['tets'] if orient(Gt,t)==o}=={ref}
check("translation invariance: every void of an orientation gives the same amplitudes, on L=4 and L=8", inv_ok)
r0=amps(G8,defect['base-down'])[3]; r1=amps(G8,defect['base-up'])[3]
check("every down-hop touches exactly one more committed site than every up-hop (2 vs 3; 1 vs 2)",
      set(r0['UP'])=={2} and set(r0['DOWN'])=={3} and set(r1['UP'])=={1} and set(r1['DOWN'])=={2})
a,b,P,_=amps(G8,defect['base-down']); a2,b2,P2,_=amps(G8,defect['base-up'])
print("      front at the bottom of the void: base-down A_up=%.4f A_down=%.4f | base-up A_up=%.4f A_down=%.4f | P=%+.6f"%(a,b,a2,b2,P))
PC=lambda c:(1-np.sqrt(c))/(1+np.sqrt(c))
check("physical: P = (1-sqrt c)/(1+sqrt c) = 3-2sqrt2 = +0.1716 at c=1/2, identical for both orientations",
      abs(P-PC(0.5))<1e-12 and abs(P2-PC(0.5))<1e-12 and abs(PC(0.5)-(3-2*np.sqrt(2)))<1e-12)
sa,sb,sP,_=amps(G8,defect['base-down'],'static'); sa2,sb2,sP2,_=amps(G8,defect['base-up'],'static')
check("static crystal: P = 0 exactly for both orientations", abs(sP)<1e-12 and abs(sP2)<1e-12)
check("all checks pending: P = 0 exactly for both orientations",
      all(abs(amps(G8,defect[o],'pending')[2])<1e-12 for o in defect))
check("inverted front: P = -(3-2sqrt2) exactly for both orientations",
      all(abs(amps(G8,defect[o],'inverted')[2]+PC(0.5))<1e-12 for o in defect))
check("closed form at every declared cost: P = 1/3, 3-2sqrt2, 0.0718 at c = 1/4, 1/2, 3/4, both orientations",
      all(abs(amps(G8,defect[o],'physical',c)[2]-PC(c))<1e-12 for o in defect for c in (0.25,0.5,0.75)))
place={o:[amps(G8,defect[o],'physical',shift=s)[2] for s in (-4,-2,0,2,4,6)] for o in defect}
print("      frontier placement s=-4..+6: base-down %s | base-up %s"%([round(float(x),4) for x in place['base-down']],[round(float(x),4) for x in place['base-up']]))
check("frontier placement: P is +0.1716 when the frontier meets the hop neighbourhood and 0 otherwise; never negative",
      all(abs(x)<1e-12 or abs(x-PC(0.5))<1e-12 for o in place for x in place[o]) and all(x>-1e-12 for o in place for x in place[o]))
def wind(x,y):
    ks=np.linspace(0,2*np.pi,4001)[:-1]; Ek=x*np.exp(1j*ks)+y*np.exp(-1j*ks)
    return int(round(np.sum(np.angle(Ek[1:]/Ek[:-1]))/(2*np.pi)))
check("point-gap winding: W=+1 with the front and -1 inverted for both orientations; W=0 in the static crystal",
      wind(a,b)==1 and wind(a2,b2)==1 and wind(b,a)==-1 and wind(sa,sb)==0 and wind(sa2,sb2)==0)
def alt_chain(N,au_d,ad_d,au_u,ad_u,phi=0.0,ring=True):
    # worldline alternating base-down (even sites) and base-up (odd sites), as edge hops require
    H=np.zeros((N,N),complex)
    for n in range(N if ring else N-1):
        m=(n+1)%N; up=au_d if n%2==0 else au_u; dn=ad_d if m%2==0 else ad_u
        H[m,n]+=up*np.exp(1j*phi/N); H[n,m]+=dn*np.exp(-1j*phi/N)
    return H
Hs=alt_chain(40,a,b,a2,b2,ring=False); w_,V=np.linalg.eig(Hs)
com_=np.mean([np.sum(np.arange(40)*np.abs(V[:,i])**2)/np.sum(np.abs(V[:,i])**2) for i in range(40)])
check("skin effect on the alternating worldline: modes pile at the frontier end", com_>0.85*39)
adm=lambda x,y,n: 0.5*(1-(x**n-y**n)/(x**n+y**n))
check("transmission chirality: right-handed admixture (sqrt c)^n, = 3.0e-2, 9.8e-4, 9.5e-7 at n=10,20,40, both orientations",
      all(abs(adm(x,y,n)-(np.sqrt(0.5)**n)/(1+np.sqrt(0.5)**n))<1e-12 for x,y in ((a,b),(a2,b2)) for n in (10,20,40))
      and abs(adm(a,b,20)-9.76e-4)<1e-5)
check("EXCLUSION C0: single-edge Pauli hop disturbs no environment check", HZ[:,0].sum()==2)
u=np.array([1,1,1])/np.sqrt(3); e1=np.array([1,-1,0])/np.sqrt(2); e2=np.cross(u,e1)
D=[np.array(d)/np.sqrt(2) for d in NN]
def sang(order):
    Pp=[D[k] for k in order]; tot=0.0
    for i in range(len(Pp)):
        A,B,C=u,Pp[i],Pp[(i+1)%len(Pp)]
        tot+=2*np.arctan2(np.dot(A,np.cross(B,C)),1+np.dot(A,B)+np.dot(B,C)+np.dot(C,A))
    return tot
az=list(np.argsort([np.arctan2(np.dot(d,e2),np.dot(d,e1)) for d in D])); ph=lambda o:(-sang(o)/2)%(2*np.pi)
pert=az[:1]+[az[2],az[1]]+az[3:]
check("EXCLUSION H2: canonical phase pi, path-sensitive, class-blind",
      abs(ph(az)-np.pi)<1e-9 and abs(ph(pert)-np.pi)>0.1 and abs((ph(az)-ph(az[::-1]))%(2*np.pi))<1e-9)
print("=== B. THE UNIT ===")
def flow_alt(au_d,ad_d,au_u,ad_u,N=40,steps=801,Eref=0.02+0.01j):
    ph=np.linspace(0,2*np.pi,steps)
    d=[np.linalg.det(alt_chain(N,au_d,ad_d,au_u,ad_u,p)-Eref*np.eye(N)) for p in ph]
    return np.sum(np.angle(np.array(d[1:])/np.array(d[:-1])))/(2*np.pi)
fl=flow_alt(a,b,a2,b2)
check("spectral flow on the alternating worldline: one unit per flux quantum with the front", abs(fl-1)<1e-6)
check("flow controls: 0 in the static crystal, -1 with the front inverted",
      abs(flow_alt(sa,sb,sa2,sb2))<1e-6 and abs(flow_alt(b,a,b2,a2)+1)<1e-6)
check("flow independent of ring size and reference inside the gap; an integer identically",
      all(abs(flow_alt(a,b,a2,b2,N=Nn)-1)<1e-6 for Nn in (20,60)) and abs(flow_alt(a,b,a2,b2,Eref=0.05+0.02j)-1)<1e-6)
print("=== C. THE ALGEBRA ===")
M=9; qs=list(range(-4,5)); Sh=np.eye(M,k=-1); R=np.fliplr(np.eye(M))
sp=np.array([[0,1],[0,0]]); sm=sp.T; sz=np.diag([1.,-1.]); sx=np.array([[0,1],[1,0]]); I2=np.eye(2)
K=lambda A,B,C: np.kron(np.kron(A,B),C)
Vv=K(sz,I2,np.eye(M)); T3=K(I2,sz/2,np.eye(M)); Z=K(I2,sz,np.eye(M))
Ql=K(I2,I2,np.diag(np.array(qs,float))); Qel=-(1/3)*Vv+Ql; Y=Qel-T3
Pin=K(I2,I2,np.diag([0,1,1,1,1,1,1,1,0.])); eq=lambda A,B: np.allclose(Pin@A@Pin,Pin@B@Pin,atol=1e-12)
comm=lambda A,B: A@B-B@A
def ops(a,b): return a*K(I2,sp,Sh), b*K(I2,sm,Sh.T)
def closure(a,b):
    Wp,Wm=ops(a,b); r=eq(comm(Wp,Wm),a*b*Z) and eq(comm(Z,Wp),2*Wp) and eq(comm(Z,Wm),-2*Wm)
    basis=[Wp,Wm,Z,Ql]; B=np.array([(Pin@X@Pin).ravel() for X in basis]).T
    for X in basis:
        for Yy in basis:
            c=(Pin@comm(X,Yy)@Pin).ravel(); coef=np.linalg.lstsq(B,c,rcond=None)[0]; r&= np.linalg.norm(B@coef-c)<1e-10
    Cm=np.array([(Pin@comm(X,Yy)@Pin).ravel() for X in basis for Yy in basis])
    return r and np.linalg.matrix_rank(Cm,tol=1e-10)==3
check("closure: su(2)+u(1), physical amplitudes", closure(a,b))
check("control: closure identical with the static amplitudes", closure(sa,sb) and closure(sa2,sb2))
Wp,Wm=ops(a,b)
check("non-unitary representation iff a != b", not np.allclose(Wm,Wp.conj().T) and np.allclose(ops(0.2,0.2)[1],ops(0.2,0.2)[0].conj().T))
check("boson charges: W+- carry +-1, Z neutral", eq(comm(Ql,Wp),Wp) and eq(comm(Ql,Wm),-Wm) and eq(comm(Ql,Z),0*Z))
Yc=Ql-0.5*Z
check("center: Q is not central, Q - sigma_z/2 is central (the hypercharge direction)",
      not eq(comm(Ql,Wp),0*Wp) and eq(comm(Yc,Wp),0*Wp) and eq(comm(Yc,Wm),0*Wm) and eq(comm(Yc,Z),0*Z))
def st(v,s,n):
    x=np.zeros(4*M); x[(v*2+s)*M+qs.index(n)]=1; return x
uq,dq=st(0,0,1),st(0,1,0)
check("doublet: Q=(+2/3,-1/3), T3=+-1/2, Y=+1/6 on both",
      abs(uq@Qel@uq-2/3)<1e-12 and abs(dq@Qel@dq+1/3)<1e-12 and abs(uq@Y@uq-1/6)<1e-12 and abs(dq@Y@dq-1/6)<1e-12)
check("Y su(2)-invariant", eq(comm(Y,Wp),0*Y) and eq(comm(Y,Wm),0*Y) and np.allclose(comm(Y,T3),0))
Cc=K(sx,sx,R); Ci=np.linalg.inv(Cc); cj=lambda A: Cc@A@Ci
check("C well-defined: Q, T3, Y odd; conjugate doublet Y=-1/6 on both",
      eq(cj(Qel),-Qel) and eq(cj(T3),-T3) and eq(cj(Y),-Y) and abs((Cc@uq)@Y@(Cc@uq)+1/6)<1e-12 and abs((Cc@dq)@Y@(Cc@dq)+1/6)<1e-12)
check("the front breaks C: C W+ C^-1 = (a/b) W-", eq(cj(Wp),(a/b)*Wm))
check("C is broken by the same factor in both orientations: A_up/A_down = 1/sqrt(c) = sqrt(2)",
      abs(a/b-np.sqrt(2))<1e-12 and abs(a2/b2-np.sqrt(2))<1e-12)

L=4
print("=== D. MONOPOLE CELLS ===")
nodeset=set(nodes); cubes=[(x,y,z) for x in range(L) for y in range(L) for z in range(L)]
corners=lambda c: [tuple(((c[i]+d[i])%L) for i in range(3)) for d in itertools.product((0,1),repeat=3)]
check("every elementary cube of the node-void grid has 4 node + 4 void corners",
      all(sum(1 for q in corners(c) if q in nodeset)==4 for c in cubes))
adj={i:set() for i in range(len(nodes))}
for i,j in edges: adj[i].add(j); adj[j].add(i)
tets=[]
for i in range(len(nodes)):
    nb=sorted(x for x in adj[i] if x>i)
    for a,b,c in itertools.combinations(nb,3):
        if b in adj[a] and c in adj[a] and c in adj[b]: tets.append((i,a,b,c))
def unwrap(t):
    P=np.array([nodes[v] for v in t],float); ref=P[0]
    return np.array([ref+((p-ref+L/2)%L-L/2) for p in P])
tc=set(tuple(np.round(unwrap(t).mean(0)%L,6)) for t in tets)
cc=set(tuple(((np.array(c)+0.5)%L)) for c in cubes)
check("cube centers coincide exactly with the 64 tetrahedral-void centroids", tc==cc and len(tc)==64)
u=np.array([1,1,1])/np.sqrt(3); res={}
for t in tets:
    Q=unwrap(t); h=Q@u; apex=int(np.argmax(np.abs(h-h.mean())))
    o='up' if h[apex]>h.mean() else 'down'; par=int(round(sum(Q.mean(0)%L)-1.5))%2
    res.setdefault(o,set()).add(par)
check("void orientation <-> cube-center parity, one-to-one", res['up']!=res['down'] and len(res['up'])==1 and len(res['down'])==1)
rng=np.random.default_rng(7); theta={(s,ax):rng.uniform(-np.pi,np.pi) for s in cubes for ax in range(3)}
def link(s,ax,sign=1):
    s=tuple(int(v)%L for v in s)
    if sign==1: return theta[(s,ax)]
    sp=list(s); sp[ax]=(sp[ax]-1)%L; return -theta[(tuple(sp),ax)]
def plaq(s,a,b):
    sa=list(s); sa[a]+=1; sb=list(s); sb[b]+=1
    th=link(s,a)+link(sa,b)-link(sb,a)-link(s,b); return (th+np.pi)%(2*np.pi)-np.pi
def mono(c):
    m=0.0
    for ax in range(3):
        b_,c_=[(1,2),(2,0),(0,1)][ax]; far=list(c); far[ax]+=1
        m+=plaq(far,b_,c_)-plaq(c,b_,c_)
    return m/(2*np.pi)
Mv=[mono(c) for c in cubes]
check("DeGrand-Toussaint monopole number integer on every cube; total zero (conserved)",
      all(abs(v-round(v))<1e-9 for v in Mv) and sum(round(v) for v in Mv)==0)
print("=== E. CONSTRAINTS ON THE BREAKING SECTOR ===")
T3v=np.array([0.5,-0.5])
check("neutral member exists iff Y = +-1/2 (quark Y=1/6 cannot condense)",
      all(np.any(np.abs(T3v+Y)<1e-12) for Y in (0.5,-0.5)) and not any(np.any(np.abs(T3v+Y)<1e-12) for Y in (1/6,-1/6,0,1/3)))
nidx={n:i for i,n in enumerate(nodes)}; eidx={}
for k,(i,j) in enumerate(edges): eidx[(i,j)]=k; eidx[(j,i)]=k
sq=[(0,0,0),(1,1,0),(2,0,0),(1,3,0)]; vs=[nidx[p] for p in sq]; es=[eidx[(vs[k],vs[(k+1)%4])] for k in range(4)]
Cs=len(set(r for e in es for r in range(HZ.shape[0]) if HZ[r,e]))+len(set(r for e in es for r in range(HX.shape[0]) if HX[r,e]))
check("frozen plaquette count: E_s=4, C_s=9, C=36; largest local EM count 216", len(es)==4 and Cs==9 and 4*Cs==36)
check("mass identification excluded: m_W/m_e and m_Z/m_e exceed 216 by > 700x", 157300/216>700 and 178400/216>700)
print("=== F. THE LEPTON DOUBLET ===")
M=9; qs=list(range(-4,5)); Sh=np.eye(M,k=-1); R=np.fliplr(np.eye(M))
sp=np.array([[0,1],[0,0]]); sm=sp.T; sz=np.diag([1.,-1.]); sx=np.array([[0,1],[1,0]]); I2=np.eye(2)
K=lambda A,B,C: np.kron(np.kron(A,B),C)
V=K(sz,I2,np.eye(M)); T3=K(I2,sz/2,np.eye(M)); Ql=K(I2,I2,np.diag(np.array(qs,float)))
Wp=0.5*K(I2,sp,Sh); Wm=0.268*K(I2,sm,Sh.T); C=K(sx,sx,R)
Pin=K(I2,I2,np.diag([0,1,1,1,1,1,1,1,0.])); eq=lambda A,B: np.allclose(Pin@A@Pin,Pin@B@Pin,atol=1e-12)
comm=lambda A,B: A@B-B@A
def st(v,s,n):
    x=np.zeros(4*M); x[(v*2+s)*M+qs.index(n)]=1; return x
def doublet(base):
    Qel=-base*V+Ql; Y=Qel-T3; lo,up=st(0,1,0),st(0,0,1)
    return (up@Qel@up,lo@Qel@lo,up@Y@up,lo@Y@lo,(C@up)@Y@(C@up),(C@lo)@Y@(C@lo),
            eq(comm(Y,Wp),0*Y) and eq(comm(Y,Wm),0*Y) and np.allclose(comm(Y,T3),0))
q=doublet(1/3); l=doublet(1.0)
check("quark control: Q=(+2/3,-1/3), Y=+1/6 both, conjugate -1/6, invariant",
      abs(q[0]-2/3)<1e-12 and abs(q[1]+1/3)<1e-12 and abs(q[2]-1/6)<1e-12 and abs(q[3]-1/6)<1e-12 and abs(q[4]+1/6)<1e-12 and q[6])
check("lepton doublet: Q=(0,-1), Y=-1/2 both, invariant", abs(l[0])<1e-12 and abs(l[1]+1)<1e-12 and abs(l[2]+0.5)<1e-12 and abs(l[3]+0.5)<1e-12 and l[6])
check("conjugate lepton doublet: Y=+1/2 both (the Higgs quantum numbers); neutral member present",
      abs(l[4]-0.5)<1e-12 and abs(l[5]-0.5)<1e-12 and abs(l[0])<1e-12)
print("=== G. THE LINK-PHASE PARITY THEOREM ===")
check("every edge: 2 endpoints and in exactly 2 octahedra (theorem inputs)",
      set(HZ.sum(0))=={2} and set(HX.sum(0))=={2})
v0=nidx[(2,2,2)]; o0=next(i for i,oc in enumerate(octs) if v0 in oc)
mer=[e for e in range(192) if HX[o0,e] and HZ[v0,e]]
HZi=HZ.astype(np.int64); HXi=HX.astype(np.int64)
codes=np.array(list(itertools.product(range(4),repeat=len(mer))))
xs=((codes==1)|(codes==3)).astype(np.int64); zs=((codes==2)|(codes==3)).astype(np.int64)
av=(xs@HZi[:,mer].T)%2; ao=(zs@HXi[:,mer].T)%2; nz=(codes!=0).any(1)
tv=np.zeros(HZ.shape[0],int); tv[v0]=1; to=np.zeros(HX.shape[0],int); to[o0]=1
check("all 255 Paulis on the 4 shared qubits: even syndrome counts; zero single-endpoint links",
      bool(((av.sum(1)%2==0)&(ao.sum(1)%2==0))[nz].all()) and int(((av==tv).all(1)&(ao==to).all(1))[nz].sum())==0)


print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
