# P_L Prerequisite 1 - Extraction Record (Matter paper)

Source: R. Kulkarni, Phys. Open 27 (2026) 100423. Read against
PL_protocol.md (Amendment 1). Date: August 30, 2026. This record
completes the Matter-paper half of Prerequisite 1.

## A. The Lift, as the paper defines it (Sec. 2.3)

- Lift places a node above the centroid of a triangular face at the
  unique height h = sqrt(2/3) L (three-unit-sphere intersection).
- The solution set is a 0-parameter APEX PAIR - above and below the
  face - "of which one is selected by orientation." The orientation
  selection is therefore part of the Lift's published definition.
- P_lift = e^-3, suppressed by codimension; lifts are the rare events
  that weld sheets (mean inter-layer bond count 4.9 per node).
- Fig. 1: K = 12 = 6 in-plane (Stitch) + 3 upper (Layer C, z = +h,
  "reached by lift") + 3 lower (Layer A, z = -h, "the mirror lift").
  The upper/lower triads are the two sheets of the orientation
  doublet.

## B. The defect, as the paper defines it (Secs. 3-4)

- Extra node at the tetrahedral-void centroid, bonded to the 4
  bounding vertices; 1 anchor + 3 valence under the host embedding.
- The two void orientations (a/4- and 3a/4-centered) are related by
  spatial inversion; anchor choice is dynamical.
- PUBLISHED SUPPORT FOR HYPOTHESIS H (Sec. 4.4, verbatim content):
  the two void orientations are "the geometric origin of matter and
  antimatter, and the local cosmological excess of one orientation
  over the other selects the observed matter-dominated universe."
  The reservoir-for-the-sign idea is therefore already in print in
  the series; H extends it from matter selection to chirality
  selection by the same front.

## C. The hop, constructed from the Lift (per Amendment 1)

The paper defines growth, not defect motion; but the Lift determines
the hop up to the code dictionary:

- hop_up: the defect re-bonds from its current sheet to the adjacent
  UPPER sheet through a Lift-type triangular face (Layer C side).
  In code terms its support lies on edges whose checks are PENDING
  (structure created by the most recent growth events; verification
  not yet applied).
- hop_down: the defect re-bonds to the LOWER sheet through the
  mirror-Lift face (Layer A side). Support lies on edges whose
  checks are COMMITTED (stabilizers projected; the verified past).
- The environments differ ONLY in check status; geometry is
  identical by the paper's own inversion pairing (Theorem 1 of the
  F4-to-E6 paper reconstructs this).

## D. What MEI must still supply (second half of Prerequisite 1)

The dictionary defect <-> code excitation: how the extra node and its
four bonds are represented on the edge-qubit CSS code (which edges,
which checks see the defect), and the charge table. Without it, any
explicit hop operator would be a stand-in, which the protocol
forbids. MEI upload = the last input before Steps 1-4 run.

## E. Status

- Prerequisite 2 (code rebuild): COMPLETE (fcc_code.py, 6x PASS).
- Prerequisite 1, Matter half: COMPLETE (this record).
- Prerequisite 1, MEI half: PENDING (upload in the execution
  session).
- Steps 1-4 + controls C1-C3: NOT STARTED; to run in a fresh session
  under the locked criteria, never in a depleted context.

---

## F. MEI extraction (Phys. Open 27, 100414) - completes Prerequisite 1

Date: August 30, 2026.

**The defect <-> code dictionary.** Particles are localized syndrome
patterns on the [[192,130,3]] code. The footprint is a set of EDGES
(qubits) of the 13-node coordination cluster C13; the detecting
constraints are the vertex stabilizers plus the face structure
(C_s = f0 + f2). Explicitly: electron = single edge (E_s=1, C_s=1);
pion = 2-sheet, E_s=16, C_s=17 (+1 closing string); muon = 3-sheet
EM sector, 36 x 6 - 9; proton = full cluster, E_s=36, C_s=51,
dim(B)=1836; neutron = 1836 + D=3 internal probes. The coupling
matrix B (36 x 51, nnz=192, BB^T = edge Hodge Laplacian) is
constructible from fcc_code.py's H_Z, H_X plus the cluster face data.

**For the hop.** The baryon defect's code support is the full C13
cluster (E_s = 36). The doublet hop's two channels are the anchor
vertex's upper-triad edges (Layer C side) versus lower-triad edges
(Layer A side); which checks contain each edge is read directly from
H_Z (vertex checks) and H_X (octahedral checks) in fcc_code.py. All
objects for Steps 1-4 now exist on disk.

**DEFINITIONAL CAUTION (resolve before Step 1).** The two papers use
two different sheet decompositions of K=12: the Matter paper's
close-packed layering 6+3+3 (Layers A/B/C - the orientation doublet
of hypothesis H) and MEI's three orthogonal 2D sheets of 4 (the
verification-cost bookkeeping). The hop environments MUST be defined
in the Matter-paper layering; MEI's orthogonal sheets enter only
through C_s counting. Conflating them would silently change the
doublet. The execution session states which decomposition each
object uses before any computation runs.

**Side effect - a standing debt cleared.** The merged paper's one
[imported] tag (defects occupy glue classes) is verified against
source: the Matter paper (Sec. 3.1-3.2) places the extra node at the
tetrahedral-void centroid, and the tetrahedral voids are the
glue-class sites of the D4 home. The import is sound. The Paper 6
interstitial battery (added-node vs vacancy) remains open and is NOT
run here.

## G. Final status

- Prerequisite 1: COMPLETE (Matter + MEI extracted, this record).
- Prerequisite 2: COMPLETE (fcc_code.py, 6x PASS).
- Steps 1-4 + controls C1-C3: READY, NOT STARTED. Per Section E,
  they run in a fresh session under the locked criteria. Opening
  moves: resolve the sheet-decomposition caution; build the hop on
  H_Z/H_X; run with C1-C3; judge by Section 4 outcomes only.

---

## H. Step 0 executed + the Step-1 fork (working note, pre-execution)

Date: August 30, 2026. Steps 1-4 remain NOT RUN.

**Step 0 resolved.** On the verified L=4 code: the 12 neighbors split
6+3+3 along (1,1,1) with upper triad {(1,1,0),(1,0,1),(0,1,1)} and
lower triad the negatives - the Matter-paper doublet, confirmed
disjoint from MEI's 4+4+4 orthogonal decomposition. Object table
built at a bulk node: each triad edge participates in exactly 2
vertex-checks and 2 octahedral-checks, symmetric between up and down
as inversion requires. All indices on record in the transcript.

**The Step-1 fork.** Two formalizations of the hop exist, and the
choice is THE decision of Step 1:

(a) Pauli-syndrome motion (defect = violated checks on fixed qubits;
hop = X-string). VERIFIED FACT: a single-edge X-hop anticommutes
with exactly its two endpoint vertex checks (source and target of
the defect - its own syndrome) and commutes with every octahedral
check and every other vertex check. It therefore disturbs NO
environment stabilizer, committed or pending: the environments are
indistinguishable and the computation returns Outcome B trivially.
RULING: this is a modeling artifact, not a physics verdict. The
Matter paper's defect is a structural extra node with four bonds -
new qubits - not a syndrome on fixed qubits. Formalization (a) is
model-unfaithful and is EXCLUDED as the basis for the verdict. It
survives only as control C0: any pipeline must reproduce its null.

(b) Structural re-bonding (hop = destroy the four bonds, create four
new bonds at the adjacent void - the Lift/un-stitch machinery). This
engages the environment: a created or destroyed bond changes the
support of the weight-12 checks containing it, and on the committed
side those checks hold projected eigenvalues that constrain the
process; on the pending side they do not. This is the model-faithful
formalization and the one Steps 1-4 must use. It requires a bond
creation/annihilation formalism on the code - defining it cleanly is
the execution session's first construction, done fresh, with the
initialization state of a new bond taken from the growth rule (or
documented as a declared choice if the papers underdetermine it).

**Why execution still waits.** The verdict now rests entirely on a
formalism not yet defined. Defining it in a depleted context, with
the desired outcome known, is the April condition. The execution
session builds (b), runs C0/C1/C2/C3 and the physical configuration,
and judges by Section 4 of the protocol. Nothing else remains before
it.

---

## I. EXECUTION RECORD - Steps 1-4 run (August 30, 2026)

**Model M1, declared before the numbers:** fresh bond in |+> (Bell-bond
convention); committed = vertex checks at layers <= frontier,
projected; each bond created or destroyed at a committed interface
costs 1/2 in syndrome-free probability; pending interfaces free;
A^2 = (1/2)^(n_c). Hop = tetra -> octa -> tetra (the corrected
adjacency: tetra voids share faces only with octahedra - the X-check
sites sit in every hop path). Endpoint bond bookkeeping; single
sampled up-void; amplitudes averaged over the 28 geometric paths.

**Results (L=4, defect at up-void, frontier at base layer):**
- PHYSICAL: A_up = 0.500, A_down = 0.268, polarization
  P = (A_up - A_down)/(A_up + A_down) = +0.302.
- C1 (all committed / static crystal): P = 0.000 exactly; up and
  down n_c distributions identical {4,6,8} - the published static
  centrosymmetry obstruction reproduced in the numbers.
- C2 (all pending): all amplitudes 1; P = 0.000.
- C3 (frontier inverted): P = -0.305 - sign reversed, magnitude
  matched. The sign comes from the front, not the construction.

**VERDICT (per Section 4, no reinterpretation):**
- Not Outcome A: A_down = 0.268 != 0, and the suppression is a fixed
  per-step ratio, not code-distance-scaling.
- Not Outcome B: A_up != A_down by a factor 1.87.
- **OUTCOME C: the chiral structure is OBTAINED IN MODIFIED FORM.**
  The induced doublet generator is A_up sigma+ + A_down sigma-:
  a genuinely parity-violating coupling (nonzero sigma_y component,
  now DYNAMICALLY derived, upgrading the kinematic sigma_y of the
  worldline paper), chirally weighted at P = 0.30 per step, but not
  the clean projector P_L (which requires P = 1).

**Characterization of the partial structure (recorded, not decided):**
the per-step asymmetry compounds along a worldline as
(A_up/A_down)^n ~ 1.87^n: the defect statistically rides the growth
front. Whether this compounding yields an effective P_L in the
continuum limit is the follow-up computation; deciding it tonight
would be rounding up to Outcome A, which Section 4 forbids.

**Model-dependence caveats (binding on any write-up):** the |+>
initialization, the 1/2-per-interface rule, endpoint-only counting
(octahedral transit not separately costed), one sampled void
orientation, mean-over-paths aggregation. Robustness of P = 0.30
under these declared choices is untested. The RESULT that survives
all four configurations regardless of these choices: asymmetry
exists iff a frontier exists, with sign set by the front.

**Queued next:** (1) M1 robustness sweep (init state, costing rule,
octa transit, down-void defect); (2) the compounding/continuum
analysis; (3) only then, drafting - under the vocabulary of rule 5.

---

## J. Hypothesis H2 registered (August 30, 2026 - before its test runs)

**H2 (sequential handedness and the circuit phase).** The syndrome
circuit that gathers a weight-12 check must traverse the shell in
SOME cyclic order; the two routing classes (handed about the growth
axis) exist and are exchanged by spatial inversion (verified,
choice-free). H2 asserts: (a) the first executed circuit at a
defect's birth fixes the class; (b) worldline memory: subsequent
QEC updates must preserve the recorded sequence (topological lock);
(c) REQUIRED for viability - the birth choice is inherited from the
GLOBAL growth sequence (the front's own operational order), never
drawn per defect; a per-defect choice predicts handedness-mixed
matter and is falsified at once; (d) the two routing classes
accumulate different geometric phases through the out-of-plane
(sigma_y) sector, and if the class difference is pi mod 2pi, a
strict +/-1 is injected: the operational origin of the Matter
paper's empirical winding restriction w in {0,+1} (Eq. 9), and of
the integer unit the charge fence proved cannot be a Cartan charge.

**Pre-specified test (to run in the robustness session, not
tonight):** define the doublet transport rule for one out-of-plane
segment ONCE, from the Lift geometry, before computing any phase;
compute the accumulated phase for at least 6 representative paths in
EACH routing class. PASS if the phase is class-constant
(path-independent within a class = genuinely topological) AND the
class difference is pi mod 2pi. FAIL if path-dependent (artifact) or
unquantized (no strict unit). Either result publishes.

**Consistency notes on record:** H2 supplies exactly the non-Cartan
origin the charge fence demanded; it is independent of M1's
commit-status resource (two selection mechanisms, possibly
cooperating: candidate P=0.30 completer); the skeleton facts
(routing classes exist, inversion exchanges them, closed loops with
6 out-of-plane visits) are verified above.

## J'. Correction to J, from the skeleton check itself

The claim "inversion exchanges the routing classes" is FALSE and the
check caught it: spatial inversion acts on the projection plane as a
rotation by pi, which PRESERVES planar circulation (verified:
handedness +1 -> +1). What inversion actually flips is the
out-of-plane visit pattern (z-steps negate). The two routing classes
(clockwise vs counterclockwise circuits) are exchanged by CIRCUIT
REVERSAL - running the gather sequence backward, the operational
time-reversal - and by reflection, not by P.

Consequence for H2 (recorded, not yet exploited): the circuit
direction is an operational T-ODD, P-even choice - an arrow of
operation. The class-dependent phase of H2(d) therefore couples the
circuit arrow to the growth arrow (both T-odd), and the correct
discrete-symmetry bookkeeping of the accumulated phase under P, T,
and PT is hereby added to the pre-specified test: the phase's parity
under each must be COMPUTED, not assumed, and any chirality claim
must survive that bookkeeping. This tightens H2 rather than wounding
it: "chirality from chronology" now enters twice - the front's arrow
and the circuit's arrow - and the test decides whether they lock.

---

## K. EXECUTION RECORD - robustness sweep + continuum analysis

**(1) Robustness (queued item 1): DONE.** Polarization stays positive
in every physical variant: cost rule c=1/4 -> P=+0.54, c=1/2 ->
+0.30, c=3/4 -> +0.13; octa transit costed -> +0.37; down-void
defect -> +0.41; frontier placement irrelevant (+0.302 both).
C1 = 0.000 under all choices; C3 sign-flips throughout. VERDICT:
sign and front-iff are model-robust; the magnitude is
model-dependent in [0.13, 0.54] as declared.

**(2) Compounding/continuum (queued item 2): DONE, decisive.** The
effective worldline dynamics is directed hopping - the
Hatano-Nelson class. Computed:
- PHYSICAL: spectral winding W = +1 (point-gap topological
  invariant); finite-chain modes pile at the frontier end (center
  37.6/39): the non-Hermitian skin effect. "Rides the front" is now
  a topological statement.
- C1 static: W = 0, delocalized. C3 inverted: W = -1, piled at the
  opposite end.
- W depends only on sign(A_up - A_down), so it is +1 across the
  ENTIRE robustness sweep: the soft per-step polarization feeds a
  STRICT, QUANTIZED, MODEL-ROBUST +/-1 set by the front.
- NN guard: the dynamics is non-Hermitian (measurement
  irreversibility), outside Nielsen-Ninomiya's assumptions; point-gap
  winding has no Hermitian counterpart; no doubler restores the
  symmetry.

**Characterization of Outcome C, completed:** the chiral structure is
obtained as POINT-GAP TOPOLOGY - an exact winding number +/-1,
front-signed, model-robust - rather than as an amplitudinal
projector. The strict integer the program hunted exists in the
worldline spectrum.

**Boundaries (binding):** W = +1 is a statement about defect
transport, not yet about the gauge vertex; equating it with SU(2)_L
left-handedness awaits the bridge (queued item 4). Whether W is
also the H2 charge-unit integer awaits item 3. Both remain
pre-specified and unrun.

---

## L. EXECUTION RECORD - H2 phase test and the bridge (final items)

**(3) H2 phase test: FAIL, as pre-specified.** Transport rule declared
once (spin-1/2 of the growth direction, parallel transport, Berry
phase = -solid angle/2; no further choices). Results: the canonical
circuit gives phase exactly pi (a strict -1 exists), BUT (a)
within-class spread 0.55 rad under path perturbations - NOT
class-constant, hence not topological in the required sense; and (b)
the two routing classes give the SAME phase mod 2pi (reversal sends
pi -> -pi = pi) - no class discrimination. VERDICT, locked
vocabulary: the H2 circuit-phase mechanism for the integer unit is
EXCLUDED BY COMPUTATION under the declared rule. The universal -1
(hemisphere phase) is recorded as a curiosity, unhanded and
unexploited. This negative publishes with everything else.

**(4) The bridge: DONE.** Per-step vertex = 0.384 sigma_x +
i 0.116 sigma_y: a V - lambda*A structure with lambda = P = 0.30
(model-dependent, 0.13-0.54). Transmission chirality over n steps:
P_T = (a^n-b^n)/(a^n+b^n) -> 1 exponentially; right-handed
admixture (b/a)^-n: 4x10^-2 at n=5, 2x10^-3 at n=10, 4x10^-6 at
n=20, 10^-11 at n=40. STATEMENT: the vertex is partially chiral per
step; PROPAGATION is asymptotically exactly chiral.
FALSIFIER-SHAPED PREDICTION (recorded): right-handed couplings are
exponentially suppressed but never exactly zero at finite
verification depth - a structural difference from the Standard
Model's exact zero. The physical value of n (verification depth per
interaction) is NOT determined here; only the nonzero-exponential
character is claimed.

## M. Program state at close

DERIVED: dynamical parity violation (front-signed, iff-front,
model-robust in sign). OBTAINED IN MODIFIED FORM: chirality as exact
point-gap topology (W = +/-1, Hatano-Nelson class, skin effect =
riding the front) plus asymptotically exact transmission chirality;
per-step vertex V - 0.30 A. EXCLUDED: the H2 circuit-phase origin of
the integer unit (declared rule); the Pauli-hop formalization (C0).
OPEN: the physical verification depth n; the operational meaning of
W versus the Matter paper's winding w (flagged, not claimed); H2's
universality requirement if any variant of it returns. All
computations pre-registered; every verdict in locked vocabulary;
negatives recorded beside positives. Drafting, when it comes, uses
rule 5's words and includes Section L's FAIL.

---

## N. EXECUTION RECORD - H3 (Amendment 2) run

**The pre-specified calculation.** Spectral flow = winding of
det(H(phi)-E) under one flux quantum through the worldline ring
(tracking-free; an integer identically). Results: PHYSICAL +1,
robust across N = 30..120 and every reference inside the point gap;
C1 static 0; C3 inverted -1. Controls pass; the sign is the front's.

**Verdict (Amendment 2 vocabulary): OUTCOME A - DERIVED.** The
worldline pumps exactly one unit of charge per flux quantum. By
Callan-Harvey anomaly matching, a boundary mode of flow W is the
edge of a bulk theta = 2*pi*W; by the Witten effect, flux/monopole-
bound matter shifts electric charge by e*theta/2pi = e*W. Hence
q = -1/3 + W: the up-type +2/3 for W = +1. The identification step
(flow -> theta) is anomaly matching and is tagged as such; the
physical, convention-free content is the pumping itself and the
dyonic relabeling of flux-bound states.

**Outcome B empty by quantization:** determinant winding is an
integer; fractional theta/2pi cannot arise; the geometric thirds are
untouched. No collision.

**Bonus derivations:** (i) the Matter paper's empirical winding
restriction w >= 0 is now derived - W = -1 requires an inverted
frontier, which the physical configuration forbids; negative-w
charges (-4/3, ...) are excluded by the front's sign, matching their
non-observation. (ii) w's upper truncation (w <= 1) remains open.
(iii) The framework now REQUIRES monopole-type defects of the <100>
photon grid; their microscopic code construction is open (P2) and is
a falsifier-shaped commitment.

---

## O. EXECUTION RECORD - H4 (Amendment 3) items (i) and (ii)

**Formalism declared before the run:** doublet (upper/lower sheet)
tensor a compact-U(1) link rotor. W+ = a sigma+ (x) e^{i phi},
W- = b sigma- (x) e^{-i phi} (the derived directed hops, each
pumping one unit), Q the link charge, photon the link phase.

**(i) CLOSURE - PASS (derived).** [W+,W-] = ab sigma_z (the
Z-candidate); [sigma_z, W+-] = +-2 W+-; the span {W+,W-,Z,Q} is
closed under commutators; dim = 4, derived algebra dim = 3 = su(2),
Q central. The hop algebra IS su(2) + u(1). Verified for the
physical amplitudes AND for the static control (a = b): the algebra
is front-independent, as the amendment required; the front enters
only through W- != (W+)^dagger - a non-unitary representation of the
same algebra, which is the parity-violating charged current.
Consistency: MEI's four square-plaquette modes = dim su(2)+u(1) = 4.

**(ii) CHARGES - PASS (derived).** [Q,W+-] = +-W+-: the charged
bosons carry +-1 unit of the derived U(1); [Q,Z] = 0 and the photon
is neutral. Both strict tests passed.

**Gate status:** items (iii) neutral mixing and (iv) masses are now
OPEN per Amendment 3, and NOT run here. They require the
symmetry-breaking sector (the mass matrix of the neutral modes),
i.e. the declared square-plaquette fluctuation formalism and P2.
Vocabulary for (i)-(ii): "derived." No comparison with any measured
electroweak number has been made or may be made until (iii)/(iv)
values are frozen in this record.

## P. H4 neutral sector, structural part (Amendment 3, gate opened)

**Hypercharge - DERIVED (arithmetic of derived inputs).** With the
standard T3 = +-1/2 normalization (the one declared input), the
front-made doublet (upper sheet, n=1 pumped; lower sheet, n=0)
carries Q = (+2/3, -1/3), T3 = (+1/2, -1/2), and Y = Q - T3 = +1/6 on
BOTH members: constant on the doublet, and [Y,W+] = [Y,W-] =
[Y,T3] = 0 (su(2)-invariant). This is the Standard Model Y(Q_L) =
1/6, obtained from geometric thirds + spectral-flow unit + hop
closure. No target was used; the value fell out.

**Conjugate doublet - operator check NOT correctly done in this
session.** The arithmetic gives Y = -1/6 on both antidoublet members
(-2/3 + 1/2; +1/3 - 1/2), but the operator-level construction run
here was mis-labeled and its output is void. Deferred to the session
that builds the charge-conjugation map on doublet x rotor properly.
Recorded as a pending check, not a result.

**Mixing angle (iii) and masses (iv): NOT computed.** They require
the relative coupling normalization of link versus hop fluctuations,
i.e. the declared square-plaquette fluctuation formalism and P2.
No comparison with sin^2(theta_W), m_W, or m_Z has been made, and
none may be made before those values are frozen here.

## Q. Pre-step 1 done: the conjugate doublet, operator level (replaces the voided check in P)

Model enlarged by the void-orientation label v = +-1 (the Matter
paper's Sec. 4.4 antimatter label), distinct from the sheet doublet:
Q_el = -(1/3) v + Q_link. Charge conjugation C = (flip void) (x)
(flip sheet) (x) (reflect rotor charge). VERIFIED: C Q C^-1 = -Q,
C T3 C^-1 = -T3, C Y C^-1 = -Y; antidoublet (C-images of u, d)
carries Q = (-2/3, +1/3), T3 = (-1/2, +1/2), Y = -1/6 on BOTH
members; Y commutes with W+-, T3 on the full space; the hop algebra
is unchanged. The check in Section P is now DONE and passing.
Bonus, recorded not exploited: C W+ C^-1 = (a/b) W- - the front
breaks C as well as P (coupling strengths swap). CP status: open,
to be computed, not assumed.

---

## R. EXECUTION RECORD - P2 (Amendment 4): monopoles as code objects

All three registered criteria PASS on the verified L=4 code:
 (a) The 64 elementary cubes of the node-void simple-cubic grid have
     centers coinciding EXACTLY with the 64 tetrahedral-void
     centroids; every cube has 4 node corners and 4 octahedral-void
     corners.
 (b) The two parity classes of cube centers are the two
     tetrahedral-void orientations, one-to-one (32 up -> parity 1,
     32 down -> parity 0). [First run misreported this through a
     torus-wrap bug in the classifier; the wrap-safe test passes.
     Recorded as a corrected implementation, not a changed criterion.]
 (c) The DeGrand-Toussaint monopole number is an integer on every
     cube for arbitrary compact link configurations, and the total
     charge on the torus is zero (current conserved).

**VERDICT: P2 PASS - monopoles are code-localized objects.** Their
cells are the tetrahedral voids: the sites that carry the code's
logical qubits (CSS paper, Sec. 7) and the trapped matter node
(Matter paper, Sec. 3). The monopole's orientation class is the
void orientation - the matter/antimatter label.

**Consequences (tagged):** DERIVED: monopole cells = tetrahedral
voids; orientation = parity class; integer, conserved monopole
charge on the photon grid. RECORDED, NOT CLAIMED: the dyon locality
conjecture - that the Witten linking number is the monopole number
of the defect's own cell (quark = node + monopole in one void).
STILL DECLARED: the link phases as functions of the code's qubits;
this construction locates the monopoles and shows they are
well-defined; it does not derive the U(1) from the stabilizers.

**Unblocked:** Amendment 3 items (iii) and (iv) now have their
prerequisite P2. The square-plaquette fluctuation formalism remains
to be declared before they run.

---

## S. EXECUTION RECORD - the gate (Amendment 5): items (iii) and (iv)

**(iii) Mixing angle - NOT COMPUTED; constraint DERIVED.** A massless
photon requires a condensing doublet with a neutral member, i.e.
Q = T3 + Y = 0 for one member, which forces Y = +-1/2 exactly. The
front-made quark doublet (Y = 1/6) has no neutral member and CANNOT
be the condensate. The framework therefore REQUIRES a Y = +-1/2
doublet - the quantum numbers of the lepton doublet and of the
Higgs - as the condensing sector. That doublet is not derived in
the record, so the angle is not computed and no value is compared.
Vocabulary: "constraint derived; angle open."

**(iv) Masses - COMPUTED, FROZEN, COMPARED: MISS.** On the actual
code a square plaquette has E_s = 4 edges and C_s = 9 detecting
checks (4 vertex + 5 octahedral): C = 36. The largest local
EM-sector count in the MEI bookkeeping is 216. Frozen before
comparison. m_W/m_e = 157,300 and m_Z/m_e = 178,400 exceed these by
factors of 700 to 5,000. VERDICT: the W and Z masses are NOT the
verification cost of any local plaquette fluctuation. The
identification of boson mass with local counting is EXCLUDED BY
COMPUTATION. The mass scale must come from the breaking scale of
the condensate of (iii). Vocabulary: "excluded by computation."

**What the gate returned, in one line:** the electroweak dynamics
needs a Y = 1/2 sector the framework has not built, and the boson
masses live at that sector's scale, not in local counting. Both
statements are derived constraints on the next construction; neither
is a number.

**No measured electroweak value was used to produce any result
above; the two masses were consulted only after the counts were
frozen, as registered.**

---

## T. EXECUTION RECORD - H5 (Amendment 6): the lepton doublet

**OUTCOME A - DERIVED.** With the lepton baseline set by the
projection rule for a single-bond defect (self-projection +-1,
signed by the void orientation) and no other input, the front-made
lepton doublet is:
  upper sheet, n=1:  Q = 0,  T3 = +1/2,  Y = -1/2   (the neutrino)
  lower sheet, n=0:  Q = -1, T3 = -1/2,  Y = -1/2   (the electron)
Y is constant on the doublet and commutes with W+-, T3; the
C-conjugate doublet carries Q = (0, +1), Y = +1/2 on both members.
The quark control is reproduced unchanged (Y = +1/6) by the same
code. The doublet has a NEUTRAL member: the gate's requirement
(Amendment 5, item iii) is met by this sector.

**What is derived:** the lepton charges (0, -1) - previously not
derived anywhere in the series - and the Standard Model's Y(L) =
-1/2, from three inputs derived earlier (projection rule, spectral
flow unit, hop closure) and one stated extension of a published rule
(the single-bond baseline). No target was used.

**What this enables (not done):** a condensate in the Y = +1/2
conjugate direction has the Higgs quantum numbers; the neutral
member is the condensable one. The mixing angle still requires the
coupling normalization and is NOT computed. The family count (E6's
nine-state block = three families x (nu, e, e^c)?) is noted as a
consistency to test, not used.

**Extension tag, binding on any write-up:** "the lepton baseline is
the self-projection of its single bond" is an extension of the
Matter paper's rule, declared here; it is the one new input.

---

## U. EXECUTION RECORD - H6 (Amendment 7): link phases from the qubits

**Theorem (verified on the code, general for any Pauli).** Every edge
has exactly two endpoints (H_Z column weight 2) and lies in exactly
two octahedra (H_X column weight 2). Hence any Pauli operator
anticommutes with an EVEN number of vertex checks (the boundary of
its X-support) and an EVEN number of octahedral checks (each edge
counted twice across octahedra). No Pauli operator on any set of
qubits can carry charge at a single endpoint under the code's own
checks. Exhaustive check on the four qubits shared by a node-void
link (255 non-identity Paulis): all syndrome counts even; ZERO
operators anticommuting with exactly the vertex check at v and the
octahedral check at o.

**VERDICT H6: OUTCOME C - EXCLUDED BY COMPUTATION** in the registered
form. A compact U(1) link phase covariant under the code's checks
cannot be a local operator on the shared qubits, because the code's
Gauss laws are Z2 and their charged objects come in PAIRS: a single
excitation on a shared edge flips two vertex checks and two
octahedral checks (a dipole), never one of each.

**What the exclusion teaches (derived, tagged):** the electromagnetic
U(1) of the framework must be realized on DIPOLE degrees of freedom
- pairs of charges - not on single-endpoint links. This is
consistent with, and now explains, the Matter paper's own picture
of photon channels as alternating {+,-} oscillations on the
bipartite square faces (Sec. 6.4): the square is the minimal dipole
cell. The registered follow-on (H6', to be written before it runs):
the link phase as a covariant object on a node-node PAIR through the
equatorial square of their shared octahedron, with covariance under
the paired checks, and the coupling read from the dipole moment per
qubit operation.

**Consequences for the gate:** H6 did not return A or B, so by
Amendment 7 H7 remains closed. The mixing angle and the boson masses
are NOT computable in the present record, and no value was
consulted. The two hurdles are now three: the dipole realization
(H6'), then the couplings, then the scale.

## Addendum - corrected front geometry (September 23, 2026)

Recomputed under Amendment 8 (minimum-image heights, frontier relative
to the defect; L = 4 and L = 8 tori and an open lattice agree).

| quantity | first run (raw coordinates) | corrected, base-down void | corrected, base-up void |
|---|---|---|---|
| neighbours up : down : lateral | 10 : 10 : 8 | 12 : 10 : 6 | 10 : 12 : 6 |
| A_up, A_down (frontier at the bottom of the void) | 0.500, 0.268 | 0.415, 0.292 | 0.707, 0.415 |
| P, frontier at the bottom of the void | +0.302 | +0.174 | +0.261 |
| P, static crystal | 0 | -0.041 | +0.041 |
| P, inverted front | -0.305 | -0.261 | -0.174 |
| W: front / static / inverted | +1 / 0 / -1 | +1 / -1 / -1 | +1 / +1 / -1 |
| P at c = 1/4, 3/4; octahedral transit costed | +0.54, +0.13; +0.37 | +0.318, +0.080; +0.252 | +0.449, +0.119; +0.261 |
| P, frontier at the void's top | not computed | -0.015 | +0.289 |

Charge conjugation across orientations: the base-down up-hop and the
base-up down-hop have exactly equal amplitude (0.415); the base-down
down-hop and the base-up up-hop do not (0.292 against 0.707).

Verdicts: two registered falsifiers met for a single orientation, as
recorded in Amendment 8; every other verdict unchanged.
