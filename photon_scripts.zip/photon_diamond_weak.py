"""Is the <111> diamond the natural home for a chiral SU(2) sector?"""
import itertools, numpy as np
from itertools import product
print("THE DECISIVE PROPERTY: WHICH STRUCTURE IS NON-CENTROSYMMETRIC?\n")
sets={
 "<110> close-packed":[np.array(d,float) for d in product((-1,0,1),repeat=3) if sum(map(abs,d))==2],
 "<100> cubic":[np.array(d,float) for d in product((-1,0,1),repeat=3) if sum(map(abs,d))==1],
 "<111> diamond":[np.array(s,float)/np.sqrt(3) for s in
                  [(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]],
}
print("  %-22s %-8s %-14s %s"%("structure","coord","rank-3 moment","site symmetry"))
for nm,S in sets.items():
    T3=np.zeros((3,3,3))
    for v in S: T3+=np.einsum('i,j,k->ijk',v,v,v)
    m=np.abs(T3).max()
    print("  %-22s %-8d %-14.5f %s"%(nm,len(S),m,"O_h (centrosymmetric)" if m<1e-9 else "T_d (NON-centrosymmetric)"))
print()
print("  only the diamond has a non-vanishing odd moment. It is the ONLY")
print("  structure in the packing that can carry a handedness.\n")
print("WHY THAT MATTERS FOR THE WEAK SECTOR\n")
print("  the photon paper states the obstruction directly:")
print('    \"FCC centrosymmetry forbids a static chiral assignment on it: the')
print('     interlayer up- and down-environments of any bulk node are inversion')
print('     partners, so a handedness cancels under parity.\"')
print()
print("  and it notes what selecting a diamond sublattice does:")
print('    \"that choice reduces the site symmetry from O_h to T_d ... a')
print('     spontaneous selection of one orientation over its inversion')
print('     partner, structurally analogous to a Higgs-like choice of vacuum\"')
print()
print("  so the paper already identifies the diamond choice as parity-breaking")
print("  and Higgs-like. It used that for the piezoelectric coupling. The same")
print("  property is exactly what a chiral SU(2) sector requires.\n")
print("TWO FURTHER STRUCTURAL FITS\n")
L=4
print("  1. the diamond is BIPARTITE with two sublattices, A and B. A")
print("     two-sublattice structure carries a natural 2-component index --")
print("     the same mechanism that gives graphene its pseudospin -- which is")
print("     the doublet structure SU(2) acts on.")
print()
print("  2. there are TWO tetrahedral interstitial sublattices, inversion")
print("     partners of each other. Selecting one is a binary vacuum choice")
print("     with an unbroken and a broken option: the shape of a Higgs")
print("     selection, not an analogy to one.")
