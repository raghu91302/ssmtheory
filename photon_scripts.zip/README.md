# Electromagnetism on the cubic sublattice of the FCC vacuum

Verification scripts for the paper *Electromagnetism on the cubic sublattice of
the FCC vacuum: the correct photon polarization count, and masslessness from
centrosymmetry* (R. Kulkarni, 2026).

Every number in the paper is produced here. Nothing is hard-coded: the lattices
are built from their defining rules and the ranks are computed with
`numpy.linalg.matrix_rank` or exact F2 elimination.

## Requirements

    python >= 3.8, numpy

`photon_make_figures.py` additionally needs `matplotlib`. Each script runs in
seconds and prints its results; run them from any directory.

## Scripts

| script | what it verifies |
|---|---|
| `photon_verify_100.py` | the cubic sublattice and its bipartiteness; the Hodge split giving 1 gauge + 2 transverse modes per site; disjointness from the code qubits; the moments of the ⟨100⟩ star; the dispersion and its isotropy; the four-dimensional lift |
| `photon_emission.py` | every ⟨110⟩ edge is covered by exactly two two-step ⟨100⟩ paths through octahedral voids, and the two differ by one cubic plaquette |
| `photon_two_codes.py` | the FCC and cubic CSS codes on identical qubit counts, [[192,130,3]] against [[192,3,4]], and a weight-L winding operator bounding the distance |
| `photon_sector_table.py` | coordination, bipartiteness and moments for the three structures, behind the sector assignment |
| `photon_diamond_weak.py` | rank-three moments: the ⟨111⟩ diamond is the only non-centrosymmetric structure in the packing |
| `photon_make_figures.py` | both figures, recomputing the geometry and the Hodge ranks rather than drawing them by hand |

## Expected output

Key values, at L = 4 and L = 6 unless noted:

    cubic sublattice     nodes + voids = L^3, bipartite by parity
    Hodge split          exact 0.995/site, coexact 1.991/site, harmonic 3
    code complex         one physical polarization per site, not two
    disjointness         192 code edges, 192 gauge links, 0 shared
    rank-3 moment        <110> 0, <100> 0, <111> 0.770
    edge covering        2 paths per edge, all intermediates are voids
    two codes            [[192,130,3]] and [[192,3,4]]
    4D lift              D4 + odd coset = Z^4, 24 bonds each split 2 ways

## Building the paper

    pdflatex photon_cubic.tex
    pdflatex photon_cubic.tex

The two figure PDFs must be in the same directory. Regenerate them with
`python3 photon_make_figures.py`.
