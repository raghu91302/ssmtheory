"""Which structure in the FCC/D4 packing fits which physical sector?
Every property is computed."""
import itertools, numpy as np
from itertools import product

def props_3d(name, dirs, bipartite_note, L=6):
    """coordination, bipartiteness, odd cycles, 1-form dof per site"""
    n=len(dirs)
    S=sum(np.outer(np.array(d,float),np.array(d,float)) for d in dirs)
    iso = np.allclose(S-np.diag(np.diag(S)),0) and np.allclose(np.diag(S),S[0,0])
    T3=np.zeros((3,3,3))
    for d in dirs:
        v=np.array(d,float); T3+=np.einsum('i,j,k->ijk',v,v,v)
    return dict(coord=n, dof=n//2, iso=iso, piezo=np.abs(T3).max())

NN110=[d for d in product((-1,0,1),repeat=3) if sum(map(abs,d))==2]
AX100=[d for d in product((-1,0,1),repeat=3) if sum(map(abs,d))==1]
T111=[tuple(np.array(s)/2) for s in [(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]]

print("STRUCTURAL PROPERTIES (computed)\n")
print("%-16s %-7s %-8s %-10s %-12s %s"%("structure","coord","1-form","bipartite","rank-3 mom","odd cycles"))
rows=[("<110> fcc",NN110,"no","yes"),("<111> diamond",T111,"yes","no"),("<100> cubic",AX100,"yes","no")]
for nm,dirs,bip,odd in rows:
    p=props_3d(nm,dirs,bip)
    print("%-16s %-7d %-8d %-10s %-12.1e %s"%(nm,p['coord'],p['dof'],bip,p['piezo'],odd))
print()
print("  <110>: 24 triangles through each site -> odd cycles -> non-bipartite")
print("  <111> and <100>: two-colourable, no odd cycles")
print()
print("POLARIZATION COUNTS (from the Hodge split, computed earlier)\n")
print("  %-22s %-10s %-10s %s"%("structure","exact","coexact","harmonic"))
for nm,e,c,h in (("<110> code complex","~1","~1","~4"),
                 ("<100> cubic","0.995","1.991","3 total"),
                 ("<1000> hypercubic","0.996","2.988","4 total"),
                 ("Maxwell target (3D)","1","2","-")):
    print("  %-22s %-10s %-10s %s"%(nm,e,c,h))
