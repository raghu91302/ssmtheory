#!/usr/bin/env python3
"""Moments g_A and mu_p of the Peierls-Yoccoz state (zero total momentum), compared with the fixed-center state.
Adapted from py_projection.py.
Peierls-Yoccoz projection of three quarks in the lowest cavity mode onto total momentum zero.
The quark mode u is the lowest positive-energy state of the lattice Dirac Hamiltonian of dirac_cavity.py:
   h = alpha.(-i grad) + beta [ M(x) + (r/2)(-Laplacian) ],  M = 0 inside the cavity, M_out outside, periodic box.
The three-quark state is the product Phi = u(r1) u(r2) u(r3) (spin-averaged overlaps). Its translate by a is Phi_a.
In the free-center picture the wall moves with the quarks, so the one-body energy between Phi and Phi_a uses the
average of the two walls:  h(a) = <u|T|u_a> + <u| beta (M(x) + M(x-a))/2 |u_a>,  T the translation-invariant part.
With n(a) = <u|u_a>:
   E_PY = 3 sum_a h(a) n(a)^2 / sum_a n(a)^3                       (energy of the P = 0 state)
   r_int^2 = sum_a (2/3)[q(a) n(a)^2 - d(a).d(a) n(a)] / sum_a n(a)^3   (mean square radius about the quarks' center)
with q(a) = <u|x^2|u_a>, d(a) = <u|x|u_a>. Without projection (a = 0 only): E = 3 e, r_int^2 = (2/3)<x^2>.
Usage: python3 py_projection.py sphere|cubo n R Mout"""
import numpy as np, scipy.sparse as sp, sys
from scipy.sparse.linalg import lobpcg, LinearOperator
shape=sys.argv[1]; n=int(sys.argv[2]); Rg=float(sys.argv[3]); Mout=float(sys.argv[4]); r=1.0
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); Z=np.zeros((2,2))
al=[np.block([[Z,s],[s,Z]]) for s in (s1,s2,s3)]; be=np.diag([1,1,-1,-1]).astype(complex)
c=(np.arange(n)-n/2+0.5); X,Y,Zc=np.meshgrid(c,c,c,indexing='ij')
if shape=='sphere': inside=X**2+Y**2+Zc**2<Rg**2
else:
    a=Rg/np.sqrt(2); inside=(np.abs(X)<a)&(np.abs(Y)<a)&(np.abs(Zc)<a)&(np.abs(X)+np.abs(Y)+np.abs(Zc)<2*a)
Mx=np.where(inside,0.0,Mout); N=n**3; I=sp.identity(N,format='csr')
def shift(d,s):
    idx=np.arange(N).reshape(n,n,n); j=np.roll(idx,-s,axis=d).ravel(); return sp.csr_matrix((np.ones(N),(np.arange(N),j)),shape=(N,N))
D=[];Lap=-6*I
for d in range(3):
    Sp,Sm=shift(d,1),shift(d,-1); D.append((Sp-Sm)/2); Lap=Lap+Sp+Sm
T=sp.kron(-0.5*r*Lap,be)
for d in range(3): T=T+sp.kron(-1j*D[d],al[d])
T=T.tocsr(); W=sp.kron(sp.diags(Mx.ravel()),be).tocsr(); H=(T+W).tocsr()
H2=LinearOperator(H.shape,matvec=lambda v: H@(H@v),dtype=complex)
rng=np.random.default_rng(0); X0=rng.random((H.shape[0],4))+0j
w,V=lobpcg(H2,X0,largest=False,tol=1e-9,maxiter=4000)
E=np.sqrt(w.real.min())
# positive-energy subspace: P+ v = (v + H v / E)/2 ; orthonormalize two vectors
U=[]
for i in range(V.shape[1]):
    v=V[:,i]; p=(v+H@v/E)/2
    for u in U: p=p-u*(u.conj()@p)
    if np.linalg.norm(p)>1e-3: U.append(p/np.linalg.norm(p))
    if len(U)==2: break
res=max(np.linalg.norm(H@u-E*u) for u in U)
def field(v): return v.reshape(n,n,n,4)
def corr(f,g):
    """C(a) = sum_x f(x)^dag g(x-a), all shifts a, summed over spinor components."""
    F=np.fft.fftn(f,axes=(0,1,2)); G=np.fft.fftn(g,axes=(0,1,2))
    return np.fft.ifftn((np.conj(F)*G).sum(-1),axes=(0,1,2))   # = sum_x f*(x) g(x+a); flip below
def corrA(f,g): C=corr(f,g); return np.roll(np.flip(C,axis=(0,1,2)),1,axis=(0,1,2))  # g(x-a)
xs=np.stack([X,Y,Zc],-1)
nA=0; hA=0; hT=0; qA=0; dA=[0,0,0]
S12=corrA(field(U[0]),field(U[1])); S11=corrA(field(U[0]),field(U[0]))
for u in U:   # spin average over the two degenerate modes
    uf=field(u); Tu=field(T@u); bMu=field(W@u)
    hT=hT+corrA(uf,Tu)/2
    nA=nA+corrA(uf,uf)/2; hA=hA+(corrA(uf,Tu)+0.5*(corrA(bMu,uf)+corrA(uf,bMu)))/2
    qA=qA+corrA(uf*(xs**2).sum(-1)[...,None],uf)/2
    for k in range(3): dA[k]=dA[k]+corrA(uf*xs[...,k][...,None],uf)/2

# spin-up mode of the doublet
Sz=np.block([[s3,Z],[Z,s3]]); OSz=sp.kron(sp.identity(N),sp.csr_matrix(Sz))
Um=np.array(U).T; A_=Um.conj().T@(OSz@Um); w2,v2=np.linalg.eigh(A_); up=Um@v2[:,1]
f=field(up)
def app(M4,v): return field(sp.kron(sp.identity(N),sp.csr_matrix(M4))@v)
nA=corrA(f,f).real
sA=corrA(f,app(Sz,up)).real
ax=app(al[0],up); ay=app(al[1],up)
mxy=corrA(f*X[...,None],ay)-corrA(f*Y[...,None],ax)
vx=corrA(f,ax); vy=corrA(f,ay)
idx=np.arange(n); sh=np.where(idx<n//2,idx,idx-n)
AX,AY,AZ=np.meshgrid(sh,sh,sh,indexing='ij')
m=0.5*(mxy-(AX/2)*vy+(AY/2)*vx)
print('max imag of m: %.1e  weighted-sum imag/real: %.1e'%(np.abs(m.imag).max(),abs((m.imag*nA**2).sum())/abs((m.real*nA**2).sum()))); m=m.real
Z3=(nA**3).sum()
gA_fix=5/3*sA[0,0,0]; gA_py=5/3*(sA*nA**2).sum()/Z3
mu_fix=m[0,0,0]; mu_py=(m*nA**2).sum()/Z3
qA=corrA(f*(xs**2).sum(-1)[...,None],f).real; dA=[corrA(f*xs[...,k][...,None],f).real for k in range(3)]
d2=sum(d**2 for d in dA)
rcav=np.sqrt(qA[0,0,0]); rint=np.sqrt(((2/3)*(qA*nA**2-d2*nA)).sum()/Z3)
hc=197.327; rp=0.84075; mp=938.272
print('%s n=%d R=%g Mout=%g  n(0)=%.6f  rcav/R=%.4f rint/R=%.4f'%(shape,n,Rg,Mout,nA[0,0,0],rcav/Rg,rint/Rg))
print('  g_A: fixed center %.4f  projected %.4f  ratio %.4f'%(gA_fix,gA_py,gA_py/gA_fix))
print('  mu/length: fixed %.4f (per rcav)  projected %.4f (per rint)'%(mu_fix/rcav,mu_py/rint))
print('  mu_p at r_p [mu_N] (grid values): fixed center %.3f   projected %.3f'%(2*mp*rp*mu_fix/rcav/hc, 2*mp*rp*mu_py/rint/hc))
