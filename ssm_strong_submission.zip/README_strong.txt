A Self-Correcting Discrete Vacuum: Baryon Conservation and Color (comprehensive, full depth)
Author: Raghu Kulkarni (raghu@idrive.com)

ONE comprehensive paper (17 pp) for the strong sector, replacing the
conservation/qutrit, unified-vacuum, gauge-structure, and dynamical-connection
papers. Full derivations restored throughout; nothing compressed to summary.

ARC (one code, two sectors):
  CODE       explicit [[192,130,3]] build: weight-12 star/cage stabilizers,
             commutation (overlap 0 or 4), k=192-62=130, distance-3, [4,4,4] split
  EXTERNAL   orientation NOT protected (2/3 cost); baryon charge Q=-1+W as a
             Gauss-law super-selection rule + ladder table; E=gamma E_rest
             (sine-Gordon, 6 d.p.); migration as code-corrected string
  INTERNAL   emergent qutrit (T=(J3-I3)(x)J2, full factorization + dark sector);
             S4/V4=S3 Weyl + torus; A2=su(3) selection table among rank-2 algebras;
             anchor leakage (Gamma_A-Gamma)/2 with two-regime bound; color-complete
             triangles (explicit displacement check); Z3 triality code (chain
             complex, CSS auto, k=3=b1(T^3), integer homology no torsion, octahedral
             subsumed); 513-dim SU(3) Gauss law gated by triality; gauge-invariant
             plaquette (1e-16); spatial N(T) obstruction (3 channels, bond-disjoint);
             temporal su(3) closure (J3-I3 + torus -> dim 8); strong-coupling area
             law + string tension; single-plaquette ED with 4/3 gap
  UNIFICATION one Gauss law refined Z -> Z3 -> SU(3), shared distance-3 protection

FIGURES: 4 data PDFs (baryon ladder, kinematics, strong coupling, spectrum) +
3 inline TikZ (architecture, cage/matchings, color-complete plaquette) + 3 tables.

SCRIPTS (ssm_strong_scripts.zip, 14, all run; numpy, some scipy/matplotlib):
  su3_emergence, su3_weyl, su3_rank2, su3_anchor, su3_qec, gauge_geometry,
  gauge_z3code, gauge_nonabelian, nt_geometric, nt_qec, nt_anchor, nt_temporal,
  su3_strongcoupling, su3_plaquette_ed.

SCOPE attained: both sectors, color algebra (su(3) closes with time), well-posed
gauge theory, leading strong-coupling confinement (4/3 gap). OPEN/not claimed:
continuum confinement, running coupling, Lambda_QCD, full consistency of temporal
links with baryon/triality protection. Only physical input: Phys. Open 27 (2026)
100423; arXiv:2603.20294.
