#!/usr/bin/env python3
"""
su3_strongcoupling.py
---------------------
Backs the dynamical foothold: leading strong-coupling confinement on the
triangular FCC plaquettes.

(A) Area law: a side-L triangular Wilson loop in an FCC {111} plane (a 2D
    triangular lattice of FCC bonds) has minimal spanning area L^2 triangles
    and perimeter 3L bonds, so the leading strong-coupling term <W> ~ f^area
    decays with ENCLOSED AREA, not perimeter -- confinement at strong coupling.
(B) String-tension coefficient: the SU(3) fundamental character coefficient
    c_f(beta) = <conj(Tr U) exp(b/N Re Tr U)>_Haar / <exp(...)>_Haar -> beta/6
    at small beta (computed by Haar Monte Carlo, not recalled). The per-plaquette
    Wilson-loop factor f = c_f/N -> beta/18, so sigma a^2 = -ln f -> ln(18/beta).
    At large beta (~6, the coarse-grained regime) the expansion breaks down: the
    weak-coupling/coarse-grained regime is NOT accessible this way.

Requires: numpy.  Run:  python3 su3_strongcoupling.py
"""
import numpy as np
print("(A) area law on triangular plaquettes:")
def count(L):
    up=sum(1 for i in range(L) for j in range(L-i)); dn=sum(1 for i in range(L) for j in range(L-1-i))
    return up+dn, 3*L
print(f"    {'L':>3} {'area(triangles)':>16} {'perimeter':>10} {'area/L^2':>9}")
for L in [1,2,4,8,16]:
    a,p=count(L); print(f"    {L:>3} {a:>16} {p:>10} {a/L**2:>9.2f}")
print("    -> area = L^2 (area law), perimeter = 3L.")

print("\n(B) SU(3) string-tension coefficient (Haar Monte Carlo):")
rng=np.random.default_rng(1)
def haar_su3(n):
    Z=(rng.standard_normal((n,3,3))+1j*rng.standard_normal((n,3,3)))/np.sqrt(2)
    out=np.empty_like(Z)
    for k in range(n):
        Q,R=np.linalg.qr(Z[k]); ph=np.diagonal(R)/np.abs(np.diagonal(R)); out[k]=(Q*ph.conj())/(np.linalg.det(Q*ph.conj()))**(1/3)
    return out
N=3; U=haar_su3(300000); tr=np.trace(U,axis1=1,axis2=2); ReTr=tr.real
print(f"    {'beta':>5} {'c_f(MC)':>9} {'beta/6':>7} {'f=c_f/N':>8} {'sigma=-ln f':>11} {'ln(18/b)':>9}")
for b in [0.25,0.5,1.0,2.0,4.0,6.0]:
    w=np.exp((b/N)*ReTr); cf=(np.mean(np.conj(tr)*w).real)/np.mean(w); f=cf/N
    sig=-np.log(f) if f>0 else float('nan')
    print(f"    {b:>5.2f} {cf:>9.4f} {b/6:>7.4f} {f:>8.4f} {sig:>11.4f} {np.log(18/b):>9.4f}")
print("    small beta: c_f->beta/6, sigma a^2->ln(18/beta) (positive tension).")
print("    large beta (~6): f>1, sigma<0 -- expansion breaks down; coarse-grained regime NOT reached.")
