"""
Two-step path enumeration for the trapped-node defect (alpha paper, Sec. window).
Fixes ONE counting rule in advance and computes BOTH numbers (external, internal)
under that same rule. Reports every rule in the grid and flags any giving (1836, 16).

Geometry: FCC nodes = even-parity points of Z^3 (cubic side 2, bond length sqrt2).
Tetrahedral void with corners A=(0,0,0), B=(1,1,0), C=(1,0,1), D=(0,1,1); trapped
node T at the centroid, bonded to A..D by four spokes.
"""
import itertools, math
from collections import defaultdict

R = 6
NN = [v for v in itertools.product((-1,0,1),repeat=3) if sum(abs(c) for c in v)==2]
assert len(NN)==12
nodes = {p for p in itertools.product(range(-R,R+1),repeat=3) if sum(p)%2==0}
A,B,C,D = (0,0,0),(1,1,0),(1,0,1),(0,1,1)
T = 'T'
V4 = [A,B,C,D]
DEF_V = set(V4)|{T}

def fcc_nbrs(p):
    return [tuple(p[i]+d[i] for i in range(3)) for d in NN]

def build_adj(with_spokes):
    adj = defaultdict(list)
    for p in nodes:
        for q in fcc_nbrs(p):
            if q in nodes: adj[p].append(q)
    if with_spokes:
        for v in V4:
            adj[v].append(T); adj[T].append(v)
    return adj

K4 = {frozenset(e) for e in itertools.combinations(V4,2)}
SPOKES = {frozenset((v,T)) for v in V4}
# sanity: K4 edges are FCC bonds
for e in K4:
    a,b = tuple(e); assert tuple(b[i]-a[i] for i in range(3)) in NN

def walks(adj, s, backtrack=True):
    for x in adj[s]:
        for y in adj[x]:
            if not backtrack and y == s: continue
            yield (s,x,y)

def classify(w, def_edges):
    e1, e2 = frozenset(w[:2]), frozenset(w[1:])
    return 'int' if (e1 in def_edges and e2 in def_edges) else 'ext'

EDGESETS = {'K4': K4, 'spokes': SPOKES, 'K4+spokes': K4|SPOKES}
SOURCES = {
    '4 vertices':                 {v:1 for v in V4},
    '4 vertices + T':             {**{v:1 for v in V4}, T:1},
    '12 corner ends (x3)':        {v:3 for v in V4},
    '12 corner ends + T (paper)': {**{v:3 for v in V4}, T:1},
    'T only':                     {T:1},
}

lb = 386.15927  # reduced electron Compton wavelength, fm
rows=[]
for spokes_in_graph in (True, False):
    adj = build_adj(spokes_in_graph)
    for bt in (True, False):
        for sname, mult in SOURCES.items():
            if T in mult and not spokes_in_graph: continue
            for ename, eset in EDGESETS.items():
                if not spokes_in_graph and 'spokes' in ename: continue
                ext = intl = 0
                for s,m in mult.items():
                    for w in walks(adj, s, bt):
                        if classify(w, eset)=='int': intl += m
                        else: ext += m
                rows.append((spokes_in_graph, bt, sname, ename, ext, intl))

# per-source breakdown for the paper's pieces
adj = build_adj(True)
print("Per-source two-step walk counts (spokes in graph, backtracking allowed):")
for s,label in [(A,'bounding vertex'),(T,'trapped node')]:
    tot = sum(1 for _ in walks(adj,s))
    br = {k: sum(1 for w in walks(adj,s) if classify(w,e)=='int') for k,e in EDGESETS.items()}
    print(f"  {label:16s} deg={len(adj[s]):2d} total={tot:4d} internal by edge set: {br}")
adj0 = build_adj(False)
print(f"  FCC node without spokes: total={sum(1 for _ in walks(adj0,A))} (K^2=144)")
print()
print(f"{'spokes':6s} {'backtr':6s} {'sources':28s} {'defect edges':11s} {'ext':>6s} {'int':>5s} "
      f"{'Lc(fm)':>7s} {'1/alpha':>8s}  flag")
for sp,bt,sn,en,ext,intl in rows:
    Lc = intl*lb/(4*ext) if ext else float('nan')
    ai = 4*math.pi*math.sqrt(ext/intl) if intl else float('nan')
    flag = ('<== 1836 & 16' if (ext,intl)==(1836,16) else
            ('ext=1836' if ext==1836 else ('int=16' if intl==16 else '')))
    print(f"{str(sp):6s} {str(bt):6s} {sn:28s} {en:11s} {ext:6d} {intl:5d} {Lc:7.4f} {ai:8.2f}  {flag}")

print()
# The paper's actual combination (mixed rules)
ext_paper = 13*144 - 36
print("Paper's combination: ext = 13*144 - 36 =", ext_paper,
      "(12 corner ends + T at 144 each, no spokes; minus K4-only internal walks from 4 vertices counted once)")
print("                     int = 16 (walks from T only, K4+spokes)")
