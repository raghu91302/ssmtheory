# Wider search: more classification rules and counting objects; flags anything with
# ext=1836, int=16, or ratio ext/int = 1836/16 = 114.75 (the only thing that fixes Lc).
exec(open('alpha_two_step_enum.py').read().split("lb = 386.15927")[0])
import math
def cls_edges(w,e): return classify(w,e)
def cls_endpoint(w,e): return 'int' if w[2] in DEF_V else 'ext'
def cls_allverts(w,e): return 'int' if all(x in DEF_V for x in w) else 'ext'
CLS = {'both edges in defect':cls_edges,'endpoint in defect':cls_endpoint,'all 3 sites in defect':cls_allverts}
hits=[]; n=0
for sp in (True,False):
    adj=build_adj(sp)
    for bt in (True,False):
        for obj in ('ordered walks','distinct endpoints'):
            for sname,mult in SOURCES.items():
                if T in mult and not sp: continue
                for ename,eset in EDGESETS.items():
                    if not sp and 'spokes' in ename: continue
                    for cname,cf in CLS.items():
                        ext=intl=0
                        for s,m in mult.items():
                            ws=list(walks(adj,s,bt))
                            if obj=='distinct endpoints':
                                seen={}
                                for w in ws: seen.setdefault(w[2],cf(w,eset))
                                vals=list(seen.values())
                            else: vals=[cf(w,eset) for w in ws]
                            intl+=m*vals.count('int'); ext+=m*vals.count('ext')
                        n+=1
                        r = ext/intl if intl else float('inf')
                        if ext==1836 or intl==16 or abs(r-114.75)<1.5:
                            hits.append((sp,bt,obj,sname,ename,cname,ext,intl,r))
print("rules tested:",n)
for h in hits: print(h)
print("any rule with ext/int within 1.3% of 114.75:", any(abs(h[-1]-114.75)<1.5 for h in hits))

# Summary statistics quoted in the paper (Sec. window, App. lifts)
allr=[]
for sp in (True,False):
    adj=build_adj(sp)
    for bt in (True,False):
        for obj in ('ordered walks','distinct endpoints'):
            for sname,mult in SOURCES.items():
                if T in mult and not sp: continue
                for ename,eset in EDGESETS.items():
                    if not sp and 'spokes' in ename: continue
                    for cname,cf in CLS.items():
                        ext=intl=0
                        for s,m in mult.items():
                            ws=list(walks(adj,s,bt))
                            if obj=='distinct endpoints':
                                seen={}
                                for w in ws: seen.setdefault(w[2],cf(w,eset))
                                vals=list(seen.values())
                            else: vals=[cf(w,eset) for w in ws]
                            intl+=m*vals.count('int'); ext+=m*vals.count('ext')
                        allr.append((obj,ext,intl))
print("\nsummary: rules =",len(allr))
print("  max external count             :", max(e for _,e,_ in allr))
print("  any (1836,16)                  :", any((e,i)==(1836,16) for _,e,i in allr))
print("  any ratio within 1% of 114.75  :", any(i>0 and abs(e/i-114.75)/114.75<0.01 for _,e,i in allr))
print("  max ratio, ordered walks       :", max(e/i for o,e,i in allr if o=='ordered walks' and i>0))
print("  rules with internal count 0    :", sum(1 for _,_,i in allr if i==0))
print("  rules with ratio > 49 have int :", sorted({i for o,e,i in allr if i>0 and e/i>49}))
