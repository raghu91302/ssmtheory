"""One-loop leptonic (exact, spacelike) plus parametrized hadronic running (Jegerlehner, hep-ph/9606484)
at hbar c/Lc, hbar c/a, pi hbar c/a for Lc = r_p = 0.8409 fm, a = Lc/sqrt2."""
import numpy as np
from scipy.integrate import quad
a0=1/137.035999
c1,c2,c3,c4,l1,s0=2.2694240e-3,8.073429,0.1636393,-3.35455e-5,9.3055e-3,-4.0
had=lambda s: c1*(np.log(abs(1-c2*s))+c2*c3*s/(c3-s))-l1*c3*s/(c3-s)+c4*(s/s0)**2
def lep(Q2):
    return sum(2*a0/np.pi*quad(lambda x:x*(1-x)*np.log(1+Q2*x*(1-x)/m**2),0,1)[0] for m in (0.51099895e-3,0.1056584,1.77686))
for Q in (0.2346,0.3319,1.0428,1.0):
    Q2=Q*Q; h=had(-Q2); l=lep(Q2)
    print(f"Q={Q:.4f} lep={l:.5f} had={h:.5f} 1/alpha={(1-l-h)/a0:.2f}")
