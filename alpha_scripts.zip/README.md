# Scripts for "The fine-structure constant in the FCC vacuum code"

Every computation in the paper is reproduced by the scripts below (Appendix F of the paper).
Requirements: Python 3, numpy, scipy, matplotlib; numba for the compiled projector Monte Carlo.

| Script | Reproduces |
|---|---|
| alpha_run.py | Two-loop Standard Model running to the fine-code scale (Sec. 5, App. A) |
| alpha_running_lowQ.py | One-loop leptonic and parametrized hadronic running at ħc/L_c, ħc/a, πħc/a (Sec. 5) |
| alpha_cost_ratios.py | Verification-cost ratios (Sec. 6.1) |
| alpha_liftB_gfmc.py, alpha_liftB_gfmc_fast.py | Projector Monte Carlo of the photon sector (Prop. 3, Sec. 8.7) |
| alpha_liftB_ed.py, alpha_liftB_ed_common.py | Exact diagonalization at L=2 (Prop. 3) |
| alpha_liftB_ice.py | Charge-free ensemble for the level bound (App. C) |
| alpha_liftA_liftB.py | Bloch dispersion of the two U(1) lifts (Prop. 2, App. E) |
| alpha_dual_moves.py, alpha_dual_spectrum.py, alpha_logical_vs_photon.py | Lift A moves, invariants, spectrum; counting identities (App. E) |
| alpha_ice_quartet.py | Cube-edge-constrained ensemble (App. E) |
| alpha_elastic_projection.py | Phonon projection onto the ⟨100⟩ links (Sec. 6.3) |
| alpha_ring_exchange.py | Ring exchange on the ⟨100⟩ lattice (App. B) |
| alpha_gaussian_levels.py, alpha_calibrate_diamond.py | Gaussian estimate and its calibration (App. C) |
| alpha_tick_floquet.py | Exact Floquet Hamiltonian of the tick unitary (Sec. 8.4) |
| alpha_current_operator.py | Flux current of the phase term and transfer per tick (Sec. 8.5) |
| alpha_two_step_enum.py | Two-step walk counts on the trapped-node defect (Sec. 8.9, App. E) |
| alpha_two_step_enum_wide.py | 204-rule consistency search for the two defect costs (Sec. 8.9, App. E); run from the same folder as alpha_two_step_enum.py |
| alpha_monopole.py | Lattice monopole self-energy (Sec. 8.10) |
| alpha_figures.py | Figs. 4 and 5 |
| alpha_figures_relation.py | Figs. 1, 2 and 3 |
