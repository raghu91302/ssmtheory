"""Regenerates fig_alpha_Lc, fig_defect_bonds and fig_chain for alpha_ssm.tex."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.size":9,"mathtext.fontset":"cm"})
lb=386.15927; rp=0.8409
def save(fig,name):
    fig.savefig(name+".pdf",bbox_inches="tight"); fig.savefig(name+".eps",bbox_inches="tight"); plt.close(fig)

# ---- Fig 1: relation alpha^-1 = 2 pi sqrt(lb/Lc)
fig,ax=plt.subplots(figsize=(4.6,3.3))
L=np.linspace(0.68,1.06,400)
ax.axvspan(0.80,0.96,color="0.88",zorder=0,label=r"mechanical window for $L_c$")
ax.axhspan(135.4,135.8,color="#9ecae1",alpha=0.8,zorder=1,label=r"$\alpha^{-1}(\hbar c/L_c)=135.6\pm0.2$")
ax.axhline(134.74,color="#3182bd",ls=":",lw=1.2,zorder=1,label=r"$\alpha^{-1}(\pi\hbar c/a)=134.7$")
ax.axvline(rp,color="#de2d26",ls="--",lw=1.3,zorder=5,label=r"$r_p=0.8409$ fm")
ax.plot(L,2*np.pi*np.sqrt(lb/L),"k",lw=1.6,zorder=3,label=r"$\alpha^{-1}=2\pi\sqrt{\bar\lambda_e/L_c}$")
Lc=4*lb/1836; ax.plot([Lc],[2*np.pi*np.sqrt(lb/Lc)],"o",color="k",ms=7,mec="white",mew=1.2,zorder=6,
    label=r"under (P6): $L_c=4\bar\lambda_e/1836$, $\alpha^{-1}=\pi\sqrt{m_p/m_e}$")
ax.set_xlim(0.68,1.06); ax.set_ylim(118,142); ax.set_xlabel(r"$L_c$ (fm)"); ax.set_ylabel(r"$\alpha^{-1}$")
ax.legend(fontsize=6.4,loc="lower left",framealpha=0.95); ax.grid(alpha=0.3)
save(fig,"fig_alpha_Lc")

# ---- Fig: defect graph K5
A=np.array([0,0,0.]);B=np.array([1,1,0.]);C=np.array([1,0,1.]);D=np.array([0,1,1.]);T=(A+B+C+D)/4
V={"A":A,"B":B,"C":C,"D":D}
# oblique projection
def P(x): 
    R=np.array([[-0.791,0.553,0.261],[-0.612,-0.715,-0.337]]); return R@x
fig,ax=plt.subplots(figsize=(4.4,3.6))
import itertools
for a,b in itertools.combinations("ABCD",2):
    p,q=P(V[a]),P(V[b]); ax.plot([p[0],q[0]],[p[1],q[1]],color="0.4",lw=1.6,zorder=1)
for a in "ABCD":
    p,q=P(V[a]),P(T); ax.plot([p[0],q[0]],[p[1],q[1]],color="#e6550d",lw=1.8,zorder=2)
    # bond-end markers at the vertex: 3 edges + 1 spoke
    for b in [x for x in "ABCD" if x!=a]+["T"]:
        tgt=T if b=="T" else V[b]; m=P(V[a]+0.13*(tgt-V[a]))
        ax.plot(*m,"o",ms=3.5,color="#d62728" if b!="T" else "#fd8d3c",zorder=3)
for a in "ABCD":
    p=P(V[a]); ax.plot(*p,"o",ms=11,color="#3182bd",zorder=4); u=(p-P(T))/np.linalg.norm(p-P(T)); ax.text(p[0]+0.12*u[0],p[1]+0.12*u[1],a,fontsize=11,weight="bold",color="#08306b",ha="center",va="center")
pt=P(T); ax.plot(*pt,"*",ms=16,color="#fdd835",mec="#b8860b",zorder=5); ax.text(pt[0]+0.05,pt[1]+0.07,"trapped node",fontsize=8)
ax.set_aspect("equal"); ax.axis("off")
txt=("6 tetrahedron edges (grey) + 4 spokes (orange) = 10 bonds on 5 nodes: the complete graph $K_5$\n"
     "four-regular: from any node, $4^2=16$ two-step walks inside the defect\n"
     "equivalently, committed bond-ends at the four vertices (markers): $4\\times(3+1)=16$")
fig.subplots_adjust(bottom=0.2); fig.text(0.03,0.13,txt,fontsize=7.2,va="top")
save(fig,"fig_defect_bonds")

# ---- Fig: chain
fig,ax=plt.subplots(figsize=(8.4,7.6)); ax.set_xlim(0,10.6); ax.set_ylim(0,10.4); ax.axis("off")
col={"y":("#fff3c4","#c9a227"),"g":("#e5f5e0","#31a354"),"b":("#deebf7","#3182bd"),"r":("#fde0dd","#c0392b")}
def box(x,y,w,h,c,t,fs=7.6):
    f,e=col[c]; ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle="round,pad=0.02,rounding_size=0.12",fc=f,ec=e,lw=1.1))
    ax.text(x,y,t,ha="center",va="center",fontsize=fs,linespacing=1.35)
def arr(x1,y1,x2,y2): ax.annotate("",xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle="-|>",lw=1,color="k"))
box(5,9.8,8.4,0.75,"y","Postulates (P1)–(P5): FCC lattice, $K=12$, $K/d=4$; tick $\\tau=4L/c$; $\\epsilon_b$ per standing bit;\npricing of standing and transient terms; two metric realizations")
box(2.5,8.5,4.7,0.85,"g","Photon sector: $U(1)$ rotor on node–void half-links\n$H=-J\\sum\\cos B_b+\\frac{U}{2}\\sum(\\mathrm{curl}\\,m)^2$,  $\\alpha=\\sqrt{U/J}/4\\pi$")
box(7.6,8.5,4.7,0.85,"y","Rule (P6): the defect's kinematic cost is\none node's two-step reach in its $K_5$ graph")
box(2.5,7.1,4.7,0.85,"y","Rules (R$_U$), (R$_J$): priced unit of flux is one bond;\n(P2) bounds the flux a bond transmits per tick")
box(2.5,5.75,4.7,0.8,"g","Coefficients: $U=\\epsilon_b=m_ec^2$, $J=E_{\\rm bond}=\\hbar c/4L$")
box(7.6,7.1,4.7,0.85,"g","Two costs of the trapped-node defect:\n$m_pc^2=1836\\,\\epsilon_b$ (Refs.),  $m_pc^2=16\\,E_{\\rm bond}$")
box(2.5,4.4,4.7,0.8,"g","Relation at the confinement scale:\n$\\alpha^{-1}=2\\pi\\sqrt{\\bar\\lambda_e/L_c}$")
box(7.6,5.75,4.7,0.8,"g","Stability window: $1836\\,\\epsilon_b=16\\,E_{\\rm bond}$\n$L_c=4\\bar\\lambda_e/1836=0.8413$ fm")
box(4.6,3.05,6.4,0.8,"b","Outputs: $L_c=0.8413$ fm;  $\\alpha^{-1}=\\pi\\sqrt{m_p/m_e}=134.6$\nat the confinement scale")
box(4.6,1.85,6.4,0.8,"b","Measured: $r_p=0.8409$ fm;  running $\\alpha^{-1}=135.6$ at $\\hbar c/L_c$,\n$134.7$ at the zone edge $\\pi\\hbar c/a$")
box(4.6,0.6,6.4,0.75,"r","Standard Model running (leptonic + hadronic) to zero momentum:\n$\\alpha(0)^{-1}=137.036$")
arr(2.5,9.45,2.6,8.93); arr(7.6,9.45,7.5,8.93)
arr(2.5,8.07,2.6,7.53); arr(2.5,6.67,2.6,6.15); arr(2.5,5.35,2.6,4.8)
arr(7.6,8.07,7.5,7.53); arr(7.6,6.67,7.5,6.15)
arr(2.5,4.0,3.6,3.45); arr(7.6,5.35,5.8,3.45)
arr(4.6,2.65,4.6,2.25); arr(4.6,1.45,4.6,0.98)
box(9.55,1.85,1.9,2.6,"r","Not derived:\nthe postulates;\nrotor premise (A3);\ntwo-code\nreading (A1)–(A2);\nmatching map;\nmatching scale",fs=6.6)
save(fig,"fig_chain")
print("figures written")
