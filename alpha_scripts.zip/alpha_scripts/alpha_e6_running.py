"""One-loop SM running of the three gauge couplings between M_Z and the Planck scale,
with GUT normalization for U(1)_Y (alpha_1 = (5/3) alpha_Y), and the test: does imposing
alpha_1 = alpha_2 = alpha_3 (trinification/E6) at M_P reproduce the measured couplings?"""
import numpy as np
MZ=91.1876; MP=1.220890e19; LP_lattice=MP/1.843   # cutoff hbar c / L_f with L_f = 1.843 l_P
# measured at M_Z (PDG): alpha^-1 = 127.95, sin^2 = 0.23122, alpha_s = 0.1180
a_em_inv=127.951; s2=0.23122; a3=0.1180
a1_inv=(3/5)*a_em_inv*(1-s2)      # alpha_1^-1 = (3/5) alpha_Y^-1 ; alpha_Y^-1 = alpha^-1 (1-s2)... careful
# alpha_Y = alpha/(1-s2) -> alpha_Y^-1 = alpha^-1 (1-s2); alpha_1 = (5/3) alpha_Y -> alpha_1^-1 = (3/5) alpha^-1 (1-s2)
a2_inv=a_em_inv*s2
a3_inv=1/a3
b=np.array([41/10, -19/6, -7.0])   # SM one-loop, GUT-normalized
def run(ainv, mu):
    t=np.log(mu/MZ)/(2*np.pi); return ainv - b*t
print("at M_Z: alpha_1^-1, alpha_2^-1, alpha_3^-1 =", np.round([a1_inv,a2_inv,a3_inv],2))
for mu,name in [(1e15,'1e15 GeV'),(1e16,'1e16 GeV'),(MP,'M_Planck'),(LP_lattice,'hbar c/L_f')]:
    print(f"at {name:10s}: {np.round(run(np.array([a1_inv,a2_inv,a3_inv]),mu),1)}")
# prediction: impose unification at M_P with alpha_3 as the single input
aU_inv = a3_inv - b[2]*np.log(MP/MZ)/(2*np.pi)
a1_pred = aU_inv + b[0]*np.log(MP/MZ)/(2*np.pi); a2_pred = aU_inv + b[1]*np.log(MP/MZ)/(2*np.pi)
aY_inv = (5/3)*a1_pred   # alpha_Y^-1 = (5/3) alpha_1^-1
aem_inv = aY_inv + a2_pred  # alpha^-1 = alpha_Y^-1 + alpha_2^-1
s2_pred = a2_pred/aem_inv
print(f"\nE6 at M_P with alpha_s(M_Z) input: alpha_U^-1 = {aU_inv:.1f}; predicted alpha^-1(M_Z) = {aem_inv:.1f} (meas 127.95), sin^2 = {s2_pred:.3f} (meas 0.2312)")
# and the same with alpha_em as the input, predicting alpha_s and sin^2 (two unknowns, need both a1=a2 and a3=a1: overdetermined) -> use alpha_em and alpha_s to predict sin^2 only
# classic: sin^2(M_Z) from unification: solve a1=a2 at M_P given alpha_em: alpha_1^-1 = alpha_2^-1 + (b1-b2) t
t=np.log(MP/MZ)/(2*np.pi)
# a1_inv = (3/5)(1-s2) aem_inv ; a2_inv = s2 aem_inv ; a1_inv - a2_inv = (b1-b2) t
s2_from_12 = ((3/5) - (b[0]-b[1])*t/a_em_inv)/((3/5)+1)
print(f"a1=a2 at M_P with alpha_em input: sin^2(M_Z) = {s2_from_12:.3f}")
