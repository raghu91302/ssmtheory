# Scripts for "The fine-structure constant as a confinement-length ratio"

All scripts run with `numpy`/`scipy` (and `matplotlib` for the figure) in under a minute.

| script | paper section | what it computes |
|---|---|---|
| `alpha_run.py` | Sec. 5, App. A | Two-loop SM running of alpha_em to the fine-code cutoff; one-loop leptonic + hadronic estimate at the confinement scale |
| `alpha_cost_ratios.py` | Sec. 6.1 | Verification-cost (E_s x C_s) of Gauss-law charges and plaquette flux on the <100> sector; shows count ratios give a confining phase |
| `alpha_ice_quartet.py` | Sec. 6.2, Prop. 3 | Annealed Metropolis sampling of the charge-free ensemble; quartet correlation of the four bonds a link serves |
| `alpha_elastic_projection.py` | Sec. 6.3 | Projection of FCC phonons onto <100> link one-forms; shows no Maxwell sector and Zener anisotropy |
| `alpha_ring_exchange.py` | Sec. 7, App. B | Exact second-order ring exchange J = 2 t^2 / V on the <100> lattice |
| `alpha_gaussian_levels.py` | App. C | Self-consistent harmonic estimate of the coupling vs link level count |
| `alpha_calibrate_diamond.py` | App. C | Same estimator on the diamond lattice (quantum spin ice) for calibration; tests the served-qubit candidate |
| `alpha_figure.py` | Fig. 1 | Generates fig_alpha_Lc.pdf |

Note: `alpha_gaussian_levels.py` and `alpha_ice_quartet.py` were written against the fine-code target 104.9; the paper's Section 6.2 and Appendix C quote the numbers rescaled to the confinement-scale target 135.5 (needed <E^2> = 3.2, c = +0.7). Edit the `target` variable to reproduce either.
