# Scripts for "An embedded confinement structure in the FCC vacuum code: impedance matching and the proton radius"

Runtimes: the structural, running, enumeration, Gaussian and Floquet scripts take seconds to a minute (numpy/scipy; matplotlib for the figures). Exact diagonalization takes minutes (spin-1). The projector Monte Carlo takes minutes at L=4 and hours per seed at L>=6; `alpha_liftB_gfmc_fast.py` needs numba. `alpha_two_step_enum_wide.py` exec's `alpha_two_step_enum.py` and `alpha_matching_scale.py` exec's `alpha_running_lowQ.py`, so keep each pair in one directory.

| script | paper section | what it computes |
|---|---|---|
| `alpha_run.py` | Sec. 5, App. A | Two-loop SM running of alpha_em to the Planck-scale cutoff; one-loop leptonic + hadronic estimate at the confinement scale |
| `alpha_running_lowQ.py` | Sec. 5 | One-loop leptonic and Jegerlehner hadronic running at hbar c/L_c, pi hbar c/L_c and 3.4 hbar c/a; alpha^-1(hbar c/L_c) = 135.6 +/- 0.2 |
| `alpha_matching_scale.py` | Sec. 5, Eq. (5) | Brodsky-Lepage-Mackenzie matching momentum on the rotor's Hamiltonian propagator: q* a = 2.46, q* = 0.82 GeV, alpha^-1(q*) = 134.8 +/- 0.2 |
| `alpha_cost_ratios.py` | Sec. 6.1 | Verification cost (E_s x C_s) of Gauss-law charges and plaquette flux; count ratios give a confining phase |
| `alpha_ice_quartet.py` | Sec. 6.2, Prop. 3 | Annealed Metropolis sampling of the charge-free ensemble; quartet correlation of the four bonds a link serves |
| `alpha_liftB_ice.py` | Sec. 6.2, App. C | The photon's charge-free ensemble (tetrahedral-void divergence) with Z_M bond fluxes; served-quartet fluctuation |
| `alpha_liftA_liftB.py` | Sec. 6.2, App. E | Bloch dispersion of the two U(1) lifts on the bonds: cube-edge (not Maxwell) vs tetrahedral divergence (Maxwell) |
| `alpha_liftB_ed.py` (+ `alpha_liftB_ed_common.py`) | Sec. 6.2 | Exact diagonalization of the photon sector at L=2 (spin-1/2 and spin-1) with electric and magnetic twists; run `python3 alpha_liftB_ed.py half` and `... one` |
| `alpha_liftB_gfmc.py` | Sec. 6.2 | Projector Monte Carlo for lift B (spin-S quantum link model); forward-walked transverse structure factor gives sqrt(J/U) and alpha^-1 with no calibration |
| `alpha_liftB_gfmc_fast.py` | Sec. 8.7 | numba-compiled, checkpointed projector MC with explicit charging energy (`--UJ`); the Kogut-Susskind check (L=4: alpha^-1 = 132-136 for U/J = 0.0086) |
| `alpha_elastic_projection.py` | Sec. 6.3 | Projection of FCC phonons onto <100> link one-forms; no Maxwell sector, Zener anisotropy |
| `alpha_ring_exchange.py` | Sec. 7, App. B | Exact second-order ring exchange J = 2 t^2 / V on the <100> lattice |
| `alpha_gaussian_levels.py` | App. C | Self-consistent harmonic estimate of the coupling vs link level count |
| `alpha_calibrate_diamond.py` | App. C | Same estimator on the diamond lattice (quantum spin ice) for calibration |
| `alpha_tick_floquet.py` | Sec. 8.2 | Exact Floquet Hamiltonian of the tick unitary (single bond and served quartet); U_eff/J_eff vs input |
| `alpha_current_operator.py` | Sec. 8.3 | Flux current of the phase term; exact transfer per tick; verifies j = 1 |
| `alpha_form_factor.py` | Sec. 8.6 | rms charge radius for the charge placements on the K5 defect (r_E = L_c for valence vertices); G_E = j_0(Q L_c) against the dipole, zero at Q^2 = 0.54 GeV^2 |
| `alpha_two_step_enum.py` | Sec. 8.9, App. E | Enumeration of the 204 two-step walk rules on K5 and the FCC shell: no rule gives both 1836 and 16 |
| `alpha_two_step_enum_wide.py` | Sec. 8.9, App. E | Wide enumeration (ordered walks, degenerate rules); maximum external/internal ratio 49 |
| `alpha_monopole.py` | Sec. 8.10 | Lattice monopole self-energy constant v(0) and the monopole mass on the inclusion |
| `alpha_dual_moves.py`, `alpha_dual_spectrum.py`, `alpha_logical_vs_photon.py` | App. E | Lift A's moves, invariants and spectrum, and the counting identities |
| `alpha_figures_relation.py` | Figs. 1-3 | Regenerates fig_alpha_Lc, fig_defect_bonds and fig_chain |
| `alpha_figures.py` | Figs. 4-5 | Regenerates fig_dispersions and fig_quantum |

Note: `alpha_gaussian_levels.py` and `alpha_ice_quartet.py` were written against the Planck-scale target 104.9; Section 6.2 and Appendix C quote the numbers rescaled to the confinement-scale target 135.5. Edit the `target` variable to reproduce either.
