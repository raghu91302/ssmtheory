"""One-loop (tadpole) renormalization of the compact rotor's coupling.

H = U/2 sum_links E^2 - J sum_plaq cos B.   Expanding cos B = 1 - B^2/2 + B^4/24 - ..., the quartic term
Wick-contracted gives J_eff = J (1 - <B^2>/2) + O(B^4), with <B^2> per plaquette in the Gaussian theory
= c sqrt(U/J), c = (1/(6N^3)) sum_{k,pol} lambda_k on the cubic link lattice (two transverse polarizations,
3 plaquettes per site, lambda_k^2 = 4 sum_i sin^2(k_i/2)).  Hence
   alpha_phys = sqrt(U/J_eff)/4pi = alpha_tree (1 + <B^2>/4 + ...)  =>  alpha_phys^-1 = alpha_tree^-1 - pi c + O(alpha).
Part 1 checks the formula on a single rotor against exact diagonalization.  Part 2 evaluates c and the shift.
"""
import numpy as np
from scipy.linalg import eigh_tridiagonal

# ---- Part 1: single rotor H = U/2 m^2 - J cos B, exact gap vs harmonic and tadpole ----
def gap(U, J, M=400):
    m = np.arange(-M, M+1); d = 0.5*U*m**2; e = -0.5*J*np.ones(2*M)
    w = eigh_tridiagonal(d, e, select='i', select_range=(0,1))[0]; return w[1]-w[0]
print("single rotor: omega_exact/sqrt(UJ)  vs tadpole 1 - sqrt(U/J)/8  (<B^2> = sqrt(U/J)/2 for one mode)")
for UJ in [0.1, 0.03, 0.0086, 0.002]:
    U, J = UJ, 1.0; w = gap(U, J)
    print(f"  U/J={UJ:7.4f}: exact {w/np.sqrt(U*J):.5f}   tadpole {1-np.sqrt(UJ)/8:.5f}   SCHA {np.exp(-np.sqrt(UJ)/8):.5f}")

# ---- Part 2: lattice constant c and the shift of alpha^-1 ----
def lattice_c(N):
    k = 2*np.pi*np.arange(N)/N
    kx, ky, kz = np.meshgrid(k, k, k, indexing='ij')
    lam = np.sqrt(4*(np.sin(kx/2)**2 + np.sin(ky/2)**2 + np.sin(kz/2)**2))
    return 2*lam.sum()/(6*N**3)
for N in [16, 32, 64, 128]:
    print(f"N={N:4d}: c = {lattice_c(N):.6f}")
c = lattice_c(128)
UJ = 0.0086
print(f"\nlattice: <B^2> = c sqrt(U/J) = {c*np.sqrt(UJ):.4f} at U/J = {UJ}")
print(f"one-loop shift of alpha^-1: -pi c = {-np.pi*c:.3f}   (exact in alpha at this order: independent of alpha)")
tree = 4*np.pi/np.sqrt(UJ); print(f"alpha^-1: tree {tree:.2f} -> one loop {tree-np.pi*c:.2f}; SCHA (resummed) {4*np.pi/np.sqrt(UJ/np.exp(-c*np.sqrt(UJ/np.exp(-c*np.sqrt(UJ)/2))/2)):.2f}")
# the relation with the correction: alpha^-1(q*) = 2 pi sqrt(lb/Lc) - pi c
lb = 386.159; rp = 0.84075; target = 134.8
print(f"\ncorrected relation: alpha^-1(q*) = 2 pi sqrt(lb/Lc) - pi c")
print(f"  with Lc = r_p: alpha^-1(q*) = {2*np.pi*np.sqrt(lb/rp) - np.pi*c:.2f}  (running coupling 134.8 +- 0.2)")
Lc = 4*np.pi**2*lb/(target + np.pi*c)**2
print(f"  with alpha^-1(q*) = 134.8: Lc = {Lc:.4f} fm  (r_p = 0.84075; tree level gave 0.8390)")
print(f"  under (P6), Lc = 0.8413 fixed: alpha^-1(q*) = pi sqrt(1836) - pi c = {np.pi*np.sqrt(1836) - np.pi*c:.2f}")
