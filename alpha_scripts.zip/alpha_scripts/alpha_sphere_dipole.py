"""Central dipole in a spherical inclusion: reflection and stored energy versus mismatch.

A dipole at the centre of a sphere of radius R filled with (eps_c, mu_c), impedance Z_c and
speed v_c, inside a host (eps_f, mu_f), Z_f, c. Only the l=1 electric partial wave is emitted.
Interior field = outgoing source wave + reflected regular wave (amplitude rho); exterior =
transmitted outgoing wave (amplitude t). Tangential E and H continuous at r=R.

Model scaling (Sec. 8): with s = L_c / L_c*, Z_c = Z_f sqrt(s), v_c = v* sqrt(s), the quantum
emitted has hbar*omega = E_bond = hbar c/(4 L_c), and R = 2 L_c (patch extent). Hence
  x_f = k_f R = omega R / c = 1/2                     (independent of s)
  x_c = k_c R = omega R / v_c = (c / 2 v*) / sqrt(s)   (= 30.3 at s = 1, v* = 0.0165 c)
The run reports |rho|^2, the interior stored energy of the reflected part relative to the
energy the source emits in one transit time R/v_c, and the escaping power fraction, for s in
[0.1, 10]; also the plane-wave Fresnel r^2 for comparison. Hypothesis-free: this is classical
electrodynamics of the inclusion, nothing about pricing.
"""
import numpy as np
from scipy.special import spherical_jn, spherical_yn

def psi(x):  return x * spherical_jn(1, x)                      # Riccati-Bessel, regular
def dpsi(x): return spherical_jn(1, x) + x * spherical_jn(1, x, derivative=True)
def xi(x):   return x * (spherical_jn(1, x) + 1j * spherical_yn(1, x))   # outgoing h1^(1)
def dxi(x):  return (spherical_jn(1, x) + 1j * spherical_yn(1, x)) + x * (spherical_jn(1, x, derivative=True) + 1j * spherical_yn(1, x, derivative=True))

def solve(xc, xf, Zc, Zf):
    """TM l=1: H_phi ~ f(kr)/r, E_theta ~ Z f'(kr)/r (derivative in the argument).
    interior: xi(kc r) + rho psi(kc r); exterior: t xi(kf r)."""
    A = np.array([[psi(xc), -xi(xf)],
                  [Zc * dpsi(xc), -Zf * dxi(xf)]], dtype=complex)
    b = np.array([-xi(xc), -Zc * dxi(xc)], dtype=complex)
    rho, t = np.linalg.solve(A, b)
    return rho, t

def interior_energy_ratio(xc, rho, n=4000):
    """Time-averaged energy of the reflected (regular) interior wave, in units of the energy the
    source wave carries through the sphere in one transit (power x R/v_c). Both computed from the
    same TM l=1 field expressions, so normalisations cancel. For the source wave the transit
    energy is P*R/v = (R/v) * (flux of xi through any sphere) ; for a unit-amplitude outgoing
    wave the radial flux factor is 1 and the transit energy integral is x_c (in these units)."""
    x = np.linspace(1e-4, xc, n)
    # reflected regular wave: |E|^2 ~ |psi'(x)|^2 + 2|psi(x)/x|^2 (radial part), |H|^2 ~ |psi(x)|^2
    # per unit solid-angle factor; energy density ~ (eps|E|^2 + mu|H|^2)/4 -> in units where
    # eps E^2 and mu H^2 are both measured by the Riccati functions (Z absorbed), the l=1 TM
    # energy integrand is |psi|^2 + |psi'|^2 + 2|psi/x|^2.
    w_refl = np.trapezoid(np.abs(psi(x))**2 + np.abs(dpsi(x))**2 + 2*np.abs(psi(x)/x)**2, x)
    return np.abs(rho)**2 * w_refl / xc

if __name__ == "__main__":
    vstar = 0.0165  # v_c/c at the matched spacing
    print(" s=Lc/Lc*   Zc/Zf     x_c    |rho|^2   stored/transit   escaping   Fresnel r^2")
    rows = []
    for s in [0.1, 0.2, 0.3, 0.5, 0.7, 0.85, 1.0, 1.2, 1.5, 2.0, 3.0, 5.0, 10.0]:
        Zc, Zf = np.sqrt(s), 1.0
        xc = (1.0 / (2 * vstar)) / np.sqrt(s)
        xf = 0.5
        rho, t = solve(xc, xf, Zc, Zf)
        # escaping power fraction: exterior outgoing flux over interior source outgoing flux.
        # For TM l=1 the radial Poynting flux of an outgoing unit wave is |amp|^2 / Z (H^2 Z), so
        # escaping = |t|^2 (Zc/Zf) ... with H normalised: P ~ Z |H|^2 -> P_out/P_src = |t|^2 Zf/Zc
        esc = np.abs(t)**2 * Zf / Zc
        fres = ((Zc - Zf) / (Zc + Zf))**2
        rows.append((s, Zc, xc, np.abs(rho)**2, interior_energy_ratio(xc, rho), esc, fres))
        print(f"{s:7.2f}  {Zc:7.3f}  {xc:7.2f}  {np.abs(rho)**2:8.4f}  {interior_energy_ratio(xc, rho):12.4f}  {esc:9.4f}  {fres:9.4f}")
    # fine scan for the minimum of stored energy
    ss = np.linspace(0.05, 10, 4000)
    st = []
    for s in ss:
        xc = (1.0 / (2 * vstar)) / np.sqrt(s); rho, t = solve(xc, 0.5, np.sqrt(s), 1.0)
        st.append(interior_energy_ratio(xc, rho, n=1500))
    st = np.array(st); i = st.argmin()
    print(f"\nminimum of stored/transit over s in [0.05,10]: s = {ss[i]:.3f}, value {st[i]:.4f}")
    rr = np.array([np.abs(solve((1/(2*vstar))/np.sqrt(s), 0.5, np.sqrt(s), 1.0)[0])**2 for s in ss])
    j = rr.argmin(); print(f"minimum of |rho|^2: s = {ss[j]:.3f}, value {rr[j]:.4f}")
