"""Path-integral Monte Carlo of the vacuum rotor with the stabilizer-product magnetic term.

H = (U/2) sum_links E_l^2 - w sum_checks prod_{b in c} cos B_b        (product form, w = |c| E_bond = 12)
H = (U/2) sum_links E_l^2 - J sum_bonds cos B_b                         (Kogut-Susskind form, J = 48)

Rotor phases theta_l on the node-void links of a periodic FCC box (side N cubes, grid of side 2N
with nodes on even-sum sites and octahedral voids on odd-sum sites, link length a = 1).  B_b is the
plaquette phase of bond b: the circulation node -> void1 -> node' -> void2 -> node.  Checks: the 12
bonds at each node and the 12 edges of each octahedral void; both act as phase products.

Euclidean action with M slices of eps = beta/M, temporal gauge, units E_bond = hbar = 1:
   S = sum_t [ sum_l (dtheta_l)^2 / (2 eps U)  -  eps * (magnetic term at slice t) ]
Observables: <B^2>, <prod cos> per check, and the imaginary-time correlator of the transverse
magnetic mode at the smallest momentum k = pi/N along x (plaquettes normal to z), from which
   omega(k) = sqrt( U J_eff lambda_k^2 ),  lambda_k^2 = 4 sin^2(k/2),
so J_eff = omega^2 / (U lambda_k^2) is the physical long-wavelength stiffness.  The light-speed
condition v = a sqrt(U J_eff) = c reads U J_eff = 32 (Appendix D), and the coupling at that point is
alpha^-1 = 4 pi sqrt(J_eff/U) = pi J_eff / sqrt2.

usage: python3 alpha_zeno_pimc.py --form prod|ks --U 0.7 --N 4 --beta 2.0 --M 80 --sweeps 20000
"""
import numpy as np, itertools, argparse, time, sys
from numba import njit

def build(N):
    G = 2*N
    def wrap(p): return tuple(x % G for x in p)
    nodes = [p for p in itertools.product(range(G), repeat=3) if sum(p) % 2 == 0]
    voids = [p for p in itertools.product(range(G), repeat=3) if sum(p) % 2 == 1]
    nid = {p:i for i,p in enumerate(nodes)}; vid = {p:i for i,p in enumerate(voids)}
    units = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
    links = {}; link_list = []
    for p in nodes:
        for e in units:
            v = wrap(tuple(p[i]+e[i] for i in range(3)))
            links[(nid[p], vid[v])] = len(link_list); link_list.append((nid[p], vid[v]))
    # bonds: p -> p + d, d = e1 + e2 (positive set), plaquette p, v1=p+e1, q, v2=p+e2
    dirs = [((1,0,0),(0,1,0)),((1,0,0),(0,-1,0)),((1,0,0),(0,0,1)),((1,0,0),(0,0,-1)),((0,1,0),(0,0,1)),((0,1,0),(0,0,-1))]
    bonds = []; bond_links = []; bond_signs = []; bond_key = {}; bond_dir = []; bond_x = []
    for p in nodes:
        for (e1,e2) in dirs:
            q = wrap(tuple(p[i]+e1[i]+e2[i] for i in range(3)))
            v1 = wrap(tuple(p[i]+e1[i] for i in range(3))); v2 = wrap(tuple(p[i]+e2[i] for i in range(3)))
            key = frozenset((nid[p], nid[q]))
            if key in bond_key: continue
            bond_key[key] = len(bonds); bonds.append((nid[p], nid[q]))
            # B = th(p,v1) - th(q,v1) + th(q,v2) - th(p,v2)
            bond_links.append([links[(nid[p],vid[v1])], links[(nid[q],vid[v1])], links[(nid[q],vid[v2])], links[(nid[p],vid[v2])]])
            bond_signs.append([1,-1,1,-1]); bond_dir.append((e1,e2)); bond_x.append(p[0] + 0.5*(e1[0]+e2[0]))
    nb = len(bonds)
    # checks
    checks = []
    for p in nodes:
        cb = []
        for d in [v for v in itertools.product((-1,0,1),repeat=3) if sum(abs(x) for x in v)==2]:
            q = wrap(tuple(p[i]+d[i] for i in range(3))); cb.append(bond_key[frozenset((nid[p],nid[q]))])
        assert len(set(cb)) == 12; checks.append(cb)
    for v in voids:
        corners = [wrap(tuple(v[i]+e[i] for i in range(3))) for e in units]
        cb = [bond_key[frozenset((nid[a],nid[b]))] for a,b in itertools.combinations(corners,2) if frozenset((nid[a],nid[b])) in bond_key]
        assert len(cb) == 12, len(cb); checks.append(cb)
    nc = len(checks)
    # link -> (bond, sign) served
    link_bonds = [[] for _ in link_list]
    for b in range(nb):
        for l,s in zip(bond_links[b], bond_signs[b]): link_bonds[l].append((b,s))
    assert all(len(x)==4 for x in link_bonds)
    bond_checks = [[] for _ in range(nb)]
    for c,cb in enumerate(checks):
        for b in cb: bond_checks[b].append(c)
    assert all(len(x)==4 for x in bond_checks)
    # transverse mode: plaquettes normal to z, i.e. dirs (x,y): sign +1 for (x,+y), -1 for (x,-y)
    # plaquette normal n = e1 x e2 (axis and sign), centre coordinates
    bnorm = np.zeros(nb, dtype=np.int64); bsgn = np.zeros(nb); bctr = np.zeros((nb,3))
    for b in range(nb):
        e1,e2 = bond_dir[b]; n = np.cross(e1,e2); ax = int(np.argmax(np.abs(n)))
        bnorm[b] = ax; bsgn[b] = float(np.sign(n[ax]))
        p = nodes[bonds[b][0]]; bctr[b] = [p[i] + 0.5*(e1[i]+e2[i]) for i in range(3)]
    A = lambda x,dt=np.int64: np.array(x, dtype=dt)
    return dict(nl=len(link_list), nb=nb, nc=nc, bond_links=A(bond_links), bond_signs=A(bond_signs, np.float64),
                link_bonds=A([[b for b,s in x] for x in link_bonds]), link_bsign=A([[s for b,s in x] for x in link_bonds], np.float64),
                checks=A(checks), bond_checks=A(bond_checks), bnorm=bnorm, bsgn=bsgn, bctr=bctr)

@njit(cache=True)
def plaq(theta, t, b, bond_links, bond_signs):
    B = 0.0
    for i in range(4): B += bond_signs[b,i]*theta[t, bond_links[b,i]]
    return B

@njit(cache=True)
def init_state(theta, bond_links, bond_signs, checks, M):
    nb = bond_links.shape[0]; nc = checks.shape[0]
    cosB = np.empty((M, nb)); prod = np.empty((M, nc)); Bv = np.empty((M, nb))
    for t in range(M):
        for b in range(nb):
            Bv[t,b] = plaq(theta, t, b, bond_links, bond_signs); cosB[t,b] = np.cos(Bv[t,b])
        for c in range(nc):
            p = 1.0
            for j in range(12): p *= cosB[t, checks[c,j]]
            prod[t,c] = p
    return Bv, cosB, prod

@njit(cache=True)
def sweep(theta, Bv, cosB, prod, epsU, epsw, epsJ, form, delta, link_bonds, link_bsign, bond_checks, checks, rng_u, rng_d, rng_l, rng_t):
    M, nl = theta.shape
    acc = 0
    newB = np.empty(4); newc = np.empty(4); affc = np.empty(16, dtype=np.int64); newp = np.empty(16)
    for n in range(rng_u.shape[0]):
        l = rng_l[n]; t = rng_t[n]; d = rng_d[n]*delta
        th = theta[t,l]; thn = th + d
        tp = t+1 if t+1 < M else 0; tm = t-1 if t > 0 else M-1
        def wr(x):
            return x
        a1 = thn-theta[tp,l]; a1 = a1 - 2*np.pi*np.round(a1/(2*np.pi))
        a0 = th -theta[tp,l]; a0 = a0 - 2*np.pi*np.round(a0/(2*np.pi))
        b1 = thn-theta[tm,l]; b1 = b1 - 2*np.pi*np.round(b1/(2*np.pi))
        b0 = th -theta[tm,l]; b0 = b0 - 2*np.pi*np.round(b0/(2*np.pi))
        dS = (a1*a1 - a0*a0 + b1*b1 - b0*b0)/(2*epsU)
        # magnetic
        for i in range(4):
            b = link_bonds[l,i]; newB[i] = Bv[t,b] + link_bsign[l,i]*d; newc[i] = np.cos(newB[i])
        if form == 0:   # KS
            for i in range(4):
                dS -= epsJ*(newc[i] - cosB[t, link_bonds[l,i]])
        else:
            na = 0
            for i in range(4):
                b = link_bonds[l,i]
                for j in range(4):
                    c = bond_checks[b,j]; seen = False
                    for k in range(na):
                        if affc[k] == c: seen = True
                    if not seen:
                        affc[na] = c; na += 1
            for k in range(na):
                c = affc[k]; p = 1.0
                for j in range(12):
                    bb = checks[c,j]; cv = cosB[t,bb]
                    for i in range(4):
                        if link_bonds[l,i] == bb: cv = newc[i]
                    p *= cv
                newp[k] = p; dS -= epsw*(p - prod[t,c])
        if dS <= 0 or rng_u[n] < np.exp(-dS):
            acc += 1; theta[t,l] = thn
            for i in range(4):
                b = link_bonds[l,i]; Bv[t,b] = newB[i]; cosB[t,b] = newc[i]
            if form == 1:
                for k in range(na): prod[t, affc[k]] = newp[k]
    return acc

@njit(cache=True)
def measure(Bv, prod, bnorm, bsgn, bctr, kx):
    M, nb = Bv.shape
    B2 = 0.0
    for t in range(M):
        for b in range(nb): B2 += Bv[t,b]**2
    B2 /= M*nb
    P = prod.mean()
    C = np.zeros(M)
    for n in range(3):
        for j in range(3):
            if j == n: continue
            Oc = np.zeros(M); Os = np.zeros(M)
            for t in range(M):
                for b in range(nb):
                    if bnorm[b] != n: continue
                    v = bsgn[b]*Bv[t,b]; ph = kx*bctr[b,j]
                    Oc[t] += v*np.cos(ph); Os[t] += v*np.sin(ph)
            for tau in range(M):
                s = 0.0
                for t in range(M):
                    u = t+tau if t+tau < M else t+tau-M
                    s += Oc[t]*Oc[u] + Os[t]*Os[u]
                C[tau] += s/(6*M)
    return B2, P, C

def fit_omega(C, eps, beta):
    """slope of log C(tau) on tau in [0.1, 0.5] (cosh image negligible for beta >= 2); also effective masses."""
    M = len(C); taus = np.arange(M)*eps
    meff = np.array([np.arccosh(max(1.0,(C[(t+1)%M] + C[(t-1)%M])/(2*C[t])))/eps if C[t] > 0 else np.nan for t in range(M)])
    lo, hi = int(round(0.05/eps)), int(round(0.4/eps))
    w = np.nanmean(meff[lo:hi+1])
    return w, meff

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--form", default="prod"); ap.add_argument("--U", type=float, default=0.7)
    ap.add_argument("--N", type=int, default=4); ap.add_argument("--beta", type=float, default=2.0); ap.add_argument("--M", type=int, default=80)
    ap.add_argument("--sweeps", type=int, default=20000); ap.add_argument("--therm", type=int, default=2000); ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--J", type=float, default=48.0); ap.add_argument("--w", type=float, default=12.0); ap.add_argument("--delta", type=float, default=0.25); ap.add_argument("--hot", type=int, default=0)
    a = ap.parse_args()
    g = build(a.N); M = a.M; eps = a.beta/M; form = 0 if a.form == "ks" else 1
    rng = np.random.default_rng(a.seed)
    theta = np.zeros((M, g["nl"])) if not a.hot else rng.uniform(-np.pi, np.pi, (M, g["nl"]))
    Bv, cosB, prod = init_state(theta, g["bond_links"], g["bond_signs"], g["checks"], M)
    kx = np.pi/a.N; lam2 = 4*np.sin(kx/2)**2
    print(f"# form={a.form} N={a.N} links={g['nl']} bonds={g['nb']} checks={g['nc']} U={a.U} beta={a.beta} M={M} eps={eps:.4f} k=pi/{a.N} lambda^2={lam2:.4f}")
    print(f"# tree level: J={a.J if form==0 else 4*a.w}, omega={np.sqrt(a.U*(a.J if form==0 else 4*a.w)*lam2):.3f}", flush=True)
    nvar = M*g["nl"]; B2s=[]; Ps=[]; Cs=[]; acc=0; t0=time.time()
    for s in range(a.therm + a.sweeps):
        ru = rng.random(nvar); rd = rng.random(nvar)*2-1; rl = rng.integers(0, g["nl"], nvar); rt = rng.integers(0, M, nvar)
        acc += sweep(theta, Bv, cosB, prod, eps*a.U, eps*a.w, eps*a.J, form, a.delta, g["link_bonds"], g["link_bsign"], g["bond_checks"], g["checks"], ru, rd, rl, rt)
        if s >= a.therm and s % 2 == 0:
            B2, P, C = measure(Bv, prod, g["bnorm"], g["bsgn"], g["bctr"], kx); B2s.append(B2); Ps.append(P); Cs.append(C)
        if s % 1000 == 0 and s > 0:
            Cm = np.mean(Cs, axis=0) if Cs else None
            w = fit_omega(Cm, eps, a.beta)[0] if Cs else float('nan')
            print(f"sweep {s:6d}  acc {acc/((s+1)*nvar):.3f}  <B^2> {np.mean(B2s) if B2s else float('nan'):.4f}  <prod> {np.mean(Ps) if Ps else float('nan'):.4f}  omega {w:.3f}  J_eff {w*w/(a.U*lam2) if Cs else float('nan'):.2f}  ({time.time()-t0:.0f}s)", flush=True)
    Cs = np.array(Cs); nblk = 10; blk = np.array_split(np.arange(len(Cs)), nblk)
    ws = np.array([fit_omega(Cs[i].mean(axis=0), eps, a.beta)[0] for i in blk])
    w = ws.mean(); dw = ws.std()/np.sqrt(nblk-1)
    Jeff = w*w/(a.U*lam2); dJ = 2*w*dw/(a.U*lam2)
    B2 = np.mean(B2s); P = np.mean(Ps)
    print(f"\nRESULT form={a.form} U={a.U} N={a.N}: <B^2>={B2:.4f}  <prod cos>={P:.4f}  omega={w:.3f}+-{dw:.3f}  J_eff={Jeff:.2f}+-{dJ:.2f}  U*J_eff={a.U*Jeff:.2f} (32 for v=c)  alpha^-1 at v=c: pi J_eff/sqrt2 = {np.pi*Jeff/np.sqrt(2):.1f}")
    w_, meff = fit_omega(Cs.mean(axis=0), eps, a.beta)
    np.save("corr_%s_U%s_N%d_s%d%s.npy" % (a.form, a.U, a.N, a.seed, "_hot" if a.hot else ""), Cs)
    print("effective mass by slice:", np.round(meff[:M//2+1], 3))

if __name__ == "__main__":
    main()
