"""Charge radius and form factor of the trapped-node defect for stated charge placements.
Regular tetrahedron ABCD, edge L; trapped node T at centroid; spokes T-A..T-D of length R=L*sqrt(3/8).
Proton (uud): valence spokes T-B, T-C, T-D carry +2/3, +2/3, -1/3; anchor spoke T-A carries none.
r_E^2 = -6 dG_E/dQ^2|0 = sum_i q_i |r_i - r_0|^2 for point charges (total charge 1), origin r_0."""
import numpy as np
L=1.0
A=np.array([0,0,0.]);B=np.array([1,1,0.])/np.sqrt(2);C=np.array([1,0,1.])/np.sqrt(2);D=np.array([0,1,1.])/np.sqrt(2)
T=(A+B+C+D)/4
R=np.linalg.norm(B-T); print("circumradius R/L =",R, " check AB =",np.linalg.norm(B-A))
q={'B':2/3,'C':2/3,'D':-1/3}; V={'B':B,'C':C,'D':D}
def r2_points(origin): return sum(q[k]*np.sum((V[k]-origin)**2) for k in q)
def r2_spokes(origin):  # charge uniform along spoke T->vertex
    tot=0
    for k in q:
        ts=np.linspace(0,1,20001); x=T[None,:]+ts[:,None]*(V[k]-T)[None,:]
        tot+=q[k]*np.mean(np.sum((x-origin)**2,axis=1))
    return tot
cm_nodes=(A+B+C+D+T)/5
rows=[("charges at valence vertices, origin anchor node A",r2_points(A)),
      ("charges at valence vertices, origin trapped node T",r2_points(T)),
      ("charges at valence vertices, origin centroid of 5 nodes",r2_points(cm_nodes)),
      ("charge uniform on valence spokes, origin anchor A",r2_spokes(A)),
      ("charge uniform on valence spokes, origin T",r2_spokes(T))]
print(f"{'placement':58s} r_E^2/L^2   r_E/L   L for r_E=0.84075 fm")
for n,v in rows: print(f"{n:58s} {v:8.4f}  {np.sqrt(v):6.3f}   {0.84075/np.sqrt(v):6.3f} fm")
# form factor for the vertex/anchor placement: three charges at distance L from origin
hc=0.1973269804; Lfm=0.84075
Q=np.linspace(0.01,1.5,8)
GE=np.sinc(Q*Lfm/hc/np.pi)  # j0(QL)
dip=(1+Q**2/0.71)**-2
print("\nQ(GeV)   G_E point-vertex model   dipole fit")
for a,b,c in zip(Q,GE,dip): print(f"{a:5.2f}      {b:8.3f}               {c:6.3f}")
print("first zero of j0(QL): Q =",np.pi*hc/Lfm,"GeV, Q^2 =",(np.pi*hc/Lfm)**2,"GeV^2")
