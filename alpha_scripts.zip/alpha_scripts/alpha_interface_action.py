"""Interface effective action of the harmonic rotor across a planar boundary between two media.

Cubic link lattice N^3 (periodic), harmonic Hamiltonian H = 1/2 sum_l U_l E_l^2 + 1/2 sum_p J_p B_p^2,
B = C theta (C the plaquette curl).  The slab x < N/2 is the host (U_f = J_f = 1: speed 1, impedance 1);
the slab x >= N/2 is the inclusion with speed 1/n and impedance zeta:  U_c = zeta/n, J_c = 1/(zeta n).
Equal lattice spacing on both sides (the spacing ratio of the model, 1e19, is not represented; what is
represented is the impedance and speed mismatch of one U(1) field across a boundary).

(i)  Zero-point energy E_0 = 1/2 sum omega, omega^2 = eig(U^1/2 C^T J C U^1/2), as a function of zeta at
     fixed n.  Bulk energies depend on U J only, so E_0(zeta) - E_0(1) is the interface term.  Duality
     E <-> B, U <-> J maps zeta -> 1/zeta; the question is whether E_int is stationary at zeta = 1 and
     whether it is a minimum.
(ii) The ground-state plaquette fluctuation <B_p^2> as a function of distance from the interface at
     zeta = 1, against the bulk value c sqrt(U/J) (same on both sides when matched): the one-loop
     boundary term of the matching condition.
"""
import numpy as np, sys, itertools
from scipy.sparse import lil_matrix

def curl(N):
    idx = lambda x,y,z,d: ((x%N)*N*N + (y%N)*N + (z%N))*3 + d
    nl = 3*N**3; C = lil_matrix((nl, nl)); pos = np.zeros((nl,3)); ppos = np.zeros((nl,3)); pnorm = np.zeros(nl, dtype=int)
    p = 0
    for x,y,z in itertools.product(range(N), repeat=3):
        for d in range(3):
            pos[idx(x,y,z,d)] = [x,y,z]; pos[idx(x,y,z,d)][d] += 0.5
        for (d1,d2) in [(1,2),(2,0),(0,1)]:               # plaquette normal to axis n = 3-d1-d2
            r = [x,y,z]; r1 = r.copy(); r1[d1] += 1; r2 = r.copy(); r2[d2] += 1
            C[p, idx(*r, d1)] += 1; C[p, idx(*r1, d2)] += 1; C[p, idx(*r2, d1)] -= 1; C[p, idx(*r, d2)] -= 1
            ppos[p] = [x,y,z]; ppos[p][d1] += 0.5; ppos[p][d2] += 0.5; pnorm[p] = 3-d1-d2; p += 1
    return C.tocsr(), pos, ppos, pnorm

def media(N, pos, ppos, zeta, n):
    inc_l = (pos[:,0] % N) >= N/2; inc_p = (ppos[:,0] % N) >= N/2
    U = np.where(inc_l, zeta/n, 1.0); J = np.where(inc_p, 1.0/(zeta*n), 1.0)
    return U, J

def spectrum(C, U, J):
    M = (np.sqrt(U)[:,None] * (C.T @ (J[:,None] * C.toarray())) * np.sqrt(U)[None,:])
    w2, V = np.linalg.eigh(M); w2[w2 < 1e-10] = 0.0
    return np.sqrt(w2), V

def zero_point(C, U, J):
    w, _ = spectrum(C, U, J); return 0.5*w.sum()

def B2_profile(C, U, J, ppos, N):
    w, V = spectrum(C, U, J); nz = w > 1e-6
    cov_q = (V[:,nz] / w[nz]) @ V[:,nz].T * 0.5
    cov_th = np.sqrt(U)[:,None] * cov_q * np.sqrt(U)[None,:]
    Cd = C.toarray(); B2 = np.einsum('pl,lm,pm->p', Cd, cov_th, Cd)
    xs = ppos[:,0]; out = {}
    for x in sorted(set(np.round(xs,1))):
        sel = np.abs(xs-x) < 0.01; out[x] = B2[sel].mean()
    return out, B2

if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    C, pos, ppos, pnorm = curl(N)
    # bulk check
    U = np.ones(3*N**3); J = np.ones(3*N**3)
    prof, B2 = B2_profile(C, U, J, ppos, N)
    k = 2*np.pi*np.arange(N)/N; kx,ky,kz = np.meshgrid(k,k,k,indexing='ij')
    lam = np.sqrt(4*(np.sin(kx/2)**2+np.sin(ky/2)**2+np.sin(kz/2)**2)); c_N = lam.mean()/3
    print(f"N={N}: bulk <B^2> = {B2.mean():.5f}, harmonic prediction c_N sqrt(U/J) = {c_N:.5f}")
    for n in (2.0, 10.0, 60.0):
        print(f"\nspeed ratio n = {n}:  interface zero-point energy E_0(zeta) - E_0(1), per interface plaquette")
        E1 = zero_point(C, *media(N, pos, ppos, 1.0, n)); A = N*N
        row = []
        for zeta in (0.5, 0.7, 0.85, 1.0, 1/0.85, 1/0.7, 2.0):
            E = zero_point(C, *media(N, pos, ppos, zeta, n)); row.append((zeta, (E-E1)/(2*A)))
        print("   zeta:   " + "  ".join(f"{z:6.3f}" for z,_ in row))
        print("   dE/A:   " + "  ".join(f"{e:6.4f}" for _,e in row))
        kap = np.mean([e/np.log(z)**2 for z,e in row if abs(z-1)>1e-9]); print(f"   E_int = kappa (ln zeta)^2 with kappa = {kap:.4f} per boundary plaquette (symmetric under zeta -> 1/zeta: {abs(row[0][1]-row[-1][1])<1e-6})")
        Up, Jp = media(N, pos, ppos, 1.0, n); prof, B2 = B2_profile(C, Up, Jp, ppos, N)
        bulk_f = c_N*1.0; bulk_c = c_N*np.sqrt((1.0/n)/(1.0/n))      # same U/J on both sides at zeta = 1
        print(f"   <B_p^2> by plane x (interfaces at x = {N/2-0.5:.1f}/{N/2:.1f} and {N-0.5:.1f}/0), bulk value {c_N:.4f} on both sides:")
        print("   " + "  ".join(f"{x:4.1f}:{v:.4f}" for x,v in prof.items()))
