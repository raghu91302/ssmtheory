"""BLM / Lepage-Mackenzie matching momentum for the rotor's plaquette-defined coupling,
on the Hamiltonian cubic (node-void) lattice of spacing a.
Harmonic rotor: transverse modes omega_k = lambda_k sqrt(UJ), lambda_k^2 = sum_i 4 sin^2(k_i/2).
Ground-state plaquette and link fluctuations: <B^2> = (1/2) sqrt(U/J) <lambda>_BZ, <E^2> = (1/2) sqrt(J/U) <lambda>_BZ,
so the observable that measures Z = sqrt(U/J) has integrand f(k) = lambda_k over the Brillouin zone.
BLM: ln(q*^2 a^2) = int f ln(lambda_k^2) / int f, with lambda_k the lattice momentum (continuum |q| a at small k)."""
import numpy as np
n=200
k=(np.arange(n)+0.5)*2*np.pi/n - np.pi
kx,ky,kz=np.meshgrid(k,k,k,indexing='ij')
lam2=4*(np.sin(kx/2)**2+np.sin(ky/2)**2+np.sin(kz/2)**2); lam=np.sqrt(lam2)
w=lam
qa=np.exp(0.5*(w*np.log(lam2)).sum()/w.sum())
print("plaquette/link-fluctuation weight lambda_k:  q* a = %.3f"%qa)
# alternatives for sensitivity
for name,wt in [("uniform over BZ",np.ones_like(lam)),("lambda^2 (energy density)",lam2),("1/lambda (propagator at equal time)",1/np.maximum(lam,1e-9))]:
    print("%-36s q* a = %.3f"%(name,np.exp(0.5*(wt*np.log(np.maximum(lam2,1e-18))).sum()/wt.sum())))
hc=0.1973269804; Lc=0.84075; a=Lc/np.sqrt(2)
qs=qa*hc/a
print("\nwith a = Lc/sqrt2 = %.4f fm: q* = %.3f GeV  (pi hbar c/Lc = %.3f, 3.4 hbar c/a = %.3f)"%(a,qs,np.pi*hc/Lc,3.4*hc/a))
# running at q*
exec(open('alpha_running_lowQ.py').read().split('hc=0.19')[0])
h=had(-qs*qs); print("alpha^-1(q*): spacelike %.2f, MSbar %.2f ; hadronic term %.5f"%((1-lep(qs*qs)-h)/a0,(1-lep_msbar(qs)-h)/a0,h))
print("relation 2 pi sqrt(lambda_e/r_p) = %.2f"%(2*np.pi*np.sqrt(386.15927/Lc)))
