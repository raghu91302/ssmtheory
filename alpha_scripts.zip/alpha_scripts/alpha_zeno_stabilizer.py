"""The vacuum's phase stiffness from a stabilizer Hamiltonian, taken literally.

Route: price each check by (P4) as transient, one quantum E_bond per bit it verifies, so that
    H_ver = - E_bond sum_c |c| S_c ,   |c| = 12,
and represent a check on the rotor by the product of its bonds' phase operators,
    S_c = prod_{b in c} cos B_b                      (product form)
or by their sum,
    S_c = (1/|c|) sum_{b in c} cos B_b               (sum form; the check reads each bond once).
Each bond lies in 4 checks.  The script gives the single-bond stiffness of each form at tree level
(the Hessian at B = 0, computed numerically on the explicit check), and the self-consistent
one-loop stiffness of the product form, where the other eleven cosines of each check are
contracted: J_eff = 48 E_bond <cos B>^11 with <B^2> = c sqrt(U/J_eff), c = 0.7959 (Theorem 5).
"""
import numpy as np
E = 1.0; nb = 12; nc = 4; c_tad = 0.795867

def hessian(f, n, h=1e-3):
    H = np.zeros((n, n)); x0 = np.zeros(n)
    for i in range(n):
        for j in range(n):
            e = np.zeros(n); e[i] += h; g = np.zeros(n); g[j] += h
            H[i, j] = (f(x0+e+g) - f(x0+e-g) - f(x0-e+g) + f(x0-e-g))/(4*h*h)
    return H

prod = lambda B: -E*nb*np.prod(np.cos(B))
summ = lambda B: -E*nb*np.mean(np.cos(B))
Hp, Hs = hessian(prod, nb), hessian(summ, nb)
print("tree level, one check of 12 bonds priced at 12 quanta:")
print(f"  product form: Hessian diagonal {Hp[0,0]:.4f} E per bond, max off-diagonal {np.abs(Hp-np.diag(np.diag(Hp))).max():.1e}")
print(f"  sum form:     Hessian diagonal {Hs[0,0]:.4f} E per bond")
print(f"  a bond in {nc} checks: J_b = {nc*Hp[0,0]:.1f} E (product form), {nc*Hs[0,0]:.1f} E (sum form)")
for lab, J in [("product", nc*Hp[0,0]), ("sum", nc*Hs[0,0])]:
    print(f"  alpha^-1_bare = pi n/sqrt2 with n = {J:.0f}: {np.pi*J/np.sqrt(2):.2f}  ({lab} form)")

print("\none loop, product form: the other eleven cosines of each check are contracted")
for lab, Ufix in [("U fixed at 2/3 E", True), ("U J = 32 E^2 held (v = c)", False)]:
    J = 48.0
    for _ in range(200):
        U = 2/3 if Ufix else 32.0/J
        B2 = c_tad*np.sqrt(U/J)
        J = 48.0*np.exp(-0.5*B2)**11                   # <cos B>^11 at Gaussian order
    print(f"  {lab:28s}: J_eff = {J:6.2f} E, <B^2> = {B2:.3f}, alpha^-1_bare = {4*np.pi*np.sqrt(J/U):6.1f}")
