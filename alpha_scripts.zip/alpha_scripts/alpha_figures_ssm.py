"""Figures for the model description (Section 2) and the inclusion (Section 3.3).

fig_ssm_lattice.pdf : (a) an FCC node with its twelve <110> bonds (the Z-check);
                      (b) an octahedral void with the twelve bonds bounding it (the X-check)
                          and the six <100> node-void links that carry the photon.
fig_inclusion.pdf   : a (100) cut through the vacuum lattice at spacing L_f with an embedded
                      patch at spacing L_c holding the trapped node; the far field of the
                      enclosed charge continues into the host.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch

# ---------- projection used for the 3D panels ----------
d = np.array([0.574, -0.579, -0.579]); d /= np.linalg.norm(d)          # viewing direction, off every symmetry axis
u = np.cross(d, [0, 0, 1.0]); u /= np.linalg.norm(u); w = np.cross(d, u)
R = np.vstack([u, w])
def P(v): v = np.asarray(v, float); return R @ v

def draw_bonds(ax, pairs, color, lw=1.2, alpha=1.0, z=1):
    for a, b in pairs:
        pa, pb = P(a), P(b)
        ax.plot([pa[0], pb[0]], [pa[1], pb[1]], color=color, lw=lw, alpha=alpha, zorder=z, solid_capstyle="round")

def dot(ax, v, c, s=40, z=3, marker="o", ec="k"):
    p = P(v); ax.scatter([p[0]], [p[1]], s=s, c=c, edgecolors=ec, linewidths=0.6, zorder=z, marker=marker)

# FCC: nearest neighbours of the origin are the 12 vectors (±1,±1,0)/2 and permutations (cube side 1)
nn = []
for i in range(3):
    for s1 in (-1, 1):
        for s2 in (-1, 1):
            v = np.zeros(3); j, k = [m for m in range(3) if m != i]
            v[j] = s1 / 2; v[k] = s2 / 2; nn.append(v)
nn = np.array(nn)

fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.7))

# ----- (a) node with twelve bonds: the Z-check -----
ax = axes[0]
draw_bonds(ax, [(np.zeros(3), v) for v in nn], "#2b6cb0", lw=1.6)
# the cuboctahedron edges joining the twelve neighbours (light), to show the shell
for a in nn:
    for b in nn:
        if np.allclose(np.linalg.norm(a - b), np.sqrt(0.5)) and tuple(a) < tuple(b):
            draw_bonds(ax, [(a, b)], "#9fb3c8", lw=0.6, alpha=0.8, z=0)
for v in nn: dot(ax, v, "#2b6cb0", s=26)
dot(ax, np.zeros(3), "white", s=70, z=4)
ax.text(0.03, 0.97, "(a)", transform=ax.transAxes, va="top", fontsize=11)


# ----- (b) octahedral void with its twelve bounding bonds and six <100> links -----
ax = axes[1]
oct_v = [np.array(v, float) for v in [(0.5,0,0),(-0.5,0,0),(0,0.5,0),(0,-0.5,0),(0,0,0.5),(0,0,-0.5)]]
# octahedron edges = the 12 bonds bounding the void (nearest-neighbour FCC bonds)
edges = [(a, b) for a in oct_v for b in oct_v if np.allclose(np.linalg.norm(a - b), np.sqrt(0.5)) and tuple(a) < tuple(b)]
draw_bonds(ax, edges, "#c05621", lw=1.6)
# the six <100> links from the void centre to its six nodes
draw_bonds(ax, [(np.zeros(3), v) for v in oct_v], "#2f855a", lw=1.2, z=2)
for v in oct_v: dot(ax, v, "#2b6cb0", s=26)
dot(ax, np.zeros(3), "#2f855a", s=46, z=4, marker="s")
ax.text(0.03, 0.97, "(b)", transform=ax.transAxes, va="top", fontsize=11)


axes[0].set_xlim(-0.95, 0.95); axes[0].set_ylim(-0.85, 0.85)
axes[1].set_xlim(-0.68, 0.68); axes[1].set_ylim(-0.6, 0.6)
for ax in axes:
    ax.set_aspect("equal"); ax.axis("off")
plt.tight_layout()
plt.savefig("fig_ssm_lattice.pdf"); plt.savefig("fig_ssm_lattice.png", dpi=200)
plt.close()

# ---------- the inclusion ----------
fig, ax = plt.subplots(figsize=(6.2, 5.4))
Lf = 0.18; Lc = 1.0; Rin = 1.55
# host lattice: fine square grid (a (100) cut of FCC is a square net of nodes)
xs = np.arange(-3.6, 3.61, Lf)
for x in xs:
    ax.plot([x, x], [-3.6, 3.6], color="#d0d7de", lw=0.4, zorder=0)
    ax.plot([-3.6, 3.6], [x, x], color="#d0d7de", lw=0.4, zorder=0)
# mask the inclusion region of the fine grid
ax.add_patch(Circle((0, 0), Rin, facecolor="white", edgecolor="none", zorder=1))
# coarse patch: nodes at spacing Lc inside the inclusion, bonds between them
pts = [(i * Lc, j * Lc) for i in range(-2, 3) for j in range(-2, 3) if (i * Lc) ** 2 + (j * Lc) ** 2 <= (Rin - 0.1) ** 2]
for (x, y) in pts:
    for (dx, dy) in [(Lc, 0), (0, Lc)]:
        if (x + dx, y + dy) in pts:
            ax.plot([x, x + dx], [y, y + dy], color="#2b6cb0", lw=1.6, zorder=2)
    # diagonal bonds of the (100) cut of FCC
    for (dx, dy) in [(Lc, Lc), (Lc, -Lc)]:
        if (x + dx, y + dy) in pts:
            ax.plot([x, x + dx], [y, y + dy], color="#9fb3c8", lw=0.8, zorder=2)
for (x, y) in pts:
    ax.scatter([x], [y], s=34, c="white", edgecolors="#2b6cb0", linewidths=1.0, zorder=3)
# trapped node at a void centre (centre of a square of the cut), with its spokes
tx, ty = 0.5, 0.5
for (x, y) in [(0, 0), (1, 0), (0, 1), (1, 1)]:
    ax.plot([tx, x], [ty, y], color="#c05621", lw=1.4, zorder=4)
ax.scatter([tx], [ty], s=120, marker="*", c="#c05621", edgecolors="k", linewidths=0.5, zorder=5)
# boundary
ax.add_patch(Circle((0, 0), Rin, facecolor="none", edgecolor="k", lw=1.4, ls="--", zorder=6))
# far field: radial lines continuing into the host
for th in np.linspace(0, 2 * np.pi, 12, endpoint=False):
    r0, r1 = Rin + 0.08, 3.3
    ax.annotate("", xy=(r1 * np.cos(th), r1 * np.sin(th)), xytext=(r0 * np.cos(th), r0 * np.sin(th)),
                arrowprops=dict(arrowstyle="-|>", lw=0.9, color="#2f855a", shrinkA=0, shrinkB=0), zorder=7)
# labels
ax.text(-3.45, 3.25, "vacuum: FCC at $L_f$, carries the photon", fontsize=9, ha="left", va="top",
        bbox=dict(facecolor="white", edgecolor="none", pad=1.5), zorder=8)
ax.text(0, -1.78, "inclusion: FCC at $L_c$, holds the trapped node", fontsize=9, ha="center", va="top",
        bbox=dict(facecolor="white", edgecolor="none", pad=1.5), zorder=8)
ax.annotate("boundary: $Z_c=Z_f$, no reflection", xy=(Rin * np.cos(0.6), Rin * np.sin(0.6)),
            xytext=(2.0, 2.55), fontsize=9, ha="left",
            arrowprops=dict(arrowstyle="-", lw=0.7, color="k"), zorder=8)
ax.text(2.55, -2.9, "far field of the\nenclosed charge:\nthe host's, at $c$", fontsize=9, ha="center", va="top",
        bbox=dict(facecolor="white", edgecolor="none", pad=1.5), zorder=8)
# scale bars
ax.plot([-3.3, -3.3 + Lf], [-3.25, -3.25], color="k", lw=2, zorder=8); ax.text(-3.3 + Lf / 2, -3.38, "$L_f$", ha="center", va="top", fontsize=9)
ax.plot([-2.0, -2.0 + Lc], [-3.25, -3.25], color="k", lw=2, zorder=8); ax.text(-2.0 + Lc / 2, -3.38, "$L_c$ (not to scale)", ha="center", va="top", fontsize=9)
ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-3.6, 3.6); ax.set_ylim(-3.6, 3.6)
plt.tight_layout()
plt.savefig("fig_inclusion.pdf"); plt.savefig("fig_inclusion.png", dpi=200)
print("wrote fig_ssm_lattice.pdf, fig_inclusion.pdf")
