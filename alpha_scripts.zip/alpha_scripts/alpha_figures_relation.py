"""Regenerates fig_alpha_Lc, fig_defect_bonds and fig_chain for alpha_ssm.tex."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.size":9,"mathtext.fontset":"cm"})
lb=386.15927; rp=0.84075
def save(fig,name):
    fig.savefig(name+".pdf",bbox_inches="tight"); fig.savefig(name+".eps",bbox_inches="tight"); plt.close(fig)

# ---- Fig 1: relation alpha^-1 = 2 pi sqrt(lb/Lc)
fig,ax=plt.subplots(figsize=(4.6,3.3))
L=np.linspace(0.68,1.06,400)
ax.axvspan(0.80,0.96,color="0.88",zorder=0,label=r"mechanical window for $L_c$")
ax.axhspan(134.6,135.0,color="#9ecae1",alpha=0.8,zorder=1,label=r"$\alpha^{-1}(q^*)=134.8\pm0.2$")
ax.axvline(rp,color="#de2d26",ls="--",lw=1.3,zorder=5,label=r"$r_p=0.84075$ fm")
ax.plot(L,2*np.pi*np.sqrt(lb/L),"k",lw=1.6,zorder=3,label=r"$\alpha^{-1}=2\pi\sqrt{\bar\lambda_e/L_c}$")
Lc=4*lb/1836; ax.plot([Lc],[2*np.pi*np.sqrt(lb/Lc)],"o",color="k",ms=7,mec="white",mew=1.2,zorder=6,
    label=r"under (P6): $L_c=4\bar\lambda_e/1836$, $\alpha^{-1}=\pi\sqrt{m_p/m_e}$")
ax.set_xlim(0.68,1.06); ax.set_ylim(118,142); ax.set_xlabel(r"$L_c$ (fm)"); ax.set_ylabel(r"$\alpha^{-1}$")
ax.legend(fontsize=6.4,loc="lower left",framealpha=0.95); ax.grid(alpha=0.3)
save(fig,"fig_alpha_Lc")

# ---- Fig: defect graph K5
A=np.array([0,0,0.]);B=np.array([1,1,0.]);C=np.array([1,0,1.]);D=np.array([0,1,1.]);T=(A+B+C+D)/4
V={"A":A,"B":B,"C":C,"D":D}
# oblique projection
def P(x): 
    R=np.array([[-0.791,0.553,0.261],[-0.612,-0.715,-0.337]]); return R@x
fig,ax=plt.subplots(figsize=(4.4,3.6))
import itertools
for a,b in itertools.combinations("ABCD",2):
    p,q=P(V[a]),P(V[b]); ax.plot([p[0],q[0]],[p[1],q[1]],color="0.4",lw=1.6,zorder=1)
for a in "ABCD":
    p,q=P(V[a]),P(T); ax.plot([p[0],q[0]],[p[1],q[1]],color="#e6550d",lw=1.8,zorder=2)
    # bond-end markers at the vertex: 3 edges + 1 spoke
    for b in [x for x in "ABCD" if x!=a]+["T"]:
        tgt=T if b=="T" else V[b]; m=P(V[a]+0.13*(tgt-V[a]))
        ax.plot(*m,"o",ms=3.5,color="#d62728" if b!="T" else "#fd8d3c",zorder=3)
for a in "ABCD":
    p=P(V[a]); ax.plot(*p,"o",ms=11,color="#3182bd",zorder=4); u=(p-P(T))/np.linalg.norm(p-P(T)); ax.text(p[0]+0.12*u[0],p[1]+0.12*u[1],a,fontsize=11,weight="bold",color="#08306b",ha="center",va="center")
pt=P(T); ax.plot(*pt,"*",ms=16,color="#fdd835",mec="#b8860b",zorder=5); ax.text(pt[0]+0.05,pt[1]+0.07,"trapped node",fontsize=8)
ax.set_aspect("equal"); ax.axis("off")
txt=("6 tetrahedron edges (grey) + 4 spokes (orange) = 10 bonds on 5 nodes: the complete graph $K_5$\n"
     "four-regular: from any node, $4^2=16$ two-step walks inside the defect\n"
     "equivalently, committed bond-ends at the four vertices (markers): $4\\times(3+1)=16$")
fig.subplots_adjust(bottom=0.2); fig.text(0.03,0.13,txt,fontsize=7.2,va="top")
save(fig,"fig_defect_bonds")

# ---- Fig: chain
fig,ax=plt.subplots(figsize=(8.4,7.8)); ax.set_xlim(0,10.6); ax.set_ylim(0,10.4); ax.axis("off")
col={"y":("#fff3c4","#c9a227"),"g":("#e5f5e0","#31a354"),"b":("#deebf7","#3182bd"),"r":("#fde0dd","#c0392b")}
def box(x,y,w,h,c,t,fs=7.6):
    f,e=col[c]; ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle="round,pad=0.02,rounding_size=0.12",fc=f,ec=e,lw=1.1))
    ax.text(x,y,t,ha="center",va="center",fontsize=fs,linespacing=1.35)
def arr(x1,y1,x2,y2): ax.annotate("",xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle="-|>",lw=1,color="k"))
box(5.3,9.8,8.6,0.75,"y","Postulates (P1)–(P5): FCC lattice, $K=12$, $K/d=4$; tick $\\tau=4L/c$; $\\epsilon_b$ per standing bit;\npricing; vacuum at $L_f$; a hadron is a lattice patch at spacing $L_c$ embedded in it")
box(2.5,8.5,4.7,0.85,"g","Vacuum photon sector: rotor on node–void half-links\n$H=-J\\sum\\cos B_b+\\frac{U}{2}\\sum(\\mathrm{curl}\\,m)^2$,  $\\alpha=\\sqrt{U/J}/4\\pi$")
box(7.6,8.5,4.7,0.85,"r","Vacuum's coupling: not derived from its dynamics; measured input,\n$\\alpha^{-1}=134.8\\pm0.2$ at $q^*=0.82$ GeV")
box(2.5,7.1,4.7,0.85,"y","Rules (R$_U$), (R$_J$): priced unit of flux is one bond;\n(P2) bounds the flux a bond transmits per tick")
box(2.5,5.75,4.7,0.8,"g","Inclusion's stiffnesses: $U_c=\\epsilon_b$, $J_c=\\hbar c/4L_c$\nimpedance $Z_c^2=4L_c/\\bar\\lambda_e$, speed $0.017c$")
box(7.6,7.1,4.7,0.85,"g","Inclusion electrodynamics: far field is the host's,\n$|q_p|=|q_e|$; boundary reflects unless $Z_c=Z_f$")
box(7.6,5.75,4.7,0.8,"g","(A1) Matching $Z_c=Z_f$: conditional on pricing, (P6) and\nstored quanta read as standing information (Prop. 4)")
box(5.05,4.4,5.4,0.8,"g","Proton radius: $L_c=4\\pi^2\\alpha^2\\bar\\lambda_e$")
box(2.5,3.05,4.7,0.85,"y","Rule (P6): kinematic cost $=16$ quanta;\nwindow $1836\\,\\epsilon_b=16\\,E_{\\rm bond}$ gives $L_c=4\\bar\\lambda_e/1836$")
box(7.6,3.05,4.7,0.85,"g","Consistency of the two spacings:\n$\\alpha^{-1}=\\pi\\sqrt{m_p/m_e}=134.6$")
box(5.05,1.7,6.6,0.8,"b","Measured: $r_p=0.84075(64)$ fm vs $0.837$–$0.841$ fm (matching), $0.8413$ fm (P6);\n$\\alpha^{-1}(q^*)=134.8\\pm0.2$ vs $134.6$ (P6)")
box(5.05,0.55,6.6,0.75,"r","Not derived: microscopic realization of the matched boundary; the vacuum's\nstiffnesses ($U_f=0.68$, $J_f=47$ bond quanta); rotor premise (A3); (P6)")
arr(2.5,9.42,2.5,8.93); arr(7.6,9.42,7.6,8.93)
arr(2.5,8.07,2.5,7.53); arr(2.5,6.67,2.5,6.15); arr(7.6,8.07,7.6,7.53); arr(7.6,6.67,7.6,6.15)
arr(2.5,5.35,4.0,4.8); arr(7.6,5.35,6.1,4.8)
arr(5.05,4.0,5.05,3.5); arr(2.5,2.62,4.0,2.1); arr(7.6,2.62,6.1,2.1); arr(5.05,1.3,5.05,0.93)
arr(4.85,3.05,5.25,3.05)
save(fig,"fig_chain")
print("figures written")
