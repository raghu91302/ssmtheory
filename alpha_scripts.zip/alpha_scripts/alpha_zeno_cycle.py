"""Does an explicit verification cycle generate the vacuum's phase stiffness, and with what factor?

Harmonic (small-B) rotor on the 12 bonds of one check: H = (U/2) sum m_b^2 + (J0/2) sum B_b^2,
[B_b, m_b] = i, hbar = 1.  One tick = free evolution for tau, then a verification cycle.
Three cycles are compared, all non-selective (no post-selection), all with the code's correction
(the measured deviation is fed back, which is what 'resolved within the tick' means):

  A  collective: the check measures ONE linear combination of its 12 phases (the parity ancilla
     reads sum_b B_b) with resolution sigma, and corrects it.
  B  per-bond, once per check: each of the 12 phases is measured once with resolution sigma and
     corrected.
  C  per-bond, k times per tick (a bond verified by k independent comparisons).

The stationary Gaussian state is computed by iterating the covariance map.  A Hamiltonian
rotor with stiffness J_eff and charging U has <B^2> = (1/2) sqrt(U/J_eff) and
<m^2> = (1/2) sqrt(J_eff/U).  The two estimates of J_eff agree only if the stationary state is
a rotor ground state at all; where they disagree the cycle has produced noise, not stiffness.
"""
import numpy as np

def tick_map(U, J0, tau, n=12):
    """Symplectic map of free evolution on (B_1..B_n, m_1..m_n)."""
    w = np.sqrt(U*J0)
    c, s = np.cos(w*tau), np.sin(w*tau)
    I = np.eye(n)
    # B(t) = B cos wt + (U/w) m sin wt ; m(t) = m cos wt - (J0/w) B sin wt
    return np.block([[c*I, (U/w)*s*I], [-(J0/w)*s*I, c*I]])

def measure_and_correct(Cov, w, sigma):
    """Gaussian measurement of O = w.B with resolution sigma, outcome fed back to set O -> O - <O|outcome>.
    Non-selective: average over outcomes.  Returns the updated covariance (2n x 2n, ordering B then m)."""
    n = len(w); W = np.concatenate([w, np.zeros(n)])      # O acts on the B block
    S = W @ Cov @ W + sigma**2                               # variance of the record
    K = Cov @ W / S                                          # Kalman gain
    # conditional covariance after measurement (same for every outcome), then the correction shifts
    # the mean by -K*record, which does not change the conditional covariance; averaging over outcomes
    # of the corrected states adds the variance of the residual mean: (1-g)^2 ... with full correction g=1
    # the corrected mean of O is 0 for every outcome, so the unconditional covariance equals the
    # conditional one.  Back-action: measuring B with resolution sigma kicks the conjugate m by 1/(2 sigma)^2.
    Cc = Cov - np.outer(K, K)*S
    back = np.zeros_like(Cov);
    # momentum kick on the conjugate of O: variance 1/(4 sigma^2) along w in the m block (Heisenberg-limited meter)
    Wm = np.concatenate([np.zeros(n), w])/np.dot(w, w)
    back += np.outer(Wm, Wm)*np.dot(w, w)**2/(4*sigma**2)
    return Cc + back

def stationary(U, J0, tau, cycle, sigma, k=1, n=12, iters=4000):
    M = tick_map(U, J0, tau, n)
    # start from the bare ground state
    Cov = np.diag(np.concatenate([np.full(n, 0.5*np.sqrt(U/J0)), np.full(n, 0.5*np.sqrt(J0/U))]))
    for _ in range(iters):
        Cov = M @ Cov @ M.T
        if cycle == "A":
            Cov = measure_and_correct(Cov, np.ones(n)/np.sqrt(n), sigma)
        else:
            for _ in range(k):
                for b in range(n):
                    e = np.zeros(n); e[b] = 1
                    Cov = measure_and_correct(Cov, e, sigma)
    return Cov

if __name__ == "__main__":
    U, J0, tau, n = 1.0, 1.0, 1.0, 12
    print("bare rotor: U = J0 = 1, tau = 1, <B^2> = <m^2> = 0.5\n")
    print(" cycle   k   sigma   <B_b^2>   <m_b^2>   J_eff from <B^2>   J_eff from <m^2>   product <B^2><m^2> (0.25 for a ground state)")
    for cycle, k in [("A",1), ("B",1), ("C",4), ("C",12), ("C",48)]:
        for sigma in (1.0, 0.3):
            C = stationary(U, J0, tau, cycle, sigma, k=k)
            b2 = np.mean(np.diag(C)[:n]); m2 = np.mean(np.diag(C)[n:])
            JB = U/(2*b2)**2; Jm = U*(2*m2)**2
            print(f"   {cycle}    {k:3d}   {sigma:4.1f}   {b2:7.4f}   {m2:8.3f}   {JB:12.2f}       {Jm:12.2f}        {b2*m2:8.3f}")
    # cycle A: which mode is affected
    C = stationary(U, J0, tau, "A", 0.3)
    ev = np.linalg.eigvalsh(C[:n, :n])
    print("\ncycle A, eigenvalues of the B-block covariance (one collective mode, eleven untouched at 0.5):")
    print("  ", np.round(np.sort(ev), 4))
