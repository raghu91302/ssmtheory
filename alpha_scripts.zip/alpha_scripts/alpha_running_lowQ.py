"""Low-momentum running of alpha for the comparison of Sec. 5 (alpha_ssm.tex).
One-loop leptonic polarization, exact and spacelike; MSbar logarithms with e, mu active;
hadronic part from the Eidelman-Jegerlehner parametrization (hep-ph/9606484).
Scales: hbar c/Lc, and the matching range pi hbar c/Lc to q* = 3.4 hbar c/a (a = Lc/sqrt2)."""
import numpy as np
from scipy.integrate import quad
a0=1/137.035999
c1,c2,c3,c4,l1,s0=2.2694240e-3,8.073429,0.1636393,-3.35455e-5,9.3055e-3,-4.0
def had(s): return c1*(np.log(abs(1-c2*s))+c2*c3*s/(c3-s))-l1*c3*s/(c3-s)+c4*(s/s0)**2
LEP=(0.51099895e-3,0.1056584,1.77686)
def lep(Q2): return sum(2*a0/np.pi*quad(lambda x:x*(1-x)*np.log(1+Q2*x*(1-x)/m**2),0,1)[0] for m in LEP)
def lep_msbar(Q): return sum(a0/(3*np.pi)*np.log(Q*Q/m**2) for m in LEP if m<Q)
hc=0.1973269804; Lc=0.84075; a=Lc/np.sqrt(2)
for name,Q in [("hbar c/Lc",hc/Lc),("pi hbar c/Lc",np.pi*hc/Lc),("3.4 hbar c/a",3.4*hc/a)]:
    h=had(-Q*Q)
    print(f"{name:14s} Q={Q:.3f} GeV  had={h:.5f}  spacelike={(1-lep(Q*Q)-h)/a0:.2f}  MSbar={(1-lep_msbar(Q)-h)/a0:.2f}")
print("relation 2 pi sqrt(lambda_e/Lc) =", round(2*np.pi*np.sqrt(386.15927/Lc),2))
