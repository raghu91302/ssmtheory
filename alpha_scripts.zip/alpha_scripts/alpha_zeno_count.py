"""The vacuum's phase stiffness as a verification count (the Zeno rule), and what it gives for alpha.

Rule (R_Z), stated before any number is computed:
  In the vacuum every check is satisfied each tick, and a unit of rotor flux on a bond is a
  correctable error the code resolves within the tick (transient, priced by (P2) through (P4)).
  The restoring term on a bond's phase is the verification itself: the stabilizer bits that
  constrain the bond's phase in one tick, one quantum E_bond each.  Counted with the model's
  own convention for stabilizer cost, C = E_s x C_s (bonds in the footprint times the checks
  that see them, the rule that gives 1836 for the proton), the bits constraining one bond are
      n(b) = sum over the checks that contain b of (number of bonds in that check),
  so   J_f = n(b) E_bond.
  The charging term of the vacuum is kinematic: U_f J_f = (hbar c / a)^2 with a = L/sqrt2 the
  node-void link, i.e. U_f J_f = 32 E_bond^2, because the vacuum's rotor propagates at c = 4L/tau.
  In the inclusion the checks' bits are standing (they are the defect's mass, priced by (P3)),
  so the rule does not apply there and (R_J) holds: J_c = E_bond.  Theorem 1 is unchanged.

Then alpha^-1_bare = 4 pi sqrt(J_f/U_f) = 4 pi n / sqrt(32) = pi n / sqrt2, a pure lattice number.

The script (i) builds a periodic FCC lattice, the Z-checks at nodes and X-checks on octahedral
voids, and counts n(b) and the alternative readings of 'the bits that constrain b' by
construction; (ii) evaluates alpha^-1 for each reading; (iii) compares with the continuum
coupling run to the vacuum's cutoff, after the one-loop lattice correction -pi c of Theorem 5.
"""
import numpy as np, itertools
from scipy.integrate import solve_ivp

# ---------------- (i) the lattice count ----------------
N = 4                                                  # periodic box, cubic cells; FCC nodes = 4 N^3
cube = [(0,0,0),(0,1,1),(1,0,1),(1,1,0)]               # FCC in units of half the cube side (coords even-sum)
nodes = sorted({((2*i+c[0])%(2*N),(2*j+c[1])%(2*N),(2*k+c[2])%(2*N)) for i in range(N) for j in range(N) for k in range(N) for c in cube})
nodeset = set(nodes)
def wrap(p): return tuple(x%(2*N) for x in p)
nn = [v for v in itertools.product((-1,0,1),repeat=3) if sum(abs(x) for x in v)==2]   # 12 <110> directions
bonds = set()
for p in nodes:
    for v in nn:
        q = wrap(tuple(p[i]+v[i] for i in range(3))); bonds.add(frozenset((p,q)))
bonds = sorted(bonds, key=lambda b: sorted(b))
bidx = {b:i for i,b in enumerate(bonds)}
# Z-checks: the 12 bonds at a node
Z = {p:[bidx[frozenset((p,wrap(tuple(p[i]+v[i] for i in range(3)))))] for v in nn] for p in nodes}
# octahedral voids: odd-sum sites at distance 1 from six nodes; X-check = the 12 edges of the octahedron
voids = sorted({wrap(tuple(p[i]+e[i] for i in range(3))) for p in nodes for e in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]})
X = {}
for v in voids:
    corners = [wrap(tuple(v[i]+e[i] for i in range(3))) for e in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
    assert all(c in nodeset for c in corners)
    edges = [frozenset((a,b)) for a,b in itertools.combinations(corners,2) if frozenset((a,b)) in bidx]
    assert len(edges)==12, len(edges)
    X[v] = [bidx[e] for e in edges]
checks = list(Z.values())+list(X.values())
print(f"FCC box: {len(nodes)} nodes, {len(bonds)} bonds, {len(Z)} Z-checks, {len(X)} X-checks "
      f"(code [[{len(bonds)},{len(bonds)-len(checks)+2},3]])")
# the checks that contain a given bond
b0 = 0
seen = [c for c in checks if b0 in c]
inc  = sum(len(c) for c in seen)                       # incidences: bits in the checks that see b
dist = len(set(itertools.chain.from_iterable(seen)))   # distinct bonds in those checks
assert all(sum(len(c) for c in checks if b in c)==inc for b in range(len(bonds)))   # same for every bond
readings = {
 "checks that see the bond":                        len(seen),
 "distinct bonds in those checks, excluding b":     dist-1,
 "distinct bonds in those checks":                  dist,
 "incidences excluding b itself":                   inc-len(seen),
 "incidences (bond,check), the E_s x C_s convention": inc,
}

# ---------------- (ii) alpha from each reading ----------------
UJ = 32.0                                              # U_f J_f in E_bond^2, from v_f = c and a = L/sqrt2
c_tad = 0.795867                                       # one-loop lattice constant, Theorem 5
print("\nreading of 'bits constraining one bond'            n    J_f/E_b  U_f/E_b   alpha^-1_bare  alpha^-1(q*) = bare - pi c")
for lab,n in readings.items():
    J=n; U=UJ/n; ainv=4*np.pi*np.sqrt(J/U)
    print(f"  {lab:48s} {n:3d}   {J:6.1f}   {U:6.3f}     {ainv:8.2f}        {ainv-np.pi*c_tad:8.2f}")
n = readings["incidences (bond,check), the E_s x C_s convention"]
ainv_bare = np.pi*n/np.sqrt(2)
print(f"\n(R_Z): n = C_s(b) x K = {len(seen)} x 12 = {n};  alpha^-1_bare = pi n/sqrt2 = 24 sqrt2 pi = {ainv_bare:.3f};"
      f"  U_f = {UJ/n:.4f} E_bond, J_f = {n} E_bond;  continuum at the vacuum's q*: {ainv_bare-np.pi*c_tad:.2f}")

# ---------------- (iii) the target: SM two-loop running to the vacuum's scales ----------------
mt = 173.34; g1,g2,g3,yt = 0.4626,0.6478,1.1666,0.9369
b = np.array([41/10,-19/6,-7.0]); B = np.array([[199/50,27/10,44/5],[9/10,35/6,12.0],[11/10,9/2,-26.0]]); C = np.array([17/10,3/2,2.0]); k=1/(16*np.pi**2)
def rhs(t,y):
    g=y[:3]; y_t=y[3]; dg=k*g**3*b+k*g**3*k*(B@(g**2)-C*y_t**2)
    return np.concatenate([dg,[k*y_t*(4.5*y_t**2-(17/20)*g[0]**2-(9/4)*g[1]**2-8*g[2]**2)]])
def ainv_run(mu, y0=(g1,g2,g3,yt)):
    s=solve_ivp(rhs,[np.log(mt),np.log(mu)],list(y0),rtol=1e-9,atol=1e-12); g=s.y[:3,-1]
    return 4*np.pi*(1/g[1]**2+(5/3)/g[0]**2)
hbarc=0.1973269804; lP=1.616255e-20; Lf=1.843*lP; a=Lf/np.sqrt(2)
mu_L=hbarc/Lf; mu_q=2.46*hbarc/a                        # BLM matching momentum q* a = 2.46 (alpha_matching_scale.py)
print(f"\nSM two-loop running (Standard Model content only above M_Z):")
print(f"  alpha^-1(hbar c/L_f)          = {ainv_run(mu_L):.2f}")
print(f"  alpha^-1(q*),  q* a = 2.46    = {ainv_run(mu_q):.2f}   (q* = {mu_q:.3g} GeV)")
print(f"  sensitivity: g3 +1% -> {ainv_run(mu_q,(g1,g2,g3*1.01,yt)):.2f};  g1,g2 +0.1% -> {ainv_run(mu_q,(g1*1.001,g2*1.001,g3,yt)):.2f}")
print(f"\ncomparison at q*: (R_Z) gives {ainv_bare-np.pi*c_tad:.2f}; running gives {ainv_run(mu_q):.2f} +- 0.3 (scheme, inputs; "
      f"not including unknown content above the electroweak scale)")

# ---------------- (iv) the light-speed condition on the physical stiffness ----------------
# one loop: J_eff = J (1 - <B^2>/2), <B^2> = c sqrt(U/J_eff) (Theorem 3); v = a sqrt(U J_eff) = c fixes U = 32/J_eff
J = 48.0
for _ in range(100):
    U = 32.0/J; J = 48.0*(1 - 0.5*c_tad*np.sqrt(U/J))
print(f"\nphysical light-speed reading: J_eff = {J:.2f}, U_f = {32/J:.3f}, alpha^-1 = pi J_eff/sqrt2 = {np.pi*J/np.sqrt(2):.1f}"
      f"   (bare reading above: {ainv_bare-np.pi*c_tad:.1f}; Monte Carlo J_eff = 46.2 +- 1.2 -> {np.pi*46.2/np.sqrt(2):.1f} +- {np.pi*1.2/np.sqrt(2):.1f})")
