"""Self-consistent harmonic estimate of the compact rotor's coupling renormalization on the cubic link lattice.
H = U/2 sum E^2 - J sum cos B.  SCHA: J_eff = J exp(-<B^2>/2), with <B^2> per plaquette from the Gaussian
theory at stiffness J_eff: <B^2> = c sqrt(U/J_eff), c = (1/(6N^3)) sum_{k,pol} lambda_k, lambda_k^2 = 4 sum_i sin^2(k_i/2).
Prints the shift of alpha^-1 = 4 pi sqrt(J_eff/U) at the inclusion's U/J and the L_c implied at fixed physical alpha."""
import numpy as np
N=64; k=2*np.pi*np.arange(N)/N
kx,ky,kz=np.meshgrid(k,k,k,indexing='ij'); lam=np.sqrt(4*(np.sin(kx/2)**2+np.sin(ky/2)**2+np.sin(kz/2)**2))
c=2*lam.sum()/(6*N**3)
def scha(UJ):
    r=1.0
    for _ in range(200):
        B2=c*np.sqrt(UJ/r); r=np.exp(-B2/2)
    return r,B2
UJ=0.0086; r,B2=scha(UJ)
print(f"c = {c:.4f};  U/J = {UJ}: <B^2> = {B2:.4f}, J_eff/J = {r:.4f}")
print(f"alpha^-1: tree {4*np.pi/np.sqrt(UJ):.2f} -> SCHA {4*np.pi/np.sqrt(UJ/r):.2f}  ({100*(np.sqrt(r)-1):+.2f}%)")
target=134.8; UJt=(4*np.pi/target)**2
for _ in range(100):
    r,_=scha(UJt); UJt=(4*np.pi/target)**2*r
lb=386.159; print(f"U/J for alpha^-1_ren = {target}: {UJt:.5f} (tree {(4*np.pi/target)**2:.5f}); L_c = {lb*UJt/4:.4f} fm (tree {lb*(4*np.pi/target)**2/4:.4f}, r_p 0.8407)")
