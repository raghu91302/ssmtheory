#!/usr/bin/env python3
"""code_d4.py -- records in the CSS code of the D4 lattice (Section 9).

The code of Ref. [meiext]: D4 = integer 4-vectors (t, x, y, z) with even sum; one qubit per bond (24 per node);
Z-type checks on the node stars (24 bonds) and X-type checks on the sixteen-cells around the odd-sum points
(24 edges).  A defect detected by the node checks is moved by X strings; two routes to the same endpoint
differ by an X loop, which leaves no record if it lies in the span of the sixteen-cell checks.
Checks (periodic block L = 4, [[1536,1282]]):
  D1  the code: n = 1536, k = 5 L^4 + 2 = 1282, weight-24 checks that commute;
  D2  no triangle or 4-cycle through a node is a stabilizer;
  D3  the short loops whose support is a logical operator of both types are 96 tetrahedral 4-cycles, among
      them all 24 spatial (FCC) ones;
  D4  the two routes through each spatial lift triangle (o, v, v', u) differ by a tetrahedral loop that is not a
      stabilizer of the D4 code;
  D5  second-order routes on a straight column: the 24 returns apply the identity string; the next site is
      reached by 8 routes (4 spatial, 4 null), the second site by 2;
  D6  coherent second-order hopping on the column gives K <= 0.361 for any phase; amplitude ratio 8/24;
  D7  two null steps back to the time slice give registry probabilities 240 : 60 : 60, K = 1/2.
Requires numpy.  Runs in a few minutes.
"""
import itertools as it, numpy as np
from collections import Counter
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}", flush=True)
L = 4
roots = sorted({tuple(s0*(i == a) + s1*(i == b) for i in range(4))
                for a, b in it.combinations(range(4), 2) for s0 in (1, -1) for s1 in (1, -1)})
R = [np.array(r) for r in roots]
nodes = [p for p in it.product(range(L), repeat=4) if sum(p) % 2 == 0]
odd = [p for p in it.product(range(L), repeat=4) if sum(p) % 2 == 1]
md = lambda p: tuple(int(x) % L for x in p)
eidx = {}
for p in nodes:
    for r in R: eidx.setdefault(frozenset((md(p), md(np.array(p) + r))), len(eidx))
n = len(eidx)
def vec(edges):
    v = np.zeros(n, np.uint8)
    for a, b in edges: v[eidx[frozenset((md(a), md(b)))]] ^= 1
    return v
HZ = np.array([vec([(p, np.array(p) + r) for r in R]) for p in nodes])
unit = [np.eye(4, dtype=int)[a]*s for a in range(4) for s in (1, -1)]
HX = []
for c in odd:
    vs = [np.array(c) + u for u in unit]
    HX.append(vec([(a, b) for a, b in it.combinations(vs, 2) if np.sum((a - b)**2) == 2]))
HX = np.array(HX)
def rank2(M):
    M = M.copy() % 2; r = 0
    for c in range(M.shape[1]):
        piv = np.flatnonzero(M[r:, c])
        if piv.size == 0: continue
        pr = r + piv[0]; M[[r, pr]] = M[[pr, r]]
        rows = np.flatnonzero(M[:, c]); rows = rows[rows != r]; M[rows] ^= M[r]
        r += 1
        if r == M.shape[0]: break
    return r
rz, rx = rank2(HZ), rank2(HX); k = n - rz - rx
check(f"D1  code: n = {n}, k = {k}, check weights {sorted(int(w) for w in set(HZ.sum(1)) | set(HX.sum(1)))}, commuting",
      n == 1536 and k == 5*L**4 + 2 and set(HZ.sum(1)) == {24} == set(HX.sum(1))
      and not ((HX.astype(int) @ HZ.T.astype(int)) % 2).any())
inspan = lambda M, r, v: rank2(np.vstack([M, v])) == r
def kind(Lv):
    stab = inspan(HX, rx, Lv)
    log2 = not ((HX.astype(int) @ Lv) % 2).any() and not inspan(HZ, rz, Lv)
    return stab, log2
adj = lambda a, b: np.sum((np.array(a) - np.array(b))**2) == 2
o = np.zeros(4, int); P0 = [o + r for r in R]
tri = [(a, c) for a, c in it.combinations(P0, 2) if adj(a, c)]
cyc = [(a, a + r, c) for a, c in it.combinations(P0, 2) for r in R
       if tuple(a + r) not in (tuple(o), tuple(c)) and adj(a + r, c)]
K3 = [kind(vec([(o, a), (a, c), (c, o)])) for a, c in tri]
K4 = [(adj(a, c) and adj(x, o), (a, x, c), kind(vec([(o, a), (a, x), (x, c), (c, o)]))) for a, x, c in cyc]
nstab = sum(s for s, _ in K3) + sum(s for _, _, (s, _) in K4)
check(f"D2  {len(tri)} triangles and {len(cyc)} 4-cycles through a node; stabilizers among them: {nstab}", nstab == 0)
dual = [(t, q) for t, q, (s, l2) in K4 if l2]
spatial = sum(all(v[0] == 0 for v in q) for t, q in dual)
check(f"D3  loops logical of both types: {len(dual)}, all tetrahedral, {spatial} of them spatial",
      len(dual) == 96 and all(t for t, _ in dual) and spatial == 24 and not any(l2 for _, l2 in K3))
G, rG = HX, rx                                             # stabilizers of the route type
sp = [q for q in P0 if q[0] == 0]
ok4 = True
for uu in [q for q in sp if sum(q[1:])//2 == 1]:
    vv = [q for q in sp if sum(q[1:]) == 0 and adj(q, uu)]
    loop = (vec([(o, vv[0]), (vv[0], uu)]) + vec([(o, vv[1]), (vv[1], uu)])) % 2
    ok4 &= len(vv) == 2 and not inspan(G, rG, loop)
check("D4  the two routes through each spatial lift triangle differ by a tetrahedral loop that is not a stabilizer", ok4)
def classes(paths):
    reps, cnt = [], []
    for q in paths:
        for i, r in enumerate(reps):
            if inspan(G, rG, (q + r) % 2): cnt[i] += 1; break
        else: reps.append(q); cnt.append(1)
    return cnt
u0, u1 = np.array([0, 0, 1, 1]), np.array([0, 1, 0, 1])   # straight column of Ref. [koide]
cr = classes([(vec([(o, j)]) + vec([(j, o)])) % 2 for j in P0])
mid = [j for j in P0 if adj(j, o + u0)]
cu = classes([(vec([(o, j)]) + vec([(j, o + u0)])) % 2 for j in mid])
nnull = sum(j[0] != 0 for j in mid)
s2 = o + u0 + u1; m2 = [j for j in P0 if adj(j, s2)]
ident = all(not ((vec([(o, j)]) + vec([(j, o)])) % 2).any() for j in P0)
check(f"D5  returns: 24 routes, each the identity string; next site on the column: {len(mid)} routes ({nnull} null); "
      f"second site: {len(m2)} routes", ident and cr == [24] and len(mid) == 8 and nnull == 4 and len(m2) == 2)
best = 0
for phi in np.linspace(0, 2*np.pi, 4001):
    th = 2*np.pi*np.arange(3)/3 + phi; m = 24 + 16*np.cos(th) + 2*len(m2)*np.cos(2*th)
    best = max(best, m.sum()/np.sqrt(m).sum()**2)
check(f"D6  column process: max K = {best:.4f}; amplitude ratio 8/24 = {8/24:.3f}", best < 0.37)
null = [r for r in roots if r[0] != 0]; amp = Counter()
for a in null:
    for b in null:
        if a[0] + b[0] == 0: amp[tuple(x + y for x, y in zip(a, b))] += 1
pr = Counter()
for s, cnt in amp.items(): pr[{0: 0, 1: 1, 2: -1}[(sum(s[1:])//2) % 3]] += cnt**2
Kn = (1 + (pr[1] + pr[-1])/pr[0])/3
check(f"D7  two null steps: registry probabilities {pr[0]} : {pr[1]} : {pr[-1]}, K = {Kn:.4f}",
      (pr[0], pr[1], pr[-1]) == (240, 60, 60) and np.isclose(Kn, 0.5))
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
