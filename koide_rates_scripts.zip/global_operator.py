#!/usr/bin/env python3
"""global_operator.py -- a unitary two-stage realization and a global form of the records (Section 7).

Records labeled by bond direction: the six in-sheet directions get orthonormal records |E_d>; a direction d
into the sheet above (below) gets |E_d> = e^{+-i phi} (|E_v> + |E_v'>)/sqrt2, with v, v' the in-sheet directions
that close a tetrahedron with d.
Checks:
  G1  two-stage walk: with a stage flag (stay / continue up / continue down), the map
        |v>|E_v>|up> -> |v+u_v>|E_v>|done>, |v>|E_v>|stay> -> |v>|E_v>|done>, ...
      preserves all inner products (an isometry, extendable to a unitary), and the up-hop superposition
      (|v>|E_v> + |v'>|E_v'>)/sqrt2 is carried to |u> (x) (|E_v> + |E_v'>)/sqrt2;
  G2  V = (1/12) sum_d T_d (x) |E_d> is a contraction (norm <= 1) on a periodic FCC block;
  G3  A = (I (x) <e|) V, with |e> = 6^{-1/2} sum_j |E_j>, is the hopping operator with bond amplitudes
      <e|E_d> = 1/sqrt6 (in-sheet) and e^{+-i phi}/sqrt3 (adjacent sheets), a ratio sqrt2 e^{+-i phi};
  G4  A maps the sheet-uniform states |S_r> (uniform on registry r) into their span, and there equals
      (1/12)[sqrt6 I + sqrt3 (e^{i phi} P + e^{-i phi} P^-1)]: Eq. (2) up to normalization, K = 2/3 at
      phi = 0.2222220;
  G5  identical records (all |E_d> equal) give isotropic bond amplitudes and K = 1/2 on the same states.
Requires numpy.
"""
import itertools as it, numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
lay = lambda p: int(round(sum(p)))//2
adj = lambda a, b: np.sum((np.array(a) - np.array(b))**2) == 2
ins = [b for b in B if lay(b) == 0]; up = [b for b in B if lay(b) == 1]; dn = [b for b in B if lay(b) == -1]
phi = 0.2222220
E = {tuple(b): np.eye(6)[i].astype(complex) for i, b in enumerate(ins)}
partner = {}
for s, grp in ((1, up), (-1, dn)):
    for d in grp:
        pr = [v for v in ins if adj(v, d)]
        E[tuple(d)] = np.exp(1j*s*phi)*(E[tuple(pr[0])] + E[tuple(pr[1])])/np.sqrt(2)
        for v in pr: partner[(tuple(v), s)] = tuple(d)
# G1: two-stage walk on the 13 sites o + {0, B}; registers: site (13) x record (6) x stage (stay, up, down, done)
sites = [(0, 0, 0)] + [tuple(b) for b in B]; si = {p: i for i, p in enumerate(sites)}
def ket(site, rec, stage):
    v = np.zeros((13, 6, 4), complex); v[si[site], :, stage] = rec; return v.ravel()
inputs, outputs = [], []
for v in ins:
    for st, s in ((0, 0), (1, 1), (2, -1)):
        inputs.append(ket(tuple(v), E[tuple(v)], st))
        dest = tuple(v) if s == 0 else tuple(np.array(partner[(tuple(v), s)]))
        outputs.append(ket(dest, E[tuple(v)], 3))
Gi = np.array([[np.vdot(a, b) for b in inputs] for a in inputs]); Go = np.array([[np.vdot(a, b) for b in outputs] for a in outputs])
d0 = up[0]; pr = [v for v in ins if adj(v, d0)]
inp = (ket(tuple(pr[0]), E[tuple(pr[0])], 1) + ket(tuple(pr[1]), E[tuple(pr[1])], 1))/np.sqrt(2)
coef = np.linalg.lstsq(np.array(inputs).T, inp, rcond=None)[0]; out = np.array(outputs).T @ coef
target = ket(tuple(d0), (E[tuple(pr[0])] + E[tuple(pr[1])])/np.sqrt(2), 3)
check("G1  the two-stage map preserves all inner products (isometry) and carries the up-hop superposition to "
      "|u> (x) (|E_v> + |E_v'>)/sqrt2", np.allclose(Gi, Go) and np.allclose(out, target))
# periodic block, side N (N multiple of 6 keeps registries periodic)
N = 6
S = [p for p in it.product(range(N), repeat=3) if sum(p) % 2 == 0]; idx = {p: i for i, p in enumerate(S)}
md = lambda p: tuple(int(x) % N for x in p)
def T(d):
    M = np.zeros((len(S), len(S)))
    for p in S: M[idx[md(np.array(p) + d)], idx[p]] = 1
    return M
Ts = {tuple(d): T(d) for d in B}
V = sum(np.kron(Ts[tuple(d)], E[tuple(d)][:, None]) for d in B)/12          # maps sites -> sites x records
check(f"G2  V is a contraction: norm {np.linalg.norm(V, 2):.4f} <= 1", np.linalg.norm(V, 2) <= 1 + 1e-12)
e = np.ones(6)/np.sqrt(6)
w = {tuple(d): np.vdot(e, E[tuple(d)]) for d in B}
A = sum(w[tuple(d)]*Ts[tuple(d)] for d in B)/12
Avia = np.kron(np.eye(len(S)), e.conj()[None, :]) @ V
check(f"G3  A = (I x <e|)V has bond amplitudes {abs(w[tuple(ins[0])]):.4f} in-sheet and {abs(w[tuple(up[0])]):.4f} "
      f"adjacent (ratio {abs(w[tuple(up[0])])/abs(w[tuple(ins[0])]):.4f})",
      np.allclose(A, Avia) and np.isclose(abs(w[tuple(up[0])])/abs(w[tuple(ins[0])]), np.sqrt(2)))
reg = np.array([lay(p) % 3 for p in S])
Sr = np.array([(reg == r).astype(float)/np.sqrt((reg == r).sum()) for r in range(3)]).T
Af = Sr.T @ A @ Sr
inv = np.allclose(A @ Sr, Sr @ Af)
P = np.roll(np.eye(3), 1, 0)
Wt = (np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*phi)*P + np.exp(-1j*phi)*P.T))/12
x = np.linalg.eigvalsh(Af); K = (x**2).sum()/x.sum()**2
check(f"G4  sheet-uniform states are invariant; A_f equals Eq. (2)/12; K = {K:.6f}", inv and np.allclose(Af, Wt) and np.isclose(K, 2/3))
A1 = sum(Ts[tuple(d)] for d in B)/12/np.sqrt(6)
Af1 = Sr.T @ A1 @ Sr; x1 = np.linalg.eigvalsh(Af1); K1 = (x1**2).sum()/x1.sum()**2
check(f"G5  identical records: isotropic amplitudes, K = {K1:.6f}", np.isclose(K1, 0.5))
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
