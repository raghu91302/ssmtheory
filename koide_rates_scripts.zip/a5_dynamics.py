#!/usr/bin/env python3
"""a5_dynamics.py -- a second-order dynamical origin of the mass rule A5 (Section 8).

Family states (energy 0) couple to a three-state intermediate sector (energy Delta > 0) through g A, with A the
family operator of Eq. (2), a Hermitian circulant:
      H = [[0, g A^dagger], [g A, D]],   D = Delta I  (or D = Delta I + eps (e^{i chi} P + h.c.)).
Checks:
  S1  the low branch of the exact spectrum of H satisfies m (m + Delta) = g^2 lambda^2 for each eigenvalue lambda
      of A (m = -E), and its eigenvectors are the characters of P at every order;
  S2  to leading order m = g^2 lambda^2 / Delta, so the masses are the squared eigenvalues of A and K = 2/3;
  S3  the deviation from 2/3 grows as 2/3 - K ~ 0.095 m_tau/Delta; the measured ratio requires
      m_tau/Delta < 1.3e-4, i.e. Delta > 1.4e4 GeV;
  S4  hopping eps between the sheet types of the intermediate sector makes the denominators family
      dependent: max over chi of |2/3 - K| = eps/(3 Delta), so eps/Delta must be below about 3e-5.
Requires numpy.
"""
import numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
P = np.roll(np.eye(3), 1, 0); d = 0.2222220
A = np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*d)*P + np.exp(-1j*d)*P.T)
lam = np.linalg.eigvalsh(A)
K = lambda m: m.sum()/np.sqrt(m).sum()**2
def low_branch(r, D=None):
    """exact low branch of H with Delta = 1 and g fixed by r = g^2 lam_max^2 / Delta^2 (leading-order m_tau/Delta)"""
    g = np.sqrt(r)/lam.max(); D = np.eye(3) if D is None else D
    H = np.block([[np.zeros((3, 3)), g*A.conj().T], [g*A, D]])
    E, U = np.linalg.eigh(H); sel = E < 0.5
    return -E[sel], U[:3, sel], g
r = 1e-2
m, U, g = low_branch(r)
rel = np.allclose(np.sort(m*(m + 1)), np.sort(g**2*lam**2))
chars = np.array([[np.exp(-2j*np.pi*k*n/3) for n in range(3)] for k in range(3)])/np.sqrt(3)
ov = np.abs(chars.conj() @ (U/np.linalg.norm(U, axis=0)))
check(f"S1  exact low branch obeys m(m + Delta) = g^2 lambda^2; eigenvectors are characters of P (overlaps {np.round(np.sort(ov.max(0)), 6)})",
      rel and np.allclose(ov.max(0), 1))
m2, _, g2 = low_branch(1e-6)
check(f"S2  leading order: m Delta / (g lambda)^2 = {np.round(np.sort(m2)/np.sort(g2**2*lam**2), 6)}; K = {K(m2):.7f}",
      np.allclose(np.sort(m2)/np.sort(g2**2*lam**2), 1, atol=1e-5) and abs(K(m2) - 2/3) < 1e-6)
print("     m_tau/Delta   2/3 - K")
for rr in (1e-5, 1e-4, 1e-3, 1e-2): print(f"     {rr:<12g}  {2/3 - K(low_branch(rr)[0]):.2e}")
mobs = np.array([0.51099895, 105.6583755, 1776.93]); sm = np.array([0, 0, 0.09])
Km = mobs.sum()/np.sqrt(mobs).sum()**2; dK = abs((mobs + sm).sum()/np.sqrt(mobs + sm).sum()**2 - Km)
allow = (2/3 - Km) + 2*dK
lo, hi = 1e-7, 1e-1
for _ in range(80):
    mid = np.sqrt(lo*hi); lo, hi = (mid, hi) if 2/3 - K(low_branch(mid)[0]) < allow else (lo, mid)
slope = (2/3 - K(low_branch(1e-4)[0]))/1e-4
check(f"S3  slope d(2/3 - K)/d(m_tau/Delta) = {slope:.3f}; bound m_tau/Delta < {lo:.2e}, Delta > {1.77693/lo:.2e} GeV",
      0.08 < slope < 0.11 and 1e-4 < lo < 2e-4)
coef = []
for eps in (1e-5, 1e-4, 1e-3):
    w = 0
    for chi in np.linspace(0, 2*np.pi, 145):
        D = np.eye(3) + eps*(np.exp(1j*chi)*P + np.exp(-1j*chi)*P.T)
        M = A.conj().T @ np.linalg.inv(D) @ A; mm = np.linalg.eigvalsh((M + M.conj().T)/2)
        w = max(w, abs(2/3 - K(mm)))
    coef.append(w/eps)
check(f"S4  intermediate hopping eps: max |2/3 - K| / (eps/Delta) = {np.round(coef, 4)} (= 1/3)", np.allclose(coef, 1/3, atol=2e-3))
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
