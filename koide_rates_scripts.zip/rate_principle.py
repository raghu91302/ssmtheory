#!/usr/bin/env python3
"""rate_principle.py -- the family operator fixed by its rates (Sections 3 and 5).

The family operator W acts on the three registry labels A, B, C.  It is Hermitian and commutes with the
stacking translation P (P|A> = |B>, P|B> = |C>, P|C> = |A>), so it is a circulant W = a I + b P + c P^-1.
Rate principle: |W_lk|^2 equals the rate from family state k into sheet type l (Section 4 defines it).
Checks:
  R1  Hermiticity and translation invariance force a real and c = conj(b); given the rates (r0, r+, r-) with
      r+ = r-, every such W is +-sqrt(r0) I + sqrt(r+)(e^{i d} P + e^{-i d} P^-1): unique up to sign and phase;
  R2  for that W, K = Tr W^2/(Tr W)^2 = (1 + 2 rho)/3 with rho = r+/r0, at every phase with non-negative
      eigenvalues;
  R3  rates r = n (6, 3, 3) give K = 2/3; rates r = n^2 (36, 9, 9) give K = 1/2;
  R4  records with pairwise overlap c, r = n + c n(n-1), give K(c) = 2/3 - c + O(c^2);
  R5  the measured pole-mass ratio bounds the record overlap c.
Requires numpy.
"""
import numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
P = np.roll(np.eye(3), 1, 0)
rng = np.random.default_rng(7)
# R1: the real-linear space of Hermitian 3x3 matrices commuting with P
basis=[]
for i in range(3):
    for j in range(3):
        for z in (1, 1j):
            E = np.zeros((3, 3), complex); E[i, j] = z; basis.append(E)
def realvec(X): return np.concatenate([X.real.ravel(), X.imag.ravel()])
cons = np.array([np.concatenate([realvec(E@P - P@E), realvec(E - E.conj().T)]) for E in basis]).T
dim = len(basis) - np.linalg.matrix_rank(cons)
check(f"R1  Hermitian matrices commuting with P form a {dim}-parameter real family (a, Re b, Im b)", dim == 3)
r0, rp = 6.0, 3.0
def W_of(sign, d): return sign*np.sqrt(r0)*np.eye(3) + np.sqrt(rp)*(np.exp(1j*d)*P + np.exp(-1j*d)*P.T)
moduli_ok = all(np.allclose(np.abs(W_of(s, d))**2, r0*np.eye(3) + rp*(P + P.T)) for s in (1, -1) for d in rng.uniform(0, 2*np.pi, 50))
check("R1  W = +-sqrt(r0) I + sqrt(r+)(e^{id}P + h.c.) has squared entries equal to the rates", moduli_ok)
# conversely: for every member of the family the squared entries are a^2 on the diagonal and |b|^2 off it,
# so matching the rates means a = +-sqrt(r0) and |b| = sqrt(r+), leaving one sign and the phase arg(b)
conv = True
for _ in range(500):
    a_, br, bi = rng.normal(size=3)
    W = a_*np.eye(3) + (br + 1j*bi)*P + (br - 1j*bi)*P.T
    conv &= np.allclose(np.abs(W)**2, a_**2*np.eye(3) + (br**2 + bi**2)*(P + P.T))
check("R1  in that family |W_kk|^2 = a^2 and |W_k+-1,k|^2 = |b|^2: the rates fix |a| and |b|, leaving one sign and one phase", conv)
# R2
def K_eigs(W):
    x = np.linalg.eigvalsh(W); return (x**2).sum()/x.sum()**2, x
for rho in (0.5, 0.25, 0.4):
    good = True
    for d in np.linspace(-np.pi/12 + 1e-3, np.pi/12 - 1e-3, 41):
        W = np.eye(3) + np.sqrt(rho)*(np.exp(1j*d)*P + np.exp(-1j*d)*P.T)
        K, x = K_eigs(W)
        if x.min() >= 0: good &= np.isclose(K, (1 + 2*rho)/3)
    check(f"R2  K = (1 + 2 rho)/3 at every phase with non-negative eigenvalues (rho = {rho})", good)
# R3
nk = np.array([6, 3, 3])
for label, r, target in (("r = n", nk.astype(float), 2/3), ("r = n^2", nk**2.0, 1/2)):
    rho = r[1]/r[0]; check(f"R3  {label}: rho = {rho:g}, K = {(1 + 2*rho)/3:.6f} (target {target:.6f})", np.isclose((1 + 2*rho)/3, target))
# R4
def K_c(c):
    r = nk + c*nk*(nk - 1); rho = r[1]/r[0]; return (1 + 2*rho)/3
print("     c         K(c)")
for c in (0, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1):
    print(f"     {c:<9g} {K_c(c):.7f}")
slope = (K_c(1e-7) - K_c(0))/1e-7
check(f"R4  dK/dc at c = 0 is -1 (numerical {slope:.4f})", np.isclose(slope, -1, atol=1e-4))
check("R4  K(0) = 2/3 and K(1) = 1/2", np.isclose(K_c(0), 2/3) and np.isclose(K_c(1), 1/2))
# R5: pole masses (PDG 2024)
m = np.array([0.51099895, 105.6583755, 1776.93]); sm = np.array([0, 0, 0.09])
K = m.sum()/np.sqrt(m).sum()**2
dK = abs((((m + sm).sum()/np.sqrt(m + sm).sum()**2) - K))
print(f"     measured K = {K:.7f} +/- {dK:.1e};  2/3 - K = {2/3 - K:+.1e}")
cmax = (2/3 - K) + 2*dK
check(f"R5  record overlap c < {cmax:.1e} at two standard deviations", 1e-6 < cmax < 3e-5)
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
