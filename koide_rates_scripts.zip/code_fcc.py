#!/usr/bin/env python3
"""code_fcc.py -- records in the CSS code of the FCC lattice (Section 9).

The code of Ref. [cssfcc]: one qubit per bond; checks of one type on the node stars (the 12 bonds at a node)
and of the other type on the octahedral voids (the 12 edges of an octahedron).  A defect detected by the
node checks is moved by a string of the conjugate type along its route; two routes to the same endpoint
differ by a closed loop.  A loop in the span of the octahedral checks leaves no record; any other loop is a
logical operator and stores which route was taken.
Checks (periodic block of side N; N = 4 gives [[192,130,3]], N = 6 is used for the stated robustness):
  F1  the code: n = 3 N^3, k = 2 N^3 + 2, the two check types commute;
  F2  no triangle or 4-cycle through a node is a stabilizer: every short loop is a logical operator;
  F3  the 24 tetrahedral 4-cycles (the 4 vertices form a regular tetrahedron; 8 tetrahedra x 3) are the only
      short loops whose support is a logical operator of both types;
  F4  in the code ensemble rho = Pi_code / Tr Pi_code a Pauli operator outside the stabilizer group has
      expectation 0, so the two routes o -> v -> u and o -> v' -> u through the tetrahedron (o, v, v', u) have
      orthogonal records (their loop is the tetrahedral 4-cycle, not a stabilizer), as Eq. (11) requires;
  F5  second-order routes on a straight column of Ref. [koide] (one up-bond of each component, so the column
      returns to its lateral position after three sheets): all 12 returns o -> j -> o carry no record; the 4
      routes to the next site have mutually orthogonal records; the second site is reached by 2 routes;
  F6  coherent second-order hopping on the column, with any phase per up-hop, gives K <= 0.375; the
      off-diagonal amplitude 4 is a third of the diagonal 12, while Eq. (2) needs |M_10|/M_00 = 11/12.
Requires numpy.  Usage: python3 code_fcc.py [N]
"""
import itertools as it, sys, numpy as np
from collections import Counter
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
N = int(sys.argv[1]) if len(sys.argv) > 1 else 4
nodes = [p for p in it.product(range(N), repeat=3) if sum(p) % 2 == 0]
voids = [p for p in it.product(range(N), repeat=3) if sum(p) % 2 == 1]
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
md = lambda p: tuple(int(x) % N for x in p)
bonds = {}
for p in nodes:
    for b in B:
        e = frozenset([md(p), md(np.array(p) + b)])
        bonds.setdefault(e, len(bonds))
n = len(bonds)
def vec(edges):
    v = np.zeros(n, np.uint8)
    for a, b in edges: v[bonds[frozenset([md(a), md(b)])]] ^= 1
    return v
star = np.array([vec([(p, np.array(p) + b) for b in B]) for p in nodes])
E3 = [np.eye(3, dtype=int)[i] for i in range(3)]
octa = []
for c in voids:
    vs = [np.array(c) + s*e for e in E3 for s in (1, -1)]
    octa.append(vec([(a, b) for a, b in it.combinations(vs, 2) if np.sum((a - b)**2) == 2]))
octa = np.array(octa)
def rank2(M):
    M = M.copy() % 2; r = 0
    for c in range(M.shape[1]):
        piv = np.flatnonzero(M[r:, c])
        if piv.size == 0: continue
        pr = r + piv[0]; M[[r, pr]] = M[[pr, r]]
        rows = np.flatnonzero(M[:, c]); rows = rows[rows != r]; M[rows] ^= M[r]
        r += 1
        if r == M.shape[0]: break
    return r
rs, ro = rank2(star), rank2(octa); k = n - rs - ro
check(f"F1  code on the N = {N} block: n = {n}, k = {k}, checks commute",
      n == 3*N**3 and k == 2*N**3 + 2 and not ((star.astype(int) @ octa.T.astype(int)) % 2).any())
inspan = lambda M, r, v: rank2(np.vstack([M, v])) == r
def kind(L):   # (stabilizer?, logical of the node-detected type?, also logical of the other type?)
    stab = inspan(octa, ro, L)
    log1 = not ((star.astype(int) @ L) % 2).any() and not stab
    log2 = not ((octa.astype(int) @ L) % 2).any() and not inspan(star, rs, L)
    return stab, log1, log2
adj = lambda a, b: np.sum((np.array(a) - np.array(b))**2) == 2
o = np.zeros(3, int); P0 = [o + b for b in B]
tri = [(a, c) for a, c in it.combinations(P0, 2) if adj(a, c)]
cyc = [(a, a + b, c) for a, c in it.combinations(P0, 2) for b in B
       if tuple(a + b) not in (tuple(o), tuple(c)) and adj(a + b, c)]
K3 = Counter(kind(vec([(o, a), (a, c), (c, o)])) for a, c in tri)
K4 = Counter((adj(a, c) and adj(x, o), kind(vec([(o, a), (a, x), (x, c), (c, o)]))) for a, x, c in cyc)
nstab = sum(v for (s, _, _), v in K3.items() if s) + sum(v for (_, (s, _, _)), v in K4.items() if s)
check(f"F2  {len(tri)} triangles and {len(cyc)} 4-cycles through a node; stabilizers among them: {nstab}",
      nstab == 0 and all(l1 for (s, l1, _) in K3) and all(l1 for (_, (s, l1, _)) in K4))
dual = [(t, v) for (t, (s, l1, l2)), v in K4.items() if l2]
check(f"F3  short loops logical of both types: {sum(v for _, v in dual)}, all tetrahedral",
      sum(v for _, v in dual) == 24 and all(t for t, _ in dual) and not any(l2 for (_, _, l2) in K3))
G, rG = octa, ro                                           # stabilizers of the route type
up = [q for q in P0 if (int(sum(q))//2) == 1]
ok4 = True
for uu in up:
    vv = [q for q in P0 if int(sum(q))//2 == 0 and adj(q, uu)]
    loop = (vec([(o, vv[0]), (vv[0], uu)]) + vec([(o, vv[1]), (vv[1], uu)])) % 2
    ok4 &= len(vv) == 2 and not inspan(G, rG, loop)
check("F4  code ensemble: for each of the 3 neighbors above, the two routes through its tetrahedron have "
      "orthogonal records (tetrahedral loop not a stabilizer, expectation 0)", ok4)
inG = lambda L: inspan(G, rG, L)
def classes(paths):
    reps, cnt = [], []
    for q in paths:
        for i, r in enumerate(reps):
            if inG((q + r) % 2): cnt[i] += 1; break
        else: reps.append(q); cnt.append(1)
    return cnt
u0, u1 = np.array([0, 1, 1]), np.array([1, 0, 1])        # straight column: o, o+u0, o+u0+u1, ... (Ref. [koide])
cr = classes([(vec([(o, j)]) + vec([(j, o)])) % 2 for j in P0])
rts = [(vec([(o, j)]) + vec([(j, o + u0)])) % 2 for j in P0 if adj(j, o + u0)]
cu = classes(rts)
s2 = o + u0 + u1
r2 = [(vec([(o, j)]) + vec([(j, s2)])) % 2 for j in P0 if adj(j, s2)]
c2 = classes(r2)
check(f"F5  returns: {len(P0)} routes in {len(cr)} class; next site on the column: {len(rts)} routes in classes {cu}; "
      f"second site: {len(r2)} routes in classes {c2}",
      cr == [12] and len(rts) == 4 and sorted(cu) == [1, 1, 1, 1] and len(r2) == 2)
best = 0
for phi in np.linspace(0, 2*np.pi, 4001):
    th = 2*np.pi*np.arange(3)/3 + phi; m = 12 + 8*np.cos(th) + 2*len(r2)*np.cos(2*th)
    best = max(best, m.sum()/np.sqrt(m).sum()**2)
P = np.roll(np.eye(3), 1, 0); d = 0.2222220
W = np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*d)*P + np.exp(-1j*d)*P.T); M = W @ W
check(f"F6  column process: max K = {best:.4f}; amplitude ratio 4/12 = 0.333 vs |M_10|/M_00 = {abs(M[1, 0])/abs(M[0, 0]):.3f}",
      best < 0.38 and abs(abs(M[1, 0]) - 11) < 0.01)
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
