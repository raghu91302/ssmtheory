#!/usr/bin/env python3
"""coherent_records.py -- an existence construction of coherent records (Section 7).

Each hop of a lepton on site o into an adjacent sheet goes to a site u that forms a regular tetrahedron with
o and two in-sheet neighbors v, v' of o.  Give the six in-sheet hops orthonormal records |E_v>, and give the
hop to u the record  |E_u> = e^{+-i phi} (|E_v> + |E_v'>)/sqrt 2  (sign + for the sheet above, - below).
Checks:
  T1  every adjacent-sheet neighbor u of o shares exactly two in-sheet neighbors v, v' with o; v and v' are
      neighbors, so (o, v, v', u) is a regular tetrahedron; the three pairs for the sheet above partition the
      six in-sheet neighbors, and so do the three pairs for the sheet below;
  T2  the records within each class are orthonormal (c = 0), so the filter F gives weights 6 : 3 : 3;
  T3  the three sheet outcomes are fully coherent: |e_+> = e^{i phi}|e_0>/sqrt2, |e_-> = e^{-i phi}|e_0>/sqrt2,
      so the record factors out and the family register is left in the pure state
      (sqrt6 |0> + sqrt3 e^{i phi}|+> + sqrt3 e^{-i phi}|->)/sqrt12;
  T4  the construction is defined by the lattice geometry alone, so it is the same for sources in every
      registry: the Gram matrix of the outcomes is identical for sources in registries 0, 1 and 2;
  T5  the amplitudes of T3, read as the column of a circulant, give W of Eq. (2) with delta = phi, and
      K = 2/3 at the fitted phase delta = 0.2222220 with non-negative eigenvalues;
  T6  FCC is a Bravais lattice, so the records can be labeled by the bond direction instead of the destination
      site; the outcome record |e_0>/|e_0| is then the same vector for sources in every registry.
Requires numpy.
"""
import itertools as it, numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
Bs = {tuple(b) for b in B}
lay = lambda p: int(round(sum(p)))//2
def build(o, phi):
    nb = [o + b for b in B]
    ins = [q for q in nb if lay(q) == lay(o)]
    adj = {s: [q for q in nb if lay(q) - lay(o) == s] for s in (1, -1)}
    idx = {tuple(q): i for i, q in enumerate(ins)}
    E = {tuple(q): np.eye(6)[i].astype(complex) for i, q in enumerate(ins)}
    pairs = {}
    for s in (1, -1):
        for u in adj[s]:
            pr = [v for v in ins if tuple(u - v) in Bs]
            pairs[tuple(u)] = pr
            E[tuple(u)] = np.exp(1j*s*phi)*(E[tuple(pr[0])] + E[tuple(pr[1])])/np.sqrt(2) if len(pr) == 2 else None
    return ins, adj, pairs, E
o = np.array([0, 0, 0]); phi = 0.2222220
ins, adj, pairs, E = build(o, phi)
t1 = True
for s in (1, -1):
    cover = []
    for u in adj[s]:
        pr = pairs[tuple(u)]
        t1 &= len(pr) == 2 and tuple(pr[0] - pr[1]) in Bs
        d = [np.linalg.norm(a - b) for a, b in it.combinations([o, u] + pr, 2)]
        t1 &= np.allclose(d, np.sqrt(2)); cover += [tuple(v) for v in pr]
    t1 &= sorted(cover) == sorted(tuple(v) for v in ins)
check("T1  each adjacent-sheet neighbor closes a regular tetrahedron with two in-sheet neighbors; "
      "the pairs partition the six in-sheet neighbors, above and below", t1)
def outcomes(ins, adj, E):
    e = {0: sum(E[tuple(v)] for v in ins)/np.sqrt(6)}
    for s in (1, -1): e[s] = sum(E[tuple(u)] for u in adj[s])/np.sqrt(6)
    return e
t2 = all(np.allclose([[np.vdot(E[tuple(a)], E[tuple(b)]) for b in grp] for a in grp], np.eye(len(grp)))
         for grp in (ins, adj[1], adj[-1]))
e = outcomes(ins, adj, E); w = {l: np.vdot(e[l], e[l]).real*6 for l in e}
check(f"T2  records orthonormal within each class; weights {w[0]:.3f} : {w[1]:.3f} : {w[-1]:.3f}",
      t2 and np.allclose([w[0], w[1], w[-1]], [6, 3, 3]))
L = (0, 1, -1)
G = np.array([[np.vdot(e[a], e[b]) for b in L] for a in L])
coh = [abs(G[i, j])/np.sqrt(G[i, i].real*G[j, j].real) for i, j in ((0, 1), (0, 2), (1, 2))]
fac = np.allclose(e[1], np.exp(1j*phi)*e[0]/np.sqrt(2)) and np.allclose(e[-1], np.exp(-1j*phi)*e[0]/np.sqrt(2))
check(f"T3  normalized coherence between sheets {[round(float(c), 6) for c in coh]}; the record factors out", np.allclose(coh, 1) and fac)
srcs = [np.array(s) for s in [(0, 0, 0), (1, 1, 0), (2, 1, 1), (3, 1, 0), (0, 1, 1), (1, 2, 1)]]
Gs = {}
for s in srcs:
    i_, a_, p_, E_ = build(s, phi); e_ = outcomes(i_, a_, E_)
    Gs.setdefault(lay(s) % 3, []).append(np.array([[np.vdot(e_[a], e_[b]) for b in L] for a in L]))
check(f"T4  outcome Gram matrix identical for sources in registries {sorted(Gs)}",
      sorted(Gs) == [0, 1, 2] and all(np.allclose(g, G) for v in Gs.values() for g in v))
amp = np.array([np.sqrt(w[0]), np.sqrt(w[1])*np.exp(1j*phi), np.sqrt(w[-1])*np.exp(-1j*phi)])
P = np.roll(np.eye(3), 1, 0)
W = amp[0]*np.eye(3) + amp[1]*P + amp[2]*P.T
Wref = np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*phi)*P + np.exp(-1j*phi)*P.T)
x = np.linalg.eigvalsh(W); K = (x**2).sum()/x.sum()**2
check(f"T5  W equals Eq. (2) with delta = phi; eigenvalues {np.round(x, 4)}, K = {K:.6f}",
      np.allclose(W, Wref) and np.allclose(W, W.conj().T) and x.min() >= 0 and np.isclose(K, 2/3))
Bin = [tuple(b) for b in B if lay(b) == 0]
ED = {b: np.eye(6)[i] for i, b in enumerate(Bin)}
recs = []
for src in srcs:
    v = sum(ED[tuple(q - src)] for q in (src + np.array(b) for b in B) if lay(q) == lay(src))
    recs.append(v/np.linalg.norm(v))
check(f"T6  direction-labeled records: the outcome record is the same for all {len(srcs)} sources "
      f"(registries {sorted({lay(s) % 3 for s in srcs})})", all(np.allclose(r, recs[0]) for r in recs))
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
