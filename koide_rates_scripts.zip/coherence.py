#!/usr/bin/env python3
"""coherence.py -- coherence between sheets in the output of the filter F (Section 6).

After F the state is sum_l |l> (x) |e_l>, with |e_l> = 6^{-1/2} sum_{j in D_l} |E_j>.  The family register is
coherent between sheets l and l' only to the extent that <e_l|e_l'> != 0.  Records of destinations in
different sheets are compared.
Checks:
  H1  site-resolving records (all 12 orthonormal): <e_l|e_l'> = 0 for l != l', so the family register leaves
      F as a mixture with weights 6 : 3 : 3, with no relative phase;
  H2  records at the resolution of the stacking cell (one cell holds one site of each registry): the Gram
      matrix 6 <e_l|e_l'> has diagonal 6, 3, 3 and off-diagonal entries 2, 2 and 1 or 2, so the coherence is
      partial;
  H3  the up-down entry depends on the registry of the source site, for every one of 49 placements of the
      cell boundary tried, so the output does not commute with the stacking translation;
  H4  merging the filters of different source sites: two in-sheet neighbors share 4 of their 12 destinations,
      so a source-independent filter mixes the destination sets of neighboring sources.
Requires numpy.
"""
import itertools as it, numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
lay = lambda p: int(round(sum(p)))//2
nrm = np.ones(3)/np.sqrt(3); e1 = np.array([1, -1, 0])/np.sqrt(2); e2 = np.cross(nrm, e1)
proj = lambda p: np.array([p@e1, p@e2])
a1, a2 = proj(np.array([1, -1, 0])), proj(np.array([0, 1, -1])); tau = proj(np.array([0, 1, 1]))
Minv = np.linalg.inv(np.column_stack([a1, a2]))
L = (0, 1, -1)
def gram(src, label):
    V = {l: {} for l in L}
    for b in B:
        q = src + b; l = lay(q) - lay(src); k = label(q); V[l][k] = V[l].get(k, 0) + 1
    return np.array([[sum(V[a].get(k, 0)*V[b].get(k, 0) for k in V[a]) for b in L] for a in L])
def cell_label(off):
    def f(p):
        r = lay(p) % 3
        return tuple(np.floor(Minv@(proj(np.array(p, float)) - r*tau) + off + 1e-9).astype(int))
    return f
srcs = [np.array(s) for s in [(0, 0, 0), (2, 0, 0), (1, 1, 0), (0, 1, 1), (2, 1, 1), (1, 2, 1), (2, 2, 0), (3, 1, 0)]]
# H1
G = gram(srcs[0], lambda q: tuple(q))
check(f"H1  site records: 6<e_l|e_l'> = {G.tolist()} (diagonal 6, 3, 3; no coherence between sheets)",
      np.array_equal(G, np.diag([6, 3, 3])))
# H2, H3
offs = [np.array([u, v]) for u in np.arange(7)/7 for v in np.arange(7)/7]
h2 = True; h3 = True; seen = set()
for off in offs:
    lab = cell_label(off); byreg = {}
    for s in srcs:
        g = gram(s, lab); h2 &= list(np.diag(g)) == [6, 3, 3] and g[0, 1] == 2 and g[0, 2] == 2 and g[1, 2] in (1, 2)
        byreg.setdefault(lay(s) % 3, set()).add(int(g[1, 2])); seen.add(int(g[1, 2]))
    h3 &= len({frozenset(v) for v in byreg.values()}) > 1
G0 = {lay(s) % 3: gram(s, cell_label(np.zeros(2))) for s in srcs}
for r in (0, 1, 2): print(f"     source in registry {r}: 6<e_l|e_l'> = {G0[r].tolist()}")
g = G0[0]; coh = [g[0, 1]/np.sqrt(g[0, 0]*g[1, 1]), g[1, 2]/np.sqrt(g[1, 1]*g[2, 2])]
print(f"     normalized coherence: own-up {coh[0]:.3f}, up-down {coh[1]:.3f} (1 would be full)")
check("H2  cell records: diagonal 6, 3, 3; own-up and own-down 2; up-down 1 or 2 (partial coherence)", h2)
check(f"H3  the up-down entry depends on the source registry for all {len(offs)} cell-boundary placements", h3)
# H4
o = np.array([0, 0, 0]); nb = np.array([1, -1, 0])
shared = {tuple(o + b) for b in B} & {tuple(nb + b) for b in B}
check(f"H4  two in-sheet neighbors share {len(shared)} of their 12 destinations", len(shared) == 4)
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
