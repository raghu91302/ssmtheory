#!/usr/bin/env python3
"""lift_routes.py -- the tetrahedral records from lift-triangle routes (Section 7.3).

Records are built from hop routes. A hop of a node defect from o to a neighbor d is a sum over routes; the
record of a route is the bond by which it leaves the source star (its first leg). Allowed routes: in-sheet
hops go directly; a hop into an adjacent sheet goes through the two in-sheet corners of its lift triangle
(o -> v -> u and o -> v' -> u), optionally with admixtures of the direct lift hop (a) and of the routes that
leave along a lift bond first (a').
Checks:
  L1  every neighbor u of o in an adjacent sheet touches exactly three sites of o's sheet, (o, v, v'), and sits
      above their centroid along [111]: u is the lift node of the triangle (o, v, v') in the growth rule;
  L2  a lattice mirror fixes o and u, preserves the sheets and exchanges v and v', so a symmetric hop process
      gives the two lift-triangle routes equal amplitude;
  L3  with lift-triangle routes only, the records are those of Eq. (11): in-sheet records orthonormal,
      |E_u> = (|E_v> + |E_v'>)/sqrt2; the filter gives 6:3:3 with full coherence and the global form gives
      K = 2/3; the factor sqrt2 is sqrt(number of routes) at equal amplitude and unit norm;
  L4  the direct lift hop alone gives orthogonal records and no coherence; all routes at equal amplitude give
      K = 0.467 in the global form;
  L5  admixtures shift K quadratically: 2/3 - K = a^2/6 for the direct hop and a'^2/3 for lift-first routes,
      so the measured ratio requires a < 8.6e-3 and a' < 6.1e-3.
Requires numpy.
"""
import itertools as it, numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
lay = lambda p: int(round(sum(p)))//2
adj = lambda a, b: np.sum((np.array(a) - np.array(b))**2) == 2
o = np.zeros(3, int); n111 = np.ones(3)/np.sqrt(3)
ins = [b for b in B if lay(b) == 0]; up = [b for b in B if lay(b) == 1]
l1 = True
for u in up:
    tri = [q for q in [o] + ins if adj(q, u)]
    l1 &= len(tri) == 3 and np.allclose(np.cross(u - np.mean(tri, axis=0), n111), 0)
check("L1  each adjacent-sheet neighbor is the lift node of a triangle (o, v, v') of the source sheet", l1)
mats = []
for perm in it.permutations(range(3)):
    for sg in it.product((1, -1), repeat=3):
        M = np.zeros((3, 3), int)
        for i, j in enumerate(perm): M[i, j] = sg[i]
        mats.append(M)
l2 = True
for u in up:
    v, v2 = [q for q in ins if adj(q, u)]
    l2 &= any(all(lay(M @ b) == lay(b) for b in B) and np.array_equal(M @ u, u) and np.array_equal(M @ v, v2)
              and np.array_equal(M @ v2, v) for M in mats)
check("L2  for each lift triangle a lattice mirror fixes o and u, preserves the sheets and exchanges v, v'", l2)
idx = {tuple(b): i for i, b in enumerate(B)}; cls = {tuple(b): lay(b) for b in B}
def records(a, b, c):
    E = {}
    for d in B:
        e = np.zeros(12)
        if cls[tuple(d)] == 0: e[idx[tuple(d)]] = 1.0
        else:
            e[idx[tuple(d)]] += a
            for j in B:
                if adj(j, d): e[idx[tuple(j)]] += b if cls[tuple(j)] == 0 else c
            e /= np.linalg.norm(e)
        E[tuple(d)] = e
    return E
def analyse(a, b, c):
    E = records(a, b, c)
    eo = {l: sum(E[tuple(d)] for d in B if cls[tuple(d)] == l)/np.sqrt(6) for l in (0, 1, -1)}
    w = {l: eo[l] @ eo[l] for l in eo}
    coh = [abs(eo[x] @ eo[y])/np.sqrt(w[x]*w[y]) for x, y in ((0, 1), (0, -1), (1, -1))]
    ev = np.zeros(12)
    for d in ins: ev[idx[tuple(d)]] = 1/np.sqrt(6)
    amp = {l: sum(ev @ E[tuple(d)] for d in B if cls[tuple(d)] == l) for l in (0, 1, -1)}
    Kg = (amp[0]**2 + 2*amp[1]**2)/(3*amp[0]**2)
    return E, w, coh, Kg
E, w, coh, Kg = analyse(0, 1, 0)
G_ok = all(np.isclose(E[tuple(v)] @ E[tuple(v2)], 0) for v, v2 in it.combinations(ins, 2))
tet_ok = all(np.isclose(E[tuple(u)] @ E[tuple(v)], 1/np.sqrt(2)) for u in up for v in ins if adj(u, v))
check(f"L3  lift-triangle routes: weights {6*w[0]:.0f}:{6*w[1]:.0f}:{6*w[-1]:.0f}, coherence {np.round(coh, 6)}, K = {Kg:.6f}",
      G_ok and tet_ok and np.allclose([6*w[0], 6*w[1], 6*w[-1]], [6, 3, 3]) and np.allclose(coh, 1) and np.isclose(Kg, 2/3))
_, _, cd, Kd = analyse(1, 0, 0); _, _, _, Ka = analyse(1, 1, 1)
check(f"L4  direct lift hop: coherence {np.round(cd, 3)}; all routes equal: K = {Ka:.4f}", np.allclose(cd, 0) and abs(Ka - 0.4667) < 1e-3)
sl = [(2/3 - analyse(x, 1, 0)[3])/x**2 for x in (1e-2, 1e-3)] + [(2/3 - analyse(0, 1, x)[3])/x**2 for x in (1e-2, 1e-3)]
def bound(f):
    lo, hi = 1e-8, 1.0
    for _ in range(80):
        m = np.sqrt(lo*hi); lo, hi = (m, hi) if abs(2/3 - f(m)) < 1.24e-5 else (lo, m)
    return lo
ba, bc = bound(lambda x: analyse(x, 1, 0)[3]), bound(lambda x: analyse(0, 1, x)[3])
check(f"L5  2/3 - K = {sl[1]:.4f} a^2 and {sl[3]:.4f} a'^2; bounds a < {ba:.1e}, a' < {bc:.1e}",
      np.allclose(sl[:2], 1/6, rtol=2e-2) and np.allclose(sl[2:], 1/3, rtol=2e-2) and 8e-3 < ba < 9e-3 and 5.5e-3 < bc < 6.5e-3)
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
