#!/usr/bin/env python3
"""make_figs.py -- Figures 1 (fig_fcc.pdf) and 2 (fig_K.pdf). Requires numpy and matplotlib."""
import itertools as it, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 12, 'font.family': 'serif', 'mathtext.fontset': 'stix', 'pdf.fonttype': 42})
m = np.array([0.51099895, 105.6583755, 1776.93]); sm = np.array([0, 0, 0.09])
Km = m.sum()/np.sqrt(m).sum()**2; dK = abs((m + sm).sum()/np.sqrt(m + sm).sum()**2 - Km); Klow = Km - 2*dK
nk = np.array([6, 3, 3])
def K_c(c): r = nk + c*nk*(nk - 1); return (1 + 2*r[1]/r[0])/3
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
lay = lambda p: int(round(sum(p)))//2
Lb = 12
sites = [np.array(p) for p in it.product(range(-Lb, Lb + 1), repeat=3) if sum(p) == 0 and max(map(abs, p)) <= Lb - 2]
def K_xi(xi):
    w = np.array([np.exp(-(p@p/2)/(4*xi**2)) for p in sites]); w /= np.linalg.norm(w)
    amp = {}
    for p, a in zip(sites, w):
        for b in B:
            q = tuple(p + b); amp[q] = amp.get(q, 0) + a
    r = {0: 0, 1: 0, -1: 0}
    for q, a in amp.items(): r[lay(q)] += a*a
    return (1 + (r[1] + r[-1])/r[0])/3
fig, ax = plt.subplots(1, 2, figsize=(10, 3.9))
c = np.logspace(-7, 0, 300)
ax[0].plot(c, [K_c(x) for x in c], 'k-', lw=1.8)
ax[0].axvline(1.2e-5, color='tab:blue', ls='--', lw=1.2)
ax[0].text(1.6e-5, 0.53, '$c < 1.2\\times10^{-5}$', color='tab:blue', fontsize=11)
ax[0].set_xscale('log'); ax[0].set_xlabel('record overlap $c$'); ax[0].set_ylabel('$K$')
ax[0].set_title('(a) filter $F$, localized source', fontsize=12)
xi = np.concatenate([np.linspace(0.12, 0.6, 25), np.linspace(0.65, 4, 20)])
ax[1].plot(xi, [K_xi(x) for x in xi], 'k-', lw=1.8)
ax[1].axvline(0.206, color='tab:blue', ls='--', lw=1.2)
ax[1].text(0.26, 0.53, '$\\xi < 0.21$', color='tab:blue', fontsize=11)
ax[1].set_xscale('log'); ax[1].set_xticks([0.2, 0.5, 1, 2, 4]); ax[1].set_xticklabels(['0.2', '0.5', '1', '2', '4']); ax[1].minorticks_off(); ax[1].set_xlabel('source width $\\xi$ (nearest-neighbor spacings)')
ax[1].set_title('(b) registry measurement, spread source', fontsize=12)
for a in ax:
    a.axhline(2/3, color='0.5', ls=':', lw=1); a.axhline(1/2, color='0.5', ls=':', lw=1); a.set_ylim(0.48, 0.69)
    a.text(0.02, 2/3 + 0.006, '$2/3$', transform=a.get_yaxis_transform(), ha='left', fontsize=10, color='0.35')
    a.text(0.02, 0.5 + 0.006, '$1/2$', transform=a.get_yaxis_transform(), ha='left', fontsize=10, color='0.35')
plt.tight_layout(); plt.savefig('../fig_K.pdf'); plt.close()
print("figure written: fig_K.pdf")
# ---------- Fig 1: the bond split and the tetrahedral pairing, projected on the (111) plane
from matplotlib.patches import Polygon
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
nrm = np.ones(3)/np.sqrt(3); e1 = np.array([1, -1, 0])/np.sqrt(2); e2 = np.cross(nrm, e1)
pj = lambda p: np.array([p@e1, p@e2])
cls = lambda b: int(sum(b))//2
adjb = lambda a, b: np.sum((a - b)**2) == 2
ins = [b for b in B if cls(b) == 0]; up = [b for b in B if cls(b) == 1]; dn = [b for b in B if cls(b) == -1]
col = {0: '#1f5fbf', 1: '#d1495b', -1: '#2e8b57'}
fig, ax = plt.subplots(1, 3, figsize=(12, 4.2))
def base(a, title):
    for b in ins:
        a.plot(*zip(pj(np.zeros(3)), pj(b)), color='0.8', lw=0.8, zorder=1)
    hexa = sorted(ins, key=lambda b: np.arctan2(*pj(b)[::-1]))
    a.add_patch(Polygon([pj(b) for b in hexa], closed=True, fill=False, ec='0.75', lw=0.8, ls=':'))
    a.plot(*pj(np.zeros(3)), 'ko', ms=9, zorder=5); a.text(0.1, -0.22, '$o$', fontsize=17)
    for b in ins: a.plot(*pj(b), 's', ms=13, color=col[0], mec='k', zorder=4)
    a.set_aspect('equal'); a.set_xlim(-1.62, 1.62); a.set_ylim(-1.62, 1.62); a.axis('off')
    a.set_title(title, fontsize=16)
base(ax[0], '(a) the $6:3:3$ split')
for b in up: ax[0].plot(*pj(b), '^', ms=15, color=col[1], mec='k', zorder=4)
for b in dn: ax[0].plot(*pj(b), 'v', ms=15, color=col[-1], mec='k', zorder=4)
for k_, (lst, mk, title) in enumerate(((up, '^', '(b) tetrahedra, sheet above'),
                                        (dn, 'v', '(c) tetrahedra, sheet below'))):
    a = ax[k_ + 1]; base(a, title)
    shades = ['#f4c7cc', '#f9e0b8', '#cde3f5'] if mk == '^' else ['#c9e8d3', '#e6d9f2', '#f9e0b8']
    for s, u in zip(shades, lst):
        pr = [v for v in ins if adjb(u, v)]
        a.add_patch(Polygon([pj(np.zeros(3)), pj(pr[0]), pj(u), pj(pr[1])], closed=True, fc=s, ec='k', lw=1.0, alpha=0.9, zorder=2))
        for v in pr: a.plot(*zip(pj(u), pj(v)), color='k', lw=1.0, zorder=3)
        a.plot(*pj(u), mk, ms=15, color=col[1 if mk == '^' else -1], mec='k', zorder=4)
plt.tight_layout(); plt.savefig('../fig_fcc.pdf'); plt.close()
print("figure written: fig_fcc.pdf")
