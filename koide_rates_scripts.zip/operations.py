#!/usr/bin/env python3
"""operations.py -- three operations on the state after one hop, and the filter F (Section 4).

A lepton on site o hops with amplitude t = 1 to its 12 FCC neighbors; neighbor j leaves the record |E_j>.
The records of the destinations within one hop class have pairwise overlap c (Gram matrix (1-c) I + c J);
records of different classes are taken orthogonal.  The post-hop state is |Psi> = sum_j |j>|E_j>.
Checks:
  O1  registry measurement, p_l = <Psi|Pi_l|Psi>: 6 : 3 : 3 for every c (K = 2/3);
  O2  projection onto the normalized combination |S_l> of the n_l destinations: p_l = 1 + (n_l - 1) c,
      i.e. 1 : 1 : 1 at c = 0 and 6 : 3 : 3 at c = 1;
  O3  the filter F = 6^{-1/2} sum_l |l> sum_{j in D_l} <j| satisfies F F^dagger = diag(1, 1/2, 1/2) and has
      norm 1, so it is a contraction (a Kraus operator of some channel);
  O4  the outcome weights of F are p_l = [n_l + c n_l (n_l - 1)]/6: 6 : 3 : 3 at c = 0 and 36 : 9 : 9 at c = 1;
  O5  registry measurement from a source spread over its own sheet with a Gaussian profile of width xi
      (in nearest-neighbor spacings) interpolates from 6 : 3 : 3 (xi -> 0) toward 36 : 9 : 9; the measured
      ratio requires xi below about 0.2 at two standard deviations (|psi|^2 ~ exp(-d^2/2 xi^2)).
Requires numpy.
"""
import itertools as it, numpy as np
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
B = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
lay = lambda p: int(round(sum(p)))//2
o = np.array([0, 0, 0])
cls = [lay(o + b) - lay(o) for b in B]                      # 0 own sheet, +1 up, -1 down
D = {l: [i for i in range(12) if cls[i] == l] for l in (0, 1, -1)}
n = {l: len(D[l]) for l in D}
Kof = lambda p: (1 + 2*((p[1] + p[-1])/2/p[0]))/3
def records(c):
    """12 record vectors: overlap c within a class, 0 between classes."""
    E = np.zeros((12, 12))
    for l, idx in D.items():
        G = (1 - c)*np.eye(len(idx)) + c*np.ones((len(idx), len(idx)))
        L = np.linalg.cholesky(G + 1e-15*np.eye(len(idx)))
        for a, i in enumerate(idx): E[i, idx] = L[a]
    return E                                                 # row i = |E_i> in a 12-dim record space
def psi(c):
    E = records(c); return np.array([np.kron(np.eye(12)[i], E[i]) for i in range(12)]).sum(0)
def site_op(A):                                              # operator on sites, identity on records
    return np.kron(A, np.eye(12))
cs = (0.0, 0.3, 1.0)
# O1
good = True
for c in cs:
    v = psi(c); p = {l: v@site_op(np.diag([1.0 if cls[i] == l else 0 for i in range(12)]))@v for l in D}
    good &= all(np.isclose(p[l], n[l]) for l in D)
check(f"O1  registry measurement gives {[n[l] for l in (0, 1, -1)]} for c in {cs}; K = 2/3", good and np.isclose(Kof(n), 2/3))
# O2
good = True
for c in cs:
    v = psi(c)
    for l in D:
        S = np.zeros(12); S[D[l]] = 1/np.sqrt(n[l])
        amp = np.kron(S, np.eye(12)) @ v                     # environment vector <S_l|Psi>
        good &= np.isclose(amp@amp, 1 + (n[l] - 1)*c)
check("O2  projection onto the normalized combination: p_l = 1 + (n_l - 1) c (1 : 1 : 1 at c = 0)", good)
# O3
F = np.zeros((3, 12)); lab = {0: 0, 1: 1, -1: 2}
for i in range(12): F[lab[cls[i]], i] = 1/np.sqrt(6)
FFd = F@F.T; nrmF = np.linalg.norm(F, 2)
check(f"O3  F F^dagger = diag{tuple(float(x) for x in np.round(np.diag(FFd), 3))}, off-diagonal 0, norm {nrmF:.3f}",
      np.allclose(FFd, np.diag([1, .5, .5])) and np.isclose(nrmF, 1))
# O4
good = True; rows = []
for c in cs:
    out = np.kron(F, np.eye(12)) @ psi(c)                    # (3 x 12) outcome state, family label x record
    out = out.reshape(3, 12); p = {l: out[lab[l]]@out[lab[l]] for l in D}
    good &= all(np.isclose(p[l], (n[l] + c*n[l]*(n[l] - 1))/6) for l in D); rows.append((c, Kof(p)))
check("O4  F outcome weights p_l = [n_l + c n_l(n_l - 1)]/6; K = " + ", ".join(f"{K:.4f} (c = {c})" for c, K in rows),
      good and np.isclose(rows[0][1], 2/3) and np.isclose(rows[-1][1], 1/2))
# O5
Lb = 12
sites = [np.array(p) for p in it.product(range(-Lb, Lb + 1), repeat=3) if sum(p) == 0 and max(map(abs, p)) <= Lb - 2]
def K_xi(xi):
    w = np.array([np.exp(-(p@p/2)/(4*xi**2)) for p in sites]); w /= np.linalg.norm(w)
    amp = {}
    for p, a in zip(sites, w):
        for b in B:
            q = tuple(p + b); amp[q] = amp.get(q, 0) + a
    r = {0: 0, 1: 0, -1: 0}
    for q, a in amp.items(): r[lay(q)] += a*a
    return Kof(r), r
m = np.array([0.51099895, 105.6583755, 1776.93]); sm = np.array([0, 0, 0.09])
Km = m.sum()/np.sqrt(m).sum()**2; dK = abs((m + sm).sum()/np.sqrt(m + sm).sum()**2 - Km); Klow = Km - 2*dK
print("     xi     K(xi)")
for xi in (0.2, 0.25, 0.3, 0.5, 1, 2, 4): print(f"     {xi:<6g} {K_xi(xi)[0]:.6f}")
lo, hi = 0.2, 0.4
for _ in range(30):
    mid = (lo + hi)/2; lo, hi = (mid, hi) if K_xi(mid)[0] > Klow else (lo, mid)
K4, r4 = K_xi(4)
nb = 6*np.exp(-1/(2*lo**2)); print(f"     at xi = {lo:.3f} the six in-sheet neighbors carry {nb/(1 + nb):.1e} of the probability")
check(f"O5  K(xi) falls from 2/3 toward 1/2 (xi = 4: rates {r4[0]:.1f} : {r4[1]:.1f} : {r4[-1]:.1f}); "
      f"K within 2 sigma requires xi < {lo:.3f}", abs(K_xi(0.15)[0] - 2/3) < 1e-6 and K4 < 0.51 and 0.15 < lo < 0.25)
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
