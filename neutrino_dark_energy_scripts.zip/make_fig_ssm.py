"""Figure 1: the Selection-Stitch Model in brief.
(a) the 12 FCC bonds of a site (cuboctahedron); (b) the 24 D4 bonds, projected by dropping time, colored by
orthogonal frame (16-cell); (c) the (t,x) section of D4 with the frame-A neutrino string."""
import itertools, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection
plt.rcParams.update({"font.size":8,"font.family":"serif"})
BLUE="#2a6fb0"; COL={"A":"#c0392b","B":"#2a8a4a","C":"#7a4fb0"}; GREY="#9a9a9a"
R=[np.array(v) for v in itertools.product([-1,0,1],repeat=4) if sum(map(abs,v))==2]
def frame(r):
    nz=frozenset(np.nonzero(r)[0])
    return "A" if nz in ({0,1},{2,3}) else "B" if nz in ({0,2},{1,3}) else "C"
fig=plt.figure(figsize=(7.0,2.5))
# (a) FCC
ax=fig.add_subplot(1,3,1,projection="3d")
S=[r[1:] for r in R if r[0]==0]
P=np.array(S,float)
segs=[[P[i],P[j]] for i,j in itertools.combinations(range(12),2) if np.isclose(np.linalg.norm(P[i]-P[j]),np.sqrt(2))]
ax.add_collection3d(Line3DCollection(segs,colors=GREY,linewidths=0.5))
for p in P: ax.plot([0,p[0]],[0,p[1]],[0,p[2]],color=BLUE,lw=0.9)
ax.scatter(*P.T,color=BLUE,s=10,depthshade=False); ax.scatter([0],[0],[0],color="k",s=14)
ax.set_title("(a) FCC slice: 12 bonds",fontsize=8)
# (b) D4 projected
bx=fig.add_subplot(1,3,2,projection="3d")
for r in R:
    p=r[1:].astype(float)
    if r[0]!=0: p=p*1.0
    c=COL[frame(r)]
    bx.plot([0,p[0]],[0,p[1]],[0,p[2]],color=c,lw=0.9 if r[0]==0 else 0.9,ls="-" if r[0]==0 else "--")
    bx.scatter(*p,color=c,s=10 if r[0]==0 else 16,marker="o" if r[0]==0 else "s",depthshade=False)
bx.scatter([0],[0],[0],color="k",s=14)
bx.set_title("(b) $D_4$: 24 bonds, three frames",fontsize=8)
for a in (ax,bx):
    a.set_box_aspect((1,1,1)); a.set_axis_off(); a.view_init(18,32)
    a.set_xlim(-1.1,1.1); a.set_ylim(-1.1,1.1); a.set_zlim(-1.1,1.1)
# (c) (t,x) section
cx=fig.add_subplot(1,3,3)
pts=[(x,t) for t in range(0,5) for x in range(-2,3) if (t+x)%2==0]
for x,t in pts:
    for dx in (-1,1):
        if (x+dx,t+1) in pts: cx.plot([x,x+dx],[t,t+1],color=GREY,lw=0.6,zorder=1)
cx.scatter([p[0] for p in pts],[p[1] for p in pts],color="k",s=9,zorder=3)
path=[(0,0),(1,1),(0,2),(1,3),(0,4)]
cx.plot([p[0] for p in path],[p[1] for p in path],color=COL["A"],lw=2.0,zorder=2,label="neutrino string (frame A)")
for (px,pt) in path:
    sq=np.array([(px,pt-1),(px+1,pt),(px,pt+1),(px-1,pt),(px,pt-1)])
    cx.plot(sq[:,0],sq[:,1],color=COL["A"],lw=0.6,ls=":",zorder=1)
sq=np.array([(1,0),(2,1),(1,2),(0,1),(1,0)])
cx.fill(sq[:,0],sq[:,1],color=COL["A"],alpha=0.13,lw=0)
cx.text(1.18,0.55,"cell",fontsize=7,color=COL["A"])
cx.annotate("",xy=(-2.45,4.2),xytext=(-2.45,0),arrowprops=dict(arrowstyle="->",lw=0.8)); cx.text(-2.75,2.0,"$t$",fontsize=8)
cx.set_xlim(-2.9,2.6); cx.set_ylim(-1.1,5.1); cx.set_aspect("equal"); cx.axis("off")
cx.set_xlabel("$x$")
cx.text(2.0,-0.9,"$x$",fontsize=8)
cx.set_title("(c) $(t,x)$ section: null bonds",fontsize=8)
cx.legend(fontsize=6.3,frameon=False,loc="lower left",bbox_to_anchor=(-0.02,-0.12))
fig.tight_layout(w_pad=0.2)
fig.savefig("fig_ssm.pdf",bbox_inches="tight"); fig.savefig("fig_ssm.png",dpi=160,bbox_inches="tight")
print("ok")
