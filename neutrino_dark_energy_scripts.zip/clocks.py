"""Section 4.5: compatibility of the two clock prescriptions.
Bond rule with tick tau = alpha*L/c:  m1 = hbar/tau  ->  L = hbar c/(alpha m1).
Neutrino action in one orthogonal-frame four-cell (4-volume L^4): m1 * T,  T = beta*L/c.
Vacuum action in the same cell: rho * L^4 / c.   Equality:  rho = beta * alpha^3 * m1^4/(hbar c)^3.
Clocks:  FCC  alpha = 4      (light crosses K/d = 4 bond lengths per tick)
         D4   alpha = 2 sqrt2 (light crosses K/d = 4 null bonds per tick; slice spacing L/(sqrt2 c))
Durations: one tick (beta = alpha); the cell's time extent along the time axis (beta = sqrt2, two slices);
           its mean time extent (beta = 1/sqrt2, one slice); one Euclidean edge length (beta = 1).
"""
import numpy as np
r2 = np.sqrt(2)
meas, dmeas = 63.3, 4.4             # rho/m1^4 from nde_numbers.py (ratio 2.821 +- 0.048)
# geometry check: a worldline along the time axis crosses one frame cell every two slices
# frame cells in the (t,x) plane: lattice spanned by (1,1),(1,-1) [units L/sqrt2]; time axis hits lattice points every 2 units
pts = [(t, 0) for t in range(0, 9) if (t + 0) % 2 == 0]
print("time-axis lattice points (t in slices):", [p[0] for p in pts], "-> one cell per 2 slices; tick of D4 clock = 4 slices = 2 cells")
print("mean time extent of a cell = area/width = (L^2)/(sqrt2 L) = L/sqrt2 -> beta = 1/sqrt2")
print()
rows = []
for cname, a in [("FCC tick 4L/c", 4.0), ("D4 tick 4 null steps = 2sqrt2 L/c", 2*r2)]:
    for dname, b, consistent in [("one tick", a, None), ("cell time extent sqrt2 L/c", r2, None),
                                 ("cell mean extent L/(sqrt2 c)", 1/r2, None), ("Euclidean edge L/c", 1.0, None)]:
        k = b*a**3
        rows.append((cname, dname, k, (k-meas)/dmeas, k**0.25))
for c, d, k, s, r in rows:
    print(f"{c:36s} {d:30s} coef {k:7.2f}  ratio rho^1/4/m1 {r:5.3f}  pull {s:+7.1f} sigma")
import itertools
R=[np.array(v)/np.sqrt(2) for v in itertools.product([-1,0,1],repeat=4) if sum(abs(x) for x in v)==2]

kd = sum(np.outer(r,r) for r in R)[0,0]
print(f"\nEuclidean D4: structure tensor = {kd:.0f} x identity (K/d = 24/4)")
k = 1.0*kd**3
print(f"fully Euclidean D4 tick 6L/c, one Euclidean bond step per cell: coef {k:.0f}, ratio {k**0.25:.3f}, pull {(k-meas)/dmeas:+.1f} sigma")
print()
print("Notes: (FCC, Euclidean edge) is the reading of Eq. (10); (D4, one tick) also gives 64 but assigns a")
print("whole tick to one cell, while the time-axis worldline crosses two cells per tick; assigning per crossing")
print("gives (D4, cell time extent) = 32.")
