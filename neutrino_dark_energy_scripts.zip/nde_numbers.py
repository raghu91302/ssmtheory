#!/usr/bin/env python3
"""All numbers of the paper (Sections 2-5): K = 1/2 neutrino masses, the dark-energy scale, the relation
rho_L = 64 m1^4, the inverse prediction, the solar-splitting prediction, m_beta, m_betabeta, inverted ordering."""
import numpy as np
from scipy.optimize import brentq
rng = np.random.default_rng(2026)
# inputs: global fit including the first JUNO data (normal ordering)
D21, sD21 = 7.530e-5, 0.097e-5
D31, sD31 = 2.521e-3, 0.020e-3          # NuFIT-6.1 (without SK-atm), as quoted in arXiv:2601.09791
s12, s13 = 0.3096, 0.0220                   # sin^2 theta12, sin^2 theta13
h0, sh = 0.6736, 0.0054; omh2, somh2 = 0.1430, 0.0011    # Planck 2018 LCDM
Mp = 2.435e18; H100 = 100e3/3.0857e22*6.582e-25           # GeV
u = lambda d: np.sort((1+np.cos(d+2*np.pi*np.arange(3)/3))**2)     # m_k / a^2 (sorted)
def masses(d21, d31):
    f = lambda d: (lambda x: (x[1]**2-x[0]**2)/(x[2]**2-x[0]**2))(u(d)) - d21/d31
    d = brentq(f, 0.2, 0.45); x = u(d); a2 = np.sqrt(d31/(x[2]**2-x[0]**2)); return d, a2, a2*x
def eL(h, om): return ((h*h-om)*3*H100**2*Mp**2)**0.25*1e9     # eV
d, a2, m = masses(D21, D31)
print(f"K=1/2 NO: delta_nu={d:.4f}  a^2={a2*1e3:.3f} meV  m={np.round(m*1e3,3)} meV  sum={m.sum()*1e3:.2f} meV  eps=pi/3-delta={np.pi/3-d:.4f}")
N = 4000
M = np.array([masses(rng.normal(D21,sD21), rng.normal(D31,sD31))[2] for _ in range(N)])
E = eL(rng.normal(h0,sh,N), rng.normal(omh2,somh2,N))
print(f"m1 = {M[:,0].mean()*1e3:.3f} +- {M[:,0].std()*1e3:.3f} meV ; rho^1/4 (Planck) = {E.mean()*1e3:.3f} +- {E.std()*1e3:.3f} meV")
R = E/M[:,0]; print(f"ratio rho^1/4/m1 = {R.mean():.3f} +- {R.std():.3f}  (2 sqrt2 = {2*np.sqrt(2):.4f}, pull {(R.mean()-2*np.sqrt(2))/R.std():+.2f} sigma)")
inv = 2*np.sqrt(2)*M[:,0]; print(f"inverse prediction rho^1/4 = 2 sqrt2 m1 = {inv.mean()*1e3:.3f} +- {inv.std()*1e3:.3f} meV ; Planck {E.mean()*1e3:.3f} +- {E.std()*1e3:.3f}")
# solar-splitting prediction
def predict(d31, rho14):
    m1t = rho14/(2*np.sqrt(2))
    g = lambda dd: (lambda x: x[0]/np.sqrt(x[2]**2-x[0]**2))(u(dd)) - m1t/np.sqrt(d31)
    dd = brentq(g, 0.2, np.pi/3-1e-7); x = u(dd); a = np.sqrt(d31/(x[2]**2-x[0]**2)); mm = a*x
    return mm[1]**2-mm[0]**2, mm
P = np.array([predict(rng.normal(D31,sD31), e)[0] for e in E])
print(f"predicted dm21 = {P.mean()*1e5:.3f} +- {P.std()*1e5:.3f} e-5 eV^2 ; measured {D21*1e5:.3f} +- {sD21*1e5:.3f} ; pull {(P.mean()-D21)/np.hypot(P.std(),sD21):+.2f} sigma")
for h in (0.6736, 0.70, 0.73):
    print(f"   h = {h}: rho^1/4 = {eL(h,omh2)*1e3:.3f} meV, predicted dm21 = {predict(D31, eL(h,omh2))[0]*1e5:.3f} e-5")
pm = predict(D31, eL(h0,omh2))[1]; print(f"masses under the relation: {np.round(pm*1e3,3)} meV, sum {pm.sum()*1e3:.2f} meV")
# m_beta and m_betabeta (K=1/2 masses)
c12, c13 = 1-s12, 1-s13
mb = np.sqrt(c12*c13*m[0]**2 + s12*c13*m[1]**2 + s13*m[2]**2)
a1, a2_, a3 = c12*c13*m[0], s12*c13*m[1], s13*m[2]
ph = np.linspace(0, 2*np.pi, 721)
P1, P2 = np.meshgrid(ph, ph); mbb = np.abs(a1 + a2_*np.exp(1j*P1) + a3*np.exp(1j*P2))
print(f"m_beta = {mb*1e3:.2f} meV ; m_betabeta in [{mbb.min()*1e3:.2f}, {mbb.max()*1e3:.2f}] meV")
# inverted ordering: K = 1/2 gives the lightest mass ~ 0 -> relation impossible
D32 = -2.484e-3
def io(d21, d32):
    # IO: m3 lightest; m1, m2 heavy, m2^2 - m1^2 = d21, m2^2 - m3^2 = |d32|
    f = lambda d: (lambda x: (x[2]**2-x[1]**2)/(x[2]**2-x[0]**2))(u(d)) - d21/abs(d32)
    xs = np.linspace(0.001, np.pi/3-0.001, 4000); v = [f(t) for t in xs]
    r = [brentq(f, xs[i], xs[i+1]) for i in range(len(xs)-1) if v[i]*v[i+1] < 0]
    out = []
    for dd in r:
        x = u(dd); a = np.sqrt(abs(d32)/(x[2]**2-x[0]**2)); out.append(a*x)
    return out
for mm in io(D21, D32):
    print(f"IO solution: masses {np.round(mm*1e3,4)} meV ; lightest {mm[0]*1e3:.3e} meV -> 2 sqrt2 m_lightest = {2*np.sqrt(2)*mm[0]*1e3:.4f} meV")
print(f"L_nu = hbar c/(4 m1) = {197.3269804e-9/(4*m[0])*1e6:.1f} micron ; dark-energy length hbar c/rho^1/4 = {197.3269804e-9/eL(h0,omh2)*1e6:.1f} micron")

# Hubble dependence with uncertainty (SH0ES h = 0.7304 +- 0.0104) and sensitivity to dm31
P2 = np.array([predict(rng.normal(D31,sD31), eL(rng.normal(0.7304,0.0104), rng.normal(omh2,somh2)))[0] for _ in range(3000)])
print(f"SH0ES h: predicted dm21 = {P2.mean()*1e5:.3f} +- {P2.std()*1e5:.3f} e-5 ; pull {(P2.mean()-D21)/np.hypot(P2.std(),sD21):+.2f} sigma")
p1 = predict(D31, eL(h0,omh2))[0]; p2 = predict(D31-0.01e-3, eL(h0,omh2))[0]
print(f"slope: d(dm21)/d(dm31) = {(p1-p2)*1e5:.3f} e-5 per 0.01e-3 ; with dm31 = 2.511e-3: {predict(2.511e-3, eL(h0,omh2))[0]*1e5:.3f} e-5")
# error budget of the prediction
Pa = np.array([predict(rng.normal(D31,sD31), eL(h0,omh2))[0] for _ in range(2000)])
Pb = np.array([predict(D31, eL(rng.normal(h0,sh), omh2))[0] for _ in range(2000)])
print(f"error budget: from dm31 {Pa.std()*1e5:.3f}, from h {Pb.std()*1e5:.3f} (e-5 eV^2)")

# --- inverted forms used in the summary table (Section 5) ---
rng2 = np.random.default_rng(7)
inv14 = 2*np.sqrt(2)*M[:,0]                                   # rho^1/4 predicted from neutrino data (eV)
om_s = rng2.normal(omh2, 0.0011, len(inv14))
h_inv = np.sqrt(inv14**4*1e-36/(3*H100**2*Mp**2) + om_s)       # eV^4 -> GeV^4
print(f"H0 implied by the relation with Planck Omega_m h^2: {h_inv.mean()*100:.1f} +- {h_inv.std()*100:.1f} km/s/Mpc ; "
      f"vs SH0ES 73.0 +- 1.0: {(0.730-h_inv.mean())/np.hypot(h_inv.std(),0.010):.1f} sigma")
m1_rho = E/(2*np.sqrt(2)); print(f"m1 from rho_Lambda alone = rho^1/4/(2 sqrt2) = {m1_rho.mean()*1e3:.3f} +- {m1_rho.std()*1e3:.3f} meV")
