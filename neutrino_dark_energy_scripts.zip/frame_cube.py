"""Cubes inside D4 (Section 4.3 of the paper): no orthogonal triple of spatial (FCC) bonds;
three orthogonal frames, each pairing time (axis 0) with one spatial axis; volumes of the frame cells."""
import itertools, numpy as np
R=[np.array(v) for v in itertools.product([-1,0,1],repeat=4) if sum(abs(x) for x in v)==2]
assert len(R)==24
sp=[r for r in R if r[0]==0]
tri=[c for c in itertools.combinations(sp,3) if all(np.dot(a,b)==0 for a,b in itertools.combinations(c,2))]
print("spatial (FCC) roots:",len(sp)," mutually orthogonal spatial triples:",len(tri))
# orthogonal frames: sets of 4 mutually orthogonal roots up to sign
frames=set()
for c in itertools.combinations(R,4):
    if all(np.dot(a,b)==0 for a,b in itertools.combinations(c,2)):
        frames.add(frozenset(frozenset([tuple(r),tuple(-r)]) for r in c))
frames=list(frames)
print("orthogonal frames (unordered, up to sign):",len(frames))
# group by support pairing
pairings={}
for f in frames:
    sup=frozenset(frozenset(np.nonzero(np.array(next(iter(p))))[0]) for p in f)
    pairings.setdefault(sup,0); pairings[sup]+=1
for s,n in pairings.items():
    print("  pairing",sorted(sorted(x) for x in s),"frames:",n)
L=np.sqrt(2)
# example frame {01|23}
F=np.array([[1,1,0,0],[1,-1,0,0],[0,0,1,1],[0,0,1,-1]])
print("4-volume of frame tesseract =",abs(np.linalg.det(F)),"= L^4 =",L**4, "; D4 covolume 2 -> sites per cell:",abs(np.linalg.det(F))/2)
eta=np.diag([-1,1,1,1])
print("Lorentzian norms of frame legs:",[int(v@eta@v) for v in F],"(t-x legs null)")
# 3-cube using one tilted leg + two spatial legs
C=F[[0,2,3]]
G=C@C.T; Gl=C@eta@C.T
print("tilted 3-cube: Euclidean 3-volume",np.sqrt(np.linalg.det(G)),"(=L^3=%.3f)"%L**3,
      " Lorentzian 3-volume^2",np.linalg.det(Gl),
      " spatial projection volume",abs(np.linalg.det(C[:,1:])),"(=L^3/sqrt2=%.3f)"%(L**3/np.sqrt(2)))
