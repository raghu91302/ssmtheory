import numpy as np
m1, eL = 0.7938, 2.239   # meV
# rho = m1c^2 / V_cell with the bond quantum hbar c/(k s_tick) = m1 c^2  ->  s_tick = lambda/k ; V_cell in units of s_tick^3
rows = [
 ("FCC tick (K/d=4), cube of edge L (D4 tesseract face)",            4, 1.0),
 ("cubic <100> node-void network, its own tick (K/d=6/3=2), cell s^3", 2, 1.0),
 ("FCC tick, cubic <100> cell of side L/sqrt2",                       4, (1/np.sqrt(2))**3),
 ("FCC tick, conventional FCC cube (side sqrt2 L)",                   4, (np.sqrt(2))**3),
 ("FCC tick, cube of the 8 tetrahedral voids (side L/sqrt2)",         4, (1/np.sqrt(2))**3),
 ("D4 null-bond shadow (dx=dt), its own tick, cell (L/sqrt2)^3",      1, 1.0),
]
print(f"{'cube structure':66s} {'coef':>7s} {'rho^1/4':>8s} {'vs obs':>7s}")
for name,k,v in rows:
    coef = k**3 / v
    p = coef**0.25*m1
    print(f"{name:66s} {coef:7.1f} {p:8.3f} {100*(p/eL-1):+6.1f}%")
