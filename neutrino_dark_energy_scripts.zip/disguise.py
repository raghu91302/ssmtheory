# Are the two readings of 2*sqrt2 the same mechanism?  Generalize to D_n slices (n space dims, spacetime n+1).
#  bond-rule reading:  rho = (K/n)^n m^(n+1)  ->  rho^(1/(n+1)) / m = (K/n)^(n/(n+1)),   K = 2n(n-1) for D_n
#  diagonal reading:   (diagonal of (n+1)-cube with bond edge L) / (cubic spacing s) = sqrt(n+1) * L/s = sqrt(n+1)*sqrt2
import numpy as np
print(f"{'n':>2s} {'K':>3s} {'K/n':>5s} {'bond-rule':>10s} {'diagonal':>9s}")
for n in range(2,8):
    K=2*n*(n-1); a=(K/n)**(n/(n+1)); b=np.sqrt(n+1)*np.sqrt(2)
    print(f"{n:2d} {K:3d} {K/n:5.1f} {a:10.4f} {b:9.4f}  {'EQUAL' if abs(a-b)<1e-9 else ''}")
