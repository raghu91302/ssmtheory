import numpy as np
hbarc = 197.3269804e-9   # eV m
H100=100e3/3.0857e22*6.582e-25; Mp=2.435e18
eL = ((0.6736**2-0.1430)*3*H100**2*Mp**2)**0.25*1e9   # eV
m1 = 0.7938e-3                                          # eV, K=1/2 normal ordering (NuFIT-6.1 splittings)
K, d = 12, 3
# (P2): light crosses K/d = 4 bonds per tick, each bond carries one quantum hbar/tau = hbar c/(4L).
# Set the bond quantum equal to the lightest neutrino's rest energy: hbar c/(4 L_nu) = m1 c^2.
L_nu = hbarc/((K/d)*m1)
print(f"L_nu = hbar c/(4 m1) = {L_nu*1e6:.1f} micron ; tick c*tau = 4 L_nu = {4*L_nu*1e6:.1f} micron = reduced Compton wavelength of nu_1")
cands = {"one quantum per cube L^3      ": 1.0,
         "one quantum per FCC site (L^3/sqrt2)": np.sqrt(2),
         "one quantum per FCC bond (L^3/(6 sqrt2))": 6*np.sqrt(2),
         "one quantum per tetrahedron (L^3/(6 sqrt2))": 6*np.sqrt(2),
         "one quantum per octahedron (sqrt2 L^3/3)": 3/np.sqrt(2)}
print(f"\nrho^(1/4) observed (Planck LCDM) = {eL*1e3:.3f} meV ;  m1 = {m1*1e3:.3f} meV")
for name, f in cands.items():
    coef = (K/d)**3 * f                       # rho = coef * m1^4 / (hbar c)^3
    pred = coef**0.25 * m1
    print(f"  {name:44s} rho = {coef:7.2f} m1^4  ->  rho^(1/4) = {pred*1e3:.3f} meV  ({100*(pred/eL-1):+.1f}%)")
print(f"\ndark-energy length hbar c / rho^(1/4) = {hbarc/eL*1e6:.1f} micron")
