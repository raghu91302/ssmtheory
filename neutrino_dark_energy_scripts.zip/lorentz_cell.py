import numpy as np, itertools as it
R=[np.array(v) for v in it.product([-1,0,1],repeat=4) if sum(map(abs,v))==2]   # D4 roots, (t,x,y,z), |r|=sqrt2=L
L=np.sqrt(2)
# orthogonal frames of 4 roots (cells with edge L and right angles)
frames=set()
for c in it.combinations(range(len(R)),4):
    V=[R[i] for i in c]
    if all(abs(V[i]@V[j])<1e-9 for i in range(4) for j in range(i+1,4)):
        frames.add(frozenset(tuple(np.abs(v)) for v in V))
print("distinct orthogonal root frames (up to sign):",len(frames))
for F in frames: print("  ",sorted(F))
# cubes of edge L made of three orthogonal roots that are purely spatial (t=0)?
sp=[r for r in R if r[0]==0]
cub=[c for c in it.combinations(sp,3) if all(abs(a@b)<1e-9 for a,b in it.combinations(c,2))]
print("purely spatial orthogonal triples of bonds:",len(cub))
# frame A: (1,1,0,0),(1,-1,0,0),(0,0,1,1),(0,0,1,-1): equal-time section of the tesseract, Monte Carlo
F=np.array([(1,1,0,0),(1,-1,0,0),(0,0,1,1),(0,0,1,-1)],float)
rng=np.random.default_rng(0); P=rng.random((400000,4))@F          # points of the tesseract
t=P[:,0]; print("tesseract 4-volume:",abs(np.linalg.det(F)),"= L^4 =",L**4)
# equal-time sections (analytic): the (t,x) face of the frame is a diamond of t-extent 2 (= sqrt2 L) and x-width
# 2 - 2|t-1|; times the (y,z) square of area L^2.  Mid-time section: 2*L^2 = sqrt2 L^3; time-average: L^4/(sqrt2 L) = L^3/sqrt2.
mid = 2*L**2; avg = L**4/(np.sqrt(2)*L)
print(f"mid-time section {mid:.4f} = sqrt2 L^3 ({np.sqrt(2)*L**3:.4f});  average section {avg:.4f} = L^3/sqrt2 ({L**3/np.sqrt(2):.4f})")
print(f"coefficients: per cube face 64, per mid-time section {64*L**3/mid:.2f}, per average section {64*L**3/avg:.2f}")
print("time extent of the frame tesseract: sqrt2 L (t from 0 to 2 in units where L = sqrt2); 4-volume L^4")
