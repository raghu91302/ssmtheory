import numpy as np
from scipy.optimize import brentq
rng=np.random.default_rng(1)
H100=100e3/3.0857e22*6.582e-25; Mp=2.435e18
u=lambda dl: np.sort((1+np.cos(dl+2*np.pi*np.arange(3)/3))**2)
def predict(d31, eL_eV, factor=2*np.sqrt(2)):
    m1t=eL_eV/factor
    # choose delta so that m1/sqrt(m3^2-m1^2) matches m1t/sqrt(d31)
    g=lambda dl: (lambda x: x[0]/np.sqrt(x[2]**2-x[0]**2))(u(dl)) - m1t/np.sqrt(d31)
    dl=brentq(g,0.2,np.pi/3-1e-6); x=u(dl); a2=np.sqrt(d31/(x[2]**2-x[0]**2)); m=a2*x
    return m[1]**2-m[0]**2, dl, m
N=3000; out=[]
for _ in range(N):
    d31=rng.normal(2.521e-3,0.020e-3); h=rng.normal(0.6736,0.0054); om=rng.normal(0.1430,0.0011)
    eL=((h*h-om)*3*H100**2*Mp**2)**0.25*1e9   # eV
    out.append(predict(d31,eL)[0])
out=np.array(out)
print(f"prediction from K=1/2 + rho_L^1/4 = 2 sqrt2 m1 + measured dm31 + Planck: dm21 = {out.mean()*1e5:.3f} +- {out.std()*1e5:.3f} e-5 eV^2")
print("measured (global fit incl. first JUNO data): 7.530 +- 0.097 e-5 eV^2 ; JUNO six-year projection 0.3%")
d,dl,m=predict(2.521e-3,((0.6736**2-0.1430)*3*H100**2*Mp**2)**0.25*1e9)
print(f"central: delta_nu = {dl:.4f}, masses = {np.round(m*1e3,3)} meV")
# with SH0ES h
d2,_,_=predict(2.521e-3,((0.73**2-0.1430)*3*H100**2*Mp**2)**0.25*1e9); print(f"with h=0.73: dm21 = {d2*1e5:.3f} e-5")
