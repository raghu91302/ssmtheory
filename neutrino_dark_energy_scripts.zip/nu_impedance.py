"""Section 4.2/4.4: the bond rule with N quanta, and the impedance-matching count.
Proton comparison:       m_p = 16 * hbar c/(4 L)  ->  L = 4 hbar/(m_p c)  (vs r_p = 0.84075 fm)
Neutrino:       window  m1 = N_k * hbar c/(4 L)  (P6: N_k = degree^2 of defect graph)
                         inclusion: U = m1 (lightest time-wrap, analogue of I1), J = hbar c/(4L)
                                    -> Z_nu^2 = N_k
                         vacuum (matching hypothesis, Sec. 4.4): U_f = rho_L * c_V * L^3, J_f = hbar c/(4L)
                                    -> Z_f^2 = 4 c_V rho_L L^4/(hbar c)
                         match Z_nu = Z_f -> L from rho_L alone
                         consistency -> rho_L = 64 m1^4/(N_k^3 c_V)
"""
import numpy as np
hc = 197.3269804e-9          # eV m
m1, dm1 = 0.7938e-3, 0.013e-3   # eV  (nde_numbers.py)
r4, dr4 = 2.239e-3, 0.013e-3    # rho_Lambda^(1/4), eV
# alpha-paper check
me, mp = 0.51099895e6, 938.27208816e6
print("proton: 4 hbar/(m_p c) =", 4*hc/mp*1e15, "fm  vs 0.84075(64) fm")
print()
ratio = r4/m1; dratio = ratio*np.hypot(dm1/m1, dr4/r4)
meas = ratio**4; dmeas = 4*meas*dratio/ratio
print(f"measured rho/m1^4 = {meas:.1f} +- {dmeas:.1f}  ->  N_k^3 c_V = {64/meas:.3f} +- {64/meas*dmeas/meas:.3f}")
print()
cells = {"orthogonal cube L^3 (c_V=1)":1.0,
         "FCC per-site L^3/sqrt2":1/np.sqrt(2),
         "FCC conventional cube (sqrt2 L)^3":2*np.sqrt(2)}
for Nk, gname in [(1,"single time bond K2 (deg 1)"),(4,"closed cycle (deg 2)"),(16,"K5 like proton (deg 4)")]:
    for cname,cV in cells.items():
        pred = 64/(Nk**3*cV)
        s = (pred-meas)/dmeas
        L_win = Nk*hc/(4*m1)
        L_match = (Nk*hc**3/(4*cV*r4**4)*1)**0.25 if True else 0
        # rho_L in eV^4/(hbar c)^3 ; Z_f^2 = 4 cV rho L^4/(hc) = Nk -> L^4 = Nk hc^4/(4 cV r4^4)
        L_match = (Nk/(4*cV))**0.25*hc/r4
        print(f"N_k={Nk:2d} {gname:28s} {cname:34s} pred={pred:8.2f}  {s:+7.1f} sigma   L_win={L_win*1e6:7.1f} um  L_match={L_match*1e6:7.1f} um")
print()
# speed in the inclusion with alpha-paper dictionary (v/c)^2 = u*j/32, u=U/E_bond, j=J/E_bond
for Nk in (1,4,16):
    print(f"N_k={Nk}: inclusion wave speed v/c = {np.sqrt(Nk/32):.3f}  (index n = {np.sqrt(32/Nk):.2f})")
print("vacuum side: if the vacuum time channel obeyed v=c with J_f=E_bond, then Z_f^2 = 32 independent of rho_Lambda")
