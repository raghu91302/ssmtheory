#!/usr/bin/env python3
"""Look-elsewhere for rho_L^1/4 / m1 = 2.821 +- 0.048 (Section 6): a set of 'simple' constants a/b * s,
a, b in {1,2,3,4,5,6,8,9,12,16,24}, s in {1, sqrt2, sqrt3, sqrt6, pi, 1/pi, sqrt(pi)}."""
import numpy as np
base = [1,2,3,4,5,6,8,9,12,16,24]; S = [1, np.sqrt(2), np.sqrt(3), np.sqrt(6), np.pi, 1/np.pi, np.sqrt(np.pi)]
c = np.array(sorted({round(a/b*s, 9) for a in base for b in base for s in S if 1 < a/b*s < 20}))
R, sR = 2.821, 0.048
band = c[(c > R-sR) & (c < R+sR)]
print(f"{len(c)} constants in (1,20); within 1 sigma of {R}: {len(band)} -> {np.round(band,4)}")
# probability that a ratio drawn uniformly in [R-2sR, R+2sR] lies within 0.7% of some constant
rng = np.random.default_rng(0); x = rng.uniform(R-2*sR, R+2*sR, 200000)
d = np.min(np.abs(np.log(x[:, None]/c[None, :])), axis=1)
print(f"P(some constant within 0.7%) = {(d < 0.007).mean():.2f} ;  within 0.3%: {(d < 0.003).mean():.2f}")
