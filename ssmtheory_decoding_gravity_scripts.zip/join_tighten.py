"""
Tighten: test C_x vs ||J_cons||^2 on STRUCTURALLY DIFFERENT defects (not just bigger),
to rule out "both grow with size". 
Defect types at ROUGHLY FIXED size but different geometry:
  (a) single strained bond
  (b) trapped node in tetra void (the matter defect)
  (c) trapped node in OCTAHEDRAL void (different void)
  (d) vacancy (removed-node strain: neighbors relax inward)
  (e) shear on a face (different strain pattern, same edge count)
  (f) dilation of a tetra (isotropic vs shear)
Compute C_x = E_s*C_s (exact: E_s=strained edges, C_s=vertices+tri-faces touching them)
and ||J_cons||^2. Test if the SAME proportionality holds across different geometries.
"""
import numpy as np, itertools as it
a=1.0; L=a/np.sqrt(2); R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)
center=np.array([R/2.,R/2.,R/2.])
def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]
def edges_among(cl): return [eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
def Cs_of(cl,cle):
    V=len(cl); Ftri=sum(1 for i,j,k in it.combinations(cl,3)
        if all(tuple(sorted(x)) in eidx for x in [(i,j),(j,k),(i,k)]))
    return V+Ftri
def Jc(cle,vals):
    e=np.zeros(E)
    for te,v in zip(cle,vals): e[te]=v
    u,*_=np.linalg.lstsq(B,e,rcond=None); J=e-B@u; Jc=J-d1p@(d1@J)
    return np.linalg.norm(Jc)

results=[]
# (b) tetra void trapped node
void=center+np.array([.25,.25,.25]); cl=near(void,4); cle=edges_among(cl)
results.append(("tetra-void",len(cle),Cs_of(cl,cle),Jc(cle,[1]*len(cle))))
# (c) octahedral void (at face center region), 6 surrounding
octv=center+np.array([.5,0,0]); cl=near(octv,6); cle=edges_among(cl)
results.append(("oct-void",len(cle),Cs_of(cl,cle),Jc(cle,[1]*len(cle))))
# (d) vacancy: a node's incident edges strained inward
v=near(center,1)[0]; cle=[k for k,(i,j) in enumerate(edges) if i==v or j==v]
cl=list(set([i for k in cle for i in edges[k]]))
results.append(("vacancy",len(cle),Cs_of(cl,cle),Jc(cle,[1]*len(cle))))
# (e) shear: tetra void but antisymmetric strain pattern (+1,-1 alternating)
void=center+np.array([.25,.25,.25]); cl=near(void,4); cle=edges_among(cl)
vals=[(-1)**i for i in range(len(cle))]
results.append(("shear-tetra",len(cle),Cs_of(cl,cle),Jc(cle,vals)))
# (f) dilation of larger cluster (isotropic +1)
cl=near(center,8); cle=edges_among(cl)
results.append(("dilate-8",len(cle),Cs_of(cl,cle),Jc(cle,[1]*len(cle))))
# (g) single bond
cle=[0]; cl=list(edges[0])
results.append(("1-bond",1,Cs_of(cl,cle),Jc(cle,[1])))
# (a2) two disjoint bonds (structurally different, same E_s as some)
cle=[0, E//2]; cl=list(set(list(edges[0])+list(edges[E//2])))
results.append(("2-bond-disj",2,Cs_of(cl,cle),Jc(cle,[1,1])))
# (h) line of 4 bonds
cl=near(center,5); cle=edges_among(cl)[:4]
results.append(("4-edge-cluster",len(cle),Cs_of(cl,cle),Jc(cle,[1]*len(cle))))

print(f"{'defect':>15} | {'E_s':>4} | {'C_s':>4} | {'C_x':>6} | {'||Jc||':>7} | {'||Jc||^2':>8} | {'C_x/||Jc||^2':>12}")
Cx=[];Y=[]
for name,Es,Cs,Jn in results:
    cx=Es*Cs; y=Jn**2
    ratio=cx/y if y>1e-9 else float('nan')
    print(f"{name:>15} | {Es:>4} | {Cs:>4} | {cx:>6} | {Jn:>7.3f} | {y:>8.3f} | {ratio:>12.2f}")
    Cx.append(cx);Y.append(y)
Cx=np.array(Cx,float);Y=np.array(Y,float)
r=np.corrcoef(Cx,Y)[0,1]
a_=np.sum(Cx*Y)/np.sum(Cx*Cx)
print()
print(f"C_x vs ||J_cons||^2 across {len(results)} STRUCTURALLY DIFFERENT defects: corr={r:.3f}")
print(f"  ratio C_x/||Jc||^2 spread: min={np.nanmin(Cx/Y):.1f} max={np.nanmax(Cx/Y):.1f}")
print()
print("If corr stays high AND ratio is roughly constant across DIFFERENT geometries,")
print("the proportionality is real (not a size artifact). If ratio varies wildly,")
print("it was mostly a size effect and the join is weaker than it looked.")
