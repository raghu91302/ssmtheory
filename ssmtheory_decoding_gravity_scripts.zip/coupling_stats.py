"""
Honest statistics on the coupling. The 7 non-gauge defects.
Test: Pearson (linear), Spearman (monotonic, leverage-robust), and log-log power-law fit.
"""
import numpy as np
from scipy import stats
# data from join_tighten (excluding 1-bond which has J=0)
Cx  = np.array([48, 168, 540, 48, 357, 8, 36], float)
En  = np.array([1.537, 3.023, 8.804, 2.570, 4.827, 0.449, 1.370], float)  # ||J_cons||^2
names=['tetra','oct','vac','shear','dil8','2bond','4edge']

pear=stats.pearsonr(Cx,En)
spear=stats.spearmanr(Cx,En)
print(f"Pearson  r = {pear[0]:.3f}  (p={pear[1]:.3f})  -- linear, leverage-sensitive")
print(f"Spearman r = {spear[0]:.3f}  (p={spear[1]:.3f})  -- monotonic, leverage-robust")
print()
# log-log fit: En = A * Cx^b  =>  log En = log A + b log Cx
lx,ly=np.log(Cx),np.log(En)
b,logA=np.polyfit(lx,ly,1)
r_log=stats.pearsonr(lx,ly)[0]
print(f"log-log fit:  ||J||^2 ~ C_x^b  with b = {b:.3f},  R(loglog) = {r_log:.3f}")
print(f"  (b=1 would mean ||J||^2 proportional to C_x; b!=1 means a different power)")
print()
# if b~0.5, then ||J||^2 ~ sqrt(Cx), i.e. ||J|| ~ Cx^0.25 ... check what b actually says
# also test ||J|| (not squared) vs Cx
En_sqrt=np.sqrt(En)  # = ||J_cons||
b2,_=np.polyfit(np.log(Cx),np.log(En_sqrt),1)
print(f"||J_cons|| (not squared) ~ C_x^{b2:.3f}")
print()
# the honest ratio scatter
ratio=Cx/En
print(f"ratio C_x/||J||^2: {np.round(ratio,1)}")
print(f"  mean={ratio.mean():.1f}, std={ratio.std():.1f}, spread max/min={ratio.max()/ratio.min():.1f}x")
print()
# leverage check: recompute Pearson WITHOUT the two biggest points (vac, dil8)
keep=[0,1,3,5,6]  # drop vac(2) and dil8(4)
pear_small=stats.pearsonr(Cx[keep],En[keep])
print(f"Pearson WITHOUT the 2 largest (leverage) points: r = {pear_small[0]:.3f}")
print("  if this drops a lot, the 0.97 was leverage-driven.")
