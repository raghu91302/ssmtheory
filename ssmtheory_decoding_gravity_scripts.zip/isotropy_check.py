"""
Is the D4 rank-4 tensor REALLY isotropic (full SO(4)), or only cubic/hypercubic isotropic
(invariant under the discrete lattice point group but NOT the full rotation group)?

This is THE crucial question. A cubic-invariant rank-4 tensor has TWO independent components:
  T_iiii (diagonal) and T_iijj (i!=j).
It is fully isotropic ONLY if T_iiii = 3*T_iijj (the specific ratio that kills the
anisotropic part). If T_iiii/T_iijj != 3, there is a hypercubic anisotropy and Lorentz
invariance is BROKEN at the lattice scale.

The famous fact: the 24-cell is NOT a spherical 6-design, so at RANK 6 the D4 tensor is
anisotropic. The question is whether at RANK 4 it is isotropic. Let me check rank 4 directly
AND rank 6, and test rotation invariance explicitly (not just the delta-form fit).
"""
import numpy as np, itertools as it

roots=[]
for i,j in it.combinations(range(4),2):
    for si in(1,-1):
        for sj in(1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; roots.append(np.array(v,float))
roots=np.array(roots)

# rank-4 tensor
T4=np.einsum('ai,aj,ak,al->ijkl',roots,roots,roots,roots)
print("RANK 4:")
print(f"  T_1111 (diagonal) = {T4[0,0,0,0]:.4f}")
print(f"  T_1122 (i!=j)     = {T4[0,0,1,1]:.4f}")
print(f"  ratio T_1111/T_1122 = {T4[0,0,0,0]/T4[0,0,1,1]:.6f}  (isotropic REQUIRES exactly 3)")
print(f"  T_1112 (odd)      = {T4[0,0,0,1]:.4f}  (should be 0)")
print(f"  isotropic at rank 4? {abs(T4[0,0,0,0]/T4[0,0,1,1]-3)<1e-9}")
print()

# DECISIVE test: rotate the roots by a generic SO(4) rotation and recompute. If truly
# isotropic, the tensor is UNCHANGED. If only cubic, it CHANGES.
def random_SO4(seed):
    rng=np.random.default_rng(seed)
    A=rng.normal(size=(4,4)); Q,R=np.linalg.qr(A); Q=Q@np.diag(np.sign(np.diag(R)))
    if np.linalg.det(Q)<0: Q[:,0]=-Q[:,0]
    return Q

print("ROTATION TEST (generic SO(4) rotation of the root set):")
for seed in [1,2,3]:
    Q=random_SO4(seed)
    rr=roots@Q.T
    T4r=np.einsum('ai,aj,ak,al->ijkl',rr,rr,rr,rr)
    diff=np.linalg.norm(T4r-T4)/np.linalg.norm(T4)
    print(f"  seed {seed}: ||T4(rotated)-T4||/||T4|| = {diff:.3e}  {'INVARIANT' if diff<1e-9 else 'CHANGES'}")
print()
print("RANK 6 (for comparison - known to be anisotropic since 24-cell is not a 6-design):")
T6=np.einsum('ai,aj,ak,al,am,an->ijklmn',roots,roots,roots,roots,roots,roots)
# isotropic rank-6 would have T_111111/T_111122 = 5, T_112233 pattern etc. Check one ratio.
print(f"  T_111111 = {T6[0,0,0,0,0,0]:.2f}")
print(f"  T_111122 = {T6[0,0,0,0,1,1]:.2f}")
print(f"  ratio = {T6[0,0,0,0,0,0]/T6[0,0,0,0,1,1]:.4f}  (isotropic rank-6 requires exactly 5)")
for seed in [1,2]:
    Q=random_SO4(seed); rr=roots@Q.T
    T6r=np.einsum('ai,aj,ak,al,am,an->ijklmn',rr,rr,rr,rr,rr,rr)
    diff=np.linalg.norm(T6r-T6)/np.linalg.norm(T6)
    print(f"  rank6 rotation seed {seed}: diff = {diff:.3e}  {'INVARIANT' if diff<1e-9 else 'ANISOTROPIC (changes)'}")
