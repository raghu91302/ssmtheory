"""
Is C_x = kappa*||J_inc||^2 tautological? Test whether ||J_inc||^2 is just a rescaling
of E_s (or C_x) by construction, or an independent geometric quantity.

Key test: for the SAME footprint (same E_s, same edges) but DIFFERENT strain PATTERNS,
does ||J_inc||^2 stay fixed (=> tautological, determined by edge count) or vary
(=> independent, determined by the actual strain geometry)?

If ||J_inc||^2 depends only on E_s, it's tautological. If it depends on the strain
pattern on those edges, it's a real geometric quantity and the law is not definitional.
"""
import numpy as np, itertools as it
a=1.0; L=a/np.sqrt(2); R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)
def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]
def edges_among(cl): return [eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
def Jinc2(cle,vals):
    e=np.zeros(E)
    for te,v in zip(cle,vals): e[te]=v
    u,*_=np.linalg.lstsq(B,e,rcond=None); J=e-B@u; Jc=J-d1p@(d1@J)
    return np.linalg.norm(Jc)**2, np.linalg.norm(e)**2

center=np.array([R/2,R/2,R/2])
void=center+np.array([.25,.25,.25])
cle=edges_among(near(void,4))  # 6 edges of the tetra void
Es=len(cle)
print(f"SAME footprint: tetra-void, {Es} edges. Vary the strain PATTERN on these edges.")
print(f"{'pattern':>28} | {'||e||^2':>8} | {'||Jinc||^2':>10} | {'Jinc^2/||e||^2':>13}")
patterns={
  "uniform (1,1,1,1,1,1)":[1,1,1,1,1,1],
  "alt shear (1,-1,1,-1,1,-1)":[1,-1,1,-1,1,-1],
  "single edge (1,0,0,0,0,0)":[1,0,0,0,0,0],
  "two edges (1,1,0,0,0,0)":[1,1,0,0,0,0],
  "random A":list(np.random.default_rng(1).normal(size=6)),
  "random B":list(np.random.default_rng(2).normal(size=6)),
  "random C":list(np.random.default_rng(3).normal(size=6)),
}
fracs=[]
for name,vals in patterns.items():
    j2,e2=Jinc2(cle,vals)
    frac=j2/e2 if e2>1e-9 else 0
    fracs.append(frac)
    print(f"{name:>28} | {e2:>8.3f} | {j2:>10.4f} | {frac:>13.4f}")
print()
print("If ||Jinc||^2 / ||e||^2 VARIES with pattern -> incompatible energy depends on the")
print("STRAIN GEOMETRY, not just the edge count -> NOT tautological.")
print(f"  fraction range: {min(fracs):.3f} to {max(fracs):.3f}  (spread {max(fracs)/max(min(fracs),1e-9):.1f}x)")
print()
# The deeper test: C_x uses C_s (stabilizer count), which is PURELY combinatorial
# (counts vertices+faces), computed WITHOUT any reference to the strain field or B matrix.
# ||J_inc||^2 uses B (the geometric compatibility operator). They use DIFFERENT inputs.
print("Independence of inputs:")
print("  C_x = E_s * C_s : E_s=edge count, C_s=vertex+face count. PURELY COMBINATORIAL.")
print("     (no bond directions, no B matrix, no strain field)")
print("  ||J_inc||^2 : uses B (bond direction geometry) to project out compatible strain.")
print("     (depends on actual 3D embedding / bond vectors)")
print("  => different mathematical inputs. C_x is topology/counting; J_inc is metric geometry.")
