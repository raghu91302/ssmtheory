"""
Refinement: correlate the INCOMPATIBLE part of the verification cost against ||J_cons||^2.
The insight from the single-bond case (C_x=2 but J_cons=0): total code cost counts gauge
(compatible) strain too. The gravitational source is only the INCOMPATIBLE part. So the
right code quantity may be C_x weighted by the incompatible fraction, or the verification
cost of only the uncorrectable syndrome.

Define incompatible verification cost:
  C_x^inc = C_s * E_s^inc, where E_s^inc = rank of the incompatible sector among the
  defect's edges = number of independent uncorrectable syndrome components.
Or simpler: C_x^inc = C_s * (||J_cons||/||e_defect|| fraction) * E_s.
Test which tightens the ratio C_x^inc / ||J_cons||^2 to a constant.
"""
import numpy as np, itertools as it
a=1.0; L=a/np.sqrt(2); R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)
center=np.array([R/2.,R/2.,R/2.])
def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]
def edges_among(cl): return [eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
def Cs_of(cl):
    V=len(cl); Ftri=sum(1 for i,j,k in it.combinations(cl,3)
        if all(tuple(sorted(x)) in eidx for x in [(i,j),(j,k),(i,k)]))
    return V+Ftri
def analyze(cl,cle,vals):
    e=np.zeros(E)
    for te,v in zip(cle,vals): e[te]=v
    u,*_=np.linalg.lstsq(B,e,rcond=None); ec=B@u; J=e-ec; Jc=J-d1p@(d1@J)
    Es=len(cle); Cs=Cs_of(cl)
    # incompatible fraction of the footprint
    frac = np.linalg.norm(J)/np.linalg.norm(e) if np.linalg.norm(e)>1e-9 else 0.0
    Es_inc = Es*frac                       # effective # incompatible qubits
    Cx=Es*Cs
    Cx_inc=Es_inc*Cs                        # incompatible verification cost
    return Es,Cs,Cx,Cx_inc,np.linalg.norm(Jc),frac

defs=[]
void=center+np.array([.25,.25,.25]); cl=near(void,4); defs.append(("tetra-void",cl,edges_among(cl),[1]*len(edges_among(cl))))
octv=center+np.array([.5,0,0]); cl=near(octv,6); defs.append(("oct-void",cl,edges_among(cl),[1]*len(edges_among(cl))))
v=near(center,1)[0]; cle=[k for k,(i,j) in enumerate(edges) if i==v or j==v]; cl=list(set([i for k in cle for i in edges[k]])); defs.append(("vacancy",cl,cle,[1]*len(cle)))
cl=near(center+np.array([.25,.25,.25]),4); cle=edges_among(cl); defs.append(("shear",cl,cle,[(-1)**i for i in range(len(cle))]))
cl=near(center,8); cle=edges_among(cl); defs.append(("dilate-8",cl,cle,[1]*len(cle)))
cle=[0]; cl=list(edges[0]); defs.append(("1-bond",cl,cle,[1]))
cle=[0,E//2]; cl=list(set(list(edges[0])+list(edges[E//2]))); defs.append(("2-bond-disj",cl,cle,[1,1]))
cl=near(center,5); cle=edges_among(cl)[:4]; defs.append(("4-edge",cl,cle,[1]*len(cle)))

print(f"{'defect':>13} | {'C_x':>6} | {'C_x^inc':>8} | {'||Jc||^2':>8} | {'Cx/J2':>7} | {'Cxinc/J2':>9} | {'inc.frac':>8}")
rows=[]
for name,cl,cle,vals in defs:
    Es,Cs,Cx,Cxi,Jn,frac=analyze(cl,cle,vals)
    y=Jn**2
    r1=Cx/y if y>1e-9 else float('nan'); r2=Cxi/y if y>1e-9 else float('nan')
    print(f"{name:>13} | {Cx:>6} | {Cxi:>8.1f} | {y:>8.3f} | {r1:>7.1f} | {r2:>9.2f} | {frac:>8.3f}")
    rows.append((Cx,Cxi,y))
rows=np.array(rows,float)
# correlations and ratio spreads, excluding J=0 rows
m=rows[:,2]>1e-9
Cx,Cxi,Y=rows[m,0],rows[m,1],rows[m,2]
print()
print(f"total C_x    vs ||Jc||^2: corr={np.corrcoef(Cx,Y)[0,1]:.3f}, ratio spread {(Cx/Y).min():.1f}-{(Cx/Y).max():.1f} (x{(Cx/Y).max()/(Cx/Y).min():.1f})")
print(f"incompat C_x^inc vs ||Jc||^2: corr={np.corrcoef(Cxi,Y)[0,1]:.3f}, ratio spread {(Cxi/Y).min():.2f}-{(Cxi/Y).max():.2f} (x{(Cxi/Y).max()/(Cxi/Y).min():.1f})")
print()
print("If C_x^inc ratio spread is much tighter than C_x, the incompatible verification")
print("cost is the right quantity: mass_grav = incompatible code cost ~ strain energy.")
