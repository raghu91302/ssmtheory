"""
Test the clean-law hypothesis: C_x ~ ELASTIC ENERGY of J_cons (FP-weighted), not
the Euclidean ||J_cons||^2. The physical strain energy is <J, K J> with K the elastic
stiffness operator (the Regge/FP quadratic form), NOT <J,J>.

Build the elastic energy operator on edge-strains directly from the FCC bond geometry:
the elastic energy of an edge-strain field e is E_elastic = sum over sites of the local
elastic energy = strain energy in the linearized bond-spring model. For central-force
springs, E = (1/2) sum_edges k (e_edge)^2 in the SIMPLEST model = Euclidean (which we
tried). The RICHER model includes angular/bulk terms via the structure tensor.

Better: the elastic energy that sources gravity is the INCOMPATIBLE strain measured in
the metric inner product. The incompatible strain maps to curvature; its energy is the
Regge action. Compute E_elastic = ||curvature||^2 = ||inc(e)||^2 where inc is the discrete
incompatibility (double curl). This weights strain by how much CURVATURE it carries,
which is the right gravitational energy.

We compute the incompatibility operator and use ||inc(J_cons)||^2 as the elastic/grav energy.
"""
import numpy as np, itertools as it
a=1.0; L=a/np.sqrt(2); R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)
Bp=np.linalg.pinv(B)
# incompatibility operator: inc = I - B B^+ projects onto incompatible space already.
# The "curvature energy" of a strain e: how much it fails compatibility = ||(I-BB^+) e||^2
# but that's just ||J||^2 again. The RIGHT weighting: curvature ~ second difference of strain.
# Build a triangle-loop (plaquette) curl: for each triangle, the sum of oriented edge strains
# = the "deficit" carried. Curvature energy = sum over triangles of (loop strain)^2.
tris=[]
for i in range(N):
    for j in range(i+1,N):
        if tuple(sorted((i,j))) not in eidx: continue
        for k in range(j+1,N):
            if tuple(sorted((i,k))) in eidx and tuple(sorted((j,k))) in eidx:
                tris.append((i,j,k))
print(f"N={N} E={E} triangles={len(tris)}")
# curl operator C2: triangles x edges (oriented sum of edge strains around triangle)
C2=np.zeros((len(tris),E))
for t,(i,j,k) in enumerate(tris):
    for (p,q),s in [((i,j),1),((j,k),1),((i,k),-1)]:
        C2[t,eidx[tuple(sorted((p,q)))]] += s*(1 if p<q else -1)
center=np.array([R/2.,R/2.,R/2.])
def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]
def edges_among(cl): return [eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
def Cs_of(cl):
    V=len(cl); Ftri=sum(1 for i,j,k in it.combinations(cl,3)
        if all(tuple(sorted(x)) in eidx for x in [(i,j),(j,k),(i,k)]))
    return V+Ftri
def measures(cl,cle,vals):
    e=np.zeros(E)
    for te,v in zip(cle,vals): e[te]=v
    u,*_=np.linalg.lstsq(B,e,rcond=None); J=e-B@u; Jc=J-d1p@(d1@J)
    Es=len(cle); Cs=Cs_of(cl); Cx=Es*Cs
    euclid=np.linalg.norm(Jc)**2
    curv=np.linalg.norm(C2@Jc)**2         # curvature energy (FP-like)
    return Cx,euclid,curv

defs=[]
void=center+np.array([.25,.25,.25]); cl=near(void,4); defs.append(("tetra-void",cl,edges_among(cl),[1]*len(edges_among(cl))))
octv=center+np.array([.5,0,0]); cl=near(octv,6); defs.append(("oct-void",cl,edges_among(cl),[1]*len(edges_among(cl))))
v=near(center,1)[0]; cle=[k for k,(i,j) in enumerate(edges) if i==v or j==v]; cl=list(set([i for k in cle for i in edges[k]])); defs.append(("vacancy",cl,cle,[1]*len(cle)))
cl=near(center+np.array([.25,.25,.25]),4); cle=edges_among(cl); defs.append(("shear",cl,cle,[(-1)**i for i in range(len(cle))]))
cl=near(center,8); cle=edges_among(cl); defs.append(("dilate-8",cl,cle,[1]*len(cle)))
cle=[0,E//2]; cl=list(set(list(edges[0])+list(edges[E//2]))); defs.append(("2-bond-disj",cl,cle,[1,1]))
cl=near(center,5); cle=edges_among(cl)[:4]; defs.append(("4-edge",cl,cle,[1]*len(cle)))

print(f"{'defect':>13} | {'C_x':>6} | {'||Jc||^2':>8} | {'curv-E':>8} | {'Cx/curv':>8}")
rows=[]
for name,cl,cle,vals in defs:
    Cx,euc,curv=measures(cl,cle,vals)
    r=Cx/curv if curv>1e-9 else float('nan')
    print(f"{name:>13} | {Cx:>6} | {euc:>8.3f} | {curv:>8.3f} | {r:>8.2f}")
    rows.append((Cx,euc,curv))
rows=np.array(rows,float); m=rows[:,2]>1e-9
Cx,euc,curv=rows[m,0],rows[m,1],rows[m,2]
print()
print(f"C_x vs Euclidean ||Jc||^2 : corr={np.corrcoef(Cx,euc)[0,1]:.3f}, ratio x{(Cx/euc).max()/(Cx/euc).min():.1f}")
print(f"C_x vs CURVATURE energy   : corr={np.corrcoef(Cx,curv)[0,1]:.3f}, ratio x{(Cx/curv).max()/(Cx/curv).min():.1f}")
print()
print("If curvature-energy ratio is much tighter (-> ~constant), THAT is the clean law:")
print("  verification cost = curvature energy of the defect strain.")
