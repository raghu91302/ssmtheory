#!/usr/bin/env python3
"""
d4_canonical_star.py  --  Section 2 of "Linearized Gravity on the D4 Lattice as a
Self-Decoding Code", in full.

Builds the canonical translation-invariant triangulation of D4, verifies the star
counts and the flat background, assembles the linearized Regge operator by exact
contraction of the Regge Hessian, and reproduces every number in Section 2.

REPLACES two things in the previous version of the archive.

1. The Delaunay triangulation.  scipy's Delaunay with qhull_options='Qt' on a D4
   point set is not usable: the lattice is massively cospherical, so degenerate
   facets are triangulated in an implementation- and input-order dependent way.
   On a 409-point chunk it returns 393 zero-volume simplices, 40 of volume 1/6
   among 5488 of volume 1/12, and 96 distinct simplex shapes with multiplicities
   from 1 to 20.  It is not translation-invariant -- 125 hinges at the origin is
   not divisible by 3 -- and its degenerate simplices make coordinate
   reconstruction blow up away from the origin.

   The construction here is fixed by the lattice.  The deep holes of D4 (covering
   radius 1) are the three nontrivial cosets of D4 in D4*,
       (1,0,0,0)+D4,   (1/2,1/2,1/2,1/2)+D4,   (1/2,1/2,1/2,-1/2)+D4,
   each with exactly 8 lattice points at distance 1 forming a 4-orthoplex
   (16-cell).  Each 16-cell splits into 8 four-simplices of volume 1/12 by a rule
   fixed by lexicographic order on the antipodal-pair directions, hence
   translation-invariant.  The facets of a 16-cell are already tetrahedra, so
   cells subdivide independently and the global complex is consistent.
   Star of the origin: 120 simplices, 150 hinges, 30 edges (24 bonds + 6
   diagonals), all fans complete, all volumes 1/12.

2. The finite-difference operator Q(k).  The previous diagnostics summed only the
   hinges CONTAINING the origin, which is not a fundamental domain.  That
   truncation broke rank-four isotropy by ~34% (TT+ and TTx differed by a third at
   the same k in the body direction) and produced six non-degenerate negative
   eigenvalues where Fierz-Pauli requires five degenerate ones.  It was not noise
   (identical for eps from 1e-2 to 1e-5) and not slivers (all star simplices have
   volume exactly 1/12); completing the hinge set reduced the anisotropy
   monotonically, 33.8% -> 12.0% -> 2.9% at 125 -> 307 -> 699 hinges.

   The operator is instead assembled from the Regge Hessian
       M[e,e'] = sum_h (dA_h/dL_e)(d delta_h/dL_e')
   contracted in momentum space, with the outer index anchored at the origin.  At
   the flat background delta = 0, so this cross term is the whole second variation
   (Schlafli kills sum_h A_h d delta_h).

RESULTS REPRODUCED
  Table 1   30 edges at O (24 + 6), 150 hinges, 120 simplices, 24 cells
  Sec 2.3(i)  max background deficit 1.8e-15; every fan sums to exactly 2 pi
  Table 2   spectrum -1/2 (x5, TT), 0 (x4, gauge), +1 (x1, trace)
            direction-independent to 9e-16; singular values {1, 1/2^5, 0^4}
  Eq (2.x)  h_00 k^2 = -1.0000000000, exactly k-independent
  Sec 2.4   C^(2)/q_FP = -1 to 2e-15 on the canonical triangulation, i.e. the exact
            Fierz-Pauli identity is subdivision-independent
  Sec 4     decoding flow converges to 4e-16 in ~1e3 iterations; condition
            number of F on the physical sector is exactly 2

A NOTE ON NORMALISATION.  The spectrum is computed in an ORTHONORMAL basis of
Sym(R^4), one in which <A,B> = sum_ij A_ij B_ij and every basis element has unit
norm.  This is not conventional bookkeeping.  The previously reported sector
coefficients (-1:+3:0) came from evaluating the quadratic form on eps_TT = uu-vv
(norm^2 = 2) and on eps_trace = delta (norm^2 = 4) -- two different
normalizations -- and the "four transverse-traceless polarizations" undercounts:
Euclidean 4D has five, and 4+1+4 does not reconstruct a 10-dimensional space.

Usage:  python3 d4_canonical_star.py
Requires numpy, sympy (scipy only for the optional Delaunay cross-check).
"""
import itertools as it
from collections import defaultdict, Counter

import numpy as np
import sympy as sp

# the three nontrivial cosets of D4 in D4*: the deep holes
HOLE_REPS = [(sp.Integer(1), sp.Integer(0), sp.Integer(0), sp.Integer(0)),
             (sp.Rational(1, 2),) * 4,
             (sp.Rational(1, 2), sp.Rational(1, 2), sp.Rational(1, 2), sp.Rational(-1, 2))]

PAIRS = [(i, j) for i in range(5) for j in range(i + 1, 5)]


# ----------------------------------------------------------------- triangulation
def cell_vertices(c):
    """the 8 D4 points at distance 1 from hole center c (a 4-orthoplex)"""
    lo = [int(np.floor(float(x))) - 1 for x in c]
    hi = [int(np.ceil(float(x))) + 1 for x in c]
    return [x for x in it.product(*[range(lo[i], hi[i] + 1) for i in range(4)])
            if sum(x) % 2 == 0
            and sum((sp.Integer(x[i]) - c[i]) ** 2 for i in range(4)) == 1]


def triangulate_cell(c):
    """8 four-simplices from one 16-cell, split by a translation-invariant rule.

    Group the 8 vertices into 4 antipodal pairs, order the pairs by the
    lexicographic order of their direction vectors (local geometry only, hence
    translation-invariant), and call them (a0,a1),(b0,b1),(c0,c1),(d0,d1).  The
    equatorial octahedron on {b,c,d} is coned from b0 and b1 over the square
    {c,d}, which is split on the diagonal (c0,c1); coning the resulting 4
    tetrahedra from a0 and a1 fills the cell.
    """
    vs = cell_vertices(c)
    dirs = {}
    for v in vs:
        d = tuple(sp.Integer(v[i]) - c[i] for i in range(4))
        key = d if d > tuple(-x for x in d) else tuple(-x for x in d)
        dirs.setdefault(key, []).append(v)
    pairs = [sorted(dirs[k]) for k in sorted(dirs)]
    assert len(pairs) == 4 and all(len(p) == 2 for p in pairs)
    (a0, a1), (b0, b1), (c0, c1), (d0, d1) = pairs
    tets = [(b0, c0, d0, c1), (b0, c0, d1, c1), (b1, c0, d0, c1), (b1, c0, d1, c1)]
    return [t + (apex,) for t in tets for apex in (a0, a1)]


def build_patch(radius2=8):
    """a local patch of the infinite lattice, big enough that every hinge at the
    origin has its complete fan of simplices"""
    trans = [t for t in it.product(range(-3, 4), repeat=4)
             if sum(t) % 2 == 0 and sum(x * x for x in t) <= radius2]
    simp = set()
    for r in HOLE_REPS:
        for t in trans:
            c = tuple(r[i] + t[i] for i in range(4))
            for sm in triangulate_cell(c):
                simp.add(tuple(sorted(tuple(v) for v in sm)))
    simp = sorted(simp)
    O = (0, 0, 0, 0)
    star = [s for s in simp if O in s]
    hinges = sorted({tuple(sorted(f)) for s in star
                     for f in it.combinations(s, 3) if O in f})
    edges = sorted({tuple(sorted((O, v))) for s in star for v in s if v != O})
    around = defaultdict(list)
    for s in simp:
        for f in it.combinations(sorted(s), 3):
            if O in f:
                around[f].append(s)
    return simp, star, hinges, edges, dict(around)


# ------------------------------------------------------- exact local geometry
def _dihedral():
    Ls = {p: sp.Symbol(f'L{p[0]}{p[1]}', positive=True) for p in PAIRS}
    LL = lambda i, j: Ls[(min(i, j), max(i, j))]
    xx = lambda i, j: (LL(0, i) if i == j
                       else sp.Rational(1, 2) * (LL(0, i) + LL(0, j) - LL(i, j)))
    g = xx(1, 1) * xx(2, 2) - xx(1, 2) ** 2

    def perp(a, b):
        ua, va = xx(1, a), xx(2, a)
        ub, vb = xx(1, b), xx(2, b)
        return xx(a, b) - ((xx(2, 2) * ua - xx(1, 2) * va) * ub
                          + (-xx(1, 2) * ua + xx(1, 1) * va) * vb) / g

    theta = sp.acos(perp(3, 4) / sp.sqrt(perp(3, 3) * perp(4, 4)))
    return Ls, theta, {p: sp.diff(theta, Ls[p]) for p in PAIRS}


def sig(loc):
    return tuple(sum((loc[i][t] - loc[j][t]) ** 2 for t in range(4)) for i, j in PAIRS)


def dArea(h, e):
    """d(area)/d(L^2_e) for triangle h, in closed form from the squared sides"""
    i, j, k = h
    sq = lambda p, q: sum((p[t] - q[t]) ** 2 for t in range(4))
    a, b, c = sq(j, k), sq(i, k), sq(i, j)
    v = 2 * a * b + 2 * b * c + 2 * c * a - a * a - b * b - c * c
    if v <= 0:
        return 0.0
    A = np.sqrt(v) / 4
    e = tuple(sorted(e))
    if e == tuple(sorted((j, k))):
        num = 2 * b + 2 * c - 2 * a
    elif e == tuple(sorted((i, k))):
        num = 2 * a + 2 * c - 2 * b
    elif e == tuple(sorted((i, j))):
        num = 2 * a + 2 * b - 2 * c
    else:
        return 0.0
    return num / (32 * A)


# ----------------------------------------------------------- the Regge operator
def hessian(hinges, edges, around, dth_cache, Ls, dth):
    """M[e,e'] = sum_h (dA_h/dL_e)(d delta_h/dL_e'), e anchored at the origin"""
    def dtheta(loc):
        s = sig(loc)
        if s not in dth_cache:
            sub = {Ls[p]: sp.Integer(s[n]) for n, p in enumerate(PAIRS)}
            dth_cache[s] = [float(sp.N(sp.nsimplify(dth[p].subs(sub)))) for p in PAIRS]
        return dth_cache[s]

    M = defaultdict(float)
    for e in edges:
        for h in hinges:
            if e[0] not in h or e[1] not in h:
                continue
            g = dArea(h, e)
            if g == 0.0:
                continue
            for sm in around[h]:
                loc = [*h, *[v for v in sm if v not in h]]
                d = dtheta(loc)
                for n, (i, j) in enumerate(PAIRS):
                    if abs(d[n]) < 1e-14:
                        continue
                    ep = tuple(sorted((loc[i], loc[j])))
                    M[(e, ep)] -= g * d[n]      # delta_h = 2 pi - sum theta
    return M


def sym_basis():
    """orthonormal in <A,B> = sum_ij A_ij B_ij; off-diagonals carry 1/sqrt(2)"""
    B = []
    for i in range(4):
        E = np.zeros((4, 4)); E[i, i] = 1.0; B.append(E)
    for i, j in it.combinations(range(4), 2):
        E = np.zeros((4, 4)); E[i, j] = E[j, i] = 1 / np.sqrt(2); B.append(E)
    return B


def make_coeff(M):
    mid = lambda e: (np.array(e[0]) + np.array(e[1])) / 2
    vec = lambda e: np.array(e[1]) - np.array(e[0])

    def coeff(k, eps):
        """C^(2): the O(|k|^2) coefficient of the Regge action, per unit |k|^2.

        This is the leading term of the momentum expansion, NOT the full
        finite-spacing lattice symbol, which differs from Fierz-Pauli at O(k^4).
        """
        kh = np.asarray(k, float)
        kh = kh / np.linalg.norm(kh)
        tot = 0.0
        for (e, ep), m in M.items():
            tot += m * (vec(e) @ eps @ vec(e)) * (vec(ep) @ eps @ vec(ep)) \
                   * (kh @ (mid(e) - mid(ep))) ** 2
        return -0.25 * tot
    return coeff


def operator(coeff, k, B):
    dg = [coeff(k, b) for b in B]
    A = np.zeros((10, 10))
    for a in range(10):
        for b in range(a + 1, 10):
            A[a, b] = A[b, a] = 0.5 * (coeff(k, B[a] + B[b]) - dg[a] - dg[b])
    for a in range(10):
        A[a, a] = dg[a]
    return A


def q_FP(k, eps):
    """linearized Einstein quadratic form per unit |k|^2; equals -h.G(h)/k^2"""
    kh = np.asarray(k, float)
    kh = kh / np.linalg.norm(kh)
    a = kh @ eps
    t = np.trace(eps)
    return 0.5 * np.sum(eps * eps) - a @ a + t * (kh @ eps @ kh) - 0.5 * t * t


# ------------------------------------------------------------------- reporting
def main():
    print("== Table 1: the D4 star, canonical triangulation ==")
    simp, star, hinges, edges, around = build_patch()
    lens = Counter(sum((np.array(e[1]) - np.array(e[0])) ** 2) for e in edges)
    print(f"  simplices at O = {len(star)}   hinges at O = {len(hinges)}"
          f"   edges at O = {len(edges)}  (by |d|^2: {dict(lens)})")
    vols = Counter(round(abs(np.linalg.det(np.array(s, float)[1:]
                                          - np.array(s, float)[0])) / 24, 9) for s in star)
    print(f"  star simplex volumes: {dict(vols)}")
    print(f"  hinges with complete fans: "
          f"{sum(1 for h in hinges if len(around[h]) >= 3)} of {len(hinges)}")

    Ls, theta, dth = _dihedral()
    print("\n== Sec 2.3(i): flat background ==")
    worst, exact = 0.0, True
    for h in hinges:
        tot = sp.Integer(0)
        for sm in around[h]:
            sub = {Ls[p]: sp.Integer(sig([*h, *[v for v in sm if v not in h]])[n])
                   for n, p in enumerate(PAIRS)}
            tot += sp.nsimplify(theta.subs(sub))
        d = sp.simplify(2 * sp.pi - tot)
        if d != 0:
            exact = False
        worst = max(worst, abs(float(sp.N(d))))
    print(f"  max |deficit| = {worst:.2e}    every fan sums to exactly 2*pi: {exact}")

    M = hessian(hinges, edges, around, {}, Ls, dth)
    coeff = make_coeff(M)
    B = sym_basis()
    print(f"  Regge Hessian entries: {len(M)}")

    print("\n== Table 2: spectrum in an ORTHONORMAL basis of Sym(R^4) ==")
    target = np.array(sorted([-0.5] * 5 + [0.0] * 4 + [1.0]))
    worst = 0.0
    for nm, d in [('axis', [0, 0, 0, 1]), ('face', [1, 1, 0, 0]), ('body', [1, 1, 1, 1]),
                  ('mixed', [2, 1, 1, 0]), ('generic', [0.371, -0.822, 1.13, 0.499])]:
        w = np.linalg.eigvalsh(operator(coeff, np.array(d, float), B))
        worst = max(worst, np.abs(np.sort(w) - target).max())
        print(f"  {nm:8s}: " + " ".join(f"{x:+7.4f}" for x in w))
    print(f"  direction-independent to {worst:.1e}")
    print("  sectors: TT -1/2 (x5) | gauge 0 (x4) | trace +1 (x1);  normalized (-1:+2:0)")

    A = operator(coeff, np.array([0.0, 1.0, 0.0, 0.0]), B)
    w, V = np.linalg.eigh(A)
    print("\n  sector identification (k along axis 1):")
    for val, vec_ in zip(w, V.T):
        H = sum(c * Bi for c, Bi in zip(vec_, B))
        kh = np.array([0.0, 1.0, 0.0, 0.0])
        kind = ('gauge' if np.linalg.norm(H @ kh) > 1e-6
                else 'trace' if abs(np.trace(H)) > 1e-6 else 'TT')
        print(f"    eig={val:+7.4f}  tr={np.trace(H):+6.3f}"
              f"  |k.H|={np.linalg.norm(H @ kh):.4f}  -> {kind}")

    sv = np.linalg.svd(A, compute_uv=False)
    print(f"\n== Newtonian solve ==")
    print(f"  singular values: {np.round(sv, 9)}")
    keep = np.abs(w) > 1e-6
    J = np.zeros(10); J[0] = 1.0
    P = V[:, keep] @ V[:, keep].T
    h = np.linalg.pinv(A, rcond=1e-6) @ (P @ J)
    print(f"  h_00 * k^2 = {h[0]:.10f}   (exactly k-independent by construction)")
    print(f"  condition number on the physical sector = "
          f"{np.max(np.abs(w[keep])) / np.min(np.abs(w[keep])):.1f}")
    print(f"  gauge modes at {np.max(np.abs(w[~keep])):.1e} relative, so rcond=1e-6"
          f" genuinely discards them")

    print("\n== Sec 2.4: Fierz-Pauli identity on THIS subdivision ==")
    rng = np.random.default_rng(0)
    rat = []
    for _ in range(200):
        kk = rng.normal(size=4)
        e = rng.normal(size=(4, 4))
        rat.append(coeff(kk, e + e.T) / q_FP(kk, e + e.T))
    rat = np.array(rat)
    print(f"  C^(2)_Regge / q_FP : mean = {rat.mean():.10f}   std/mean = "
          f"{rat.std() / abs(rat.mean()):.1e}")
    print("  => the identity is subdivision-independent (cf. partI_verify.py, which")
    print("     verifies it symbolically on a generic Delaunay subdivision)")

    print("\n== Sec 4: decoding flow  h' = -A(A h - J) ==")
    href = np.zeros(10)
    for i in range(10):
        if keep[i]:
            href += (V[:, i] @ (P @ J)) / w[i] * V[:, i]
    hh = np.zeros(10)
    dt = 0.5 / np.max(w ** 2)
    for n in range(1, 2001):
        hh = hh - dt * (A @ (A @ hh - P @ J))
        if n in (10, 100, 1000, 2000):
            print(f"  iter {n:5d}: ||Ah-J||/||J|| = "
                  f"{np.linalg.norm(A @ hh - P @ J) / np.linalg.norm(P @ J):.2e}"
                  f"   ||h-href||/||href|| = "
                  f"{np.linalg.norm(hh - href) / np.linalg.norm(href):.2e}")


if __name__ == '__main__':
    main()
