"""
Is kappa EXACT and constant for the tetra-void defect (= all ordinary matter)?
Scale the tetra-void strain amplitude and multiple independent tetra-void placements;
check C_x/||J_cons||^2 stays fixed. Also test several tetra-voids at different lattice
sites to confirm kappa is a property of the DEFECT TYPE, not the location.
"""
import numpy as np, itertools as it
a=1.0; L=a/np.sqrt(2); R=5
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)
def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]
def edges_among(cl): return [eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
def Cs_of(cl):
    V=len(cl); Ftri=sum(1 for i,j,k in it.combinations(cl,3)
        if all(tuple(sorted(x)) in eidx for x in [(i,j),(j,k),(i,k)]))
    return V+Ftri
def Jc2(cle,vals):
    e=np.zeros(E)
    for te,v in zip(cle,vals): e[te]=v
    u,*_=np.linalg.lstsq(B,e,rcond=None); J=e-B@u; Jc=J-d1p@(d1@J)
    return np.linalg.norm(Jc)**2

print("TEST 1: scale strain amplitude of ONE tetra-void. Is kappa constant?")
void=np.array([R/2,R/2,R/2])+np.array([.25,.25,.25])
cl=near(void,4); cle=edges_among(cl); Cs=Cs_of(cl); Es=len(cle); Cx=Es*Cs
print(f"  tetra-void: E_s={Es}, C_s={Cs}, C_x={Cx}")
print(f"  {'amplitude':>9} | {'||Jc||^2':>9} | {'C_x/||Jc||^2':>12}")
for amp in [0.5,1.0,2.0,3.0,5.0]:
    y=Jc2(cle,[amp]*len(cle))
    print(f"  {amp:>9.1f} | {y:>9.4f} | {Cx/y:>12.4f}")
print("  (C_x is amplitude-independent; ||Jc||^2 ~ amp^2; so ratio ~ 1/amp^2 -- ")
print("   kappa is defined at UNIT strain. The physical kappa = C_x/||Jc||^2 at unit amp.)")
print()
print("TEST 2: tetra-voids at DIFFERENT lattice sites. Same kappa? (kappa = species constant)")
print(f"  {'void site':>20} | {'C_x':>5} | {'||Jc||^2':>9} | {'kappa':>8}")
kappas=[]
# find several tetra voids (points at (n+.25) offsets) inside the patch
tried=0
for base in it.product(range(1,R-1),repeat=3):
    void=np.array(base)+np.array([.25,.25,.25])
    cl=near(void,4)
    # verify it's really a tetra void: 4 vertices mutually at distance L (regular tetra)
    ds=[np.linalg.norm(P[cl[i]]-P[cl[j]]) for i,j in it.combinations(range(4),2)]
    if not all(abs(dd-L)<1e-6 for dd in ds): continue
    cle=edges_among(cl); 
    if len(cle)!=6: continue
    Cs=Cs_of(cl); Cx=len(cle)*Cs; y=Jc2(cle,[1.0]*6)
    kappas.append(Cx/y)
    if tried<6:
        print(f"  {str(tuple(np.round(void,2))):>20} | {Cx:>5} | {y:>9.4f} | {Cx/y:>8.4f}")
    tried+=1
kappas=np.array(kappas)
print(f"\n  {len(kappas)} tetra-voids: kappa mean={kappas.mean():.4f}, std={kappas.std():.4f}, spread={kappas.max()-kappas.min():.4f}")
print(f"  all identical? {np.allclose(kappas,kappas[0],atol=1e-6)}")
if kappas.std()<1e-6:
    print("  => kappa is EXACT and universal for tetra-void = ordinary matter. Clean linear law.")
else:
    print(f"  => kappa varies by {kappas.std()/kappas.mean()*100:.2f}% across sites (boundary effects?)")
