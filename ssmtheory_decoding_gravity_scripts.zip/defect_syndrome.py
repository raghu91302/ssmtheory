"""
THE RIGHT TEST. Chain: defect -> irreducible syndrome J -> FP h = J -> gravity (1/r).
NOT k (logical count). The observable is J = the incompatible part of the edge-strain
the defect forces, which the decoder cannot remove.

Steps:
1. FCC lattice patch. Reference bond length L.
2. Insert trapped node in tetrahedral void, bonded to 4 vertices at strained length.
   This forces edge-length errors e (the strain field).
3. Decompose e = compatible (gauge, = grad of vertex displacement) + incompatible (syndrome).
   The compatible part is image of d1^T (vertex coboundary). Project it out.
   J = incompatible remainder = what the decoder CANNOT remove.
4. Check J conserved (d1 J = 0).
5. Solve FP h = J and check for 1/r (Newtonian) falloff.

We do the strain-incompatibility computation on the FCC edge complex.
"""
import numpy as np, itertools as it
from collections import defaultdict

a=1.0; L=a/np.sqrt(2)

# Build an FCC patch (conventional cells), collect nodes and nn-edges
nodes=set()
for cx,cy,cz in it.product(range(2),repeat=3):
    base=np.array([cx,cy,cz])
    cell=[(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
          (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]
    for p in cell:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes)
nidx={n:i for i,n in enumerate(nodes)}
P=np.array(nodes)
N=len(nodes)
# nn edges (distance L)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
print(f"FCC patch: N={N} nodes, E={E} edges, L={L:.4f}")

# d1: edges->nodes (signed incidence), shape (N, E). Compatible strains = image of d1^T.
# For linearized strain: edge strain from vertex displacement u is e_ij = (u_i-u_j).(x_i-x_j)/L
# The compatible space is spanned by these. Build the "compatibility operator" B: (3N) -> E
B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=(P[i]-P[j]); dhat=d/np.linalg.norm(d)
    B[k,3*i:3*i+3]=dhat
    B[k,3*j:3*j+3]=-dhat
# compatible strain subspace = column space of B (image of displacements)
# incompatible/syndrome space = orthogonal complement in R^E

# --- insert trapped node defect ---
# pick a tetrahedral void, add node, bond to 4 neighbors. The strain: those 4 new bonds
# want length L but the node sits at 0.433 -> but node is NEW. Instead model the defect
# as the matter paper does: the trapped node DISPLACES its 4 neighbors (pushes them),
# forcing edge-length errors on the surrounding FCC bonds. 
# Simplest faithful model: the defect imposes a fixed strain pattern on the edges incident
# to the void's 4 vertices (they are pushed outward by the trapped node). 
void=np.array([.25,.25,.25])
# 4 surrounding vertices
tet=sorted(range(N),key=lambda i:np.linalg.norm(P[i]-void))[:4]
print(f"trapped node at {void}, pushes 4 vertices: {[tuple(P[i]) for i in tet]}")

# The defect forces an outward radial displacement on these 4 (they relax away from the
# over-close trapped node). This is a DISPLACEMENT -> if purely that, it's COMPATIBLE (gauge).
# The question: is the FORCED strain compatible or not? The trapped node bonds to 4 verts;
# those 4 bonds have a fixed (strained) length. That's a constraint on 4 edges that may NOT
# be reachable by any global displacement = incompatible = J.
# Model: impose strain eps0 on the (up to) edges among the 4 tet vertices (they're mutually
# bonded - the void tetrahedron's 6 edges are FCC bonds). The trapped node forces these 6
# edges to a DIFFERENT length (the pocket squeezes them). Impose e=eps0 on those 6 edges.
tet_edges=[eidx[tuple(sorted((i,j)))] for i,j in it.combinations(tet,2) if tuple(sorted((i,j))) in eidx]
print(f"void tetrahedron has {len(tet_edges)} FCC edges among its 4 vertices")
e_defect=np.zeros(E)
for te in tet_edges: e_defect[te]=1.0   # unit strain on the pocket edges

# decompose: compatible part = projection onto col(B); J = e - compatible
# solve least squares B u = e_defect
u,res,rk,sv=np.linalg.lstsq(B,e_defect,rcond=None)
e_compat=B@u
J=e_defect-e_compat
print()
print(f"defect strain norm ||e_defect|| = {np.linalg.norm(e_defect):.4f}")
print(f"compatible (gauge) part  ||e_compat|| = {np.linalg.norm(e_compat):.4f}")
print(f"INCOMPATIBLE syndrome    ||J|| = {np.linalg.norm(J):.4f}")
print(f"  fraction incompatible = {np.linalg.norm(J)/np.linalg.norm(e_defect):.3f}")
print()
if np.linalg.norm(J)>1e-9:
    print(">>> The defect sources a NONZERO incompatible syndrome J.")
    print("    This is the part the decoder CANNOT remove = the gravitational source.")
    # check conservation: d1 J should vanish (J divergence-free at nodes)
    d1=np.zeros((N,E))
    for k,(i,j) in enumerate(edges):
        d1[i,k]+=1; d1[j,k]-=1
    divJ=d1@J
    print(f"    ||d1 J|| (divergence) = {np.linalg.norm(divJ):.4e}  {'(conserved)' if np.linalg.norm(divJ)<1e-6 else '(NOT conserved as-is)'}")
else:
    print(">>> J=0: the defect strain is fully compatible (gauge). No source. ")
    print("    This defect does not gravitate.")
