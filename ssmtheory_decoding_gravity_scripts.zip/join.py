"""
The JOIN: does verification cost C_x (QEC mass) predict incompatible strain ||J_cons||
(gravitational source) for the SAME defect? If proportional across defects, the indirect
chain QEC->mass->strain->gravity composes.

For several defect types, compute:
  - C_x = E_s * C_s  (verification cost = mass, from the mass paper's rule)
  - ||J_cons|| = magnitude of conserved incompatible strain the defect sources
and test C_x vs ||J_cons|| (or ||J_cons||^2, since energy/mass ~ strain^2).
"""
import numpy as np, itertools as it

a=1.0; L=a/np.sqrt(2)
R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d)
    d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)

center=np.array([R/2.,R/2.,R/2.])

def Jcons_of(strained_edges, strain_vals):
    e_def=np.zeros(E)
    for te,val in zip(strained_edges,strain_vals): e_def[te]=val
    u,*_=np.linalg.lstsq(B,e_def,rcond=None); J=e_def-B@u
    Jc=J-d1p@(d1@J)
    return np.linalg.norm(Jc)

def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]

# Define a family of defects of increasing "size" (footprint), and for each:
#  - E_s = number of strained edges (physical qubits in footprint)
#  - C_s = number of stabilizers touching them (proxy: vertices + faces of the footprint)
#  - C_x = E_s * C_s  (verification cost)
#  - ||J_cons|| from unit strain on those edges
defects=[]
# 1-edge defect (smallest): strain one bond
e1=[eidx[tuple(sorted((near(center,2)[0],near(center,2)[1])))]] if tuple(sorted(near(center,2)[:2])) in eidx else None
# build defects by clusters around the center void of growing radius
void=center+np.array([.25,.25,.25])
for m in [2,3,4,6,8,12]:  # cluster of m nodes
    cl=near(void,m)
    cle=[eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
    if len(cle)==0: continue
    Es=len(cle)                       # edges in footprint = physical qubits
    # C_s: stabilizers = vertices in cluster (V) + triangular faces among them (F)
    V=len(cl)
    Ftri=sum(1 for i,j,k in it.combinations(cl,3)
             if all(tuple(sorted(x)) in eidx for x in [(i,j),(j,k),(i,k)]))
    Cs=V+Ftri
    Cx=Es*Cs
    Jn=Jcons_of(cle,[1.0]*len(cle))
    defects.append((m,Es,V,Ftri,Cs,Cx,Jn))

print(f"{'m':>3} | {'E_s':>4} | {'V':>3} | {'Ftri':>4} | {'C_s':>4} | {'C_x=E_s*C_s':>11} | {'||J_cons||':>10} | {'||J||^2':>8}")
for m,Es,V,Ftri,Cs,Cx,Jn in defects:
    print(f"{m:>3} | {Es:>4} | {V:>3} | {Ftri:>4} | {Cs:>4} | {Cx:>11} | {Jn:>10.3f} | {Jn**2:>8.2f}")

# test proportionality C_x vs ||J_cons|| and vs ||J_cons||^2
import numpy as np
Cx=np.array([d[5] for d in defects],float)
Jn=np.array([d[6] for d in defects],float)
print()
for label,y in [("||J_cons||",Jn),("||J_cons||^2",Jn**2)]:
    if len(Cx)>2 and y.std()>0:
        r=np.corrcoef(Cx,y)[0,1]
        # fit y = a*Cx
        a=np.sum(Cx*y)/np.sum(Cx*Cx)
        print(f"  C_x vs {label}: corr={r:.3f}, best y={a:.4e}*C_x")
print()
print("If C_x and ||J_cons|| (or ^2) are strongly correlated, the mass layer and the")
print("strain layer agree on the same defect -> the indirect chain composes.")
