#!/usr/bin/env python3
"""Exact-arithmetic verification for Section 2.4 of
"Linearized Gravity on the D4 Lattice as a Self-Decoding Code".
Reproduces every quantitative diagnostic used in the paper, including the explicit D4 Regge ->
Fierz-Pauli numerical verification: flat D4 background, deficit-map gauge kernel, kinetic
isotropy, TT/trace/gauge sector coefficients, and comparison of the Regge kinetic quadratic
form with the linearized Einstein / Fierz-Pauli quadratic form. The Fierz-Pauli identity is
established both numerically (finite-difference Hessian) and analytically: the closing block
evaluates the dihedral-angle derivatives in closed form, finds all 1100 kinetic-tensor entries
exactly rational, and proves C(k,eps)+q_FP(k,eps) expands to zero as a symbolic identity in
general k and eps (for this subdivision). It does NOT address the exact general covariance of the
matter coupling, which the paper leaves open. Requires numpy, scipy, sympy; runs in a few seconds.

NOTE ON THE SECTOR COEFFICIENTS.  The closing block reports the CHARACTERISTIC
POLYNOMIAL of the operator in an orthonormal basis of Sym(R^4),
    det(C(k) - lambda) = lambda^4 (lambda + 1/2)^5 (lambda - 1),
superseding the "(-1:+3:0)" reported previously.  Those numbers came from
evaluating the quadratic form on eps_TT = uu-vv (norm^2 = 2) and eps_trace =
delta (norm^2 = 4), i.e. two different normalizations, and undercounted the
transverse-traceless multiplicity: Euclidean 4D has FIVE TT polarizations, not
four, and 4+1+4 does not reconstruct a 10-dimensional space.  The invariant
content is the relative SIGN (the conformal mode opposes the gravitons); the
magnitude of the ratio is normalization-dependent, so the convention is stated.

Blocks with no counterpart in the manuscript have been removed from this script:
the "induced Newton constant" calculation (which used hardcoded Nb=3, a1=1/6,
Lam=pi with no derivation) and the "self-bound vacuum" block (A_=1.0, B_=3.0).
"""
import numpy as np, sympy as sp, itertools as it
def nrm(v): return v/np.linalg.norm(v)

print("== Theorem 1: rank-four isotropy of D4 ==")
D4=[]
for mu in range(4):
    for nu in range(mu+1,4):
        for sa in(1,-1):
            for sb in(1,-1):
                v=[0,0,0,0];v[mu]=sa;v[nu]=sb;D4.append(np.array(v,float))
T=np.zeros((4,)*4)
for n in D4:
    for i,j,k,l in it.product(range(4),repeat=4): T[i,j,k,l]+=n[i]*n[j]*n[k]*n[l]
S=np.zeros((4,)*4); d=np.eye(4)
for i,j,k,l in it.product(range(4),repeat=4): S[i,j,k,l]=d[i,j]*d[k,l]+d[i,k]*d[j,l]+d[i,l]*d[j,k]
print("  T == 4*S ?", np.allclose(T,4*S), " ratio T1111/T1122 =",T[0,0,0,0]/T[0,0,1,1])

print("== Prop 1: R[d u] = 0 identically ==")
x=sp.symbols('x0 x1 x2 x3',real=True); u=[sp.Function(f'u{m}')(*x) for m in range(4)]
def dd(f,i): return sp.diff(f,x[i])
h=[[dd(u[m],n)+dd(u[n],m) for n in range(4)] for m in range(4)]
def Riem(m,n,r,s): return sp.Rational(1,2)*(dd(dd(h[m][s],n),r)+dd(dd(h[n][r],m),s)-dd(dd(h[n][s],m),r)-dd(dd(h[m][r],n),s))
print("  all components zero?", all(sp.simplify(Riem(m,n,r,s))==0 for m in range(4) for n in range(4) for r in range(4) for s in range(4)))

print("== Section 4: edge-dyad span = 10, TT mode carried, TT curvature != 0 ==")
dirs=[]
for mu in range(4):
    for nu in range(mu+1,4):
        for sb in(1,-1): vv=[0,0,0,0];vv[mu]=1;vv[nu]=sb;dirs.append(np.array(vv,float)/np.sqrt(2))
def sc(n):
    M=np.outer(n,n); return np.array([M[i,i] for i in range(4)]+[M[i,j] for i in range(4) for j in range(i+1,4)])
print("  rank of 12 edge-dyads in Sym^2(R^4):", np.linalg.matrix_rank(np.array([sc(n) for n in dirs])))
hTT=np.zeros((4,4)); hTT[1,1]=1; hTT[2,2]=-1
print("  '+' TT mode edge strains nonzero?", np.any(np.abs([0.5*n@hTT@n for n in dirs])>1e-9))
w=sp.symbols('omega',positive=True); k=[w,0,0,w]; eps=sp.zeros(4,4); eps[1,1]=1; eps[2,2]=-1
ph=sp.exp(sp.I*sum(k[m]*x[m] for m in range(4))); hh=[[eps[m,n]*ph for n in range(4)] for m in range(4)]
def Rm(m,n,r,s): return sp.Rational(1,2)*(dd(dd(hh[m][s],n),r)+dd(dd(hh[n][r],m),s)-dd(dd(hh[n][s],m),r)-dd(dd(hh[m][r],n),s))
print("  R_0101 =", sp.simplify(Rm(0,1,0,1)/ph), "  R_0202 =", sp.simplify(Rm(0,2,0,2)/ph))

# === Explicit D4 Regge -> Fierz-Pauli keystone (requires scipy) ===
# Compact, self-contained core for the explicit D4 Regge -> Fierz-Pauli verification.
import numpy as np, itertools as it
from scipy.spatial import Delaunay
from collections import defaultdict

def build():
    pts=[v for v in it.product(range(-3,4),repeat=4) if sum(v)%2==0 and sum(x*x for x in v)<=8]
    pts=np.array(sorted(pts),float); O=int(np.where((pts==0).all(1))[0][0])
    simp=[tuple(s) for s in Delaunay(pts,qhull_options='Qt').simplices]
    return pts,O,simp
def embed(L):
    G=np.zeros((4,4))
    for i in range(1,5):
        for j in range(1,5): G[i-1,j-1]=0.5*(L[0,i]+L[0,j]-L[i,j])
    w,V=np.linalg.eigh(G); w=np.clip(w,0,None)
    X=np.zeros((5,4)); X[1:]=V@np.diag(np.sqrt(w)); return X
def _n(v): n=np.linalg.norm(v); return v/n if n>1e-14 else v
def dih(X):
    u1=_n(X[1]-X[0]); t2=X[2]-X[0]; u2=_n(t2-t2@u1*u1)
    pp=lambda z:z-z@u1*u1-z@u2*u2; pd,pe=pp(X[3]-X[0]),pp(X[4]-X[0])
    return np.arccos(np.clip(pd@pe/(np.linalg.norm(pd)*np.linalg.norm(pe)),-1,1))

class D4Regge:
    def __init__(self):
        self.pts,self.O,self.simp=build()
        O=self.O
        self.star=[s for s in self.simp if O in s]
        self.hinges=sorted({tuple(sorted(t)) for s in self.star for t in it.combinations(s,3) if O in t})
        self.around=defaultdict(list)
        for s in self.simp:
            for t in it.combinations(sorted(s),3):
                if O in t: self.around[t].append(s)
        self.edges=sorted({tuple(sorted((O,a))) for s in self.star for a in s if a!=O})
    def _sl(self,i,j,ov):
        k=tuple(sorted((i,j))); return ov.get(k,(self.pts[i]-self.pts[j])@(self.pts[i]-self.pts[j]))
    def deficit(self,t,ov):
        tot=0
        for s in self.around[t]:
            o=[x for x in s if x not in t]; sv=list(t)+o; L=np.zeros((5,5))
            for a in range(5):
                for b in range(a+1,5): L[a,b]=L[b,a]=self._sl(sv[a],sv[b],ov)
            tot+=dih(embed(L))
        return 2*np.pi-tot
    def flatness(self): return max(abs(self.deficit(t,{})) for t in self.hinges)
    def deficit_map(self,eps=1e-6):           # D[h,e]=d def_h/d(L_e^2) for origin edges
        D=np.zeros((len(self.hinges),len(self.edges)))
        for je,e in enumerate(self.edges):
            l0=(self.pts[e[0]]-self.pts[e[1]])@(self.pts[e[0]]-self.pts[e[1]])
            dp=np.array([self.deficit(t,{e:l0+eps}) for t in self.hinges])
            dm=np.array([self.deficit(t,{e:l0-eps}) for t in self.hinges])
            D[:,je]=(dp-dm)/(2*eps)
        return D
    def gauge(self):                           # squared-length gauge vectors (origin translations)
        G=np.zeros((len(self.edges),4))
        for je,e in enumerate(self.edges):
            a=e[1] if e[0]==self.O else e[0]; G[je,:]=-2.0*(self.pts[a]-self.pts[self.O])
        return G
    def hessian(self,eps=1e-6):                # M[(e,e')] = sum_h (dA_h/dL_e)(d def_h/dL_e')
        starsimp={s for t in self.hinges for s in self.around[t]}
        defgrad={}
        for h in self.hinges:
            es={tuple(sorted((i,j))) for s in self.around[h] for i,j in it.combinations(s,2)}
            for e in es:
                L0=(self.pts[e[0]]-self.pts[e[1]])@(self.pts[e[0]]-self.pts[e[1]])
                defgrad[(h,e)]=(self.deficit(h,{e:L0+eps})-self.deficit(h,{e:L0-eps}))/(2*eps)
        def tri2(a2,b2,c2): return 0.25*np.sqrt(max(2*a2*b2+2*b2*c2+2*c2*a2-a2*a2-b2*b2-c2*c2,0))
        def dA(h,e):
            i,j,k=h; L={tuple(sorted((i,j))):(self.pts[i]-self.pts[j])@(self.pts[i]-self.pts[j]),
                        tuple(sorted((i,k))):(self.pts[i]-self.pts[k])@(self.pts[i]-self.pts[k]),
                        tuple(sorted((j,k))):(self.pts[j]-self.pts[k])@(self.pts[j]-self.pts[k])}
            f=lambda Lm:tri2(Lm[tuple(sorted((j,k)))],Lm[tuple(sorted((i,k)))],Lm[tuple(sorted((i,j)))])
            Lp=dict(L);Lp[e]=L[e]+eps;Lm=dict(L);Lm[e]=L[e]-eps; return (f(Lp)-f(Lm))/(2*eps)
        M=defaultdict(float)
        for e in self.edges:
            for h in self.hinges:
                if e[0] in h and e[1] in h:
                    g=dA(h,e)
                    for ep in {tuple(sorted((i,j))) for s in self.around[h] for i,j in it.combinations(s,2)}:
                        M[(e,ep)]+=g*defgrad[(h,ep)]
        self.M=M; return M
    def coeff(self,kh,epsT):                   # small-k kinetic coefficient per unit |k|^2 (analytic)
        kh=_n(kh)
        mid=lambda e:0.5*(self.pts[e[0]]+self.pts[e[1]]); vec=lambda e:self.pts[e[1]]-self.pts[e[0]]
        p=lambda e:epsT.dot(vec(e)).dot(vec(e)); tot=0
        for (e,ep),m in self.M.items():
            dx=mid(e)-mid(ep); tot+=m*p(e)*p(ep)*(kh@dx)**2
        return -0.25*tot

def TTpol(kh,which=0):
    kh=_n(kh); A=np.array([1.0,0,0,0])
    if abs(kh@A)>0.9: A=np.array([0,1.0,0,0])
    u=_n(A-(A@kh)*kh); B=np.array([0,0,1.0,0]); B=B-(B@kh)*kh-(B@u)*u
    if np.linalg.norm(B)<0.3: B=np.array([0,0,0,1.0]); B=B-(B@kh)*kh-(B@u)*u
    v=_n(B)
    return (np.outer(u,u)-np.outer(v,v)) if which==0 else (np.outer(u,v)+np.outer(v,u))


# ---- Section 5: explicit linearized D4 Regge -> Fierz-Pauli ----
print("== Section 5: explicit D4 Regge -> Fierz-Pauli ==")
_r=D4Regge()
print("flat background max|deficit|       :", f"{_r.flatness():.2e}")
_D=_r.deficit_map(); _G=_r.gauge()
_rank=np.linalg.matrix_rank(_D,tol=1e-6); _ker=len(_r.edges)-_rank
print("deficit-map rank / kernel / gauge  :", _rank, "/", _ker, "/ 4   (kernel = diffeomorphisms)")
print("  ||D . G_gauge||                  :", f"{np.max(np.abs(_D@_G)):.2e}")
_r.hessian()
_dirs=[('axis',[0,0,0,1]),('face',[1,1,0,0]),('body',[1,1,1,1]),('mix',[2,1,1,0]),('mix2',[3,1,0,0])]
_cs=[_r.coeff(np.array(d,float),TTpol(np.array(d,float))) for _,d in _dirs]
print("TT kinetic coeff per direction     :", [f"{c:.5f}" for c in _cs])
print("  isotropy fractional spread       :", f"{(max(_cs)-min(_cs))/abs(np.mean(_cs)):.2e}")
_kh=np.array([0,0,0,1.0])
print("[legacy, UNNORMALISED test tensors] TT+ / TTx / delta / gauge :",
      f"{_r.coeff(_kh,TTpol(_kh,0)):.4f}", "/", f"{_r.coeff(_kh,TTpol(_kh,1)):.4f}", "/",
      f"{_r.coeff(_kh,np.eye(4)):.4f}", "/",
      f"{_r.coeff(_kh,np.outer(_kh,[1,0,0,0])+np.outer([1,0,0,0],_kh)):.1e}")
print("  => two-derivative, isotropic, spin-2, gauge=diffeos: Fierz-Pauli.")

# ---- Section 5 (continued): continuum operator == linearized Einstein operator ----
def _qFP(kh,eps):
    kh=kh/np.linalg.norm(kh); a=kh@eps; s=kh@eps@kh; t=np.trace(eps)
    return 0.5*np.sum(eps*eps)-a@a+t*s-0.5*t*t
np.random.seed(0)
_rat=[]
for _ in range(60):
    _k=np.random.randn(4); _e=np.random.randn(4,4); _eps=_e+_e.T
    _rat.append(_r.coeff(_k,_eps)/_qFP(_k,_eps))
_rat=np.array(_rat)
print("continuum operator vs linearized Einstein (generic polarizations):")
print("  C^(2)_Regge / q_FP  mean =", f"{_rat.mean():.6f}", " std/mean =", f"{_rat.std()/abs(_rat.mean()):.1e}")
print("  => D4 Regge kinetic operator matches the linearized Einstein operator to ~1e-8 (numerical Fierz-Pauli identity).")

# ============================================================================
#  ANALYTIC proof: D4 Regge kinetic operator == linearized Einstein operator
#  (exact symbolic evaluation of dihedral-angle derivatives; rational Hessian)
# ============================================================================
import sympy as _sp
def _analytic_fierz_pauli_proof():
    import itertools as _it
    from scipy.spatial import Delaunay as _Del
    from collections import defaultdict as _dd
    # closed-form dihedral angle at hinge(0,1,2), apexes 3,4, in squared edge lengths
    _L={(i,j):_sp.Symbol(f'L{i}{j}',positive=True) for i in range(5) for j in range(i+1,5)}
    _LL=lambda i,j:_L[(min(i,j),max(i,j))]
    def _xx(i,j): return _LL(0,i) if i==j else _sp.Rational(1,2)*(_LL(0,i)+_LL(0,j)-_LL(i,j))
    _g=_xx(1,1)*_xx(2,2)-_xx(1,2)**2
    def _perp(a,b):
        ua,va=_xx(1,a),_xx(2,a); ub,vb=_xx(1,b),_xx(2,b)
        return _xx(a,b)-((_xx(2,2)*ua-_xx(1,2)*va)*ub+(-_xx(1,2)*ua+_xx(1,1)*va)*vb)/_g
    _th=_sp.acos(_perp(3,4)/_sp.sqrt(_perp(3,3)*_perp(4,4)))
    _dth={k:_sp.diff(_th,_L[k]) for k in _L}
    _la,_lb,_lc=_sp.symbols('la lb lc',positive=True)
    _A=_sp.sqrt(2*_la*_lb+2*_lb*_lc+2*_lc*_la-_la**2-_lb**2-_lc**2)/4
    _dA={'la':_sp.diff(_A,_la),'lb':_sp.diff(_A,_lb),'lc':_sp.diff(_A,_lc)}
    # subdivision
    _pts=[v for v in _it.product(range(-3,4),repeat=4) if sum(v)%2==0 and sum(x*x for x in v)<=8]
    _pts=__import__('numpy').array(sorted(_pts),float)
    _O=int((_pts==0).all(1).nonzero()[0][0]); _simp=[tuple(s) for s in _Del(_pts,qhull_options='Qt').simplices]
    _star=[s for s in _simp if _O in s]
    _hin=sorted({tuple(sorted(t)) for s in _star for t in _it.combinations(s,3) if _O in t})
    _ar=_dd(list)
    for s in _simp:
        for t in _it.combinations(sorted(s),3):
            if _O in t: _ar[t].append(s)
    _eO=sorted({tuple(sorted((_O,a))) for s in _star for a in s if a!=_O})
    _sq=lambda i,j:int(round((_pts[i]-_pts[j])@(_pts[i]-_pts[j])))
    _ca={}
    def _dts(s,h,e):
        d=[v for v in s if v not in h]; loc=list(h)+d; pos={g:i for i,g in enumerate(loc)}
        ei,ej=sorted((pos[e[0]],pos[e[1]])); key=(tuple(_sq(loc[i],loc[j]) for i in range(5) for j in range(i+1,5)),(ei,ej))
        if key in _ca: return _ca[key]
        sub={_L[(i,j)]:_sp.Integer(_sq(loc[i],loc[j])) for i in range(5) for j in range(i+1,5)}
        v=_sp.nsimplify(_dth[(ei,ej)].subs(sub)); _ca[key]=v; return v
    def _ddef(h,e): return -sum((_dts(s,h,e) for s in _ar[h] if e[0] in s and e[1] in s),_sp.Integer(0))
    def _dArea(h,e):
        i,j,k=h; sub={_la:_sq(j,k),_lb:_sq(i,k),_lc:_sq(i,j)}; e=tuple(sorted(e))
        ex=_dA['la'] if e==tuple(sorted((j,k))) else _dA['lb'] if e==tuple(sorted((i,k))) else _dA['lc']
        return _sp.nsimplify(ex.subs(sub))
    _M={}
    for e in _eO:
        for h in [h for h in _hin if e[0] in h and e[1] in h]:
            da=_dArea(h,e)
            if da==0: continue
            for ep in {tuple(sorted((a,b))) for s in _ar[h] for a,b in _it.combinations(s,2)}:
                _M[(e,ep)]=_sp.nsimplify(_M.get((e,ep),_sp.Integer(0))+da*_ddef(h,ep))
    nirr=sum(0 if v.is_rational else 1 for v in _M.values())
    # symbolic contraction vs linearized Einstein
    _E=_sp.zeros(4,4)
    for i in range(4):
        for j in range(i,4): sym=_sp.Symbol(f'e{i}{j}'); _E[i,j]=sym; _E[j,i]=sym
    _k=_sp.Matrix(_sp.symbols('k0 k1 k2 k3'))
    _mid=lambda e:(_pts[e[0]]+_pts[e[1]])/2
    def _p(e): d=_sp.Matrix([int(round(x)) for x in (_pts[e[1]]-_pts[e[0]])]); return (d.T*_E*d)[0]
    def _kx(e,ep): dx=_sp.Matrix([_sp.Rational(int(round(2*x)),2) for x in (_mid(e)-_mid(ep))]); return (_k.dot(dx))**2
    _C=_sp.expand(-_sp.Rational(1,4)*sum((m*_p(e)*_p(ep)*_kx(e,ep) for (e,ep),m in _M.items() if m!=0),_sp.Integer(0)))
    _kk=(_k.T*_k)[0]; _a2=(_k.T*_E*_E*_k)[0]; _s=(_k.T*_E*_k)[0]; _t=_sp.trace(_E)
    _n2=sum(_E[i,j]**2 for i in range(4) for j in range(4))
    _qFP=_sp.Rational(1,2)*_kk*_n2-_a2+_t*_s-_sp.Rational(1,2)*_kk*_t**2
    _resid=_sp.expand(_C+_qFP)
    return len(_M),nirr,(_resid==0),_M,_pts

# run the analytic proof as the capstone
_nM,_nirr,_ok,_Mrat,_ptsrat=_analytic_fierz_pauli_proof()
print("\n== ANALYTIC Fierz-Pauli identity (exact symbolic, this subdivision) ==")
print(f"  exact rational Hessian: {_nM} entries ({_nirr} irrational)")
print(f"  C(k,eps) + q_FP(k,eps) expands to {'0  -> EXACT operator identity' if _ok else 'NONZERO'}")
print("  => D4 Regge kinetic operator = linearized Einstein operator, exactly (proven).")


# ============================================================================
#  Exact characteristic polynomial of the operator in an ORTHONORMAL basis of
#  Sym(R^4), built from the RATIONAL Hessian returned by the analytic proof
#  above.  This is Eq. (sectors) of the manuscript and supersedes "(-1:+3:0)".
# ============================================================================
def _exact_charpoly(M, pts, kvec=(0, 1, 0, 0)):
    idx = [(i, i) for i in range(4)] + list(it.combinations(range(4), 2))
    norm2 = [sp.Integer(1)] * 4 + [sp.Integer(2)] * 6

    def dyad(e):
        d = [int(round(x)) for x in (pts[e[1]] - pts[e[0]])]
        return [sp.Integer(d[i] * d[j] * (1 if i == j else 2)) for i, j in idx]

    kk = [sp.Integer(c) for c in kvec]
    k2 = sum(c * c for c in kk)
    half = lambda x: sp.Rational(int(round(2 * x)), 2)
    A = sp.zeros(10, 10)
    dy = {}
    for (e, ep), m in M.items():
        if m == 0:
            continue
        dy.setdefault(e, dyad(e)); dy.setdefault(ep, dyad(ep))
        dx = [half(x) for x in ((pts[e[0]] + pts[e[1]]) / 2 - (pts[ep[0]] + pts[ep[1]]) / 2)]
        w = -sp.Rational(1, 4) * m * sum(kk[i] * dx[i] for i in range(4)) ** 2 / k2
        if w == 0:
            continue
        for a in range(10):
            if dy[e][a] == 0:
                continue
            for b in range(10):
                if dy[ep][b] == 0:
                    continue
                A[a, b] += w * dy[e][a] * dy[ep][b]
    A = sp.Matrix(10, 10, lambda a, b: sp.Rational(1, 2) * (A[a, b] + A[b, a]))
    all_rational = all(v.is_rational for v in A)
    A = sp.expand(sp.diag(*[1 / sp.sqrt(n) for n in norm2]) * A
                  * sp.diag(*[1 / sp.sqrt(n) for n in norm2]))
    lam = sp.Symbol('lambda')
    return sp.factor(A.charpoly(lam).as_expr()), all_rational


print("\n== EXACT sector spectrum (orthonormal basis of Sym(R^4)) ==")
_cp, _rat = _exact_charpoly(_Mrat, _ptsrat)
print(f"  10x10 operator entries all rational: {_rat}")
print(f"  char. polynomial: {_cp}")
print("  i.e. lambda^4 (lambda+1/2)^5 (lambda-1):"
      " gauge 0 (x4), TT -1/2 (x5), trace +1 (x1)")
print("  normalized to unit TT coefficient: (TT : trace : gauge) = (-1 : +2 : 0)")
