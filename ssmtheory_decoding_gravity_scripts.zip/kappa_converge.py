"""Confirm kappa converges to a fixed bulk value as patch size grows (boundary effect vanishes)."""
import numpy as np, itertools as it
def kappa_at(R):
    a=1.0; L=a/np.sqrt(2)
    nodes=set()
    for cx,cy,cz in it.product(range(R),repeat=3):
        base=np.array([cx,cy,cz])
        for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
                  (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
            nodes.add(tuple(np.round(base+np.array(p),3)))
    nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
    edges=[]
    for i in range(N):
        for j in range(i+1,N):
            if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
    E=len(edges); eidx={e:k for k,e in enumerate(edges)}
    d1=np.zeros((N,E)); B=np.zeros((E,3*N))
    for k,(i,j) in enumerate(edges):
        d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
        B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
    d1p=np.linalg.pinv(d1)
    void=np.array([R/2,R/2,R/2])+np.array([.25,.25,.25])
    cl=sorted(range(N),key=lambda i:np.linalg.norm(P[i]-void))[:4]
    cle=[eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]
    V=len(cl); Ftri=sum(1 for i,j,k in it.combinations(cl,3) if all(tuple(sorted(x)) in eidx for x in [(i,j),(j,k),(i,k)]))
    Cx=len(cle)*(V+Ftri)
    e=np.zeros(E)
    for te in cle: e[te]=1.0
    u,*_=np.linalg.lstsq(B,e,rcond=None); J=e-B@u; Jc=J-d1p@(d1@J)
    return Cx/np.linalg.norm(Jc)**2
print("kappa vs patch size (central tetra-void, deepest bulk):")
for R in [3,4,5,6]:
    print(f"  R={R}: kappa = {kappa_at(R):.4f}")
