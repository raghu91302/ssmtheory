#!/usr/bin/env python3
"""Regenerates the figures for "Linearized Gravity on the D4 Lattice as a
Self-Decoding Code".

  fig_isotropy.pdf  the directional kinetic coefficient of the D4 root system at
                    rank four and at rank six, along a path through direction
                    space.  Rank four is exactly constant (the 24-cell is a
                    spherical 4-design), rank six varies by 40%.  This is the
                    content of Section 5: the quadratic graviton operator is
                    exactly isotropic, hence exactly Lorentz invariant, while the
                    cubic vertex is not.

  fig_flow.pdf      convergence of the decoding flow.  Retained for continuity,
                    but note that with the corrected operator the condition
                    number is exactly 2, so this is ordinary geometric
                    convergence of gradient descent on a well-conditioned
                    quadratic and the figure carries little information; the
                    sentence in Section 4 says as much in one line.

fig_scaling.pdf is no longer produced.  With the operator assembled as the O(k^2)
coefficient, k-independence is automatic and a momentum scan is not a test; the
two-derivative property is established by the exact identity of Section 2.4.
"""
import itertools as it

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ---------------------------------------------------------------- root system
ROOTS = np.array([[si if k == i else sj if k == j else 0 for k in range(4)]
                  for i, j in it.combinations(range(4), 2)
                  for si in (1, -1) for sj in (1, -1)], float)


def directional(v, n):
    """sum over roots of (r . v)^n : the rank-n moment contracted with v^n"""
    return sum((r @ v) ** n for r in ROOTS)


def path(t):
    """t in [0,2]: coordinate axis -> face diagonal -> body diagonal"""
    a = np.array([0, 0, 0, 1.])
    f = np.array([1, 1, 0, 0.]) / np.sqrt(2)
    b = np.array([1, 1, 1, 1.]) / 2
    v = (1 - t) * a + t * f if t <= 1 else (2 - t) * f + (t - 1) * b
    return v / np.linalg.norm(v)


def fig_isotropy():
    ts = np.linspace(0, 2, 401)
    T4 = np.array([directional(path(t), 4) for t in ts])
    T6 = np.array([directional(path(t), 6) for t in ts])

    fig, ax = plt.subplots(figsize=(5.8, 3.6))
    ax.plot(ts, T4, lw=2.0, label=r'rank four (graviton operator)')
    ax.plot(ts, T6, lw=2.0, ls='--', label=r'rank six (cubic vertex)')
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels(['axis\n(0,0,0,1)',
                        'face diagonal\n(1,1,0,0)',
                        'body diagonal\n(1,1,1,1)'], fontsize=8)
    ax.set_ylabel(r'$T_{\mu\nu\cdots}\hat k^\mu\hat k^\nu\cdots$')
    ax.set_ylim(11.2, 18.8)
    ax.grid(alpha=0.3)
    ax.annotate(f'exactly constant  (spread {100*(T4.max()-T4.min())/T4.mean():.0e}\\%)',
                xy=(1.0, 12.0), xytext=(0.42, 13.3), fontsize=8,
                arrowprops=dict(arrowstyle='->', lw=0.8))
    ax.annotate(f'varies by {100*(T6.max()-T6.min())/T6.min():.0f} percent',
                xy=(1.72, T6[int(0.86*len(ts))]), xytext=(1.05, 16.9), fontsize=8,
                arrowprops=dict(arrowstyle='->', lw=0.8))
    ax.legend(fontsize=8, loc='upper left')
    fig.tight_layout()
    fig.savefig('fig_isotropy.pdf')
    print(f"wrote fig_isotropy.pdf   rank-4 spread "
          f"{100*(T4.max()-T4.min())/T4.mean():.1e}%   rank-6 spread "
          f"{100*(T6.max()-T6.min())/T6.min():.0f}%")


def fig_flow():
    w = np.array([-0.5] * 5 + [0.0] * 4 + [1.0])      # Fierz-Pauli spectrum
    F = np.diag(w)
    J = np.zeros(10); J[9] = 1.0
    h = np.zeros(10)
    dt = 0.5 / np.max(w ** 2)
    res = []
    for _ in range(1200):
        h = h - dt * (F @ (F @ h - J))
        res.append(np.linalg.norm(F @ h - J) / np.linalg.norm(J))
    fig, ax = plt.subplots(figsize=(5.0, 3.3))
    ax.semilogy(np.arange(1, len(res) + 1), np.maximum(res, 1e-17), lw=1.6)
    ax.set_xlabel('decoding-flow iteration')
    ax.set_ylabel(r'residual $\|Fh-J\|/\|J\|$')
    ax.grid(alpha=0.3, which='both')
    ax.set_ylim(1e-17, 2)
    fig.tight_layout()
    fig.savefig('fig_flow.pdf')
    print(f"wrote fig_flow.pdf   condition number "
          f"{np.max(np.abs(w[np.abs(w)>1e-12]))/np.min(np.abs(w[np.abs(w)>1e-12])):.1f}")


if __name__ == '__main__':
    fig_isotropy()
    fig_flow()
