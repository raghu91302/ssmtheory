import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    'font.size': 11, 'font.family': 'serif',
    'axes.linewidth': 0.8, 'xtick.direction': 'in', 'ytick.direction': 'in',
    'xtick.top': True, 'ytick.right': True, 'figure.dpi': 150,
})

# ---- Figure 1: two panels, k^2 scaling and Newtonian ----
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8.2, 3.4))

# Panel (a): Q(k) ~ k^2 -> max|eig|/k^2 constant
k1  = np.array([0.05, 0.10, 0.20])
r1  = np.array([11.0043, 10.9832, 10.8992])
ax1.plot(k1, r1, 'o-', color='#1f4e79', ms=6, lw=1.4, mfc='white', mec='#1f4e79', mew=1.4)
ax1.axhline(11.0, ls=':', c='0.6', lw=1)
ax1.set_xlabel(r'$|k|$')
ax1.set_ylabel(r'$\max|\mathrm{eig}\,Q(k)|\,/\,k^2$')
ax1.set_title(r'(a) two-derivative scaling', fontsize=10.5)
ax1.set_ylim(10.6, 11.2)
ax1.set_xlim(0, 0.22)
ax1.text(0.06, 10.72, r'constant $\Rightarrow Q(k)=O(k^2)$', fontsize=9, color='0.35')

# Panel (b): Newtonian  h00 * k^2 constant -> h00 ~ 1/k^2
k2  = np.array([0.06, 0.10, 0.16, 0.24])
h2  = np.array([-0.111045, -0.111338, -0.112202, -0.114097])
ax2.plot(k2, h2, 's-', color='#7a1f1f', ms=6, lw=1.4, mfc='white', mec='#7a1f1f', mew=1.4)
ax2.axhline(-0.1110, ls=':', c='0.6', lw=1)
ax2.set_xlabel(r'$|k|$')
ax2.set_ylabel(r'$h_{00}(k)\,k^2$')
ax2.set_title(r'(b) Newtonian limit', fontsize=10.5)
ax2.set_ylim(-0.118, -0.108)
ax2.set_xlim(0, 0.26)
ax2.text(0.07, -0.1170, r'constant $\Rightarrow h_{00}\sim 1/k^2\Rightarrow 1/r$', fontsize=9, color='0.35')

fig.tight_layout()
fig.savefig('fig_scaling.pdf', bbox_inches='tight')
print("fig_scaling.pdf written")

# ---- Figure 2: decoding-flow convergence ----
# reproduce the residual trajectory of the corrected flow h' = -F(Fh - J)
import itertools as it, math
from scipy.spatial import Delaunay
from collections import defaultdict
exec(open('decoding_gravity_diagnostics.py').read().split('# --------------------------------------------------------------- Sec 4')[0]
     .replace('# ----------------------------------------------------------------','# x'))
# Rebuild Q at k for the flow (reuse machinery already exec'd above)
M = Q(np.array([0., 0.12, 0., 0.]))
w, V = np.linalg.eigh(M)
phys = np.abs(w) > 1e-6*np.max(np.abs(w))
J = V[:, phys] @ (V[:, phys].T @ (np.eye(10)[0]))
h = np.zeros(10); dt = 0.5/np.max(w**2)
res=[]
for n in range(8000000):
    if n % 20000 == 0:
        res.append(np.linalg.norm(M@h - J)/np.linalg.norm(J))
    h = h - dt*(M@(M@h - J))
res=np.array(res); steps=np.arange(len(res))*20000

fig2, ax = plt.subplots(figsize=(5.2, 3.4))
ax.semilogy(steps, res, '-', color='#1f4e79', lw=1.6)
ax.set_xlabel('decoding-flow iteration')
ax.set_ylabel(r'residual $\|F h - J\|\,/\,\|J\|$')
ax.set_title(r'decoder converges to $F h = J$', fontsize=10.5)
ax.grid(True, which='both', ls=':', lw=0.5, alpha=0.5)
fig2.tight_layout()
fig2.savefig('fig_flow.pdf', bbox_inches='tight')
print(f"fig_flow.pdf written; final residual {res[-1]:.2e}")
