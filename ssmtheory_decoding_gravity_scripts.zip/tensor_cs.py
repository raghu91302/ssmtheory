"""
Path 1: tensor-aware C_s. The mass paper selects sectors by defect character:
 - square faces (F_sq) = EM/dilational sector
 - triangular faces (F_tri) = color/shear sector
So C_s should weight faces by how the defect's strain projects onto them.
Instead of isotropic C_s = V + all faces, use a strain-aware count:
  C_s^eff = V + (triangular faces that carry shear) + (square faces that carry dilation)
Operationally: a face "counts" if the defect strain has nonzero projection onto that
face's curvature loop. This makes C_s tensor-sensitive WITHOUT per-defect hand-tuning:
a face counts iff the strain actually triggers its check.

C_x^eff = E_s * C_s^eff, where E_s = strained edges, C_s^eff = stabilizers the strain
actually triggers (nonzero syndrome on that check). This is the HONEST fault-tolerant
cost: only checks that fire. Test C_x^eff vs strain energy.
"""
import numpy as np, itertools as it
a=1.0; L=a/np.sqrt(2); R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d); d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh
d1p=np.linalg.pinv(d1)
# all triangles (curvature checks)
tris=[]
for i in range(N):
    for j in range(i+1,N):
        if tuple(sorted((i,j))) not in eidx: continue
        for k in range(j+1,N):
            if tuple(sorted((i,k))) in eidx and tuple(sorted((j,k))) in eidx: tris.append((i,j,k))
C2=np.zeros((len(tris),E))
for t,(i,j,k) in enumerate(tris):
    for (p,q),s in [((i,j),1),((j,k),1),((i,k),-1)]:
        C2[t,eidx[tuple(sorted((p,q)))]]+= s
# vertex checks (X-type): incidence rows d1
center=np.array([R/2.,R/2.,R/2.])
def near(pt,m): return sorted(range(N),key=lambda i:np.linalg.norm(P[i]-pt))[:m]
def edges_among(cl): return [eidx[tuple(sorted((i,j)))] for i,j in it.combinations(cl,2) if tuple(sorted((i,j))) in eidx]

def measures(cl,cle,vals):
    e=np.zeros(E)
    for te,v in zip(cle,vals): e[te]=v
    u,*_=np.linalg.lstsq(B,e,rcond=None); J=e-B@u; Jc=J-d1p@(d1@J)
    Es=len(cle)
    # C_s^eff = number of CHECKS THAT FIRE on the defect strain e:
    #   vertex checks that fire: nonzero (d1 e) at that vertex
    #   triangle checks that fire: nonzero (C2 e) on that triangle
    vfire=np.sum(np.abs(d1@e)>1e-9)
    tfire=np.sum(np.abs(C2@e)>1e-9)
    Cs_eff=vfire+tfire
    Cx_eff=Es*Cs_eff
    # strain energy (curvature)
    curv=np.linalg.norm(C2@Jc)**2
    euc=np.linalg.norm(Jc)**2
    return Cx_eff, Es, Cs_eff, euc, curv

defs=[]
void=center+np.array([.25,.25,.25]); cl=near(void,4); defs.append(("tetra-void",cl,edges_among(cl),[1]*len(edges_among(cl))))
octv=center+np.array([.5,0,0]); cl=near(octv,6); defs.append(("oct-void",cl,edges_among(cl),[1]*len(edges_among(cl))))
v=near(center,1)[0]; cle=[k for k,(i,j) in enumerate(edges) if i==v or j==v]; cl=list(set([i for k in cle for i in edges[k]])); defs.append(("vacancy",cl,cle,[1]*len(cle)))
cl=near(center+np.array([.25,.25,.25]),4); cle=edges_among(cl); defs.append(("shear",cl,cle,[(-1)**i for i in range(len(cle))]))
cl=near(center,8); cle=edges_among(cl); defs.append(("dilate-8",cl,cle,[1]*len(cle)))
cle=[0,E//2]; cl=list(set(list(edges[0])+list(edges[E//2]))); defs.append(("2-bond-disj",cl,cle,[1,1]))
cl=near(center,5); cle=edges_among(cl)[:4]; defs.append(("4-edge",cl,cle,[1]*len(cle)))

print(f"{'defect':>13} | {'Es':>3} | {'Cs_eff':>6} | {'Cx_eff':>7} | {'curv-E':>7} | {'Cx_eff/curv':>11}")
rows=[]
for name,cl,cle,vals in defs:
    Cxe,Es,Cse,euc,curv=measures(cl,cle,vals)
    r=Cxe/curv if curv>1e-9 else float('nan')
    print(f"{name:>13} | {Es:>3} | {Cse:>6} | {Cxe:>7} | {curv:>7.2f} | {r:>11.2f}")
    rows.append((Cxe,euc,curv))
rows=np.array(rows,float); m=rows[:,2]>1e-9
Cxe,euc,curv=rows[m,0],rows[m,1],rows[m,2]
print()
print(f"C_x^eff vs curvature energy: corr={np.corrcoef(Cxe,curv)[0,1]:.3f}, ratio spread x{(Cxe/curv).max()/(Cxe/curv).min():.2f}")
print(f"C_x^eff vs Euclidean ||Jc||^2: corr={np.corrcoef(Cxe,euc)[0,1]:.3f}, ratio spread x{(Cxe/euc).max()/(Cxe/euc).min():.2f}")
print()
print("Compare to isotropic C_x earlier (ratio x4.1). If x dropped substantially, the")
print("checks-that-fire cost is the clean quantity.")
