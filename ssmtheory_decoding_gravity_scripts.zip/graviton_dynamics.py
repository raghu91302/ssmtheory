"""
Does the 4D D4 graviton operator, with one direction chosen as time and Wick-rotated,
give an exactly Lorentz-invariant wave operator, or a space-time anisotropy?

Plan:
1. Build the D4 root system (24 roots = the 24-cell vertices), the nearest-neighbor
   bond directions of the 4D D4 lattice.
2. Form the rank-4 structure tensor T_{mu nu rho sigma} = sum over bonds n_mu n_nu n_rho n_sigma.
   The paper's spatial result is T = 4S (rank-4 isotropy) in the SPATIAL (3D) restriction.
   Check the FULL 4D isotropy first.
3. The linearized graviton kinetic operator in momentum space is built from T contracted
   with k's. Pick a time direction (say mu=0). Wick-rotate k_0 -> i omega.
4. Check whether the resulting dispersion is omega^2 = |k_spatial|^2 (exact Lorentz /
   light-cone) or omega^2 = c_t^2-weighted with c_t != 1 (anisotropy), and whether the
   TT graviton sector is isotropic between time and space.
"""
import numpy as np, itertools as it

# D4 roots: all permutations of (+-1,+-1,0,0). That's C(4,2)*4 = 24 roots.
roots=[]
for i,j in it.combinations(range(4),2):
    for si in (1,-1):
        for sj in (1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; roots.append(np.array(v,float))
roots=np.array(roots)
print(f"D4 roots (24-cell): {len(roots)} (expect 24)")

# rank-2 structure tensor S_{mu nu} = sum n_mu n_nu
S=np.einsum('ai,aj->ij',roots,roots)
print("rank-2 tensor S (should be isotropic ~ c*I):")
print(np.round(S,3))
print(f"  isotropic? {np.allclose(S, S[0,0]*np.eye(4))}  (S00={S[0,0]})")

# rank-4 structure tensor T
T=np.einsum('ai,aj,ak,al->ijkl',roots,roots,roots,roots)
# isotropic rank-4 tensor built from S: I4 = S_ij S_kl + S_ik S_jl + S_il S_jk (up to norm)
delta=np.eye(4)
I4=(np.einsum('ij,kl->ijkl',delta,delta)+np.einsum('ik,jl->ijkl',delta,delta)+np.einsum('il,jk->ijkl',delta,delta))
# find best scalar a: T ?= a * I4
a=np.sum(T*I4)/np.sum(I4*I4)
resid=T-a*I4
print(f"\nrank-4: T = a*I4 with a={a:.4f}; ||T - a*I4|| / ||T|| = {np.linalg.norm(resid)/np.linalg.norm(T):.3e}")
iso4 = np.linalg.norm(resid)/np.linalg.norm(T) < 1e-10
print(f"  FULL 4D rank-4 isotropy (T proportional to I4)? {iso4}")
print(f"  (if True: the graviton operator is SO(4)-isotropic in all 4 dims -> after Wick")
print(f"   rotation gives exactly Lorentz-invariant wave operator.)")
print()

# Now the physical test: build the scalar dispersion on the lattice and Wick-rotate.
# omega(k)^2 for a field = sum over bonds [1 - cos(k . n)] ~ (1/2) k_mu k_nu S_mu nu at small k
# = (1/2) S00 |k|^2  (isotropic in 4D Euclidean). Pick direction 0 as time: split k=(k0,kvec)
# Euclidean: E4(k) = (1/2) S00 (k0^2 + |kvec|^2).  Wick rotate k0 -> i omega:
#   (1/2)S00(-omega^2 + |kvec|^2)=0  =>  omega^2 = |kvec|^2. Light cone, c=1.
print("Dispersion test (scalar, small k):")
print(f"  Euclidean 4D operator ~ (1/2)S00 (k0^2+|kvec|^2), S00={S[0,0]}")
print(f"  Wick rotate k0->i*omega: omega^2 = |kvec|^2  (c=1 exactly, by 4D isotropy)")
print()

# The real subtlety: the GRAVITON (spin-2, TT) not the scalar. Check the rank-4 operator's
# time-space isotropy explicitly by comparing a purely-spatial contraction to a mixed one.
# Build Q_{ij,kl}(k) = T contracted with k in the FP combination, then compare the
# coefficient structure for k along a spatial axis vs along the time axis.
def Q_coeff(kdir):
    k=np.array(kdir,float); k/=np.linalg.norm(k)
    # simplest kinetic scalar from T: c(k) = T_{mu nu rho sig} k_mu k_nu k_rho k_sig
    return np.einsum('ijkl,i,j,k,l->',T,k,k,k,k)
dirs={'time (1,0,0,0)':[1,0,0,0],'space (0,1,0,0)':[0,1,0,0],
      'diagonal (1,1,0,0)':[1,1,0,0],'diag4 (1,1,1,1)':[1,1,1,1]}
print("Directional kinetic coefficient c(k)=T k k k k (normalized k):")
vals={}
for name,d in dirs.items():
    c=Q_coeff(d); vals[name]=c
    print(f"  {name:>20}: {c:.4f}")
print()
# if time and space give the SAME coefficient and diagonal matches the isotropic prediction,
# the operator is 4D-isotropic and Wick rotation gives exact Lorentz invariance.
tvals=list(vals.values())
print(f"time vs space coefficient equal? {abs(vals['time (1,0,0,0)']-vals['space (0,1,0,0)'])<1e-10}")
# isotropic rank-4 predicts c(k)=a*(3) for unit k (since I4 contracted 4x with unit k = 3)
print(f"isotropic prediction a*3 = {a*3:.4f}; actual along axis = {vals['time (1,0,0,0)']:.4f}")
print()
if iso4:
    print("=> RESULT: full 4D SO(4) isotropy holds. Choosing any direction as time and")
    print("   Wick-rotating gives an EXACTLY Lorentz-invariant graviton wave operator:")
    print("   no space-time anisotropy, gravitons on the light cone, no preferred frame")
    print("   at the level of the quadratic (linearized) operator.")
else:
    print("=> RESULT: 4D isotropy FAILS -> the Wick-rotated operator carries a space-time")
    print("   anisotropy; gravitons would have lattice-scale Lorentz violation.")
