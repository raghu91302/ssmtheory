"""
Clean version of the full chain, done carefully:
  defect -> incompatible syndrome J_cons (conserved) -> FP h = J_cons -> 1/r field.

Key fix vs the proxy: use the ACTUAL strain-to-metric structure. The edge strain e_ij
relates to the metric perturbation h by e_ij = h_{mu nu} d^mu d^nu / (2|d|) on each bond.
The incompatible (syndrome) part of e is the curvature source. We solve for the metric
field h_{mu nu}(x) whose induced strain best matches -J_cons (the decoder drives strain to
cancel the defect syndrome), then read the Newtonian potential h_00(r) and test 1/r.

To get clean falloff we use a larger patch and measure along a lattice axis away from the
defect, comparing h_00(r) to A/r.
"""
import numpy as np, itertools as it

a=1.0; L=a/np.sqrt(2)
R=4
nodes=set()
for cx,cy,cz in it.product(range(R),repeat=3):
    base=np.array([cx,cy,cz])
    for p in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
              (.5,.5,0),(.5,0,.5),(0,.5,.5),(.5,.5,1),(.5,1,.5),(1,.5,.5)]:
        nodes.add(tuple(np.round(base+np.array(p),3)))
nodes=sorted(nodes); P=np.array(nodes); N=len(nodes)
edges=[]
for i in range(N):
    for j in range(i+1,N):
        if abs(np.linalg.norm(P[i]-P[j])-L)<1e-6: edges.append((i,j))
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
print(f"FCC patch R={R}: N={N}, E={E}")

# incidence and compatibility operators
d1=np.zeros((N,E)); B=np.zeros((E,3*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; dh=d/np.linalg.norm(d)
    d1[i,k]+=1; d1[j,k]-=1
    B[k,3*i:3*i+3]=dh; B[k,3*j:3*j+3]=-dh

# defect: trapped node at central void, strains its 6 pocket edges
center=np.array([R/2.,R/2.,R/2.]); void=center+np.array([.25,.25,.25])
tet=sorted(range(N),key=lambda i:np.linalg.norm(P[i]-void))[:4]
c0=tet[0]
te=[eidx[tuple(sorted((i,j)))] for i,j in it.combinations(tet,2) if tuple(sorted((i,j))) in eidx]
e_def=np.zeros(E)
for t in te: e_def[t]=1.0
# incompatible + conserved
u,*_=np.linalg.lstsq(B,e_def,rcond=None); J=e_def-B@u
J_cons=J-np.linalg.pinv(d1)@(d1@J)
print(f"||J||={np.linalg.norm(J):.3f}  ||J_cons||={np.linalg.norm(J_cons):.3f}  div={np.linalg.norm(d1@J_cons):.1e}")

# --- metric field solve ---
# Represent h_{mu nu}(x) as a symmetric 3x3 field per NODE (6 comps x N). Induced edge
# strain: for edge (i,j) with direction d, midpoint strain = h(mid).d.d / |d|... use nodal
# average. Build operator G: (6N) -> E mapping metric field to edge strain.
sym=[(0,0),(1,1),(2,2),(0,1),(0,2),(1,2)]
def symmat(v):
    M=np.zeros((3,3))
    for c,(p,q) in enumerate(sym):
        M[p,q]=v[c]; M[q,p]=v[c]
    return M
G=np.zeros((E,6*N))
for k,(i,j) in enumerate(edges):
    d=P[i]-P[j]; 
    for c,(p,q) in enumerate(sym):
        val=d[p]*d[q]/np.linalg.norm(d)*(2 if p!=q else 1)*0.5
        G[k,6*i+c]+=0.5*val; G[k,6*j+c]+=0.5*val
# decoder drives induced strain to cancel J_cons: solve G h = -J_cons (least squares, gauge-fixed)
h,*_=np.linalg.lstsq(G,-J_cons,rcond=None)
h=h.reshape(N,6)
# Newtonian potential ~ trace / h_00-like: use trace of h at each node
trace=h[:,0]+h[:,1]+h[:,2]
# measure vs distance from defect node c0
rs=np.array([np.linalg.norm(P[i]-P[c0]) for i in range(N)])
# use nodes not on the outer boundary
onb=np.array([ (P[i]<=0.01).any() or (P[i]>=R-0.01).any() for i in range(N)])
mask=(rs>0.6)&(rs<2.2)&(~onb)
phi=trace
inv_r=1/rs[mask]
A=np.polyfit(inv_r,phi[mask],1)
pred=A[0]*inv_r+A[1]; ss=1-np.var(phi[mask]-pred)/np.var(phi[mask])
print()
print("Newtonian test via induced metric trace (interior nodes, boundary excluded):")
print(f"  phi ~ A/r: A={A[0]:.4f}, R^2={ss:.4f}  (npts={mask.sum()})")
# also test radial monotonic falloff by binning
print("  phi vs r (binned):")
for lo,hi in [(0.6,1.0),(1.0,1.4),(1.4,1.8),(1.8,2.2)]:
    m=(rs>lo)&(rs<=hi)&(~onb)
    if m.sum()>0: print(f"    r in ({lo},{hi}]: <phi>={phi[m].mean():+.4f}  <1/r>={np.mean(1/rs[m]):.3f}  n={m.sum()}")
print()
print("full chain:")
print(f"  1. defect -> ||J_cons||={np.linalg.norm(J_cons):.3f} conserved incompatible syndrome")
print(f"  2. decoder cancels it: FP/G h = -J_cons")
print(f"  3. induced potential ~ 1/r : R^2={ss:.3f}")
