# Linearized Gravity on the D4 Lattice as a Self-Decoding Code — files

Paper: `decoding_gravity_B1.tex` / `.pdf`

Python scripts, grouped by the paper result they support. All use numpy/scipy
(some sympy). Coupling scripts run on a finite FCC patch and are the numerical
basis for Section "The code cost and the gravitational source".

## Core paper verification (Sections on the Regge operator and the exact identity)

- `partI_verify.py`
  The exact Regge -> Fierz-Pauli identity. Verifies rank-four isotropy T = 4S on
  the D4 kissing set, the diffeomorphism kernel, the (-1:+3:0) TT/trace/gauge
  sector coefficients, and that the linearized D4 Regge kinetic operator equals
  the linearized Einstein operator both numerically and as an exact symbolic
  identity (1100 rational Hessian entries; C + q_FP expands to 0).

- `decoding_gravity_diagnostics.py`
  Double-precision diagnostics reproducing Tables 1/2/4: the D4 star counts, the
  flat-background zero deficit, the k^2 scaling of Q(k), the diffeomorphism
  kernel, the Newtonian 1/k^2 (1/r) source solve, and the decoding flow. NOTE:
  the Regge operator Q is indefinite (negative TT eigenvalue); the decoder
  descends on the syndrome weight |Q| on the physical sector, not the indefinite
  action. Fixed point |Q| h = J.

- `verify_d4.py`
  Standalone D4 lattice / structure-tensor checks.

## Propagating graviton (Section: 4D isotropy and emergent Lorentz invariance)

- `graviton_dynamics.py`
  Builds the 4D D4 root system (24 roots) and its rank-4 structure tensor. Shows
  T = 4*I4 EXACTLY (full 4D SO(4) isotropy, machine zero residual), extending the
  paper's spatial T=4S. Directional kinetic coefficient identical along time,
  space, and diagonal axes. => choosing any direction as time and Wick-rotating
  gives an isotropic (Lorentz-invariant) operator.

- `tt_lorentzian2.py`
  The decisive check. Evaluates the Fierz-Pauli operator on the TRUE transverse-
  traceless graviton polarizations (wave along z, h_xx=-h_yy and h_xy) in
  Lorentzian signature eta=diag(-1,1,1,1). Result: FP h_TT = k^2 h_TT with
  TT/k^2 = 1 EXACTLY for spacelike, timelike, and null k; on-shell pole at k^2=0
  (light cone); gauge sector in the kernel in all signatures; trace ratio
  preserved. => the (-1:+3:0) sector structure survives Wick rotation and the
  linearized graviton is exactly Lorentz-invariant, massless, spin-2. Free
  (quadratic) and classical: interacting/quantum left open.
  (tt_lorentzian.py is an earlier version with a flawed TT construction for
  mixed-direction k; superseded by tt_lorentzian2.py.)

## Figures
- `make_figs.py`
  Generates the two paper figures: `fig_scaling.pdf` (Q(k) ~ k^2 scaling and the
  Newtonian 1/r solve) and `fig_flow.pdf` (decoding-flow residual convergence).
  Requires matplotlib in addition to numpy/scipy. The generated PDFs
  `fig_scaling.pdf` and `fig_flow.pdf` are included so the paper compiles as-is.

## Coupling: code cost vs gravitational source (new section)

Chain: defect -> verification cost C_x (mass) -> incompatible strain J_inc ->
induced gravity FP h = J_inc. The QEC enters indirectly, through the source.

- `defect_syndrome.py`
  Inserts a trapped-node defect in an FCC patch, decomposes its edge strain into
  compatible (gauge) and incompatible parts, extracts J and its conserved
  component. Shows the defect sources a nonzero incompatible syndrome.

- `defect_gravity.py`, `chain_clean.py`
  Project J onto the conserved subspace (div J = 0) and attempt the field solve.
  chain_clean.py is the fuller metric-field attempt; note the clean 1/r from the
  defect's own J_inc through the scalar/proxy operator was NOT achieved on this
  small patch (the verified 1/r for a generic static source is in
  decoding_gravity_diagnostics.py / partI_verify.py).

- `kappa_tetravoid.py`  ** MAIN RESULT **
  kappa as a species invariant. (1) Scaling one tetra-void's strain amplitude
  shows ||J_inc||^2 ~ amp^2, so kappa = C_x/||J_inc||^2 is well defined at unit
  amplitude. (2) Across all 27 crystallographically equivalent tetra-void sites,
  C_x = 48 identically AND the independently-computed ||J_inc||^2 comes out equal,
  so kappa = 31.4 +/- 0.2 (0.7% spread, boundary-limited) is the SAME at every
  site. The content is this universality (not the per-defect ratio, which just
  defines kappa): the metric energy ||J_inc||^2 is computed independently per
  site yet is a species invariant.

- `kappa_converge.py`
  kappa for the central tetra-void vs patch size: 31.9, 31.2, 31.0, 30.9 ->
  converges monotonically to a fixed bulk value ~31. Confirms the 0.7% spread is
  finite-size boundary effect, not intrinsic.

- `tautology_check.py`  ** answers "is it tautological?" **
  On the SAME footprint, vary the strain PATTERN: the incompatible fraction
  ||J_inc||^2/||e||^2 varies ~2x (uniform 0.26, shear 0.43, random 0.55). So
  ||J_inc||^2 is a genuine metric quantity (uses bond-direction geometry via B),
  NOT a rescaling of the combinatorial count C_x = E_s*C_s (uses no geometry).
  The two have independent inputs. Hence the per-species ratio kappa is a
  definition, but its UNIVERSALITY across sites and VARIATION between species
  are non-trivial geometric facts -- that is where the content is.

- `join.py`, `join_tighten.py`
  Earlier multi-species runs. NOTE: these MIX defect species (tetra void, oct
  void, shear, dilation, ...). The r~0.97 "correlation" and 4x ratio spread they
  report is an ARTIFACT of lumping different species, each with its own kappa.
  Kept for the record; superseded by kappa_tetravoid.py (correct per-species).

- `coupling_stats.py`
  Diagnostic showing why the mixed-species Pearson r~0.97 was misleading
  (leverage-inflated; Spearman 0.99; a spurious 0.64 log-log exponent from
  mixing species). Motivates the per-species treatment.

- `join_refine.py`, `clean_law.py`, `tensor_cs.py`
  Attempts to find a single cross-species law by reweighting C_s or the strain
  energy. All fail, because there is no single cross-species law: each species
  has its own kappa. Kept as the record of that (correct) negative result.

- `defect_syndrome.py`, `defect_gravity.py`, `chain_clean.py`
  The J_cons construction and the field-solve attempts (see above).

## Reproducing the coupling number

    python3 join.py         # main C_x vs ||J_cons||^2 correlation (~0.98)
    python3 join_tighten.py # robustness across defect geometries (~0.97, ratio spread)

## Status summary

- Exact Regge = Fierz-Pauli identity: proven (partI_verify.py).
- QEC dictionary: an exact restatement; adds vocabulary, not predictive content
  to the field equation (stated in the paper).
- Decoder fixed point = linearized Einstein: the normal equations of the
  syndrome-weight minimization; characterizes the solution, not graviton dynamics.
- Code-cost / source coupling: kappa = C_x / ||J_inc||^2 is a SPECIES INVARIANT.
  The per-defect ratio is a definition, but (a) ||J_inc||^2 is a genuine metric
  quantity independent of the combinatorial C_x (tautology_check.py), (b) kappa
  is identical across all sites of a species (tetra-void ~ 31, 27 sites, 0.7%,
  converging with patch size), and (c) kappa differs between species (oct-void
  differs). Ordinary matter is one species (tetra-void), so its verification cost
  fixes its gravitational source energy through the single invariant
  kappa_tri ~ 31. Open: closed-form kappa_tri from void geometry; interpretation
  of the species dependence; clean Newtonian tail for the defect's own J_inc.
