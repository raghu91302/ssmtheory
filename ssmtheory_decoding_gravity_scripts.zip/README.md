# Linearized Gravity on the D4 Lattice as a Self-Decoding Code — files

Paper: `decoding_gravity_B1.tex` / `.pdf`

Python scripts, grouped by the paper result they support. All use numpy/scipy
(some sympy). Graviton scripts verify the 4D isotropy and Lorentzian operator.
basis for Section "The code cost and the gravitational source".

## Core paper verification (Sections on the Regge operator and the exact identity)

- `partI_verify.py`
  The exact Regge -> Fierz-Pauli identity. Verifies rank-four isotropy T = 4S on
  the D4 kissing set, the diffeomorphism kernel, the (-1:+3:0) TT/trace/gauge
  sector coefficients, and that the linearized D4 Regge kinetic operator equals
  the linearized Einstein operator both numerically and as an exact symbolic
  identity (1100 rational Hessian entries; C + q_FP expands to 0).

- `decoding_gravity_diagnostics.py`
  Double-precision diagnostics reproducing Tables 1/2/4: the D4 star counts, the
  flat-background zero deficit, the k^2 scaling of Q(k), the diffeomorphism
  kernel, the Newtonian 1/k^2 (1/r) source solve, and the decoding flow. NOTE:
  the Regge operator Q is indefinite (negative TT eigenvalue); the decoder
  descends on the syndrome weight |Q| on the physical sector, not the indefinite
  action. Fixed point |Q| h = J.

## Propagating graviton (Section: 4D isotropy and emergent Lorentz invariance)

- `graviton_dynamics.py`
  Builds the 4D D4 root system (24 roots) and its rank-4 structure tensor. Shows
  T = 4*I4 EXACTLY (full 4D SO(4) isotropy, machine zero residual), extending the
  paper's spatial T=4S. Directional kinetic coefficient identical along time,
  space, and diagonal axes. => choosing any direction as time and Wick-rotating
  gives an isotropic (Lorentz-invariant) operator.

- `isotropy_check.py`  ** is it REALLY isotropic? **
  Decisive test that rank-4 isotropy is full SO(4), not merely cubic/lattice-
  point-group invariance. (1) The diagonal-to-mixed ratio T_1111/T_1122 = 3.000
  exactly -- the value that kills the hypercubic anisotropic part. (2) Rotating
  the root set by GENERIC SO(4) rotations leaves T4 invariant to 1e-16 (a merely
  cubic tensor would change). (3) Contrast: the rank-6 tensor CHANGES by ~59%
  under the same rotations (24-cell is not a 6-design) -- so the test correctly
  detects anisotropy where it exists. Conclusion: rank-4 is genuinely isotropic
  (free graviton exactly Lorentz-invariant); rank-6 is not (interacting theory
  lattice-corrected).

- `tt_lorentzian2.py`
  The decisive check. Evaluates the Fierz-Pauli operator on the TRUE transverse-
  traceless graviton polarizations (wave along z, h_xx=-h_yy and h_xy) in
  Lorentzian signature eta=diag(-1,1,1,1). Result: FP h_TT = k^2 h_TT with
  TT/k^2 = 1 EXACTLY for spacelike, timelike, and null k; on-shell pole at k^2=0
  (light cone); gauge sector in the kernel in all signatures; trace ratio
  preserved. => the (-1:+3:0) sector structure survives Wick rotation and the
  linearized graviton is exactly Lorentz-invariant, massless, spin-2. Free
  (quadratic) and classical: interacting/quantum left open.
  (tt_lorentzian.py is an earlier version with a flawed TT construction for
  mixed-direction k; superseded by tt_lorentzian2.py.)

## Figures
- `make_figs.py`
  Generates the two paper figures: `fig_scaling.pdf` (Q(k) ~ k^2 scaling and the
  Newtonian 1/r solve) and `fig_flow.pdf` (decoding-flow residual convergence).
  Requires matplotlib in addition to numpy/scipy. The generated PDFs
  `fig_scaling.pdf` and `fig_flow.pdf` are included so the paper compiles as-is.

## Status summary

- Exact Regge = Fierz-Pauli identity: proven (partI_verify.py).
- QEC dictionary: an exact restatement; adds vocabulary, not predictive content
  to the field equation (stated in the paper).
- Decoder fixed point = linearized Einstein: the normal equations of the
  syndrome-weight minimization; characterizes the solution, not graviton dynamics.