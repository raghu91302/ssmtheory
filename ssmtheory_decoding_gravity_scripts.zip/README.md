# Linearized Gravity on the D4 Lattice as a Self-Decoding Code: scripts

Paper: `decoding_gravity_B2.tex` / `.pdf`

All scripts use numpy/scipy/sympy. Run any of them directly; each prints the
manuscript quantities it is responsible for.

## Core verification

- **`d4_canonical_star.py`**: Section 2, in full.
  Builds the canonical translation-invariant triangulation of D4 (the three
  nontrivial cosets of D4 in D4*, each hole a 16-cell, each 16-cell split into 8
  simplices by a lexicographic rule on antipodal-pair directions). Verifies
  Table 1 (30 edges at the origin = 24 bonds + 6 diagonals, 150 hinges, 120
  simplices, all volumes 1/12, all fans complete), the vanishing background
  deficit (every fan sums to exactly 2*pi), Table 2 (spectrum -1/2 x5 TT,
  0 x4 gauge, +1 x1 trace, direction-independent to 2e-15), the Newtonian value
  h_00 k^2 = -1.0000000000, the singular values {1, 1/2^5, 0^4} and condition
  number 2, the order-k^2 Fierz-Pauli identity on this subdivision (C^(2)/q_FP = -1 to 3e-15),
  and the decoding-flow convergence of Section 4.

- **`partI_verify.py`**: the exact-arithmetic core of Section 2.4.
  Rank-four isotropy T = 4S on the D4 kissing set; the rational Hessian (1100
  entries, 0 irrational); the symbolic identity C^(2) + q_FP == 0 in general k and
  polarization, where C^(2) is the coefficient at order k^2; and the exact characteristic polynomial in an orthonormal basis
  of Sym(R^4),

      det(C(k) - lambda) = lambda^4 (lambda + 1/2)^5 (lambda - 1).

## Propagating graviton (Section 5)

- `graviton_dynamics.py`: the 4D D4 root system and its rank-4 structure
  tensor; T = 4*I4 exactly (residual zero, integer arithmetic).
- `isotropy_check.py`: that the rank-4 isotropy is full SO(4) and not only
  cubic: T_1111/T_1122 = 3 exactly; invariance under generic SO(4) rotations to
  1e-15; and the contrast at rank six, whose largest entry changes by ~33% under
  the same rotations (the 24-cell is not a spherical 6-design).
- `tt_lorentzian2.py`: the Fierz-Pauli operator on the true transverse-traceless
  polarizations in Lorentzian signature. The result is the eigenvalue relation
  F h_TT = k^2 h_TT with unit coefficient, verified for spacelike and timelike k.
  Note it is stated as an eigenvalue relation, not as a ratio: the quotient of the
  eigenvalue by k^2 is indeterminate on the light cone, where both vanish.

## Figures

- `make_figs.py`: regenerates `fig_isotropy.pdf` and `fig_flow.pdf`.

## Corrections relative to the previous archive

Recorded here so they are not rediscovered.

1. **The finite-difference operator Q(k) was truncated.** The old
   `decoding_gravity_diagnostics.py` summed only the hinges *containing the
   origin*, which is not a fundamental domain. That broke rank-four isotropy by
   ~34% (TT+ and TTx differed by a third at the same k in the body direction) and
   gave six non-degenerate negative eigenvalues where Fierz-Pauli requires five
   degenerate ones. It was not noise (identical for eps from 1e-2 to 1e-5) and not
   slivers (all star simplices have volume exactly 1/12); completing the hinge set
   reduced the anisotropy monotonically, 33.8% -> 12.0% -> 2.9% at 125 -> 307 ->
   699 hinges. The operator is now assembled from the Regge Hessian by exact
   contraction. Superseded numbers: max|eig|/k^2 ~ 11 (Table 2) and
   h_00 k^2 ~ -0.111 with a 2.7% spread (Table 3).

2. **Eigenvalues must be taken in an orthonormal basis.** A basis whose
   off-diagonal elements carry norm sqrt(2) rather than 1 gives basis-dependent
   numbers and hides the TT degeneracy.

3. **The sector coefficients "(-1:+3:0)" were normalization-mixed.** They came
   from evaluating the form on eps_TT = uu-vv (norm^2 = 2) and eps_trace = delta
   (norm^2 = 4). The multiplicity was also wrong: Euclidean 4D has FIVE TT
   polarizations, not four, and 4+1+4 does not reconstruct a 10-dimensional space.
   Replaced by the exact characteristic polynomial.

4. **`rcond=1e-6` did not discard the gauge modes** in the old operator, where
   they sat at ~1e-2 relative to the largest singular value. In the corrected
   operator they sit at ~1e-16 and the cutoff is genuine.

5. **The decoder flow.** The old figure showed 8e6 iterations reaching 1e-6; that
   was measuring the truncated operator's condition number (~7e2). The corrected
   operator has condition number exactly 2 and the flow reaches 1.5e-16 in ~1e3
   iterations. The flow solves F h = J; it does NOT solve |F| h = J, which would
   flip the sign on the TT sector. (An earlier version of this README asserted the
   latter; that was wrong, and both the manuscript and the code were always right.)

6. **The Delaunay triangulation is not reproducible.** `qhull_options='Qt'` on a
   409-point D4 chunk returns 393 zero-volume simplices, 40 of volume 1/6 among
   5488 of volume 1/12, and 96 distinct simplex shapes with multiplicities 1-20;
   it is not translation-invariant (125 hinges at the origin is not divisible by
   3). Replaced by the canonical construction. The exact Fierz-Pauli identity is
   verified on both, so it is subdivision-independent.

7. **Stale blocks removed from `partI_verify.py`**: the "induced Newton constant"
   calculation (hardcoded Nb=3, a1=1/6, Lam=pi, no derivation) and the
   "self-bound vacuum" block (A_=1.0, B_=3.0), neither of which has a counterpart
   in the manuscript. The docstring named a different paper; the diagnostics
   docstring referenced a nonexistent `linearized_gravity_verify.py`.
