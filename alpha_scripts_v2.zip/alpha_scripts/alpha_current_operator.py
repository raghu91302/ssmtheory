#!/usr/bin/env python3
"""Operator derivation of j = 1: the flux current of the phase term.
Rotor algebra: [B,m] = i, e^{±iB}|m> = |m±1>.
H_J = -J cos B.  Current I = dm/dt = (i/hbar)[H_J, m].
Claim: [H_J,m] = i J sin B, so I = -(J/hbar) sin B, and since [H_J,B]=0 the drift is exact:
   Delta m over one tick = -(J tau/hbar) sin B,   max over states = J tau / hbar.
(P2) 'a bond transmits one quantum per tick' = max transfer per tick is one flux quantum
   =>  J tau/hbar = 1  =>  J = hbar/tau = E_bond.
"""
import numpy as np
M=40; ms=np.arange(-M,M+1); d=len(ms)
up=np.diag(np.ones(d-1),-1)            # e^{iB}: |m> -> |m+1>
dn=up.T
cosB=(up+dn)/2; sinB=(up-dn)/(2j)
mop=np.diag(ms.astype(complex))
J=1.0; hbar=1.0
HJ=-J*cosB
com=HJ@mop-mop@HJ
print("check [H_J, m] = i J sin B :", np.allclose(com[2:-2,2:-2], (1j*J*sinB)[2:-2,2:-2]))
I=(1j/hbar)*com
print("check I = -(J/hbar) sin B  :", np.allclose(I[2:-2,2:-2], (-(J/hbar)*sinB)[2:-2,2:-2]))
print("check [H_J, B] = 0 (B conserved): cos B and sin B commute with H_J:",
      np.allclose((HJ@cosB-cosB@HJ),0), np.allclose((HJ@sinB-sinB@HJ)[2:-2,2:-2],0))
# exact drift: evolve a near-phase state and measure <m>(t)
def phase_state(B0,width=6.0):
    psi=np.exp(-1j*B0*ms)*np.exp(-(ms/width)**2/2); return psi/np.linalg.norm(psi)
from scipy.linalg import expm
for B0 in (np.pi/2, np.pi/4, 0.0):
    psi=phase_state(B0)
    for tau in (0.5,1.0,2.0):
        U=expm(-1j*HJ*tau/hbar); pt=U@psi
        dm=(pt.conj()@mop@pt).real-(psi.conj()@mop@psi).real
        print(f"  B0={B0:.3f}  tau={tau}:  <Delta m> = {dm:+.4f}   predicted -(J tau/hbar) sin B0 = {-(J*tau/hbar)*np.sin(B0):+.4f}")
print("\nmax |Delta m| per tick over all states = J tau / hbar")
print("(P2): one quantum per bond per tick  ->  J tau/hbar = 1  ->  j = 1")
print("alternatives: 'span 2J = E_bond' -> max transfer 1/2 quantum per tick;")
print("              'one channel J/2'   -> max transfer 2 quanta per tick.")
