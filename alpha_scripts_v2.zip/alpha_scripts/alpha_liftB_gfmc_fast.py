#!/usr/bin/env python3
"""alpha_liftB_gfmc_fast.py -- numba-compiled, checkpointed version of alpha_liftB_gfmc.py.
Same algorithm (projector MC, adaptive E_T, reconfiguration every `reconf` steps, forward walking).
Runs in chunks: --chunk_steps per invocation, state saved to --ckpt, resumed on the next call.
"""
import numpy as np, itertools, time, argparse, os, pickle
from numba import njit

def build(L):
    sites=list(itertools.product(range(L),repeat=3)); sidx={s:i for i,s in enumerate(sites)}
    def sh(s,mu,d=1): t=list(s); t[mu]=(t[mu]+d)%L; return tuple(t)
    links=[(s,mu) for s in sites for mu in range(3)]; lidx={l:i for i,l in enumerate(links)}
    pl=[]
    for s in sites:
        for mu,nu in [(0,1),(0,2),(1,2)]:
            pl.append([lidx[(s,mu)],lidx[(sh(s,mu),nu)],lidx[(sh(s,nu),mu)],lidx[(s,nu)]])
    pl=np.array(pl,np.int64); sg=np.array([1,1,-1,-1],np.int64)
    pos=np.array([[s[i]+0.5*(i==mu) for i in range(3)] for (s,mu) in links],float)
    dirn=np.array([mu for (s,mu) in links],np.int64)
    return pl,sg,pos,dirn,len(links)

@njit(cache=True)
def step_walkers(Ew, pl, sg, step, Smax, dtau, ET, J, U, rnd_jump, rnd_choice, n_out, Eloc_out, w_out):
    W=Ew.shape[0]; NP=pl.shape[0]
    for wi in range(W):
        # count feasible flips and diagonal energy
        n=0
        for p in range(NP):
            okp=True; okm=True
            for a in range(4):
                v=Ew[wi,pl[p,a]]
                if abs(v+step*sg[a])>Smax: okp=False
                if abs(v-step*sg[a])>Smax: okm=False
            if okp: n+=1
            if okm: n+=1
        hd=0.0
        for l in range(Ew.shape[1]):
            e=Ew[wi,l]/step; hd+=e*e
        hd*=0.5*U
        Eloc=-J*n+hd
        w=1.0+dtau*(ET-Eloc)
        if w<1e-12: w=1e-12
        n_out[wi]=n; Eloc_out[wi]=Eloc; w_out[wi]=w
        # jump?
        if n>0 and rnd_jump[wi]<dtau*J*n/w:
            target=int(rnd_choice[wi]*n); c=0
            for p in range(NP):
                okp=True; okm=True
                for a in range(4):
                    v=Ew[wi,pl[p,a]]
                    if abs(v+step*sg[a])>Smax: okp=False
                    if abs(v-step*sg[a])>Smax: okm=False
                if okp:
                    if c==target:
                        for a in range(4): Ew[wi,pl[p,a]]+=step*sg[a]
                        break
                    c+=1
                if okm:
                    if c==target:
                        for a in range(4): Ew[wi,pl[p,a]]-=step*sg[a]
                        break
                    c+=1

def structure_factor(Ew,pos,dirn,L,ks,step):
    out=np.zeros((len(ks),Ew.shape[0])); N=L**3
    for a,kk in enumerate(ks):
        k=2*np.pi*np.array(kk)/L; ph=np.exp(1j*(pos@k))/np.sqrt(N)
        Ek=np.stack([(Ew[:,dirn==i]*ph[dirn==i]).sum(1) for i in range(3)],axis=1)
        K=2*np.sin(k/2); K2=K@K; Ek_L=(Ek@K)/K2; Et=Ek-np.outer(Ek_L,K)
        out[a]=(np.abs(Et)**2).sum(1)/step**2
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--L',type=int,default=6); ap.add_argument('--S',type=float,default=6)
    ap.add_argument('--UJ',type=float,default=0.0086); ap.add_argument('--walkers',type=int,default=800)
    ap.add_argument('--steps',type=int,default=300000); ap.add_argument('--chunk_steps',type=int,default=40000)
    ap.add_argument('--equil',type=int,default=None); ap.add_argument('--fw',type=int,default=70000)
    ap.add_argument('--meas_every',type=int,default=1000); ap.add_argument('--reconf',type=int,default=10)
    ap.add_argument('--dtau',type=float,default=None); ap.add_argument('--seed',type=int,default=1)
    ap.add_argument('--ckpt',type=str,default='gfmc_ckpt.pkl'); a=ap.parse_args()
    L=a.L; step=2 if abs(a.S-0.5)<1e-9 else 1; Smax=1 if abs(a.S-0.5)<1e-9 else int(a.S)
    pl,sg,pos,dirn,NL=build(L); NP=len(pl); W=a.walkers; J=1.0; U=a.UJ*2*J
    if a.dtau is None: a.dtau=0.3/NP
    equil=a.equil if a.equil is not None else a.steps//3
    ks=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1)]
    lam=[np.sqrt(np.sum(4*np.sin(np.pi*np.array(kk)/L)**2)) for kk in ks]
    if os.path.exists(a.ckpt):
        st=pickle.load(open(a.ckpt,'rb')); Ew=st['Ew']; wacc=st['wacc']; ET=st['ET']; Emix=st['Emix']; pending=st['pending']; results=st['results']; it0=st['it']; rng=st['rng']
        print(f"resumed at step {it0}, results so far {len(results)}",flush=True)
    else:
        rng=np.random.default_rng(a.seed); Ew=np.zeros((W,NL),np.int64); wacc=np.ones(W); ET=0.0; Emix=[]; pending=[]; results=[]; it0=0
        print(f"L={L} S={a.S} U/J_KS={a.UJ} walkers={W} steps={a.steps} dtau={a.dtau:.2e} fw={a.fw}; tree level S_T/lambda={1/np.sqrt(a.UJ):.3f} alpha^-1={4*np.pi/np.sqrt(a.UJ):.2f}",flush=True)
    n_out=np.zeros(W,np.int64); Eloc=np.zeros(W); w=np.zeros(W); t0=time.time()
    it_end=min(a.steps,it0+a.chunk_steps)
    for it in range(it0,it_end):
        rj=rng.random(W); rc=rng.random(W)
        step_walkers(Ew,pl,sg,step,Smax,a.dtau,ET,J,U,rj,rc,n_out,Eloc,w)
        Emix.append(float((wacc*Eloc).sum()/wacc.sum())); wacc*=w
        if it>=equil and it%a.meas_every==0:
            pending.append([it,structure_factor(Ew,pos,dirn,L,ks,step),np.arange(W),None])
        if (it+1)%a.reconf==0:
            idx=rng.choice(W,size=W,p=wacc/wacc.sum()); Ew=Ew[idx]; wacc=np.ones(W)
            for rec in pending: rec[2]=rec[2][idx]
        done=[rec for rec in pending if it-rec[0]>=a.fw]
        for rec in done: results.append(rec[1][:,rec[2]].mean(1)); pending.remove(rec)
        if it>=100: ET=0.98*ET+0.02*np.mean(Emix[-100:])
        elif it==99: ET=np.mean(Emix[-50:])
        if it%5000==0: print(f"step {it} E_mix={np.mean(Emix[-5000:]):.3f} E_T={ET:.2f} <n>={n_out.mean():.1f} pending={len(pending)} done={len(results)} ({time.time()-t0:.0f}s)",flush=True)
    pickle.dump({'Ew':Ew,'wacc':wacc,'ET':ET,'Emix':Emix,'pending':pending,'results':results,'it':it_end,'rng':rng},open(a.ckpt,'wb'))
    print(f"checkpoint at step {it_end}/{a.steps} ({time.time()-t0:.0f}s this chunk)",flush=True)
    Eest=np.mean(Emix[equil:]) if len(Emix)>equil else np.mean(Emix[-1000:])
    print(f"E0 (mixed) so far = {Eest:.4f}   E0/N_plaq = {Eest/NP:.4f}")
    R=np.array(results)
    if len(R):
        m=R.mean(0); e=R.std(0)/np.sqrt(len(R))
        for kk,l,mm,ee in zip(ks,lam,m,e): print(f"  k={kk}: S_T={mm:.3f}+-{ee:.3f}  S_T/lambda={mm/l:.3f}  alpha^-1={4*np.pi*mm/l:.1f}")
        ax=np.mean(m[:3])/np.mean(lam[:3]); print(f"  axis average: S_T/lambda = {ax:.3f} -> alpha^-1 = {4*np.pi*ax:.2f}  (samples={len(R)})")
if __name__=="__main__": main()
