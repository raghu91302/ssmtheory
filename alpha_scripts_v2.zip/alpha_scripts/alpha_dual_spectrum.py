#!/usr/bin/env python3
"""Harmonic spectrum of the dual clock model.
Phases theta on bonds (dual links), conjugate to s.  Gauss constraints (cube sums of s) generate gauge shifts
theta -> theta + C^T phi.  Ring exchange on tetrahedral 4-cycles: -J cos(A theta) with A the move matrix.
Harmonic: H = (U/2) s^2 + (J/2)(A theta)^2  ->  omega^2 = U J * eig(A^T A) on the gauge-invariant subspace.
Compare with Maxwell on the primal cubic lattice: omega^2 = U J * lambda_k^2, lambda_k^2 = sum 4 sin^2(k_i/2), 2 pol."""
import itertools, numpy as np
from scipy.linalg import orth
def build(N):
    NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
    E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
    m=lambda p: tuple(c%N for c in p); add=lambda p,d: m((p[0]+d[0],p[1]+d[1],p[2]+d[2])); par=lambda p: sum(p)%2
    nodes=[p for p in itertools.product(range(N),repeat=3) if par(p)==0]; voids=[p for p in itertools.product(range(N),repeat=3) if par(p)==1]
    edges=sorted({frozenset((n,add(n,d))) for n in nodes for d in NN},key=lambda e:sorted(e)); eidx={e:i for i,e in enumerate(edges)}; ne=len(edges)
    chk=[]
    for n in nodes: chk.append([eidx[frozenset((n,add(n,d)))] for d in NN])
    for o in voids:
        ring=[add(o,d) for d in E3]; chk.append([eidx[frozenset((a,b))] for a in ring for b in ring if a<b and frozenset((a,b)) in eidx])
    C=np.zeros((len(chk),ne))
    for c,es in enumerate(chk): C[c,es]=1
    tets=[tuple(2*c+1 for c in p) for p in itertools.product(range(N),repeat=3)]
    def verts(t):
        return [tuple(((t[i]+s[i])//2)%N for i in range(3)) for s in itertools.product([1,-1],repeat=3) if sum(((t[i]+s[i])//2)%N for i in range(3))%2==0]
    moves=[]
    for t in tets:
        v=verts(t); pairs=[(a,b) for a in range(4) for b in range(a+1,4)]
        for skew in [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]:
            cyc=[p for p in pairs if p not in skew]; adj={i:[] for i in range(4)}
            for a,b in cyc: adj[a].append(b); adj[b].append(a)
            order=[0]; prev=None
            while len(order)<4:
                nxt=[x for x in adj[order[-1]] if x!=prev and x not in order][0]; prev=order[-1]; order.append(nxt)
            es=[eidx[frozenset((v[order[i]],v[order[(i+1)%4]]))] for i in range(4)]
            vec=np.zeros(ne)
            for i,e in enumerate(es): vec[e]=1 if i%2==0 else -1
            moves.append(vec)
    return np.array(moves),C,ne
N=6
A,C,ne=build(N)
Qc=orth(C.T); P=np.eye(ne)-Qc@Qc.T          # projector onto gauge-invariant theta
K=P@(A.T@A)@P
w=np.linalg.eigvalsh(K); w=np.sort(w)
nz=w[w>1e-8]
print(f"N={N}: gauge-invariant dim={ne-Qc.shape[1]}, zero modes among them={np.sum((w<=1e-8))-Qc.shape[1]}, nonzero modes={len(nz)}")
vals,counts=np.unique(np.round(nz,6),return_counts=True)
print("lowest clock-model eigenvalues (value, multiplicity):")
for v,c in list(zip(vals,counts))[:10]: print(f"  {v:.4f}  x{c}")
# Maxwell reference on N^3 cubic lattice, 2 transverse pol per k (k != 0), k=2 pi m/N
ks=[]
for mm in itertools.product(range(N),repeat=3):
    if mm==(0,0,0): continue
    k=2*np.pi*np.array(mm)/N; ks.append(np.sum(4*np.sin(k/2)**2))
ks=np.array(sorted(ks)); vals2,c2=np.unique(np.round(ks,6),return_counts=True)
print("Maxwell lambda_k^2 (value, multiplicity x2 pol):")
for v,c in list(zip(vals2,c2))[:6]: print(f"  {v:.4f}  x{2*c}")
