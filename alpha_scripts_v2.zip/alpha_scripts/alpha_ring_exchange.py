#!/usr/bin/env python3
"""Stage 1: ring exchange on the <100> cubic link lattice.
Hard-core bosons (qubits) on links, oriented node->void.  Gauss law: each site has 3 of its 6
links occupied (div E = 0 with E = n - 1/2).  A charge is a site with occupation != 3, cost V
per unit |charge| (V = C_E * eps_b in SSM units).  Hopping t moves a boson between two links
sharing a site.  Compute the effective plaquette-flip amplitude K by 2nd-order degenerate PT
(Schrieffer-Wolff) on the cluster of all links touching the plaquette's four sites."""
import itertools, numpy as np

# plaquette in the xy-plane: sites s0=(0,0,0) s1=(1,0,0) s2=(1,1,0) s3=(0,1,0)
P = [(0,0,0),(1,0,0),(1,1,0),(0,1,0)]
E3 = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
add = lambda p,d: (p[0]+d[0],p[1]+d[1],p[2]+d[2])
links = set()
for s in P:
    for d in E3: links.add(frozenset((s, add(s,d))))
links = sorted(links, key=lambda l: sorted(l)); L = {l:i for i,l in enumerate(links)}
site_links = {s:[L[frozenset((s,add(s,d)))] for d in E3] for s in P}
plaq = [L[frozenset((P[i],P[(i+1)%4]))] for i in range(4)]
ext = [i for i in range(len(links)) if i not in plaq]
print(f"cluster: {len(links)} links, plaquette links {plaq}")

# reference configurations: A = links 0,2 of plaquette occupied, B = 1,3; external links chosen so
# that every plaquette site has exactly 3 occupied links (a generic flippable background).
def occupation_ok(n):
    return all(sum(n[l] for l in site_links[s])==3 for s in P)
# choose external occupation: each site has 2 plaquette links (one occupied in A), needs 2 more of its 4 external
rng = np.random.default_rng(0)
Ks = []
for trial in range(50):
    n = np.zeros(len(links), int)
    n[plaq[0]] = n[plaq[2]] = 1
    for s in P:
        exts = [l for l in site_links[s] if l in ext]
        for l in rng.choice(exts, 2, replace=False): n[l] = 1
    if not occupation_ok(n): continue
    nA = n.copy(); nB = n.copy(); nB[plaq] = 1 - nB[plaq]
    assert occupation_ok(nB)
    # hopping: boson from link a to link b (sharing site s), amplitude -t; charge cost
    def charge(m): return sum(abs(sum(m[l] for l in site_links[s])-3) for s in P)
    # enumerate 2-hop paths A -> X -> B
    hops = []
    for s in P:
        for a in site_links[s]:
            for b in site_links[s]:
                if a!=b: hops.append((a,b))
    K = 0.0; npaths = 0
    for (a,b) in hops:
        if nA[a]!=1 or nA[b]!=0: continue
        X = nA.copy(); X[a]=0; X[b]=1
        dE = charge(X)  # in units of V (external sites not in P are outside cluster; ignore)
        for (c,d) in hops:
            if X[c]!=1 or X[d]!=0: continue
            Y = X.copy(); Y[c]=0; Y[d]=1
            if np.array_equal(Y, nB):
                K += 1.0/dE; npaths += 1
    Ks.append((K, npaths))
Ks = sorted(set(Ks))
print("K in units of t^2/V, (value, #paths):", Ks)
