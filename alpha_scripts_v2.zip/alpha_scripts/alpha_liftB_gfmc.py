#!/usr/bin/env python3
"""alpha_liftB_gfmc.py  --  projector Monte Carlo for lift B (U(1) quantum link model on a cubic lattice).

Model:  links (s,mu) of an L^3 periodic cubic lattice carry integer flux E in {-S..S};
        Gauss law div E = 0 on every site;  H = -J sum_p (R_p + R_p^+)  (ring exchange, J = 1).
        Spin-1/2 is S=1/2 (E = +-1/2, stored as +-1 with flips of 2); spin-1 is S=1 (E in -1,0,1).
Method: power-method projection with G = 1 - dtau (H - E_T), exact (no time-step error) for dtau small
        enough; no sign problem since all off-diagonal elements of H are -J <= 0 (Perron-Frobenius ground state).
        Population control by stochastic reconfiguration; ancestry tracked for forward-walking (pure) estimators.
Output: ground energy (mixed estimator, exact for H), and the transverse electric structure factor
        S_T(k) = < |E_T(k)|^2 > (sum over the two transverse polarizations) at the smallest k.
        In the Coulomb phase (Kogut-Susskind effective theory, unit charge = unit flux):
            S_T(k) = lambda_k sqrt(J/U),  lambda_k^2 = sum_i 4 sin^2(k_i/2)   =>  alpha^-1 = 4 pi S_T(k)/lambda_k.
Usage:  python3 alpha_liftB_gfmc.py --L 6 --S 1 --walkers 400 --steps 60000 --fw 1500 --meas_every 300 --seed 1
        dtau defaults to 0.3/N_plaq (power-method stability with the adaptive energy offset); correlation times
        scale as 1/dtau: forward-walk for fw*dtau >= 5/gap, gap ~ lambda_min sqrt(2 UJ) J_ring.  L=8, S=1 needs ~10^5 steps: hours in pure Python; run per seed in parallel.
        The estimate is the small-k limit of S_T(k)/lambda_k; compare the three axes (they must agree) and the
        diagonal k (should be close); increase L until it stops drifting.
Check:  python3 alpha_liftB_gfmc.py --L 2 --S 1 --steps 4000  should give E0 ~ -20.148 (ED);  S=0.5: -9.027.
Explicit-U test:  python3 alpha_liftB_gfmc.py --L 6 --S 6 --UJ 0.0086 --walkers 800 --steps 300000 --fw 70000 --meas_every 1000
        (tree level predicts S_T/lambda = 10.8, alpha^-1 = 135.5; the photon gap at k_min is ~0.19 J_ring, dtau = 4.6e-4,
         so fw ~ 70000 steps at L=6.  Hours per seed in numpy; a numba decorator on feasible() gives ~20x.)
Results so far: L=6 S=1: alpha^-1 = 14; L=8 S=1: 20+-6 (axes scatter: lineage collapse, use more walkers);
                L=6 S=0.5: alpha^-1 = 7 (after the step^2 units fix in v2 of this script).
"""
import numpy as np, argparse, itertools, time, sys

def build(L):
    sites=list(itertools.product(range(L),repeat=3)); sidx={s:i for i,s in enumerate(sites)}
    def sh(s,mu,d=1): t=list(s); t[mu]=(t[mu]+d)%L; return tuple(t)
    links=[(s,mu) for s in sites for mu in range(3)]; lidx={l:i for i,l in enumerate(links)}
    pl=[];  # plaquettes (s,mu<nu): +(s,mu) +(s+mu,nu) -(s+nu,mu) -(s,nu)
    for s in sites:
        for mu,nu in [(0,1),(0,2),(1,2)]:
            pl.append([lidx[(s,mu)],lidx[(sh(s,mu),nu)],lidx[(sh(s,nu),mu)],lidx[(s,nu)]])
    pl=np.array(pl); sg=np.array([1,1,-1,-1])
    # link positions (midpoints) and directions for Fourier transforms
    pos=np.array([[s[i]+0.5*(i==mu) for i in range(3)] for (s,mu) in links],float)
    dirn=np.array([mu for (s,mu) in links])
    return pl,sg,pos,dirn,len(links)

def init_state(L,S,step,rng,pl,sg,NL):
    """a Gauss-law state with flippable plaquettes.  Integer S: E=0.  Spin-1/2 (stored +-1):
    E(s,x)=(-1)^(s_y+s_z), E(s,y)=(-1)^(s_z+s_x), E(s,z)=(-1)^(s_x+s_y): divergence-free, and the plaquettes
    with the right parities are flippable (needs even L)."""
    if step==1: return np.zeros(NL,np.int8)
    assert L%2==0, "spin-1/2 initial state needs even L"
    E=np.zeros(NL,np.int8); sites=list(itertools.product(range(L),repeat=3)); i=0
    for s in sites:
        for mu in range(3):
            o=[j for j in range(3) if j!=mu]; E[i]=1 if (s[o[0]]+s[o[1]])%2==0 else -1; i+=1
    return E

def feasible(Ew,pl,sg,step,S):
    """Ew: (W,NL).  returns feas (W,NP,2) bool for sign +1 / -1."""
    sub=Ew[:,pl]                       # (W,NP,4)
    up=sub+step*sg; dn=sub-step*sg
    return np.stack([np.all(np.abs(up)<=S,axis=2), np.all(np.abs(dn)<=S,axis=2)],axis=2)

def structure_factor(Ew,pos,dirn,L,ks):
    """transverse S_T(k) per walker for a list of k vectors (in units 2pi/L * integer)."""
    out=np.zeros((len(ks),Ew.shape[0]))
    N=L**3
    for a,kk in enumerate(ks):
        k=2*np.pi*np.array(kk)/L
        ph=np.exp(1j*(pos@k))/np.sqrt(N)
        Ek=np.stack([(Ew[:,dirn==i]*ph[dirn==i]).sum(1) for i in range(3)],axis=1)   # (W,3)
        # lattice transverse projector with K_i = 2 sin(k_i/2) (phase conventions cancel in |.|^2 for axis-aligned k)
        K=2*np.sin(k/2); K2=K@K
        if K2<1e-12: out[a]=np.abs(Ek).sum(1)**0; continue
        Ek_L=(Ek@K)/K2
        Et=Ek-np.outer(Ek_L,K)
        out[a]=(np.abs(Et)**2).sum(1)
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--L',type=int,default=4); ap.add_argument('--S',type=float,default=1.0)
    ap.add_argument('--walkers',type=int,default=300); ap.add_argument('--steps',type=int,default=5000)
    ap.add_argument('--equil',type=int,default=None); ap.add_argument('--fw',type=int,default=150)
    ap.add_argument('--meas_every',type=int,default=50); ap.add_argument('--dtau',type=float,default=None)
    ap.add_argument('--seed',type=int,default=1)
    ap.add_argument('--reconf',type=int,default=10,help='reconfigure population every this many steps (weights accumulate in between)')
    ap.add_argument('--UJ',type=float,default=0.0,help='explicit Kogut-Susskind charging ratio U/J_KS with J_KS = 2 J_ring (0 = pure quantum link model)')
    a=ap.parse_args()
    rng=np.random.default_rng(a.seed); L=a.L
    step=2 if abs(a.S-0.5)<1e-9 else 1; Smax=1 if abs(a.S-0.5)<1e-9 else int(a.S)   # spin-1/2 stored as +-1
    pl,sg,pos,dirn,NL=build(L); NP=len(pl); W=a.walkers; J=1.0
    if a.dtau is None: a.dtau=0.3/NP     # power-method stability with E_T ~ E_0: dtau < 2/(E_max-E_0) ~ 1/(2|E_0|); |E_0|/N_plaq <= ~2
    if a.UJ>0: print(f'explicit charging energy: U/J_KS = {a.UJ}  ->  tree-level prediction S_T/lambda = sqrt(J_KS/U) = {1/np.sqrt(a.UJ):.3f}, alpha^-1 = {4*np.pi/np.sqrt(a.UJ):.2f}',flush=True)
    print(f'L={L} S={a.S} walkers={W} steps={a.steps} dtau={a.dtau:.5f} fw={a.fw} meas_every={a.meas_every}',flush=True)
    E0w=init_state(L,a.S,step,rng,pl,sg,NL); Ew=np.tile(E0w,(W,1))
    equil=a.equil if a.equil is not None else a.steps//3
    ET=0.0; wsum_hist=[]; Emix=[]; pending=[]   # pending forward-walking measurements
    ks=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1)] if L>2 else [(1,0,0),(0,1,0),(0,0,1)]
    lam=[np.sqrt(np.sum(4*np.sin(np.pi*np.array(kk)/L)**2)) for kk in ks]
    results=[]; t0=time.time()
    wacc=np.ones(W); 
    for it in range(a.steps):
        feas=feasible(Ew,pl,sg,step,Smax); n=feas.reshape(W,-1).sum(1)      # number of feasible flips
        Hd=0.5*(a.UJ*2*J)*((Ew.astype(float)/step)**2).sum(1)              # diagonal charging energy (U/2) sum E^2, U = UJ * J_KS, J_KS = 2 J_ring
        Eloc=-J*n+Hd
        w=1.0+a.dtau*(ET-Eloc)                                             # row sums of G = 1 - dtau(H - E_T)
        w=np.maximum(w,1e-12)
        pjump=a.dtau*J*n/w
        jump=rng.random(W)<pjump
        for i in np.nonzero(jump)[0]:
            f=np.nonzero(feas[i].reshape(-1))[0]; c=f[rng.integers(len(f))]; p,sgn=c//2,(1 if c%2==0 else -1)
            Ew[i,pl[p]]+=sgn*step*sg
        # mixed estimator with the weights carried into this step (before this step's factor)
        Emix.append((wacc*Eloc).sum()/wacc.sum()); wsum_hist.append(w.mean())
        wacc*=w
        if it>=equil and it%a.meas_every==0:
            O=structure_factor(Ew,pos,dirn,L,ks)/step**2
            pending.append([it,O,np.arange(W),wacc.copy()])
        if (it+1)%a.reconf==0:
            pw=wacc/wacc.sum(); idx=rng.choice(W,size=W,p=pw)
            Ew=Ew[idx]; wacc=np.ones(W)
            for rec in pending: rec[2]=rec[2][idx]
        done=[rec for rec in pending if it-rec[0]>=a.fw]
        for rec in done:
            _,O,ancs,_=rec; results.append(O[:,ancs].mean(1)); pending.remove(rec)
        # adaptive energy offset: track the running mixed energy (keeps weights near 1)
        if it>=100: ET=0.98*ET+0.02*np.mean(Emix[-100:])
        elif it==99: ET=np.mean(Emix[-50:])
        if it%1000==0:
            print(f"step {it} E_mix={np.mean(Emix[-1000:]):.4f} E_T={ET:.2f} <n>={n.mean():.1f} pending={len(pending)} done={len(results)} ({time.time()-t0:.0f}s)",flush=True)
    Eest=np.mean(Emix[equil:]); Eerr=np.std(Emix[equil:])/np.sqrt(len(Emix[equil:])/50)
    print(f"\nL={L} S={a.S}: E0 (mixed, exact for H) = {Eest:.4f} +- {Eerr:.4f}   E0/N_plaq = {Eest/NP:.4f}")
    R=np.array(results)
    if len(R):
        m=R.mean(0); e=R.std(0)/np.sqrt(len(R))
        print("forward-walked transverse structure factor and implied coupling:")
        for kk,l,mm,ee in zip(ks,lam,m,e):
            print(f"  k=2pi/L*{kk}: S_T={mm:.4f}+-{ee:.4f}  lambda_k={l:.4f}  sqrt(J/U)=S_T/lambda={mm/l:.4f}  alpha^-1={4*np.pi*mm/l:.2f}")
        ax=np.mean(m[:3])/np.mean(lam[:3])
        print(f"  axis average: sqrt(J/U) = {ax:.4f}  ->  alpha^-1 = {4*np.pi*ax:.2f}   (samples={len(R)})")
    else: print("no forward-walked samples; increase --steps or reduce --fw")
if __name__=="__main__": main()
