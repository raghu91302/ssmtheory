#!/usr/bin/env python3
"""Elementary Gauss-preserving moves of the dual clock model: alternating flips on tetrahedral 4-cycles.
Report: count, conservation, rank of the move space vs logical dimension, and the 4th-order ring-exchange
path count with intermediate charges."""
import itertools, numpy as np, sys
def run(N):
    NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
    E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
    m=lambda p: tuple(c%N for c in p); add=lambda p,d: m((p[0]+d[0],p[1]+d[1],p[2]+d[2])); par=lambda p: sum(p)%2
    nodes=[p for p in itertools.product(range(N),repeat=3) if par(p)==0]; voids=[p for p in itertools.product(range(N),repeat=3) if par(p)==1]
    edges=sorted({frozenset((n,add(n,d))) for n in nodes for d in NN},key=lambda e:sorted(e)); eidx={e:i for i,e in enumerate(edges)}; ne=len(edges)
    chk=[]
    for n in nodes: chk.append([eidx[frozenset((n,add(n,d)))] for d in NN])
    for o in voids:
        ring=[add(o,d) for d in E3]; chk.append([eidx[frozenset((a,b))] for a in ring for b in ring if a<b and frozenset((a,b)) in eidx])
    C=np.zeros((len(chk),ne),int)
    for c,es in enumerate(chk): C[c,es]=1
    tets=[tuple(2*c+1 for c in p) for p in itertools.product(range(N),repeat=3)]
    def verts(t):
        out=[]
        for s in itertools.product([1,-1],repeat=3):
            v=tuple(((t[i]+s[i])//2)%N for i in range(3))
            if sum(v)%2==0: out.append(v)
        return out
    moves=[]
    for t in tets:
        v=verts(t); pairs=[(a,b) for a in range(4) for b in range(a+1,4)]
        for skew in [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]:
            cyc=[p for p in pairs if p not in skew]; adj={i:[] for i in range(4)}
            for a,b in cyc: adj[a].append(b); adj[b].append(a)
            order=[0]; prev=None
            while len(order)<4:
                nxt=[x for x in adj[order[-1]] if x!=prev and x not in order][0]; prev=order[-1]; order.append(nxt)
            es=[eidx[frozenset((v[order[i]],v[order[(i+1)%4]]))] for i in range(4)]
            vec=np.zeros(ne,int)
            for i,e in enumerate(es): vec[e]=1 if i%2==0 else -1
            moves.append(vec)
    moves=np.array(moves)
    rk=np.linalg.matrix_rank(moves.astype(float))
    k=2*N**3+2
    # 4th-order path count for one move: sum over orderings of prod 1/(charge cost of intermediates), cost = number of charged cubes (unit V each, quadratic penalty V*Q^2 with Q=+-1)
    mv=moves[0]; es=np.nonzero(mv)[0]; sg=mv[es]; total=0.0; hist={}
    for perm in itertools.permutations(range(4)):
        v=np.zeros(ne,int); den=1.0; costs=[]
        for i in perm[:3]:
            v[es[i]]+=sg[i]; q=C@v; costs.append(int((q**2).sum())); den*=costs[-1]
        total+=1.0/den; hist[tuple(costs)]=hist.get(tuple(costs),0)+1
    print(f"N={N}: bonds={ne} moves={len(moves)} conserve all cubes: {not (C@moves.T).any()}; rank(moves)={rk}, k={k}, k-rank={k-rk}")
    print(f"   4th-order ring exchange: J = {total:.4f} t^4/V^3 ; intermediate charge costs (V Q^2 units) by ordering: {hist}")
for N in (4,6): run(N)
