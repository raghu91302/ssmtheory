#!/usr/bin/env python3
"""Two-step path counts used in Section 8.10 of the alpha paper.

Verified here by enumeration on the FCC lattice:
  * K = 12 nearest neighbours; K^2 = 144 ordered two-step paths from a node
    (12 of them return to the origin; the rest reach 54 distinct endpoints).
    The second coordination shell has 6 members, so K^2 is a path count, not a shell count.
  * the external leading term, 13 x 144 = 1872, under the convention of Ref. [3] in which the
    defect's "13 structural nodes" are the twelve corner ends of the tetrahedron's six edges
    plus the trapped centre (the four bounding vertices are 4 distinct lattice nodes, each an
    end of 3 edges, so 4 x 3 = 12 ends);
  * the internal count, 4 x 3 + 4 = 16, from the trapped node inside the defect graph,
    equal to the number of committed bond-ends at the four bounding vertices.

  * the correction -36: the ordered two-step paths from the four bounding vertices that never
    leave the defect (3 first steps along tetrahedron edges x 3 second steps, per corner:
    4 x 3 x 3 = 36, of which 12 return to the start). These are internal, not external, so they
    are removed from the external count: 13 x 144 - 36 = 1836. Numerically this equals Ref. [3]'s
    c_skew*K = 3 x 12.
"""
import itertools, math
NN=[v for v in itertools.product([-1,0,1],repeat=3) if sum(x*x for x in v)==2]
add=lambda p,d: tuple(p[i]+d[i] for i in range(3))
assert len(NN)==12
paths=[(d1,d2) for d1 in NN for d2 in NN]
ret=[p for p in paths if all(p[0][i]+p[1][i]==0 for i in range(3))]
ends={add(add((0,0,0),d1),d2) for d1,d2 in paths}-{(0,0,0)}
shell2=[v for v in itertools.product(range(-2,3),repeat=3) if sum(x*x for x in v)==4]
print(f"K = {len(NN)};  ordered two-step paths K^2 = {len(paths)};  returning = {len(ret)};  distinct endpoints = {len(ends)}")
print(f"second coordination shell = {len(shell2)} members  ->  K^2 is a path count, not a shell count\n")

A,B,C,D=(0,0,0),(1,1,0),(1,0,1),(0,1,1); corners=[A,B,C,D]
edges=[(i,j) for i in range(4) for j in range(i+1,4)]
ends_per_corner=3            # each corner is an end of 3 of the 6 edges
n_ends=len(corners)*ends_per_corner
print(f"defect: {len(corners)} bounding vertices, {len(edges)} tetrahedron edges, {n_ends} corner ends, +1 trapped centre")
print(f"external, leading term: ({n_ends}+1) x K^2 = 13 x 144 = {(n_ends+1)*len(paths)}")
cor={A,B,C,D}
internal_only=sum(1 for c in cor for d1 in NN if add(c,d1) in cor for d2 in NN if add(add(c,d1),d2) in cor)
per=[sum(1 for d1 in NN if add(c,d1) in cor for d2 in NN if add(add(c,d1),d2) in cor) for c in cor]
ret=sum(1 for c in cor for d1 in NN if add(c,d1) in cor for d2 in NN if add(add(c,d1),d2)==c)
print(f"correction: two-step paths from the 4 bounding vertices that stay inside the defect = {per} -> {internal_only} (of which {ret} return to the start)")
print(f"  = 4 x 3 x 3 = {4*3*3}, numerically Ref. [3]'s c_skew*K = {3*12}")
print(f"external, priced count: 13 x 144 - {internal_only} = {(n_ends+1)*len(paths)-internal_only}\n")

internal=len(corners)*ends_per_corner+len(corners)   # 4 spokes x 3 K4 edges, plus 4 out-and-back
print(f"internal two-step paths from the trapped node = 4x3 + 4 = {internal}")
print(f"committed bond-ends at the bounding vertices  = 4 x (3 + 1) = {4*4}\n")



lam=386.159
for N in (1836,1872):
    Lc=4*lam/N
    print(f"N={N}: L_c = 4*lambda_e/N = {Lc:.4f} fm (r_p = 0.8409, {100*(Lc/0.8409-1):+.2f}%), alpha^-1 = pi*sqrt(N) = {math.pi*math.sqrt(N):.2f}")
print("Removing the internal-only paths is 2% of the count and moves L_c from 1.9% below r_p to 0.05% above it.")
