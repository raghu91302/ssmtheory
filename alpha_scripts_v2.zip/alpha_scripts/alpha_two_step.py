#!/usr/bin/env python3
"""Two-step path counts used in Section 8.10.
External: from an FCC node, K^2 = 144 ordered two-step paths (12 neighbours x 12 onward steps);
12 of them return to the origin; the rest reach 54 distinct endpoints.  The second coordination
shell has 6 members, so K^2 is a path count, not a shell count.
Internal: the trapped-node defect is K_4 on the four bounding vertices plus four spokes to the centre;
two-step paths from the trapped node are 4 spokes x 3 K_4 edges + 4 out-and-back = 16, equivalently
4 committed bond-ends at each of the 4 bounding vertices."""
import itertools
NN=[v for v in itertools.product([-1,0,1],repeat=3) if sum(x*x for x in v)==2]
assert len(NN)==12
paths=[(d1,d2) for d1 in NN for d2 in NN]
ret=[p for p in paths if all(p[0][i]+p[1][i]==0 for i in range(3))]
ends={tuple(d1[i]+d2[i] for i in range(3)) for d1,d2 in paths}-{(0,0,0)}
shell2=[v for v in itertools.product(range(-2,3),repeat=3) if sum(x*x for x in v)==4]
print(f"K = {len(NN)}; ordered two-step paths K^2 = {len(paths)}; returning = {len(ret)}; distinct endpoints = {len(ends)}")
print(f"second coordination shell = {len(shell2)} members  (so K^2 is a path count, not a shell count)")
K,c=12,3
print(f"external count (K+1)K^2 - c_skew*K = {(K+1)*K**2-c*K}")
corners=list(range(4))
internal=sum(3 for _ in corners)+4      # 4 spokes x 3 K4 edges, plus 4 out-and-back
print(f"internal two-step paths from the trapped node = 4x3 + 4 = {internal}")
print(f"committed bond-ends at the bounding vertices = 4 x (3 edge-ends + 1 spoke-end) = {4*4}")
