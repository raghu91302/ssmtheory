# Scripts for "The fine-structure constant as a confinement-length ratio"

Runtimes: the structural, running, Gaussian and Floquet scripts take seconds to a minute (numpy/scipy; matplotlib for the figures). Exact diagonalization takes minutes (spin-1). The projector Monte Carlo takes minutes at L=4 and hours per seed at L>=6; `alpha_liftB_gfmc_fast.py` needs numba.

| script | paper section | what it computes |
|---|---|---|
| `alpha_run.py` | Sec. 5, App. A | Two-loop SM running of alpha_em to the fine-code cutoff; one-loop leptonic + hadronic estimate at the confinement scale |
| `alpha_cost_ratios.py` | Sec. 6.1 | Verification-cost (E_s x C_s) of Gauss-law charges and plaquette flux on the <100> sector; shows count ratios give a confining phase |
| `alpha_ice_quartet.py` | Sec. 6.2, Prop. 3 | Annealed Metropolis sampling of the charge-free ensemble; quartet correlation of the four bonds a link serves |
| `alpha_elastic_projection.py` | Sec. 6.3 | Projection of FCC phonons onto <100> link one-forms; shows no Maxwell sector and Zener anisotropy |
| `alpha_ring_exchange.py` | Sec. 7, App. B | Exact second-order ring exchange J = 2 t^2 / V on the <100> lattice |
| `alpha_gaussian_levels.py` | App. C | Self-consistent harmonic estimate of the coupling vs link level count |
| `alpha_calibrate_diamond.py` | App. C | Same estimator on the diamond lattice (quantum spin ice) for calibration; tests the served-qubit candidate |
| `alpha_liftB_ice.py` | Sec. 6.2, Prop. 3 | The photon's charge-free ensemble (tetrahedral-void divergence) with Z_M bond fluxes; served-quartet fluctuation |
| `alpha_liftA_liftB.py` | Sec. 6.2, Prop. 2 | Bloch dispersion of the two U(1) lifts on the bonds: cube-edge (not Maxwell) vs tetrahedral divergence (Maxwell) |
| `alpha_liftB_ed.py` (+ `alpha_liftB_ed_common.py`) | Sec. 6.2, Prop. 3 | Exact diagonalization of the photon sector at L=2 (spin-1/2 and spin-1) with electric and magnetic twists; run `python3 alpha_liftB_ed.py half` and `... one` |
| `alpha_liftB_gfmc.py` | rotor program | Projector Monte Carlo for lift B (spin-S quantum link model); forward-walked transverse structure factor gives sqrt(J/U) and alpha^-1 with no calibration. Benchmarked against exact diagonalization at L=2. L=6 spin-1 gives alpha^-1 = 14. |
| `alpha_liftB_gfmc_fast.py` | Sec. 5 | numba-compiled, checkpointed projector MC with optional explicit charging energy (`--UJ`); the Kogut-Susskind check (L=4: alpha^-1 = 132-136 for U/J = 0.0086) |
| `alpha_tick_floquet.py` | Sec. 8.7 | Exact Floquet Hamiltonian of the tick unitary (single bond and served quartet); U_eff/J_eff vs input |
| `alpha_current_operator.py` | Sec. 8.8 | Flux current of the phase term; exact transfer per tick; verifies j=1 |
| `alpha_two_step.py` | Sec. 8.10, App. E | Two-step path counts: 144 per node, 16 inside the defect |
| `alpha_monopole.py` | Sec. 8.7 | Lattice monopole self-energy constant v(0) and the confinement-code monopole mass |
| `alpha_figures.py` | Figs. 1-5 | Regenerates all five figures |

Note: `alpha_ice_quartet.py` samples the cube-edge-constrained ensemble (lift A), kept for comparison; the photon's ensemble is `alpha_liftB_ice.py`. `alpha_gaussian_levels.py` and `alpha_ice_quartet.py` were written against the fine-code target 104.9; the paper's Section 6.2 and Appendix C quote the numbers rescaled to the confinement-scale target 135.5 (needed <E^2> = 3.2, c = +0.7). Edit the `target` variable to reproduce either.
