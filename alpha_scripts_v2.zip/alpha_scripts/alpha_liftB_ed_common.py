import numpy as np, itertools, time
from scipy.sparse import csr_matrix, coo_matrix
from scipy.sparse.linalg import eigsh, minres, LinearOperator
L=2; NS=L**3
sites=list(itertools.product(range(L),repeat=3)); sidx={s:i for i,s in enumerate(sites)}
def sh(s,mu,d=1): t=list(s); t[mu]=(t[mu]+d)%L; return tuple(t)
links=[(s,mu) for s in sites for mu in range(3)]; lidx={l:i for i,l in enumerate(links)}; NL=len(links)
DIV=np.zeros((NS,NL),np.int64)
for s in sites:
    for mu in range(3):
        DIV[sidx[s],lidx[(s,mu)]]+=1; DIV[sidx[s],lidx[(sh(s,mu,-1),mu)]]-=1
plaqs=[]
for s in sites:
    for mu,nu in [(0,1),(0,2),(1,2)]:
        plaqs.append((np.array([lidx[(s,mu)],lidx[(sh(s,mu),nu)],lidx[(sh(s,nu),mu)],lidx[(s,nu)]]),np.array([1,1,-1,-1]),s,(mu,nu)))
xlinks0=np.array([lidx[(s,0)] for s in sites if s[0]==0])
def enumerate_mim(vals, Wx):
    A=np.arange(12); B=np.arange(12,24)
    confA=np.array(list(itertools.product(vals,repeat=12)),dtype=np.int64)
    dA=confA@DIV[:,A].T; wA=confA[:,[i for i,l in enumerate(A) if l in set(xlinks0)]].sum(1)
    dB=confA@DIV[:,B].T; wB=confA[:,[i for i,l in enumerate(B) if l in set(xlinks0)]].sum(1)
    from collections import defaultdict
    groups=defaultdict(list)
    for i,k in enumerate(map(tuple,np.concatenate([dA,wA[:,None]],1))): groups[k].append(i)
    keysB=map(tuple,np.concatenate([-dB,(Wx-wB)[:,None]],1))
    out=[]
    for j,k in enumerate(keysB):
        for i in groups.get(k,()): out.append((i,j))
    out=np.array(out); return np.concatenate([confA[out[:,0]],confA[out[:,1]]],1)
def encode(basis,base,offset): 
    pw=base**np.arange(NL,dtype=np.int64); return ((basis+offset)*pw).sum(1)
def build_parts(basis, Smax, step, base, offset):
    """returns H0 (all plaquettes, theta=0), Hp, Hm (crossing plaquettes, + and - flips) as real sparse matrices (sign -1 included)."""
    n=len(basis); codes=encode(basis,base,offset); order=np.argsort(codes); sc=codes[order]
    parts={'all':[],'p':[],'m':[]}
    for (ls,sg,s,(mu,nu)) in plaqs:
        cross=((mu,nu)==(0,1) and s[1]==L-1)
        for sign in (+1,-1):
            nb=basis.copy(); nb[:,ls]+=sign*step*sg
            ok=np.all(np.abs(nb)<=Smax,axis=1); idx=np.nonzero(ok)[0]
            c=encode(nb[idx],base,offset); pos=np.searchsorted(sc,c); pos=np.clip(pos,0,n-1)
            found=sc[pos]==c; i=idx[found]; j=order[pos[found]]
            parts['all'].append((j,i))
            if cross: parts['p' if sign==+1 else 'm'].append((j,i))
    def mk(lst):
        if not lst: return csr_matrix((n,n))
        J=np.concatenate([a for a,b in lst]); I=np.concatenate([b for a,b in lst])
        return coo_matrix((-np.ones(len(I)),(J,I)),shape=(n,n)).tocsr()
    return mk(parts['all']), mk(parts['p']), mk(parts['m'])
def ground_vec(H):
    if H.shape[0]<600:
        w,v=np.linalg.eigh(H.toarray()); return w[0],v[:,0]
    w,v=eigsh(H,k=1,which='SA'); return w[0],v[:,0]
def curvature(H0,Hp,Hm,E0,psi):
    """E0''(theta) at 0 for H(theta)=H0+(e^{i th}-1)Hp+(e^{-i th}-1)Hm."""
    # H'' = -(Hp+Hm) ; H' = i(Hp-Hm)
    first=-(psi@((Hp+Hm)@psi))
    v=(Hp-Hm)@psi; v=v-psi*(psi@v)          # (1-P0) H'psi up to factor i
    n=len(psi)
    op=LinearOperator((n,n),matvec=lambda x:(H0@x-E0*x)-psi*(psi@x)*0 ,dtype=float)  # (H0-E0) on the orthogonal complement; add projector shift to make it invertible
    op2=LinearOperator((n,n),matvec=lambda x:(H0@x-E0*x)+psi*(psi@x),dtype=float)
    x,info=minres(op2,v,rtol=1e-8,maxiter=5000)
    second=-2*(v@x)
    return first+second, info
