#!/usr/bin/env python3
"""Probe: electric vs magnetic verification costs on the <100> sector of the FCC code.

Sites of the <100> lattice: all integer points (x,y,z) mod L.  Even parity = FCC node
(Z-check), odd parity = octahedral void (X-check).  <100> links = +-e_i.  Plaquettes =
unit squares; each plaquette is exactly the two 2-step paths of one <110> code edge.
"""
import itertools, numpy as np
L = 6
NN = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E = [(1,0,0),(0,1,0),(0,0,1)]
m = lambda p: tuple(c % L for c in p)
add = lambda p,d: m((p[0]+d[0],p[1]+d[1],p[2]+d[2]))
par = lambda p: sum(p) % 2

nodes = [p for p in itertools.product(range(L),repeat=3) if par(p)==0]
voids = [p for p in itertools.product(range(L),repeat=3) if par(p)==1]
sites = nodes + voids

# code edges (<110>), as frozensets of endpoints
edges = set()
for n in nodes:
    for d in NN: edges.add(frozenset((n, add(n,d))))
edges = list(edges); eidx = {e:i for i,e in enumerate(edges)}
# checks: Z at each node (12 incident edges), X at each void (12 octahedron edges)
Zchk = {n: {eidx[frozenset((n,add(n,d)))] for d in NN} for n in nodes}
Xchk = {}
for o in voids:
    ring = [add(o,d) for d in E] + [add(o,(-d[0],-d[1],-d[2])) for d in E]
    Xchk[o] = {eidx[frozenset((a,b))] for a in ring for b in ring
               if frozenset((a,b)) in eidx}
assert all(len(s)==12 for s in Zchk.values()) and all(len(s)==12 for s in Xchk.values())
edge_checks = {}          # code edge -> set of (type, site) checks detecting it
for n,s in Zchk.items():
    for e in s: edge_checks.setdefault(e,set()).add(('Z',n))
for o,s in Xchk.items():
    for e in s: edge_checks.setdefault(e,set()).add(('X',o))
assert all(len(v)==4 for v in edge_checks.values())

# <100> links -> the code edges whose two-step paths use them
links = set()
for s in sites:
    for d in E: links.add(frozenset((s, add(s,d))))
links = list(links)
def link_edges(l):
    a,b = tuple(l)
    n,o = (a,b) if par(a)==0 else (b,a)      # node, void
    return {eidx[frozenset((n,nb))] for nb in (add(o,d) for d in E+[(-1,0,0),(0,-1,0),(0,0,-1)])
            if nb!=n and frozenset((n,nb)) in eidx}
LE = {l: link_edges(l) for l in links}
assert all(len(v)==4 for v in LE.values())

# plaquettes: one per code edge
def plaquette_links(e):
    a,b = tuple(e); d = tuple((b[i]-a[i]+L//2)%L - L//2 for i in range(3))
    i,j = [k for k in range(3) if d[k]!=0]
    di = tuple(d[k] if k==i else 0 for k in range(3)); dj = tuple(d[k] if k==j else 0 for k in range(3))
    o1, o2 = add(a,di), add(a,dj)
    return [frozenset((a,o1)),frozenset((o1,b)),frozenset((a,o2)),frozenset((o2,b))]
print(f"L={L}: sites {len(sites)}, code edges {len(edges)}, <100> links {len(links)}, plaquettes {len(edges)}")

def cost(edge_set):
    Es = len(edge_set)
    Cs = set().union(*(edge_checks[e] for e in edge_set))
    z = sum(1 for c in Cs if c[0]=='Z'); x = len(Cs)-z
    return Es, len(Cs), z, x, Es*len(Cs)

def report(label, edge_set):
    Es,Cs,z,x,C = cost(edge_set)
    print(f"  {label:42s} E_s={Es:3d}  C_s={Cs:3d} (Z {z:2d}, X {x:2d})  C={C}")

print("\nMagnetic (flux through one plaquette = one code edge in disagreement):")
e0 = 0
report("plaquette, code checks", {e0})
print("  plaquette, M/E/I trivial-sector convention          C=1  (electron)")

print("\nElectric:")
n0 = nodes[0]; o0 = voids[0]
lk = frozenset((n0, add(n0,(1,0,0))))
report("unit E on one link (4 code edges)", LE[lk])
report("unit charge at a node (div E=1, 6 links)", set().union(*(LE[frozenset((n0,add(n0,d)))] for d in E+[(-1,0,0),(0,-1,0),(0,0,-1)])))
report("unit charge at a void", set().union(*(LE[frozenset((o0,add(o0,d)))] for d in E+[(-1,0,0),(0,-1,0),(0,0,-1)])))
report("closed E loop around one plaquette", set().union(*(LE[l] for l in plaquette_links(edges[e0]))))

print("\nCoupling from cost ratios (KS: cost(unit E)/cost(unit B) = g^4/4, alpha=g^2/4pi):")
CB_list = {"code-check B (C=4)":4, "trivial-sector B (C=1)":1}
for lab_e, es in [("link E", LE[lk]),
                  ("node charge", set().union(*(LE[frozenset((n0,add(n0,d)))] for d in E+[(-1,0,0),(0,-1,0),(0,0,-1)]))),
                  ("E loop", set().union(*(LE[l] for l in plaquette_links(edges[e0]))))]:
    CE = cost(es)[-1]
    for lab_b, CB in CB_list.items():
        r = CE/CB; g2 = 2*np.sqrt(r); alpha = g2/(4*np.pi)
        print(f"  {lab_e:12s} / {lab_b:22s}: r={r:7.1f}  g^2={g2:6.2f}  alpha={alpha:6.2f}  beta=1/g^2={1/g2:.3f}")
print("\nCoulomb phase needs beta > ~1.01 (g^2 < ~0.99); alpha^-1(1/a)~100 needs g^2~0.125, r = g^4/4 ~ 0.004")
