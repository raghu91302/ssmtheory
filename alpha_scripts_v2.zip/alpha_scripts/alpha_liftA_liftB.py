#!/usr/bin/env python3
"""Bloch dispersion of the two U(1) lifts on the code bonds.
Lift A: cube-edge (check) Gauss law, tetrahedral 4-cycle ring exchange -> anisotropic, not Maxwell.
Lift B: tetrahedral-void divergence, dual-plaquette (served-quartet) ring exchange -> Maxwell.
"""

import numpy as np, itertools
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
# representative bonds from node 0: 6 bonds n->n+d for d in first half of NN (others are translates)
reps=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
def bond_rep(a,b):
    """bond between even points a,b -> (rep index, translation r) such that bond = translate of rep bond by r (r even point)"""
    d=tuple(b[i]-a[i] for i in range(3))
    if d in reps: return reps.index(d), a
    dn=tuple(-x for x in d)
    if dn in reps: return reps.index(dn), b
    raise ValueError
def phase(k,r): return np.exp(1j*np.dot(k,r))
# checks in the cell: node cube at n=0 and void cube at o=(1,0,0)
def C_of_k(k):
    C=np.zeros((2,6),complex)
    n=(0,0,0)
    for d in NN:
        b=tuple(n[i]+d[i] for i in range(3)); i,r=bond_rep(n,b); C[0,i]+=phase(k,r)
    o=(1,0,0); ring=[tuple(o[i]+d[i] for i in range(3)) for d in E3]
    for a in ring:
        for b in ring:
            if a<b and tuple(abs(b[i]-a[i]) for i in range(3)) in [tuple(abs(x) for x in d) for d in NN] and sum(abs(b[i]-a[i]) for i in range(3))==2:
                i,r=bond_rep(a,b); C[1,i]+=phase(k,r)
    return C
# tetrahedra in the cell: centres (1/2,1/2,1/2) and (-1/2,-1/2,-1/2)?? use doubled coords: (1,1,1) and (1,1,-1)... take the two tets containing node 0 with centres t=(±.5,±.5,±.5) of the two orientations: (.5,.5,.5) and (.5,.5,-.5)
def verts(t):
    return [tuple(int(t[i]+s[i]) for i in range(3)) for s in itertools.product([.5,-.5],repeat=3) if sum(int(t[i]+s[i]) for i in range(3))%2==0]
def A_of_k(k):
    rows=[]
    for t in [(.5,.5,.5),(.5,.5,-.5)]:
        v=verts(t); assert len(v)==4
        pairs=[(a,b) for a in range(4) for b in range(a+1,4)]
        for skew in [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]:
            cyc=[p for p in pairs if p not in skew]; adj={i:[] for i in range(4)}
            for a,b in cyc: adj[a].append(b); adj[b].append(a)
            order=[0]; prev=None
            while len(order)<4:
                nxt=[x for x in adj[order[-1]] if x!=prev and x not in order][0]; prev=order[-1]; order.append(nxt)
            row=np.zeros(6,complex)
            for i in range(4):
                a,b=v[order[i]],v[order[(i+1)%4]]; j,r=bond_rep(a,b); row[j]+=(1 if i%2==0 else -1)*phase(k,r)
            rows.append(row)
    return np.array(rows)
def bands(k):
    C=C_of_k(k); A=A_of_k(k)
    # gauge directions: C^H phi ; project out
    Q,_=np.linalg.qr(C.conj().T); P=np.eye(6)-Q@Q.conj().T
    M=P@(A.conj().T@A)@P
    w=np.linalg.eigvalsh(M); return np.sort(w.real)
print("=== Lift A: cube-edge Gauss law, tetrahedral 4-cycle ring exchange ===")
for name,kh in [("[100]",(1,0,0)),("[110]",(1,1,0)),("[111]",(1,1,1)),("[210]",(2,1,0))]:
    kh=np.array(kh,float); kh/=np.linalg.norm(kh)
    for kmag in [0.05,0.02]:
        w=bands(kmag*kh); nz=w[w>1e-10]
        print(f"{name} |k|={kmag}: omega^2/k^2 of lowest bands = {np.round(nz[:4]/kmag**2,4)}")
print("(Maxwell reference: omega^2/k^2 = 1 for both polarizations, all directions)")

# ---------------- lift B ----------------

import numpy as np, itertools
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
reps=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
def tets_of_bond(a,b):
    """the two tetrahedral-void centres (half-integer) sharing bond a-b, ordered by the bond's orientation convention"""
    mid=np.array([(a[i]+b[i])/2 for i in range(3)]); d=np.array(b)-np.array(a)
    # centres are mid +- (perp direction)/2 where perp is the axis with d=0, times ... for FCC edge (1,1,0): tets at mid +- (0,0,.5)? no: tets at (.5,.5,.5),(.5,.5,-.5) for bond (0,0,0)-(1,1,0): mid=(.5,.5,0) -> +-(0,0,.5)
    z=[i for i in range(3) if d[i]==0][0]; e=np.zeros(3); e[z]=.5
    return tuple(mid+e), tuple(mid-e)
def bond_rep(a,b):
    d=tuple(b[i]-a[i] for i in range(3))
    if d in reps: return reps.index(d), a, +1
    dn=tuple(-x for x in d)
    if dn in reps: return reps.index(dn), b, -1
    raise ValueError
phase=lambda k,r: np.exp(1j*np.dot(k,r))
# divergence at the two tets in the cell: t=(.5,.5,.5) and (.5,.5,-.5); a bond's dual orientation: from tets_of_bond()[0] to [1]
def bonds_of_tet(t):
    v=[tuple(int(t[i]+s[i]) for i in range(3)) for s in itertools.product([.5,-.5],repeat=3) if sum(int(t[i]+s[i]) for i in range(3))%2==0]
    return [(v[a],v[b]) for a in range(4) for b in range(a+1,4)]
def D_of_k(k):
    D=np.zeros((2,6),complex)
    for ti,t in enumerate([(.5,.5,.5),(.5,.5,-.5)]):
        for a,b in bonds_of_tet(t):
            j,r,_=bond_rep(a,b); t1,t2=tets_of_bond(a,b)
            sgn=+1 if np.allclose(t1,t) else -1
            D[ti,j]+=sgn*phase(k,r)
    return D
# served quartets: link (n,o) with n=(0,0,0), o=n+e for e in E3 (6 links per node; each link also belongs to its void, so 3 links per primal site: take the 3 links n->n+e, e in +x,+y,+z ... and the 3 from void o=(1,0,0) to its other ring nodes? simpler: the 6 links at node 0 are all distinct primal links; primal links per FCC cell = 6.)

def A_of_k_B(k):
    rows=[]; n=(0,0,0)
    for e in E3:
        o=tuple(n[i]+e[i] for i in range(3)); axis=[i for i in range(3) if e[i]!=0][0]; others=[i for i in range(3) if i!=axis]
        mid=np.array([(n[i]+o[i])/2 for i in range(3)]); cyc=[]
        for s1,s2 in [(.5,.5),(-.5,.5),(-.5,-.5),(.5,-.5)]:
            c=mid.copy(); c[others[0]]+=s1; c[others[1]]+=s2; cyc.append(tuple(c))
        ring=[tuple(o[i]+d[i] for i in range(3)) for d in E3 if tuple(o[i]+d[i] for i in range(3))!=n and (o[axis]+d[axis])==o[axis]]
        row=np.zeros(6,complex)
        for a in range(4):
            ta,tb=cyc[a],cyc[(a+1)%4]; found=None
            for r in ring:
                t1,t2=tets_of_bond(n,r)
                if np.allclose(t1,ta) and np.allclose(t2,tb): found=(r,+1)
                if np.allclose(t1,tb) and np.allclose(t2,ta): found=(r,-1)
            r,sgn=found; j,rr,_=bond_rep(n,r); row[j]+=sgn*phase(k,rr)
        rows.append(row)
    return np.array(rows)
def bands_B(k):
    D=D_of_k(k); A=A_of_k_B(k); Q,_=np.linalg.qr(D.conj().T); P=np.eye(6)-Q@Q.conj().T
    return np.sort(np.linalg.eigvalsh(P@(A.conj().T@A)@P).real)
print("\n=== Lift B: tetrahedral-void divergence, dual-plaquette ring exchange ===")
for name,kh in [("[100]",(1,0,0)),("[110]",(1,1,0)),("[111]",(1,1,1)),("[210]",(2,1,0)),("[321]",(3,2,1))]:
    kh=np.array(kh,float); kh/=np.linalg.norm(kh); kmag=0.02; w=bands_B(kmag*kh); nz=w[w>1e-10]
    print(f"{name}: omega^2/k^2 = {np.round(nz[:2]/kmag**2,5)}")
