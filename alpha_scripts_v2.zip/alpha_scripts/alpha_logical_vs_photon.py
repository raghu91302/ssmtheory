#!/usr/bin/env python3
"""Logical sector vs <100> photon sector.
Code: qubits on <110> bonds; HZ (nodes x bonds), HX (voids x bonds).  Logical dim k = n - rk HZ - rk HX.
Cubic <100> lattice: sites = nodes+voids, links; d0: sites->links (gradient), div = d0^T; d1: links->plaquettes (curl),
one plaquette per bond.  Physical (Gauss-law) sector = ker(div), dim = links - (sites-1).
Two-path map M: bonds -> links, M[l,b]=1 iff link l lies on one of the two paths of bond b (4 bonds per link).
Questions: rank M; does M kill X-checks (descend to logicals)? is M(code space) inside/onto ker(div)?  what is d1 M?"""
import itertools, numpy as np

def gf2_rank(A):
    A=A.copy()%2; r=0; rows,cols=A.shape
    for c in range(cols):
        piv=np.nonzero(A[r:,c])[0]
        if len(piv)==0: continue
        p=r+piv[0]; A[[r,p]]=A[[p,r]]
        others=np.nonzero(A[:,c])[0]; others=others[others!=r]
        A[others]^=A[r]; r+=1
        if r==rows: break
    return r

def build(N):
    NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
    E3=[(1,0,0),(0,1,0),(0,0,1)]; E6=E3+[(-1,0,0),(0,-1,0),(0,0,-1)]
    m=lambda p: tuple(c%N for c in p); add=lambda p,d: m((p[0]+d[0],p[1]+d[1],p[2]+d[2])); par=lambda p: sum(p)%2
    pts=list(itertools.product(range(N),repeat=3)); nodes=[p for p in pts if par(p)==0]; voids=[p for p in pts if par(p)==1]
    sites=pts; sidx={s:i for i,s in enumerate(sites)}
    bonds=sorted({frozenset((n,add(n,d))) for n in nodes for d in NN},key=lambda e:sorted(e)); bidx={b:i for i,b in enumerate(bonds)}
    links=sorted({frozenset((s,add(s,d))) for s in sites for d in E3},key=lambda e:sorted(e)); lidx={l:i for i,l in enumerate(links)}
    nb,nl,ns=len(bonds),len(links),len(sites)
    HZ=np.zeros((len(nodes),nb),np.uint8); HX=np.zeros((len(voids),nb),np.uint8)
    for i,n in enumerate(nodes):
        for d in NN: HZ[i,bidx[frozenset((n,add(n,d)))]]=1
    for i,o in enumerate(voids):
        ring=[add(o,d) for d in E6]
        for a in ring:
            for b in ring:
                if a<b and frozenset((a,b)) in bidx: HX[i,bidx[frozenset((a,b))]]=1
    d0=np.zeros((nl,ns),np.uint8)             # gradient: link <- its two sites
    for l in links:
        for s in l: d0[lidx[l],sidx[s]]=1
    M=np.zeros((nl,nb),np.uint8); d1=np.zeros((nb,nl),np.uint8)   # plaquette index = bond index
    for b in bonds:
        a,c=tuple(b); dvec=tuple((c[i]-a[i]+N//2)%N-N//2 for i in range(3)); i,j=[k for k in range(3) if dvec[k]!=0]
        di=tuple(dvec[k] if k==i else 0 for k in range(3)); dj=tuple(dvec[k] if k==j else 0 for k in range(3))
        o1,o2=add(a,di),add(a,dj)
        for l in [frozenset((a,o1)),frozenset((o1,c)),frozenset((a,o2)),frozenset((o2,c))]:
            M[lidx[l],bidx[b]]=1; d1[bidx[b],lidx[l]]=1
    return HZ,HX,M,d0,d1,nb,nl,ns

def nullspace_gf2(A):
    """basis of {x : A x = 0} over GF(2)"""
    A=A.copy()%2; rows,cols=A.shape; piv=[]; r=0
    for c in range(cols):
        p=np.nonzero(A[r:,c])[0]
        if len(p)==0: continue
        p=r+p[0]; A[[r,p]]=A[[p,r]]
        others=np.nonzero(A[:,c])[0]; others=others[others!=r]; A[others]^=A[r]; piv.append(c); r+=1
        if r==rows: break
    free=[c for c in range(cols) if c not in piv]; basis=[]
    for f in free:
        v=np.zeros(cols,np.uint8); v[f]=1
        for i,pc in enumerate(piv):
            if A[i,f]: v[pc]=1
        basis.append(v)
    return np.array(basis,np.uint8) if basis else np.zeros((0,cols),np.uint8)

for N in (4,6):
    HZ,HX,M,d0,d1,nb,nl,ns=build(N)
    rZ,rX=gf2_rank(HZ),gf2_rank(HX); k=nb-rZ-rX
    div=d0.T
    print(f"\nN={N}: bonds={nb} links={nl} sites={ns}; k = {k}; ker(div) dim = {nl-gf2_rank(div)}  (= 2N^3+1 = {2*N**3+1})")
    print(f"  rank M = {gf2_rank(M)};  d1 M == 0 ? {not np.any((d1.astype(int)@M.astype(int))%2)}")
    # curl of served sum: (d1 M)[p,b] counts links shared by plaquette p and bond b's paths
    DM=(d1.astype(int)@M.astype(int))%2
    print(f"  d1 M mod 2: nonzero entries per row = {DM.sum(1)[:1]}, equals HZ^T HZ + ...? rank(d1 M)={gf2_rank(DM.astype(np.uint8))}")
    # does M kill X-checks?
    MX=(M.astype(int)@HX.T.astype(int))%2
    print(f"  M(X-check) zero? {not MX.any()}; weight of M(X-check) = {MX[:,0].sum()}")
    # is M(X-check) pure gauge (in image of d0)?  test: div of it is zero (always) and curl d1 of it zero?
    print(f"  d1 M(X-check) zero? {not ((d1.astype(int)@MX)%2).any()}")
    # M restricted to code space ker HZ: dimension of image, and modulo pure gauge im(d0)
    K=nullspace_gf2(HZ)                       # basis of ker HZ (dim = nb - rZ)
    MK=(M.astype(int)@K.T.astype(int))%2      # links x dimK
    print(f"  dim ker HZ = {K.shape[0]};  dim M(ker HZ) = {gf2_rank(MK.T.astype(np.uint8))}")
    # gauge-invariant content: rank of [M K | d0] minus rank d0
    aug=np.concatenate([MK.astype(np.uint8),d0],axis=1)
    gi=gf2_rank(aug.T)-gf2_rank(d0.T)
    print(f"  dim of M(ker HZ) modulo pure gauge im(d0) = {gi}   (physical modes available: {nl-ns+1-0 - 0} incl. harmonic; coexact = {nl-(ns-1)-3})")
    # curl images: does d1 M map ker HZ onto plaquette fluxes?
    print(f"  dim d1 M (ker HZ) = {gf2_rank(((d1.astype(int)@MK)%2).T.astype(np.uint8))}")
    # ker M within code space
    print(f"  dim (ker HZ ∩ ker M) = {K.shape[0]-gf2_rank(MK.T.astype(np.uint8))}")
