#!/usr/bin/env python3
"""Lift B (the photon): Z_M-valued flux s_b on bonds = dual links between tetrahedral voids, oriented t1->t2.
Gauss law: signed divergence at every tetrahedral void = 0.  E on a primal <100> link = oriented sum of s around
the dual plaquette it pierces (the 4 served bonds, with dual-orientation signs).  Sample the zero-divergence
ensemble by annealing, measure <E^2> per link, convert with the Gaussian estimator (calibrated x2.7)."""
import itertools, numpy as np
rng=np.random.default_rng(7); N=6
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
m=lambda p: tuple(c%N for c in p); add=lambda p,d: m((p[0]+d[0],p[1]+d[1],p[2]+d[2])); par=lambda p: sum(p)%2
nodes=[p for p in itertools.product(range(N),repeat=3) if par(p)==0]
edges=sorted({frozenset((n,add(n,d))) for n in nodes for d in NN},key=lambda e:sorted(e)); eidx={e:i for i,e in enumerate(edges)}; ne=len(edges)
# tetrahedral voids in doubled coordinates (odd,odd,odd) mod 2N
tets=[tuple(2*c+1 for c in p) for p in itertools.product(range(N),repeat=3)]; tidx={t:i for i,t in enumerate(tets)}
def tets_of_bond(e):
    a,b=sorted(e); d=tuple((b[i]-a[i]+N//2)%N-N//2 for i in range(3)); z=[i for i in range(3) if d[i]==0][0]
    mid2=[(2*a[i]+d[i]) for i in range(3)]   # doubled coords of midpoint
    t1=list(mid2); t1[z]+=1; t2=list(mid2); t2[z]-=1
    return tuple(x%(2*N) for x in t1), tuple(x%(2*N) for x in t2)
D=np.zeros((len(tets),ne),int)
for e in edges:
    t1,t2=tets_of_bond(e); D[tidx[t1],eidx[e]]+=1; D[tidx[t2],eidx[e]]-=1
edge_tets=[np.nonzero(D[:,i])[0] for i in range(ne)]; edge_sgn=[D[np.nonzero(D[:,i])[0],i] for i in range(ne)]
# served quartets with dual-plaquette orientation signs
quart=[]; qsgn=[]
for n in nodes:
    for e in E3:
        o=add(n,e); axis=[i for i in range(3) if e[i]!=0][0]; others=[i for i in range(3) if i!=axis]
        mid2=[2*n[i]+e[i] for i in range(3)]
        cyc=[]
        for s1,s2 in [(1,1),(-1,1),(-1,-1),(1,-1)]:
            c=list(mid2); c[others[0]]+=s1; c[others[1]]+=s2; cyc.append(tuple(x%(2*N) for x in c))
        ring=[add(o,d) for d in E3 if add(o,d)!=n and d[axis]==0]
        es=[]; ss=[]
        for a in range(4):
            ta,tb=cyc[a],cyc[(a+1)%4]; found=None
            for r in ring:
                b=frozenset((n,r)); t1,t2=tets_of_bond(b)
                if t1==ta and t2==tb: found=(b,+1)
                if t1==tb and t2==ta: found=(b,-1)
            assert found; es.append(eidx[found[0]]); ss.append(found[1])
        quart.append(es); qsgn.append(ss)
quart=np.array(quart); qsgn=np.array(qsgn)
lam=2.388; f=2.7
for M in (2,3,4,5,6):
    levels=np.arange(M)-(M-1)/2
    s=rng.choice(levels,size=ne); Q=D@s
    def sweep(T):
        global s,Q
        for e in rng.permutation(ne):
            new=rng.choice(levels)
            if new==s[e]: continue
            dq=(new-s[e])*edge_sgn[e]; ts=edge_tets[e]; dE=sum((Q[t]+q)**2-Q[t]**2 for t,q in zip(ts,dq))
            if dE<=0 or rng.random()<np.exp(-dE/T): s[e]=new; Q[ts]+=dq
    for T in [4,2,1,0.5,0.25]:
        for _ in range(40): sweep(T)
    E2s=[]
    for _ in range(30):
        sweep(0.25); E2s.append(np.mean((s[quart]*qsgn).sum(1)**2))
    E2=np.mean(E2s); ainv=4*np.pi*3*E2/lam
    print(f"Z_{M}: <Q^2>/tet={np.mean(Q**2):.3f}  <E^2>/link={E2:.3f}  alpha^-1 raw={ainv:6.1f}  calibrated={f*ainv:6.1f}")
print("target 135.5 +- 0.3; calibration +-30%")
