#!/usr/bin/env python3
"""The SSM tick as a unitary and its effective Hamiltonian.
Per tick tau:  U = exp(+i g sum_b cos B_b) * exp(-i eps/2 * sum_l (curl m)_l^2),
  g = J tau/hbar (one radian per bond per tick => g=1),  eps = U tau/hbar = eps_b/E_bond.
H_F = (i hbar/tau) log U.  Fit H_F to -J_eff cos B + (U_eff/2)(curl m)^2 and report U_eff/J_eff vs input eps/g.
Case 1: single rotor, Y = eps/2 m^2 (toy).   Case 2: one served quartet, four rotors, Y = eps/2 (m1+m2-m3-m4)^2.
"""
import numpy as np
from scipy.linalg import logm, expm
M=8                     # |m| <= M truncation
ms=np.arange(-M,M+1); d=len(ms)
# single-rotor operators in the m basis
cosB=np.zeros((d,d)); 
for i in range(d-1): cosB[i,i+1]=cosB[i+1,i]=0.5     # cos B = (e^{iB}+e^{-iB})/2 shifts m by +-1
m2=np.diag(ms.astype(float)**2)
def fit_single(g,eps):
    U=expm(1j*g*cosB)@expm(-1j*eps/2*m2)
    HF=1j*logm(U)                                   # in units of hbar/tau ; H_F = -g_eff cos B + (u_eff/2) m^2 + ...
    # extract u_eff from diagonal curvature, g_eff from nearest-neighbour hopping, central region
    c=M; u_eff=(HF[c+1,c+1]+HF[c-1,c-1]-2*HF[c,c]).real          # second difference of diagonal = u_eff (for (u/2) m^2)
    g_eff=-2*HF[c,c+1].real
    return u_eff,g_eff,HF
print("single rotor: input eps/g -> effective u_eff/g_eff (H_F fit), ratio to input")
for g,eps in [(1.0,0.0087),(1.0,0.05),(1.0,0.2),(0.1,0.0087),(2.0,0.0087)]:
    u,ge,HF=fit_single(g,eps)
    off2=abs(HF[M,M+2]); print(f"  g={g:4.2f} eps={eps:6.4f}:  u_eff={u:.5f} g_eff={ge:.5f}  u_eff/g_eff={u/ge:.5f}  input={eps/g:.5f}  ratio={(u/ge)/(eps/g):.4f}  |m->m+2 term|={off2:.2e}")
# ---- one served quartet: 4 rotors, Y = eps/2 (m1+m2-m3-m4)^2 ----
M4=3; ms4=np.arange(-M4,M4+1); d4=len(ms4)
I=np.eye(d4); c4=np.zeros((d4,d4))
for i in range(d4-1): c4[i,i+1]=c4[i+1,i]=0.5
def kron4(ops): 
    out=ops[0]
    for o in ops[1:]: out=np.kron(out,o)
    return out
mdiag=np.diag(ms4.astype(float))
m_ops=[kron4([mdiag if k==j else I for k in range(4)]) for j in range(4)]
cos_ops=[kron4([c4 if k==j else I for k in range(4)]) for j in range(4)]
E=m_ops[0]+m_ops[1]-m_ops[2]-m_ops[3]
X=sum(cos_ops); Y=E@E
for g,eps in [(1.0,0.0087),(1.0,0.05)]:
    U=expm(1j*g*X)@expm(-1j*eps/2*Y)
    HF=1j*logm(U)
    # project H_F onto the two operator directions: <X,HF>/<X,X>, <Y,HF>/<Y,Y> (Hilbert-Schmidt), after removing identity
    def hs(A,B): return np.trace(A.conj().T@B).real
    Xc=X-np.trace(X)/X.shape[0]*np.eye(X.shape[0]); Yc=Y-np.trace(Y)/Y.shape[0]*np.eye(Y.shape[0])
    HFc=HF-np.trace(HF)/HF.shape[0]*np.eye(HF.shape[0])
    gx=-hs(Xc,HFc)/hs(Xc,Xc); uy=2*hs(Yc,HFc)/hs(Yc,Yc)
    resid=HFc-(-gx*Xc)-(uy/2)*Yc
    print(f"quartet g={g} eps={eps}: g_eff={gx:.5f} u_eff={uy:.5f} u_eff/g_eff={uy/gx:.5f} input {eps/g:.5f} ratio={(uy/gx)/(eps/g):.4f}; residual norm/|H_F| = {np.linalg.norm(resid)/np.linalg.norm(HFc):.3e}")
