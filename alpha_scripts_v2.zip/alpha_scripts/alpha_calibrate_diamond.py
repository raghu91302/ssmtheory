#!/usr/bin/env python3
"""Calibration + candidate test.
(1) Same Gaussian estimator on the diamond lattice (links = pyrochlore spins, plaquettes = hexagons),
    whose spin-1/2 quantum spin ice has QMC/literature alpha ~ 1/10 (Pace et al. PRL 2021).
(2) Cubic <100> lattice again for the same code path.
(3) Candidate: E_link = signed sum of the 4 code qubits the link serves (5 levels, S=2)."""
import numpy as np, itertools
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import svds
from numpy.linalg import svd

def gaussian_alpha(curl, n_links, E2):
    """curl: dense (plaquettes x links) incidence matrix with signs. Returns alpha^-1 for given <E^2>."""
    s = svd(curl, compute_uv=False)
    s = s[s > 1e-9]
    lam_per_link = s.sum()/2/n_links          # <E^2> = sqrt(K/U) * this
    sqrtKU = E2/lam_per_link
    return 4*np.pi*sqrtKU, lam_per_link

# ---------- cubic <100> lattice ----------
def cubic(L):
    sites = list(itertools.product(range(L), repeat=3)); idx = {s:i for i,s in enumerate(sites)}
    m = lambda p: tuple(c%L for c in p)
    E3 = [(1,0,0),(0,1,0),(0,0,1)]
    links = {}; 
    for s in sites:
        for d in E3: links[(s,d)] = len(links)
    plaq = []
    for s in sites:
        for i,j in [(0,1),(0,2),(1,2)]:
            di,dj = E3[i],E3[j]
            s1 = m(tuple(s[k]+di[k] for k in range(3))); s2 = m(tuple(s[k]+dj[k] for k in range(3)))
            plaq.append([(links[(s,di)],+1),(links[(s1,dj)],+1),(links[(s2,di)],-1),(links[(s,dj)],-1)])
    C = np.zeros((len(plaq), len(links)))
    for p,ls in enumerate(plaq):
        for l,sg in ls: C[p,l] = sg
    return C, len(links)

# ---------- diamond lattice (pyrochlore spins on its links) ----------
def diamond(L):
    a = [np.array(v) for v in [(0,.5,.5),(.5,0,.5),(.5,.5,0)]]
    cells = list(itertools.product(range(L), repeat=3)); cidx = {c:i for i,c in enumerate(cells)}
    m = lambda c: tuple(x%L for x in c)
    # A site in cell c; B site in cell c. Links A(c) -> B(c - t) for t in {0, e1, e2, e3} (cell offsets)
    offs = [(0,0,0),(1,0,0),(0,1,0),(0,0,1)]
    nodes = {}
    for c in cells:
        nodes[('A',c)] = len(nodes); nodes[('B',c)] = len(nodes)
    links = {}; adj = {n:[] for n in nodes}
    for c in cells:
        for t in offs:
            b = m(tuple(c[k]-t[k] for k in range(3)))
            l = len(links); links[(c,t)] = l
            adj[('A',c)].append((('B',b), l, +1)); adj[('B',b)].append((('A',c), l, -1))
    # enumerate hexagons (simple 6-cycles) by DFS from each node, dedupe by link set
    hexes = {}
    for start in nodes:
        stack = [(start, [start], [])]
        while stack:
            node, path, lp = stack.pop()
            if len(path) == 6:
                for nb, l, sg in adj[node]:
                    if nb == start and l not in [x[0] for x in lp]:
                        cyc = lp + [(l, sg)]
                        key = frozenset(x[0] for x in cyc)
                        if len(key) == 6: hexes.setdefault(key, cyc)
                continue
            for nb, l, sg in adj[node]:
                if nb not in path and l not in [x[0] for x in lp]:
                    stack.append((nb, path+[nb], lp+[(l,sg)]))
    C = np.zeros((len(hexes), len(links)))
    for p,cyc in enumerate(hexes.values()):
        for l,sg in cyc: C[p,l] = sg
    return C, len(links), len(hexes)

L = 6
Cc, nl_c = cubic(L)
Cd, nl_d, nh = diamond(L)
print(f"cubic L={L}: {nl_c} links, {Cc.shape[0]} plaquettes")
print(f"diamond L={L}: {nl_d} links, {nh} hexagons ({nh/(L**3):.1f} per cell; expect 4)")

ainv_c, lam_c = gaussian_alpha(Cc, nl_c, 0.25)
ainv_d, lam_d = gaussian_alpha(Cd, nl_d, 0.25)
print(f"\nspin-1/2 Gaussian estimate:  cubic alpha^-1 = {ainv_c:.2f}   diamond (QSI) alpha^-1 = {ainv_d:.2f}")
print(f"literature QSI (QMC, Pace et al.): alpha^-1 ~ 10   -> calibration factor f = {10/ainv_d:.2f} on alpha^-1")
f = 10/ainv_d

print("\n--- cubic <100> sector, calibrated ---")
target = 104.86
for label, E2 in [("qubit link", 0.25), ("4-qubit sum, uncorrelated (<E^2>=1)", 1.0),
                  ("4-qubit sum, hard cap S^2=4", 4.0), ("target", None)]:
    if E2 is None:
        E2_needed = target/f/(4*np.pi)*lam_c
        print(f"  target 104.9 needs <E^2> = {E2_needed:.2f}  (raw Gaussian: {target/(4*np.pi)*lam_c:.2f})")
        print(f"     hard cap S^2:        S >= {np.sqrt(E2_needed):.2f}  -> >= {int(np.ceil(2*np.sqrt(E2_needed)+1))} states")
        Sg = (-1+np.sqrt(1+12*E2_needed))/2
        print(f"     Gaussian S(S+1)/3:   S >= {Sg:.2f}  -> >= {int(np.ceil(2*Sg+1))} states")
        continue
    ainv, _ = gaussian_alpha(Cc, nl_c, E2)
    print(f"  {label:40s} alpha^-1 raw {ainv:6.1f}   calibrated {ainv*f:6.1f}")
