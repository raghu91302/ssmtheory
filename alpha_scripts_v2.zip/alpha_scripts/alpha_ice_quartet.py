#!/usr/bin/env python3
"""Ice-state test of the 4-qubit link variable.
s_e = +-1 on the 3L^3 code edges.  U(1) Gauss law: sum of the 12 s_e at every node and every void = 0.
Sample with H = sum_nodes Q_n^2 + sum_voids Q_o^2 (Q = sum of the 12 s_e), annealed Metropolis,
then measure, for each <100> link, the 4 code edges it serves:
   E_link = (1/2) sum_{4} s_e ,  <E^2> = (4 + 12 c)/4  with c = mean pairwise <s_i s_j> in the quartet.
Target from calibration: <E^2> = 2.45  ->  c = +0.48.  Constraint-only expectation: c < 0."""
import itertools, numpy as np
rng = np.random.default_rng(1)
L = 6
NN = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E3 = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
m = lambda p: tuple(c%L for c in p); add = lambda p,d: m((p[0]+d[0],p[1]+d[1],p[2]+d[2])); par = lambda p: sum(p)%2
nodes = [p for p in itertools.product(range(L),repeat=3) if par(p)==0]
voids = [p for p in itertools.product(range(L),repeat=3) if par(p)==1]
edges = sorted({frozenset((n,add(n,d))) for n in nodes for d in NN}, key=lambda e: sorted(e))
eidx = {e:i for i,e in enumerate(edges)}; ne = len(edges)
chk = []                      # list of edge-index arrays, one per node and per void
for n in nodes: chk.append(np.array([eidx[frozenset((n,add(n,d)))] for d in NN]))
for o in voids:
    ring = [add(o,d) for d in E3]
    chk.append(np.array([eidx[frozenset((a,b))] for a in ring for b in ring if frozenset((a,b)) in eidx and a<b]))
chk = np.array(chk); assert chk.shape[1]==12
edge_chk = [[] for _ in range(ne)]
for c,es in enumerate(chk):
    for e in es: edge_chk[e].append(c)
edge_chk = np.array(edge_chk); assert edge_chk.shape[1]==4

# quartets: for each <100> link (n,o): the 4 code edges from n to o's other ring nodes
quartets = []
for n in nodes:
    for d in E3:
        o = add(n,d)
        q = [eidx[frozenset((n,nb))] for nb in (add(o,dd) for dd in E3) if nb!=n and frozenset((n,nb)) in eidx]
        assert len(q)==4; quartets.append(q)
quartets = np.array(quartets)
pairs = [(i,j) for i in range(4) for j in range(i+1,4)]

s = rng.choice([-1,1], size=ne)
Q = np.array([s[es].sum() for es in chk])
def sweep(T):
    global s,Q
    for e in rng.permutation(ne):
        cs = edge_chk[e]; dQ = -2*s[e]
        dE = sum((Q[c]+dQ)**2 - Q[c]**2 for c in cs)
        if dE <= 0 or rng.random() < np.exp(-dE/T):
            s[e] = -s[e]; Q[cs] += dQ

def measure():
    sq = s[quartets]
    c = np.mean([np.mean(sq[:,i]*sq[:,j]) for i,j in pairs])
    E2 = np.mean((0.5*sq.sum(1))**2)
    # also: same-node pair correlation and same-void pair correlation for reference
    return c, E2, np.mean(Q**2)

print(f"L={L}: {ne} edges, {len(chk)} checks, {len(quartets)} links")
for T in [4,2,1,0.5,0.25,0.12,0.06]:
    for _ in range(60): sweep(T)
    cs, E2s, Qs = [], [], []
    for _ in range(40):
        sweep(T); c,E2,q2 = measure(); cs.append(c); E2s.append(E2); Qs.append(q2)
    print(f"  T={T:<5} <Q^2>/check={np.mean(Qs):6.3f}   quartet c={np.mean(cs):+.4f}   <E_link^2>={np.mean(E2s):.3f}"
          f"   -> calibrated alpha^-1 ~ {42.9*np.mean(E2s):5.1f}")
print("\ntarget: c=+0.48, <E^2>=2.45, alpha^-1=104.9")
