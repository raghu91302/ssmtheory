#!/usr/bin/env python3
"""alpha_em^-1 at mu = hbar c / L_f, SM two-loop gauge running with top Yukawa (MS-bar).
Inputs at mu = m_t (Buttazzo et al. 2013 central values, GUT-normalised g1)."""
import numpy as np
from scipy.integrate import solve_ivp

mt = 173.34
g1, g2, g3, yt = 0.4626, 0.6478, 1.1666, 0.9369   # at mu = m_t
b  = np.array([41/10, -19/6, -7.0])
B  = np.array([[199/50, 27/10, 44/5],[9/10, 35/6, 12.0],[11/10, 9/2, -26.0]])
C  = np.array([17/10, 3/2, 2.0])
k  = 1/(16*np.pi**2)

def rhs(t, y, loops):
    g = y[:3]; yt = y[3]
    dg = k*g**3*b
    if loops == 2:
        dg += k*g**3*k*(B@(g**2) - C*yt**2)
    dyt = k*yt*(4.5*yt**2 - (17/20)*g[0]**2 - (9/4)*g[1]**2 - 8*g[2]**2)
    return np.concatenate([dg, [dyt]])

def alpha_em_inv(g):
    return 4*np.pi*(1/g[1]**2 + (5/3)/g[0]**2)

hbarc = 0.1973269804   # GeV fm
lP = 1.616255e-20      # fm
targets = {"L_f = 1.843 l_P (G_N, bond calib.)": 1.843*lP,
           "L_f = 1.665 l_P (plaquette calib.)": 1.665*lP,
           "L_c = 0.84 fm":  0.84,
           "10^16 GeV": hbarc/1e16}
print(f"alpha_em^-1(m_t) = {alpha_em_inv([g1,g2,g3]):.2f}")
for loops in (1, 2):
    print(f"\n{loops}-loop:")
    for label, L in targets.items():
        mu = hbarc/L
        if mu < mt:   # below m_t just report the low-scale value from data
            print(f"  {label:38s} mu={mu:9.3g} GeV  (below m_t: use data, ~135.1)"); continue
        sol = solve_ivp(rhs, [np.log(mt), np.log(mu)], [g1,g2,g3,yt], args=(loops,), rtol=1e-9, atol=1e-12)
        g = sol.y[:3,-1]
        print(f"  {label:38s} mu={mu:9.3g} GeV  alpha_em^-1 = {alpha_em_inv(g):7.2f}   (alpha_s^-1={4*np.pi/g[2]**2:5.1f})")

# sensitivity: +-1 sigma on alpha_s(MZ) (~0.0009) and alpha_em(MZ), roughly via g3, g1,g2 shifts
print("\nsensitivity at 6.6e18 GeV (2-loop):")
mu = hbarc/(1.843*lP)
for lab, y0 in [("g3 +1%", [g1,g2,g3*1.01,yt]), ("g1,g2 +0.1%", [g1*1.001,g2*1.001,g3,yt]), ("yt +1%", [g1,g2,g3,yt*1.01])]:
    sol = solve_ivp(rhs, [np.log(mt), np.log(mu)], y0, args=(2,), rtol=1e-9, atol=1e-12)
    print(f"  {lab:14s} alpha_em^-1 = {alpha_em_inv(sol.y[:3,-1]):7.2f}")
