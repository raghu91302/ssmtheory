#!/usr/bin/env python3
"""Elastic carrier test.
Harmonic FCC lattice: nodes of mass m, nearest-neighbour central springs kappa, spacing a=1 (cubic cell).
Void o = centroid of its 6 ring nodes.  <100> link 1-form from a vector field v on nodes:
    A_{n->o} = (v_o - v_n).d  with v_o = mean of ring,  for o = n + d,  d in {+-x,+-y,+-z}.
A := projection of displacement u (potential sector), E := projection of momentum p (kinetic sector).
B_p := lattice curl of A on the cubic plaquettes (each = one <110> bond's two paths).
For a phonon eigenmode (k, branch): potential energy = (1/2) m omega^2 |u|^2 (virial), kinetic same.
Effective Maxwell stiffnesses per mode:
    K_eff(k,b) = m omega^2 |u|^2 / |B|^2        (energy = (K/2) sum B^2)
    U_eff(k,b) = (1/m) |p|^2 / |E|^2 = (1/m) |u|^2/|A|^2   (same projection for p and u)
Photon test: as k->0, K_eff and U_eff should be finite and independent of direction/branch for the
transverse-A sector.  sqrt(U/K) then scales as 1/sqrt(m kappa) = Lambda (de Boer-type parameter)."""
import numpy as np, itertools
m = kappa = 1.0
NN = np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)])/2.0
ehat = NN/np.linalg.norm(NN,axis=1)[:,None]
D6 = np.array([(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)])*0.5   # node->void half-spacing offsets
def dyn(k):
    D = np.zeros((3,3),complex)
    for d,e in zip(NN,ehat): D += kappa*np.outer(e,e)*(1-np.exp(1j*k@d))
    return D
def link_form(k, v):
    """v: 3-vector amplitude on nodes (plane wave).  Returns the 6 link values at a reference node n=0."""
    c = np.mean([np.exp(1j*k@r) for r in D6])           # ring average relative to void centre  (ring = void +- half offsets)
    A = np.zeros(6,complex)
    for i,d in enumerate(D6):
        dhat = d/np.linalg.norm(d)
        v_o = c*np.exp(1j*k@d)*v                          # centroid field at void o = n + d
        A[i] = (v_o - v)@dhat
    return A
def curl_form(k, A):
    """plaquette flux for the 3 plaquettes at node n=0 (xy, xz, yz), using links from n and translated links."""
    # links: index 0..2 = n->n+d (d=x,y,z), 3..5 = n->n-d.  Plaquette (i,j): n -> n+d_i -> n+d_i+d_j -> n+d_j -> n
    B = []
    for i,j in [(0,1),(0,2),(1,2)]:
        di,dj = D6[i],D6[j]
        # A on link (n+d_i -> n+d_i+d_j): that link starts at a *void*; the 1-form on void->node link (o -> n') equals
        # -(A on n'->o) with n' = n+d_i+d_j, o = n+d_i:  n' -> o is direction -d_j from n', index j+3, phase e^{ik.(d_i+d_j)}
        a1 = A[i]
        a2 = -A[j+3]*np.exp(1j*k@(di+dj))
        a3 = -A[i]*np.exp(1j*k@dj)              # link (n+d_i+d_j -> n+d_j) = -(n+d_j -> n+d_j+d_i): index i at node n+d_j
        a4 = -A[j]                              # link (n+d_j -> n) = -(n -> n+d_j)
        B.append(a1+a2+a3+a4)
    return np.array(B)

print("direction   branch   omega/k   K_eff/kappa   U_eff*m   sqrt(U/K)*sqrt(m kappa)   |B|/|A|")
dirs = {"[100]":(1,0,0),"[110]":(1,1,0),"[111]":(1,1,1),"[210]":(2,1,0)}
res = {}
for name,dv in dirs.items():
    khat = np.array(dv,float); khat/=np.linalg.norm(khat)
    for kmag in [0.05, 0.02]:
        k = kmag*khat
        w2,V = np.linalg.eigh(dyn(k))
        for b in range(3):
            u = V[:,b]; om = np.sqrt(max(w2[b],0))
            A = link_form(k,u); B = curl_form(k,A)
            nA2 = np.vdot(A,A).real; nB2 = np.vdot(B,B).real
            if nB2 < 1e-14: continue
            Keff = m*om**2*1.0/nB2            # |u|^2 = 1
            Ueff = (1/m)*1.0/nA2
            pol = "L" if abs(u@khat)>0.9 else ("T" if abs(u@khat)<0.1 else "mixed")
            if kmag==0.02:
                print(f"  {name:6s}  {b}({pol:5s})  {om/kmag:7.4f}   {Keff:10.4f}   {Ueff:8.4f}   {np.sqrt(Ueff/Keff):10.4f}        {np.sqrt(nB2/nA2):.4f}")
                res.setdefault(pol,[]).append(np.sqrt(Ueff/Keff))
print("\nspread of sqrt(U/K) over transverse modes/directions:", np.min(res.get('T',[np.nan])), np.max(res.get('T',[np.nan])))
