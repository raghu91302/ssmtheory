#!/usr/bin/env python3
"""Monopole self-energy of the <100> rotor sector at weak coupling.
H = (U/2) sum E^2 - J sum cos B.  A unit magnetic charge (div B = 2 pi on the dual lattice) has
Coulomb-phase energy E_m = (J/2)(2 pi)^2 v(0), v(0) = int d^3k/(2pi)^3 / sum_i 4 sin^2(k_i/2),
the cubic-lattice self-energy constant.  Numbers for the confinement code: J = hbar c / 4 L_c."""
import numpy as np
for N in (64,128,256):
    k=2*np.pi*(np.arange(N)+0.5)/N          # half-shifted grid avoids k=0
    kx,ky,kz=np.meshgrid(k,k,k,indexing='ij')
    lam2=4*np.sin(kx/2)**2+4*np.sin(ky/2)**2+4*np.sin(kz/2)**2
    v0=np.mean(1/lam2); print(f"N={N}: v(0)={v0:.5f}")
coef=2*np.pi**2*v0
hbarc=197.327; Lc=0.8409; J=hbarc/(4*Lc); U=0.511; beta=np.sqrt(J/U)
Em=coef*J
print(f"\nE_m = 2 pi^2 v(0) J = {coef:.3f} J")
print(f"confinement code: J = {J:.1f} MeV, beta = {beta:.2f}, E_m = {Em:.0f} MeV = {Em/U:.0f} eps_b")
print(f"for comparison: m_pi = 140 MeV, sqrt(sigma) = 440 MeV, Lambda_QCD ~ 200-300 MeV, hbar c/L_c = {hbarc/Lc:.0f} MeV")
print(f"E_m in units of hbar c / L_c: {Em/(hbarc/Lc):.3f}  (= 2 pi^2 v(0)/4 = {coef/4:.3f})")
