#!/usr/bin/env python3
"""Regenerates all four figures of the paper: fig_alpha_Lc.pdf, fig_defect_bonds.pdf, fig_dispersions.pdf, fig_quantum.pdf.
Figure 3 recomputes the Bloch dispersions of the two U(1) lifts (see alpha_liftA_liftB.py for the derivation)."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt

# ---------------- Figure 1 ----------------
lam=386.159; L=np.linspace(0.70,1.05,300); a=2*np.pi*np.sqrt(lam/L)
fig,ax=plt.subplots(figsize=(5.2,3.6))
ax.plot(L,a,'k-',lw=1.6,label=r'$\alpha^{-1}=2\pi\sqrt{\bar\lambda_e/L_c}$')
ax.axvspan(0.80,0.96,color='0.9',label=r'model band for $L_c$')
ax.axhspan(135.2,135.8,color='tab:blue',alpha=0.25,label=r'$\alpha^{-1}(\hbar c/L_c)=135.5\pm0.3$')
ax.axvline(0.8409,color='tab:red',ls='--',lw=1.2,label=r'$r_p=0.8409$ fm')
ax.set_xlabel(r'$L_c$ (fm)'); ax.set_ylabel(r'$\alpha^{-1}$'); ax.set_ylim(122,142); ax.legend(fontsize=8,loc='upper right'); ax.grid(alpha=.3)
plt.tight_layout(); plt.savefig('fig_alpha_Lc.pdf'); plt.close()

# ---------------- Figure 2: trapped-node defect ----------------
A=np.array([0,0,0.]); B=np.array([1,1,0.]); C=np.array([1,0,1.]); D=np.array([0,1,1.]); T=(A+B+C+D)/4; P={'A':A,'B':B,'C':C,'D':D}
proj=lambda p: np.array([p[0]+0.45*p[2], p[1]+0.35*p[2]])
fig,ax=plt.subplots(figsize=(5.6,4.6)); ax.set_aspect('equal'); ax.axis('off')
for u,v in [('A','B'),('A','C'),('A','D'),('B','C'),('B','D'),('C','D')]:
    p,q=proj(P[u]),proj(P[v]); ax.plot([p[0],q[0]],[p[1],q[1]],color='0.35',lw=2,zorder=1)
for k in P:
    p,q=proj(P[k]),proj(T); ax.plot([p[0],q[0]],[p[1],q[1]],color='tab:orange',lw=2,zorder=1)
for k in P:
    for other in list(P)+['T']:
        if other==k: continue
        q=T if other=='T' else P[other]; s=proj(P[k])+0.16*(proj(q)-proj(P[k]))
        ax.plot(s[0],s[1],marker='o',ms=6,color='tab:red' if other!='T' else 'tab:orange',mec='k',mew=0.6,zorder=3)
for k in P:
    p=proj(P[k]); ax.plot(p[0],p[1],'o',ms=13,color='tab:blue',mec='k',zorder=4); ax.text(p[0]+0.05,p[1]+0.05,k,fontsize=12)
p=proj(T); ax.plot(p[0],p[1],'*',ms=17,color='gold',mec='k',zorder=5); ax.text(p[0]+0.05,p[1]-0.09,'trapped node',fontsize=9)
for y,s in [(-0.16,"6 tetrahedron edges (grey)  +  4 spokes (orange)  =  10 distinct bonds"),
            (-0.24,"bond-ends at the four corners: 4 corners × (3 edge-ends + 1 spoke-end) = 16 (markers)"),
            (-0.32,"bond-ends in all: 16 + 4 at the trapped node = 20")]:
    ax.text(0.02,y,s,fontsize=9,transform=ax.transAxes)
plt.subplots_adjust(bottom=0.28); plt.savefig('fig_defect_bonds.pdf',bbox_inches='tight'); plt.close()

# ---------------- Figure 3: dispersions of the two lifts ----------------
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
reps=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
def bond_rep(a,b):
    d=tuple(b[i]-a[i] for i in range(3))
    if d in reps: return reps.index(d),a
    dn=tuple(-x for x in d); return reps.index(dn),b
phase=lambda k,r: np.exp(1j*np.dot(k,r))
def verts(t): return [tuple(int(t[i]+s[i]) for i in range(3)) for s in itertools.product([.5,-.5],repeat=3) if sum(int(t[i]+s[i]) for i in range(3))%2==0]
def cycle_rows(k):
    rows=[]
    for t in [(.5,.5,.5),(.5,.5,-.5)]:
        v=verts(t); pairs=[(a,b) for a in range(4) for b in range(a+1,4)]
        for skew in [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]:
            cyc=[p for p in pairs if p not in skew]; adj={i:[] for i in range(4)}
            for a,b in cyc: adj[a].append(b); adj[b].append(a)
            order=[0]; prev=None
            while len(order)<4:
                nxt=[x for x in adj[order[-1]] if x!=prev and x not in order][0]; prev=order[-1]; order.append(nxt)
            row=np.zeros(6,complex)
            for i in range(4):
                a,b=v[order[i]],v[order[(i+1)%4]]; j,r=bond_rep(a,b); row[j]+=(1 if i%2==0 else -1)*phase(k,r)
            rows.append(row)
    return np.array(rows)
def C_of_k(k):   # lift A: cube-edge sums at node 0 and void (1,0,0)
    C=np.zeros((2,6),complex); n=(0,0,0)
    for d in NN:
        b=tuple(n[i]+d[i] for i in range(3)); i,r=bond_rep(n,b); C[0,i]+=phase(k,r)
    o=(1,0,0); ring=[tuple(o[i]+d[i] for i in range(3)) for d in E3]
    for a in ring:
        for b in ring:
            if a<b and sum(abs(b[i]-a[i]) for i in range(3))==2 and max(abs(b[i]-a[i]) for i in range(3))==1:
                i,r=bond_rep(a,b); C[1,i]+=phase(k,r)
    return C
def tets_of_bond(a,b):
    mid=np.array([(a[i]+b[i])/2 for i in range(3)]); d=np.array(b)-np.array(a); z=[i for i in range(3) if d[i]==0][0]; e=np.zeros(3); e[z]=.5
    return tuple(mid+e),tuple(mid-e)
def D_of_k(k):   # lift B: signed divergence at the two tetrahedra of the cell
    D=np.zeros((2,6),complex)
    for ti,t in enumerate([(.5,.5,.5),(.5,.5,-.5)]):
        v=verts(t)
        for a in range(4):
            for b in range(a+1,4):
                j,r=bond_rep(v[a],v[b]); t1,t2=tets_of_bond(v[a],v[b]); D[ti,j]+=(+1 if np.allclose(t1,t) else -1)*phase(k,r)
    return D
def quartet_rows(k):
    rows=[]; n=(0,0,0)
    for e in E3:
        o=tuple(n[i]+e[i] for i in range(3)); axis=[i for i in range(3) if e[i]!=0][0]; others=[i for i in range(3) if i!=axis]
        mid=np.array([(n[i]+o[i])/2 for i in range(3)]); cyc=[]
        for s1,s2 in [(.5,.5),(-.5,.5),(-.5,-.5),(.5,-.5)]:
            c=mid.copy(); c[others[0]]+=s1; c[others[1]]+=s2; cyc.append(tuple(c))
        ring=[tuple(o[i]+d[i] for i in range(3)) for d in E3 if tuple(o[i]+d[i] for i in range(3))!=n and d[axis]==0]
        row=np.zeros(6,complex)
        for a in range(4):
            ta,tb=cyc[a],cyc[(a+1)%4]; found=None
            for r in ring:
                t1,t2=tets_of_bond(n,r)
                if np.allclose(t1,ta) and np.allclose(t2,tb): found=(r,+1)
                if np.allclose(t1,tb) and np.allclose(t2,ta): found=(r,-1)
            r,sgn=found; j,rr=bond_rep(n,r); row[j]+=sgn*phase(k,rr)
        rows.append(row)
    return np.array(rows)
def bands(k,Cfun,Afun):
    C=Cfun(k); A=Afun(k); Q,_=np.linalg.qr(C.conj().T); Pm=np.eye(6)-Q@Q.conj().T
    return np.sort(np.linalg.eigvalsh(Pm@(A.conj().T@A)@Pm).real)
dirs={'[100]':(1,0,0),'[110]':(1,1,0),'[111]':(1,1,1)}; cols={'[100]':'tab:blue','[110]':'tab:orange','[111]':'tab:green'}
fig,axs=plt.subplots(1,2,figsize=(8.2,3.4),sharey=True); kk=np.linspace(0.02,1.2,40)
for ax,(lab,Cf,Af) in zip(axs,[('Lift A: cube-edge (check) Gauss law',C_of_k,cycle_rows),('Lift B: tetrahedral-void divergence',D_of_k,quartet_rows)]):
    for name,dv in dirs.items():
        kh=np.array(dv,float); kh/=np.linalg.norm(kh); w=np.array([bands(k*kh,Cf,Af) for k in kk]); phys=w[:,2:4]
        for j in range(2): ax.plot(kk,np.sqrt(np.maximum(phys[:,j],0)),color=cols[name],ls='-' if j==0 else '--',label=name if j==0 else None)
    ax.plot(kk,kk,'k:',lw=1,label=r'$\omega=k$ (Maxwell)'); ax.set_title(lab,fontsize=10); ax.set_xlabel(r'$|k|$ (units of $1/a$)'); ax.grid(alpha=.3)
axs[0].set_ylabel(r'$\omega/\sqrt{UJ}$'); axs[0].legend(fontsize=8,loc='upper left'); axs[0].set_ylim(0,1.6)
plt.tight_layout(); plt.savefig('fig_dispersions.pdf'); plt.close()

# ---------------- Figure 4: quantum results ----------------
fig,ax=plt.subplots(figsize=(5.4,3.6))
ax.errorbar([2,6],[5.1,7.0],yerr=[0,2.0],fmt='s-',color='tab:blue',label='spin-1/2 QLM (ED L=2; PMC L=6)')
ax.errorbar([2,6,8],[12.5,14.2,20],yerr=[0,0.7,6],fmt='o-',color='tab:orange',label='spin-1 QLM (ED L=2; PMC L=6,8)')
ax.errorbar([4],[134],yerr=[[2],[2]],fmt='D',color='tab:green',ms=8,label=r'explicit $U/J=(4\pi\alpha)^2$, spin-6 (PMC L=4, two axes)')
ax.axhline(135.5,color='tab:red',ls='--',lw=1.2,label=r'observed $\alpha^{-1}(0.235\,{\rm GeV})=135.5$')
ax.set_yscale('log'); ax.set_xlabel(r'linear size $L$'); ax.set_ylabel(r'$\alpha^{-1}=4\pi\sqrt{J_{\rm eff}/U_{\rm eff}}$'); ax.set_xticks([2,4,6,8]); ax.legend(fontsize=7.5,loc='center right'); ax.grid(alpha=.3,which='both')
plt.tight_layout(); plt.savefig('fig_quantum.pdf'); plt.close()
print("wrote fig_alpha_Lc.pdf fig_defect_bonds.pdf fig_dispersions.pdf fig_quantum.pdf")
# ---------------- Figure 5: the derivation chain ----------------
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
fig,ax=plt.subplots(figsize=(8.6,9.4)); ax.set_xlim(0,10); ax.set_ylim(0,13.2); ax.axis('off')
def box(x,y,w,h,text,fc='white',ec='k',fs=8.6,lw=1.2):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle="round,pad=0.02,rounding_size=0.12",fc=fc,ec=ec,lw=lw)); ax.text(x,y,text,ha='center',va='center',fontsize=fs,linespacing=1.35)
def arrow(x1,y1,x2,y2,ls='-'): ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=14,lw=1.2,color='k',linestyle=ls))
G='#e8f0e8'; Y='#fff3d6'; B='#e6eef8'; R='#f8e6e6'
box(5,12.5,7.2,0.9,"FCC lattice, $D_4$ slice; $[[3N^3,2N^3+2,3]]$ CSS code\n$K=12$, $K/d=4$, tetrahedral voids as dual sites",fc=G); arrow(5,12.05,5,11.45)
box(5,11.0,7.2,0.9,"Mass as verification count (Ref. [2]): external two-step paths\n$(K{+}1)K^2-c_{\\rm skew}K=1836$;  $m_pc^2=1836\\,\\epsilon_b$, $\\epsilon_b=m_ec^2$",fc=G); arrow(5,10.55,5,9.95)
box(5,9.5,7.2,0.9,"Trapped-node defect (Ref. [3], Fig. 2): internal two-step paths\n$4\\times3+4=16$;  kinematic cost $16\\,E_{\\rm bond}=4\\hbar c/L_c$",fc=G)
box(1.55,8.1,2.7,1.15,"Axioms (P2),(P3): one quantum\nper node per tick (transmission);\none bit per standing bond\n(energy). Coefficients derived\nin Sec. 8.8, not fitted.",fc=Y,ec='#b8860b'); arrow(2.9,8.1,3.55,8.1); arrow(2.2,8.7,3.6,9.3); arrow(5,9.05,5,8.55)
box(5.6,8.1,4.0,0.9,"Stability window, kinematic form (Sec. 8.10):\n$1836\\,\\epsilon_b=16\\,E_{\\rm bond}$",fc=G); arrow(4.0,7.65,2.6,6.85); arrow(7.2,7.65,7.4,6.85)
box(2.6,6.35,4.4,1.0,"Proton charge radius as output\n$L_c=4\\bar\\lambda_e/1836=0.8413$ fm\n(0.05% muonic; 0.06% CODATA 2022)",fc=B)
box(7.4,6.35,4.4,1.0,"Rotor stiffnesses (Sec. 8.7): $U=\\epsilon_b$, $J=\\hbar c/4L_c$\nKogut–Susskind $\\alpha=\\sqrt{U/J}/4\\pi$ (MC check, Sec. 8.6;\ntick undressed, Sec. 8.7)",fc=G); arrow(7.4,5.85,7.4,5.25); arrow(4.8,6.0,5.2,5.05)
ax.text(4.55,5.45,"Eq. (9):\n$\\alpha^{-1}=2\\pi\\sqrt{\\bar\\lambda_e/L_c}$\n$L_c=r_p\\Rightarrow134.65$",fontsize=7.4,ha='right',va='center',color='0.25')
box(7.4,4.75,4.4,1.0,"Confinement-scale coupling\n$\\alpha^{-1}=4\\pi\\sqrt{E_{\\rm bond}/\\epsilon_b}=\\pi\\sqrt{m_p/m_e}=134.6$\n(0.6% vs running value $135.5\\pm0.3$)",fc=B); arrow(7.4,4.25,7.4,3.65)
box(7.4,3.15,4.4,0.9,"Standard Model vacuum polarization\n(leptonic + hadronic), $0.235$ GeV $\\to0$",fc=R,ec='#a04040'); arrow(7.4,2.7,7.4,2.1)
box(7.4,1.6,4.4,0.9,"Low-energy fine-structure constant\n$\\alpha(0)^{-1}=137.036$",fc=B)
box(2.6,2.6,4.4,1.9,"Not derived (ledger, Sec. 10):\nthe axioms (P1)-(P5) themselves;\nthe rotor premise (A3);\nthe two-code reading (A1)-(A2);\nthe matching map on the fine code",fc=R,ec='#a04040',fs=7.8); arrow(1.55,7.5,1.55,3.6,ls='--')
plt.savefig('fig_chain.pdf',bbox_inches='tight'); plt.close()
print("wrote fig_chain.pdf")

