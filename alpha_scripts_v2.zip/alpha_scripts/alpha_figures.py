#!/usr/bin/env python3
"""Regenerates all four figures of the paper: fig_alpha_Lc.pdf, fig_defect_bonds.pdf, fig_dispersions.pdf, fig_quantum.pdf.
Figure 3 recomputes the Bloch dispersions of the two U(1) lifts (see alpha_liftA_liftB.py for the derivation)."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt

# ---------------- Figure 1 ----------------
lam=386.159; L=np.linspace(0.70,1.05,300); a=2*np.pi*np.sqrt(lam/L)
fig,ax=plt.subplots(figsize=(5.2,3.6))
ax.plot(L,a,'k-',lw=1.6,label=r'$\alpha^{-1}=2\pi\sqrt{\bar\lambda_e/L_c}$')
ax.axvspan(0.80,0.96,color='0.9',label=r'model band for $L_c$')
ax.axhspan(135.2,135.8,color='tab:blue',alpha=0.25,label=r'$\alpha^{-1}(\hbar c/L_c)=135.5\pm0.3$')
ax.axvline(0.8409,color='tab:red',ls='--',lw=1.2,label=r'$r_p=0.8409$ fm')
ax.plot([0.8413],[2*np.pi*np.sqrt(lam/0.8413)],'o',ms=7,color='k',zorder=5,
        label=r'derived: $L_c=4\bar\lambda_e/1836$, $\alpha^{-1}=\pi\sqrt{m_p/m_e}$')
ax.set_xlabel(r'$L_c$ (fm)'); ax.set_ylabel(r'$\alpha^{-1}$'); ax.set_ylim(122,142); ax.legend(fontsize=7.5,loc='upper right'); ax.grid(alpha=.3)
plt.tight_layout(); plt.savefig('fig_alpha_Lc.pdf'); plt.close()

# ---------------- Figure 2: trapped-node defect ----------------
A=np.array([0,0,0.]); B=np.array([1,1,0.]); C=np.array([1,0,1.]); D=np.array([0,1,1.]); T=(A+B+C+D)/4; P={'A':A,'B':B,'C':C,'D':D}
proj=lambda p: np.array([p[0]+0.45*p[2], p[1]+0.35*p[2]])
fig,ax=plt.subplots(figsize=(5.6,4.6)); ax.set_aspect('equal'); ax.axis('off')
for u,v in [('A','B'),('A','C'),('A','D'),('B','C'),('B','D'),('C','D')]:
    p,q=proj(P[u]),proj(P[v]); ax.plot([p[0],q[0]],[p[1],q[1]],color='0.35',lw=2,zorder=1)
for k in P:
    p,q=proj(P[k]),proj(T); ax.plot([p[0],q[0]],[p[1],q[1]],color='tab:orange',lw=2,zorder=1)
for k in P:
    for other in list(P)+['T']:
        if other==k: continue
        q=T if other=='T' else P[other]; s=proj(P[k])+0.16*(proj(q)-proj(P[k]))
        ax.plot(s[0],s[1],marker='o',ms=6,color='tab:red' if other!='T' else 'tab:orange',mec='k',mew=0.6,zorder=3)
for k in P:
    p=proj(P[k]); ax.plot(p[0],p[1],'o',ms=13,color='tab:blue',mec='k',zorder=4); ax.text(p[0]+0.05,p[1]+0.05,k,fontsize=12)
p=proj(T); ax.plot(p[0],p[1],'*',ms=17,color='gold',mec='k',zorder=5); ax.text(p[0]+0.05,p[1]-0.09,'trapped node',fontsize=9)
for y,s in [(-0.15,"6 tetrahedron edges (grey)  +  4 spokes (orange)  =  10 distinct bonds"),
            (-0.23,"two-step paths from the trapped node inside the defect: 4 spokes x 3 edges + 4 back = 16"),
            (-0.31,"equivalently, bond-ends at the four corners (markers): 4 x (3 + 1) = 16"),
            (-0.39,"bond-ends in all, with the trapped node's four: 20 - it is not a lattice node and does not transmit")]:
    ax.text(0.02,y,s,fontsize=8.4,transform=ax.transAxes)
plt.subplots_adjust(bottom=0.36); plt.savefig('fig_defect_bonds.pdf',bbox_inches='tight'); plt.close()

# ---------------- Figure 3: dispersions of the two lifts ----------------
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
E3=[(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)]
reps=[(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
def bond_rep(a,b):
    d=tuple(b[i]-a[i] for i in range(3))
    if d in reps: return reps.index(d),a
    dn=tuple(-x for x in d); return reps.index(dn),b
phase=lambda k,r: np.exp(1j*np.dot(k,r))
def verts(t): return [tuple(int(t[i]+s[i]) for i in range(3)) for s in itertools.product([.5,-.5],repeat=3) if sum(int(t[i]+s[i]) for i in range(3))%2==0]
def cycle_rows(k):
    rows=[]
    for t in [(.5,.5,.5),(.5,.5,-.5)]:
        v=verts(t); pairs=[(a,b) for a in range(4) for b in range(a+1,4)]
        for skew in [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]:
            cyc=[p for p in pairs if p not in skew]; adj={i:[] for i in range(4)}
            for a,b in cyc: adj[a].append(b); adj[b].append(a)
            order=[0]; prev=None
            while len(order)<4:
                nxt=[x for x in adj[order[-1]] if x!=prev and x not in order][0]; prev=order[-1]; order.append(nxt)
            row=np.zeros(6,complex)
            for i in range(4):
                a,b=v[order[i]],v[order[(i+1)%4]]; j,r=bond_rep(a,b); row[j]+=(1 if i%2==0 else -1)*phase(k,r)
            rows.append(row)
    return np.array(rows)
def C_of_k(k):   # lift A: cube-edge sums at node 0 and void (1,0,0)
    C=np.zeros((2,6),complex); n=(0,0,0)
    for d in NN:
        b=tuple(n[i]+d[i] for i in range(3)); i,r=bond_rep(n,b); C[0,i]+=phase(k,r)
    o=(1,0,0); ring=[tuple(o[i]+d[i] for i in range(3)) for d in E3]
    for a in ring:
        for b in ring:
            if a<b and sum(abs(b[i]-a[i]) for i in range(3))==2 and max(abs(b[i]-a[i]) for i in range(3))==1:
                i,r=bond_rep(a,b); C[1,i]+=phase(k,r)
    return C
def tets_of_bond(a,b):
    mid=np.array([(a[i]+b[i])/2 for i in range(3)]); d=np.array(b)-np.array(a); z=[i for i in range(3) if d[i]==0][0]; e=np.zeros(3); e[z]=.5
    return tuple(mid+e),tuple(mid-e)
def D_of_k(k):   # lift B: signed divergence at the two tetrahedra of the cell
    D=np.zeros((2,6),complex)
    for ti,t in enumerate([(.5,.5,.5),(.5,.5,-.5)]):
        v=verts(t)
        for a in range(4):
            for b in range(a+1,4):
                j,r=bond_rep(v[a],v[b]); t1,t2=tets_of_bond(v[a],v[b]); D[ti,j]+=(+1 if np.allclose(t1,t) else -1)*phase(k,r)
    return D
def quartet_rows(k):
    rows=[]; n=(0,0,0)
    for e in E3:
        o=tuple(n[i]+e[i] for i in range(3)); axis=[i for i in range(3) if e[i]!=0][0]; others=[i for i in range(3) if i!=axis]
        mid=np.array([(n[i]+o[i])/2 for i in range(3)]); cyc=[]
        for s1,s2 in [(.5,.5),(-.5,.5),(-.5,-.5),(.5,-.5)]:
            c=mid.copy(); c[others[0]]+=s1; c[others[1]]+=s2; cyc.append(tuple(c))
        ring=[tuple(o[i]+d[i] for i in range(3)) for d in E3 if tuple(o[i]+d[i] for i in range(3))!=n and d[axis]==0]
        row=np.zeros(6,complex)
        for a in range(4):
            ta,tb=cyc[a],cyc[(a+1)%4]; found=None
            for r in ring:
                t1,t2=tets_of_bond(n,r)
                if np.allclose(t1,ta) and np.allclose(t2,tb): found=(r,+1)
                if np.allclose(t1,tb) and np.allclose(t2,ta): found=(r,-1)
            r,sgn=found; j,rr=bond_rep(n,r); row[j]+=sgn*phase(k,rr)
        rows.append(row)
    return np.array(rows)
def bands(k,Cfun,Afun):
    C=Cfun(k); A=Afun(k); Q,_=np.linalg.qr(C.conj().T); Pm=np.eye(6)-Q@Q.conj().T
    return np.sort(np.linalg.eigvalsh(Pm@(A.conj().T@A)@Pm).real)
dirs={'[100]':(1,0,0),'[110]':(1,1,0),'[111]':(1,1,1)}; cols={'[100]':'tab:blue','[110]':'tab:orange','[111]':'tab:green'}
fig,axs=plt.subplots(1,2,figsize=(8.2,3.4),sharey=True); kk=np.linspace(0.02,1.2,40)
for ax,(lab,Cf,Af) in zip(axs,[('Lift A: cube-edge (check) Gauss law',C_of_k,cycle_rows),('Lift B: tetrahedral-void divergence',D_of_k,quartet_rows)]):
    for name,dv in dirs.items():
        kh=np.array(dv,float); kh/=np.linalg.norm(kh); w=np.array([bands(k*kh,Cf,Af) for k in kk]); phys=w[:,2:4]
        for j in range(2): ax.plot(kk,np.sqrt(np.maximum(phys[:,j],0)),color=cols[name],ls='-' if j==0 else '--',label=name if j==0 else None)
    ax.plot(kk,kk,'k:',lw=1,label=r'$\omega=k$ (Maxwell)'); ax.set_title(lab,fontsize=10); ax.set_xlabel(r'$|k|$ (units of $1/a$)'); ax.grid(alpha=.3)
axs[0].set_ylabel(r'$\omega/\sqrt{UJ}$'); axs[0].legend(fontsize=8,loc='upper left'); axs[0].set_ylim(0,1.6)
axs[0].annotate('flat polarization along [100]',xy=(1.05,0.02),xytext=(0.30,0.28),fontsize=7.5,
                arrowprops=dict(arrowstyle='->',lw=0.8,color='0.3'),color='0.25')
axs[1].annotate('all six curves coincide\nwith $\\omega=k$',xy=(1.0,1.0),xytext=(0.32,1.32),fontsize=7.5,
                arrowprops=dict(arrowstyle='->',lw=0.8,color='0.3'),color='0.25')
plt.tight_layout(); plt.savefig('fig_dispersions.pdf'); plt.close()

# ---------------- Figure 4: quantum results ----------------
fig,ax=plt.subplots(figsize=(5.4,3.6))
ax.errorbar([2,6],[5.1,7.0],yerr=[0,2.0],fmt='s-',color='tab:blue',label='spin-1/2 QLM (ED L=2; PMC L=6)')
ax.errorbar([2,6,8],[12.5,14.2,20],yerr=[0,0.7,6],fmt='o-',color='tab:orange',label='spin-1 QLM (ED L=2; PMC L=6,8)')
ax.errorbar([4],[134],yerr=[[2],[2]],fmt='D',color='tab:green',ms=8,label=r'explicit $U/J=(4\pi\alpha)^2$, spin-6 (PMC L=4, two axes)')
ax.axhspan(135.2,135.8,color='tab:red',alpha=0.18); ax.axhline(135.5,color='tab:red',ls='--',lw=1.2,label=r'observed $\alpha^{-1}(0.235\,{\rm GeV})=135.5$')
ax.set_yscale('log'); ax.set_xlabel(r'linear size $L$'); ax.set_ylabel(r'$\alpha^{-1}=4\pi\sqrt{J_{\rm eff}/U_{\rm eff}}$'); ax.set_xticks([2,4,6,8]); ax.legend(fontsize=7.5,loc='center right'); ax.grid(alpha=.3,which='both')
plt.tight_layout(); plt.savefig('fig_quantum.pdf'); plt.close()
print("wrote fig_alpha_Lc.pdf fig_defect_bonds.pdf fig_dispersions.pdf fig_quantum.pdf")
# ---------------- Figure 5: the derivation chain ----------------
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
fig,ax=plt.subplots(figsize=(9.4,10.4)); ax.set_xlim(-0.4,10.4); ax.set_ylim(0.2,14.2); ax.axis('off')
def box(x,y,w,h,text,fc='white',ec='k',fs=8.4,lw=1.2):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle="round,pad=0.02,rounding_size=0.12",fc=fc,ec=ec,lw=lw,zorder=3))
    ax.text(x,y,text,ha='center',va='center',fontsize=fs,linespacing=1.35,zorder=4)
def arrow(x1,y1,x2,y2,ls='-'):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=13,lw=1.1,color='k',linestyle=ls,zorder=2))
G='#e8f0e8'; Y='#fff3d6'; B='#e6eef8'; R='#f8e6e6'
box(5,13.4,6.4,1.0,"Five axioms (P1)-(P5), Sec. 2.9\n"
    r"FCC $K=12$, $K/d=4$; tick $\tau=4L/c$; $\epsilon_b$ per standing bit; pricing; two codes",fc=Y,ec='#b8860b')
arrow(5,12.9,2.7,12.2); arrow(5,12.9,7.3,12.2)
box(2.7,11.6,4.2,1.2,"Information cost (external)\n"+r"$1836$ two-step paths out of the defect"+"\n"+r"$m_pc^2=1836\,\epsilon_b$,  $\epsilon_b=m_ec^2$",fc=G)
box(7.3,11.6,4.2,1.2,"Kinematic cost (internal)\n"+r"$16$ two-step paths inside it"+"\n"+r"$m_pc^2=16\,E_{\rm bond}$,  $E_{\rm bond}=\hbar c/4L_c$",fc=G)
arrow(2.7,11.0,4.6,10.2); arrow(7.3,11.0,5.4,10.2)
box(5,9.7,4.6,0.85,"Stability window (Sec. 8.11)\n"+r"$1836\,\epsilon_b=16\,E_{\rm bond}$",fc=G)
arrow(5,9.25,2.7,8.5); arrow(5,9.25,7.3,8.5)
box(2.7,7.9,4.2,1.15,"Proton charge radius as output\n"+r"$L_c=4\bar\lambda_e/1836=0.8413$ fm"+"\n"+r"($r_p=0.8409(4)$; CODATA 0.84075, $0.06\%$)",fc=B)
box(7.3,7.9,4.2,1.15,"Photon sector (Sec. 4, 7)\n"+r"$H=-J\sum\cos B_b+(U/2)\sum E_l^2$"+"\n"+r"$\alpha=\sqrt{U/J}/4\pi$",fc=G)
arrow(7.3,7.3,7.3,6.7)
box(7.3,6.1,4.2,1.15,"Coefficients derived (Sec. 8.8)\n"+r"$u=1$ (energy, gauge invariance); $\jmath=1$"+"\n"+r"(current $I=-(J/\hbar)\sin B$): $U=\epsilon_b$, $J=E_{\rm bond}$",fc=G)
arrow(2.9,7.3,4.6,5.25); arrow(7.3,5.5,6.0,5.25)
box(5.3,4.6,5.6,1.05,"Coupling at the confinement scale\n"+r"$\alpha^{-1}=4\pi\sqrt{E_{\rm bond}/\epsilon_b}=\pi\sqrt{m_p/m_e}=134.61$"+"\n"+r"(running value $135.5\pm0.3$, $0.6\%$)",fc=B)
arrow(5.3,4.05,5.3,3.35)
box(5.3,2.8,4.8,0.8,"Standard Model vacuum polarization\n"+r"(leptonic + hadronic), $0.235$ GeV $\to 0$",fc=R,ec='#a04040')
arrow(5.3,2.4,5.3,1.85)
box(5.3,1.35,4.8,0.8,"Low-energy fine-structure constant\n"+r"$\alpha(0)^{-1}=137.036$",fc=B)
box(1.5,2.5,2.9,1.9,"Not derived (Sec. 10):\nthe axioms themselves;\nthe rotor premise (A3);\nthe two-code reading (A1)-(A2);\nthe fine-code matching map",fc=R,ec='#a04040',fs=7.6)
arrow(1.5,12.9,1.5,3.5,ls='--')
plt.savefig('fig_chain.pdf',bbox_inches='tight'); plt.close()
print("wrote fig_chain.pdf")
