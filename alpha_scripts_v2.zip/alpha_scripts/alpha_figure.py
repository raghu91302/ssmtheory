#!/usr/bin/env python3
"""Figure 1: alpha^-1 = 2 pi sqrt(lambda_e / L_c) against the measured bands."""
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
lam=386.159; L=np.linspace(0.70,1.05,300); a=2*np.pi*np.sqrt(lam/L)
fig,ax=plt.subplots(figsize=(5.2,3.6))
ax.plot(L,a,'k-',lw=1.6,label=r'$\alpha^{-1}=2\pi\sqrt{\bar\lambda_e/L_c}$')
ax.axvspan(0.80,0.96,color='0.9',label=r'model band for $L_c$')
ax.axhspan(135.2,135.8,color='tab:blue',alpha=0.25,label=r'$\alpha^{-1}(\hbar c/L_c)=135.5\pm0.3$')
ax.axvline(0.8409,color='tab:red',ls='--',lw=1.2,label=r'$r_p=0.8409$ fm')
ax.set_xlabel(r'$L_c$ (fm)'); ax.set_ylabel(r'$\alpha^{-1}$'); ax.set_ylim(122,142)
ax.legend(fontsize=8,loc='upper right'); ax.grid(alpha=.3); plt.tight_layout(); plt.savefig('fig_alpha_Lc.pdf')
