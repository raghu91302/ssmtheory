#!/usr/bin/env python3
"""Stage 2: emergent coupling on the <100> cubic link lattice.
Lattice Maxwell: H = (U/2) sum_l E_l^2 + (K/2) sum_p B_p^2.  Transverse modes: omega_k = lambda_k sqrt(UK),
lambda_k^2 = sum_i 4 sin^2(k_i/2).  Ground state <E_l^2> = (1/3) sqrt(K/U) <lambda>_BZ.
Kogut-Susskind normalisation: g^2 = sqrt(U/K), alpha = g^2/(4 pi)  (unit charge = unit E, c = 1).
A qubit link has E = +-1/2 exactly, so <E^2> = 1/4 fixes sqrt(K/U) self-consistently.
A link with 2S+1 states can hold at most <E^2> = S(S+1)/3."""
import numpy as np
N = 96
k = 2*np.pi*np.arange(N)/N
kx,ky,kz = np.meshgrid(k,k,k, indexing='ij')
lam = np.sqrt(4*np.sin(kx/2)**2 + 4*np.sin(ky/2)**2 + 4*np.sin(kz/2)**2)
lam_mean = lam.mean()
print(f"<lambda>_BZ = {lam_mean:.4f}")

def alpha_from_E2(E2):
    sqrtKU = 3*E2/lam_mean          # sqrt(K/U)
    g2 = 1/sqrtKU                   # sqrt(U/K)
    return g2/(4*np.pi), g2, 1/g2   # alpha, g^2, beta

print("\nqubit link (E=+-1/2, <E^2>=1/4):")
a,g2,beta = alpha_from_E2(0.25)
print(f"  alpha = {a:.3f} = 1/{1/a:.1f}   g^2 = {g2:.2f}   beta = {beta:.3f}   (Coulomb phase needs beta > ~1.01)")

print("\nspin-S links, alpha at the maximal-fluctuation point <E^2> = S(S+1)/3:")
for S in [0.5,1,1.5,2,3,4,5,6,8]:
    a,g2,beta = alpha_from_E2(S*(S+1)/3)
    print(f"  S={S:<4} states={int(2*S+1):<3} alpha^-1={1/a:7.1f}   beta={beta:6.2f}")

target = 104.86
E2_needed = lam_mean*target/(4*np.pi)/3
S_needed = (-1+np.sqrt(1+12*E2_needed))/2
print(f"\ntarget alpha^-1 = {target}: needs <E^2> = {E2_needed:.2f}, i.e. sqrt(K/U) = {3*E2_needed/lam_mean:.2f},"
      f" U/K = {(lam_mean/(3*E2_needed))**2:.4f}")
print(f"  minimum link spin S >= {S_needed:.2f}  ->  at least {int(np.ceil(2*S_needed+1))} states per link")
print(f"  rms electric flux per link: {np.sqrt(E2_needed):.2f} quanta")
