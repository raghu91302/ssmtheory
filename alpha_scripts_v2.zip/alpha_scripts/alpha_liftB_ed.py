import sys, time, numpy as np
from alpha_liftB_ed_common import *
which=sys.argv[1]
if which=='half':
    vals,Smax,step,base,offset,Wunit=[-1,1],1,2,3,1,2
else:
    vals,Smax,step,base,offset,Wunit=[-1,0,1],1,1,3,1,1
t0=time.time()
b0=enumerate_mim(vals,0); print("W=0 basis",len(b0),f"{time.time()-t0:.0f}s",flush=True)
H0,Hp,Hm=build_parts(b0,Smax,step,base,offset); print("H built nnz",H0.nnz,f"{time.time()-t0:.0f}s",flush=True)
E0,psi=ground_vec(H0); print("E0(W=0)=",E0,f"{time.time()-t0:.0f}s",flush=True)
curv,info=curvature(H0,Hp,Hm,E0,psi); print("curvature",curv,"minres info",info,f"{time.time()-t0:.0f}s",flush=True)
np.save(f"ed_{which}_W0.npy",np.array([E0,curv]))
b1=enumerate_mim(vals,Wunit); print("W=1 basis",len(b1),flush=True)
H1,_,_=build_parts(b1,Smax,step,base,offset); E1,_=ground_vec(H1); print("E0(W=1)=",E1,f"{time.time()-t0:.0f}s",flush=True)
U=2*L*(E1-E0); J=L*curv
print(f"RESULT {which}: U_eff={U:.5f} J_eff={J:.5f} sqrt(J/U)={np.sqrt(J/U):.5f} alpha^-1={4*np.pi*np.sqrt(J/U):.3f}")
np.save(f"ed_{which}.npy",np.array([E0,E1,curv,U,J]))
