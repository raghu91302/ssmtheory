"""Figure: (a) the defect and the spin direction on each site for the J_z=+1/2 bound doublet; (b) spin share vs spoke hopping."""
import numpy as np, json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 10, "mathtext.fontset": "cm"})
fig = plt.figure(figsize=(11, 4.4))
# (a)
ax = fig.add_subplot(1, 2, 1)
d = np.array([0.995, 0.0, 0.0998]); d /= np.linalg.norm(d); u = np.cross(d, [0, 0, 1.]); u /= np.linalg.norm(u); w = np.cross(u, d)
P = lambda v: np.array([u@v, w@v])
n = [np.array(v)/np.sqrt(3) for v in [(-1, -1, -1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]]
V = [0.612*1.0*x/np.linalg.norm(x)*np.sqrt(3)/np.sqrt(3) for x in n]
for a in range(4):
    for b in range(a+1, 4):
        pa, pb = P(V[a]), P(V[b]); ax.plot([pa[0], pb[0]], [pa[1], pb[1]], color="0.75", lw=1.0, zorder=0)
for v in V:
    p = P(v); ax.plot([0, p[0]], [0, p[1]], color="#e6550d", lw=1.4, ls=(0, (3, 2)), zorder=1)
    ax.scatter(*p, s=110, c="#3182bd", edgecolors="k", zorder=3)
ax.scatter(0, 0, s=320, marker="*", c="#fdd835", edgecolors="#8a6d00", zorder=4)
z = np.array([0, 0, 1.])
def arrow(o, vec, col, scale=0.33):
    po = P(o); pv = P(vec)*scale
    ax.annotate("", xy=po+pv, xytext=po, arrowprops=dict(arrowstyle="-|>", lw=2.0, color=col), zorder=5, annotation_clip=False)
arrow(np.zeros(3), z, "#2ca02c", 0.42)
for v, nv in zip(V, n):
    arrow(v, 2*nv*(nv@z) - z, "#7b3294")
ax.text(0.5, -0.02, "node: spin up (share 1)\nfour neighbours: $(\\sigma\\cdot\\hat n)\\chi$, average $-\\frac{1}{3}$\nequal weights: $\\frac{1}{2}-\\frac{1}{6}=\\frac{1}{3}$",
        transform=ax.transAxes, fontsize=9.5, va="top", ha="center")
ax.set_xlim(-0.65, 0.65); ax.set_ylim(-0.62, 0.62); ax.set_aspect("equal"); ax.axis("off"); ax.set_title("(a) the defect's bound doublet, $J_z=+\\frac{1}{2}$", fontsize=11)
# (b)
ax = fig.add_subplot(1, 2, 2)
dd = json.load(open("spin_scan.json"))
for R2, lab, mk in [(10.75, "81 sites", "o"), (22.75, "241 sites", "s"), (40.75, "545 sites", "^")]:
    rs = [r for r in dd["scan"] if r["R2"] == R2]
    ax.plot([r["td"] for r in rs], [r["gS"] for r in rs], marker=mk, lw=1.2, ms=6, label=lab)
ax.axhspan(0.26, 0.36, color="#9ecae1", alpha=0.45, label="COMPASS 0.26–0.36")
ax.axhline(1/3, color="k", ls="--", lw=1, label="isolated defect, exactly 1/3")
ax.errorbar([6.35], [0.330], yerr=[0.039], fmt="D", color="#de2d26", capsize=4, label="HERMES 0.330 ± 0.039")
ax.set_xlabel("spoke hopping $t_d/t$"); ax.set_ylabel("spin share of the bound doublet")
ax.set_xlim(1.4, 6.6); ax.set_ylim(0.20, 0.42); ax.legend(fontsize=8.5, loc="lower right"); ax.grid(alpha=0.3)
ax.set_title("(b) spin share in the lattice", fontsize=11)
plt.tight_layout(); fig.savefig("fig_spin.pdf"); fig.savefig("fig_spin.png", dpi=160); print("ok")
