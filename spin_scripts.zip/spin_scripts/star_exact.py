"""The isolated defect (node + four Dirac spokes, no other bonds): exact bound states and spin share 1/3.
Checks: E = +-2 t_d; node weight 1/2; sum_v (sigma.n_v) sigma_z (sigma.n_v) = -(4/3) sigma_z over tetrahedral directions;
spin share = (1/2)(1) + (1/2)(-1/3) = 1/3, for every t_d."""
import numpy as np
from fractions import Fraction
n = [np.array(v)/np.sqrt(3) for v in [(-1, -1, -1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]]
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], complex)
sdot = lambda v: v[0]*sx + v[1]*sy + v[2]*sz
M = sum(sdot(v)@sz@sdot(v) for v in n)
print("sum_v (s.n) s_z (s.n) =", np.round(M.real, 6).tolist(), " expected -(4/3) s_z")
for td in (0.3, 1.0, 4.0):
    H = np.zeros((10, 10), complex)
    for k, v in enumerate(n):
        H[2+2*k:4+2*k, 0:2] = 1j*td*sdot(v); H[0:2, 2+2*k:4+2*k] = -1j*td*sdot(v)
    E, V = np.linalg.eigh(H)
    b = V[:, np.argsort(E)[:2]]                       # the E = -2 t_d doublet
    Sz = np.kron(np.eye(5), sz/2)
    # basis with J_z = +1/2: the node spinor points up -> diagonalise P sigma_z^node P
    Pn = np.zeros((10, 10), complex); Pn[0:2, 0:2] = sz
    w, u = np.linalg.eigh(b.conj().T@Pn@b); s = b@u[:, np.argmax(w)]
    print(f"t_d={td}: E = {np.round(np.sort(E)[[0,1,-2,-1]],6).tolist()}  node weight {np.sum(abs(s[:2])**2):.6f}"
          f"  <S_z> = {np.real(s.conj()@Sz@s):.6f}  share = {2*np.real(s.conj()@Sz@s):.6f}")
print("exact:", Fraction(1, 2)*1 + Fraction(1, 2)*Fraction(-1, 3))
