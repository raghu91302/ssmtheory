"""Scan of the bound doublet's spin share over cluster size, spoke hopping and node on-site energy (for the paper)."""
import numpy as np, json
from dirac_trapped_node import analyse
out = {"scan": [], "eps": []}
for R2 in (10.75, 22.75, 40.75):
    for td in (1.633, 2.0, 2.5, 3.0, 4.0, 6.0):
        e, d, lab, lw, nw, gS = analyse(R2, td, 0.0, nshow=1, verbose=False)[0]
        out["scan"].append(dict(R2=R2, td=td, E=float(e), loc=float(lw), node=float(nw), gS=float(gS)))
        print(f"R2={R2:6.2f} td={td:4.2f}  E={e:7.3f}  loc={lw:.3f}  node={nw:.3f}  gS={gS:.4f}", flush=True)
for eps in (-4.0, -2.0, -1.0, 0.0, 1.0, 2.0, 4.0):
    rows = analyse(22.75, 4.0, eps, nshow=2, verbose=False)
    e, d, lab, lw, nw, gS = rows[0]
    out["eps"].append(dict(eps=eps, E=float(e), loc=float(lw), node=float(nw), gS=float(gS)))
    print(f"eps={eps:5.1f}  E={e:7.3f}  loc={lw:.3f}  node={nw:.3f}  gS={gS:.4f}", flush=True)
json.dump(out, open("spin_scan.json", "w"), indent=1)
