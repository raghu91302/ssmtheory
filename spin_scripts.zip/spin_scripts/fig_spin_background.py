"""Background figure for the spin paper: (a) a node and its twelve bonds; (b) the proton's trapped node and the three
colors; (c) naive Dirac hopping along a bond rotates the spin by pi about the bond; (d) the four-site shell, A1 + T2."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 10, "mathtext.fontset": "cm"})
R = None
def setview(dv):
    global R
    d = np.array(dv, float); d /= np.linalg.norm(d)
    u = np.cross(d, [0, 0, 1.0]); u /= np.linalg.norm(u); w = np.cross(u, d); R = np.vstack([u, w])
P = lambda v: R @ np.asarray(v, float)
def seg(ax, a, b, **k):
    pa, pb = P(a), P(b); ax.plot([pa[0], pb[0]], [pa[1], pb[1]], solid_capstyle="round", **k)
def dot(ax, v, **k):
    p = P(v); ax.scatter([p[0]], [p[1]], **k)
def arr(ax, o, vec, col, lw=2.2):
    po, pv = P(o), P(vec)
    ax.annotate("", xy=po+pv, xytext=po, arrowprops=dict(arrowstyle="-|>", lw=lw, color=col), annotation_clip=False, zorder=6)
fig, axes = plt.subplots(2, 2, figsize=(9.6, 8.4)); axes = axes.ravel()
# (a)
ax = axes[0]; setview([0.574, -0.579, -0.579])
nn = [np.array(v)/2 for v in itertools.product((-1, 0, 1), repeat=3) if sum(abs(x) for x in v) == 2]
for a in nn:
    for b in nn:
        if abs(np.linalg.norm(a-b) - np.sqrt(0.5)) < 1e-9 and tuple(a) < tuple(b): seg(ax, a, b, color="#9fb3c8", lw=0.6, zorder=0)
for v in nn: seg(ax, np.zeros(3), v, color="#2b6cb0", lw=1.6, zorder=1); dot(ax, v, s=24, c="#2b6cb0", edgecolors="k", linewidths=0.5, zorder=3)
dot(ax, np.zeros(3), s=70, c="white", edgecolors="k", zorder=4)
ax.set_title("(a) a node of the vacuum and its twelve bonds")
# (b)
ax = axes[1]; setview([0.30, -0.90, 0.32])
V = [np.array(v, float) for v in [(0, 0, 0), (1, 1, 0), (1, 0, 1), (0, 1, 1)]]; T = sum(V)/4
for (e1, e2), c in zip([((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2))], ["#d62728", "#2ca02c", "#1f77b4"]):
    for a, b in (e1, e2): seg(ax, V[a], V[b], color=c, lw=2.6, zorder=1)
for v in V: seg(ax, v, T, color="#e6550d", lw=1.4, ls=(0, (3, 2)), zorder=2)
for v in V: dot(ax, v, s=70, c="#3182bd", edgecolors="k", linewidths=0.6, zorder=3)
dot(ax, T, s=220, c="#fdd835", edgecolors="#8a6d00", marker="*", zorder=4)
pt = P(T); ax.text(pt[0]+0.07, pt[1]+0.04, "trapped node", fontsize=10)
ax.set_title("(b) the proton: a node trapped in a tetrahedral void;\nopposite-edge pairs are the three colors")
# (c)
ax = axes[2]
A, B = np.array([0., 0.]), np.array([2.0, 0.])
ax.plot([A[0], B[0]], [A[1], B[1]], color="0.35", lw=2.2, zorder=1)
for p in (A, B): ax.scatter(*p, s=160, c="#3182bd", edgecolors="k", zorder=3)
sA = np.array([0.35, 0.75]); sB = np.array([0.35, -0.75])          # spin turned by pi about the bond (x axis)
for p, v in ((A, sA), (B, sB)):
    ax.annotate("", xy=p+v, xytext=p, arrowprops=dict(arrowstyle="-|>", lw=2.4, color="#2ca02c"), zorder=5)
ax.annotate("", xy=(1.45, -0.32), xytext=(0.55, -0.32), arrowprops=dict(arrowstyle="-|>", lw=1.4, color="0.4"))
ax.text(1.0, -0.55, r"$\hat n$", ha="center", fontsize=13)
ax.text(1.0, 0.25, r"$i\,t\,\sigma\cdot\hat n$", ha="center", fontsize=13)
ax.text(A[0], -0.35, "$i$", ha="center", fontsize=12); ax.text(B[0], 0.25, "$j$", ha="center", fontsize=12)
ax.set_xlim(-0.6, 2.8); ax.set_ylim(-1.1, 1.1)
ax.set_title("(c) a spinor on every node; hopping along a bond\nturns the spin by $\\pi$ about the bond")
# (d)
ax = axes[3]
Q = [np.array(p) for p in [(0, 0.9), (-0.85, -0.5), (0.85, -0.5), (0.15, -0.08)]]
for sh, signs, lab in ((-1.2, (1, 1, 1, 1), "$A_1$"), (1.2, (1, -1, 1, -1), "$T_2$, one of three")):
    o = np.array([sh, 0])
    for a in range(4):
        for b in range(a+1, 4):
            ax.plot([Q[a][0]+sh, Q[b][0]+sh], [Q[a][1], Q[b][1]], color="0.7", lw=1.0, zorder=0)
    for q, sg in zip(Q, signs):
        ax.scatter(q[0]+sh, q[1], s=420, c="#fdae6b" if sg > 0 else "#9ecae1", edgecolors="k", zorder=3)
        ax.text(q[0]+sh, q[1], "+" if sg > 0 else "\u2212", ha="center", va="center", fontsize=13, zorder=4)
    ax.text(sh, -0.95, lab, ha="center", fontsize=12)
ax.set_xlim(-2.3, 2.3); ax.set_ylim(-1.2, 1.2)
ax.set_title("(d) amplitudes on the four neighbours\nof the trapped node: $A_1\\oplus T_2$")
for a in axes: a.set_aspect("equal"); a.axis("off")
axes[0].set_xlim(-0.8, 0.8); axes[0].set_ylim(-0.75, 0.75)
plt.tight_layout(); fig.savefig("fig_spin_background.pdf", bbox_inches="tight"); fig.savefig("fig_spin_background.png", dpi=140, bbox_inches="tight"); print("ok")
