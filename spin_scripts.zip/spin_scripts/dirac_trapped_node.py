"""Naive Dirac operator on an FCC cluster with the extra node placed in a tetrahedral void as a site of its own.

Grid units: conventional cube side 2, FCC nodes at integer points with even coordinate sum, bond L = sqrt2.
The void centre c = (1/2,1/2,1/2); its four vertices are at distance sqrt(3)/2 = 0.612 L (not L).
Hopping (two-component spinors, as in the GFJ paper):  H[j<-i] = i t sigma.n_ij  for FCC bonds (n_ij unit vector i->j),
                                                        H[v<-node] = i t_d sigma.n  along each spoke,  plus eps_d on the node.
The cluster is chosen symmetric about c, so the tetrahedral rotations T (order 12) about c are exact symmetries.
For each bound doublet transforming as spin 1/2 under T (double group), the spin share g_S is read from
P S_z P = g_S J_z^eff, with J_z^eff = (i/2) D(C2z) the doublet's total-angular-momentum generator (exp(-i pi J_z) = -2i J_z).
"""
import numpy as np, itertools, sys
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], complex)
S = [sx, sy, sz]
c = np.array([0.5, 0.5, 0.5])

def build(R2, t=1.0, td=1.0, eps=0.0):
    sites = [np.array(p, float) for p in itertools.product(range(-8, 9), repeat=3)
             if sum(p) % 2 == 0 and np.sum((np.array(p) - c)**2) <= R2]
    sites.append(c.copy())                        # the trapped node, last
    N = len(sites); node = N - 1
    H = np.zeros((2*N, 2*N), complex)
    def hop(i, j, amp):
        n = sites[j] - sites[i]; n = n/np.linalg.norm(n)
        H[2*j:2*j+2, 2*i:2*i+2] += 1j*amp*(n[0]*sx + n[1]*sy + n[2]*sz)
    for i in range(N-1):
        for j in range(N-1):
            if i != j and abs(np.sum((sites[i]-sites[j])**2) - 2) < 1e-9: hop(i, j, t)
    verts = [i for i in range(N-1) if abs(np.sum((sites[i]-c)**2) - 0.75) < 1e-9]
    assert len(verts) == 4
    for v in verts: hop(node, v, td); hop(v, node, td)
    H[2*node:2*node+2, 2*node:2*node+2] += eps*np.eye(2)
    assert np.allclose(H, H.conj().T)
    return sites, verts, node, H

def su2(Rm):
    """SU(2) lift of a proper rotation matrix (one of the two signs)."""
    w, v = np.linalg.eig(Rm); k = np.argmin(abs(w - 1)); ax = np.real(v[:, k]); ax /= np.linalg.norm(ax)
    ct = (np.trace(Rm) - 1)/2; ct = np.clip(ct, -1, 1); th = np.arccos(ct)
    # fix the sense of rotation so that Rm = rotation by th about ax
    K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
    if not np.allclose(np.eye(3) + np.sin(th)*K + (1-np.cos(th))*K@K, Rm): ax = -ax
    return np.cos(th/2)*np.eye(2) - 1j*np.sin(th/2)*(ax[0]*sx + ax[1]*sy + ax[2]*sz), th, ax

def tet_rotations():
    V = [np.array(v) for v in [(-.5, -.5, -.5), (.5, .5, -.5), (.5, -.5, .5), (-.5, .5, .5)]]
    out = []
    for perm in itertools.permutations(range(3)):
        for sg in itertools.product((1, -1), repeat=3):
            Rm = np.zeros((3, 3))
            for a in range(3): Rm[a, perm[a]] = sg[a]
            if np.linalg.det(Rm) < 0: continue
            if all(any(np.allclose(Rm@v, w) for w in V) for v in V): out.append(Rm)
    assert len(out) == 12
    return out

def site_perm(sites, Rm):
    idx = {tuple(np.round(s*2).astype(int)): k for k, s in enumerate(sites)}
    P = []
    for s in sites:
        r = c + Rm@(s - c); P.append(idx[tuple(np.round(r*2).astype(int))])
    return P

def op(sites, Rm):
    U, th, ax = su2(Rm); P = site_perm(sites, Rm); N = len(sites)
    W = np.zeros((2*N, 2*N), complex)
    for i, j in enumerate(P): W[2*j:2*j+2, 2*i:2*i+2] = U
    return W, th, ax

def analyse(R2, td, eps, t=1.0, nshow=4, verbose=True):
    sites, verts, node, H = build(R2, t, td, eps); N = len(sites)
    rots = tet_rotations()
    Ws = [op(sites, Rm) for Rm in rots]
    for W, th, ax in Ws: assert np.allclose(W@H@W.conj().T, H), "not symmetric"
    E, V = np.linalg.eigh(H)
    loc_idx = [2*k + s for k in verts + [node] for s in (0, 1)]
    nodew = np.sum(abs(V[[2*node, 2*node+1], :])**2, axis=0)
    locw = np.sum(abs(V[loc_idx, :])**2, axis=0)
    # C2 about z through c, and a C3 about (1,1,1)
    C2z = next(W for W, th, ax in Ws if abs(th - np.pi) < 1e-9 and abs(abs(ax[2]) - 1) < 1e-9)
    C3 = next(W for W, th, ax in Ws if abs(th - 2*np.pi/3) < 1e-9)
    Sz = np.kron(np.eye(N), sz/2)
    # group degenerate levels
    order = np.argsort(-locw); used = set(); rows = []
    for k in order:
        if k in used: continue
        grp = [m for m in range(len(E)) if abs(E[m] - E[k]) < 1e-7]; used |= set(grp)
        B = V[:, grp]; d = len(grp)
        chi3 = np.trace(B.conj().T@C3@B).real
        lab = {2: ("j=1/2 (G5)" if abs(chi3 - 1) < 1e-6 else "G6/G7 (from j=3/2)"), 4: "j=3/2-type (G6+G7)"}.get(d, f"dim {d}")
        gS = np.nan
        if d == 2 and abs(chi3 - 1) < 1e-6:
            Jz = 0.5j*(B.conj().T@C2z@B)            # doublet's J_z
            Szp = B.conj().T@Sz@B
            gS = (np.trace(Szp@Jz)/np.trace(Jz@Jz)).real
        rows.append((E[k], d, lab, locw[grp].mean(), nodew[grp].mean(), gS))
        if len(rows) >= nshow: break
    if verbose:
        print(f"R2={R2}  sites={N}  t_d/t={td}  eps_d={eps}   bulk |E|max={abs(E).max():.3f}")
        for e, d, lab, lw, nw, gS in sorted(rows, key=lambda r: r[0]):
            print(f"   E={e:8.4f}  dim {d}  {lab:20s}  weight on node+4 vertices {lw:.3f}  on node {nw:.3f}  spin share g_S = {gS:.3f}" if not np.isnan(gS)
                  else f"   E={e:8.4f}  dim {d}  {lab:20s}  weight on node+4 vertices {lw:.3f}  on node {nw:.3f}")
    return rows

if __name__ == "__main__":
    # improper operations: check that a mirror maps H to -H (the two-component naive operator is chiral)
    sites, verts, node, H = build(10.75)
    M = np.diag([1., 1., 1.]); M = np.array([[0, 1, 0], [1, 0, 0], [0, 0, 1]], float)   # mirror x<->y through c
    P = site_perm(sites, M); N = len(sites); Wm = np.zeros((2*N, 2*N), complex)
    U = su2(-M)[0]                                  # improper = inversion x proper; spin sees the proper part
    for i, j in enumerate(P): Wm[2*j:2*j+2, 2*i:2*i+2] = U
    print("mirror x<->y:  W H W^+ = +H ?", np.allclose(Wm@H@Wm.conj().T, H), "   = -H ?", np.allclose(Wm@H@Wm.conj().T, -H))
    print()
    for R2 in (10.75, 22.75, 40.75):
        for td in (1.0, 1.633, 4.0):
            analyse(R2, td, 0.0)
        print()
    print("on-site energy of the node:")
    for eps in (-4.0, -2.0, 2.0, 4.0):
        analyse(22.75, 1.633, eps)
