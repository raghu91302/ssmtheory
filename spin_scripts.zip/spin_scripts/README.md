# Scripts for "The proton's quark-spin fraction from the trapped-node defect of the FCC vacuum lattice"

R. Kulkarni. Python 3 with NumPy and Matplotlib.

| script | paper | what it does |
|---|---|---|
| `star_exact.py` | Prop. 1 | Isolated defect (node + four Dirac spokes): energies, equal weights, spin share exactly 1/3 |
| `dirac_trapped_node.py` | Lemma 1, Secs. 4 and 6 | Lattice Hamiltonian with the trapped node as a site; checks the rotation symmetry T and that mirrors reverse H; bound doublets and their spin share |
| `spin_scan.py` | Tables 1 and 2 | Scan over cluster size, spoke hopping and node on-site energy; writes spin_scan.json |
| `fig_spin_background.py` | Figure 1 | The parts of the model used: node and bonds, trapped node and colors, Dirac hopping, A1 + T2 shell |
| `fig_spin.py` | Figure 2 | Reads spin_scan.json (run spin_scan.py first) |

Run, for example: `python3 star_exact.py`
