"""Spin share of the ground doublet of an isolated star for several spoke sets.
Node at the centre, N cage sites on the spoke directions n_v, spokes i t_d sigma.n_v, no on-site energy.
Any set with sum_v n_v n_v = (N/3) 1 gives E = -sqrt(N) t_d, equal node/cage weight and share 1/3."""
import numpy as np, itertools
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], complex)
sd = lambda v: v[0]*sx + v[1]*sy + v[2]*sz
sets = {"tetrahedral (4)": [(-1,-1,-1), (1,1,-1), (1,-1,1), (-1,1,1)],
        "octahedral (6)": [(1,0,0), (-1,0,0), (0,1,0), (0,-1,0), (0,0,1), (0,0,-1)],
        "cubic (8)": list(itertools.product((-1, 1), repeat=3))}
for name, dirs in sets.items():
    n = [np.array(v, float)/np.linalg.norm(v) for v in dirs]; N = len(n); D = 2*(N+1)
    H = np.zeros((D, D), complex)
    for k, v in enumerate(n):
        H[2+2*k:4+2*k, 0:2] = 1j*sd(v); H[0:2, 2+2*k:4+2*k] = -1j*sd(v)
    E, V = np.linalg.eigh(H); b = V[:, np.argsort(E)[:2]]
    Pn = np.zeros((D, D), complex); Pn[0:2, 0:2] = sz
    w, u = np.linalg.eigh(b.conj().T @ Pn @ b); st = b @ u[:, np.argmax(w)]
    node = np.real(st[:2].conj() @ st[:2])
    share = 2*np.real(st.conj() @ np.kron(np.eye(N+1), sz/2) @ st)
    print(f"{name:16s} E0 = {np.sort(E)[0]:+.4f} t_d (-sqrt(N) = {-np.sqrt(N):+.4f})  node weight {node:.4f}  share {share:.6f}")
