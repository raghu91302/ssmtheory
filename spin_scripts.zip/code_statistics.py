"""Exchange statistics of the point excitations of the FCC vacuum code (Levin-Wen T-junction test).

Code: qubits on the bonds of the FCC lattice (periodic box, grid side G = 2 x cells), Z-check on every node
(its 12 bonds), X-check on every octahedral void (its 12 edges).  [[3N^3, 2N^3+2, 3]] with N = G.
Excitations: an X on a bond flips the Z-checks at its two ends -> 'e' particles on nodes, moved by X-strings
along bonds.  A Z on a bond flips the X-checks of the two octahedra that contain it -> 'm' particles on
octahedral voids, moved by Z-strings.  Levin-Wen: for hopping operators t1,t2,t3 that bring a particle from
three sites into a common site, t3 t2 t1 = s12 s13 s23 t1 t2 t3; the product of signs is +1 for a boson,
-1 for a fermion, and must not depend on how the strings are chosen.
"""
import numpy as np, itertools, random
from collections import deque
G = 8
def wrap(p): return tuple(x % G for x in p)
nodes = [p for p in itertools.product(range(G), repeat=3) if sum(p) % 2 == 0]
voids = [p for p in itertools.product(range(G), repeat=3) if sum(p) % 2 == 1]
nn = [v for v in itertools.product((-1, 0, 1), repeat=3) if sum(abs(x) for x in v) == 2]
bonds = {}; blist = []
for p in nodes:
    for v in nn:
        q = wrap(tuple(p[i]+v[i] for i in range(3))); k = frozenset((p, q))
        if k not in bonds: bonds[k] = len(blist); blist.append((p, q))
nb = len(blist)
units = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
oct_edges = {}
for o in voids:
    cs = [wrap(tuple(o[i]+e[i] for i in range(3))) for e in units]
    oct_edges[o] = [bonds[frozenset((a, b))] for a, b in itertools.combinations(cs, 2) if frozenset((a, b)) in bonds]
node_bonds = {p: [] for p in nodes}
for b, (p, q) in enumerate(blist): node_bonds[p].append(b); node_bonds[q].append(b)
bond_octs = [[] for _ in range(nb)]
for o, es in oct_edges.items():
    for b in es: bond_octs[b].append(o)
assert all(len(x) == 12 for x in node_bonds.values()) and all(len(x) == 12 for x in oct_edges.values())
assert all(len(x) == 2 for x in bond_octs)
HZ = np.zeros((len(nodes), nb), np.uint8); HX = np.zeros((len(voids), nb), np.uint8)
for i, p in enumerate(nodes): HZ[i, node_bonds[p]] = 1
for i, o in enumerate(voids): HX[i, oct_edges[o]] = 1
assert not ((HZ.astype(int) @ HX.T.astype(int)) % 2).any()
def rank2(M):
    M = M.copy() % 2; r = 0
    for c in range(M.shape[1]):
        piv = [i for i in range(r, M.shape[0]) if M[i, c]]
        if not piv: continue
        M[[r, piv[0]]] = M[[piv[0], r]]
        for i in range(M.shape[0]):
            if i != r and M[i, c]: M[i] ^= M[r]
        r += 1
    return r
rZ, rX = rank2(HZ), rank2(HX); k = nb - rZ - rX
print(f"code: n = {nb}, rank HZ = {rZ}, rank HX = {rX}, k = {k}  (2N^3+2 = {2*G**3+2})")
# triangles: odd-weight cycles -> X-logicals of weight 3 (commute with every Z-check, not in the even-weight span of HX)
tri = []
for p in nodes[:1]:
    nbrs = [wrap(tuple(p[i]+v[i] for i in range(3))) for v in nn]
    for a, b in itertools.combinations(nbrs, 2):
        if frozenset((a, b)) in bonds: tri.append([bonds[frozenset((p, a))], bonds[frozenset((p, b))], bonds[frozenset((a, b))]])
t = np.zeros(nb, np.uint8); t[tri[0]] = 1
print(f"a triangle: Z-syndrome {int((HZ.astype(int) @ t).sum() % 2 if False else ((HZ.astype(int)@t)%2).sum())}, weight 3 (odd), so not a product of the weight-12 X-checks: a local logical operator")
cyc = nb - len(nodes) + 1
print(f"cycle space of the bond graph: {cyc}; contractible part {cyc-3}; X-check rank {rX}; local logicals {cyc-3-rX} + 3 non-contractible = {cyc-rX}")
# octahedral X-check = sum of four alternating triangles of the octahedron
# ---- hopping operators
node_adj = {p: [(q if p == a else a, b) for b, (a, q) in enumerate(blist) if p in (a, q)] for p in nodes}
node_adj = {p: [] for p in nodes}
for b, (a, q) in enumerate(blist): node_adj[a].append((q, b)); node_adj[q].append((a, b))
oct_adj = {o: [] for o in voids}
for b in range(nb):
    o1, o2 = bond_octs[b]; oct_adj[o1].append((o2, b)); oct_adj[o2].append((o1, b))
def path(adj, s, t, rng):
    """random shortest-ish path from s to t; returns the set (GF2) of bonds used"""
    prev = {s: None}; dq = deque([s])
    while dq:
        u = dq.popleft()
        if u == t: break
        nbrs = adj[u][:]; rng.shuffle(nbrs)
        for v, b in nbrs:
            if v not in prev: prev[v] = (u, b); dq.append(v)
    v = np.zeros(nb, np.uint8); u = t
    while prev[u] is not None: u, b = prev[u]; v[b] ^= 1
    return v
def sign(A, B):  # A, B = (x, z) GF(2) vectors; -1 if anticommute
    return -1 if (int(A[0] @ B[1]) + int(A[1] @ B[0])) % 2 else 1
def tjunction(kind, rng, detour=False):
    zero = np.zeros(nb, np.uint8)
    c = (4, 4, 4)                                    # a node; its void neighbour (5,4,4) is an octahedral void
    cn, co = c, (5, 4, 4)
    ends_n = [(0, 4, 4), (4, 0, 4), (4, 4, 0)] if True else None
    ends_n = [wrap(p) for p in [(1, 5, 4), (5, 1, 4), (4, 6, 6)]]    # three nodes around
    ends_o = [wrap((p[0]+1, p[1], p[2])) for p in ends_n]             # their void partners
    ops = []
    for n_, o_ in zip(ends_n, ends_o):
        x = path(node_adj, n_, cn, rng) if kind in ("e", "em") else zero
        z = path(oct_adj, o_, co, rng) if kind in ("m", "em") else zero
        ops.append((x, z))
    return sign(ops[0], ops[1]) * sign(ops[0], ops[2]) * sign(ops[1], ops[2])
for kind, lab in [("e", "e (node charge, X-strings)"), ("m", "m (void charge, Z-strings)"), ("em", "e x m composite")]:
    res = [tjunction(kind, random.Random(s)) for s in range(200)]
    print(f"{lab:32s}: T-junction phase over 200 random string choices -> +1: {res.count(1)}, -1: {res.count(-1)}")
