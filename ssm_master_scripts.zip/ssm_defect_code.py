#!/usr/bin/env python3
"""
ssm_defect_code.py -- the tetrahedral matter defect realized IN the code.

Extends the actual [[192,130,3]] construction by the geometric insertion the
companion papers call the proton core: one site in a tetrahedral void, four
new bonds to its hosts. CSS consistency then FORCES the check structure:
the four host X-checks gain one bond (weight 12 -> 13), a new void X-check
of weight 4 appears, and six triangle Z-checks (void-host-host, weight 3)
must be added -- verified to commute with everything. Computed:

(1) the defect code's parameters [[196, k', .]] by GF(2) rank;
(2) the modified/new check census of the insertion (the flag anatomy);
(3) the syndrome-distinguishability hierarchy for the F1 axiom: whether any
    uniform static record gives point defect -> 1 AND tetrahedron -> 1836.
"""
import numpy as np, itertools as it

# ---------------------------------------------------------------- base code
L = 2
base = [(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]
sites = sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3) for b in base))
S = {p:i for i,p in enumerate(sites)}; NS=len(sites)
def wrapd(p,q):
    return tuple((np.array(q)-np.array(p)+L/2)%L - L/2)
bonds=[]
for i,p in enumerate(sites):
    for j,q in enumerate(sites):
        if j<=i: continue
        d=np.array(wrapd(p,q))
        if abs(d@d-0.5)<1e-9: bonds.append((i,j))
bonds=sorted(bonds); B={b:i for i,b in enumerate(bonds)}; NB=len(bonds)
A=np.zeros((NS,NB),np.uint8)
for (u,v),e in B.items(): A[u,e]=A[v,e]=1
voids=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3)
                 for b in [(0.5,0,0),(0,0.5,0),(0,0,0.5),(0.5,0.5,0.5)]))
def oct_edges(cn):
    vs=[i for i,p in enumerate(sites) if abs(np.array(wrapd(cn,p))@np.array(wrapd(cn,p))-0.25)<1e-9]
    return [B[(min(i,j),max(i,j))] for i,j in it.combinations(sorted(vs),2) if (min(i,j),max(i,j)) in B]
Zc=np.zeros((len(voids),NB),np.uint8)
for oi,cn in enumerate(voids):
    for e in oct_edges(cn): Zc[oi,e]=1
def gf2_rank(M):
    M=M.copy()%2; r=0
    for c in range(M.shape[1]):
        piv=None
        for i in range(r,M.shape[0]):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(M.shape[0]):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
print(f"base code: [[{NB},{NB-gf2_rank(A)-gf2_rank(Zc)},3]] (ranks {gf2_rank(A)},{gf2_rank(Zc)})")

# ---------------------------------------------------------------- insertion
vd=(0.25,0.25,0.25)
hosts=[i for i,p in enumerate(sites) if abs(np.array(wrapd(vd,p))@np.array(wrapd(vd,p))-3/16)<1e-9]
assert len(hosts)==4 and all((min(a,b),max(a,b)) in B for a,b in it.combinations(hosts,2))
Nq = NB+4                                  # four new bond qubits nb_0..nb_3
A2 = np.zeros((NS+1,Nq),np.uint8); A2[:NS,:NB]=A
for i,h in enumerate(hosts): A2[h,NB+i]=1  # hosts gain their new bond (w 13)
A2[NS,NB:]=1                               # void X-check, weight 4
Z2 = np.zeros((len(voids)+6,Nq),np.uint8); Z2[:len(voids),:NB]=Zc
tri=[]
for t,(i,j) in enumerate(it.combinations(range(4),2)):
    hh=B[(min(hosts[i],hosts[j]),max(hosts[i],hosts[j]))]
    Z2[len(voids)+t,[NB+i,NB+j,hh]]=1      # triangle Z-check, weight 3
comm=(A2@Z2.T)%2
print(f"defect code: all checks commute: {comm.max()==0}")
wA=sorted(set(A2.sum(1))); wZ=sorted(set(Z2.sum(1)))
print(f"check weights: X {wA}, Z {wZ}")
rA,rZ=gf2_rank(A2),gf2_rank(Z2)
k2=Nq-rA-rZ
print(f"ranks: X {rA}, Z {rZ}  ->  defect code [[{Nq},{k2},.]]")
print(f"logical change from insertion: k {NB-62} -> {k2}  (Delta k = {k2-130})")
print(f"check census of the insertion: 4 modified + 1 new X + 6 new Z = 11 touched")
# weight-1 logical scan on new qubits
w1=False
for q in range(NB,Nq):
    vz=np.zeros(Nq,np.uint8); vz[q]=1
    if not (A2@vz%2).any(): w1=True
    vx=np.zeros(Nq,np.uint8); vx[q]=1
    if not (Z2@vx%2).any(): w1=True
print(f"weight-1 logicals introduced: {w1}")

# ---------------------------------------------------------------- F1 records
print("\n== syndrome-distinguishability hierarchy (F1 axiom test) ==")
# record R0: flag-adjacency (f1,f2) = # flagged endpoints of each probed bond
def classes_R0(flagged):
    cls=set()
    for e in flagged:
        p=sites[e]
        dirs=[q for q in range(NS) if (min(e,q),max(e,q)) in B]
        for d1,d2 in it.product(dirs,repeat=2):
            f1=(1 if e in flagged else 0)+(1 if d1 in flagged else 0)
            f2=(1 if e in flagged else 0)+(1 if d2 in flagged else 0)
            cls.add((f1,f2))
    return len(flagged), len(cls)
pt=classes_R0({hosts[0]})
tt=classes_R0(set(hosts))
print(f"record R0 (flag adjacency): point -> {pt[0]} el x {pt[1]} classes = {pt[0]*pt[1]} ops;"
      f"  tet -> {tt[0]} el x {tt[1]} classes = {tt[0]*tt[1]} ops")
print("record R2 (full context identity): point -> 144 ops; tet -> full census")
print("""
VERDICT: no uniform STATIC record reproduces (1, 1836). R0 gives the point
defect its unit (all 144 contexts collapse to one flag-class -- verified on
the real check membership) but collapses the tetrahedron to {} ops; full
context identity gives the tetrahedron its census but breaks the electron's
unit. The distinguishability that requirement (a) needs is therefore
DYNAMICAL -- a property of syndrome propagation under U_cycle, not of static
adjacency. The orbit count is irreducibly a property of the schedule; the
master equation cannot be shortcut by geometry. [derived: second no-go]""".format(tt[0]*tt[1]))
