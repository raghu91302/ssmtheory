"""Clean-room reproduction of the merged paper's computational constructions,
implemented from the text's geometric definitions only."""
import itertools, numpy as np

def rank_gf2(rows):
    rows=[r for r in rows if r]; rank=0
    while rows:
        p=min(rows,key=int.bit_length) if False else rows[0]
        rows=rows[1:]; 
        if p==0: continue
        b=p.bit_length()-1
        rows=[(r^p) if (r>>b)&1 else r for r in rows]
        rows=[r for r in rows if r]; rank+=1
    return rank

# ---------- ambient FCC code, doubled-integer coords, box L=8 (=4 original) ----------
L=8
def w(v): return tuple(x%L for x in v)
sites=[v for v in itertools.product(range(0,L,2),repeat=3) if sum(v)%4==0]
S=set(sites)
NN=[p for p in itertools.product((-2,0,2),repeat=3) if sorted(map(abs,p))==[0,2,2]]
assert len(NN)==12
bonds=sorted({frozenset((v,w(tuple(a+b for a,b in zip(v,d))))) for v in sites for d in NN if w(tuple(a+b for a,b in zip(v,d))) in S})
bidx={b:i for i,b in enumerate(bonds)}
octa=[v for v in itertools.product(range(0,L,2),repeat=3) if sum(v)%4==2]
def octa_hosts(c):
    return [w(tuple(a+b for a,b in zip(c,d))) for d in [(2,0,0),(-2,0,0),(0,2,0),(0,-2,0),(0,0,2),(0,0,-2)]]
A_rows=[]; 
for v in sites:
    r=0
    for d in NN:
        u=w(tuple(a+b for a,b in zip(v,d)))
        if u in S: r|=1<<bidx[frozenset((v,u))]
    A_rows.append(r)
B_rows=[]
for c in octa:
    hs=octa_hosts(c); r=0; cnt=0
    for h1,h2 in itertools.combinations(hs,2):
        b=frozenset((h1,h2))
        if b in bidx: r|=1<<bidx[b]; cnt+=1
    assert cnt==12, cnt
    B_rows.append(r)
n=len(bonds); rA=rank_gf2(A_rows[:]); rB=rank_gf2(B_rows[:]); k=n-rA-rB
wtsA={bin(r).count('1') for r in A_rows}; wtsB={bin(r).count('1') for r in B_rows}
comm=all(bin(a&b).count('1')%2==0 for a in A_rows for b in B_rows)
# distance>=3 via weight<=2 syndrome uniqueness (both sectors)
synA=[frozenset(i for i,r in enumerate(A_rows) if (r>>q)&1) for q in range(n)]
synB=[frozenset(i for i,r in enumerate(B_rows) if (r>>q)&1) for q in range(n)]
dz3=all(sa for sa in synA) and len(set(synA))==n
dx3=all(sb for sb in synB) and len(set(synB))==n
print(f"[ambient]   n={n} rank(A)={rA} rank(B)={rB} k={k}  weights A={wtsA} B={wtsB}  CSS={comm}  d>=3(Z,X)=({dz3},{dx3})   EXPECT [[192,130,3]] w12")

# ---------- tetrahedral insertion ----------
T=(1,1,1)
hostsT=[w(tuple(a+b for a,b in zip(T,d))) for d in [(-1,-1,-1),(1,1,-1),(1,-1,1),(-1,1,1)]]
assert all(h in S for h in hostsT)
assert all(frozenset((h1,h2)) in bidx for h1,h2 in itertools.combinations(hostsT,2)), "hosts mutually NN"
newb=[frozenset((T,h)) for h in hostsT]
bidx2=dict(bidx); [bidx2.setdefault(b,len(bidx2)) for b in newb]
n2=len(bidx2)
A2=[]
for i,v in enumerate(sites):
    r=A_rows[i]
    if v in hostsT: r|=1<<bidx2[frozenset((T,v))]
    A2.append(r)
A2.append(sum(1<<bidx2[b] for b in newb))            # new node check, w4
Z2=list(B_rows)
tri=0
for h1,h2 in itertools.combinations(hostsT,2):
    Z2.append((1<<bidx2[frozenset((h1,h2))])|(1<<bidx2[frozenset((T,h1))])|(1<<bidx2[frozenset((T,h2))])); tri+=1
rA2=rank_gf2(A2[:]); rZ2=rank_gf2(Z2[:]); k2=n2-rA2-rZ2
hostw={bin(A2[sites.index(h)]).count('1') for h in hostsT}
comm2=all(bin(a&b).count('1')%2==0 for a in A2 for b in Z2)
tri_only=[z for z in Z2[len(B_rows):]]
newmask=sum(1<<bidx2[b] for b in newb)
r_new_sector=rank_gf2([z&newmask for z in tri_only])
r_amb_added=rank_gf2(Z2[:])-rank_gf2(list(B_rows))-r_new_sector
print(f"[tetra]     n={n2} k={k2} (dk={k2-k})  hostw={hostw} nodew={bin(A2[-1]).count('1')} triangles={tri}(w3) CSS={comm2}  Z-split: new-sector rank={r_new_sector}, ambient={rank_gf2(Z2[:])-rank_gf2(list(B_rows))-r_new_sector}   EXPECT [[196,127]] dk=-3 w13/w4/6xw3 split 3+3")

# ---------- octahedral insertion (fresh ambient copy) ----------
C=(2,0,0)
hostsC=octa_hosts(C)
newbC=[frozenset((('X',)+C,h)) for h in hostsC]  # tag node distinctly
bidx3=dict(bidx); [bidx3.setdefault(b,len(bidx3)) for b in newbC]
n3=len(bidx3)
A3=[]
for i,v in enumerate(sites):
    r=A_rows[i]
    if v in hostsC: r|=1<<bidx3[frozenset((('X',)+C,v))]
    A3.append(r)
A3.append(sum(1<<bidx3[b] for b in newbC))
Z3=list(B_rows); cage=0
for h1,h2 in itertools.combinations(hostsC,2):
    if frozenset((h1,h2)) in bidx:   # cage NN pairs only (12 of 15)
        Z3.append((1<<bidx3[frozenset((h1,h2))])|(1<<bidx3[frozenset((('X',)+C,h1))])|(1<<bidx3[frozenset((('X',)+C,h2))])); cage+=1
rA3=rank_gf2(A3[:]); rZ3=rank_gf2(Z3[:]); k3=n3-rA3-rZ3
newmask3=sum(1<<bidx3[b] for b in newbC)
tri3=[z for z in Z3[len(B_rows):]]
rn3=rank_gf2([z&newmask3 for z in tri3])
print(f"[octa]      n={n3} k={k3} (dk={k3-k})  cage-triangles={cage} nodew={bin(A3[-1]).count('1')}  Z-split: new-sector rank={rn3}, ambient={rank_gf2(Z3[:])-rank_gf2(list(B_rows))-rn3}   EXPECT [[198,124]] dk=-6 12xw3 split 5+6")

# ---------- combinatorics: 36, skew-30, intra-96, 1836, dispersion ----------
t36 = 4*3**2
K222=[(h1,h2) for h1,h2 in itertools.combinations(range(6),2)]
adj=lambda i,j: (i//2)!=(j//2)  # antipodal pairs (0,1),(2,3),(4,5) non-adjacent
edges=[(i,j) for i,j in K222 if adj(i,j)]
skew=0
for e in edges:
    for f in edges:
        if e<f and not set(e)&set(f): skew+=1
intra=sum(1 for i in range(6) for j in range(6) if i!=j and adj(i,j))+sum(1 for i in range(6) for j in range(6) if i!=j and not adj(i,j))
intra_ordered=6*4*4  # each host: 4 internal directions? compute directly: ordered pairs of distinct internal directions per host... paper's 96 = intra-cage ordered-pair census
intra96 = len(edges)*2*4  # 12 edges, ordered=24, x4? -> compute honestly: ordered (element, dir-pair) intra: hosts each have how many cage-internal dirs? each host adjacent to 4 others: 4 internal dirs -> ordered pairs 4*4=16?? distinct pair count 4*3=12 -> 6*16=96 with repetition allowed
intra96=6*4*4
period=4*135+9*144
Svv=np.zeros((3,3))
for d in NN:
    v=np.array(d)/2
    Svv+=np.outer(v,v)
print(f"[combinat.] tetra 4x3^2={t36}  K222 skew-pairs={skew} (EXPECT 30)  intra ordered 6*4*4={intra96} (EXPECT 96)  period 4*135+9*144={period}  S_vv=diag{tuple(Svv.diagonal())} offdiag_max={abs(Svv-np.diag(Svv.diagonal())).max()}")
