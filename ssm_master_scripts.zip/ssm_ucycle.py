#!/usr/bin/env python3
"""
ssm_ucycle.py -- an explicit U_cycle: the verification schedule constructed.

CANON NOTE: the canonical proton (matter paper) is the extra node trapped in
the tetrahedral void, NOT the four-host cage. The element set below is
cage-centered -- a realization choice read from the formula. Convention A of
the master-equation section reconciles the physics (the interior node
delegates verification to its interface), but the derivation of this element
set from the node is open (limitation 1b).

The two no-gos force a dynamical schedule. Minimal construction: a token
performs a closed tour of the defect's element graph; at each element, once
per round, it sweeps that element's syndrome-INFORMATIVE ordered contexts
(pairs with both directions internal to the defect carry no new syndrome and
are excluded). One operation = one informative context. Computed here, on
the real FCC geometry:

(1) the informative-context census per element and its total;
(2) Euler balance and strong connectivity of the directed element graph
    (existence of the closed tour = existence of the schedule);
(3) an explicit tour (Hierholzer) and the resulting period in operations;
(4) the same uniform rule applied to the point defect -- the normalization
    verdict, reported whichever way it falls.
"""
import numpy as np, itertools as it

d=[]
for x in (1,-1):
    for y in (1,-1): d += [(x,y,0),(x,0,y),(0,x,y)]
NN=[np.array(v)/2 for v in sorted(set(d))]
key=lambda v: tuple(np.round(v,6))

def schedule(elements, internal_of):
    """elements: list of positions; internal_of[e_idx] = set of direction
    indices pointing to another element that is DEFECT-internal for e."""
    E={key(p):i for i,p in enumerate(elements)}
    # informative contexts per element: ordered pairs not both-internal
    ops=[]
    for i,p in enumerate(elements):
        ni=len(internal_of[i])
        ops.append(144 - ni*ni)
    # directed element graph: e -> e+d if that is an element
    adj={i:[] for i in range(len(elements))}
    for i,p in enumerate(elements):
        for v in NN:
            q=key(p+v)
            if q in E: adj[i].append(E[q])
    balanced = all(len(adj[i])==sum(1 for j in adj for t in adj[j] if t==i) for i in adj)
    # strong connectivity (directed graph symmetric here -> simple BFS)
    seen={0}; stack=[0]
    while stack:
        x=stack.pop()
        for y in adj[x]:
            if y not in seen: seen.add(y); stack.append(y)
    connected = len(seen)==len(elements)
    # Hierholzer explicit Euler circuit on the directed element graph
    rem={i:list(adj[i]) for i in adj}
    circuit=[]; stack=[0]
    while stack:
        x=stack[-1]
        if rem[x]: stack.append(rem[x].pop())
        else: circuit.append(stack.pop())
    tour=circuit[::-1]
    return ops, balanced, connected, tour

print("== tetrahedral defect: elements = center + 12 shell (K+1 = 13) ==")
center=np.zeros(3)
elements=[center]+[center+v for v in NN]
# defect-internal directions: the tetrahedral core structure -- for the
# schedule of the MASS formula, internal = directions between the 4 hosts.
# Hosts among the elements: center=(0,0,0) plus 3 shell sites completing the
# NN tetrahedron around the (1/4,1/4,1/4) void:
hosts=[key(center)]+[key(np.array(p)) for p in [(0,.5,.5),(.5,0,.5),(.5,.5,0)]]
internal_of=[]
for i,p in enumerate(elements):
    if key(p) in hosts:
        internal_of.append({j for j,v in enumerate(NN) if key(p+v) in hosts})
    else:
        internal_of.append(set())
ni=[len(x) for x in internal_of]
print(f"internal directions per element: {sorted(ni,reverse=True)[:6]}... (hosts: 3 each)")
ops,bal,conn,tour=schedule(elements, internal_of)
print(f"informative contexts per element: hosts {144-9}, others {144}")
print(f"TOTAL OPERATIONS PER ROUND = {sum(ops)}")
print(f"element tour exists: balanced={bal}, connected={conn}; explicit Euler")
print(f"tour constructed, length {len(tour)-1} moves (movement is free; the")
print(f"period in OPERATIONS is the census above).")

print("\n== point defect under the SAME uniform rule ==")
elements_p=[center]
internal_p=[set()]
ops_p,_,_,_=schedule(elements_p, internal_p)
print(f"point defect operations per round = {sum(ops_p)}")
r = sum(ops)/sum(ops_p)
print(f"orbit ratio tet/point = {sum(ops)}/{sum(ops_p)} = {r}")
print(f"""
VERDICT. The schedule EXISTS and its period is FORCED given the rule:
{sum(ops)} operations per round for the tetrahedral defect -- the published
count as the period of an explicitly constructed local schedule (Euler tour
verified balanced and connected). The same uniform rule gives the series'
published electron (the point defect) {sum(ops_p)}, ratio {r}: THIRD NO-GO --
no single uniform counting rule serves both published species. The electron
is NOT in question (it is defined in the companions); what is open is the
rule's derivation: why the point defect's contexts are syndrome-redundant
(the flag-adjacency computation already shows they are, at the flag level)
while the tetrahedron's external contexts are not -- as a theorem of the
weight-12 checks. [derived: existence of the 1836 schedule; third no-go]""")
