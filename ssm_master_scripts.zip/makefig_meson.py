import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
N,J,h,hz=12,1.0,0.3,0.12
dim=2**N
H=np.zeros((dim,dim))
for st in range(dim):
    dz=dzl=0.0
    for b in range(N):
        zb=1-2*((st>>b)&1); zb1=1-2*((st>>((b+1)%N))&1)
        dz+=zb*zb1; dzl+=zb
    H[st,st]=-J*dz-hz*dzl
    for b in range(N):
        H[st^(1<<b),st]+=-h
ev,V=np.linalg.eigh(H)
Tperm=np.array([((st<<1)|(st>>(N-1)))&(dim-1) for st in range(dim)])
E0=ev[0]; band={}
i=0
while i<dim and ev[i]-E0<5.5:
    j=i
    while j+1<dim and ev[j+1]-ev[i]<1e-9: j+=1
    W=V[:,i:j+1]
    tw,_v=np.linalg.eig(W.conj().T@W[Tperm,:])
    for n in range(len(tw)):
        k=int(round(np.angle(tw[n])*N/(2*np.pi)))%N
        if ev[i]>E0+1e-9 and (k not in band or ev[i]-E0<band[k]): band[k]=ev[i]-E0
    i=j+1
ks=np.array(sorted(band)); om=np.array([band[k] for k in ks])
kk=2*np.pi*ks/N; ka=np.minimum(kk,2*np.pi-kk)
fig,ax=plt.subplots(figsize=(4.6,3.4))
kf=np.linspace(0,np.pi,200)
eps=2*np.sqrt(J**2+h**2-2*J*h*np.cos(kf))
ax.plot(kf,eps,c="#1f77b4",lw=1.5,label="elementary kink $\\varepsilon(k)$ (deconfined)")
sel=(ka>0.3)
ax.plot(ka[sel],om[sel],"s",c="crimson",ms=6,label="meson band (ED, $h_z=0.12$)")
ax.plot(ka[~sel],om[~sel],"o",mfc="none",c="gray",ms=6,label="isolated $k{=}0$ rung (excluded)")
A=np.vstack([np.ones(((ka>0.3)&(ka<1.6)).sum()),ka[(ka>0.3)&(ka<1.6)]**2]).T
c,*_=np.linalg.lstsq(A,om[(ka>0.3)&(ka<1.6)]**2,rcond=None)
ax.plot(kf,np.sqrt(np.maximum(c[0]+c[1]*kf**2,0)),"--",c="crimson",lw=1,
        label="$\\sqrt{m_b^2+v_b^2k^2}$ fit")
ax.set_xlabel("$|k|$"); ax.set_ylabel("$\\omega(k)$")
ax.legend(fontsize=7); fig.tight_layout()
fig.savefig("../figs/fig2_meson.pdf"); print("fig2 written")
