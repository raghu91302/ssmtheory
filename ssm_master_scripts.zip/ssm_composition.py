#!/usr/bin/env python3
"""
ssm_composition.py -- the equation's composition law, tested in the code.

H_eff sums over CHECKS, so verification counts compose by UNION: shared
checks enter once. Test with two tetrahedral-void insertions:
  (A) DISJOINT voids (no shared hosts): structure and Delta k should be
      exactly additive (2 x single insertion);
  (B) ADJACENT voids (sharing two hosts): the union is smaller than the sum
      -- any deviation of Delta k from 2 x (-3) is code-level binding.
"""
import numpy as np, itertools as it

L=2
base=[(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]
sites=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3) for b in base))
S={p:i for i,p in enumerate(sites)}
def wrapd(p,q): return tuple((np.array(q)-np.array(p)+L/2)%L - L/2)
bonds=[]
for i,p in enumerate(sites):
    for j,q in enumerate(sites):
        if j<=i: continue
        dd=np.array(wrapd(p,q))
        if abs(dd@dd-0.5)<1e-9: bonds.append((i,j))
bonds=sorted(bonds); B={b:i for i,b in enumerate(bonds)}; NB=len(bonds)
A=np.zeros((len(sites),NB),np.uint8)
for (u,v),e in B.items(): A[u,e]=A[v,e]=1
voids=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3)
             for b in [(0.5,0,0),(0,0.5,0),(0,0,0.5),(0.5,0.5,0.5)]))
Zc=np.zeros((len(voids),NB),np.uint8)
for oi,cn in enumerate(voids):
    vs=[i for i,p in enumerate(sites) if abs(np.array(wrapd(cn,p))@np.array(wrapd(cn,p))-0.25)<1e-9]
    for i,j in it.combinations(sorted(vs),2):
        if (i,j) in B: Zc[oi,B[(i,j)]]=1
def gf2_rank(M):
    M=M.copy()%2; r=0
    for c in range(M.shape[1]):
        piv=None
        for i in range(r,M.shape[0]):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(M.shape[0]):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
k0=NB-gf2_rank(A)-gf2_rank(Zc)
print(f"vacuum: [[{NB},{k0}]]")

def hosts_of(vd):
    return sorted(i for i,p in enumerate(sites)
                  if abs(np.array(wrapd(vd,p))@np.array(wrapd(vd,p))-3/16)<1e-9)

def double_insert(v1,v2,tag):
    h1,h2=hosts_of(v1),hosts_of(v2)
    shared=set(h1)&set(h2)
    Nq=NB+8
    A2=np.zeros((len(sites)+2,Nq),np.uint8); A2[:len(sites),:NB]=A
    for i,h in enumerate(h1): A2[h,NB+i]=1
    for i,h in enumerate(h2): A2[h,NB+4+i]=1
    A2[len(sites),NB:NB+4]=1
    A2[len(sites)+1,NB+4:NB+8]=1
    tris=[]
    for hh,off in [(h1,0),(h2,4)]:
        for a,b in it.combinations(range(4),2):
            e=(min(hh[a],hh[b]),max(hh[a],hh[b]))
            tris.append((off+a,off+b,B[e]))
    Z2=np.zeros((len(voids)+len(tris),Nq),np.uint8); Z2[:len(voids),:NB]=Zc
    for t,(i,j,e) in enumerate(tris):
        Z2[len(voids)+t,[NB+i,NB+j,e]]=1
    comm=(A2@Z2.T)%2
    rA,rZ=gf2_rank(A2),gf2_rank(Z2)
    k=Nq-rA-rZ
    mod_hosts=len(set(h1)|set(h2))
    print(f"\n[{tag}] shared hosts: {len(shared)}; CSS commutes: {comm.max()==0}")
    print(f"  modified host checks: {mod_hosts}  (sum would be 8; union arithmetic)")
    print(f"  code: [[{Nq},{k}]];  Delta k = {k-k0}  vs additive 2x(-3) = -6"
          f"  ->  {'ADDITIVE' if k-k0==-6 else f'BINDING of {k-k0+6} logical(s)'}")
    return k-k0

d1=double_insert((0.25,0.25,0.25),(0.75,0.75,0.75),"A: disjoint voids")
d2=double_insert((0.25,0.25,0.25),(0.25,0.25,0.75),"B: adjacent voids")
print(f"""
COMPOSITION LAW: H_eff sums over checks, so verification counts compose by
union -- shared checks enter once. Disjoint insertion tests exact additivity
(Delta k = -6, modified checks = 8); shared-host insertion tests the union
correction (modified checks < 8) and any code-level binding (Delta k != -6).
[derived: composition-by-union from the check-sum structure of H_eff;
computed: both insertions above]""")
