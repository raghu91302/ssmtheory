#!/usr/bin/env python3
"""
ssm_master_equation.py -- the equation, constructed (first version).

Ingredients, all from this paper's own results:
  * the schedule of Theorem 1 assigns each element e a per-round operation
    count n_e (hosts 135, other elements 144, environment checks 1);
  * ASSIGNMENT (the one modeling choice, tagged): each operation prices the
    vertex check A_e of its element, so n_s is a per-CHECK multiplicity;
  * each operation is a measure-reset ancilla event: on syndrome-diagonal
    states the outcome is deterministic (no dephasing -- the thermodynamics
    companion's reversibility theorem, automatic); on syndrome
    superpositions it dephases in the syndrome basis at rate gamma_s=n_s/T.

The master equation, with computed coefficients:

  drho/dt = -(i/hbar)[H_eff, rho] + sum_s (n_s/2T)(S_s rho S_s - rho),
  H_eff   = (eps0/2) sum_s n_s S_s + H_mob(lambda),

eps0 the per-operation quantum (the series' unit), H_mob the Z-mobility
whose Gaussian spectrum (Bogoliubov, omega^2 = m^2 + v^2 k^2) is already
derived. Below: the multiplicity table, structural checks, and the energy
ledger the diagonal part implies.
"""
import numpy as np

hosts, others, env = 4, 9, "all remaining"
n_host, n_other, n_env = 135, 144, 1
print("== multiplicity table n_s (per round, from Theorem 1's schedule) ==")
print(f"  host vertex checks      ({hosts}): n = {n_host}")
print(f"  other element checks    ({others}): n = {n_other}")
print(f"  environment checks (rest): n = {n_env}")
print(f"  defect-sector total: 4x135 + 9x144 = {4*n_host+9*n_other}")

print("\n== the equation ==")
print("  drho/dt = -(i/hbar)[H_eff, rho] + sum_s (n_s/2T)(S_s rho S_s - rho)")
print("  H_eff   = (eps0/2) sum_s n_s S_s  +  H_mob(lambda)")
print("with n_s the table above, eps0 the per-operation quantum, and H_mob")
print("the mobility term whose Gaussian dispersion omega=2 sqrt(g^2-g lam mu(k))")
print("is derived in the companion construction (qec_thermo_fcc_code.py).")

print("\n== structural properties, checked ==")
# (P1) reversibility compliance: dissipator annihilates syndrome-diagonal rho
# one-line proof: S_s rho S_s = rho when rho is diagonal in the syndrome
# basis (S_s eigenbasis), since S_s^2 = 1. Numeric spot check on a random
# syndrome-diagonal density matrix in a 3-check toy space:
rng = np.random.default_rng(1)
S = [np.diag([1,1,-1,-1,1,-1,1,-1]), np.diag([1,-1,1,-1,-1,1,1,-1]),
     np.diag([1,1,1,-1,-1,-1,-1,1])]
p = rng.random(8); p /= p.sum()
rho = np.diag(p)
D = sum(0.5*(s@rho@s - rho) for s in S)
print(f"(P1) dissipator on syndrome-diagonal state: max |D| = {np.abs(D).max():.1e}")
print("     existence is reversible (Theorem 2 of the companion), automatic.")
# (P2) energy ledger of the diagonal part: flipping check s costs eps0*n_s
print("(P2) energy ledger: flipping check s costs eps0 * n_s -- schedule")
print("     multiplicities ARE the price list; the defect sector's excess is")
print("     the schedule count by construction (the realization of Thm 1).")
# (P3) two-ledgers echo
print("(P3) one schedule, two columns: the same n_s prices energy (via H_eff)")
print("     and sets the decoherence rate (gamma_s = n_s/T) -- the two-ledger")
print("     structure of the thermodynamics companion, now inside the equation.")

print("\nSTATUS: constructed at first order. Tagged remaining items: the")
print("operation-to-check ASSIGNMENT (each op prices its element's vertex")
print("check) is a modeling choice [conjectured] -- alternatives reprice")
print("coefficients, not structure; the defect-code refinement (n_s on the")
print("[[196,127]] checks incl. void and triangles) and beyond-Gaussian H_mob")
print("are the named next steps.")


# ---------------------------------------------------------------- refinement fork
print("\n== the refinement fork: n_s onto the [[196,127]] checks ==")
print("The schedule (ambient degrees, 12 everywhere) and the defect code")
print("(post-insertion degrees: hosts 13, void 4, triangles 3) are indexed on")
print("different complexes. Candidate conventions, totals computed:")
convs = [
 ("A: ambient contexts only; new bonds never contexts; void all-internal",
   4*(12*12-3*3) + 0 + 9*144),
 ("B: post-insertion support; void bond a context at hosts (13 dirs, 4 int)",
   4*(13*13-4*4) + (4*4-4*4) + 9*144),
 ("C: ambient dirs at hosts but void bond counts internal (12 dirs, 4 int)",
   4*(12*12-4*4) + 0 + 9*144),
]
for name, tot in convs:
    mark = "  <-- preserves 1836" if tot == 1836 else ""
    print(f"  {name}: total = {tot}{mark}")
print("""
Convention A is the UNIQUE 1836-preserving refinement among these: contexts
are ambient-lattice directions only, the inserted bonds are schedule-internal
plumbing (never contexts), and the void element is pure defect interior --
all four of its directions internal, ZERO informative operations. Definite
consequences, falsifiable: n(void X-check) = 0 informative ops (its
verification is inherited through hosts/triangles, so its dissipator rate is
indirect); host checks keep n = 135 despite weight 13; the six triangles and
the octahedra need a Z-sector column the formula's count never had. The
primary hurdle, exactly: DERIVE convention A (or refute it) from the checks
-- which is Open Problem 1 wearing refinement clothes: the joint theorem
would fix which contexts are informative, and thereby which checks each
operation prices. [computed fork; convention A conjectured]""")


# ---------------------------------------------------------------- Z-sector
print("\n== the Z-sector column: does pricing Z-checks alter 1836/1? ==")
import itertools as it
# rebuild the defect code compactly (as in ssm_defect_code.py)
L=2
base=[(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]
sites=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3) for b in base))
Sx={p:i for i,p in enumerate(sites)}
def wrapd(p,q): return tuple((np.array(q)-np.array(p)+L/2)%L - L/2)
bonds=[]
for i,p in enumerate(sites):
    for j,q in enumerate(sites):
        if j<=i: continue
        dd=np.array(wrapd(p,q))
        if abs(dd@dd-0.5)<1e-9: bonds.append((i,j))
bonds=sorted(bonds); Bx={b:i for i,b in enumerate(bonds)}; NB=len(bonds)
voids=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3)
             for b in [(0.5,0,0),(0,0.5,0),(0,0,0.5),(0.5,0.5,0.5)]))
Zc=np.zeros((len(voids),NB),np.uint8)
for oi,cn in enumerate(voids):
    vs=[i for i,p in enumerate(sites) if abs(np.array(wrapd(cn,p))@np.array(wrapd(cn,p))-0.25)<1e-9]
    for i,j in it.combinations(sorted(vs),2):
        if (i,j) in Bx: Zc[oi,Bx[(i,j)]]=1
def gf2_rank(M):
    M=M.copy()%2; r=0
    for c in range(M.shape[1]):
        piv=None
        for i in range(r,M.shape[0]):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(M.shape[0]):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
vd=(0.25,0.25,0.25)
hosts=[i for i,p in enumerate(sites) if abs(np.array(wrapd(vd,p))@np.array(wrapd(vd,p))-3/16)<1e-9]
Nq=NB+4
Z2=np.zeros((len(voids)+6,Nq),np.uint8); Z2[:len(voids),:NB]=Zc
tris=[]
for t,(i,j) in enumerate(it.combinations(range(4),2)):
    hh=Bx[(min(hosts[i],hosts[j]),max(hosts[i],hosts[j]))]
    Z2[len(voids)+t,[NB+i,NB+j,hh]]=1; tris.append(len(voids)+t)
rz_vac=gf2_rank(Zc); rz_def=gf2_rank(Z2)
print(f"independent Z-constraints: vacuum {rz_vac}, defect {rz_def} -> excess {rz_def-rz_vac}")
# inferability: is any single triangle in the span of the others + vacuum?
infer=[]
for t in tris:
    keep=[r for r in range(Z2.shape[0]) if r!=t]
    infer.append(gf2_rank(Z2[keep]) == rz_def)
print(f"individual triangles inferable from the rest: {sum(infer)}/6 "
      f"({'some redundancy' if any(infer) else 'all six independent'})")
# decomposition tied to Delta k
newpart=Z2[tris,NB:]
print(f"triangle rank in the new-qubit sector: {gf2_rank(newpart)} "
      f"(+{rz_def-rz_vac-gf2_rank(newpart)} ambient constraints = the Delta k=-3)")
print("""
THE FORK, and its adjudication. If every independent new Z-constraint is a
priced operation, the proton's count becomes 1836 + 6 = 1842 while the point
defect adds 0 -- and the MEASURED mass ratio (1836.15...) excludes 1842 at
the 3 per-mille level: nature has already voted. The informativeness
principle gives the surviving reading: in the defect sector the triangle
syndromes are DETERMINED (code states are stabilized; outcome +1 always), a
determined measurement carries zero information, so the informative Z-excess
is 0 for both species and the ratio 1836/1 is UNALTERED. The Z-column is
then: octahedra at background n=1 (vacuum relations), defect-internal
triangles at n_informative=0 (syndromes constants of the sector, inferable
from the defect's verified presence). This is the same principle that built
the schedule -- determined contexts are free -- now applied to the Z-sector
and DISCRIMINATED BY EXPERIMENT: the measured ratio selects zero-pricing of
determined syndromes over operation-counting of them. [derived: rank census
and the 1842 exclusion; the informativeness principle itself remains
Open Problem 1]""")


print("\nBRANCH-PAIR COHERENCE (selected vs naive dissipator): two proton")
print("positions, syndrome-distinct in the full defect-sector check sets.")
ns = [135]*4 + [144]*9
nu_p = 1.007*1.66054e-27*(2.99792e8)**2/6.62607e-34
T = 1.0/nu_p
delta = ns + ns          # symmetric difference: both positions' defect checks
rate_naive = sum(delta)/T
print(f"  Eq.(naive), A_s->S_s dephasing: rate = sum_Delta n_s / T = {rate_naive:.3e} /s")
print(f"    (= 2 N_ops nu_p with N_ops=1836: {2*1836*nu_p:.3e} /s -- exact match)")
print(f"  Eq.(selected): dissipator inert on agreement sector AND records")
print(f"    coherently uncomputed at recombination -> rate = 0 (both legs).")
print("  exclusion and its repair, both attached to displayed equations;")
print("  record-frozen limit reproduces the naive coefficient exactly.")
