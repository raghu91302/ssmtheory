#!/usr/bin/env python3
"""
ssm_floquet_strain.py -- F3: does a composite share the elementary cone?
                         F4: the clock map g(l) and its sign.

F3. In the TFIM + lam*XX chain, search the even-parity two-kink sector for a
bound band below the two-kink continuum; if found, compare its (m_b, v_b^2)
against the elementary curve -- one-cone vs collapsed composite hopping.

F4. The candidate map: all couplings scale with the local inverse edge
length, J(x), h(x) ~ s(x) = 1 + Phi(x)/c^2 (Phi < 0 near mass => s < 1 =>
stretched edges, l(x) = l0 (1 - Phi/c^2)). Then the local gap -- and the
clock -- scales as s(x) EXACTLY, reproducing gravitational dilation with the
right sign and coefficient. Verified by ED on a strained twisted ring.
"""
import numpy as np, itertools as it

def dense_H(N, Jp, hp, lam, twist):
    dim = 2**N
    H = np.zeros((dim, dim))
    for st in range(dim):
        dz = 0.0
        for b in range(N):
            zb = 1-2*((st>>b)&1); zb1 = 1-2*((st>>((b+1)%N))&1)
            sgn = -1.0 if (twist and b==N-1) else 1.0
            dz += sgn*Jp[b]*zb*zb1
        H[st,st] = -dz
        for b in range(N):
            H[st^(1<<b), st] += -hp[b]
            if lam: H[st^(1<<b)^(1<<((b+1)%N)), st] += -lam
    return H

def kink_band(N, J, h, lam):
    Jp, hp = np.full(N,J), np.full(N,h)
    Eg = np.linalg.eigvalsh(dense_H(N,Jp,hp,lam,False))[0]
    ev = np.sort(np.linalg.eigvalsh(dense_H(N,Jp,hp,lam,True))[:2*N]) - Eg
    groups=[[ev[0]]]
    for e in ev[1:]:
        (groups[-1].append(e) if e-groups[-1][-1]<1e-8 else groups.append([e]))
    mult=[len(g) for g in groups]; M=1
    while M<len(mult) and mult[M]==2 and M<=N: M+=1
    if M==N and M<len(mult) and mult[M]==1: M+=1
    return np.pi*np.arange(M)/N, np.array([np.mean(groups[n]) for n in range(M)])

# ---------------------------------------------------------------- F3
print("== F3: composite (two-kink) sector vs the elementary cone ==")
N, J, h, lam = 12, 1.0, 0.3, 0.25
kk1, w1 = kink_band(N, J, h, lam)
# even-parity spectrum on the untwisted ring, momentum-resolved (foolproof method)
Jp, hp = np.full(N,J), np.full(N,h)
Hm = dense_H(N,Jp,hp,lam,False)
ev, V = np.linalg.eigh(Hm)
dim = 2**N
Tperm = np.array([((st<<1)|(st>>(N-1)))&(dim-1) for st in range(dim)])
Pperm = np.array([(~st)&(dim-1) for st in range(dim)])
E0 = ev[0]
band2 = {}
i = 0
while i < dim and ev[i]-E0 < 4.0:            # only low spectrum needed
    j = i
    while j+1 < dim and ev[j+1]-ev[i] < 1e-9: j += 1
    W = V[:, i:j+1]
    Tred = W.conj().T @ W[Tperm,:]
    tw, tv = np.linalg.eig(Tred)
    for n in range(len(tw)):
        vec = W @ tv[:,n]
        k = int(round(np.angle(tw[n])*N/(2*np.pi))) % N
        par = np.real(np.vdot(vec, vec[Pperm]))
        if par > 0.5 and ev[i] > E0+1e-9:
            if k not in band2 or ev[i]-E0 < band2[k]:
                band2[k] = ev[i]-E0
    i = j+1
def eps1(q):    # interpolate elementary band (symmetric, dense enough)
    qa = np.minimum(np.abs(q), 2*np.pi-np.abs(q))
    return np.interp(qa, kk1, w1)
print(f"{'k':>8s} {'lowest even w2(k)':>18s} {'2-kink continuum floor':>23s} {'binding':>9s}")
found = []
for k in sorted(band2):
    K = 2*np.pi*k/N
    qs = np.linspace(0, 2*np.pi, 481)
    floor = np.min(eps1(qs) + eps1(K-qs))
    b = floor - band2[k]
    if 0 < k <= N//2:
        print(f"{K:8.4f} {band2[k]:18.6f} {floor:23.6f} {b:9.5f}")
        if b > 1e-4: found.append((K, band2[k]))
if len(found) >= 3:
    Ks = np.array([f[0] for f in found]); Ws = np.array([f[1] for f in found])
    A = np.vstack([np.ones_like(Ks), Ks**2]).T
    c,*_ = np.linalg.lstsq(A, Ws**2, rcond=None)
    m_b, vb2 = np.sqrt(c[0]), c[1]
    m1 = w1[0]; v12 = (w1[1]**2-w1[0]**2)/kk1[1]**2
    print(f"bound band: m_b = {m_b:.4f}, v_b^2 = {vb2:.4f}")
    print(f"elementary: m_1 = {m1:.4f}, v_1^2 = {v12:.4f}")
    print(f"one-cone comparison: v_b^2/v_1^2 = {vb2/v12:.3f}  "
          f"(collapsed-hopping regime would give << 1)")
else:
    print("no bound band below the continuum at this coupling: the composite")
    print("cone test needs engineered binding (longitudinal confinement);")
    print("method stated, computation deferred. [open]")

# ---------------------------------------------------------------- F4
print("\n== F4: the clock map and its sign ==")
print("candidate map: J(x), h(x) ~ s(x) = 1 + Phi/c^2 (all couplings scale")
print("with the local inverse edge length; Phi<0 => s<1 => edges stretched,")
print("dl/l = -Phi/c^2). Then gap(x) = s(x) * gap0 EXACTLY (both couplings")
print("scale), so the clock slows by 1 + Phi/c^2: right sign, right coefficient.")
Phi = -0.02                                   # toy potential well depth (units c=1)
prof = 1 + Phi*0.5*(1+np.cos(2*np.pi*np.arange(N)/N))   # s(x), min at x=0
Jp2, hp2 = J*prof, h*prof
Eg = np.linalg.eigvalsh(dense_H(N,Jp2,hp2,0.0,False))[0]
e1 = np.sort(np.linalg.eigvalsh(dense_H(N,Jp2,hp2,0.0,True))[:1])[0]-Eg
gap0 = 2*(J-h)
pred = (1+Phi)*gap0
print(f"ED gap in the well: {e1:.5f}   local prediction s_min*gap0 = {pred:.5f}")
print(f"rate ratio ED/flat: {e1/gap0:.5f}  vs  1+Phi/c^2 = {1+Phi:.5f}")
print(f"(residual = confinement zero-point, positive, vanishing for wide wells)")
print("SIGN VERDICT: the natural map PASSES -- slower clocks in potential")
print("wells with coefficient 1 + Phi/c^2; requirement (c) reduces to deriving")
print("dl/l = -Phi/c^2 from the companion's sourcing computation. [advanced]")
