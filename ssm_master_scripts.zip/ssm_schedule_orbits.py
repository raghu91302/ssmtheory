#!/usr/bin/env python3
"""
ssm_schedule_orbits.py -- requirement (a): is 1836 an orbit count?

The companion mass formula m_p/m_e = (K+1)K^2 - c_skew*K = 1836 at K = 12
(c_skew = 3) must, if the master equation exists in the strong sense, be the
size of the verification orbit that a natural scheduling rule assigns to the
tetrahedral defect, with the point defect assigned 1. This script builds the
real FCC geometry and (i) verifies which pieces of the formula's anatomy are
genuine lattice counts, (ii) hunts for the geometric identity of the c_skew*K
discount, (iii) counts candidate orbits for both defect species under
explicit rules, reporting failures as plainly as hits.
"""
import numpy as np, itertools as it
from fractions import Fraction

# ---------------------------------------------------------------- geometry
d = []
for x in (1,-1):
    for y in (1,-1):
        d += [(x,y,0),(x,0,y),(0,x,y)]
NN = sorted(set(d))                       # 12 FCC nearest-neighbor steps (x2)
NN = [np.array(v)/2 for v in NN]          # |d|^2 = 1/2, cubic cell = 1
def is_nn(u, v):
    w = u - v
    return abs(w @ w - 0.5) < 1e-9

center = np.zeros(3)
shell = [center + v for v in NN]          # first coordination shell, 12 sites

print("== anatomy of (K+1)K^2 on the real lattice ==")
K = len(NN); print(f"K (coordination) = {K}")
elements = [center] + shell               # K+1 = 13 'elements'
ok = all(sum(1 for v in NN if True) == 12 for e in elements)
raw = 0
for e in elements:
    nbrs = [e + v for v in NN]            # every FCC site has exactly 12 NN
    raw += len(nbrs)**2                   # ordered direction pairs (contexts)
print(f"(K+1)*K^2 = elements x ordered direction-pair contexts = {raw}  "
      f"[formula: {(K+1)*K**2}]")

print("\n== hunting the discount: which natural count equals c_skew*K = 36? ==")
cands = {}
# bonded (triangle-forming) ordered pairs among a site's neighbors
tri_ord = sum(1 for u,v in it.permutations(shell,2) if is_nn(u,v))
cands["ordered bonded shell pairs (per center)"] = tri_ord
cands["unordered bonded shell pairs"] = tri_ord//2
# antipodal pairs among shell (u = -v)
antip = sum(1 for u,v in it.permutations(shell,2) if np.allclose(u,-v))
cands["ordered antipodal shell pairs"] = antip
cands["unordered antipodal pairs"] = antip//2
# collinear ordered pairs per element summed over elements? (same as antipodal per site x 13)
cands["antipodal pairs x (K+1)"] = antip//2*(K+1)
# shell sites' shell-internal neighbors: per shell site, # of its NN that are also shell sites
per = [sum(1 for u in shell if (not np.allclose(u,s)) and is_nn(u,s)) for s in shell]
cands["shell-internal adjacency (sum)"] = sum(per)
# tetrahedral structure: the 4 FCC sites around the void at (1/4,1/4,1/4)
def is_fcc(p):
    q = 2*np.asarray(p)
    return np.allclose(q, np.round(q)) and int(round(q.sum())) % 2 == 0
void = np.array([0.25,0.25,0.25])
grid = [np.array(p) for p in it.product((-0.5,0,0.5,1),repeat=3)]
tet_hosts = [s for s in grid if is_fcc(s) and abs((s-void)@(s-void) - 3/16) < 1e-9]
print(f"tetrahedral void hosts (FCC-filtered): {len(tet_hosts)}  "
      f"{[tuple(h) for h in tet_hosts]}")
mutual = all(is_nn(u,v) for u,v in it.combinations(tet_hosts,2))
print(f"hosts mutually nearest neighbors (NN tetrahedron): {mutual}")
intra = [sum(1 for v in NN if any(np.allclose(h+v,h2) for h2 in tet_hosts)) for h in tet_hosts]
print(f"defect-internal directions per host: {intra}")
cands["intra-defect ordered direction pairs (4 x 3^2)"] = sum(k*k for k in intra)
cands["K x 3"] = K*3
for name, val in sorted(cands.items(), key=lambda kv: kv[1]):
    mark = "  <-- = 36" if val == 36 else ""
    print(f"  {name:44s} = {val}{mark}")

print("\n== candidate scheduling rules: orbit(point) and orbit(tetrahedral) ==")
target = 1836
def report(name, o_pt, o_tet):
    hit = "HIT" if (o_pt == 1 and o_tet == target) else ("ratio!" if o_pt and o_tet/o_pt == target else "fail")
    print(f"  {name:58s} point={o_pt:>5} tet={o_tet:>5}  [{hit}]")

# R1: verify each element against each ordered context; point defect = bare site
report("R1: elements x K^2, no discount", 1*K**2, (K+1)*K**2)
# R2: as R1, minus contexts collinear with a defect bond (antipodal through-pairs)
report("R2: R1 minus antipodal contexts per element", K**2-K//2*2, (K+1)*K**2 - (K+1)*K)
# R3: exclusion rule -- verify elements against ENVIRONMENT contexts only:
#     discount = ordered direction pairs internal to the defect = 4 x 3^2 = 36
disc = sum(k*k for k in intra)
report("R3: (K+1)K^2 minus intra-defect contexts (4x3^2)", 1, (K+1)*K**2 - disc)
# point defect under the same exclusion: a vacancy has NO internal pairs; its
# raw element count is the open half of the rule (must give 1, not K^2)
report("R3 point defect, raw (exclusion gives no discount)", K**2, K**2)
print("\nSTATUS: two of three pieces now have geometric identities. (K+1)K^2 =")
print("1872 is a genuine lattice count. The discount c_skew*K = 36 = 4 x 3^2 is")
print("the number of ordered direction pairs INTERNAL to the defect (the four")
print("hosts form an NN tetrahedron, 3 internal directions each): the schedule")
print("verifies the defect against its environment, and self-contexts are")
print("excluded. OPEN: the normalization -- a scheduling axiom under which the")
print("point defect's orbit is 1 (not K^2), i.e. why the electron is the unit.")
print("That single question is now requirement (a) in its entirety.")


# ---------------------------------------------------------------- F1
print("\n== F1: the normalization axiom -- testing symmetry quotienting ==")
# O_h = 48 signed permutations preserving the FCC NN set; orbits on ordered pairs
import numpy as np, itertools as it
mats = []
for perm in it.permutations(range(3)):
    for signs in it.product((1,-1),repeat=3):
        M = np.zeros((3,3))
        for i,(p,sg) in enumerate(zip(perm,signs)): M[i,p]=sg
        if all(any(np.allclose(M@v,u) for u in NN) for v in NN): mats.append(M)
print(f"site symmetry group order: {len(mats)} (O_h = 48)")
pairs = [(i,j) for i in range(12) for j in range(12)]
def key(v): return tuple(np.round(v,6))
idx = {key(v): i for i,v in enumerate(NN)}
seen, orbits = set(), 0
for (i,j) in pairs:
    if (i,j) in seen: continue
    orbits += 1
    for M in mats:
        seen.add((idx[key(M@NN[i])], idx[key(M@NN[j])]))
print(f"O_h orbits on the point defect's 144 ordered contexts: {orbits}")
print(f"tetrahedral quotient check: 1836 / |T_d| = 1836/24 = {1836/24}")
print("VERDICT: symmetry quotienting is REFUTED as the normalization mechanism")
print("on both ends -- it gives the point defect", orbits, "classes (not 1), and")
print("1836 is not even divisible by |T_d|, so the tetrahedral count is a FULL")
print("census minus internal contexts, not a symmetry quotient.")
print("Surviving candidate [conjectured] -- the syndrome-response axiom: one")
print("operation per syndrome-DISTINGUISHABLE (element, context) class. A point")
print("defect's violated-check pattern is context-independent (one class -> one")
print("op); the tetrahedral defect's four-host structure makes every external")
print("context distinguishable (full census) while internal contexts probe")
print("nothing (the -36). Deriving distinguishability from the actual weight-12")
print("checks is the remaining computation of requirement (a).")
