import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
d=[]
for x in (1,-1):
    for y in (1,-1): d += [(x,y,0),(x,0,y),(0,x,y)]
NN=[np.array(v)/2 for v in sorted(set(d))]
key=lambda v: tuple(np.round(v,6))
center=np.zeros(3)
els=[center]+[center+v for v in NN]
hosts={key(center)}|{key(np.array(p)) for p in [(0,.5,.5),(.5,0,.5),(.5,.5,0)]}
# 2D layout: project (x+0.35z, y+0.35z)
P=lambda p:(p[0]+0.35*p[2], p[1]+0.35*p[2])
fig,ax=plt.subplots(figsize=(5.4,5.0))
for i,p in enumerate(els):
    for j,q in enumerate(els):
        if j<=i: continue
        w=q-p
        if abs(w@w-0.5)<1e-9:
            (x1,y1),(x2,y2)=P(p),P(q)
            internal = key(p) in hosts and key(q) in hosts
            ax.plot([x1,x2],[y1,y2], c=("crimson" if internal else "#bbb"),
                    lw=(2.2 if internal else 0.8), zorder=1)
for p in els:
    x,y=P(p); h=key(p) in hosts
    ax.scatter([x],[y], s=(340 if h else 200), c=("crimson" if h else "#4477aa"),
               edgecolors="k", zorder=3)
    ax.annotate("135" if h else "144", (x,y), ha="center", va="center",
                color="w", fontsize=8, fontweight="bold", zorder=4)
ax.annotate("hosts (NN tetrahedron):\n$144-3^2=135$ ops each", (0.02,0.97),
            xycoords="axes fraction", va="top", fontsize=9, color="crimson")
ax.annotate("other elements: 144 ops each\ntotal $4\\times135+9\\times144=1836$",
            (0.02,0.06), xycoords="axes fraction", fontsize=9)
ax.set_aspect("equal"); ax.axis("off")
ax.set_title("The verification schedule: element graph and forced period", fontsize=10)
fig.tight_layout(); fig.savefig("../figs/fig1_schedule.pdf")
print("fig written")
