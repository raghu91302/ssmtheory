#!/usr/bin/env python3
"""
ssm_electron_code.py -- the electron realized in the code: both candidates.

The series defines the electron as the point defect; this script constructs
the two candidate microscopic realizations inside the actual [[192,130,3]]
code and lets CSS consistency force their structure, exactly as was done for
the proton (tetrahedral-void node, [[196,127,3]], Delta k = -3):

  (V) VACANCY: remove one node and its 12 bonds;
  (O) OCTAHEDRAL-VOID NODE: insert one node in an octahedral void, bonded to
      its 6 hosts (the octahedral counterpart of the proton's trap).

For each: forced check structure, commutation, [[n,k,.]], Delta k, the
intra-defect ordered-pair count (the skew analogue, falsifier I2), and the
uniform-rule census score.
"""
import numpy as np, itertools as it

L=2
base=[(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]
sites=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3) for b in base))
def wrapd(p,q): return tuple((np.array(q)-np.array(p)+L/2)%L - L/2)
bonds=[]
for i,p in enumerate(sites):
    for j,q in enumerate(sites):
        if j<=i: continue
        dd=np.array(wrapd(p,q))
        if abs(dd@dd-0.5)<1e-9: bonds.append((i,j))
bonds=sorted(bonds); B={b:i for i,b in enumerate(bonds)}; NB=len(bonds)
A=np.zeros((len(sites),NB),np.uint8)
for (u,v),e in B.items(): A[u,e]=A[v,e]=1
voids=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3)
             for b in [(0.5,0,0),(0,0.5,0),(0,0,0.5),(0.5,0.5,0.5)]))
def oct_vertices(cn):
    return sorted(i for i,p in enumerate(sites) if abs(np.array(wrapd(cn,p))@np.array(wrapd(cn,p))-0.25)<1e-9)
Zc=np.zeros((len(voids),NB),np.uint8)
for oi,cn in enumerate(voids):
    for i,j in it.combinations(oct_vertices(cn),2):
        if (i,j) in B: Zc[oi,B[(i,j)]]=1
def gf2_rank(M):
    M=M.copy()%2; r=0
    for c in range(M.shape[1]):
        piv=None
        for i in range(r,M.shape[0]):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(M.shape[0]):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
print(f"parent: [[{NB},{NB-gf2_rank(A)-gf2_rank(Zc)},3]]")

# ---------------------------------------------------------------- (V) vacancy
print("\n== (V) vacancy: remove node 0 and its 12 bonds ==")
v0=0
keep=[e for e,(i,j) in enumerate(bonds) if i!=v0 and j!=v0]
Av=np.delete(A[:,keep],v0,axis=0)
Zv=Zc[:,keep]
comm=(Av@Zv.T)%2
print(f"qubits: {len(keep)}; bare CSS consistency after removal: {comm.max()==0}")
if comm.max()==0:
    rA,rZ=gf2_rank(Av),gf2_rank(Zv)
    kv=len(keep)-rA-rZ
    print(f"vacancy code: [[{len(keep)},{kv},.]]  (ranks {rA},{rZ});  "
          f"Delta k = {kv-130}; checks touched: 12 neighbors (w 11) + 6 octahedra (w 8) + 1 removed")
else:
    print("bare removal breaks CSS -- check surgery required (reported, not forced here)")
print("intra-defect ordered pairs (single removed node, no internal bonds): 0")

# ---------------------------------------------------------------- (O) octahedral node
print("\n== (O) octahedral-void node: insert at (0.5,0,0), 6 host bonds ==")
cn=(0.5,0.0,0.0)
hosts=oct_vertices(cn)
print(f"hosts: {len(hosts)}; host-host adjacency (octahedron edges): "
      f"{sum(1 for i,j in it.combinations(hosts,2) if (min(i,j),max(i,j)) in B)} of 15 pairs")
Nq=NB+6
Ao=np.zeros((len(sites)+1,Nq),np.uint8); Ao[:len(sites),:NB]=A
for i,h in enumerate(hosts): Ao[h,NB+i]=1
Ao[len(sites),NB:]=1                       # void X-check, weight 6
edges=[(i,j) for i,j in it.combinations(range(6),2)
       if (min(hosts[i],hosts[j]),max(hosts[i],hosts[j])) in B]
Zo=np.zeros((len(voids)+len(edges),Nq),np.uint8); Zo[:len(voids),:NB]=Zc
for t,(i,j) in enumerate(edges):
    hh=B[(min(hosts[i],hosts[j]),max(hosts[i],hosts[j]))]
    Zo[len(voids)+t,[NB+i,NB+j,hh]]=1      # triangle Z per octahedron edge
comm=(Ao@Zo.T)%2
print(f"forced structure: 6 host X-checks w13, void X-check w6, {len(edges)} triangle Z w3; "
      f"all commute: {comm.max()==0}")
rA,rZ=gf2_rank(Ao),gf2_rank(Zo)
ko=Nq-rA-rZ
print(f"octahedral-node code: [[{Nq},{ko},.]]  (ranks {rA},{rZ});  Delta k = {ko-130}")
# Delta-k mechanism check: ambient-constraint count (tetra gave 3 = |Dk|)
newpart=Zo[len(voids):,NB:]
rn=gf2_rank(newpart)
amb=(gf2_rank(Zo)-gf2_rank(Zc))-rn
print(f"triangle rank split: {rn} new-qubit sector + {amb} ambient  "
      f"(mechanism predicts |Delta k| = ambient = {amb}; measured {130-ko})")
intra=[sum(1 for j2 in hosts if j2!=h and (min(h,j2),max(h,j2)) in B) for h in hosts]
print(f"defect-internal host directions: {intra}  ->  intra-defect ordered pairs "
      f"= {sum(x*x for x in intra)}  (skew-analogue census, falsifier I2)")
print(f"tetrahedral comparison: Delta k=-3 (=ambient constraints 3), intra 36 = 12x3;")
print(f"octahedral: Delta k=-6 (=ambient {amb}), intra 96 = 12x8, NOT 12x6:")
print(f"the Delta-k MECHANISM (ambient constraints) generalizes; the numerical")
print(f"coincidence Delta k = -intra/K does NOT extend beyond the tetrahedron.")
print("""
STATUS: both candidate electrons are now constructed objects with forced CSS
structure and computed parameters. Which realization is the canonical point
defect of the matter paper is a canon question decided there, not here; the
joint theorem's electron pillar attaches to whichever it is. [derived:
both realizations; canon selection open]""")


# ---------------------------------------------------------------- NN lemma
print("\n== rigidity lemma: is any pure NN re-pairing possible? ==")
nn_pairs = sum(1 for i,p in enumerate(sites) for j,q in enumerate(sites) if j>i
               and abs((np.array(wrapd(p,q))@np.array(wrapd(p,q)))-0.5)<1e-9)
print(f"NN-distance pairs: {nn_pairs}; bonds in the code: {NB}; "
      f"NN graph complete: {nn_pairs==NB}")
print("""LEMMA (derived): the vacuum's NN graph is complete -- every pair at bond
distance is already bonded -- so no layer-2 re-pairing exists within the NN
class. A dislocation core therefore necessarily carries STRAINED bonds
(modified lengths, hence modified couplings via the clock map): the electron
is a bond-length defect, not a bond-existence defect. Charge program
[conjectured, three rhymes]: Burgers vector in the 4-bond translational
sector -> quantization (Burgers vectors are lattice vectors), conservation
(dislocation lines cannot end), Coulomb form (1/r elastic far field in the
EM-assigned sector). Candidate home: the minimal loop threading a
tetravoid's edge skeleton (proton and electron sharing one void, node vs
circulation -- hydrogen as the bound pair) vs a generic {111} glide loop;
canon selects.""")
