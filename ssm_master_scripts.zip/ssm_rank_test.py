#!/usr/bin/env python3
"""User-proposed rank test: informative ops = rank excess of context probe
vectors over the vacuum check span. Run verbatim, builders supplied."""
import numpy as np, itertools as it
try:
    import galois
    GF = galois.GF(2)
    HAVE = True
except Exception:
    HAVE = False

L=2
base=[(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]
sites=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3) for b in base))
def wrapd(p,q): return tuple((np.array(q)-np.array(p)+L/2)%L - L/2)
bonds=[]
for i,p in enumerate(sites):
    for j,q in enumerate(sites):
        if j<=i: continue
        dd=np.array(wrapd(p,q))
        if abs(dd@dd-0.5)<1e-9: bonds.append((i,j))
bonds=sorted(bonds); B={b:i for i,b in enumerate(bonds)}; NB=len(bonds)

def get_vacuum_parity_check_matrix():
    A=np.zeros((len(sites),NB),np.uint8)
    for (u,v),e in B.items(): A[u,e]=A[v,e]=1
    voids=sorted(set(tuple((np.array(c)+np.array(b))%L) for c in it.product(range(L),repeat=3)
                 for b in [(0.5,0,0),(0,0.5,0),(0,0,0.5),(0.5,0.5,0.5)]))
    Z=np.zeros((len(voids),NB),np.uint8)
    for oi,cn in enumerate(voids):
        vs=[i for i,p in enumerate(sites) if abs(np.array(wrapd(cn,p))@np.array(wrapd(cn,p))-0.25)<1e-9]
        for i,j in it.combinations(sorted(vs),2):
            if (i,j) in B: Z[oi,B[(i,j)]]=1
    return np.vstack([A,Z])

def element_context_rows(elems):
    rows=[]
    for e in elems:
        eb=[B[(min(e,q),max(e,q))] for q in range(len(sites)) if (min(e,q),max(e,q)) in B]
        for b1,b2 in it.product(eb,repeat=2):
            v=np.zeros(NB,np.uint8); v[b1]^=1; v[b2]^=1
            rows.append(v)
    return np.array(rows,np.uint8)

def get_point_defect_contexts():
    return element_context_rows([0])                      # 144 x 192

def gf2_rank(M):
    M=M.copy().astype(np.uint8)%2; r=0
    for c in range(M.shape[1]):
        piv=None
        for i in range(r,M.shape[0]):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(M.shape[0]):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
rank = (lambda M: int(np.linalg.matrix_rank(GF(M)))) if HAVE else gf2_rank

H_vacuum = get_vacuum_parity_check_matrix()
vacuum_rank = rank(H_vacuum)
print(f"Vacuum Rank: {vacuum_rank}")
contexts_matrix = get_point_defect_contexts()
combined_rank = rank(np.vstack([H_vacuum, contexts_matrix]))
informative_operations = combined_rank - vacuum_rank
print(f"Combined Rank: {combined_rank}")
print(f"Informative Operations (Point Defect): {informative_operations}")
if informative_operations == 1:
    print("SUCCESS: 143 contexts are syndrome-redundant. The electron is 1 unit.")
else:
    print("FAILED: The rank did not collapse to 1. The checks do not hide the contexts.")

# same encoding, tetrahedral cage (13 elements, and convention-A exclusion)
cage=[0]+[q for q in range(len(sites)) if (0,q) in B or (q,0) in B]
tet_ctx=element_context_rows(cage)
exc_t = rank(np.vstack([H_vacuum, tet_ctx])) - vacuum_rank
print(f"\nSame encoding, tetrahedral cage (13 elements): informative = {exc_t}")
print(f"ratio under this encoding: {exc_t}/{informative_operations}"
      f" = {exc_t/max(informative_operations,1):.2f}   (target 1836)")

# per-sector control: excess over the X-check span alone (no sector mixing)
A_only = H_vacuum[:len(sites)]
rX = rank(A_only)
excX = rank(np.vstack([A_only, contexts_matrix])) - rX
print(f"\nper-sector control (X-span only, rank {rX}): point-defect excess = {excX}")
print("""
VERDICT (third no-go): the linear-parity formalization of informativeness --
informative operations as the rank excess of context probe vectors over the
check span -- is refuted: it yields (electron, proton-cage) = (10, 100),
ratio 10, against the required (1, 1836). The check span hides exactly ONE
dimension of the electron's pair space (the vertex check itself), not 143.
The redundancy the joint theorem needs is therefore NOT linear-algebraic:
'syndrome-redundant' must mean outcome-DETERMINED on the defect state -- a
state-conditional, nonlinear notion -- and candidate formalizations of Open
Problem 1 must be of that kind. [derived: third no-go]""")
