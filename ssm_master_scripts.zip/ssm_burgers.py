#!/usr/bin/env python3
"""
ssm_burgers.py -- the holonomy dichotomy: a positive candidate account of the
electron's unit.

Claim to verify on the lattice geometry:
 (L) a dislocation loop's displacement field has quantized holonomy: the
     closure failure of ANY circuit equals b x (linking number) -- one
     measurement returns the loop's entire identity, circuit-independent;
 (N) a trapped node (interstitial / center of dilation) has ZERO holonomy:
     every circuit closes -- no single measurement certifies it, so its
     verification must be extensive (the census).

Loop field: u(x) = b * Omega(x) / 4pi, Omega = solid angle of the loop at x
(Van Oosterom--Strackee over a fan triangulation of a spanning surface).
Node field: u(x) = eps * rhat / r^2 (curl-free dilation).
"""
import numpy as np

def solid_angle(x, loop):
    """signed solid angle of closed polygon `loop` (Mx3) at point x."""
    c = loop.mean(axis=0)
    tot = 0.0
    M = len(loop)
    for i in range(M):
        tri = [c, loop[i], loop[(i+1) % M]]
        R = [np.asarray(p) - x for p in tri]
        r = [np.linalg.norm(v) for v in R]
        num = np.dot(R[0], np.cross(R[1], R[2]))
        den = (r[0]*r[1]*r[2] + np.dot(R[0], R[1])*r[2]
               + np.dot(R[1], R[2])*r[0] + np.dot(R[2], R[0])*r[1])
        tot += 2.0 * np.arctan2(num, den)
    return tot

rng = np.random.default_rng(7)
n = np.array([1.0, 1.0, 1.0]) / np.sqrt(3)
t1 = np.array([1.0, -1.0, 0.0]) / np.sqrt(2)
t2 = np.cross(n, t1)
R = 0.42
loop = np.array([R*np.cos(th)*t1 + R*np.sin(th)*t2
                 for th in np.linspace(0, 2*np.pi, 64, endpoint=False)])
b = np.array([0.5, 0.5, 0.0])          # Burgers vector (a lattice step)

def circuit(center, radius, axis, m=48):
    a1 = np.array([1.0, 0, 0]);  a1 -= axis*np.dot(a1, axis)
    if np.linalg.norm(a1) < 1e-8: a1 = np.array([0, 1.0, 0]) - axis*axis[1]
    a1 /= np.linalg.norm(a1); a2 = np.cross(axis, a1)
    return [center + radius*(np.cos(th)*a1 + np.sin(th)*a2)
            for th in np.linspace(0, 2*np.pi, m, endpoint=False)]

def loop_closure(pts):
    """closure failure = b x (number of spanning-surface crossings, signed).
    Omega is single-valued (principal), so around a closed circuit the raw
    increments sum to zero; the multivalued displacement gains 4pi at each
    surface crossing, detected as a jump |d| > 2pi. Counting jumps gives the
    linking number, and the closure failure is b times it."""
    om = np.array([solid_angle(p, loop) for p in pts])
    d = np.diff(np.append(om, om[0]))
    jumps = np.round(d / (4*np.pi)).astype(int)
    assert np.abs(d - 4*np.pi*jumps).max() < 2*np.pi, "circuit under-resolved"
    return -b * jumps.sum()

def node_closure(pts, eps=0.3):
    u = lambda p: eps * p / np.linalg.norm(p)**3
    us = np.array([u(p) for p in pts])
    return (np.roll(us, -1, axis=0) - us).sum(axis=0)

print("== (L) dislocation loop: holonomy of assorted circuits ==")
rim1, rim2 = 0.42*t1, 0.42*t2          # points on the loop
ax_tilt = (t2 + 0.5*n); ax_tilt /= np.linalg.norm(ax_tilt)
cases = [("linking, tight",    circuit(rim1, 0.22, t2, 96)),
         ("linking, wide",     circuit(rim1, 0.38, t2, 96)),
         ("linking, tilted",   circuit(rim1, 0.30, ax_tilt, 96)),
         ("linking, other rim",circuit(rim2, 0.28, t1, 96)),
         ("non-linking, coplanar", circuit(0.05*n, 0.60, n, 96)),
         ("non-linking, far",  circuit(3.0*n + 2.0*t2, 0.70, t1, 96))]
okL = True
for name, pts in cases:
    cl = loop_closure(pts)
    k = round(np.dot(cl, b) / np.dot(b, b))
    res = np.linalg.norm(cl - k*b)
    okL &= res < 1e-6
    print(f"  {name:18s}: closure = {k:+d} x b   (residual {res:.2e})")
print(f"holonomy quantized and circuit-independent: {okL}")

print("\n== (N) trapped node (dilation center): same circuits ==")
okN = True
for name, pts in cases:
    cl = node_closure(pts)
    okN &= np.linalg.norm(cl) < 1e-9
    print(f"  {name:18s}: closure = {np.linalg.norm(cl):.2e}")
print(f"node holonomy identically zero: {okN}")

print("""
DICHOTOMY (computed): the loop's identity -- its Burgers vector -- is
returned in full by ONE holonomy measurement, whose outcome is a homology
invariant (any linking circuit, same answer; non-linking, zero). The node
has no holonomy: no single closed measurement certifies it, and its
verification must be extensive. CANDIDATE AXIOM [conjectured]: mass counts
the undetermined certification outcomes per cycle. Under it: electron
(one invariant, one outcome) = 1; trapped node (no invariant, extensive
verification) = the census. The joint theorem of Open Problem 1 then
reduces to deriving this certification axiom from the check structure.""")
