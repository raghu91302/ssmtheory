#!/usr/bin/env python3
"""M/E/I D4 -- The D4 code distance is exactly 3, not merely at least 3.

Script 03 shows d >= 3 by ruling out every weight-1 and weight-2 vector.
This script closes the gap from above.  It shows that the 4096 triangles
of the D4 lattice at L = 4 are all weight-3 logical operators, so d = 3.

The argument is short:

  1. Every triangle of nearest-neighbor bonds is a closed loop, so it
     meets each vertex star in an even number of edges.  It therefore
     lies in ker(H_Z).
  2. No triangle lies in the row space of H_X (the void stabilizers have
     weight 24 and their span contains no weight-3 vector here), so each
     triangle is a nontrivial logical operator, not a stabilizer.
  3. Hence d_Z <= 3.  With d >= 3 from script 03, d = 3 exactly.

The same holds for FCC in Part I, where the 256 triangles play the same
role.  The distance is set by the smallest closed loop in the lattice
and does not grow with L.  Raising the distance therefore requires
adding face stabilizers, which is a change of code, not a change of L.

Requires numpy.  Runs in a few seconds at L = 4.
"""

import itertools
import time
import numpy as np


# --------------------------------------------------------------- geometry

def nn_displacements(dim):
    out = []
    for i, j in itertools.combinations(range(dim), 2):
        for si in (1, -1):
            for sj in (1, -1):
                d = [0] * dim
                d[i], d[j] = si, sj
                out.append(tuple(d))
    return out


def axis_displacements(dim):
    out = []
    for i in range(dim):
        for s in (1, -1):
            d = [0] * dim
            d[i] = s
            out.append(tuple(d))
    return out


def build(L, dim):
    """Vertices, edges and void-stabilizer supports of the D_dim code."""
    vidx = {}
    for x in itertools.product(range(L), repeat=dim):
        if sum(x) % 2 == 0:
            vidx[x] = len(vidx)

    eidx = {}
    for v, u in vidx.items():
        for d in nn_displacements(dim):
            nb = tuple((v[k] + d[k]) % L for k in range(dim))
            if nb in vidx:
                key = (min(u, vidx[nb]), max(u, vidx[nb]))
                if key[0] != key[1] and key not in eidx:
                    eidx[key] = len(eidx)

    voids = []
    for x in itertools.product(range(L), repeat=dim):
        if sum(x) % 2 == 1:
            nbs = [vidx[nb] for nb in
                   (tuple((x[k] + d[k]) % L for k in range(dim))
                    for d in axis_displacements(dim)) if nb in vidx]
            if len(nbs) == 2 * dim:
                voids.append(nbs)
    return vidx, eidx, voids


def matrices(vidx, eidx, voids):
    n = len(eidx)
    HZ = np.zeros((len(vidx), n), np.int8)
    for (a, b), i in eidx.items():
        HZ[a, i] ^= 1
        HZ[b, i] ^= 1
    HX = np.zeros((len(voids), n), np.int8)
    for oi, nbs in enumerate(voids):
        s = set(nbs)
        for (a, b), i in eidx.items():
            if a in s and b in s:
                HX[oi, i] = 1
    return HZ, HX


def rref(M):
    M = M.copy() % 2
    rows, cols = M.shape
    piv, r = [], 0
    for c in range(cols):
        nz = np.nonzero(M[r:, c])[0]
        if len(nz) == 0:
            continue
        p = r + nz[0]
        M[[r, p]] = M[[p, r]]
        for row in np.nonzero(M[:, c])[0]:
            if row != r:
                M[row] ^= M[r]
        piv.append(c)
        r += 1
        if r == rows:
            break
    return M[:r], piv


def triangles(eidx, nverts):
    adj = {i: set() for i in range(nverts)}
    for (a, b) in eidx:
        adj[a].add(b)
        adj[b].add(a)
    out = set()
    for (a, b) in eidx:
        for c in adj[a] & adj[b]:
            out.add(tuple(sorted((a, b, c))))
    return sorted(out)


# ------------------------------------------------------------------- main

def run(L, dim, label, expect_tri):
    t0 = time.time()
    vidx, eidx, voids = build(L, dim)
    HZ, HX = matrices(vidx, eidx, voids)
    n = len(eidx)
    tris = triangles(eidx, len(vidx))
    print("\n%s at L = %d" % (label, L))
    print("   vertices %d, qubits %d, void stabilizers %d"
          % (len(vidx), n, len(voids)))
    print("   triangles: %d   [expected %d]" % (len(tris), expect_tri))
    assert len(tris) == expect_tri

    RX, pivX = rref(HX)
    RZ, pivZ = rref(HZ)
    k = n - len(RZ) - len(RX)
    print("   rank(H_Z) = %d, rank(H_X) = %d, k = %d"
          % (len(RZ), len(RX), k))

    def reduce_by(R, piv, v):
        v = v.copy() % 2
        for i, p in enumerate(piv):
            if v[p]:
                v ^= R[i]
        return v

    in_kernel = 0
    logical = 0
    for t in tris:
        v = np.zeros(n, np.int8)
        for a, b in itertools.combinations(t, 2):
            v[eidx[(min(a, b), max(a, b))]] = 1
        if not (HZ.dot(v) % 2).any():
            in_kernel += 1
        if reduce_by(RX, pivX, v).any():
            logical += 1

    print("   triangles in ker(H_Z):            %d of %d" % (in_kernel, len(tris)))
    print("   triangles NOT in rowspace(H_X):   %d of %d" % (logical, len(tris)))
    assert in_kernel == len(tris)
    assert logical == len(tris)
    print("   => every triangle is a weight-3 logical operator")
    print("   => d_Z <= 3; with d >= 3 from script 03, d = 3 EXACTLY")
    print("   [%.1fs]" % (time.time() - t0))
    return 3


def main():
    print("=" * 74)
    print("Exact minimum distance of the void codes")
    print("=" * 74)
    run(4, 3, "FCC code (Part I)", 256)
    run(4, 4, "D4 code", 4096)
    print("\nBoth codes have d = 3 exactly. The distance is the length of the")
    print("shortest closed loop of nearest-neighbor bonds and is independent")
    print("of L, so larger lattices raise the rate but never the distance.")
    print("\nAll distance checks passed.")


if __name__ == '__main__':
    main()
