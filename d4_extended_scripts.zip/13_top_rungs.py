#!/usr/bin/env python3
"""M/E/I -- The final rungs: 3-cell qubits, the top class, and the
pre-registered Higgs confrontation.

The D4 lattice's Delaunay decomposition is the 16-cell honeycomb
{3,3,4,3}: at L = 4, exactly 384 cross-polytope 4-cells (128 centered
at odd integer points, 256 at half-odd points), whose 16 tetrahedral
facets each are shared pairwise -- 384 x 16 / 2 = 3072 = the tetrahedron
count, closing the complex.

RUNG 3: qubits on the 3072 tetrahedra; Z-stabilizers on the 4096
triangles (incidence: each triangle in exactly 3 tets); X-stabilizers
on the 384 16-cells. Prediction: k = dim H_3(T^4) = 4.

RUNG 4 (top): qubits on the 384 16-cells; Z-stabilizers on tetrahedra
(each a weight-2 row: the two cells sharing it). Prediction: k = 1,
the unique logical being the fundamental class (all-ones, weight 384)
-- the extensive, spacetime-filling object: the condensate slot.

PRE-REGISTERED CONFRONTATION (rule fixed before any comparison):
the validated cell-count functional C_x = E_s x C_s, with counts taken
as the induced-subcomplex cell counts, extended to the fundamental
class by taking the support to be the entire complex. We then report
every per-site cell invariant of the complex and every pairwise
product, against the target C_H = K^2(K^3 - D^3) = 244,944 = 2^4 3^7 7.
"""
import numpy as np
import time
from itertools import product, combinations

L = 4
t0 = time.time()
E4 = [tuple(1 if k == i else 0 for k in range(4)) for i in range(4)]


def gen_nn():
    nn = []
    for i in range(4):
        for j in range(i + 1, 4):
            for si in (-1, 1):
                for sj in (-1, 1):
                    d = [0, 0, 0, 0]
                    d[i], d[j] = si, sj
                    nn.append(tuple(d))
    return nn


NN = gen_nn()
vidx = {}
for x in product(range(L), repeat=4):
    if sum(x) % 2 == 0:
        vidx[x] = len(vidx)
adj = {u: set() for u in range(len(vidx))}
for v in vidx:
    for d in NN:
        nb = tuple((v[k] + d[k]) % L for k in range(4))
        if nb in vidx:
            adj[vidx[v]].add(vidx[nb])
            adj[vidx[nb]].add(vidx[v])

# triangles and tetrahedra
tri_idx = {}
for a in adj:
    for b, c in combinations(sorted(adj[a]), 2):
        if b > a and c > a and c in adj[b]:
            tri_idx[frozenset((a, b, c))] = len(tri_idx)
tet_idx = {}
tets = []
for a in adj:
    for b, c in combinations(sorted(adj[a]), 2):
        if not (b > a and c > a and c in adj[b]):
            continue
        for d in sorted(adj[a] & adj[b] & adj[c]):
            if d > c:
                tet_idx[frozenset((a, b, c, d))] = len(tets)
                tets.append((a, b, c, d))
n3 = len(tets)
print(f"complex: V={len(vidx)}, tri={len(tri_idx)}, tet={n3}")

# ---- 16-cells of the honeycomb -------------------------------------
cells = []
# odd-centered
for w in product(range(L), repeat=4):
    if sum(w) % 2 == 1:
        pairs = []
        ok = True
        for i in range(4):
            pp = tuple((w[k] + E4[i][k]) % L for k in range(4))
            pm = tuple((w[k] - E4[i][k]) % L for k in range(4))
            if pp not in vidx or pm not in vidx:
                ok = False
                break
            pairs.append((vidx[pp], vidx[pm]))
        if not ok:
            continue
        fs = []
        for s in product((0, 1), repeat=4):
            quad = frozenset(pairs[i][s[i]] for i in range(4))
            fs.append(tet_idx[quad])
        cells.append(fs)
n_odd = len(cells)
# half-odd-centered: h = a + (1/2,...); vertices h +- 1/2 per coord
for a4 in product(range(L), repeat=4):
    verts = []
    ok = True
    for s in product((0, 1), repeat=4):   # +1/2 if s=1 else -1/2
        p = tuple((a4[k] + s[k]) % L for k in range(4))
        if sum(p) % 2 == 0:
            if p not in vidx:
                ok = False
                break
            verts.append((s, vidx[p]))
    if not ok or len(verts) != 8:
        continue
    # antipodal pairs: s and its complement
    pairs = []
    used = set()
    for s, pid in verts:
        comp = tuple(1 - x for x in s)
        key = tuple(sorted((s, comp)))
        if key in used:
            continue
        used.add(key)
        other = next(q for t2, q in verts if t2 == comp)
        pairs.append((pid, other))
    fs = []
    good = True
    for sel in product((0, 1), repeat=4):
        quad = frozenset(pairs[i][sel[i]] for i in range(4))
        if quad not in tet_idx:
            good = False
            break
        fs.append(tet_idx[quad])
    if good:
        cells.append(fs)
n_half = len(cells) - n_odd
n4 = len(cells)
print(f"16-cells: {n_odd} odd-centered + {n_half} half-centered = {n4} "
      f"(honeycomb prediction: 128 + 256 = 384)")
inc = np.zeros(n3, np.int32)
for fs in cells:
    for t in fs:
        inc[t] += 1
print(f"each tetrahedron in exactly 2 cells: "
      f"{'YES' if (inc == 2).all() else 'NO'}")

# ---- RUNG 3 ---------------------------------------------------------
HZ3 = np.zeros((len(tri_idx), n3), np.uint8)
for ti, quad in enumerate(tets):
    for t in combinations(quad, 3):
        HZ3[tri_idx[frozenset(t)], ti] = 1
tri_deg = HZ3.sum(axis=1)
print(f"\nRUNG 3: each triangle in exactly 3 tets: "
      f"{'YES' if (tri_deg == 3).all() else 'NO'}")
HX3 = np.zeros((n4, n3), np.uint8)
for ci, fs in enumerate(cells):
    for t in fs:
        HX3[ci, t] = 1
assert not (HX3 @ HZ3.T % 2).any()
print("CSS valid")


def rref(M):
    M = M.copy()
    r = 0
    for c in range(M.shape[1]):
        idx = np.nonzero(M[r:, c])[0]
        if idx.size == 0:
            continue
        p = r + idx[0]
        M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        M[hit] ^= M[r]
        r += 1
        if r == M.shape[0]:
            break
    return M[:r]


R3Z = rref(HZ3)
R3X = rref(HX3)
k3 = n3 - R3Z.shape[0] - R3X.shape[0]
print(f"[[{n3}, {k3}]]  rank(H_Z)={R3Z.shape[0]}, "
      f"rank(H_X)={R3X.shape[0]}   (prediction k = dim H_3 = 4)  "
      f"[{time.time()-t0:.0f}s]")

# ---- RUNG 4 (top) ---------------------------------------------------
HZ4 = np.zeros((n3, n4), np.uint8)
for ci, fs in enumerate(cells):
    for t in fs:
        HZ4[t, ci] = 1
R4 = rref(HZ4)
k4 = n4 - R4.shape[0]
fund = np.ones(n4, np.uint8)
closed = not (HZ4 @ fund % 2).any()
print(f"\nRUNG 4 (top): [[{n4}, {k4}]]  rank = {R4.shape[0]}  "
      f"(prediction k = dim H_4 = 1)")
print(f"fundamental class (all 16-cells): closed 4-cycle: {closed}, "
      f"weight {int(fund.sum())} -- the unique extensive top class")

# ---- PRE-REGISTERED CONFRONTATION ----------------------------------
print("\nCONFRONTATION with C_H = K^2(K^3 - D^3) = 244,944 = 2^4 3^7 7")
site = L ** 4
inv = {'V': len(vidx), 'E': 6 * site, 'tri': len(tri_idx),
       'sq': 9 * site, 'tet': n3, 'cell16': n4}
print("complex invariants (count, per-site):")
for name, c in inv.items():
    print(f"  {name:<7} {c:>6}   {c/site:.3g}")
target = 244944
hits = [(a, b) for a in inv for b in inv
        if inv[a] * inv[b] == target]
print(f"pairwise products equal to 244,944: {hits if hits else 'NONE'}")


def sev(x, p):
    e = 0
    while x % p == 0:
        x //= p
        e += 1
    return e, x


print("\nfactor analysis: 244,944 = 2^4 * 3^7 * 7  (contains a factor 7)")
seven_free = all(sev(c, 7)[0] == 0 or c % 7 for c in inv.values())
print("all complex invariants are {2,3}-smooth times L-powers "
      "(7-free at every L not divisible by 7): structural obstruction --")
print("no product of uniform cell counts of this complex can equal "
      "244,944; the factor 7 arises in K^3 - D^3 = (K-D)(K^2+KD+D^2) "
      "= 9 * 189 only through the DIFFERENCE structure, i.e., only a "
      "subtraction (shedding-type) rule can produce it.")
print(f"total {time.time()-t0:.0f}s")
