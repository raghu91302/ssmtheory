#!/usr/bin/env python3
"""M/E/I -- Step-1 validation: is any natural CODE-level functional able
to reproduce the known verification costs?

The Part I mass formulas consume f-vector counts of the coordination
CLUSTER (vertices, triangular faces, square faces). The actual
[[192,130,3]] code contains vertex stabilizers and octahedral-void
stabilizers -- no face stabilizers. This experiment asks whether any
principled functional of the code matrices, evaluated on the paper's own
defect supports, reproduces the required sector counts and base costs:

  target C_s:    electron 1 | pion 17 | muon 6 | proton 51
  target base:   electron 1 | pion 272 | muon 216 | proton 1836

Functionals tested (computed from H_Z, H_X restricted to the support S):
  Es      |S|                     (edge count)
  Vt      # vertex stabilizers overlapping S
  Xo      # octahedral stabilizers overlapping S
  Ct      Vt + Xo                 (all detecting stabilizers)
  rZ,rX   GF(2) ranks of H_Z[:,S], H_X[:,S]  (syndrome-space dims)
  rT      rZ + rX
  nnz     total qubit-stabilizer incidences within S
plus the products Es*Vt, Es*Xo, Es*Ct, Es*rZ, Es*rX, Es*rT.

Muon and proton share the identical 36-edge support (07_sector_map.py),
so no single support functional can give both 6 and 51; the worldline
rule selects which stabilizer family counts. We therefore also test the
family-resolved products (Es*Xo for the deconfined muon, Es*Ct for the
confined proton) as the best-case reading.
"""
import numpy as np
from itertools import product

NN = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
      (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
AX = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
L = 6


def build():
    vidx = {}
    for x in product(range(L), repeat=3):
        if sum(x) % 2 == 0:
            vidx[x] = len(vidx)
    edges, eidx = [], {}
    for v in vidx:
        for d in NN:
            nb = tuple((v[k]+d[k]) % L for k in range(3))
            if nb in vidx:
                a, b = sorted((vidx[v], vidx[nb]))
                if (a, b) not in eidx:
                    eidx[(a, b)] = len(edges)
                    edges.append((a, b))
    octs = []
    for w in product(range(L), repeat=3):
        if sum(w) % 2 == 1:
            nbs = [vidx[tuple((w[k]+d[k]) % L for k in range(3))]
                   for d in AX
                   if tuple((w[k]+d[k]) % L for k in range(3)) in vidx]
            if len(nbs) == 6:
                octs.append(nbs)
    n = len(edges)
    HZ = np.zeros((len(vidx), n), np.uint8)
    for ei, (a, b) in enumerate(edges):
        HZ[a, ei] = 1
        HZ[b, ei] = 1
    HX = np.zeros((len(octs), n), np.uint8)
    for oi, nbs in enumerate(octs):
        s = set(nbs)
        for a in nbs:
            for b in nbs:
                if a < b and (a, b) in eidx:
                    HX[oi, eidx[(a, b)]] = 1
    return vidx, edges, eidx, HZ, HX


def gf2rank(M):
    M = M.copy().astype(np.uint8)
    r = 0
    rows, cols = M.shape
    for c in range(cols):
        idx = np.nonzero(M[r:, c])[0]
        if idx.size == 0:
            continue
        p = r + idx[0]
        M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        M[hit] ^= M[r]
        r += 1
        if r == rows:
            break
    return r


vidx, edges, eidx, HZ, HX = build()
C = (2, 2, 2)  # cluster center (even parity)
SHEETS = {'xy': [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0)],
          'xz': [(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1)],
          'yz': [(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]}


def support(sheets):
    nodes = {C} | {tuple((C[k]+d[k]) % L for k in range(3))
                   for s in sheets for d in SHEETS[s]}
    ids = {vidx[v] for v in nodes}
    return sorted(eidx[(a, b)] for (a, b) in eidx
                  if a in ids and b in ids)


defects = {
    'electron': [eidx[tuple(sorted((vidx[C],
                 vidx[tuple((C[k]+NN[0][k]) % L for k in range(3))])))]],
    'pion':     support(['xy', 'xz']),
    'mu/p':     support(['xy', 'xz', 'yz']),
}

targets = {'electron': (1, 1), 'pion': (17, 272), 'mu/p': ('6/51',
           '216/1836')}

print(f"{'defect':<9} {'Es':>4} {'Vt':>4} {'Xo':>4} {'Ct':>4} "
      f"{'rZ':>4} {'rX':>4} {'rT':>4} {'nnz':>5} | "
      f"{'Es*Vt':>6} {'Es*Xo':>6} {'Es*Ct':>6} {'Es*rT':>6} | target Cs, base")
for name, S in defects.items():
    S = np.array(S)
    subZ = HZ[:, S]
    subX = HX[:, S]
    Vt = int((subZ.sum(1) > 0).sum())
    Xo = int((subX.sum(1) > 0).sum())
    Ct = Vt + Xo
    rZ = gf2rank(subZ[subZ.sum(1) > 0])
    rX = gf2rank(subX[subX.sum(1) > 0])
    Es = len(S)
    nnz = int(subZ.sum() + subX.sum())
    print(f"{name:<9} {Es:>4} {Vt:>4} {Xo:>4} {Ct:>4} "
          f"{rZ:>4} {rX:>4} {rZ+rX:>4} {nnz:>5} | "
          f"{Es*Vt:>6} {Es*Xo:>6} {Es*Ct:>6} {Es*(rZ+rX):>6} | "
          f"{targets[name]}")

print("\nrequired for exact match:")
print("  electron: some functional = 1      (support has Ct=4 detecting stabs)")
print("  pion:     C_s = 17, base = 16 x 17 = 272")
print("  muon:     C_s = 6  (family-resolved: Es*Xo = 216 needs Xo = 6)")
print("  proton:   C_s = 51 (family-resolved: Es*Ct = 1836 needs Ct = 51)")
