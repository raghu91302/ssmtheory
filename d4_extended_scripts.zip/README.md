# Verification suite

Supplementary material for *The Mass–Energy–Information Equivalence Extended:
D4 Lattice, Triality, and the Three-Generation Structure of Matter*
(Physics Open, PHYSO-D-26-00405).

Sixteen scripts, a master runner, and four figure generators. Every numerical
claim in the paper is reproduced here.

## Running it

    python3 d4_run_all.py

Runs all sixteen scripts in order and exits 0 if every one passes. Takes about
two minutes on a standard laptop. Works from any working directory.

Requires `numpy`, `scipy`, `sympy` and `matplotlib`.

To rebuild the figures:

    python3 gen_fig1_hasse.py
    python3 gen_fig2_isotropy.py
    python3 gen_fig3_24cell.py
    python3 gen_fig4_mass_spectrum.py

## What each script verifies

| Script | Paper section | Claims verified |
|---|---|---|
| `01_structure_tensor.py` | 3.2, 3.4 | Second moment of the D4 bond set equals 12·I; third moment vanishes; the 24 bonds split 12 spatial / 12 time-mixed, the spatial 12 being exactly the D3 shell |
| `02_24cell_triality.py` | 3.1, 6 | 24-cell f-vector (24, 96, 96, 24); 72 planar 4-circuits in 36 antipodal pairs; triality decomposition into three 16-cells, 8+8+8 |
| `03_d4_css_code.py` | 3.3 | CSS validity; uniform stabilizer weight 24; n = 1536, k = 5L⁴+2 = 1282 at L = 4; d ≥ 3 by exhaustive weight-≤2 elimination on both sides |
| `04_mass_spectrum.py` | 8, 12, 14 | All seven cost predictions against measured ratios: electron 1, muon 207, pion 273, tauon 3447, proton 1836, neutron 1839, Higgs 244,944 |
| `05_triality_code_automorphism.py` | 6.3 | Triality is a code automorphism, permuting H_Z and H_X exactly; three inequivalent logical worldlines |
| `06_statistics.py` | 14.3 | Look-elsewhere analysis: achievable-integer density near each target, per-row p-values, joint figure |
| `07_sector_map.py` | 7.1 | The worldline sector rule reproduces all seven sector assignments; footprint-based rules do not |
| `08_logical_classification.py` | 4.2 | Census of all 1282 logical classes; every class reduces to weight ≤ 9; H4a refuted for the D4 code |
| `09_code_functional_validation.py` | 4.1 | The sector counts are not stabilizer counts of the D4 code (4, 23, 27 against the required 1, 17, 51) |
| `10_d4_plaquette_code.py` | 4.1 | The vertex–plaquette code; sector counts are exact stabilizer counts on it; induced subcomplex edge counts, including E_s = 120 for the 24-cell cluster |
| `11_face_qubit_code.py` | 4.2 | Ladder rung 2: k = 6 = dim H₂(T⁴) |
| `12_complete_cells.py` | 4.2 | Complete cell structure of the D4 honeycomb; 9216 pyramids |
| `13_top_rungs.py` | 4.2 | Ladder rungs 3 and 4: k = 4 = dim H₃(T⁴), k = 1 = dim H₄(T⁴); fundamental class at weight 384 |
| `14_rule_space_scan.py` | 12.1 | Exhaustive scan of the binary rule grammar: 37,334 values, maximum 167,281; vertex-figure check (24, 96, 96, 24) |
| `15_spherical_design.py` | 3.2 | D3 shell is a spherical 3-design with M₄ = 3(k²)² − Σkᵢ⁴; D4 shell is a 5-design with M₄ = 3(k²)² exactly; anisotropy exponents 2.00 and 4.00; comparison with the hypercubic lattice Z⁴ |
| `16_distance_exact.py` | 3.3 | All 4096 D4 triangles (and all 256 D3 triangles) are weight-3 logical operators, so d = 3 exactly for both codes |

## Figure generators

| Script | Figure |
|---|---|
| `gen_fig1_hasse.py` | Figure 1 — Hasse diagram of the 24-cell face lattice, all incidence numbers computed from the polytope |
| `gen_fig2_isotropy.py` | Figure 2 — fourth moment over directions; anisotropy scaling of the phase speed |
| `gen_fig3_24cell.py` | Figure 3 — D4 nearest neighbours projected to 3D; triality decomposition |
| `gen_fig4_mass_spectrum.py` | Figure 4 — predicted costs against measured mass ratios; deviations |

## Notes

Scripts 08, 09, 13 and 14 report negative results, and those are load-bearing:
the dimensional grading is refuted for the D4 code, the sector counts are not
functionals of it, and the binary rule grammar cannot reach the Higgs cost.
These are stated as such in the paper.

Script 12 dominates the runtime at roughly 65 seconds. Everything else runs in
a few seconds.
