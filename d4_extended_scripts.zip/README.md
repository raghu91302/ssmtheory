# M/E/I Extended to D4 — Verification Suite

Computational verification suite for "Mass-Energy-Information
Equivalence Extended to D4" (Physics Open, PHYSO-D-26-00405).
Every numerical claim in the paper is reproduced by these scripts.

## Requirements
Python 3 with numpy. The figure generators additionally require
matplotlib. No other dependencies.

## Running
    python3 d4_run_all.py

Runs the full fourteen-script suite (under three minutes on a
standard laptop). Each script can also be run individually.

## Scripts and the claims they verify
| Script | Verifies |
|---|---|
| 01_structure_tensor.py | S^munu = 12 delta exact; emergent leading-order isotropy |
| 02_24cell_triality.py | 24-cell structure; 4-4-4 triality split; the 72 squares |
| 03_d4_css_code.py | D4 CSS code [[1536, 1282, d>=3]] at L=4 |
| 04_mass_spectrum.py | All mass formulas and deviations (Table 3) |
| 05_triality_code_automorphism.py | Coordinate 3-cycle as code automorphism; three worldline logicals |
| 06_statistics.py | Look-elsewhere analysis (Table 4) |
| 07_sector_map.py | Footprint degeneracy; worldline sector rule (7/7) |
| 08_logical_classification.py | Census of the void code: all 1282 classes reduce to weight <= 9 |
| 09_code_functional_validation.py | FCC vertex-plaquette code [[648,3]]; sector counts 17, 6, 51 exact |
| 10_d4_plaquette_code.py | D4 edge code [[1536,4]]; worldlines; volume-class membrane |
| 11_face_qubit_code.py | Face code; six coordinate worldsheets |
| 12_complete_cells.py | Completed 3-cell inventory; k = 6 = dim H_2(T^4) |
| 13_top_rungs.py | [[3072,4]] and [[384,1]]; fundamental class; factor-seven analysis |
| 14_rule_space_scan.py | Exhaustive binary rule scan (37,334 values, max 167,281); vertex figure = 24-cell |

gen_fig1_24cell.py and gen_fig2_mass_spectrum.py regenerate the
paper's figures.
