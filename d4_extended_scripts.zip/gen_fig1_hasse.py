"""
Figure 4: Hasse diagram of the face lattice of the 24-cell, with
incidence numbers on every covering relation.

For a covering relation a < b the two labels read:
    n  = how many a's each b contains        (upper label)
    m  = how many b's each a lies in         (lower label)

All incidence numbers are computed from the polytope, not typed in.

The right-hand box makes explicit that the 72 square circuits are planar
4-loops of the edge graph, not faces of the polytope, and so appear at no
rank of the face lattice.
"""
import itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
    'font.size': 10,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'figure.facecolor': 'white',
    'savefig.facecolor': 'white',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

# ------------------------------------------------------- build the 24-cell
V = []
for i, j in itertools.combinations(range(4), 2):
    for si in (1, -1):
        for sj in (1, -1):
            v = [0, 0, 0, 0]
            v[i], v[j] = si, sj
            V.append(tuple(v))
V = sorted(set(V))
P = [np.array(v, float) for v in V]
nv = len(V)


def d2(a, b):
    return float(np.dot(P[a] - P[b], P[a] - P[b]))


edges = [(a, b) for a, b in itertools.combinations(range(nv), 2)
         if abs(d2(a, b) - 2.0) < 1e-9]
adj = {i: set() for i in range(nv)}
for a, b in edges:
    adj[a].add(b)
    adj[b].add(a)

tris = sorted({tuple(sorted((a, b, c)))
               for a, b in edges for c in adj[a] & adj[b]})

# octahedral cells: a vertex v and its 6 "polar" partners form an
# octahedron; equivalently, maximal sets of 6 mutually-adjacent-or-
# antipodal vertices lying in a common hyperplane. We find them as the
# vertex sets of the 3-faces via supporting hyperplanes x.u = 1.
# octahedral 3-faces: the supporting hyperplanes are the vertices of the
# dual 24-cell, namely (+-2,0,0,0) and (+-1,+-1,+-1,+-1).
normals = []
for i in range(4):
    for s_ in (2, -2):
        u = [0, 0, 0, 0]
        u[i] = s_
        normals.append(np.array(u, float))
for signs in itertools.product((1, -1), repeat=4):
    normals.append(np.array(signs, float))

cells = set()
for u in normals:
    vals = np.array([np.dot(P[i], u) for i in range(nv)])
    sup = tuple(sorted(np.nonzero(vals >= vals.max() - 1e-9)[0].tolist()))
    if len(sup) == 6:
        cells.add(sup)
cells = sorted(cells)

# planar 4-circuits (the paper's "squares"), which are NOT 2-faces
squares = set()
for q in itertools.combinations(range(nv), 4):
    a, b, c, d = q
    for p, r, s, t in ((a, b, c, d), (a, b, d, c), (a, c, b, d)):
        if all(x in adj[y] for x, y in ((p, r), (r, s), (s, t), (t, p))):
            M = np.array([P[r] - P[p], P[s] - P[p], P[t] - P[p]])
            if np.linalg.matrix_rank(M, tol=1e-9) <= 2:
                squares.add(tuple(sorted(q)))
                break

f = (len(V), len(edges), len(tris), len(cells))
print('f-vector of the 24-cell:', f, ' [expected (24, 96, 96, 24)]')
assert f == (24, 96, 96, 24)
print('planar 4-circuits (not faces):', len(squares), ' [expected 72]')
assert len(squares) == 72

# ------------------------------------------------------ incidence numbers
etri = {}
for t in tris:
    for pair in itertools.combinations(t, 2):
        etri.setdefault(tuple(sorted(pair)), []).append(t)

edge_in_tri = len(etri[tuple(sorted(edges[0]))])
assert all(len(v) == edge_in_tri for v in etri.values())

tri_in_cell = sum(1 for c in cells if set(tris[0]) <= set(c))
for t in tris:
    assert sum(1 for c in cells if set(t) <= set(c)) == tri_in_cell

vert_in_edge = len(adj[0])
assert all(len(adj[i]) == vert_in_edge for i in range(nv))

INC = [
    # (lower rank label, upper rank label, n = a's per b, m = b's per a)
    (r'$\varnothing$', 'vertices', 1, 1),
    ('vertices', 'edges', 2, vert_in_edge),
    ('edges', 'triangles', 3, edge_in_tri),
    ('triangles', 'octahedral cells', 8, tri_in_cell),
    ('octahedral cells', 'the 24-cell', 24, 1),
]
print('incidences  vertex<edge: n=2, m=%d | edge<tri: n=3, m=%d | '
      'tri<cell: n=8, m=%d' % (vert_in_edge, edge_in_tri, tri_in_cell))

# ----------------------------------------------------------------- drawing
rows = [
    (r'$\hat{1}$  the 24-cell',            1,  'polytope'),
    (r'octahedral cells  ($f_3$)',        24,  'cells'),
    (r'triangular 2-faces  ($f_2$)',      96,  'faces'),
    (r'edges  ($f_1$)',                   96,  'edges'),
    (r'vertices  ($f_0$)',                24,  'verts'),
    (r'$\hat{0}$  $\varnothing$',          1,  'empty'),
]
# incidence labels between consecutive drawn rows, top to bottom
between = [
    (24, 1),                      # cells -> polytope   (n=24, m=1)
    (8, tri_in_cell),             # faces -> cells
    (3, edge_in_tri),             # edges -> faces
    (2, vert_in_edge),            # verts -> edges
    (1, 1),                       # empty -> verts
]

fig, ax = plt.subplots(figsize=(8.4, 6.6))
ax.set_xlim(0, 11.2)
ax.set_ylim(-1.15, 6.05)
ax.axis('off')

XC = 3.4
ys = np.linspace(5.4, 0.0, len(rows))
C_BOX = '#1f5f8b'
C_ACC = '#c1440e'

for (label, count, _), y in zip(rows, ys):
    txt = '%s' % label if count == 1 else r'%s' % label
    box = FancyBboxPatch((XC - 2.15, y - 0.24), 4.30, 0.48,
                         boxstyle='round,pad=0.02,rounding_size=0.08',
                         linewidth=1.0, edgecolor=C_BOX,
                         facecolor='#eef4f8', zorder=3)
    ax.add_patch(box)
    ax.text(XC - 1.95, y, txt, ha='left', va='center', fontsize=10,
            zorder=4)
    ax.text(XC + 1.95, y, str(count), ha='right', va='center',
            fontsize=10, color=C_BOX, fontweight='bold', zorder=4)

for i, (n_up, m_dn) in enumerate(between):
    y_hi, y_lo = ys[i], ys[i + 1]
    ax.plot([XC, XC], [y_lo + 0.24, y_hi - 0.24], color='0.35',
            lw=1.1, zorder=2)
    ymid = 0.5 * (y_lo + y_hi)
    ax.text(XC + 0.16, y_hi - 0.40, r'$n=%d$' % n_up, ha='left',
            va='center', fontsize=8.5, color='0.30')
    ax.text(XC + 0.16, y_lo + 0.40, r'$m=%d$' % m_dn, ha='left',
            va='center', fontsize=8.5, color='0.30')
    del ymid

ax.text(XC, 5.85, 'Face lattice of the 24-cell',
        ha='center', va='bottom', fontsize=11, fontweight='bold')
ax.text(XC - 2.15, -1.05,
        r'$n$: how many of the lower rank each upper element contains.'
        '\n'
        r'$m$: how many of the upper rank each lower element lies in.',
        ha='left', va='bottom', fontsize=8.5, color='0.30')

# ------------------------------------------------- side box: what is used
bx, by, bw, bh = 6.15, 1.45, 4.75, 3.20
ax.add_patch(FancyBboxPatch((bx, by), bw, bh,
                            boxstyle='round,pad=0.06,rounding_size=0.10',
                            linewidth=1.0, edgecolor=C_ACC,
                            facecolor='#fdf2ec', zorder=3))
yy = by + bh - 0.30
ax.text(bx + 0.24, yy, 'The 72 squares are not faces',
        fontsize=9.5, fontweight='bold', color=C_ACC, va='top')
yy -= 0.42
for s in [r'2-faces of the polytope: 96, all triangles',
          r'planar 4-circuits of the edge graph: 72']:
    ax.text(bx + 0.24, yy, s, fontsize=9, va='top')
    yy -= 0.34
yy -= 0.10
body = ('A square circuit is a closed 4-loop of\n'
        'nearest-neighbor bonds. It is not a face:\n'
        'the 24-cell has triangular 2-faces only.\n'
        'The squares therefore do not appear at\n'
        'any rank of the lattice at left.')
ax.text(bx + 0.24, yy, body, fontsize=8.6, va='top', color='0.20',
        linespacing=1.45)

fig.savefig('fig1_hasse.pdf')
fig.savefig('fig1_hasse.png')
print('wrote fig1_hasse.pdf and fig1_hasse.png')
