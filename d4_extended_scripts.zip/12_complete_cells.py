#!/usr/bin/env python3
"""M/E/I -- Completing the face-qubit code's 3-cell inventory.

Script 11 found k = 2310 = 6 + 2304, with the excess exactly equal to
the number of square faces: the tetrahedron+octahedron inventory gives
squares no cell to bound. Here we add the square pyramids (each square
plus an apex adjacent to all four base vertices; boundary = the square
plus four lateral triangles, closed by construction) and test the sharp
prediction: k collapses to exactly 6 = dim H_2(T^4), with the six
coordinate worldsheets remaining nontrivial.
"""
import numpy as np
import time
from itertools import product, combinations

L = 4
t0 = time.time()


def gen_nn():
    nn = []
    for i in range(4):
        for j in range(i + 1, 4):
            for si in (-1, 1):
                for sj in (-1, 1):
                    d = [0, 0, 0, 0]
                    d[i], d[j] = si, sj
                    nn.append(tuple(d))
    return nn


NN = gen_nn()
E4 = [tuple(1 if k == i else 0 for k in range(4)) for i in range(4)]
vidx = {}
for x in product(range(L), repeat=4):
    if sum(x) % 2 == 0:
        vidx[x] = len(vidx)
adj = {u: set() for u in range(len(vidx))}
eidx = {}
for v in vidx:
    for d in NN:
        nb = tuple((v[k] + d[k]) % L for k in range(4))
        if nb in vidx:
            a, b = sorted((vidx[v], vidx[nb]))
            adj[a].add(b)
            adj[b].add(a)
            if (a, b) not in eidx:
                eidx[(a, b)] = len(eidx)
n_e = len(eidx)

faces = []
fidx = {}
tri_lookup = {}
for a in adj:
    for b, c in combinations(sorted(adj[a]), 2):
        if b > a and c > a and c in adj[b]:
            es = [eidx[tuple(sorted(p))] for p in ((a, b), (a, c), (b, c))]
            tri_lookup[frozenset((a, b, c))] = len(faces)
            faces.append((('t', a, b, c), es, frozenset((a, b, c))))
seen_sq = set()
squares = []      # (fid, cyclic vertex list)
for v in vidx:
    a = vidx[v]
    for i1 in range(len(NN)):
        for i2 in range(i1 + 1, len(NN)):
            d1, d2 = NN[i1], NN[i2]
            s = tuple(d1[k] + d2[k] for k in range(4))
            df = tuple(d1[k] - d2[k] for k in range(4))
            if s in NN or df in NN or not any(s) or not any(df):
                continue
            p1 = tuple((v[k] + d1[k]) % L for k in range(4))
            p2 = tuple((v[k] + d2[k]) % L for k in range(4))
            p3 = tuple((v[k] + d1[k] + d2[k]) % L for k in range(4))
            if p1 not in vidx or p2 not in vidx or p3 not in vidx:
                continue
            b, c, d = vidx[p1], vidx[p3], vidx[p2]
            es = []
            ok = True
            for pr in ((a, b), (b, c), (c, d), (d, a)):
                pr = tuple(sorted(pr))
                if pr not in eidx:
                    ok = False
                    break
                es.append(eidx[pr])
            if not ok:
                continue
            kk = frozenset(es)
            if kk in seen_sq:
                continue
            seen_sq.add(kk)
            fid = len(faces)
            faces.append((('s',) + tuple(sorted((a, b, c, d))), es,
                          frozenset((a, b, c, d))))
            squares.append((fid, [a, b, c, d]))
n_f = len(faces)
print(f"faces: {n_f} ({len(tri_lookup)} tri + {len(squares)} sq)")

HZ = np.zeros((n_e, n_f), np.uint8)
for fi, (_, es, _) in enumerate(faces):
    for e in es:
        HZ[e, fi] = 1

cells = []
for a in adj:                                    # tetrahedra
    for b, c in combinations(sorted(adj[a]), 2):
        if not (b > a and c > a and c in adj[b]):
            continue
        for d in sorted(adj[a] & adj[b] & adj[c]):
            if d > c:
                cells.append([tri_lookup[frozenset(t)]
                              for t in combinations((a, b, c, d), 3)])
n_tet = len(cells)
for w in product(range(L), repeat=4):            # octahedra
    if sum(w) % 2 == 1:
        for axes in combinations(range(4), 3):
            vs = {}
            ok = True
            for i in axes:
                for sgn in (1, -1):
                    p = tuple((w[k] + sgn * E4[i][k]) % L
                              for k in range(4))
                    if p not in vidx:
                        ok = False
                        break
                    vs[(i, sgn)] = vidx[p]
                if not ok:
                    break
            if not ok:
                continue
            i, j, kx = axes
            fs = [tri_lookup[frozenset((vs[(i, si)], vs[(j, sj)],
                                        vs[(kx, sk)]))]
                  for si in (1, -1) for sj in (1, -1) for sk in (1, -1)]
            cells.append(fs)
n_oct = len(cells) - n_tet

n_pyr = 0                                        # square pyramids
for fid, base in squares:
    b0, b1, b2, b3 = base
    apexes = (adj[b0] & adj[b1] & adj[b2] & adj[b3]) - set(base)
    for x in sorted(apexes):
        fs = [fid]
        for (u, vv) in ((b0, b1), (b1, b2), (b2, b3), (b3, b0)):
            fs.append(tri_lookup[frozenset((x, u, vv))])
        cells.append(fs)
        n_pyr += 1
print(f"3-cells: {n_tet} tet + {n_oct} oct + {n_pyr} pyramids "
      f"(pyramids per square: {n_pyr/len(squares):.1f})")

HX = np.zeros((len(cells), n_f), np.uint8)
for ci, fs in enumerate(cells):
    ecount = {}
    for fi in fs:
        HX[ci, fi] = 1
        for e in faces[fi][1]:
            ecount[e] = ecount.get(e, 0) + 1
    assert all(v == 2 for v in ecount.values()), f"cell {ci} not closed"
print("all cell boundaries closed")
assert not (HX @ HZ.T % 2).any()
print("CSS valid")


def rref(M):
    M = M.copy()
    r = 0
    for c in range(M.shape[1]):
        idx = np.nonzero(M[r:, c])[0]
        if idx.size == 0:
            continue
        p = r + idx[0]
        M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        M[hit] ^= M[r]
        r += 1
        if r == M.shape[0]:
            break
    return M[:r]


RZ = rref(HZ)
RX = rref(HX)
k = n_f - RZ.shape[0] - RX.shape[0]
print(f"rank(H_Z)={RZ.shape[0]}, rank(H_X)={RX.shape[0]}, "
      f"k = {k}   (prediction: 6)   [{time.time()-t0:.0f}s]")

# worldsheets still nontrivial?
vlist = list(vidx.keys())
A = RX.copy()
good = 0
for (i, j) in combinations(range(4), 2):
    v = np.zeros(n_f, np.uint8)
    others = [ax for ax in range(4) if ax not in (i, j)]
    for fid, base in squares:
        coords = [vlist[x] for x in base]
        if all(c[o] == 0 for c in coords for o in others):
            v[fid] = 1
    closed = not (HZ @ v % 2).any()
    R2 = rref(np.vstack([A, v[None, :]]))
    nt = R2.shape[0] > A.shape[0]
    if closed and nt:
        A = R2
        good += 1
print(f"coordinate worldsheets nontrivial in completed code: {good} of 6")
print(f"total {time.time()-t0:.0f}s")
