#!/usr/bin/env python3
"""M/E/I -- Face-qubit rung: the 4D toric-type code on the D4 complex.

Qubits on 2-cells (all 6400 plaquettes of script 11). Z-stabilizers on
edges (row e = all faces containing e). X-stabilizers on 3-cells
(tetrahedra = 4-cliques; octahedra = 3-axis crosses around odd sites),
each verified closed (every edge of the cell in exactly two of its
faces), which makes H_X H_Z^T = 0 automatic.

Tests:
  A. counts, CSS validity, k = n_f - rank(H_Z) - rank(H_X).
     If the 3-cell inventory were homologically complete, k = 6
     = dim H_2(T^4); any excess measures missing 3-cell types.
  B. construct the six coordinate worldsheets (planar square tilings of
     the (i,j) 2-tori) and verify each is a nontrivial X-logical:
     the surface-graded (gauge-boson) classes.
"""
import numpy as np
import time
from itertools import product, combinations

L = 4
t0 = time.time()


def gen_nn():
    nn = []
    for i in range(4):
        for j in range(i + 1, 4):
            for si in (-1, 1):
                for sj in (-1, 1):
                    d = [0, 0, 0, 0]
                    d[i], d[j] = si, sj
                    nn.append(tuple(d))
    return nn


NN = gen_nn()
E = [tuple(1 if k == i else 0 for k in range(4)) for i in range(4)]
vidx = {}
for x in product(range(L), repeat=4):
    if sum(x) % 2 == 0:
        vidx[x] = len(vidx)
vlist = list(vidx.keys())
adj = {u: set() for u in range(len(vidx))}
eidx = {}
for v in vidx:
    for d in NN:
        nb = tuple((v[k] + d[k]) % L for k in range(4))
        if nb in vidx:
            a, b = sorted((vidx[v], vidx[nb]))
            adj[a].add(b)
            adj[b].add(a)
            if (a, b) not in eidx:
                eidx[(a, b)] = len(eidx)
n_e = len(eidx)

# ---- faces: triangles (cliques) + contractible squares --------------
fidx = {}
faces = []          # each: (sorted vertex tuple key, list of edge ids)
tri_keys = set()
for a in adj:
    for b, c in combinations(sorted(adj[a]), 2):
        if b > a and c > a and c in adj[b]:
            key = ('t', a, b, c)
            es = [eidx[tuple(sorted(p))] for p in ((a, b), (a, c), (b, c))]
            fidx[key] = len(faces)
            faces.append((key, es, frozenset((a, b, c))))
seen_sq = set()
sq_by_edges = {}
for v in vidx:
    a = vidx[v]
    for i1 in range(len(NN)):
        for i2 in range(i1 + 1, len(NN)):
            d1, d2 = NN[i1], NN[i2]
            s = tuple(d1[k] + d2[k] for k in range(4))
            df = tuple(d1[k] - d2[k] for k in range(4))
            if s in NN or df in NN or not any(s) or not any(df):
                continue
            p1 = tuple((v[k] + d1[k]) % L for k in range(4))
            p2 = tuple((v[k] + d2[k]) % L for k in range(4))
            p3 = tuple((v[k] + d1[k] + d2[k]) % L for k in range(4))
            if p1 not in vidx or p2 not in vidx or p3 not in vidx:
                continue
            b, c, d = vidx[p1], vidx[p3], vidx[p2]
            es = []
            ok = True
            for pr in ((a, b), (b, c), (c, d), (d, a)):
                pr = tuple(sorted(pr))
                if pr not in eidx:
                    ok = False
                    break
                es.append(eidx[pr])
            if not ok:
                continue
            kk = frozenset(es)
            if kk in seen_sq:
                continue
            seen_sq.add(kk)
            key = ('s',) + tuple(sorted((a, b, c, d)))
            fidx[key] = len(faces)
            faces.append((key, es, frozenset((a, b, c, d))))
            sq_by_edges[kk] = fidx[key]
n_f = len(faces)
tri_count = sum(1 for f in faces if f[0][0] == 't')
print(f"faces: {n_f} qubits ({tri_count} tri + {n_f - tri_count} sq)  "
      f"edges: {n_e}  [{time.time()-t0:.0f}s]")

# H_Z: edge x face incidence
HZ = np.zeros((n_e, n_f), np.uint8)
for fi, (_, es, _) in enumerate(faces):
    for e in es:
        HZ[e, fi] = 1

# ---- 3-cells --------------------------------------------------------
tri_lookup = {}
for fi, (key, es, vs) in enumerate(faces):
    if key[0] == 't':
        tri_lookup[vs] = fi

cells = []
# tetrahedra: 4-cliques
for a in adj:
    for b, c in combinations(sorted(adj[a]), 2):
        if not (b > a and c > a and c in adj[b]):
            continue
        for d in sorted(adj[a] & adj[b] & adj[c]):
            if d > c:
                fs = [tri_lookup[frozenset(t)]
                      for t in combinations((a, b, c, d), 3)]
                cells.append(fs)
n_tet = len(cells)
# octahedra: odd site w, 3 axes
for w in product(range(L), repeat=4):
    if sum(w) % 2 == 1:
        for axes in combinations(range(4), 3):
            vs = {}
            ok = True
            for i in axes:
                for s in (1, -1):
                    p = tuple((w[k] + s * E[i][k]) % L for k in range(4))
                    if p not in vidx:
                        ok = False
                        break
                    vs[(i, s)] = vidx[p]
                if not ok:
                    break
            if not ok:
                continue
            fs = []
            i, j, kx = axes
            for si in (1, -1):
                for sj in (1, -1):
                    for sk in (1, -1):
                        t = frozenset((vs[(i, si)], vs[(j, sj)],
                                       vs[(kx, sk)]))
                        fs.append(tri_lookup[t])
            cells.append(fs)
n_oct = len(cells) - n_tet
print(f"3-cells: {n_tet} tetrahedra + {n_oct} octahedra")

# closure check + H_X
HX = np.zeros((len(cells), n_f), np.uint8)
for ci, fs in enumerate(cells):
    ecount = {}
    for fi in fs:
        HX[ci, fi] = 1
        for e in faces[fi][1]:
            ecount[e] = ecount.get(e, 0) + 1
    assert all(v == 2 for v in ecount.values()), "cell boundary not closed"
print("all 3-cell boundaries closed (every edge in exactly 2 faces)")
assert not (HX @ HZ.T % 2).any()
print("CSS validity H_X H_Z^T = 0: YES")


def rref(M):
    M = M.copy()
    r = 0
    for c in range(M.shape[1]):
        idx = np.nonzero(M[r:, c])[0]
        if idx.size == 0:
            continue
        p = r + idx[0]
        M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        M[hit] ^= M[r]
        r += 1
        if r == M.shape[0]:
            break
    return M[:r]


RZ = rref(HZ)
print(f"rank(H_Z) = {RZ.shape[0]}  [{time.time()-t0:.0f}s]")
RX = rref(HX)
k = n_f - RZ.shape[0] - RX.shape[0]
print(f"rank(H_X) = {RX.shape[0]},  k = {k}   "
      f"(homological target dim H_2(T^4) = 6; excess = missing 3-cell "
      f"types)  [{time.time()-t0:.0f}s]")

# ---- B: six coordinate worldsheets ---------------------------------
print("\ncoordinate worldsheets (surface-graded classes):")
A = RX.copy()
good = 0
for (i, j) in combinations(range(4), 2):
    v = np.zeros(n_f, np.uint8)
    w = 0
    for (kk, fid) in sq_by_edges.items():
        key, es, vs = faces[fid]
        coords = [vlist[x] for x in key[1:]]
        # square lies in the (i,j)-plane through origin of other coords
        others = [ax for ax in range(4) if ax not in (i, j)]
        if all(c[o] == 0 for c in coords for o in others):
            v[fid] = 1
            w += 1
    syn = HZ @ v % 2
    closed = not syn.any()
    R2 = rref(np.vstack([A, v[None, :]]))
    nontriv = R2.shape[0] > A.shape[0]
    if closed and nontriv:
        A = R2
        good += 1
    print(f"  plane ({i},{j}): weight {w}, closed: {closed}, "
          f"new nontrivial X-logical: {nontriv}")
print(f"\nindependent worldsheet logicals confirmed: {good} of 6")
print(f"total {time.time()-t0:.0f}s")
