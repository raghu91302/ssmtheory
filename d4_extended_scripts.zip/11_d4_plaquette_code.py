#!/usr/bin/env python3
"""M/E/I -- The D4 vertex+plaquette code (the mass-bearing code, lifted
to 4D) at L = 4.

Deliverables:
  A. Build the code: qubits on D4 edges, Z-stabilizers on vertex stars,
     X-stabilizers on all triangular and square plaquettes. Verify CSS
     validity and compute [[n, k]]. Prediction: k = 4 = dim H_1(T^4).
  B. Construct the four axis worldlines (weight 4) and verify they are
     independent X-logicals: the line-graded classes.
  C. Construct the dual membrane (all edges crossing the x_0 wrap cut)
     and verify it is a Z-logical with volume-scale weight that greedy
     reduction cannot localize: the volume-graded class that the
     octahedral code provably lacks.
  D. Evaluate the validated cell-count functional (10_...validation.py)
     on the D4 coordination cluster C_25, against the tauon's inputs
     (E_s = 96, squares 72 -> F_sq = 36 under H3).
"""
import numpy as np
import time
from itertools import product, combinations

L = 4
t0 = time.time()


def gen_nn():
    nn = []
    for i in range(4):
        for j in range(i + 1, 4):
            for si in (-1, 1):
                for sj in (-1, 1):
                    d = [0, 0, 0, 0]
                    d[i], d[j] = si, sj
                    nn.append(tuple(d))
    return nn


NN = gen_nn()
vidx = {}
for x in product(range(L), repeat=4):
    if sum(x) % 2 == 0:
        vidx[x] = len(vidx)
vlist = list(vidx.keys())
adj = {u: set() for u in range(len(vidx))}
eidx, edges = {}, []
for v in vidx:
    for d in NN:
        nb = tuple((v[k] + d[k]) % L for k in range(4))
        if nb in vidx:
            a, b = sorted((vidx[v], vidx[nb]))
            adj[a].add(b)
            adj[b].add(a)
            if (a, b) not in eidx:
                eidx[(a, b)] = len(edges)
                edges.append((a, b))
n = len(edges)

# plaquettes
tris = set()
for a in adj:
    for b, c in combinations(sorted(adj[a]), 2):
        if b > a and c > a and c in adj[b]:
            tris.add((a, b, c))
tris = sorted(tris)
sq_rows = []
seen_sq = set()
for v in vidx:
    a = vidx[v]
    for i1 in range(len(NN)):
        for i2 in range(i1 + 1, len(NN)):
            d1, d2 = NN[i1], NN[i2]
            s = tuple(d1[kk] + d2[kk] for kk in range(4))
            df = tuple(d1[kk] - d2[kk] for kk in range(4))
            if s in NN or df in NN or all(x == 0 for x in s) \
               or all(x == 0 for x in df):
                continue
            p1 = tuple((v[kk] + d1[kk]) % L for kk in range(4))
            p2 = tuple((v[kk] + d2[kk]) % L for kk in range(4))
            p3 = tuple((v[kk] + d1[kk] + d2[kk]) % L for kk in range(4))
            if p1 not in vidx or p2 not in vidx or p3 not in vidx:
                continue
            b, c, d = vidx[p1], vidx[p3], vidx[p2]
            es = []
            ok = True
            for pr in ((a, b), (b, c), (c, d), (d, a)):
                pr = tuple(sorted(pr))
                if pr not in eidx:
                    ok = False
                    break
                es.append(eidx[pr])
            if not ok:
                continue
            key = frozenset(es)
            if key in seen_sq:
                continue
            seen_sq.add(key)
            r = np.zeros(n, np.uint8)
            for e in es:
                r[e] = 1
            sq_rows.append(r)
tri_rows = []
for t in tris:
    r = np.zeros(n, np.uint8)
    good = True
    for p in combinations(t, 2):
        p = tuple(sorted(p))
        if p not in eidx:
            good = False
            break
        r[eidx[p]] = 1
    if good:
        tri_rows.append(r)
Hp = np.array(tri_rows + sq_rows, np.uint8)
HZ = np.zeros((len(vidx), n), np.uint8)
for ei, (a, b) in enumerate(edges):
    HZ[a, ei] = 1
    HZ[b, ei] = 1

print(f"A. D4 plaquette code at L={L}: n={n} edge qubits, "
      f"{HZ.shape[0]} vertex Z-stabs, "
      f"{len(tri_rows)} triangle + {len(sq_rows)} square X-stabs")
assert not (Hp @ HZ.T % 2).any()
print("   CSS validity H_plaq H_Z^T = 0: YES")


def rref(M):
    M = M.copy()
    r = 0
    piv = []
    for c in range(M.shape[1]):
        idx = np.nonzero(M[r:, c])[0]
        if idx.size == 0:
            continue
        p = r + idx[0]
        M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        M[hit] ^= M[r]
        piv.append(c)
        r += 1
        if r == M.shape[0]:
            break
    return M[:r], piv


RZ, _ = rref(HZ)
RP, _ = rref(Hp)
k = n - RZ.shape[0] - RP.shape[0]
print(f"   rank(H_Z)={RZ.shape[0]}, rank(H_plaq)={RP.shape[0]}, "
      f"k = {k}   (prediction: 4 = dim H_1(T^4))   "
      f"cycle dim = {n - len(vidx) + 1}   [{time.time()-t0:.0f}s]")


def in_span(basis_rref_rows, v):
    A = basis_rref_rows
    R2, _ = rref(np.vstack([A, v[None, :]]))
    return R2.shape[0] == A.shape[0]


# B. axis worldlines: alternate (+1,+1,0,0),(+1,-1,0,0) steps -> +2 axis0
print("\nB. axis worldlines (line-graded classes):")
W = []
for axis in range(4):
    other = (axis + 1) % 4
    d1 = [0, 0, 0, 0]
    d1[axis], d1[other] = 1, 1
    d2 = [0, 0, 0, 0]
    d2[axis], d2[other] = 1, -1
    v = np.zeros(n, np.uint8)
    p = (0, 0, 0, 0)
    for step in range(L):
        d = d1 if step % 2 == 0 else d2
        q = tuple((p[kk] + d[kk]) % L for kk in range(4))
        a, b = sorted((vidx[p], vidx[q]))
        v[eidx[(a, b)]] ^= 1
        p = q
    assert p == (0, 0, 0, 0)
    W.append(v)
A = RP.copy()
indep = 0
for i, v in enumerate(W):
    assert not (HZ @ v % 2).any(), "not in ker H_Z"
    if not in_span(A, v):
        A, _ = rref(np.vstack([A, v[None, :]]))
        indep += 1
print(f"   4 constructed, weight {int(W[0].sum())} each; "
      f"independent nontrivial X-logicals: {indep} "
      f"-> k = 4 fully accounted for by H_1" if indep == 4 else
      f"   independent: {indep}")

# C. dual membrane: edges wrapping the x_0 cut (endpoints x0 in {L-1,0})
print("\nC. dual membrane (volume-graded class):")
m = np.zeros(n, np.uint8)
for (a, b), ei in eidx.items():
    xa, xb = vlist[a][0], vlist[b][0]
    if {xa, xb} == {L - 1, 0}:
        m[ei] = 1
w0 = int(m.sum())
assert not (Hp @ m % 2).any(), "membrane not in ker H_plaq"
zlog = not in_span(RZ, m)
print(f"   crossing-edge vector: weight {w0}; in ker(H_plaq): YES; "
      f"nontrivial Z-logical (not in Z-stab span): {'YES' if zlog else 'NO'}")
# symplectic pairing with axis-0 worldline (must be odd)
pair = int((m & W[0]).sum()) % 2
print(f"   symplectic pairing with axis-0 worldline: {pair} "
      f"(odd = genuinely paired homology classes)")
# greedy reduction against vertex stars
v = m.copy()
w = w0
improved = True
S = RZ
while improved:
    improved = False
    ov = (S & v).sum(axis=1)
    delta = S.sum(axis=1) - 2 * ov
    b = int(np.argmin(delta))
    if delta[b] < 0:
        v ^= S[b]
        w += int(delta[b])
        improved = True
print(f"   greedy reduction floor: weight {w} "
      f"(volume band is > {L**3} = {L**3}) -> "
      f"{'VOLUME-SCALE, irreducible under single-stabilizer moves' if w > L**3 else 'reduced below volume band'}")

# D. cell-count functional on the D4 coordination cluster C_25
print("\nD. cell-count functional on the C_25 cluster (tauon inputs):")
C = (0, 0, 0, 0)
ids = {vidx[C]} | {vidx[tuple((C[kk] + d[kk]) % L for kk in range(4))]
                   for d in NN}
S_edges = {(a, b) for (a, b) in eidx if a in ids and b in ids}
Es = len(S_edges)
tri_in = 0
for t in tris:
    if all(x in ids for x in t):
        prs = [tuple(sorted(p)) for p in combinations(t, 2)]
        if all(p in eidx and p in S_edges for p in prs):
            tri_in += 1
sq_in = 0
for r in sq_rows:
    sup = np.nonzero(r)[0]
    if all(edges[e][0] in ids and edges[e][1] in ids for e in sup):
        sq_in += 1
shell_edges = sum(1 for (a, b) in S_edges
                  if a != vidx[C] and b != vidx[C])
print(f"   induced subcomplex: E_s = {Es} "
      f"(= 24 spokes + {shell_edges} shell edges); "
      f"paper's tauon uses E_s = 96")
print(f"   contained triangles = {tri_in}, contained squares = {sq_in}; "
      f"paper's tauon square count: 72 raw -> 36 under H3")
print(f"total {time.time()-t0:.0f}s")
