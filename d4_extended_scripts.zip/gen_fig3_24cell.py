"""
Figure 1: The 24 nearest neighbors of D4 projected to 3D.
Left panel: spatial vs time-mixed bonds (D3 sub-lattice emergence).
Right panel: triality decomposition into three 16-cells.
"""
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from itertools import permutations, product
import matplotlib
matplotlib.use('Agg')

# Publication-quality settings
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'figure.facecolor': 'white',
    'axes.facecolor':   'white',
    'savefig.facecolor': 'white',
    'savefig.edgecolor': 'white',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})


def _force_white_3d(ax):
    """Make the three pane walls of a 3D axes pure white (no light-grey tint)."""
    for pane_axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        pane_axis.pane.set_facecolor('white')
        pane_axis.pane.set_edgecolor('#cfd6e0')
        pane_axis.pane.set_alpha(1.0)
    ax.set_facecolor('white')

# Generate the 24 vertices of the D4 NN structure (24-cell)
# Each is a 4-vector with two ±1 entries and two zeros
verts_4d = []
for i, j in [(a, b) for a in range(4) for b in range(a+1, 4)]:
    for si, sj in product([-1, 1], repeat=2):
        v = [0, 0, 0, 0]
        v[i] = si
        v[j] = sj
        verts_4d.append(tuple(v))

verts_4d = np.array(verts_4d)
assert len(verts_4d) == 24

# Identify triality sets via the three pair-of-pairs:
# A: {(0,1), (2,3)}, B: {(0,2), (1,3)}, C: {(0,3), (1,2)}
def triality_set(v):
    nz = tuple(sorted([i for i in range(4) if v[i] != 0]))
    if nz in [(0, 1), (2, 3)]:
        return 0  # set A
    if nz in [(0, 2), (1, 3)]:
        return 1  # set B
    if nz in [(0, 3), (1, 2)]:
        return 2  # set C
    return -1

tri_labels = np.array([triality_set(v) for v in verts_4d])

# Project to 3D by treating coordinate 0 as time
# Spatial bonds: those with v[0] = 0 (12 vertices)
# Time-mixed bonds: those with v[0] != 0 (12 vertices)
is_spatial = (verts_4d[:, 0] == 0)
proj_3d = verts_4d[:, 1:4].astype(float)

# For time-mixed vertices, mark them slightly differently (shrink toward axis)
# Their 3D projection collapses pairs onto the same point; offset them
proj_for_plot = proj_3d.copy().astype(float)

# Build the figure with two panels
fig = plt.figure(figsize=(7.0, 3.5))

# ---------- Left panel: spatial vs time-mixed ----------
ax1 = fig.add_subplot(121, projection='3d')

# Spatial vertices (D3 sub-lattice): 12 vertices forming a cuboctahedron
spat_pts = proj_for_plot[is_spatial]
time_pts = proj_for_plot[~is_spatial]

# Draw edges of the cuboctahedron (D3 NN-NN edges at distance sqrt(2))
def draw_edges(ax, pts, max_dist, color, lw=0.8, alpha=0.5):
    n = len(pts)
    for i in range(n):
        for j in range(i+1, n):
            d = np.linalg.norm(pts[i] - pts[j])
            if abs(d - max_dist) < 0.01:
                ax.plot([pts[i, 0], pts[j, 0]],
                        [pts[i, 1], pts[j, 1]],
                        [pts[i, 2], pts[j, 2]],
                        color=color, lw=lw, alpha=alpha)

# Cuboctahedron edges: NN at distance sqrt(2) in 3D
draw_edges(ax1, spat_pts, np.sqrt(2), '#1f77b4', lw=0.7, alpha=0.45)

# Plot spatial vertices
ax1.scatter(spat_pts[:, 0], spat_pts[:, 1], spat_pts[:, 2],
            c='#1f77b4', s=42, edgecolors='black', linewidths=0.5,
            label='Spatial NN ($D_3$, 12)', zorder=5)

# Plot time-mixed vertices (project to axis positions; show as slightly displaced)
# These project to ±1 on each axis (6 distinct 3D positions, each appearing twice in 4D)
unique_time = np.unique(time_pts, axis=0)
ax1.scatter(unique_time[:, 0], unique_time[:, 1], unique_time[:, 2],
            c='#d62728', s=70, marker='s', edgecolors='black', linewidths=0.5,
            label='Time-mixed NN (12, projected to 6)', zorder=5)

# Draw axes lightly
for axis_dir in np.eye(3):
    ax1.plot([-1.2*axis_dir[0], 1.2*axis_dir[0]],
             [-1.2*axis_dir[1], 1.2*axis_dir[1]],
             [-1.2*axis_dir[2], 1.2*axis_dir[2]],
             color='gray', lw=0.4, alpha=0.4, linestyle=':')

ax1.set_xlim(-1.3, 1.3); ax1.set_ylim(-1.3, 1.3); ax1.set_zlim(-1.3, 1.3)
ax1.set_box_aspect([1, 1, 1])
ax1.set_xlabel('$x$', labelpad=-8)
ax1.set_ylabel('$y$', labelpad=-8)
ax1.set_zlabel('$z$', labelpad=-8)
ax1.set_xticks([-1, 0, 1])
ax1.set_yticks([-1, 0, 1])
ax1.set_zticks([-1, 0, 1])
ax1.tick_params(axis='both', which='major', pad=-3)
ax1.set_title('(a) $D_4$ nearest neighbors projected to 3D:\nspatial ($D_3$) vs. time-mixed', pad=8)
ax1.legend(loc='upper left', bbox_to_anchor=(-0.05, 0.98), fontsize=7.5, framealpha=0.9)
ax1.view_init(elev=22, azim=35)
_force_white_3d(ax1)

# ---------- Right panel: triality decomposition ----------
ax2 = fig.add_subplot(122, projection='3d')

# Color by triality set
colors_tri = ['#2ca02c', '#ff7f0e', '#9467bd']
labels_tri = ['16-cell A', '16-cell B', '16-cell C']
markers_tri = ['o', '^', 's']

for tset in range(3):
    mask = tri_labels == tset
    pts = proj_for_plot[mask]
    # Draw edges within this 16-cell (vertices at distance sqrt(2) in 4D project to specific 3D distances)
    # In 4D, the 16-cell has edges connecting non-antipodal vertices.
    # Compute 4D distances and draw edges for distance sqrt(2)
    verts_this = verts_4d[mask]
    for i in range(len(verts_this)):
        for j in range(i+1, len(verts_this)):
            d4 = np.linalg.norm(verts_this[i] - verts_this[j])
            if abs(d4 - 2.0) < 0.01:
                ax2.plot([pts[i, 0], pts[j, 0]],
                         [pts[i, 1], pts[j, 1]],
                         [pts[i, 2], pts[j, 2]],
                         color=colors_tri[tset], lw=0.6, alpha=0.5, zorder=2)
    ax2.scatter(pts[:, 0], pts[:, 1], pts[:, 2],
                c=colors_tri[tset], s=55, marker=markers_tri[tset],
                edgecolors='black', linewidths=0.5,
                label=labels_tri[tset], zorder=5)

# (Cuboctahedron reference edges removed; the triality edges show the structure.)

# Draw axes
for axis_dir in np.eye(3):
    ax2.plot([-1.2*axis_dir[0], 1.2*axis_dir[0]],
             [-1.2*axis_dir[1], 1.2*axis_dir[1]],
             [-1.2*axis_dir[2], 1.2*axis_dir[2]],
             color='gray', lw=0.4, alpha=0.4, linestyle=':')

ax2.set_xlim(-1.3, 1.3); ax2.set_ylim(-1.3, 1.3); ax2.set_zlim(-1.3, 1.3)
ax2.set_box_aspect([1, 1, 1])
ax2.set_xlabel('$x$', labelpad=-8)
ax2.set_ylabel('$y$', labelpad=-8)
ax2.set_zlabel('$z$', labelpad=-8)
ax2.set_xticks([-1, 0, 1])
ax2.set_yticks([-1, 0, 1])
ax2.set_zticks([-1, 0, 1])
ax2.tick_params(axis='both', which='major', pad=-3)
ax2.set_title('(b) Triality decomposition:\nthree inscribed 16-cells', pad=8)
ax2.legend(loc='upper left', bbox_to_anchor=(-0.05, 0.98), fontsize=7.5, framealpha=0.9)
ax2.view_init(elev=22, azim=35)
_force_white_3d(ax2)

plt.tight_layout()
plt.savefig('./fig3_24cell.pdf', format='pdf', bbox_inches='tight', facecolor='white')
plt.savefig('./fig3_24cell.png', format='png', bbox_inches='tight', dpi=300, facecolor='white')
print("Figure 1 saved.")
print(f"Triality counts: A={sum(tri_labels==0)}, B={sum(tri_labels==1)}, C={sum(tri_labels==2)}")
print(f"Spatial (D3) verts: {sum(is_spatial)}, Time-mixed: {sum(~is_spatial)}")
