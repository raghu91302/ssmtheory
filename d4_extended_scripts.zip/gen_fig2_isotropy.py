"""
Figure 3: How isotropic is the lattice?

(a) The fourth moment of the bond set, sum_j (k.n_j)^4, plotted over
    directions in a coordinate plane.  On $D_3$ it varies with direction;
    on D4 it is exactly constant.  This is the spherical 3-design versus
    5-design distinction.
(b) Direction-dependence of the phase speed omega/|k| computed from the
    exact lattice dispersion, versus the dimensionless momentum ka.
    D3 falls as (ka)^2, D4 as (ka)^4.

Both panels are computed, not drawn by hand.  The numbers agree with
15_spherical_design.py.
"""
import itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'savefig.facecolor': 'white',
    'savefig.edgecolor': 'white',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

C_FCC = '#c1440e'     # warm red
C_D4 = '#1f5f8b'      # deep blue


def bonds(dim):
    out = []
    for i, j in itertools.combinations(range(dim), 2):
        for si in (1, -1):
            for sj in (1, -1):
                v = [0] * dim
                v[i], v[j] = si, sj
                out.append(v)
    return np.array(out, dtype=float) / np.sqrt(2.0)


def moment(dim, p, kdirs):
    B = bonds(dim)
    return np.array([np.sum((B.dot(d)) ** p) for d in kdirs])


def omega_over_k(dim, ka, dirs):
    B = bonds(dim)
    w = np.array([np.sqrt(np.sum(1.0 - np.cos(B.dot(d) * ka))) for d in dirs])
    return w / ka


def rand_dirs(dim, n, seed=1):
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(n, dim))
    return v / np.linalg.norm(v, axis=1, keepdims=True)


fig = plt.figure(figsize=(9.6, 4.3))
gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.15], wspace=0.32)

# ---------------------------------------------------------------- panel (a)
axa = fig.add_subplot(gs[0, 0], projection='polar')

theta = np.linspace(0, 2 * np.pi, 721)
d3 = np.stack([np.cos(theta), np.sin(theta), np.zeros_like(theta)], axis=1)
d4 = np.stack([np.cos(theta), np.sin(theta),
               np.zeros_like(theta), np.zeros_like(theta)], axis=1)

m3 = moment(3, 4, d3)
m4 = moment(4, 4, d4)

# normalize each curve by its own mean so shape, not scale, is compared
axa.plot(theta, m3 / m3.mean(), color=C_FCC, lw=1.9,
         label='$D_3$ shell (12 bonds)')
axa.plot(theta, m4 / m4.mean(), color=C_D4, lw=1.9, ls='-',
         label='$D_4$ shell (24 bonds)')
axa.plot(theta, np.ones_like(theta), color='0.55', lw=0.8, ls=':',
         zorder=1)

axa.set_ylim(0.80, 1.20)
axa.set_yticks([0.9, 1.0, 1.1])
axa.set_yticklabels(['0.9', '1.0', '1.1'], fontsize=7.5, color='0.35')
axa.set_xticks(np.linspace(0, 2 * np.pi, 8, endpoint=False))
axa.set_xticklabels([r'$k_x$', '', r'$k_y$', '', '', '', '', ''], fontsize=9)
axa.grid(color='0.85', lw=0.6)
axa.set_title(r'(a) Fourth moment $\sum_j (\mathbf{k}\cdot\mathbf{n}_j)^4$,'
              ' normalized', pad=22, fontsize=10)
axa.legend(loc='lower center', bbox_to_anchor=(0.5, -0.24),
           frameon=False, ncol=1, handlelength=1.6)

axa.text(np.deg2rad(45), 1.155, 'varies with\ndirection',
         color=C_FCC, fontsize=8, ha='center', va='center')
axa.text(np.deg2rad(225), 0.855, 'exactly\nconstant',
         color=C_D4, fontsize=8, ha='center', va='center')

# ---------------------------------------------------------------- panel (b)
axb = fig.add_subplot(gs[0, 1])

kas = np.logspace(np.log10(0.02), np.log10(0.6), 22)
dirs3, dirs4 = rand_dirs(3, 1500), rand_dirs(4, 1500)

s3, s4 = [], []
for ka in kas:
    w3 = omega_over_k(3, ka, dirs3)
    w4 = omega_over_k(4, ka, dirs4)
    s3.append((w3.max() - w3.min()) / w3.mean())
    s4.append((w4.max() - w4.min()) / w4.mean())
s3, s4 = np.array(s3), np.array(s4)

axb.loglog(kas, s3, 'o-', color=C_FCC, ms=3.4, lw=1.5,
           label='$D_3$ shell')
axb.loglog(kas, s4, 's-', color=C_D4, ms=3.4, lw=1.5,
           label='$D_4$ shell')

# guide lines
g2 = s3[-1] * (kas / kas[-1]) ** 2
g4 = s4[-1] * (kas / kas[-1]) ** 4

axb.text(kas[16], g2[16] * 0.16, r'$\propto (ka)^{2}$',
         color=C_FCC, fontsize=9, ha='center', va='top')
axb.text(kas[9], g4[9] * 7.0, r'$\propto (ka)^{4}$',
         color=C_D4, fontsize=9, ha='center', va='bottom')

axb.set_xlabel(r'dimensionless momentum $ka$')
axb.set_ylabel(r'spread of $\omega/|\mathbf{k}|$ over directions')
axb.set_title('(b) Direction-dependence of the propagation speed',
              fontsize=10)
axb.legend(frameon=False, loc='upper left')
axb.grid(True, which='major', color='0.90', lw=0.6)
axb.grid(True, which='minor', color='0.95', lw=0.4)
for side in ('top', 'right'):
    axb.spines[side].set_visible(False)

fig.savefig('fig2_isotropy.pdf')
fig.savefig('fig2_isotropy.png')
print('wrote fig2_isotropy.pdf and fig2_isotropy.png')
print('D3 spread at ka=0.1: %.3e' % s3[np.argmin(abs(kas - 0.1))])
print('D4  spread at ka=0.1: %.3e' % s4[np.argmin(abs(kas - 0.1))])
