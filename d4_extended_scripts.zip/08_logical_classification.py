#!/usr/bin/env python3
"""M/E/I D4 -- Dimensional classification of the logical space at L = 4.

Tests the load-bearing prerequisite of hypothesis H4 and of the Higgs
identification: does the L = 4 D4 CSS code contain logical classes whose
minimal-weight representatives are irreducibly extended (line ~ L,
surface ~ L^2, volume ~ L^3, bulk ~ L^4), or does every logical class
admit a low-weight local representative?

Method: build the code, extract a basis of the X-logical space
ker(H_Z) / rowspace(H_X), then reduce each basis vector's weight by
greedy descent over the X-stabilizer generators (with first-improvement
passes to convergence, plus pairwise moves for stuck vectors). The
reduced weights are UPPER bounds on the class-representative weights;
a census concentrated at low weight is therefore conclusive evidence
AGAINST intrinsic extended classes in the basis directions, while any
vector stuck at high weight is a candidate extended class (upper-bound
evidence only).
"""
import numpy as np
import time
from itertools import product


def gen_d4_nn_displacements():
    nn = []
    for i in range(4):
        for j in range(i + 1, 4):
            for si in (-1, 1):
                for sj in (-1, 1):
                    d = [0, 0, 0, 0]
                    d[i] = si
                    d[j] = sj
                    nn.append(tuple(d))
    return nn


def gen_axis_displacements():
    out = []
    for i in range(4):
        for si in (-1, 1):
            d = [0, 0, 0, 0]
            d[i] = si
            out.append(tuple(d))
    return out


def build(L):
    vidx = {}
    for x in product(range(L), repeat=4):
        if sum(x) % 2 == 0:
            vidx[x] = len(vidx)
    nn = gen_d4_nn_displacements()
    edges, seen = [], set()
    for v in vidx:
        u = vidx[v]
        for d in nn:
            nb = tuple((v[k] + d[k]) % L for k in range(4))
            if nb in vidx:
                w = vidx[nb]
                e = (min(u, w), max(u, w))
                if e not in seen:
                    seen.add(e)
                    edges.append(e)
    axis = gen_axis_displacements()
    x_stab = []
    for w in product(range(L), repeat=4):
        if sum(w) % 4 == 0 or sum(w) % 2 == 1:
            pass
        if sum(w) % 2 == 1:
            nbs = []
            for d in axis:
                nb = tuple((w[k] + d[k]) % L for k in range(4))
                if nb in vidx:
                    nbs.append(vidx[nb])
            x_stab.append(nbs)
    n = len(edges)
    HZ = np.zeros((len(vidx), n), dtype=np.uint8)
    for ei, (a, b) in enumerate(edges):
        HZ[a, ei] = 1
        HZ[b, ei] = 1
    HX = np.zeros((len(x_stab), n), dtype=np.uint8)
    eidx = {e: i for i, e in enumerate(edges)}
    for si, nbs in enumerate(x_stab):
        s = set(nbs)
        for a in nbs:
            for b in nbs:
                if a < b and (a, b) in eidx:
                    HX[si, eidx[(a, b)]] = 1
    return HZ, HX, edges


def rref(M):
    M = M.copy()
    rows, cols = M.shape
    piv = []
    r = 0
    for c in range(cols):
        rr = np.nonzero(M[r:, c])[0]
        if rr.size == 0:
            continue
        p = r + rr[0]
        if p != r:
            M[[r, p]] = M[[p, r]]
        hit = np.nonzero(M[:, c])[0]
        hit = hit[hit != r]
        M[hit] ^= M[r]
        piv.append(c)
        r += 1
        if r == rows:
            break
    return M[:r], piv


def kernel_basis(M):
    R, piv = rref(M)
    cols = M.shape[1]
    pivset = set(piv)
    free = [c for c in range(cols) if c not in pivset]
    K = np.zeros((len(free), cols), dtype=np.uint8)
    for i, fc in enumerate(free):
        K[i, fc] = 1
        for ri, pc in enumerate(piv):
            if R[ri, fc]:
                K[i, pc] = 1
    return K


def greedy_reduce(v, S):
    """Reduce weight of v by XORing stabilizer rows; first-improvement."""
    w = int(v.sum())
    improved = True
    while improved:
        improved = False
        # weight after xor with each stabilizer: w + |s| - 2*overlap
        ov = (S & v).sum(axis=1)
        delta = S.sum(axis=1) - 2 * ov
        best = int(np.argmin(delta))
        if delta[best] < 0:
            v = v ^ S[best]
            w += int(delta[best])
            improved = True
    return v, w


def main():
    L = 4
    t0 = time.time()
    HZ, HX, edges = build(L)
    n = HZ.shape[1]
    print(f"built: n={n}, |Z-stabs|={HZ.shape[0]}, |X-stabs|={HX.shape[0]}"
          f"  ({time.time()-t0:.1f}s)")

    K = kernel_basis(HZ)          # dim = n - rank(HZ)
    RX, _ = rref(HX)              # X-stabilizer rowspace basis
    print(f"dim ker(H_Z) = {K.shape[0]}, rank(H_X) = {RX.shape[0]}, "
          f"k = {K.shape[0] - RX.shape[0]}")

    # quotient: reduce kernel basis mod rowspace(HX); keep vectors
    # independent of the stabilizer rowspace
    stack, _ = rref(np.vstack([RX, K]))
    # logical basis: rows of the combined rref beyond rank(RX) span
    # logicals mod stabilizers; recompute directly:
    logicals = []
    A = RX.copy()
    rankA = A.shape[0]
    for row in K:
        test = np.vstack([A, row[None, :]])
        R2, _ = rref(test)
        if R2.shape[0] > rankA:
            logicals.append(row)
            A = R2
            rankA = R2.shape[0]
    logicals = np.array(logicals, dtype=np.uint8)
    print(f"logical X basis: {logicals.shape[0]} vectors "
          f"({time.time()-t0:.1f}s)")

    S = RX  # reduce against independent stabilizer basis
    weights = []
    for v in logicals:
        _, w = greedy_reduce(v.copy(), S)
        weights.append(w)
    weights = np.array(weights)

    print(f"\nreduced-weight census over {len(weights)} basis classes "
          f"(upper bounds):")
    bands = [(0, 6, "local (<= 6)"),
             (7, 2 * L, f"line band (7..{2*L})"),
             (2 * L + 1, L * L, f"surface band ({2*L+1}..{L*L})"),
             (L * L + 1, L ** 3, f"volume band ({L*L+1}..{L**3})"),
             (L ** 3 + 1, n, f"bulk band (> {L**3})")]
    for lo, hi, name in bands:
        c = int(((weights >= lo) & (weights <= hi)).sum())
        print(f"  {name:<24} {c}")
    print(f"  max reduced weight: {int(weights.max())}, "
          f"min: {int(weights.min())}, mean: {weights.mean():.1f}")
    print(f"\nverdict inputs: classes stuck above L^2={L*L}: "
          f"{int((weights > L*L).sum())}; above L^3={L**3}: "
          f"{int((weights > L**3).sum())}")
    print(f"total time {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
