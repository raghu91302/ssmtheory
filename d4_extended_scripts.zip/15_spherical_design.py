#!/usr/bin/env python3
"""M/E/I D4 -- How isotropic is the lattice?

This script replaces the "structure tensor" argument of Part I with a
statement that is exact, standard, and checkable: a statement about the
*moments* of the nearest-neighbor bond set.

For a set of unit bond vectors {n_j} the p-th moment is the polynomial

    M_p(k) = sum_j (k . n_j)^p .

If M_p(k) depends only on |k| then the bond set has no preferred
direction at order p.  A set for which this holds for every p <= t is a
spherical t-design (Delsarte, Goethals and Seidel, 1977).

What this script establishes, exactly and by symbolic algebra:

  * the D3 shell (cuboctahedron, 12 bonds) is a spherical 3-design.
    Its 2nd moment is isotropic, its 4th moment is NOT:
        sum (k.n)^4 = 3 (k^2)^2 - sum_i k_i^4 .
    This corrects the claim in Part I that the dispersion is isotropic
    "at all orders".  It is isotropic at second order only.

  * the D4 shell (24-cell, 24 bonds) is a spherical 5-design.
    Its 2nd AND 4th moments are isotropic:
        sum (k.n)^2 = 6 k^2 ,     sum (k.n)^4 = 3 (k^2)^2 ,
    and the first anisotropy appears at 6th order.

Consequence for the lattice dispersion relation
    omega(k)^2 = kappa sum_j [1 - cos(k . n_j a)] :
direction-dependence of the propagation speed is suppressed by (ka)^2
on D3 but by (ka)^4 on D4.  With a ~ Planck length this is
(E/M_P)^2 versus (E/M_P)^4.

It also computes the same moments for the hypercubic lattice Z^4, the
lattice of lattice QCD, which is only a spherical 3-design: its fourth
moment 2*sum k_i^4 has no isotropic part whatever. Lorentz invariance is
nonetheless recovered in the continuum limit there, which bounds how much
the design property can be claimed to buy.

Requires numpy and sympy.
"""

import itertools
import numpy as np
import sympy as sp


# ---------------------------------------------------------------- geometry

def hypercubic_bond_set(dim):
    """Unit nearest-neighbor bonds of Z^dim: one coord +-1, rest 0.

    This is the lattice on which lattice QCD is formulated, and on which
    Lorentz invariance is recovered in the continuum limit. It is the
    reference point for the D4 comparison at the end of main().
    """
    out = []
    for i in range(dim):
        for sgn in (1, -1):
            v = [0] * dim
            v[i] = sgn
            out.append(v)
    return out


def bond_set(dim):
    """Unit nearest-neighbor bonds of D_dim: two coords +-1, rest 0."""
    out = []
    for i, j in itertools.combinations(range(dim), 2):
        for si in (1, -1):
            for sj in (1, -1):
                v = [0] * dim
                v[i], v[j] = si, sj
                out.append(v)
    return out


def moment_poly(dim, p, sets=bond_set):
    """Exact symbolic sum_j (k.n_j)^p over the given unit bond set."""
    ks = sp.symbols('k0:%d' % dim, real=True)
    total = 0
    for v in sets(dim):
        # normalize each bond by its own length, so the routine works for
        # both the D-lattice bonds (norm^2 = 2) and the Z^4 bonds (norm^2 = 1)
        nrm = sp.sqrt(sum(sp.Integer(c) ** 2 for c in v))
        dot = sum(sp.Integer(c) * k for c, k in zip(v, ks)) / nrm
        total += sp.expand(dot ** p)
    return sp.expand(total), ks


def is_isotropic(expr, ks):
    """True iff expr is a constant multiple of (k^2)^(p/2)."""
    k2 = sum(k ** 2 for k in ks)
    deg = sp.Poly(expr, *ks).total_degree()
    if deg % 2:
        return sp.simplify(expr) == 0
    c = expr.subs([(ks[0], 1)] + [(k, 0) for k in ks[1:]])
    return sp.simplify(sp.expand(expr - c * k2 ** (deg // 2))) == 0


def design_strength(dim, max_order=8):
    """Largest t such that all moments up to order t are isotropic."""
    t = 0
    for p in range(1, max_order + 1):
        expr, ks = moment_poly(dim, p)
        if p % 2:                      # odd moments vanish by centrosymmetry
            ok = sp.simplify(expr) == 0
        else:
            ok = is_isotropic(expr, ks)
        if ok:
            t = p
        else:
            break
    return t


# ------------------------------------------------------------- dispersion

def omega2(kvec, dim, a=1.0, kappa=1.0):
    """Exact lattice dispersion omega^2 = kappa sum_j [1 - cos(k.n a)]."""
    B = np.array(bond_set(dim), dtype=float) / np.sqrt(2.0)
    return kappa * np.sum(1.0 - np.cos(B.dot(np.asarray(kvec)) * a))


def directions(dim, n=4000, seed=0):
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(n, dim))
    return v / np.linalg.norm(v, axis=1, keepdims=True)


def speed_spread(dim, ka, n=4000):
    """Fractional spread of the phase speed omega/|k| over directions."""
    u = directions(dim, n)
    w = np.array([np.sqrt(omega2(ka * d, dim)) for d in u]) / ka
    return (w.max() - w.min()) / w.mean()


# ------------------------------------------------------------------- main

def main():
    print("=" * 74)
    print("Moment isotropy of the nearest-neighbor bond sets")
    print("=" * 74)

    labels = {3: "D3 shell  (cuboctahedron, 12 bonds)",
              4: "D4 shell   (24-cell, 24 bonds)"}

    for dim in (3, 4):
        print("\n%s" % labels[dim])
        for p in (2, 4, 6):
            expr, ks = moment_poly(dim, p)
            iso = is_isotropic(expr, ks)
            print("   order %d moment isotropic: %-5s   %s"
                  % (p, iso, sp.factor(expr)))
        t = design_strength(dim)
        print("   => spherical %d-design   [expected %d]"
              % (t, 3 if dim == 3 else 5))
        assert t == (3 if dim == 3 else 5)

    # the two identities quoted in the paper
    e3, k3 = moment_poly(3, 4)
    target3 = 3 * (sum(k ** 2 for k in k3)) ** 2 - sum(k ** 4 for k in k3)
    assert sp.simplify(sp.expand(e3 - target3)) == 0
    print("\nFCC quartic identity  sum (k.n)^4 = 3(k^2)^2 - sum k_i^4   VERIFIED")
    print("   (the -sum k_i^4 term is the cubic anisotropy Part I omitted)")

    e4, k4 = moment_poly(4, 4)
    target4 = 3 * (sum(k ** 2 for k in k4)) ** 2
    assert sp.simplify(sp.expand(e4 - target4)) == 0
    print("D4  quartic identity  sum (k.n)^4 = 3(k^2)^2  exactly       VERIFIED")

    # second moments, in the paper's unnormalised convention (|n|^2 = 2)
    for dim, expect in ((3, 4), (4, 6)):
        e, ks = moment_poly(dim, 2)
        c = e.subs([(ks[0], 1)] + [(k, 0) for k in ks[1:]])
        print("   S^{mu nu} = %d delta  (unit bonds, dim %d)   [expected %d]"
              % (c, dim, expect))
        assert c == expect

    print("\n" + "=" * 74)
    print("Direction-dependence of the phase speed  (omega/|k|)")
    print("=" * 74)
    print("%10s %16s %16s %10s" % ("k a", "D3 spread", "D4 spread", "ratio"))
    prev = None
    for ka in (0.4, 0.2, 0.1, 0.05, 0.025):
        s3, s4 = speed_spread(3, ka), speed_spread(4, ka)
        print("%10.4f %16.3e %16.3e %10.1f" % (ka, s3, s4, s3 / s4))
        if prev is not None:
            r3 = np.log(prev[0] / s3) / np.log(prev[2] / ka)
            r4 = np.log(prev[1] / s4) / np.log(prev[2] / ka)
            print("%10s   scaling exponents: D3 ~ (ka)^%.2f, D4 ~ (ka)^%.2f"
                  % ("", r3, r4))
        prev = (s3, s4, ka)

    print("\nD3 anisotropy scales as (ka)^2, D4 as (ka)^4  [as predicted]")
    print("\n" + "=" * 74)
    print("Comparison with the hypercubic lattice of lattice QCD")
    print("=" * 74)
    e, ks = moment_poly(4, 2, hypercubic_bond_set)
    c = e.subs([(ks[0], 1)] + [(k, 0) for k in ks[1:]])
    print("   Z^4, order 2:  %s   isotropic" % sp.factor(e))
    e4, ks4 = moment_poly(4, 4, hypercubic_bond_set)
    target = 2 * sum(k ** 4 for k in ks4)
    assert sp.simplify(sp.expand(e4 - target)) == 0
    print("   Z^4, order 4:  %s" % sp.factor(e4))
    print("                  NOT isotropic: no (k^2)^2 part at all")
    print("   => Z^4 is a spherical 3-design; D4 is a 5-design.")
    print("   Lorentz invariance is recovered in the continuum limit of")
    print("   lattice QCD on Z^4, so the tree-level anisotropy of the bond")
    print("   set is not by itself an obstruction. That recovery rests on RG")
    print("   flow to a critical point and applies to modes with ka << 1;")
    print("   the defects of this framework sit at ka ~ 1 (see paper).")

    print("\nAll spherical-design checks passed.")


if __name__ == '__main__':
    main()
