# The Regge action as the elasticity of vacuum fluctuations: reproduction scripts
Requires Python 3 with numpy, scipy, matplotlib. Run from this directory.

    python3 cone_heat.py          # Table 2: conical vertex coefficient from exact Bessel spectra (writes cone_rows.npy)
    python3 newton.py             # Table 3: induced Newton constant, mode-count cutoff (writes newton.json)
    python3 make_figs.py          # Figure 1 (needs the two outputs above)
    python3 induced_k0.py         # Table 1, scalar column
    python3 rotor_k0.py           # Table 1, U(1) gauge column
    python3 fermion_k0.py         # Table 1, Wilson-Dirac column
    python3 geometric_control.py  # Table 1, continuum-kinetic-tensor row
    python3 root_p.py             # scalar covariant exponent p* = 4.1996
    python3 rotor_p2.py           # gauge-field covariant exponent p* = 4.6899
