import numpy as np, json, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'font.family':'serif','mathtext.fontset':'cm'})
rows=np.load('cone_rows.npy'); a=rows[:,0]; vn=rows[:,1]
fig,ax=plt.subplots(1,2,figsize=(6.8,2.6))
d=np.linspace(0,250,300); al=1-d/360
ax[0].plot(d,(1/al-al)/12,'k-',lw=1,label=r'exact $\frac{1}{12}(\alpha^{-1}-\alpha)$')
ax[0].plot(d,(1-al)/6,'C0--',lw=1,label=r'Regge (linear), $\frac{1-\alpha}{6}$')
ax[0].plot(360*(1-a),vn,'o',ms=4,mfc='none',color='C3',label='from exact spectrum')
ax[0].set_xlabel(r'deficit angle $\delta$ (deg)'); ax[0].set_ylabel('conical heat-kernel constant')
ax[0].set_title(r'(a) hinge term of the ocean',fontsize=9); ax[0].legend(fontsize=7,frameon=False)
J=json.load(open('newton.json')); names=['SM','SM\n+$\\nu_R$','SM+$\\nu_R$\nconf. H','left–\nright','Pati–\nSalam\n(16 scalars)']
C=[r[1] for r in J['rows']]; cols=['C0' if c>0 else 'C3' for c in C]
ax[1].bar(range(5),C,color=cols,width=0.6)
lo,hi=sorted(J['Creq'].values()); ax[1].axhspan(lo,hi,color='0.8',zorder=0)
ax[1].text(4.45,hi+0.8,'area law\n(C = %.1f–%.1f)'%(lo,hi),ha='right',va='bottom',fontsize=7)
ax[1].axhline(0,color='gray',lw=0.6); ax[1].set_xticks(range(5)); ax[1].set_xticklabels(names,fontsize=7)
ax[1].set_ylabel(r'$C$ in $1/G_{\rm ind}=C\Lambda^2/12\pi$'); ax[1].set_title('(b) induced Newton constant',fontsize=9)
ax[1].set_ylim(-22,12)
plt.tight_layout(); plt.savefig('fig_ocean.pdf'); print('ok')
