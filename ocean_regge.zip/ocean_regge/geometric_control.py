"""Control: scalar with GEOMETRIC couplings. For each uniform strain eps, J_c solves
sum_c J_c d_c d_c^T = 6 sqrt(det g) g^{-1}  (exact continuum kinetic tensor), minimal-norm deviation from J=1.
Also the rotor analog: plaquette couplings reproducing sqrt(g) g^{-1} g^{-1} contracted on the plaquette bivectors."""
import numpy as np, induced_k0 as I
from scipy.optimize import brentq
R=I.R; Eb=I.Eb
A=np.array([np.outer(d,d)[np.triu_indices(4)] for d in R]).T      # (10,12) maps J -> upper-tri of sum J d d^T
def J_geo(eps):
    g=np.eye(4)+eps; T=6*np.sqrt(np.linalg.det(g))*np.linalg.inv(g)
    b=T[np.triu_indices(4)]; J0=np.ones(len(R))
    return J0+np.linalg.pinv(A)@(b-A@J0)                           # minimal-norm correction, exact constraint
Q=I.grid(16); Phi=2*(2-2*np.cos(Q@R.T))
W=lambda e: 0.5*np.mean(np.log(Phi@J_geo(e)))
h=1e-3; E0=np.eye(4)/2
w=(W(h*E0)-W(-h*E0))/(2*h)/(0.5*np.trace(E0))
res=[]
for E in [np.diag([1,-1,0,0.])/np.sqrt(2),Eb[1],np.diag([1,1,-1,-1.])/2]:
    res.append((W(h*E)-2*W(0*E)+W(-h*E))/h**2)
res=np.array(res); print('geometric scalar: w=%+.5f  shape eigs %s  covariant %+.5f  ratio %s'%(w,np.round(res,5),-0.5*w,np.round(res/(-0.5*w),4)))
# check the constraint really holds and the kinetic tensor is exactly covariant
e=1e-2*np.diag([1,-1,0,0.]); J=J_geo(e); g=np.eye(4)+e
print('kinetic tensor check: |sum J dd - 6 sqrt(g) g^-1| =',np.abs(np.einsum('c,ci,cj->ij',J,R,R)-6*np.sqrt(np.linalg.det(g))*np.linalg.inv(g)).max())
