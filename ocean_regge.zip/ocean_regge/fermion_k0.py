"""Fermion sector: D4 Wilson-Dirac operator (Kulkarni, 'Geometric Wilson masses', zenodo 18410364) with
QEC-priced bond amplitudes. W_F = -2 < log( W^2 + |V|^2 ) >_BZ per vertex (Dirac, 4 spinor components).
Shape test at k=0 as for the bosons; also report the shape EXCESS Delta = s - (-w/2) for cancellation."""
import numpy as np, induced_k0 as I, rotor_k0 as Rk
R=I.R; nhat=R/np.sqrt(2)
def grid(M): return I.grid(M)
class Ferm:
    def __init__(self,M,r=1.0):
        Q=grid(M); ph=Q@R.T; self.S=2*np.sin(ph); self.C=2-2*np.cos(ph); self.r=r
    def W(self,eps,rule,vielbein=False):
        g=np.eye(4)+eps; l2=np.einsum('ci,ij,cj->c',R,g,R); l=np.sqrt(l2)
        t={'bond':1/l,'support':np.full(12,1/l.mean())}[rule]
        if vielbein:   # physical unit directions e.d/|e.d|, e = sqrt(g) (symmetric vielbein)
            w_,U=np.linalg.eigh(g); e=U@np.diag(np.sqrt(w_))@U.T; m=(R@e.T)/l[:,None]
        else: m=nhat
        V=(self.S*t)@m; Wm=self.r*(self.C@t)
        return -2*np.mean(np.log(Wm**2+(V**2).sum(1)))
def shape_test(Wfun,h=1e-3):
    E0=np.eye(4)/2; w=(Wfun(h*E0)-Wfun(-h*E0))/(2*h)/(0.5*np.trace(E0))
    s=[]
    for E in [np.diag([1,-1,0,0.])/np.sqrt(2),I.Eb[1],np.diag([1,1,-1,-1.])/2]:
        s.append((Wfun(h*E)-2*Wfun(0*E)+Wfun(-h*E))/h**2)
    s=np.array(s); cov=-0.5*w; return w,s,cov,s-cov
if __name__=="__main__":
    rows={}
    for M in (16,24):
        F=Ferm(M,1.0)
        for rule in ['bond','support']:
            for vb in (False,True):
                w,s,cov,D=shape_test(lambda e: F.W(e,rule,vb))
                print('M=%d fermion %-8s %-9s w=%+.5f shape %s cov %+.5f ratio %.4f  excess %+.5f'%(M,rule,'vielbein' if vb else 'coord',w,np.round(s,5),cov,s[0]/cov,D[0]))
                rows[(rule,vb)]=(w,s[0],cov,D[0])
    # bosonic excesses (per field) for reference, bond rule
    Qb=I.grid(16); Phi=2*(2-2*np.cos(Qb@R.T))
    ws,ss,cs,Ds=shape_test(lambda e: I.W(e,'bond',Phi))
    rot=Rk.Rotor(8); wg,sg,cg,Dg=shape_test(lambda e: rot.W(Rk.K_of(e,'bond')))
    print('\nshape excess per field (bond rule): real scalar %+.5f | U(1) gauge %+.5f | Dirac fermion (coord) %+.5f | Dirac (vielbein) %+.5f'%(Ds[0],Dg[0],rows[('bond',False)][3],rows[('bond',True)][3]))
