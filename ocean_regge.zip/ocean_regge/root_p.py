import numpy as np, induced_k0 as I
from scipy.optimize import brentq
tr=np.array([np.trace(E) for E in I.Eb])
def ratio(p,M,h=1e-3):
    Q=I.grid(M); Phi=2*(2-2*np.cos(Q@I.R.T))
    I.J_of=lambda l2,rule: (np.sqrt(l2))**(-p)
    W=lambda e: I.W(e,'x',Phi)
    E0=np.eye(4)/2; w=2*(W(h*E0)-W(-h*E0))/(2*h)/ (np.trace(E0)) * 1.0
    # gradient coefficient: dW/d(eps)=(w/2) I  ->  along E0=I/2: dW = (w/2)*tr(E0)*h
    w=(W(h*E0)-W(-h*E0))/(2*h)/(0.5*np.trace(E0))
    E=np.diag([1,-1,0,0.])/np.sqrt(2); s=(W(h*E)-2*W(0*E)+W(-h*E))/h**2
    return s/(-0.5*w)
for M in (16,24,32):
    r=brentq(lambda p: ratio(p,M)-1,3.0,6.0,xtol=1e-6)
    print('M=%d  covariant exponent p* = %.5f   (ratio at p=4: %.5f)'%(M,r,ratio(4.0,M)))
