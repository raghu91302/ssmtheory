import numpy as np, rotor_k0 as Rk
from scipy.optimize import brentq
_K=Rk.K_of
def K_bondpow(eps,rule,p=1.0):
    if rule!='bondpow': return _K(eps,rule,p)
    l=np.sqrt(np.einsum('ci,ij,cj->c',Rk.R,np.eye(4)+eps,Rk.R))
    L=np.array([[l[c] for c in te] for te in Rk.tri_edges]); return (L**(-p)).mean(1)
Rk.K_of=K_bondpow
for M in (8,12):
    rot=Rk.Rotor(M)
    ratio=lambda p: (lambda r: r[2][0]/r[3])(Rk.test(rot,'bondpow',p))
    print('M=%d per-bond power law: '%M+'  '.join('p=%g:%.4f'%(p,ratio(p)) for p in [1,2,3,4,5,6]))
    try: print('   covariant exponent p* = %.4f'%brentq(lambda p: ratio(p)-1,1,12,xtol=1e-5))
    except ValueError: print('   no root in [1,12]')
