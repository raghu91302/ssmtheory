"""Heat-kernel constant of a cone-disk (angle 2*pi*alpha, radius 1, Dirichlet) from its exact spectrum.
Eigenvalues j_{nu,k}^2 with nu=|m|/alpha. K(t) = A/(4 pi t) - L/(8 sqrt(pi t)) + c0 + c1 sqrt(t) + ...
Prediction: c0 = alpha/6 (boundary curvature) + (1/12)(1/alpha - alpha) (conical vertex)."""
import numpy as np
from scipy.special import jv, jvp
XMAX=260.0
def zeros_nu(nu,xmax=XMAX,dx=0.02):
    x=np.arange(max(nu,1e-9)+1e-6,xmax,dx); f=jv(nu,x)
    s=np.where(np.sign(f[:-1])*np.sign(f[1:])<0)[0]
    z=x[s]-f[s]*(x[s+1]-x[s])/(f[s+1]-f[s])
    for _ in range(4): z=z-jv(nu,z)/jvp(nu,z)                  # Newton polish
    return z[z<xmax]
def spectrum(alpha):
    lam=[]; m=0
    while True:
        nu=m/alpha
        if nu>XMAX-5: break
        z=zeros_nu(nu); mult=1 if m==0 else 2
        lam+= [z**2]*mult; m+=1
    return np.concatenate(lam)
def c0(alpha):
    lam=spectrum(alpha); A=np.pi*alpha; L=2*np.pi*alpha
    ts=np.linspace(4e-4,3e-3,24)
    R=np.array([np.exp(-t*lam).sum()-A/(4*np.pi*t)+L/(8*np.sqrt(np.pi*t)) for t in ts])
    X=np.stack([np.ones_like(ts),np.sqrt(ts),ts,ts**1.5],1)
    return np.linalg.lstsq(X,R,rcond=None)[0][0]
if __name__=="__main__":
    print(' alpha   deficit(deg)   c0 numeric    alpha/6+(1/12)(1/a-a)   vertex numeric   vertex exact   smooth-R (linear) (1-a)/6')
    rows=[]
    for a in [1.0,0.98,0.95,0.9,0.8,0.7,0.5,1/3]:
        c=c0(a); pred=a/6+(1/a-a)/12; vn=c-a/6; ve=(1/a-a)/12
        rows.append((a,vn,ve,(1-a)/6))
        print(' %.4f   %7.2f      %.6f     %.6f               %.6f        %.6f       %.6f'%(a,360*(1-a),c,pred,vn,ve,(1-a)/6))
    np.save('cone_rows.npy',np.array(rows))
