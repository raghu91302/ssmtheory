"""Induced effective action W(eps) = 1/2 <log L_eps(q)>_BZ per vertex, for a scalar on D4 vertices with
couplings J_e on the 24 root bonds (12 classes), under a UNIFORM metric strain g = 1 + eps.
Covariance test: W must be w*sqrt(det g) + const  =>  grad W = (w/2) I, Hess W = w[ (1/4) tr x tr - (1/2) I ]."""
import numpy as np, itertools as it, sys
R=[]; 
for i,j in it.combinations(range(4),2):
    for si,sj in it.product([1,-1],repeat=2):
        v=np.zeros(4); v[i]=si; v[j]=sj
        if tuple(v)>tuple(-v): R.append(v)
R=np.array(R)                       # 12 root classes (one of each +/- pair)
Eb=[]
for m in range(4):
    for n in range(m,4):
        E=np.zeros((4,4)); E[m,n]=E[n,m]=1.0 if m==n else 1/np.sqrt(2); Eb.append(E)
Eb=np.array(Eb)                     # Frobenius-orthonormal basis of Sym(4)
def grid(M):
    x=(np.arange(M)+0.5)*2*np.pi/M
    Q=np.stack(np.meshgrid(x,x,x,x,indexing='ij'),-1).reshape(-1,4); return Q
def J_of(l2,rule):
    l=np.sqrt(l2)
    if rule=='bond':    return 1.0/l
    if rule=='support': return np.full_like(l,1.0/l.mean())
    if rule=='const':   return np.ones_like(l)
def W(eps,rule,Phi):
    l2=np.einsum('ci,ij,cj->c',R,np.eye(4)+eps,R)
    J=J_of(l2,rule)
    return 0.5*np.mean(np.log(Phi@J))       # L(q)=sum_c J_c * 2(1-cos q.d_c)  (both orientations -> factor 2 in Phi)
def analyse(rule,M=20,h=1e-3):
    Q=grid(M); Phi=2*(2-2*np.cos(Q@R.T))   # each class = 2 bonds per vertex (+d, -d)
    W0=W(np.zeros((4,4)),rule,Phi)
    G=np.array([(W(h*E,rule,Phi)-W(-h*E,rule,Phi))/(2*h) for E in Eb])
    H=np.zeros((10,10))
    for a in range(10):
        for b in range(a,10):
            e1,e2=Eb[a],Eb[b]
            H[a,b]=H[b,a]=(W(h*(e1+e2),rule,Phi)-W(h*(e1-e2),rule,Phi)-W(h*(-e1+e2),rule,Phi)+W(-h*(e1+e2),rule,Phi))/(4*h*h)
    tr=np.array([np.trace(E) for E in Eb])               # trace functional in this basis
    # gradient decomposition: covariant part (w/2) * tr
    w=2*(G@tr)/(tr@tr); Gres=np.linalg.norm(G-(w/2)*tr)/np.linalg.norm(G)
    Hcov=w*(0.25*np.outer(tr,tr)-0.5*np.eye(10))
    # split H into volume (trace) and shape (traceless) sectors
    P=np.outer(tr,tr)/(tr@tr); T=np.eye(10)-P
    shape=T@(H-Hcov)@T; vol=P@(H-Hcov)@P
    ev=np.linalg.eigvalsh(T@H@T)[1:] if False else np.linalg.eigvalsh(T@H@T)
    return dict(W0=W0,w=w,grad_noncov=Gres,H_shape_excess=np.linalg.norm(shape)/np.linalg.norm(Hcov),
                H_vol_excess=np.linalg.norm(vol)/np.linalg.norm(Hcov),shape_eigs_H=np.sort(np.linalg.eigvalsh(T@H@T))[1:],
                shape_eig_cov=-0.5*w)
if __name__=="__main__":
    for rule in ['bond','support','const']:
        for M in (16,24):
            r=analyse(rule,M)
            print('%-8s M=%d  w=%+.5f  gradient non-covariant %.1e | Hessian excess over sqrt(g): shape %.3f  volume %.3f'%(rule,M,r['w'],r['grad_noncov'],r['H_shape_excess'],r['H_vol_excess']))
            print('          shape-sector eigenvalues of Hessian:',np.round(r['shape_eigs_H'],5),' covariant value:',round(r['shape_eig_cov'],5))
