"""Induced Newton constant from the vacuum 'ocean' (Sakharov), proper-time cutoff eps = 1/Lambda^2.
Per species, the R-coefficient of Gamma = -(1/2) s Int dt/t Tr K, with Tr K ~ (4 pi t)^-2 Int sqrt(g) [N + t a1 R].
Derived a1 (Laplace-type D = -(nabla^2 + E), a1 = tr(E + R/6)):
  real scalar, coupling xi R : a1 = 1/6 - xi                     (bosonic, s=+1)
  Dirac, D^2 = -nabla^2 + R/4 (4 comps): a1 = 4(1/6 - 1/4) = -1/3 (fermionic: Gamma = +1/2 Int dt/t TrK(D^2))
  Maxwell + FP ghosts, Feynman gauge: a1 = [4/6 - 1] - 2*(1/6) = -2/3 (bosonic)
Result: 1/G_ind = C * Lambda^2/(12 pi),  C = N_s(1-6 xi) + N_Weyl + 2 N_Dirac - 4 N_V."""
import numpy as np
from math import pi, log
def C(Ns=0,xi=0.0,Nw=0,Nd=0,Nv=0): return Ns*(1-6*xi)+Nw+2*Nd-4*Nv
# per-species check of the unit (real minimal scalar): R-term of Gamma = -(1/2)(1/16pi^2)(1/6) Lambda^2 Int R
unit=0.5*(1/(16*pi**2))*(1/6)          # coefficient multiplying Lambda^2 Int R, equals 1/(16 pi G) per unit C
print('unit check: 1/(16 pi G) per minimal real scalar = Lambda^2 *',unit,' = Lambda^2/(192 pi^2):',np.isclose(unit,1/(192*pi**2)))
# cutoff from mode counting, two natural identifications (D4 nearest-neighbour distance L, volume per site L^4/2):
#  (a) heat-kernel density at t=Lambda^-2 equals one mode per site:   (4 pi / Lambda^2)^-2 = 2/L^4  -> Lambda L = (32 pi^2)^(1/4)
#  (b) Debye ball |p|<Lambda holds one mode per site: Lambda^4/(32 pi^2) = 2/L^4               -> Lambda L = (64 pi^2)^(1/4)
# The quadratic divergence has the same Lambda^2/(16 pi^2) coefficient in proper-time and sharp-momentum regularization.
area=4*log(2)                           # area law: 1/G = 4 ln2 / L^2
schemes={'heat-kernel density':(32*pi**2)**0.25,'Debye ball':(64*pi**2)**0.25}
Creq={}
for k,LamL in schemes.items():
    Creq[k]=area/(LamL**2/(12*pi))
    print('%-20s Lambda*L_f = %.4f   required C = %.3f'%(k,LamL,Creq[k]))
contents=[('Standard Model (45 Weyl, 12 vectors, Higgs 4, minimal)',dict(Ns=4,Nw=45,Nv=12)),
          ('SM + 3 right-handed neutrinos (48 Weyl = 3 x 16)',dict(Ns=4,Nw=48,Nv=12)),
          ('SM + nu_R, Higgs conformal (xi = 1/6)',dict(Ns=4,xi=1/6,Nw=48,Nv=12)),
          ('left-right: 15 vectors, 48 Weyl, bidoublet + 2 doublets (16 real scalars)',dict(Ns=16,Nw=48,Nv=15)),
          ('Pati-Salam with the same 16 real scalars: 21 vectors, 48 Weyl',dict(Ns=16,Nw=48,Nv=21))]
rows=[]
for name,kw in contents:
    c=C(**kw)
    rat={k:(Creq[k]/c if c>0 else float('nan')) for k in Creq}
    tag='  '.join('%s: %s'%(k,('%.2f'%v) if c>0 else ('no induced G' if c==0 else 'negative G')) for k,v in rat.items())
    print('%-75s C = %6.1f   G_ind/G_area -> %s'%(name,c,tag))
    rows.append((name,c,rat))
import json; json.dump(dict(schemes=schemes,Creq=Creq,rows=rows),open('newton.json','w'),indent=1)
