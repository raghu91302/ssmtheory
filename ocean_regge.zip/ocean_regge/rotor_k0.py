"""Induced action of a U(1) gauge field (rotor sector, Gaussian) on the D4 root complex under uniform strain.
A on the 12 root classes (edges), plaquettes = equilateral root triangles (32 per vertex).
W(eps) = 1/2 < sum log nonzero-eig( d1(q)^+ K d1(q) ) >_BZ  per vertex. Gauge kernel excluded."""
import numpy as np, itertools as it
roots=[]
for i,j in it.combinations(range(4),2):
    for si,sj in it.product([1,-1],repeat=2):
        v=np.zeros(4,int); v[i]=si; v[j]=sj; roots.append(v)
roots=np.array(roots)
canon=[r for r in roots if tuple(r)>tuple(-r)]; R=np.array(canon,float); NC=len(R)
cidx={tuple(r):k for k,r in enumerate(canon)}
def edge(u,v):                       # oriented edge u->v : (class, base position, sign)
    d=tuple(v-u)
    if d in cidx: return cidx[d],u,+1
    return cidx[tuple(-np.array(d))],v,-1
# triangles containing 0: {0,a,b}, a,b roots with a.b = 1; canonical rep: translate smallest vertex to 0
tri=set()
for a in roots:
    for b in roots:
        if a@b==1:
            P=[np.zeros(4,int),a,b]; m=min(P,key=tuple); T=tuple(sorted(tuple(p-m) for p in P)); tri.add(T)
tri=sorted(tri); NT=len(tri)
rows=[]
for T in tri:
    P=[np.array(p) for p in T]; rows.append([edge(P[0],P[1]),edge(P[1],P[2]),edge(P[2],P[0])])
tri_edges=[[r[0] for r in row] for row in rows]
def d1(q):
    D=np.zeros((NT,NC),complex)
    for t,row in enumerate(rows):
        for c,base,s in row: D[t,c]+=s*np.exp(1j*q@base)
    return D
def grid(M):
    x=(np.arange(M)+0.5)*2*np.pi/M
    return np.stack(np.meshgrid(x,x,x,x,indexing='ij'),-1).reshape(-1,4)
class Rotor:
    def __init__(self,M):
        self.Q=grid(M); self.D=np.array([d1(q) for q in self.Q])      # (nq,NT,NC)
        # check structure: nonzero eigenvalue count at K=1
        Mq=np.einsum('qtc,qtd->qcd',self.D.conj(),self.D); ev=np.linalg.eigvalsh(Mq)
        self.nzero=int(np.median((ev<1e-9*ev.max()).sum(1)))
    def W(self,K):
        Mq=np.einsum('qtc,t,qtd->qcd',self.D.conj(),K,self.D); ev=np.linalg.eigvalsh(Mq)
        ev=ev[:,self.nzero:]; return 0.5*np.mean(np.log(ev).sum(1))
def K_of(eps,rule,p=1.0):
    l=np.sqrt(np.einsum('ci,ij,cj->c',R,np.eye(4)+eps,R))
    L=np.array([[l[c] for c in te] for te in tri_edges])            # (NT,3) bond lengths per plaquette
    if rule=='bond':    return (1/L).mean(1)
    if rule=='support': return 1/L.mean(1)
    if rule=='const':   return np.ones(NT)
    if rule=='power':   return L.mean(1)**(-p)
Eb=[]
for m in range(4):
    for n in range(m,4):
        E=np.zeros((4,4)); E[m,n]=E[n,m]=1.0 if m==n else 1/np.sqrt(2); Eb.append(E)
def test(rot,rule,p=1.0,h=1e-3):
    W=lambda e: rot.W(K_of(e,rule,p))
    E0=np.eye(4)/2; w=(W(h*E0)-W(-h*E0))/(2*h)/(0.5*np.trace(E0))
    grads=np.array([(W(h*E)-W(-h*E))/(2*h) for E in Eb]); tr=np.array([np.trace(E) for E in Eb])
    iso=np.linalg.norm(grads-(w/2)*tr)/max(np.linalg.norm(grads),1e-30)
    shapes=[]
    for E in [np.diag([1,-1,0,0.])/np.sqrt(2),Eb[1],np.diag([1,1,-1,-1.])/2]:
        shapes.append((W(h*E)-2*W(0*E)+W(-h*E))/h**2)
    return w,iso,np.array(shapes),-0.5*w
if __name__=="__main__":
    print('edge classes %d, plaquette classes %d per vertex'%(NC,NT))
    for M in (8,12):
        rot=Rotor(M); print('M=%d  gauge zero modes per q: %d'%(M,rot.nzero))
        for rule in ['const','bond','support']:
            w,iso,s,c=test(rot,rule)
            print('   %-8s w=%+.5f  gradient anisotropy %.1e  shape eigs %s  covariant %+.5f  ratio %s'%(rule,w,iso,np.round(s,5),c,np.round(s/c,3) if c!=0 else '-'))
