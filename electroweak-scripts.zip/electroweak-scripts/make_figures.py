import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
plt.rcParams.update({'font.size':10,'font.family':'serif','mathtext.fontset':'cm'})

OUT='./'

# ============================================================
# FIGURE 1: the defect bond complex and its homology H1=3, H2=1
# ============================================================
A=np.array([0,0,0.]); B=np.array([1,1,0.]); C=np.array([1,0,1.]); D=np.array([0,1,1.])
c=(A+B+C+D)/4
verts={'A':A,'B':B,'C':C,'D':D}

fig=plt.figure(figsize=(7,3.4))
# --- left panel: the complex ---
ax=fig.add_subplot(1,2,1,projection='3d')
# filled triangular faces (the 2-cells)
faces=[[A,B,C],[A,B,D],[A,C,D],[B,C,D]]
pc=Poly3DCollection(faces,alpha=0.13,facecolor='#4477aa',edgecolor='none')
ax.add_collection3d(pc)
# tetrahedron edges (K4)
tet_edges=[(A,B),(A,C),(A,D),(B,C),(B,D),(C,D)]
ax.add_collection3d(Line3DCollection(tet_edges,colors='#333333',linewidths=1.4))
# defect bonds c -> vertices
def_edges=[(c,A),(c,B),(c,C),(c,D)]
ax.add_collection3d(Line3DCollection(def_edges,colors='#cc6677',linewidths=1.4,linestyles='-'))
# nodes
for name,p in verts.items():
    ax.scatter(*p,s=55,c='#222222',depthshade=False)
    ax.text(p[0],p[1],p[2]+0.08,name,fontsize=10)
ax.scatter(*c,s=90,marker='*',c='#ddaa33',depthshade=False,edgecolor='k',linewidth=0.5)
ax.text(c[0]+0.05,c[1],c[2]-0.12,'trapped node',fontsize=8,color='#886611')
ax.set_title('(a) defect bond complex',fontsize=10)
ax.set_axis_off()
ax.view_init(elev=18,azim=35)

# --- right panel: the two homology sectors ---
ax2=fig.add_subplot(1,2,2,projection='3d')
# H2 = 1: the enclosing surface (shade all faces)
pc2=Poly3DCollection(faces,alpha=0.22,facecolor='#ddaa33',edgecolor='#997711',linewidths=0.5)
ax2.add_collection3d(pc2)
ax2.add_collection3d(Line3DCollection(tet_edges,colors='#bbbbbb',linewidths=0.8))
# H1 = 3: three independent skew-edge cycles (color cycles). Draw 3 triangles c-edge loops
cyc_colors=['#ee3333','#33aa33','#3366cc']
skew=[[c,A,B],[c,C,D],[c,A,C]]  # three representative independent 1-cycles
for k,(p0,p1,p2) in enumerate(skew):
    loop=[(p0,p1),(p1,p2),(p2,p0)]
    ax2.add_collection3d(Line3DCollection(loop,colors=cyc_colors[k],linewidths=2.0))
for name,p in verts.items(): ax2.scatter(*p,s=30,c='#444444',depthshade=False)
ax2.scatter(*c,s=70,marker='*',c='#ddaa33',depthshade=False,edgecolor='k',linewidth=0.5)
ax2.set_title('(b) $H_1{=}3$ (electric/color), $H_2{=}1$ (magnetic)',fontsize=9)
ax2.set_axis_off()
ax2.view_init(elev=18,azim=35)
# legend
from matplotlib.lines import Line2D
leg=[Line2D([0],[0],color='#cc6677',lw=1.6,label='defect bonds'),
     Line2D([0],[0],color='#333333',lw=1.6,label='tetrahedron edges'),
     Line2D([0],[0],color='#3366cc',lw=2,label=r'$H_1$ cycles ($\times 3$)'),
     Line2D([0],[0],marker='s',color='w',markerfacecolor='#ddaa33',markersize=9,label=r'$H_2$ surface')]
fig.legend(handles=leg,loc='lower center',ncol=4,fontsize=7.5,frameon=False,bbox_to_anchor=(0.5,-0.02))
plt.tight_layout(rect=[0,0.05,1,1])
plt.savefig(OUT+'fig_defect_homology.pdf',bbox_inches='tight',dpi=200)
plt.close()
print('fig 1 done')

# ============================================================
# FIGURE 2: the logical spine of the reduction
# ============================================================
fig,ax=plt.subplots(figsize=(6.6,6.4))
ax.set_xlim(0,10); ax.set_ylim(0,13); ax.axis('off')
def box(x,y,w,h,txt,fc='#eef2f7',ec='#334455',fs=8.5,tc='#111'):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.08,rounding_size=0.15",
                fc=fc,ec=ec,lw=1.1))
    ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=fs,color=tc)
def arrow(x1,y1,x2,y2,txt='',col='#334455'):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=12,
                color=col,lw=1.1))
    if txt: ax.text((x1+x2)/2+0.15,(y1+y2)/2,txt,fontsize=7.5,ha='left',color=col)

box(2.8,11.6,4.4,1.0,'matter = defect in the\nFCC / D4 vacuum stabilizer code',fc='#f5f0e6',ec='#8a7a4a')
box(0.2,9.6,4.3,1.3,r'FCC ($A_3$): residual doublet' '\n' r'is REAL & SPATIAL',fc='#fbeaea',ec='#aa4444')
box(5.5,9.6,4.3,1.3,r'D4 root lattice of $\mathfrak{so}(8)$:' '\n' r'internal pseudoreal $SU(2)$',fc='#eaf3ea',ec='#448844')
arrow(4.4,11.6,2.6,10.9); arrow(5.6,11.6,7.4,10.9)
ax.text(1.6,10.75,r'$\times$ Coleman--Mandula',fontsize=7,color='#aa4444')

box(5.5,7.7,4.3,1.3,r'spinor $\mathbf{8}_s\to$ LH $SU(2)_L$ doublet' '\n' r'= chiral electroweak fermion',fc='#eaf3ea',ec='#448844')
arrow(7.65,9.6,7.65,9.0)

box(5.5,5.8,4.3,1.3,r'spin-$\frac{1}{2}$ from tethered defect' '\n' r'(Finkelstein--Rubinstein, isotropic)',fc='#eef2f7')
arrow(7.65,7.7,7.65,7.1)

box(5.5,3.9,4.3,1.3,r'$N$ edges $\to \mathrm{Spin}(2N)$;' '\n' r'$N{=}5\to \mathrm{Spin}(10)$, $\mathbf{16}=$ generation',fc='#eef2f7')
arrow(7.65,5.8,7.65,5.2)

box(0.2,3.9,4.3,1.9,r'defect bond complex homology:' '\n' r'$H_1=3$ (electric = color)' '\n' r'$H_2=1$ (magnetic)' '\n' r'on the verified CSS code',fc='#eaf0f7',ec='#33557a')
arrow(4.5,4.85,5.5,4.55)

box(2.8,1.6,4.4,1.3,r'$\theta=(-1)^{pq}=-1$: FERMION' '\n' r'$\Rightarrow$ spinor $\mathbf{8}_s \subset \mathbf{16}$',fc='#f5f0e6',ec='#8a7a4a',fs=9)
arrow(2.35,3.9,3.6,2.9); arrow(7.65,3.9,6.4,2.9)

ax.text(5,0.6,'chiral electroweak structure as a homological fact of the vacuum',
        ha='center',fontsize=8.5,style='italic',color='#333')
plt.tight_layout()
plt.savefig(OUT+'fig_reduction_spine.pdf',bbox_inches='tight',dpi=200)
plt.close()
print('fig 2 done')
