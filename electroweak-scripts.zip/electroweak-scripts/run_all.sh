#!/usr/bin/env bash
# Reproduce every computation in the paper (flat layout: run from this directory).
set -e
cd "$(dirname "$0")"
for s in sec3_4_representation sec5_spin sec6_clifford sec7_theta_toric \
         sec8_defect_homology sec8_fcc_code_check \
         sec6b_single_void_no_qubit sec6c_minimal_string sec6d_string_geometry; do
  echo "===== $s ====="; python3 "$s.py"; echo
done
echo "All computations complete."
