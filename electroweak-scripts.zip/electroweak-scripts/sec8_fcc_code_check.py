"""sec8_fcc_code_check.py -- Section 8.2. FCC code from stated rules is a valid CSS code
(-> the homological dictionary H1<->electric, H2<->magnetic is the code's real structure)."""
import itertools
L=3
sites=[p for p in itertools.product(range(L+1),repeat=3) if sum(p)%2==0]; sset=set(sites)
D=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
def nb(p): return [q for d in D for q in [tuple(p[i]+d[i] for i in range(3))] if q in sset]
edges=sorted({frozenset((p,q)) for p in sites for q in nb(p)},key=lambda e:tuple(sorted(e)))
ei={e:i for i,e in enumerate(edges)}
Z=[sorted({ei[frozenset((p,q))] for q in nb(p)}) for p in sites]; Z=[z for z in Z if z]
def octa(c): return [tuple(c[i]+(s if i==ax else 0) for i in range(3)) for ax in range(3) for s in (1,-1)]
X=[]
for c in itertools.product(range(L+1),repeat=3):
    if sum(c)%2==1 and all(v in sset for v in octa(c)):
        vs=octa(c);sp=sorted({ei[frozenset((a,b))] for a,b in itertools.combinations(vs,2)
            if sum((a[i]-b[i])**2 for i in range(3))==2 and frozenset((a,b)) in ei})
        if len(sp)>=6:X.append(sp)
bad=sum(1 for z in Z for x in X if len(set(z)&set(x))%2)
print(f"FCC L={L}: {len(sites)} sites {len(edges)} qubits; Z-checks {len(Z)} X-checks {len(X)}")
print(f"anticommuting Z-X pairs = {bad} (must be 0) -> valid CSS: {bad==0}")
print(f"Z weights {sorted(set(len(z) for z in Z))}  X weights {sorted(set(len(x) for x in X))}")
print("=> homological dictionary is the code's actual structure.")
