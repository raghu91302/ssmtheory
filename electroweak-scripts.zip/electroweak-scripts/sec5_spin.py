"""sec5_spin.py -- Section 5. Finkelstein-Rubinstein isotropic spin-1/2."""
import numpy as np, scipy.linalg as sla
sx=np.array([[0,1],[1,0]]);sy=np.array([[0,-1j],[1j,0]]);sz=np.array([[1,0],[0,-1]]);J=[sx/2,sy/2,sz/2]
print("2pi rotation on the double-valued sector, several axes:")
for a in [(1,0,0),(0,1,0),(0,0,1),(1,1,1),(2,-1,3),(1,-2,2)]:
    n=np.array(a,float);n/=np.linalg.norm(n)
    U=sla.expm(1j*2*np.pi*sum(n[k]*J[k] for k in range(3)))
    print(f"  axis {a}: -I ? {np.allclose(U,-np.eye(2))}")
print("  4pi -> +I:",np.allclose(sla.expm(1j*4*np.pi*(sz/2)),np.eye(2)))
c=lambda A,B:A@B-B@A
print("  su(2) closes:",np.allclose(c(J[0],J[1]),1j*J[2]) and np.allclose(c(J[1],J[2]),1j*J[0]))
print("  => isotropic spin-1/2 from lattice topology; no fundamental spinor field.")
