"""sec6_clifford.py -- Section 6. Edge count -> Spin(2N); N=5 -> Spin(10), 16=generation."""
import itertools
from fractions import Fraction as F
print("N edges -> emergent group:")
for N in (4,5,6): print(f"  N={N}: 2N={2*N} Majoranas -> Spin({2*N}), spinor dim {2**(N-1)}")
print("  N=4->Spin(8):8_s ; N=5->Spin(10):16=one generation\n")
six=[w for w in itertools.product((F(1,2),F(-1,2)),repeat=5) if sum(x<0 for x in w)%2==0]
from collections import Counter
for (t,u),c in sorted(Counter(('8_s' if sum(x<0 for x in w[:4])%2==0 else '8_c',w[4]) for w in six).items()):
    print(f"  {c}x {t} U(1)={u}")
print("  => SO(10) 16 = 8_s(+1/2)+8_c(-1/2); chiral EW fermion inside the generation.")
