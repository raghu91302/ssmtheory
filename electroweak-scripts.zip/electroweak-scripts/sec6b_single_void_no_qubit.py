import numpy as np, itertools

# ---------- GF(2) linear algebra ----------
def rref(M):
    M=M.copy()%2; rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=next((i for i in range(r,rows) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
        if r==rows: break
    return M[:r], piv
def nullspace(M):
    R,piv=rref(M); cols=M.shape[1]; pivset=set(piv); basis=[]
    for free in range(cols):
        if free in pivset: continue
        v=np.zeros(cols,int); v[free]=1
        for ri,pc in enumerate(piv): v[pc]=R[ri,free]
        basis.append(v%2)
    return basis
def in_rowspace(M,v):
    if len(M)==0: return not v.any()
    R,_=rref(M); A=np.vstack([R,v%2]); R2,_=rref(A)
    return R2.shape[0]==R.shape[0]  # adding v didn't raise the rank

# ---------- build the FCC code on a patch ----------
L=6
sites=[p for p in itertools.product(range(L+1),repeat=3) if sum(p)%2==0]; sset=set(sites)
DIRS=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
def nbrs(p): return [tuple(p[i]+d[i] for i in range(3)) for d in DIRS if tuple(p[i]+d[i] for i in range(3)) in sset]
edges=sorted({frozenset((p,q)) for p in sites for q in nbrs(p)}, key=lambda e:tuple(sorted(e)))
eidx={e:i for i,e in enumerate(edges)}; n=len(edges)
def mat(rows):
    M=np.zeros((len(rows),n),int)
    for i,r in enumerate(rows):
        for j in r: M[i,j]^=1
    return M
HZ=mat([[eidx[frozenset((p,q))] for q in nbrs(p)] for p in sites if nbrs(p)])
def octa(c): return [tuple(c[i]+(s if i==ax else 0) for i in range(3)) for ax in range(3) for s in (1,-1)]
Xrows=[]
for c in itertools.product(range(L+1),repeat=3):
    if sum(c)%2==1 and all(v in sset for v in octa(c)):
        vs=octa(c); supp=[eidx[frozenset((a,b))] for a,b in itertools.combinations(vs,2)
              if sum((a[i]-b[i])**2 for i in range(3))==2 and frozenset((a,b)) in eidx]
        if len(supp)==12: Xrows.append(sorted(set(supp)))
HX=mat(Xrows)
print(f"patch L={L}: {len(sites)} sites, {n} edge-qubits, {HZ.shape[0]} Z-checks, {HX.shape[0]} X-checks")

# ---------- one interior tetrahedral void, its 6 local edges ----------
base=(2,2,2)
tverts=[tuple(base[i]+d[i] for i in range(3)) for d in [(0,0,0),(1,1,0),(1,0,1),(0,1,1)]]
assert all(v in sset for v in tverts)
S=[eidx[frozenset((a,b))] for a,b in itertools.combinations(tverts,2)]
assert len(S)==6
print(f"tetrahedral void at {base}: local support = {len(S)} edges")

# ---------- local X-operators commuting with all Z-checks, mod X-stabilizers ----------
HZ_S=HZ[:,S]
localX=[]
for v6 in nullspace(HZ_S):                 # X-op on S commuting with Z-checks
    if not v6.any(): continue
    x=np.zeros(n,int); x[S]=v6
    if not in_rowspace(HX,x):              # not a product of X-stabilizers => logical
        localX.append(v6)
# local Z-operators commuting with all X-checks, mod Z-stabilizers
HX_S=HX[:,S]
localZ=[]
for v6 in nullspace(HX_S):
    if not v6.any(): continue
    z=np.zeros(n,int); z[S]=v6
    if not in_rowspace(HZ,z):
        localZ.append(v6)
print(f"local X-operators commuting w/ Z-checks that are NOT X-stabilizers: {len(localX)}")
print(f"local Z-operators commuting w/ X-checks that are NOT Z-stabilizers: {len(localZ)}")

# ---------- decisive test: an anticommuting local (X,Z) pair on S ? ----------
found=False
for xv in localX:
    for zv in localZ:
        if int(np.dot(xv,zv))%2==1:         # odd overlap => anticommute
            found=True; break
    if found: break
print("\n"+"="*60)
if found:
    print("A LOCAL LOGICAL QUBIT EXISTS on the single void (anticommuting X,Z pair).")
    print("=> the logical string need NOT extend; the 5-edge synthesis is NOT forced.")
else:
    print("NO anticommuting local (X,Z) pair on the single tetrahedral void.")
    print("=> the void hosts NO complete logical qubit by itself; any logical")
    print("   operator must extend beyond it. The body/state synthesis is FORCED,")
    print("   and the quantum identity spans into the neighbor (>=1 extra bond).")
