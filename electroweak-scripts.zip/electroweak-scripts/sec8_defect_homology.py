"""sec8_defect_homology.py -- Section 8 (main). Defect homology H1=3,H2=1 -> theta=-1."""
import numpy as np, itertools
nodes=['c','A','B','C','D']; ix={n:i for i,n in enumerate(nodes)}
edges=[('c','A'),('c','B'),('c','C'),('c','D'),('A','B'),('A','C'),('A','D'),('B','C'),('B','D'),('C','D')]
faces=[('A','B','C'),('A','B','D'),('A','C','D'),('B','C','D')]
ei={frozenset(e):j for j,e in enumerate(edges)}
def rk(M):
    M=M.copy()%2;r=0;R,C=M.shape
    for c in range(C):
        p=next((i for i in range(r,R) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(R):
            if i!=r and M[i,c]:M[i]^=M[r]
        r+=1
    return r
d1=np.zeros((5,10),int)
for j,(u,w) in enumerate(edges):d1[ix[u],j]^=1;d1[ix[w],j]^=1
d2=np.zeros((10,4),int)
for k,(x,y,z) in enumerate(faces):
    for u,w in[(x,y),(y,z),(x,z)]:d2[ei[frozenset((u,w))],k]^=1
r1,r2=rk(d1),rk(d2);H1=(10-r1)-r2;H2=4-r2
print(f"H1=(10-{r1})-{r2}={H1} (electric=color)  H2=4-{r2}={H2} (magnetic)")
print(f"(p,q)=({int(H1>0)},{int(H2>0)}) -> theta={(-1)**(int(H1>0)*int(H2>0)):+d} => FERMION (spinor 8_s)")
