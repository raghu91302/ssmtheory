import numpy as np, itertools

def rref(M):
    M=M.copy()%2; rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=next((i for i in range(r,rows) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
        if r==rows: break
    return M[:r], piv
def nullspace(M):
    R,piv=rref(M); cols=M.shape[1]; ps=set(piv); B=[]
    for f in range(cols):
        if f in ps: continue
        v=np.zeros(cols,int); v[f]=1
        for ri,pc in enumerate(piv): v[pc]=R[ri,f]
        B.append(v%2)
    return B
def checker(M):
    R,_=rref(M); base=R.shape[0]
    return lambda v: rref(np.vstack([R,(v%2)]))[0].shape[0]==base

L=6
sites=[p for p in itertools.product(range(L+1),repeat=3) if sum(p)%2==0]; sset=set(sites)
DIRS=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
def nbrs(p): return [q for d in DIRS for q in [tuple(p[i]+d[i] for i in range(3))] if q in sset]
edges=sorted({frozenset((p,q)) for p in sites for q in nbrs(p)}, key=lambda e:tuple(sorted(e)))
eidx={e:i for i,e in enumerate(edges)}; n=len(edges)
inv_e={i:tuple(sorted(e)) for e,i in eidx.items()}
emid={i:np.mean([np.array(x) for x in e],axis=0) for e,i in eidx.items()}
def mat(rows):
    M=np.zeros((len(rows),n),int)
    for i,r in enumerate(rows):
        for j in r: M[i,j]^=1
    return M
HZ=mat([[eidx[frozenset((p,q))] for q in nbrs(p)] for p in sites if nbrs(p)])
def octa(c): return [tuple(c[i]+(s if i==ax else 0) for i in range(3)) for ax in range(3) for s in (1,-1)]
Xr=[]
for c in itertools.product(range(L+1),repeat=3):
    if sum(c)%2==1 and all(v in sset for v in octa(c)):
        vs=octa(c); sp=[eidx[frozenset((a,b))] for a,b in itertools.combinations(vs,2)
             if sum((a[i]-b[i])**2 for i in range(3))==2 and frozenset((a,b)) in eidx]
        if len(sp)==12: Xr.append(sorted(set(sp)))
HX=mat(Xr)
inHX=checker(HX); inHZ=checker(HZ)

base=(2,2,2)
tverts=[tuple(base[i]+d[i] for i in range(3)) for d in [(0,0,0),(1,1,0),(1,0,1),(0,1,1)]]
tvset=set(tverts)
centroid=np.mean([np.array(v) for v in tverts],axis=0)
S6=set(eidx[frozenset((a,b))] for a,b in itertools.combinations(tverts,2))
order=sorted(range(n), key=lambda i: np.linalg.norm(emid[i]-centroid))

# find the minimal 5-edge logical pair in the smallest region
R=sorted(set(order[:8]))
lx=[(v,(lambda z: (z))(np.zeros(n,int))) for v in []]
LX=[]; LZ=[]
for v in nullspace(HZ[:,R]):
    if v.any():
        x=np.zeros(n,int); x[R]=v
        if not inHX(x): LX.append(x)
for v in nullspace(HX[:,R]):
    if v.any():
        z=np.zeros(n,int); z[R]=v
        if not inHZ(z): LZ.append(z)
best=None
for x in LX:
    for z in LZ:
        if int(np.dot(x,z))%2==1:
            supp=np.where(x|z)[0]
            if best is None or len(supp)<len(best[2]):
                best=(x,z,supp)
x,z,supp=best
print(f"minimal logical qubit union support = {len(supp)} edges")
print("\nedges in the minimal logical operator, with their endpoints:")
in_void=0; touching=0
allverts=set()
for i in sorted(supp):
    (u,w)=inv_e[i]
    inV = (u in tvset and w in tvset)
    touch = (u in tvset or w in tvset)
    in_void+=inV; touching+=touch
    allverts.update([u,w])
    typ = 'X' if x[i] else '.'
    typz= 'Z' if z[i] else '.'
    print(f"  edge {u}-{w}   [{typ}{typz}]   {'(inside void)' if inV else ('(touches void)' if touch else '(outside)')}")
print(f"\nvertices spanned: {sorted(allverts)}")
print(f"edges fully inside the body void: {in_void}")
print(f"edges touching the body void: {touching}")
print(f"edges reaching outside: {len(supp)-touching}")

# which voids do the outside vertices belong to?
outside_verts=allverts - tvset
print(f"vertices beyond the body void: {sorted(outside_verts)}")
print("\ninterpretation:")
if in_void>=1 and len(outside_verts)>=1:
    print("  the minimal qubit has support BOTH inside the body void AND reaching to")
    print("  neighboring vertices -> the 'body local + string into neighbor' picture,")
    print("  but the exact split is shown above (not necessarily 4+1).")
