import numpy as np, itertools

def rref(M):
    M=M.copy()%2; rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=next((i for i in range(r,rows) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
        if r==rows: break
    return M[:r], piv
def nullspace(M):
    R,piv=rref(M); cols=M.shape[1]; ps=set(piv); B=[]
    for f in range(cols):
        if f in ps: continue
        v=np.zeros(cols,int); v[f]=1
        for ri,pc in enumerate(piv): v[pc]=R[ri,f]
        B.append(v%2)
    return B
def make_rank_checker(M):
    R,_=rref(M); base=R.shape[0]
    def contains(v):
        A=np.vstack([R,(v%2)]); R2,_=rref(A); return R2.shape[0]==base
    return contains

# --- build FCC code (L=6) ---
L=6
sites=[p for p in itertools.product(range(L+1),repeat=3) if sum(p)%2==0]; sset=set(sites)
DIRS=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
def nbrs(p): return [q for d in DIRS for q in [tuple(p[i]+d[i] for i in range(3))] if q in sset]
edges=sorted({frozenset((p,q)) for p in sites for q in nbrs(p)}, key=lambda e:tuple(sorted(e)))
eidx={e:i for i,e in enumerate(edges)}; n=len(edges)
emid={i:np.mean([np.array(x) for x in e],axis=0) for e,i in eidx.items()}
def mat(rows):
    M=np.zeros((len(rows),n),int)
    for i,r in enumerate(rows):
        for j in r: M[i,j]^=1
    return M
HZ=mat([[eidx[frozenset((p,q))] for q in nbrs(p)] for p in sites if nbrs(p)])
def octa(c): return [tuple(c[i]+(s if i==ax else 0) for i in range(3)) for ax in range(3) for s in (1,-1)]
Xr=[]
for c in itertools.product(range(L+1),repeat=3):
    if sum(c)%2==1 and all(v in sset for v in octa(c)):
        vs=octa(c); sp=[eidx[frozenset((a,b))] for a,b in itertools.combinations(vs,2)
             if sum((a[i]-b[i])**2 for i in range(3))==2 and frozenset((a,b)) in eidx]
        if len(sp)==12: Xr.append(sorted(set(sp)))
HX=mat(Xr)
inHX=make_rank_checker(HX); inHZ=make_rank_checker(HZ)

# void at (2,2,2)
base=(2,2,2)
tverts=[tuple(base[i]+d[i] for i in range(3)) for d in [(0,0,0),(1,1,0),(1,0,1),(0,1,1)]]
centroid=np.mean([np.array(v) for v in tverts],axis=0)
S6=[eidx[frozenset((a,b))] for a,b in itertools.combinations(tverts,2)]

# order edges by distance of midpoint to void centroid
order=sorted(range(n), key=lambda i: np.linalg.norm(emid[i]-centroid))

def has_logical_qubit(R):
    R=sorted(set(R))
    # local X-ops commuting with Z-checks, not X-stabilizers
    lx=[]
    for v in nullspace(HZ[:,R]):
        if not v.any(): continue
        x=np.zeros(n,int); x[R]=v
        if not inHX(x): lx.append((R,v,x))
    lz=[]
    for v in nullspace(HX[:,R]):
        if not v.any(): continue
        z=np.zeros(n,int); z[R]=v
        if not inHZ(z): lz.append((R,v,z))
    best=None
    for _,_,x in lx:
        for _,_,z in lz:
            if int(np.dot(x,z))%2==1:
                supp=int((x|z).sum())
                if best is None or supp<best: best=supp
    return best  # None if no qubit; else minimal union-support size

print("growing support region outward from the single void:")
prev=None
first=None
for k in range(6,80,2):
    R=order[:k]
    b=has_logical_qubit(R)
    tag=""
    if b is not None and first is None:
        first=(len(set(R)),b); tag="  <-- first complete logical qubit"
    if b!=prev:
        print(f"  region = {len(set(R)):3d} edges : logical qubit? {'yes, min union-support '+str(b) if b else 'no'}{tag}")
    prev=b
    if first and len(set(R))>first[0]+20: break

print("\n"+"="*60)
if first:
    region_edges, supp = first
    beyond = supp  # union support of the minimal completing pair
    print(f"A complete logical qubit first appears when the support reaches ~{region_edges} edges;")
    print(f"the minimal logical qubit's operators together touch {supp} edges.")
    print(f"The single void contributes 6 local edges; the string must reach")
    print(f"{supp-6 if supp>6 else 0}+ edges beyond it to close the anticommuting pair.")
else:
    print("no local logical qubit found within the grown region (string reaches farther).")
