import numpy as np, itertools

# ---------- D4 lattice: integer 4-vectors with even coordinate sum ----------
# nearest neighbors = 24 roots of so(8): (+-1,+-1,0,0) and permutations, norm sqrt2.
roots=[]
for i,j in itertools.combinations(range(4),2):
    for si in (1,-1):
        for sj in (1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; roots.append(tuple(v))
print(f"D4 nearest neighbors (kissing number): {len(roots)}  (expect 24)")

# ---------- deep holes: odd-sum points; find surrounding lattice points ----------
hole=(1,0,0,0)   # odd sum -> a deep hole
# lattice points (even sum) at minimal distance from the hole
cands=[tuple(hole[k]+d[k] for k in range(4)) for d in itertools.product((-1,0,1),repeat=4)]
def evensum(p): return sum(p)%2==0
surround=sorted({p for p in cands if evensum(p) and 0<sum((p[k]-hole[k])**2 for k in range(4))<=1.001})
print(f"lattice points bounding the deep hole at {hole}: {len(surround)}")
d2h=sorted(set(round(sum((p[k]-hole[k])**2 for k in range(4)),3) for p in surround))
print(f"  their squared distances to the hole: {d2h}")
# is it a 16-cell (cross-polytope)? antipodal pairs about the hole
h=np.array(hole)
pairs=0
sset=set(surround)
for p in surround:
    anti=tuple(2*hole[k]-p[k] for k in range(4))
    if anti in sset: pairs+=1
print(f"  vertices forming antipodal pairs about the hole: {pairs}/{len(surround)}  (16-cell has 8 vertices in 4 pairs)")

# ---------- edges of the bounding cell (nearest-neighbor bonds among the 8) ----------
def nn(a,b): return sum((a[k]-b[k])**2 for k in range(4))==2  # root distance
cell_edges=[(a,b) for a,b in itertools.combinations(surround,2) if nn(a,b)]
print(f"  edges among bounding vertices (at root distance): {len(cell_edges)}  (16-cell has 24 edges)")

# ---------- does it contain tetrahedral K4 cells -> 3 colors? ----------
verts=surround
tets=[q for q in itertools.combinations(range(len(verts)),4)
      if all(nn(verts[a],verts[b]) for a,b in itertools.combinations(q,2))]
print(f"  tetrahedral (K4) sub-cells among the 8 vertices: {len(tets)}  (each gives 3 skew-pair colors)")

# ================= DEFECT COMPLEX HOMOLOGY on D4 =================
def rk(M):
    M=M.copy()%2; r=0; R,C=M.shape
    for c in range(C):
        p=next((i for i in range(r,R) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(R):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r

def homology(nodes, edges, faces):
    idx={x:i for i,x in enumerate(nodes)}
    ei={frozenset(e):j for j,e in enumerate(edges)}
    V,E,F=len(nodes),len(edges),len(faces)
    d1=np.zeros((V,E),int)
    for j,(u,w) in enumerate(edges): d1[idx[u],j]^=1; d1[idx[w],j]^=1
    d2=np.zeros((E,F),int)
    for k,f in enumerate(faces):
        vs=list(f)
        for u,w in [(vs[0],vs[1]),(vs[1],vs[2]),(vs[0],vs[2])]:
            d2[ei[frozenset((u,w))],k]^=1
    r1,r2=rk(d1),rk(d2)
    H1=(E-r1)-r2; H2=F-r2
    return H1,H2,V,E,F

# faces of the 16-cell: triangles of 3 mutually-adjacent bounding vertices
faces16=[f for f in itertools.combinations(surround,3) if all(nn(a,b) for a,b in itertools.combinations(f,2))]

# variant A: bare 16-cell void (8 vertices)
edgesA=[tuple(e) for e in cell_edges]
H1a,H2a,Va,Ea,Fa=homology(list(surround), edgesA, faces16)
print(f"\n[A] bare 16-cell void: V={Va} E={Ea} F={Fa} -> H1={H1a}, H2={H2a}")

# variant B: trapped node + 8 defect bonds + cell (analog of FCC defect)
c='center'
nodesB=[c]+list(surround)
edgesB=[(c,v) for v in surround]+edgesA
H1b,H2b,Vb,Eb,Fb=homology(nodesB, edgesB, faces16)
th=lambda H1,H2:(-1)**(int(H1>0)*int(H2>0))
print(f"[B] trapped node + 16-cell defect: V={Vb} E={Eb} F={Fb} -> H1={H1b}, H2={H2b}")
print(f"    theta = (-1)^(pq) = {th(H1b,H2b):+d}  => {'FERMION' if th(H1b,H2b)<0 else 'boson'}")

# variant C: a single tetrahedral K4 sub-cell + node (matches the FCC color object)
tet=[surround[i] for i in tets[0]]
nodesC=['c']+tet
edgesC=[('c',v) for v in tet]+[(a,b) for a,b in itertools.combinations(tet,2)]
facesC=list(itertools.combinations(tet,3))
H1c,H2c,Vc,Ec,Fc=homology(nodesC,edgesC,facesC)
print(f"[C] node + one K4 tetrahedral sub-cell: V={Vc} E={Ec} F={Fc} -> H1={H1c}, H2={H2c}")
print(f"    theta = {th(H1c,H2c):+d}  => {'FERMION' if th(H1c,H2c)<0 else 'boson'}  (compare FCC: H1=3,H2=1)")
