import numpy as np, itertools

# ================================================================
# Two independent checks of "does Spin(10) live on D4?":
#  (A) ALGEBRA: is so(8) [D4] inside so(10), and does the 16 of so(10)
#      branch to 8_s + 8_c under so(8) via one extra U(1)? (rep theory)
#  (B) LATTICE: does the D4 four-edge Spin(8) qubit admit a natural
#      FIFTH generator (one more qubit) extending it, or does it stop at 4?
# ================================================================

# ---------- (A) so(8) subset so(10): does 16 -> 8_s + 8_c + U(1)? ----------
from fractions import Fraction as F
# 16 of so(10): weights (+-1/2)^5, even # of minus signs
sixteen=[w for w in itertools.product((F(1,2),F(-1,2)),repeat=5) if sum(x<0 for x in w)%2==0]
from collections import Counter
b=Counter(('8_s' if sum(x<0 for x in w[:4])%2==0 else '8_c', w[4]) for w in sixteen)
print("(A) ALGEBRA CHECK  so(10) 16-spinor branched under so(8) x U(1):")
for (t,u),c in sorted(b.items()): print(f"    {c}x  {t}  U(1)={u}")
print("    => so(8) IS inside so(10); the fifth coordinate is a genuine U(1).")
print("    So Spin(10) = Spin(8) + one U(1) generator, algebraically. The question")
print("    is whether that fifth generator is NATURALLY PRESENT ON D4.\n")

# ---------- (B) LATTICE: rank of the emergent structure on D4 ----------
# The Clifford/Spin group of a defect comes from its qubit count. so(8) is RANK 4;
# so(10) is RANK 5. A fifth *independent* generator requires a fifth qubit whose
# Majorana pair is INDEPENDENT of the four -- i.e. the minimal logical qubit must
# genuinely need 5 edges, not 4. We test on D4 whether the void's minimal complete
# logical qubit can be forced to 5 (an independent 5th generator) or truly sits at 4.

def rref(M):
    M=M.copy()%2; rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=next((i for i in range(r,rows) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
        if r==rows: break
    return M[:r],piv
def nullspace(M):
    R,piv=rref(M); cols=M.shape[1]; ps=set(piv); B=[]
    for f in range(cols):
        if f in ps: continue
        v=np.zeros(cols,int); v[f]=1
        for ri,pc in enumerate(piv): v[pc]=R[ri,f]
        B.append(v%2)
    return B
def checker(M):
    R,_=rref(M); base=R.shape[0]
    return lambda v: rref(np.vstack([R,(v%2)]))[0].shape[0]==base

rng=range(0,5)
sites=[p for p in itertools.product(rng,repeat=4) if sum(p)%2==0]; sset=set(sites)
roots=[]
for i,j in itertools.combinations(range(4),2):
    for si in(1,-1):
        for sj in(1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; roots.append(tuple(v))
def nbrs(p): return [q for r in roots for q in [tuple(p[k]+r[k] for k in range(4))] if q in sset]
edges=sorted({frozenset((p,q)) for p in sites for q in nbrs(p)}, key=lambda e:tuple(sorted(e)))
ei={e:i for i,e in enumerate(edges)}; n=len(edges)
emid={i:np.mean([np.array(x) for x in e],axis=0) for e,i in ei.items()}
def mat(rows):
    M=np.zeros((len(rows),n),int)
    for i,r in enumerate(rows):
        for j in r: M[i,j]^=1
    return M
HZ=mat([[ei[frozenset((p,q))] for q in nbrs(p)] for p in sites if nbrs(p)])
def hole_cell(c):
    surr=[tuple(c[k]+d[k] for k in range(4)) for d in
          [tuple(1 if t==a else 0 for t in range(4)) for a in range(4)]+
          [tuple(-1 if t==a else 0 for t in range(4)) for a in range(4)]]
    return [s for s in surr if s in sset]
HXrows=[]
for c in itertools.product(rng,repeat=4):
    if sum(c)%2==1:
        surr=hole_cell(c)
        if len(surr)==8:
            supp=sorted({ei[frozenset((a,b))] for a,b in itertools.combinations(surr,2)
                 if sum((a[k]-b[k])**2 for k in range(4))==2 and frozenset((a,b)) in ei})
            if len(supp)==24: HXrows.append(supp)
HX=mat(HXrows); inHX=checker(HX); inHZ=checker(HZ)

hole=(2,2,2,1); surr=hole_cell(hole)
centroid=np.mean([np.array(v) for v in surr],axis=0)
order=sorted(range(n), key=lambda i: np.linalg.norm(emid[i]-centroid))

# count the number of INDEPENDENT logical qubits (the rank) hostable near the void,
# by growing the region and counting independent anticommuting pairs (symplectic rank).
def logical_rank(R):
    R=sorted(set(R))
    LX=[]; LZ=[]
    for v in nullspace(HZ[:,R]):
        if v.any():
            x=np.zeros(n,int); x[R]=v
            if not inHX(x): LX.append(x)
    for v in nullspace(HX[:,R]):
        if v.any():
            z=np.zeros(n,int); z[R]=v
            if not inHZ(z): LZ.append(z)
    if not LX or not LZ: return 0
    # symplectic rank of the LX x LZ anticommutation matrix over GF(2)
    A=np.array([[int(x@z)%2 for z in LZ] for x in LX])
    return rref(A)[0].shape[0]

print("(B) LATTICE CHECK  independent-logical-qubit rank vs region size on D4:")
for k in [24,30,40,60,90]:
    R=order[:k]
    print(f"    region {len(set(R)):3d} edges: independent logical-qubit rank = {logical_rank(R)}")
print()
print("INTERPRETATION:")
print("  so(8) is rank 4, so(10) is rank 5. If the D4 void's logical structure")
print("  saturates at rank 4, the minimal fermion is Spin(8)/8_s and there is NO")
print("  natural 5th (U(1)) generator from the geometry -> Spin(10) is NOT realized")
print("  on D4; the FCC '5th edge' was cuboctahedral geometry, not the so(10) U(1).")
print("  If it reaches rank 5+, a Spin(10) extension is geometrically available.")
