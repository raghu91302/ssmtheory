# Redraw the 5-edge defect to the ACTUAL computed geometry: 3 internal edges +
# 2 reaching edges to one neighbor vertex; logical Z internal, logical X reaching out.
import numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection, Poly3DCollection
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({'font.size':10,'font.family':'serif','mathtext.fontset':'cm'})

# computed support (shifted to origin for a clean view)
V={'v0':np.array([2,2,2.]),'v1':np.array([2,3,3.]),'v2':np.array([3,2,3.]),
   'v3':np.array([3,3,2.]),'ext':np.array([1,2,3.])}
o=V['v0'].copy()
for k in V: V[k]=V[k]-o
body=['v0','v1','v2','v3']         # four body-void vertices
ext='ext'                          # the single neighbor vertex

# minimal logical operator edges (from the computation):
#  X-part (reaches out):  ext-v0 , ext-v1
#  Z-part (internal):     v0-v1 , v0-v2 , v0-v3     (v0-v1 carries both)
X_edges=[('ext','v0'),('ext','v1')]
Z_edges=[('v0','v1'),('v0','v2'),('v0','v3')]

fig=plt.figure(figsize=(7,3.5))
ax=fig.add_subplot(1,2,1,projection='3d')
# body-void tetrahedron faces (faint)
tf=[[V['v0'],V['v1'],V['v2']],[V['v0'],V['v1'],V['v3']],
    [V['v0'],V['v2'],V['v3']],[V['v1'],V['v2'],V['v3']]]
ax.add_collection3d(Poly3DCollection([[p.tolist() for p in f] for f in tf],
                    alpha=0.06,facecolor='#4477aa',edgecolor='none'))
# faint tetrahedron wireframe
tet=[('v0','v1'),('v0','v2'),('v0','v3'),('v1','v2'),('v1','v3'),('v2','v3')]
ax.add_collection3d(Line3DCollection([(V[a],V[b]) for a,b in tet],colors='#cccccc',linewidths=0.8))
# logical Z (internal, blue) and logical X (reaching out, red)
ax.add_collection3d(Line3DCollection([(V[a],V[b]) for a,b in Z_edges],colors='#3366cc',linewidths=2.2))
ax.add_collection3d(Line3DCollection([(V[a],V[b]) for a,b in X_edges],colors='#cc3333',linewidths=2.2))
for k,p in V.items():
    col = '#cc3333' if k==ext else '#222222'
    ax.scatter(*p,s=48,c=col,depthshade=False)
lab={'v0':'','v1':'','v2':'','v3':'','ext':'neighbor'}
ax.text(*(V['v0']+[0.05,0.05,-0.15]),'body void',fontsize=8,color='#33557a')
ax.text(*(V['ext']+[-0.1,0.05,0.12]),'neighbor',fontsize=8,color='#aa2222')
ax.set_title('(a) minimal logical qubit (5 edges)',fontsize=10)
ax.set_axis_off(); ax.view_init(elev=16,azim=-60)

ax2=fig.add_subplot(1,2,2); ax2.axis('off'); ax2.set_xlim(0,10); ax2.set_ylim(0,10)
def box(x,y,w,h,t,fc,ec,fs=8.5):
    ax2.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.1,rounding_size=0.2",fc=fc,ec=ec,lw=1.1))
    ax2.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs)
def ar(a,b,c,d): ax2.add_patch(FancyArrowPatch((a,b),(c,d),arrowstyle='-|>',mutation_scale=11,color='#334455',lw=1.1))
box(0.4,8.3,9.2,1.4,'single void: no complete logical qubit\n(3 local X, 3 local Z, all commuting)','#fbeaea','#aa4444')
ar(5,8.3,5,7.7)
box(0.4,6.1,9.2,1.5,'minimal logical qubit = 5 edges:\n'+r'logical $Z$ internal (3 edges), logical $X$ reaches 1 neighbor (2 edges)','#eef2f7','#33557a')
ar(5,6.1,5,5.5)
box(1.8,3.9,6.4,1.4,'5 qubits = 10 Majoranas\n'+r'$\to \mathrm{Spin}(10)$','#eaf3ea','#448844')
ar(5,3.9,5,3.3)
box(0.8,1.6,8.4,1.5,r'spinor $\mathbf{16}$ = one generation ($+\nu_R$);'+'\n'+r'$\mathbf{16}\to\mathbf{8}_s\oplus\mathbf{8}_c$ under $\mathfrak{so}(8)$','#eaf3ea','#448844')
ax2.set_title('(b) body / state split',fontsize=10)

leg=[Line2D([0],[0],color='#3366cc',lw=2.2,label=r'logical $Z$ (internal)'),
     Line2D([0],[0],color='#cc3333',lw=2.2,label=r'logical $X$ (reaches out)'),
     Line2D([0],[0],color='#cccccc',lw=0.9,label='body-void edges')]
fig.legend(handles=leg,loc='lower center',ncol=3,fontsize=7.3,frameon=False,bbox_to_anchor=(0.27,-0.02))
plt.tight_layout(rect=[0,0.05,1,1])
plt.savefig('fig_five_edge_defect.pdf',bbox_inches='tight',dpi=200)
print("true-geometry figure written")
