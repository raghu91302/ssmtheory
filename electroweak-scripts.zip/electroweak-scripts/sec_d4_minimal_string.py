import numpy as np, itertools

def rref(M):
    M=M.copy()%2; rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=next((i for i in range(r,rows) if M[i,c]),None)
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
        if r==rows: break
    return M[:r],piv
def nullspace(M):
    R,piv=rref(M); cols=M.shape[1]; ps=set(piv); B=[]
    for f in range(cols):
        if f in ps: continue
        v=np.zeros(cols,int); v[f]=1
        for ri,pc in enumerate(piv): v[pc]=R[ri,f]
        B.append(v%2)
    return B
def checker(M):
    R,_=rref(M); base=R.shape[0]
    return lambda v: rref(np.vstack([R,(v%2)]))[0].shape[0]==base

# ---------- build D4 code on a 4D patch ----------
rng=range(0,5)   # coordinate box 0..4 (keep it modest; 4D grows fast)
sites=[p for p in itertools.product(rng,repeat=4) if sum(p)%2==0]
sset=set(sites)
# 24 root directions
roots=[]
for i,j in itertools.combinations(range(4),2):
    for si in(1,-1):
        for sj in(1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; roots.append(tuple(v))
def nbrs(p): return [q for r in roots for q in [tuple(p[k]+r[k] for k in range(4))] if q in sset]
edges=sorted({frozenset((p,q)) for p in sites for q in nbrs(p)}, key=lambda e:tuple(sorted(e)))
ei={e:i for i,e in enumerate(edges)}; n=len(edges); inv={i:tuple(sorted(e)) for e,i in ei.items()}
emid={i:np.mean([np.array(x) for x in e],axis=0) for e,i in ei.items()}
def mat(rows):
    M=np.zeros((len(rows),n),int)
    for i,r in enumerate(rows):
        for j in r: M[i,j]^=1
    return M
# Z-checks: vertex stars
HZ=mat([[ei[frozenset((p,q))] for q in nbrs(p)] for p in sites if nbrs(p)])
# X-checks: deep-hole 16-cells (odd-sum centers), edges among the 8 bounding vertices
def hole_cell(c):
    surr=[tuple(c[k]+d[k] for k in range(4)) for d in
          [tuple(1 if t==a else 0 for t in range(4)) for a in range(4)]+
          [tuple(-1 if t==a else 0 for t in range(4)) for a in range(4)]]
    return [s for s in surr if s in sset]
HXrows=[]
for c in itertools.product(rng,repeat=4):
    if sum(c)%2==1:
        surr=hole_cell(c)
        if len(surr)==8:
            supp=sorted({ei[frozenset((a,b))] for a,b in itertools.combinations(surr,2)
                 if sum((a[k]-b[k])**2 for k in range(4))==2 and frozenset((a,b)) in ei})
            if len(supp)==24: HXrows.append(supp)
HX=mat(HXrows)
print(f"D4 patch: {len(sites)} sites, {n} edge-qubits, {HZ.shape[0]} Z-checks, {HX.shape[0]} X-checks(16-cells)")
# CSS validity spot-check
bad=sum(1 for z in HZ for x in HX if int(z@x)%2)
print(f"CSS validity (Z-X commute): {bad} anticommuting pairs (want 0) -> valid: {bad==0}")

inHX=checker(HX); inHZ=checker(HZ)

# ---------- pick an interior deep-hole void; its local edges ----------
hole=(2,2,2,1)  # odd sum, interior
surr=hole_cell(hole)
assert len(surr)==8, len(surr)
Sfull=[ei[frozenset((a,b))] for a,b in itertools.combinations(surr,2)
       if sum((a[k]-b[k])**2 for k in range(4))==2 and frozenset((a,b)) in ei]
centroid=np.mean([np.array(v) for v in surr],axis=0)
print(f"deep-hole void at {hole}: {len(surr)} bounding vertices, {len(Sfull)} local edges")

# ---------- does the void host a complete logical qubit locally? ----------
def local_logicals(R):
    lx=[]; lz=[]
    for v in nullspace(HZ[:,R]):
        if v.any():
            x=np.zeros(n,int); x[R]=v
            if not inHX(x): lx.append(x)
    for v in nullspace(HX[:,R]):
        if v.any():
            z=np.zeros(n,int); z[R]=v
            if not inHZ(z): lz.append(z)
    best=None
    for x in lx:
        for z in lz:
            if int(x@z)%2==1:
                s=int((x|z).sum())
                if best is None or s<best: best=s
    return len(lx),len(lz),best

nx,nz,b=local_logicals(sorted(set(Sfull)))
print(f"on the void's local edges: {nx} local X-logicals, {nz} local Z-logicals, min anticommuting-pair support = {b}")

# ---------- grow region; minimal complete logical qubit ----------
order=sorted(range(n), key=lambda i: np.linalg.norm(emid[i]-centroid))
first=None
print("\ngrowing outward from the D4 void:")
prev=None
for k in range(len(Sfull), len(Sfull)+50, 3):
    R=sorted(set(order[:k]))
    _,_,b=local_logicals(R)
    if b is not None and first is None:
        first=(len(R),b)
    if b!=prev:
        print(f"  region {len(R):3d} edges: min complete-qubit support = {b}")
    prev=b
    if first and len(R)>first[0]+15: break
print()
if first:
    print(f"D4 minimal complete logical qubit: union support = {first[1]} edges")
    print(f"  (FCC gave 5 -> Spin(10). D4 gives {first[1]} -> Spin({2*first[1]}).)")
else:
    print("no complete local logical qubit found in range (string reaches farther on D4)")
