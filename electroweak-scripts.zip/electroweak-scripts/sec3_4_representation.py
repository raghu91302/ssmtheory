"""sec3_4_representation.py -- Sections 3 & 4.
S3 doublet is REAL (nu=+1); weak SU(2) is PSEUDOREAL (nu=-1) -> FCC no-go.
so(8) spinor 8_s branches as the chiral electroweak fermion."""
import itertools
from fractions import Fraction as F
def fs(elems,sq,chi): return sum(chi[sq[g]] for g in elems)/len(elems)
S3=['e','t1','t2','t3','c1','c2']; sq={'e':'e','t1':'e','t2':'e','t3':'e','c1':'c2','c2':'c1'}
irr={'trivial':{'e':1,'t1':1,'t2':1,'t3':1,'c1':1,'c2':1},
     'sign':{'e':1,'t1':-1,'t2':-1,'t3':-1,'c1':1,'c2':1},
     'standard(doublet)':{'e':2,'t1':0,'t2':0,'t3':0,'c1':-1,'c2':-1}}
print("Section 3 -- Frobenius-Schur indicators (S3):")
for k,c in irr.items(): print(f"  {k:20s} nu={fs(S3,sq,c):+.0f} (real)")
print("  weak SU(2)_L: nu=-1 (pseudoreal) -> real != pseudoreal -> FCC no-go.\n")
Q8=['1','-1','i','-i','j','-j','k','-k']; sqQ={'1':'1','-1':'1','i':'-1','-i':'-1','j':'-1','-j':'-1','k':'-1','-k':'-1'}
chiQ={'1':2,'-1':-2,'i':0,'-i':0,'j':0,'-j':0,'k':0,'-k':0}
print(f"Section 4 -- Q8 subset SU(2) doublet: nu={fs(Q8,sqQ,chiQ):+.0f} (pseudoreal, correct type)")
def wts(r):
    if r=='8_v': return [tuple(F(1 if k==i else 0)*s for k in range(4)) for i in range(4) for s in (1,-1)]
    return [sg for sg in itertools.product((F(1,2),F(-1,2)),repeat=4)
            if (sum(x<0 for x in sg)%2==0)==(r=='8_s')]
def lab(w): return (('LH' if w[0]+w[1] else '--'),('RH' if w[0]-w[1] else '--'),
                    ('SU2_L' if w[2]+w[3] else '.'),('SU2_R' if w[2]-w[3] else '.'))
from collections import Counter
for r in ('8_v','8_s'):
    print(f"\n  {r} under (spacetime x internal) so(4):")
    for k,v in Counter(lab(w) for w in wts(r)).items():
        print(f"    {v}x spacetime[{k[0]}/{k[1]}] internal[{k[2]}/{k[3]}]")
print("\n  => 8_s = [LH spacetime] x [internal SU(2)_L doublet] = chiral EW fermion.")
