"""sec7_theta_toric.py -- Section 7. Validate theta=(-1)^{pq} on the toric code."""
from topological_spin import build_toric, pauli, anticommute
code,n,h,v=build_toric(3)
p=anticommute(pauli(n,x_support=[h(0,0)]),code.z_stabs[0],n)
q=anticommute(pauli(n,z_support=[h(0,0)]),code.x_stabs[0],n)
th=lambda p,q:(-1)**(p*q)
print(f"e (X): (p,q)=({p},0) theta={th(p,0):+d} boson")
print(f"m (Z): (p,q)=(0,{q}) theta={th(0,q):+d} boson")
print(f"eps (XZ): (p,q)=({p},{q}) theta={th(p,q):+d} FERMION")
print("=> fermion iff carries BOTH e and m charge.")
