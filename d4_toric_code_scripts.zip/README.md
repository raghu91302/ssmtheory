# A four-dimensional toric code on the D4 lattice

Verification scripts for the paper *A four-dimensional toric code on the
D4 lattice: [[16L^4, 6, 2L^2]] with weight-4 X-stabilizers*. All files sit
in one folder with no subdirectories.

Install: `pip install numpy matplotlib python-sat`. Run `verify_all.py`
first; it ends in `ALL CHECKS PASS`.

| file | what it checks | needs |
|---|---|---|
| `verify_all.py` | every structural number in the paper at L=4 and L=6: cell counts, incidence structure, check weights, CSS validity, ranks and k, the parity remark, both shadow constants, the close-packed plane, the flat sheets, the slice property, and the absence of point excitations; prints PASS or FAIL per claim | nothing |
| `projection.py` | the two shadow constants of Lemma 1 (1/2 and 1/4) in exact arithmetic | nothing |
| `planes.py` | Theorem 3: the close-packed plane has L^2 points and 2L^2 triangles, is a cycle, and is nontrivial (`python3 planes.py 4`, `python3 planes.py 6`) | nothing |
| `zsheet.py` | Theorem 4: the Z-type operator made of the triangles crossed by a plane has weight 4L^2, commutes with every X-check and is nontrivial, at L=4 and L=6; also checks the counting step of the proof | nothing |
| `lemmas.py` | translations act freely on triangles and trivially on homology; the 128 flat sheets at L=4 and the classes they span (Lemma 2) (`python3 lemmas.py 4`) | numpy |
| `supplementary.py` | the weight-4 scan of Section 4, a greedy check that Z-type operators reduce to weight 64 = 4L^2 at L=4, and the search over classes with no flat operator | numpy |
| `slice3d_distance.py` | exact minimum distance of the three-dimensional face code on a slice, both sectors: d_X = 32 and d_Z = 8 at L=4 (`python3 slice3d_distance.py 4`) | python-sat |
| `hooks.py` | the hook-error table of Section 8.1, the bound for several faults on one ancilla, and the same table for the hypercubic code | python-sat |
| `satdist.py` | GF(2) helpers and the SAT encoding, imported by `planes.py`, `lemmas.py`, `zsheet.py` and `slice3d_distance.py`; python-sat is loaded only for the SAT search | nothing |
| `make_figs.py` | regenerates both figures | numpy, matplotlib |

Timings on a laptop: `projection.py` and `zsheet.py` a few seconds;
`verify_all.py`, `planes.py`, `lemmas.py`, `slice3d_distance.py` and
`hooks.py` a few minutes each; `supplementary.py` about ten minutes.

The paper proves d_X = 2L^2 and d_Z = 4L^2 for all even L >= 4. It reports
no decoder or threshold; the hook-error analysis gives counting bounds, not
measured circuit distances.
