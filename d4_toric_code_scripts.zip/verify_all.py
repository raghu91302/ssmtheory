#!/usr/bin/env python3
"""Check every number the paper claims, from scratch. PASS/FAIL per claim."""
import sys
from itertools import product, combinations
from fractions import Fraction

FAILS = []
def chk(name, got, want):
    ok = (got == want)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}: got {got}, paper says {want}")
    if not ok: FAILS.append(name)

pop = lambda x: bin(x).count('1')

def rank(rows):
    piv, rk = {}, 0
    for r in rows:
        while r:
            h = r.bit_length()-1
            if h in piv: r ^= piv[h]
            else: piv[h] = r; rk += 1; break
    return rk

def pivots(rows):
    piv = {}
    for r in rows:
        while r:
            h = r.bit_length()-1
            if h in piv: r ^= piv[h]
            else: piv[h] = r; break
    return piv

def inspan(v, piv):
    while v:
        h = v.bit_length()-1
        if h not in piv: return False
        v ^= piv[h]
    return True

def build4(L):
    vs = [v for v in product(range(L), repeat=4) if sum(v) % 2 == 0]
    add = lambda a,b: tuple((a[i]+b[i]) % L for i in range(4))
    adj = lambda a,b: sorted(min((a[i]-b[i])%L,(b[i]-a[i])%L)
                             for i in range(4)) == [0,0,1,1]
    NN = [v for v in product((-1,0,1), repeat=4) if sum(map(abs,v)) == 2]
    nb = {v: [add(v,d) for d in NN] for v in vs}
    E, F, T, C4 = {}, {}, {}, []
    for v in vs:
        for u in nb[v]:
            k = frozenset((v,u))
            if k not in E: E[k] = len(E)
    for ek in list(E):
        a, b = tuple(ek)
        for c in nb[a]:
            if c != b and adj(c,b):
                fk = frozenset((a,b,c))
                if fk not in F: F[fk] = len(F)
    for fk in list(F):
        a, b, c = tuple(fk)
        for d in nb[a]:
            if d not in fk and adj(d,b) and adj(d,c):
                tk = frozenset((a,b,c,d))
                if tk not in T: T[tk] = len(T)
    for h in product(range(L), repeat=4):
        if sum(h) % 2 == 1:
            C4.append([add(h, tuple(int(i==j)*s for j in range(4)))
                       for i in range(4) for s in (1,-1)])
    for hb in product(range(L), repeat=4):
        h = tuple(x+.5 for x in hb)
        want = 0 if sum(hb) % 2 == 0 else 2
        C4.append([tuple(int((h[i]+s[i]*.5)) % L for i in range(4))
                   for s in product((1,-1), repeat=4) if sum(s) % 4 == want])
    return vs, E, F, T, C4, add, adj

L = 4
vs, E, F, T, C4, add, adj = build4(L)
nV, nE, nF, nT, nC = len(vs), len(E), len(F), len(T), len(C4)

print(f"\n=== Section 2: counts at L={L} ===")
chk("points",    nV, L**4//2)
chk("edges",     nE, 6*L**4)
chk("triangles", nF, 16*L**4)
chk("tetrahedra",nT, 12*L**4)
chk("16-cells",  nC, 3*L**4//2)
chk("Euler characteristic", nV-nE+nF-nT+nC, 0)
chk("table row L=4", (nV,nE,nF,nT,nC), (128,1536,4096,3072,384))

print("\n=== Section 2: how the pieces fit ===")
fin = [0]*nF
for tk in T:
    for tri in combinations(tuple(tk),3): fin[F[frozenset(tri)]] += 1
chk("triangle in how many tetrahedra", set(fin), {3})
tin = [0]*nT
for cv in C4:
    prs = {frozenset(p) for p in combinations(cv,2) if adj(*p)}
    for q in combinations(cv,4):
        if all(frozenset(p) in prs for p in combinations(q,2)):
            tin[T[frozenset(q)]] += 1
chk("tetrahedron in how many 16-cells", set(tin), {2})
fic = [0]*nF
for cv in C4:
    for tri in combinations(cv,3):
        fk = frozenset(tri)
        if fk in F: fic[F[fk]] += 1
chk("triangle in how many 16-cells", set(fic), {3})

HZ = [0]*nE
for fk, fi in F.items():
    for pr in combinations(tuple(fk),2): HZ[E[frozenset(pr)]] |= 1 << fi
HX = [0]*nT
for tk, ti in T.items():
    for tri in combinations(tuple(tk),3): HX[ti] |= 1 << F[frozenset(tri)]

print("\n=== Section 3: the code ===")
chk("Z-check weight", set(pop(r) for r in HZ), {8})
chk("X-check weight", set(pop(r) for r in HX), {4})
colZ = [0]*nF; colX = [0]*nF
for i, r in enumerate(HZ):
    m = r
    while m:
        b = (m & -m).bit_length()-1; colZ[b] |= 1 << i; m &= m-1
for i, r in enumerate(HX):
    m = r
    while m:
        b = (m & -m).bit_length()-1; colX[b] |= 1 << i; m &= m-1
chk("Z-checks per qubit", set(pop(c) for c in colZ), {3})
chk("X-checks per qubit", set(pop(c) for c in colX), {3})
chk("X and Z checks commute",
    all(pop(x & z) % 2 == 0 for x in HX for z in HZ), True)

print("\n=== Section 4: parameters ===")
rz, rx = rank(HZ), rank(HX)
chk("n", nF, 4096)
chk("rank of H_Z", rz, 1405)
chk("rank of H_X", rx, 2685)
chk("k", nF-rz-rx, 6)

print("\n=== Section 5: parity remark ===")
allones = (1 << nF) - 1
chk("all-ones is a sum of Z-checks", inspan(allones, pivots(HZ)), True)
chk("all-ones is a sum of X-checks", inspan(allones, pivots(HX)), True)

print("\n=== Section 5: Lemma 1, the shadow constants ===")
roots = [tuple(r) for r in product((-1,0,1), repeat=4)
         if sum(map(abs,r)) == 2]
rootset = set(roots)
area2 = lambda a,b,i,j: abs(a[i]*b[j] - a[j]*b[i])
best = 0; kinds = 0
for r, s in combinations(roots, 2):
    if tuple(r[i]-s[i] for i in range(4)) not in rootset: continue
    kinds += 1
    for i, j in combinations(range(4), 2):
        best = max(best, area2(r,s,i,j))
chk("triangles at a lattice point", kinds, 96)
chk("largest triangle shadow", Fraction(best,2), Fraction(1,2))
holes = [tuple(map(Fraction,p)) for p in product(range(-2,3), repeat=4)
         if sum(p) % 2 == 1]
holes += [tuple(Fraction(2*x+1,2) for x in p)
          for p in product(range(-2,3), repeat=4)]
bestd, three = 0, True
for r, s in combinations(roots, 2):
    if tuple(r[i]-s[i] for i in range(4)) not in rootset: continue
    tri = [(Fraction(0),)*4, tuple(map(Fraction,r)), tuple(map(Fraction,s))]
    hs = [h for h in holes
          if all(sum((u[i]-h[i])**2 for i in range(4)) == 1 for u in tri)]
    if len(hs) != 3: three = False; continue
    a = tuple(hs[1][i]-hs[0][i] for i in range(4))
    b = tuple(hs[2][i]-hs[0][i] for i in range(4))
    for i, j in combinations(range(4), 2):
        bestd = max(bestd, area2(a,b,i,j))
chk("every triangle sits in 3 16-cells (local check)", three, True)
chk("largest dual-cell shadow", Fraction(bestd,2), Fraction(1,4))
chk("lower bound on X-logicals", Fraction(2,best), 2)
chk("lower bound on Z-logicals", Fraction(2,bestd), 4)

print("\n=== Section 5: Theorem 3, the close-packed plane ===")
pX = pivots(HX)
def reduce_(v, piv):
    while v:
        h = v.bit_length()-1
        if h not in piv: return v
        v ^= piv[h]
    return 0
for c in (0, 2):
    pts = {v for v in vs if (v[0]+v[1]+v[2]) % L == c and v[3] == 0}
    m = 0; cnt = 0
    for fk in F:
        if all(u in pts for u in fk): m |= 1 << F[fk]; cnt += 1
    chk(f"plane c={c}: points", len(pts), L*L)
    chk(f"plane c={c}: triangles", cnt, 2*L*L)
    chk(f"plane c={c}: commutes with all Z-checks",
        all(pop(h & m) % 2 == 0 for h in HZ), True)
    chk(f"plane c={c}: not a product of stabilizers",
        reduce_(m, pX) != 0, True)

print("\n=== Section 5: flat sheets ===")
LZ_basis = []
def kernel(rows, n):
    piv = {}
    for r in rows:
        while r:
            h = r.bit_length()-1
            if h in piv: r ^= piv[h]
            else: piv[h] = r; break
    def clean(v):
        out = 0
        while v:
            h = v.bit_length()-1
            if h in piv: v ^= piv[h]
            else: out |= 1 << h; v ^= 1 << h
        return out
    for h in list(piv): piv[h] = (1 << h) | clean(piv[h] ^ (1 << h))
    free = [c for c in range(n) if c not in piv]
    out = []
    for fc in free:
        v = 1 << fc
        for h, r in piv.items():
            if (r >> fc) & 1: v |= 1 << h
        out.append(v)
    return out
aug = dict(pivots(HZ))
for v in kernel(HX, nF):
    r = reduce_(v, aug)
    if r:
        LZ_basis.append(v); aug[r.bit_length()-1] = r
        if len(LZ_basis) == 6: break
sheets, classes = {}, set()
for r, s_ in combinations(roots, 2):
    if (tuple(r[i]-s_[i] for i in range(4)) not in rootset and
        tuple(r[i]+s_[i] for i in range(4)) not in rootset): continue
    base = [tuple((a*r[i]+b*s_[i]) % L for i in range(4))
            for a in range(L) for b in range(L)]
    for t in vs:                      # include all translates
        pts = frozenset(add(p, t) for p in base)
        m = 0
        for fk in F:
            if all(u in pts for u in fk): m |= 1 << F[fk]
        if not m or any(pop(h & m) % 2 for h in HZ) or not reduce_(m, pX):
            continue
        sheets[m] = pts
        classes.add(tuple(pop(m & f) % 2 for f in LZ_basis))
chk("number of distinct flat sheets", len(sheets), 128)
chk("their weights", {pop(m) for m in sheets}, {32})
chk("distinct classes", len(classes), 4)
sp, a2 = 0, {}
for cls in classes:
    v = int("".join(map(str, cls)), 2)
    r = reduce_(v, a2)
    if r: sp += 1; a2[r.bit_length()-1] = r
chk("dimensions they span (of 6)", sp, 3)
chk("all lie in a coordinate slice",
    all(any(len({p[i] for p in pts}) == 1 for i in range(4))
        for pts in sheets.values()), True)

print("\n=== Section 7: the slice ===")
sv = [v for v in vs if v[3] == 0]
se = [k for k in E if all(u[3] == 0 for u in k)]
sf = [k for k in F if all(u[3] == 0 for u in k)]
st = [k for k in T if all(u[3] == 0 for u in k)]
chk("slice points", len(sv), L**3//2)
chk("slice edges", len(se), 3*L**3)
chk("slice triangles", len(sf), 4*L**3)
chk("slice tetrahedra", len(st), L**3)
chk("slice edge in how many slice triangles",
    {sum(1 for fk in sf if ek <= fk) for ek in se}, {4})
chk("16-cell slice sections",
    sorted({sum(1 for u in cv if u[3] == 0) for cv in C4
            if 0 < sum(1 for u in cv if u[3] == 0) < 8}), [1,4,6])

print("\n=== Section 6: no point excitations ===")
def solvable(rows, rhs):
    piv = {}
    for i, r in enumerate(rows):
        a = (r << 1) | rhs[i]
        while a >> 1:
            h = (a >> 1).bit_length()-1
            if h in piv: a ^= piv[h]
            else: piv[h] = a; break
        else:
            if a & 1: return False
    return True
chk("a single X-check can be lit", solvable(HX, [1]+[0]*(nT-1)), False)

print("\n=== Section 8: qubits at equal distance ===")
d = 2*L*L
chk("D4 qubit count equals 4d^2", 16*L**4, 4*d*d)
chk("hypercubic at same d needs 6d^2", 6*(d)**2, 6*d*d)

print("\n=== L=6: the plane construction ===")
L6 = 6
vs6, E6, F6, T6, C46, add6, adj6 = build4(L6)
pts6 = {v for v in vs6 if (v[0]+v[1]+v[2]) % L6 == 0 and v[3] == 0}
cnt6 = sum(1 for fk in F6 if all(u in pts6 for u in fk))
chk("L=6 plane points", len(pts6), L6*L6)
chk("L=6 plane triangles", cnt6, 2*L6*L6)
chk("L=6 qubits", len(F6), 16*L6**4)

print("\n=== L=2 is degenerate (paper requires L >= 4) ===")
vs2, E2, F2, T2, C42, _, _ = build4(2)
chk("L=2 edge count equals 6L^4 (it must not)", len(E2) == 6*2**4, False)

print("\n" + "="*60)
print(f"{'ALL CHECKS PASS' if not FAILS else 'FAILURES: ' + str(FAILS)}")
