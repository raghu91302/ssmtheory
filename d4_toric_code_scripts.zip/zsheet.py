#!/usr/bin/env python3
"""A Z-type logical operator of weight exactly 4L^2, for every even L.

Take a flat 2-plane Q = {x3 = a, x4 = b} with (a, b) generic, i.e. off every
line through integer points in the (x3, x4) shadow of an edge.  Q runs along
the x1 and x2 directions and closes up into a 2-torus.  Apply Z to every
triangle that Q passes through.

  (1) Q meets each tetrahedron in a segment or not at all, and the two ends
      of a segment lie on two of its triangles.  So every X-check sees 0 or
      2 of the chosen triangles: the operator commutes with all X-checks.
  (2) It is nontrivial, because Q has intersection number 1 with any
      2-cycle in the (x3, x4) class.  Checked here directly: the operator
      is not a product of Z-stabilizers.
  (3) Weight.  The triangles at a lattice point fall into 32 translation
      classes.  Exactly 16 have a shadow on (x3, x4) of nonzero area, every
      one of area 1/2, and they pair up under point reflection.  A lattice
      triangle of area 1/2 and its reflection tile the plane under integer
      translations, so each pair covers a generic point exactly once.  Each
      integer point of the (x3, x4) torus is the shadow of L^2/2 lattice
      points, so the weight is (L^2/2) * (16/2) = 4L^2.

Part (3) is checked in exact arithmetic; (1), (2) and the weight are checked
on the full code at L = 4 and L = 6.  Standard library only, about a minute.
"""
import sys
from itertools import product, combinations
from fractions import Fraction as Fr
from satdist import pivots, reduce_

pop = lambda x: bin(x).count('1')
ROOTS = [r for r in product((-1, 0, 1), repeat=4) if sum(map(abs, r)) == 2]
isroot = lambda v: sum(map(abs, v)) == 2 and max(map(abs, v)) == 1

# ------------------------------------------------ (3) the counting argument --
tris = set()
for r, s in combinations(ROOTS, 2):
    if isroot(tuple(r[i]-s[i] for i in range(4))):
        tris.add(frozenset([(0,)*4, r, s]))
print(f"triangles at a lattice point: {len(tris)}")


def canon(t):
    """Translation class: the vertex set moved so its smallest vertex is 0."""
    m = min(t)
    return tuple(sorted(tuple(x[i]-m[i] for i in range(4)) for x in t))


classes = {canon(t) for t in tris}
print(f"translation classes: {len(classes)}")


def area2(c):                       # twice the area of the (x3, x4) shadow
    p, q, r = c
    return abs((q[2]-p[2])*(r[3]-p[3]) - (q[3]-p[3])*(r[2]-p[2]))


nz = [c for c in classes if area2(c)]
refl = lambda c: canon([tuple(-x for x in v) for v in c])
print(f"classes with a shadow of nonzero area: {len(nz)}, "
      f"twice their areas: {sorted({area2(c) for c in nz})}")
print(f"closed under point reflection: {all(refl(c) in nz for c in nz)}, "
      f"classes fixed by it: {sum(refl(c) == c for c in nz)}")
print(f"predicted weight: (L^2/2) * {len(nz)}/2 = 4L^2")

# ------------------------------------------------- (1), (2) on the full code --
a, b = Fr(1, 4), Fr(3, 5)            # generic: off every line x=n, y=n, x+-y=n


def check(L):
    vs = [v for v in product(range(L), repeat=4) if sum(v) % 2 == 0]
    add = lambda p, q: tuple((p[i]+q[i]) % L for i in range(4))
    adj = lambda p, q: sorted(min((p[i]-q[i]) % L, (q[i]-p[i]) % L)
                              for i in range(4)) == [0, 0, 1, 1]
    nb = {v: [add(v, d) for d in ROOTS] for v in vs}
    E, F, T = {}, {}, {}
    for v in vs:
        for u in nb[v]:
            E.setdefault(frozenset((v, u)), len(E))
    for ek in list(E):
        p, q = tuple(ek)
        for c in nb[p]:
            if c != q and adj(c, q):
                F.setdefault(frozenset((p, q, c)), len(F))
    for fk in list(F):
        p, q, c = tuple(fk)
        for d in nb[p]:
            if d not in fk and adj(d, q) and adj(d, c):
                T.setdefault(frozenset((p, q, c, d)), len(T))
    HZ = [0]*len(E)
    for fk, fi in F.items():
        for pr in combinations(tuple(fk), 2):
            HZ[E[frozenset(pr)]] |= 1 << fi
    HX = [0]*len(T)
    for tk, ti in T.items():
        for tri in combinations(tuple(tk), 3):
            HX[ti] |= 1 << F[frozenset(tri)]

    def lift(p, q):                  # displacement p -> q as a root
        return tuple(((q[i]-p[i]+L//2) % L) - L//2 for i in range(4))

    def pierced(fk):                 # does Q pass through this triangle?
        p, q, r = tuple(fk)
        u, w = lift(p, q), lift(p, r)
        det = u[2]*w[3] - u[3]*w[2]
        if det == 0:
            return False
        for s in (-1, 0, 1):         # periodic images of (a, b)
            for t in (-1, 0, 1):
                X = (a + s*L - p[2], b + t*L - p[3])
                lam = (X[0]*w[3] - X[1]*w[2]) / Fr(det)
                mu = (u[2]*X[1] - u[3]*X[0]) / Fr(det)
                if lam > 0 and mu > 0 and lam + mu < 1:
                    return True
        return False

    z = 0
    for fk, fi in F.items():
        if pierced(fk):
            z |= 1 << fi
    print(f"\nL={L}: n={len(F)}")
    print(f"  weight {pop(z)}   (4L^2 = {4*L*L})")
    print(f"  every X-check sees 0 or 2 of its triangles: "
          f"{set(pop(h & z) for h in HX) <= {0, 2}}")
    print(f"  not a product of Z-stabilizers (nontrivial): "
          f"{reduce_(z, pivots(HZ)) != 0}")
    return pop(z) == 4*L*L


ok = all(check(L) for L in ([int(x) for x in sys.argv[1:]] or [4, 6]))
print(f"\nd_Z = 4L^2 attained: {ok}")
