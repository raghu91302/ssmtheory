#!/usr/bin/env python3
"""Do hook errors from the weight-8 checks cut the effective distance?

Syndrome extraction for a weight-w Z-check: ancilla in |0>, one CNOT from
each data qubit (data = control, ancilla = target), measure the ancilla.
A Z fault on the ancilla after k of the CNOTs propagates back through the
remaining w-k, producing a Z error on that suffix of the data qubits.  So a
SINGLE fault can produce a data error of weight up to w-1.

A hook is harmless if, modulo the stabilizer group, it is equivalent to a
low-weight error.  A suffix of length s is equivalent to the complementary
prefix of length w-s (add the whole check), so the worst case is s = w/2.
The question is whether other stabilizers reduce it further.

The code is translation invariant, so one check of each type settles it.
For comparison the same computation is run on the hypercubic code, whose
checks all have weight 6.
"""
from itertools import product, combinations
from pysat.formula import IDPool
from pysat.card import ITotalizer
from pysat.solvers import Cadical195
import sys, time

L = 4
pop = lambda x: bin(x).count('1')
vs = [v for v in product(range(L), repeat=4) if sum(v) % 2 == 0]
add = lambda a, b: tuple((a[i]+b[i]) % L for i in range(4))
adj = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                          for i in range(4)) == [0, 0, 1, 1]
NN = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
nb = {v: [add(v, d) for d in NN] for v in vs}
E, F, T = {}, {}, {}
for v in vs:
    for u in nb[v]:
        k = frozenset((v, u))
        if k not in E: E[k] = len(E)
for ek in list(E):
    a, b = tuple(ek)
    for c in nb[a]:
        if c != b and adj(c, b):
            fk = frozenset((a, b, c))
            if fk not in F: F[fk] = len(F)
for fk in list(F):
    a, b, c = tuple(fk)
    for d in nb[a]:
        if d not in fk and adj(d, b) and adj(d, c):
            tk = frozenset((a, b, c, d))
            if tk not in T: T[tk] = len(T)
nF = len(F)
HZ = [0]*len(E)                       # weight-8 checks on edges
for fk, fi in F.items():
    for pr in combinations(tuple(fk), 2): HZ[E[frozenset(pr)]] |= 1 << fi
HX = [0]*len(T)                       # weight-4 checks on tetrahedra
for tk, ti in T.items():
    for tri in combinations(tuple(tk), 3): HX[ti] |= 1 << F[frozenset(tri)]
print(f"L={L}: qubits {nF}, Z-checks {len(HZ)} (weight 8), "
      f"X-checks {len(HX)} (weight 4)")


def bits(v):
    out = []
    while v:
        b = (v & -v).bit_length()-1; out.append(b); v &= v-1
    return out


def min_coset_weight(S, group, cap=6, nF=nF):
    """Smallest weight in the coset S + span(group)."""
    m = len(group)
    pool = IDPool(start_from=nF + m + 1)
    cnf = []
    # x_i (1..nF)  =  S_i  XOR  sum of selected rows containing i
    rowsfor = [[] for _ in range(nF)]
    for j, g in enumerate(group):
        for i in bits(g): rowsfor[i].append(nF + 1 + j)
    for i in range(nF):
        lits = rowsfor[i]
        xv = i + 1
        if not lits:
            cnf.append([xv] if (S >> i) & 1 else [-xv]); continue
        acc = lits[0]
        for v in lits[1:]:
            nxt = pool.id()
            cnf += [[-nxt, -acc, -v], [-nxt, acc, v],
                    [nxt, -acc, v], [nxt, acc, -v]]
            acc = nxt
        if (S >> i) & 1:                       # x = 1 XOR acc  -> x != acc
            cnf += [[xv, acc], [-xv, -acc]]
        else:                                  # x = acc
            cnf += [[-xv, acc], [xv, -acc]]
    tot = ITotalizer(lits=list(range(1, nF+1)), ubound=cap, top_id=pool.top)
    best = None
    with Cadical195(bootstrap_with=cnf) as s:
        s.append_formula(tot.cnf.clauses)
        for w in range(0, cap+1):
            if s.solve(assumptions=[-tot.rhs[w]]):
                best = w; break
    tot.delete()
    return best


# ---- Z-sector: hooks from the weight-8 checks ------------------------------
e0 = list(E)[0]
faces8 = [F[fk] for fk in F if e0 <= fk]
print(f"\nweight-8 check on one edge: {len(faces8)} data qubits")
print("suffix length -> smallest equivalent weight (modulo all stabilizers)")
res8 = {}
for s in range(1, 8):
    S = 0
    for i in faces8[8-s:]: S |= 1 << i
    w = min_coset_weight(S, HZ, cap=6)
    res8[s] = w
    print(f"  suffix {s}: raw weight {s}, reduced to {w}")
worst8 = max(res8.values())
print(f"worst hook from a weight-8 check reduces to weight {worst8}")

# ---- X-sector: hooks from the weight-4 checks ------------------------------
t0 = list(T)[0]
faces4 = [F[frozenset(tri)] for tri in combinations(tuple(t0), 3)]
print(f"\nweight-4 check on one tetrahedron: {len(faces4)} data qubits")
res4 = {}
for s in range(1, 4):
    S = 0
    for i in faces4[4-s:]: S |= 1 << i
    w = min_coset_weight(S, HX, cap=4)
    res4[s] = w
    print(f"  suffix {s}: raw weight {s}, reduced to {w}")
worst4 = max(res4.values())
print(f"worst hook from a weight-4 check reduces to weight {worst4}")

print(f"\n--- consequence ---")
print(f"code distances: d_X = {2*L*L}, d_Z = {4*L*L}")
print(f"a single fault acts like a weight-{worst4} error in the X sector,")
print(f"and like a weight-{worst8} error in the Z sector, so")
print(f"  circuit d_X >= {2*L*L} / {worst4} = {2*L*L/worst4:.1f}")
print(f"  circuit d_Z >= {4*L*L} / {worst8} = {4*L*L/worst8:.1f}")


# ---- the same computation for the hypercubic code, for comparison ----------
# qubits on the squares of the L^4 hypercubic torus; Z-checks on edges and
# X-checks on cubes, all of weight 6.
sq = {}
for p in product(range(L), repeat=4):
    for dd in combinations(range(4), 2):
        sq[(p, dd)] = len(sq)
nC = len(sq)
sh = lambda p, i, s=1: tuple((p[j] + s*(j == i)) % L for j in range(4))
HZc, HXc = [], []
for p in product(range(L), repeat=4):
    for i in range(4):                                   # edge (p, i)
        r = 0
        for j in range(4):
            if j != i:
                dd = tuple(sorted((i, j)))
                r |= 1 << sq[(p, dd)]
                r |= 1 << sq[(sh(p, j, -1), dd)]
        HZc.append(r)
    for c in combinations(range(4), 3):                  # cube (p, c)
        r = 0
        for j in c:
            dd = tuple(x for x in c if x != j)
            r |= 1 << sq[(p, dd)]
            r |= 1 << sq[(sh(p, j), dd)]
        HXc.append(r)
print(f"\nhypercubic code, L={L}: qubits {nC}, all checks weight 6")
for name, H in (("Z-check (edge)", HZc), ("X-check (cube)", HXc)):
    f = bits(H[0])
    red = [min_coset_weight(sum(1 << i for i in f[6-s:]), H, 6, nC)
           for s in range(1, 6)]
    print(f"  {name}: suffixes 1..5 reduce to {red}, worst {max(red)}")
print(f"  circuit d >= L^2 / 3 = {L*L/3:.1f} in each sector "
      f"(d = L^2 = {L*L})")

# ---- several faults on one ancilla ------------------------------------------
# Z faults on the same ancilla after k1 < k2 CNOTs leave Z on the data qubits
# between positions k1 and k2: always a contiguous segment of the CNOT order.
seg = [min_coset_weight(sum(1 << faces8[k] for k in range(i, j)), HZ, 6)
       for i in range(8) for j in range(i+1, 9) if j - i < 8]
print(f"\nD4 weight-8 check: every contiguous segment reduces to weight "
      f"<= {max(seg)}")
