#!/usr/bin/env python3
"""Lemmas for the systolic bound on the D4 face code.

The bound is a counting argument.  Let z be a nontrivial 2-cycle and w a
2-cocycle with <w,z> = 1.  Translate w by every element of the torus
translation group G.  Each translate still represents the same cohomology
class, so <g.w, z> = 1 for every g, hence supp(g.w) meets supp(z).  Then

    |G| <= sum_g |supp(g.w) cap supp(z)|
         = sum_{f in supp(z)} #{g : g^{-1}f in supp(w)}
        <= |z| . |w|                      (G acts freely on faces)

so |z| >= |G| / |w|.  Two things need checking:

  L1  G acts freely on the faces of the honeycomb.
  L2  translations act trivially on H_2, i.e. g.w - w is a coboundary.
"""
import numpy as np, sys
from itertools import product, combinations
from satdist import pivots, reduce_, kernel, logical_reps

L = int(sys.argv[1]) if len(sys.argv) > 1 else 4

vs = [v for v in product(range(L), repeat=4) if sum(v) % 2 == 0]
add = lambda a, b: tuple((a[i]+b[i]) % L for i in range(4))
adj = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                          for i in range(4)) == [0, 0, 1, 1]
NN = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
nb = {v: [add(v, d) for d in NN] for v in vs}
E, F, T = {}, {}, {}
for v in vs:
    for u in nb[v]:
        k = frozenset((v, u))
        if k not in E: E[k] = len(E)
for ek in list(E):
    a, b = tuple(ek)
    for c in nb[a]:
        if c != b and adj(c, b):
            fk = frozenset((a, b, c))
            if fk not in F: F[fk] = len(F)
for fk in list(F):
    a, b, c = tuple(fk)
    for d in nb[a]:
        if d not in fk and adj(d, b) and adj(d, c):
            tk = frozenset((a, b, c, d))
            if tk not in T: T[tk] = len(T)
nF = len(F)
HZ = [0]*len(E)
for fk, fi in F.items():
    for pr in combinations(tuple(fk), 2):
        HZ[E[frozenset(pr)]] |= 1 << fi
HX = []
for tk in T:
    r = 0
    for tri in combinations(tuple(tk), 3): r |= 1 << F[frozenset(tri)]
    HX.append(r)
pop = lambda x: bin(x).count('1')
print(f"L={L}: V={len(vs)} E={len(E)} F={nF} T={len(T)}")

# ---- L1: does G act freely on faces? ---------------------------------------
G = vs                                   # translations = lattice points mod L
print(f"|G| = {len(G)}   (predicted L^4/2 = {L**4//2})")
stab = 0
for g in G:
    if g == (0,)*4:
        continue
    for fk in F:
        if frozenset(add(u, g) for u in fk) == fk:
            stab += 1
            break
print(f"L1  non-identity translations fixing some face setwise: {stab} "
      f"(free action iff 0)")

# orbit structure
seen, orbits = set(), 0
for fk in F:
    if fk in seen: continue
    orbits += 1
    for g in G:
        seen.add(frozenset(add(u, g) for u in fk))
print(f"    face orbits under G: {orbits}  "
      f"(orbit size {nF//orbits}, free iff = |G|)")

# ---- L2: do translations act trivially on homology? ------------------------
LZ = logical_reps(HX, HZ, nF, 6)         # Z-logicals (2-cocycles)
LX = logical_reps(HZ, HX, nF, 6)         # X-logicals (2-cycles)
pZ, pX = pivots(HZ), pivots(HX)

def translate(v, g):
    out = 0
    for fk, fi in F.items():
        if (v >> fi) & 1:
            out |= 1 << F[frozenset(add(u, g) for u in fk)]
    return out

gens = [tuple(int(i == j) + int(i == (j+1) % 4) for i in range(4))
        for j in range(4)]                # four independent root translations
bad = 0
for g in gens:
    for v in LZ:
        if reduce_(translate(v, g) ^ v, pZ) != 0:   # must be a coboundary
            bad += 1
    for v in LX:
        if reduce_(translate(v, g) ^ v, pX) != 0:   # must be a boundary
            bad += 1
print(f"L2  translated logicals leaving their class (should be 0): {bad}")

# ---- flat A2 membranes and the classes they span ---------------------------
roots = [tuple(r) for r in product((-1, 0, 1), repeat=4)
         if sum(map(abs, r)) == 2]
# Count DISTINCT sheets.  (r,s) and (r,-s) span the same plane, so counting
# root pairs double-counts; and every translate of a plane is its own sheet.
sheets = {}                      # membrane bitmask -> its point set
for r, s in combinations(roots, 2):
    if not (adj((0,)*4, tuple((r[i]-s[i]) for i in range(4)))
            or adj((0,)*4, tuple((r[i]+s[i]) for i in range(4)))):
        continue
    base = [tuple((a*r[i] + b*s[i]) % L for i in range(4))
            for a in range(L) for b in range(L)]
    for t in vs:                 # all translates
        pts = frozenset(add(p, t) for p in base)
        m = 0
        for fk in F:
            if all(u in pts for u in fk): m |= 1 << F[fk]
        if not m or m in sheets: continue
        if any(pop(h & m) % 2 for h in HZ): continue      # must be a cycle
        if reduce_(m, pX) == 0: continue                   # must be nontrivial
        sheets[m] = pts

ws = sorted({pop(m) for m in sheets})
print(f"\nflat A2 membranes (distinct, incl. translates): {len(sheets)}, "
      f"weights {ws} (2L^2 = {2*L*L})")
classes = {tuple(pop(m & f) % 2 for f in LZ) for m in sheets}
span, aug = 0, {}
for cls in classes:
    v = int("".join(str(b) for b in cls), 2)
    r = reduce_(v, aug)
    if r:
        span += 1
        aug[r.bit_length()-1] = r
print(f"distinct classes: {len(classes)}, dimension spanned: {span} of 6")

inslice = sum(1 for pts in sheets.values()
              if any(len({p[i] for p in pts}) == 1 for i in range(4)))
print(f"flat membranes lying in a coordinate hyperplane x_i = const: "
      f"{inslice} of {len(sheets)}")
