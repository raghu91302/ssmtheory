#!/usr/bin/env python3
r"""Exact minimum distance of one CSS sector via SAT.

For an X-type logical we need the minimum weight of
    x in ker(H_Z)  \  rowspace(H_X).
Since rowspace(H_X) = ker(H_X)^perp and ker(H_X) is spanned by
rowspace(H_Z) together with the Z-logical representatives, an
x already in ker(H_Z) is a stabilizer iff <x, LZ_i> = 0 for all i.
So x is a nontrivial logical iff <x, LZ_i> = 1 for at least one i, and
    d_X = min_i  min { |x| : H_Z x = 0, <x, LZ_i> = 1 }.
Each inner problem is one CNF; we search upward in weight, so the first
satisfiable bound is the exact distance for that functional.

Encoding: parity constraints by Tseitin XOR chains (4 clauses per gate),
cardinality by an incremental totalizer so a single solver instance can be
queried at successive weight bounds under assumptions.

The GF(2) helpers need only the standard library; python-sat is loaded
only when min_distance is called.
"""
import sys, time


# ---------------------------------------------------------------- GF(2) -----
def pivots(rows):
    piv = {}
    for r in rows:
        while r:
            h = r.bit_length() - 1
            if h in piv:
                r ^= piv[h]
            else:
                piv[h] = r
                break
    return piv


def reduce_(v, piv):
    while v:
        h = v.bit_length() - 1
        if h not in piv:
            return v
        v ^= piv[h]
    return 0


def kernel(rows, n):
    """Basis of the kernel of the map x -> (<r,x>)_r, r ranging over rows."""
    piv = {}
    for r in rows:
        while r:
            h = r.bit_length() - 1
            if h in piv:
                r ^= piv[h]
            else:
                piv[h] = r
                break
    def clean(v):
        out = 0
        while v:
            h = v.bit_length() - 1
            if h in piv:
                v ^= piv[h]
            else:
                out |= 1 << h
                v ^= 1 << h
        return out
    for h in list(piv):
        piv[h] = (1 << h) | clean(piv[h] ^ (1 << h))
    free = [c for c in range(n) if c not in piv]
    out = []
    for fc in free:
        v = 1 << fc
        for h, r in piv.items():
            if (r >> fc) & 1:
                v |= 1 << h
        out.append(v)
    return out


def logical_reps(check, other, n, want):
    """Representatives of ker(check) modulo rowspace(other)."""
    aug = dict(pivots(other))
    reps = []
    for v in kernel(check, n):
        r = reduce_(v, aug)
        if r:
            reps.append(v)
            aug[r.bit_length() - 1] = r
            if len(reps) == want:
                break
    return reps


def bits(v):
    out = []
    while v:
        b = (v & -v).bit_length() - 1
        out.append(b)
        v &= v - 1
    return out


# ------------------------------------------------------------------ CNF -----
def xor_chain(lits, parity, pool, cnf):
    """Force XOR(lits) == parity, using Tseitin chaining."""
    if not lits:
        assert parity == 0
        return
    acc = lits[0]
    for v in lits[1:]:
        nxt = pool.id()
        # nxt <-> acc XOR v
        cnf.append([-nxt, -acc, -v])
        cnf.append([-nxt, acc, v])
        cnf.append([nxt, -acc, v])
        cnf.append([nxt, acc, -v])
        acc = nxt
    cnf.append([acc] if parity else [-acc])


def min_distance(check_rows, functionals, n, ub, lb=1, step=1,
                 label="", timeout_s=None):
    """Smallest weight of x with check_rows.x = 0 and <x,f> = 1 for some f."""
    from pysat.formula import IDPool
    from pysat.card import ITotalizer
    from pysat.solvers import Cadical195
    best = None
    for fi, f in enumerate(functionals):
        pool = IDPool(start_from=n + 1)
        cnf = []
        for r in check_rows:
            s = bits(r)
            if s:
                xor_chain([b + 1 for b in s], 0, pool, cnf)
        sf = bits(f)
        xor_chain([b + 1 for b in sf], 1, pool, cnf)

        cap = best - step if best is not None else ub
        if cap < lb:
            break
        tot = ITotalizer(lits=list(range(1, n + 1)), ubound=cap, top_id=pool.top)
        with Cadical195(bootstrap_with=cnf) as s:
            s.append_formula(tot.cnf.clauses)
            w = lb
            t0 = time.time()
            while w <= cap:
                sat = s.solve(assumptions=[-tot.rhs[w]])
                el = time.time() - t0
                print(f"  [{label} f{fi}] weight <= {w:3d}: "
                      f"{'SAT' if sat else 'UNSAT'}   ({el:.1f}s)", flush=True)
                if sat:
                    model = s.get_model()
                    sup = [i for i in range(n) if model[i] > 0]
                    assert len(sup) <= w
                    best = len(sup) if best is None else min(best, len(sup))
                    print(f"  [{label} f{fi}] found logical of weight "
                          f"{len(sup)}", flush=True)
                    break
                if timeout_s and el > timeout_s:
                    print(f"  [{label} f{fi}] budget exhausted; "
                          f"proved d > {w}", flush=True)
                    return best, w
                w += step
            else:
                print(f"  [{label} f{fi}] no logical of weight <= {cap}",
                      flush=True)
        tot.delete()
    return best, None
