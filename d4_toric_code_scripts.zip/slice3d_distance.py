#!/usr/bin/env python3
"""Brute-force distance of the three-dimensional face code on a slice.

The slice x4 = 0 is the tetrahedral-octahedral (FCC Delaunay) honeycomb.
The shadow argument of the paper predicts that its smallest X-type logical
operator has weight 2L^2.  This script finds the minimum weight exactly by
SAT (see satdist.py).  At L = 4 it reports d_X = 32.  Needs python-sat.
Usage: python3 slice3d_distance.py L
"""
import sys
from itertools import product, combinations
from satdist import (pivots, reduce_, kernel, logical_reps, bits, min_distance)

L = int(sys.argv[1]) if len(sys.argv) > 1 else 4

vs3 = [v for v in product(range(L), repeat=3) if sum(v) % 2 == 0]
add3 = lambda a, b: tuple((a[i] + b[i]) % L for i in range(3))
adj3 = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                           for i in range(3)) == [0, 1, 1]
NN3 = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
nb3 = {v: [add3(v, d) for d in NN3] for v in vs3}

E3, F3 = {}, {}
for v in vs3:
    for u in nb3[v]:
        k = frozenset((v, u))
        if k not in E3: E3[k] = len(E3)
for ek in list(E3):
    a, b = tuple(ek)
    for c in nb3[a]:
        if c != b and adj3(c, b):
            fk = frozenset((a, b, c))
            if fk not in F3: F3[fk] = len(F3)
nF3, nE3 = len(F3), len(E3)

HZ3 = [0] * nE3
for fk, fi in F3.items():
    for pr in combinations(tuple(fk), 2):
        HZ3[E3[frozenset(pr)]] |= 1 << fi

st3 = []
for t in product(range(L), repeat=3):                      # tetrahedra
    c = tuple(x + .5 for x in t)
    near = [v for v in vs3
            if sum(min(abs(v[i]-c[i]), L-abs(v[i]-c[i]))**2
                   for i in range(3)) < 0.751]
    r = 0
    for tri in combinations(near, 3): r |= 1 << F3[frozenset(tri)]
    st3.append(r)
for h in product(range(L), repeat=3):                      # octahedra
    if sum(h) % 2 == 1:
        nbh = [add3(h, tuple(int(i == j)*s for j in range(3)))
               for i in range(3) for s in (1, -1)]
        r = 0
        for tri in combinations(nbh, 3):
            fk = frozenset(tri)
            if fk in F3: r |= 1 << F3[fk]
        st3.append(r)

wZ = {bin(r).count('1') for r in HZ3}
wS = sorted({bin(r).count('1') for r in st3})
rkZ, rkS = len(pivots(HZ3)), len(pivots(st3))
print(f"L={L}  3D slice code: V={len(vs3)} E={nE3} F={nF3} (qubits)")
print(f"  Z-check (edge) weights {wZ}, X-check (cell) weights {wS}")
print(f"  rk(HZ3)={rkZ}  rk(st3)={rkS}  k={nF3-rkZ-rkS}")
css = all(bin(a & b).count('1') % 2 == 0 for a in st3 for b in HZ3)
print(f"  CSS: {css}")

k = nF3 - rkZ - rkS
LZ3 = logical_reps(st3, HZ3, nF3, k)     # Z-logicals: functionals for d_X
LX3 = logical_reps(HZ3, st3, nF3, k)     # X-logicals: functionals for d_Z

print(f"\nd_X (min wrapping membrane, ker HZ3 \\ rowspace st3):")
dX, _ = min_distance(HZ3, LZ3, nF3, ub=2*L*L+8, lb=2, step=2, label="3D X")
print(f"\nd_Z (ker st3 \\ rowspace HZ3):")
dZ, _ = min_distance(st3, LX3, nF3, ub=4*L+12, lb=2, step=2, label="3D Z")
print(f"\nL={L}: d_X={dX}  d_Z={dZ}  d={min(x for x in (dX,dZ) if x)}")
