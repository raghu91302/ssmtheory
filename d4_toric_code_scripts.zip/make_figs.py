import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from itertools import product, combinations
plt.rcParams.update({'font.family': 'serif', 'mathtext.fontset': 'stix',
                     'font.size': 9})

BLUE, ORANGE, GREEN, RED = 'tab:blue', 'tab:orange', 'tab:green', 'tab:red'

# ======================= FIGURE 1: structure =======================
fig = plt.figure(figsize=(10.2, 7.6))

# (a) the 16-cell: a qubit face and an X-check facet
ax = fig.add_subplot(2, 2, 1, projection='3d')
P = np.array([[1, 0, 0, .38], [0, 1, 0, .38], [0, 0, 1, .38]])
V4 = [np.eye(4)[i]*s for i in range(4) for s in (1, -1)]
V3 = [P @ v for v in V4]
for i, j in combinations(range(8), 2):
    if not np.allclose(V4[i], -V4[j]):
        ax.plot(*zip(V3[i], V3[j]), color='0.55', lw=0.7, zorder=1)
ax.add_collection3d(Poly3DCollection([[V3[0], V3[2], V3[4]]], facecolor=BLUE,
                                     alpha=0.6, edgecolor='k', lw=1.3))
tetv = [V3[0], V3[2], V3[4], V3[6]]
for f in combinations(range(4), 3):
    ax.add_collection3d(Poly3DCollection([[tetv[f[0]], tetv[f[1]], tetv[f[2]]]],
                        facecolor=ORANGE, alpha=0.22, edgecolor=ORANGE, lw=1.4))
xs = np.array(V3)
ax.scatter(xs[:, 0], xs[:, 1], xs[:, 2], color='k', s=22, zorder=5)
ax.set_title('(a) One 16-cell: 8 corners, 24 edges\n'
             'qubit = triangle (blue), $X$-check = tetrahedron (orange)',
             fontsize=9)
ax.set_axis_off(); ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=16, azim=32)

# (b) a 16-cell split 4+4 by a slice
ax = fig.add_subplot(2, 2, 2, projection='3d')
pts = [p for p in product((0, 1), repeat=4) if sum(p) % 2 == 0]
col = {0: BLUE, 1: RED}
for i, j in combinations(range(len(pts)), 2):
    a, b = np.array(pts[i]), np.array(pts[j])
    if not np.allclose(a + b, (1, 1, 1, 1)):
        same = pts[i][3] == pts[j][3]
        ax.plot(*zip(a[:3], b[:3]), color=col[pts[i][3]] if same else '0.75',
                lw=2.0 if same else 0.7, ls='-' if same else '--')
for p in pts:
    ax.scatter(*np.array(p[:3]), color=col[p[3]], s=40, depthshade=False)
ax.set_title('(b) The same 16-cell cut by a slice\n'
             '4 corners in the slice (blue), 4 just outside (red)', fontsize=9)
ax.set_axis_off(); ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=18, azim=40)

# (c) check weights
ax = fig.add_subplot(2, 2, 3)
lbl = ['$X$-check\n(this code)', '$X$-check\n(hypercubic)',
       '$Z$-check\n(this code)', '$Z$-check\n(hypercubic)']
val = [4, 6, 8, 6]
cs = [GREEN, '0.7', ORANGE, '0.7']
b = ax.bar(lbl, val, color=cs, edgecolor='k', lw=0.6)
for r, v in zip(b, val):
    ax.text(r.get_x() + r.get_width()/2, v + 0.15, str(v), ha='center',
            fontweight='bold', fontsize=10)
ax.axhline(4, ls=':', color=GREEN, lw=1)
ax.text(3.45, 4.15, 'smallest possible', color=GREEN, fontsize=8, ha='right')
ax.set_ylabel('qubits touched by one check'); ax.set_ylim(0, 9.5)
ax.set_title('(c) Check weights', fontsize=9)
ax.spines[['top', 'right']].set_visible(False)

# (d) incidence table
ax = fig.add_subplot(2, 2, 4); ax.axis('off')
rows = [['triangle sits in how many tetrahedra', '3'],
        ['triangle sits in how many 16-cells', '3'],
        ['tetrahedron sits in how many 16-cells', '2'],
        ['edge sits in how many triangles', '8'],
        ['checks touching one qubit', '3 + 3']]
t = ax.table(cellText=rows, colLabels=['counted at $L=4$', 'value'],
             cellLoc='left', loc='center', colWidths=[0.68, 0.2])
t.auto_set_font_size(False); t.set_fontsize(8.6); t.scale(1, 1.55)
for (r, c), cell in t.get_celld().items():
    cell.set_linewidth(0.5)
    if r == 0:
        cell.set_facecolor('0.9'); cell.set_text_props(weight='bold')
    if r == 3:
        cell.set_facecolor('#e8f4e8')
ax.set_title('(d) How the pieces fit together\n'
             '"tetrahedron in 2 16-cells" is why errors make loops',
             fontsize=9, y=0.86)

plt.tight_layout(); plt.savefig('fig1_structure.pdf', bbox_inches='tight')
plt.close()
print("fig1 done")

# ======================= FIGURE 2: distance =======================
L = 4
vs3 = [v for v in product(range(L), repeat=3) if sum(v) % 2 == 0]
adj3 = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                           for i in range(3)) == [0, 1, 1]
plane = [v for v in vs3 if sum(v) % L == 0]
tris = [t for t in combinations(plane, 3)
        if all(adj3(a, b) for a, b in combinations(t, 2))]


def lift(a, b):
    d = tuple((b[i]-a[i]) % L for i in range(3))
    return tuple(x - L if x > L//2 else x for x in d)


fig = plt.figure(figsize=(10.2, 7.4))

# (a) the close-packed membrane, drawn unwrapped inside the FCC lattice
ax = fig.add_subplot(2, 2, 1, projection='3d')
M = 4
box = [p for p in product(range(M+1), repeat=3) if sum(p) % 2 == 0]
pl = [p for p in box if sum(p) == M]
near = lambda a, b: sum((a[i]-b[i])**2 for i in range(3)) == 2
ba = np.array([p for p in box if p not in pl], float)
ax.scatter(ba[:, 0], ba[:, 1], ba[:, 2], color='0.72', s=9,
           depthshade=False, alpha=0.55)
for t in combinations(pl, 3):
    if all(near(a, b) for a, b in combinations(t, 2)):
        ax.add_collection3d(Poly3DCollection([np.array(t, float)],
                            facecolor=BLUE, alpha=0.45, edgecolor='k', lw=0.6))
pa = np.array(pl, float)
ax.scatter(pa[:, 0], pa[:, 1], pa[:, 2], color='k', s=20, depthshade=False)
ax.set_axis_off(); ax.view_init(elev=30, azim=38)
ax.set_box_aspect((1, 1, 1))
ax.set_title('(a) A minimum-weight logical operator\n'
             'a close-packed plane of the lattice (grey = other lattice '
             'points)', fontsize=9)

# (b) its shadow tiles the 2D torus exactly once
ax = fig.add_subplot(2, 2, 2)
for t in tris:
    a = np.array(t[0], float)[:2]
    u, v = np.array(lift(t[0], t[1]))[:2], np.array(lift(t[0], t[2]))[:2]
    up = (u[0]*v[1] - u[1]*v[0]) > 0
    for sx in (-L, 0, L):
        for sy in (-L, 0, L):
            o = a + np.array([sx, sy])
            ax.fill(*zip(o, o+u, o+v),
                    facecolor=BLUE if up else '#bcd8ef',
                    alpha=0.85, edgecolor='k', lw=0.6)
ax.set_xlim(0, L); ax.set_ylim(0, L)
ax.set_aspect('equal'); ax.set_xticks(range(L+1)); ax.set_yticks(range(L+1))
ax.set_xlabel('$x_1$'); ax.set_ylabel('$x_2$')
ax.set_title('(b) Its shadow covers the square exactly once\n'
             '32 shadows of area $1/2$ add to $16=L^2$: nothing wasted',
             fontsize=9)

# (c) the exhaustive search at L=4
ax = fig.add_subplot(2, 2, 3)
ws = list(range(6, 33, 2))
for w in ws:
    if w < 32:
        ax.plot(w, 1, marker='x', color=RED, ms=8, mew=2)
    else:
        ax.plot(w, 1, marker='o', color=GREEN, ms=13,
                markeredgecolor='k', mew=0.8, zorder=5)
ax.axvspan(5, 31, color=RED, alpha=0.06)
ax.axvline(32, color=GREEN, lw=1.2, ls=':')
ax.text(18, 1.42, 'no logical operator exists\nat any of these weights',
        ha='center', fontsize=9, color=RED)
ax.text(32, 0.55, '$2L^2=32$', ha='center', fontsize=10.5,
        color=GREEN, fontweight='bold')
ax.set_xlim(4, 35); ax.set_ylim(0.3, 1.75)
ax.set_xticks(ws); ax.set_yticks([])
ax.set_xlabel('weight of the operator')
ax.tick_params(axis='x', labelsize=7.5)
ax.spines[['top', 'right', 'left']].set_visible(False)
ax.set_title('(c) Brute-force search on the slice code, $L=4$\n'
             'odd weights are ruled out on parity grounds', fontsize=9)

# (d) qubits needed at equal distance
ax = fig.add_subplot(2, 2, 4)
dd = np.arange(8, 81, 1)
ax.plot(dd, 6*dd**2, color='0.45', lw=2, label='hypercubic:  $6d^2$')
ax.plot(dd, 4*dd**2, color=GREEN, lw=2.4, label='$D_4$ face code:  $4d^2$')
ax.fill_between(dd, 4*dd**2, 6*dd**2, color=GREEN, alpha=0.13)
ax.set_xlabel('distance $d$'); ax.set_ylabel('physical qubits $n$')
ax.legend(frameon=False, loc='upper left')
ax.text(46, 1.05e4, 'one third fewer\nqubits', color=GREEN, fontsize=9,
        ha='center')
ax.set_title('(d) Cost at the same distance', fontsize=9)
ax.spines[['top', 'right']].set_visible(False)

plt.tight_layout(); plt.savefig('fig2_distance.pdf', bbox_inches='tight')
plt.close()
print("fig2 done")
