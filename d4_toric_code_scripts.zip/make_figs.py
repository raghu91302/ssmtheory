"""Draw the two figures of the paper.  Needs numpy and matplotlib."""
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from itertools import product, combinations
plt.rcParams.update({'font.family': 'serif', 'mathtext.fontset': 'stix',
                     'font.size': 11, 'axes.titlesize': 11.5,
                     'axes.labelsize': 11})

BLUE, ORANGE, GREEN, RED = 'tab:blue', 'tab:orange', 'tab:green', 'tab:red'

# ======================= FIGURE 1: structure =======================
fig = plt.figure(figsize=(11, 9.4))

# (a) the 16-cell drawn as a flat octagon (its Petrie polygon)
ax = fig.add_subplot(2, 2, 1)
names = ['$+e_1$', '$+e_2$', '$+e_3$', '$+e_4$',
         '$-e_1$', '$-e_2$', '$-e_3$', '$-e_4$']
ang = np.pi/2 - np.arange(8)*np.pi/4
P = np.c_[np.cos(ang), np.sin(ang)]
for i, j in combinations(range(8), 2):
    if (j - i) % 8 != 4:                      # every pair but opposite corners
        ax.plot(*zip(P[i], P[j]), color='0.7', lw=0.8, zorder=1)
tet = [0, 1, 2, 3]                            # +e1 +e2 +e3 +e4
for i, j in combinations(tet, 2):
    ax.plot(*zip(P[i], P[j]), color=ORANGE, lw=3.0, zorder=2)
ax.fill(*zip(*P[[0, 1, 2]]), facecolor=BLUE, alpha=0.55, edgecolor='k',
        lw=1.2, zorder=3)
ax.scatter(P[:, 0], P[:, 1], color='k', s=36, zorder=4)
for k in range(8):
    ax.text(*(1.2*P[k]), names[k], ha='center', va='center', fontsize=11)
ax.set_xlim(-1.45, 1.45); ax.set_ylim(-1.45, 1.45)
ax.set_aspect('equal'); ax.axis('off')
ax.set_title('(a) One 16-cell: 8 corners, 24 edges\n'
             'blue triangle = one qubit;  orange = one $X$-check')

# (b) a 16-cell split 4+4 by a slice
ax = fig.add_subplot(2, 2, 2, projection='3d')
pts = [p for p in product((0, 1), repeat=4) if sum(p) % 2 == 0]
col = {0: BLUE, 1: RED}
for i, j in combinations(range(len(pts)), 2):
    a, b = np.array(pts[i]), np.array(pts[j])
    if not np.allclose(a + b, (1, 1, 1, 1)):
        same = pts[i][3] == pts[j][3]
        ax.plot(*zip(a[:3], b[:3]), color=col[pts[i][3]] if same else '0.75',
                lw=2.4 if same else 0.8, ls='-' if same else '--')
for p in pts:
    ax.scatter(*np.array(p[:3]), color=col[p[3]], s=55, depthshade=False)
ax.set_title('(b) A 16-cell centered between two slices:\n'
             '4 corners in $x_4=0$ (blue), 4 in $x_4=1$ (red)')
ax.set_axis_off(); ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=18, azim=40)

# (c) check weights
ax = fig.add_subplot(2, 2, 3)
lbl = ['$X$-check\nthis code', '$X$-check\nhypercubic',
       '$Z$-check\nthis code', '$Z$-check\nhypercubic']
val = [4, 6, 8, 6]
cs = [GREEN, '0.7', ORANGE, '0.7']
b = ax.bar(range(4), val, color=cs, edgecolor='k', lw=0.6, width=0.62)
ax.set_xticks(range(4)); ax.set_xticklabels(lbl)
for r, v in zip(b, val):
    ax.text(r.get_x() + r.get_width()/2, v + 0.2, str(v), ha='center',
            va='bottom', fontweight='bold', fontsize=12)
ax.text(0, 5.05, '(smallest\npossible)', ha='center', va='bottom',
        color=GREEN, fontsize=10)
ax.set_ylabel('qubits touched by one check'); ax.set_ylim(0, 10)
ax.set_xlim(-0.6, 3.6)
ax.set_title('(c) Check weights')
ax.spines[['top', 'right']].set_visible(False)

# (d) incidence table
ax = fig.add_subplot(2, 2, 4); ax.axis('off')
rows = [['triangles per tetrahedron', '4'],
        ['tetrahedra per triangle', '3'],
        ['16-cells per triangle', '3'],
        ['16-cells per tetrahedron', '2'],
        ['triangles per edge', '8'],
        ['checks per qubit ($X$ + $Z$)', '3 + 3']]
t = ax.table(cellText=rows, colLabels=['incidence, checked at $L=4$', 'count'],
             cellLoc='left', loc='center', colWidths=[0.7, 0.2])
t.auto_set_font_size(False); t.set_fontsize(11); t.scale(1, 1.9)
for (r, c), cell in t.get_celld().items():
    cell.set_linewidth(0.5)
    if r == 0:
        cell.set_facecolor('0.9'); cell.set_text_props(weight='bold')
    if r == 4:
        cell.set_facecolor('#e8f4e8')
ax.set_title('(d) How the pieces fit together', y=0.9)

plt.tight_layout(h_pad=2.5); plt.savefig('fig1_structure.pdf',
                                         bbox_inches='tight')
plt.close()
print("fig1 done")

# ======================= FIGURE 2: distance =======================
L = 4
vs3 = [v for v in product(range(L), repeat=3) if sum(v) % 2 == 0]
adj3 = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                           for i in range(3)) == [0, 1, 1]
plane = [v for v in vs3 if sum(v) % L == 0]
tris = [t for t in combinations(plane, 3)
        if all(adj3(a, b) for a, b in combinations(t, 2))]


def lift(a, b):
    d = tuple((b[i]-a[i]) % L for i in range(3))
    return tuple(x - L if x > L//2 else x for x in d)


fig = plt.figure(figsize=(11, 9.6))

# (a) the close-packed sheet, drawn unwrapped inside the FCC lattice
ax = fig.add_subplot(2, 2, 1, projection='3d')
M = 4
box = [p for p in product(range(M+1), repeat=3) if sum(p) % 2 == 0]
pl = [p for p in box if sum(p) == M]
near = lambda a, b: sum((a[i]-b[i])**2 for i in range(3)) == 2
ba = np.array([p for p in box if p not in pl], float)
ax.scatter(ba[:, 0], ba[:, 1], ba[:, 2], s=0)   # keeps the box size only
for t in combinations(pl, 3):
    if all(near(a, b) for a, b in combinations(t, 2)):
        ax.add_collection3d(Poly3DCollection([np.array(t, float)],
                            facecolor=BLUE, alpha=0.45, edgecolor='k', lw=0.7))
pa = np.array(pl, float)
ax.scatter(pa[:, 0], pa[:, 1], pa[:, 2], color='k', s=26, depthshade=False)
ax.set_axis_off(); ax.view_init(elev=30, azim=38)
ax.set_box_aspect((1, 1, 1))
ax.set_title('(a) Smallest $X$-type logical: a close-packed\n'
             'plane of $L^2$ points and $2L^2$ triangles')

# (b) its shadow tiles the 2D torus exactly once
ax = fig.add_subplot(2, 2, 2)
for t in tris:
    a = np.array(t[0], float)[:2]
    u, v = np.array(lift(t[0], t[1]))[:2], np.array(lift(t[0], t[2]))[:2]
    up = (u[0]*v[1] - u[1]*v[0]) > 0
    for sx in (-L, 0, L):
        for sy in (-L, 0, L):
            o = a + np.array([sx, sy])
            ax.fill(*zip(o, o+u, o+v),
                    facecolor=BLUE if up else '#bcd8ef',
                    alpha=0.85, edgecolor='k', lw=0.6)
ax.set_xlim(0, L); ax.set_ylim(0, L)
ax.set_aspect('equal'); ax.set_xticks(range(L+1)); ax.set_yticks(range(L+1))
ax.set_xlabel('$x_1$'); ax.set_ylabel('$x_2$')
ax.set_title('(b) Its shadow on $(x_1,x_2)$, $L=4$:\n'
             '32 triangles of area $1/2$ cover $L^2=16$ once')

# (c) the smallest Z-type logical: shadows on (x3, x4) through a point
ax = fig.add_subplot(2, 2, 3)
p = np.array([0.3, 0.45])
cuts = [([(0, 0), (1, 0), (0, 1)], [(1, 0), (1, 1), (0, 1)]),
        ([(0, 0), (1, 1), (0, 1)], [(0, 0), (1, 0), (1, 1)])]
for k, (hit, miss) in enumerate(cuts):
    off = np.array([1.6*k, 0])
    ax.fill(*zip(*(np.array(hit) + off)), facecolor=BLUE, alpha=0.55,
            edgecolor='k', lw=1.2)
    ax.fill(*zip(*(np.array(miss) + off)), facecolor='white',
            edgecolor='k', lw=1.2)
    ax.plot(*(p + off), marker='o', color=RED, ms=8, zorder=5)
    ax.text(0.5 + off[0], -0.17, '4 kinds of triangle\nhave this shadow',
            ha='center', va='top', fontsize=10.5)
ax.text(1.3, 1.12, 'unit cell of the $(x_3,x_4)$ shadow;\nred dot: where $Q$ crosses it', ha='center',
        va='bottom', fontsize=10.5, color=RED)
ax.set_xlim(-0.15, 2.75); ax.set_ylim(-0.75, 1.6)
ax.set_aspect('equal'); ax.axis('off')
ax.set_title('(c) Smallest $Z$-type logical: triangles crossed by\n'
             'a plane $Q$; $8$ kinds $\\times\\, L^2/2$ each $= 4L^2$')

# (d) the brute-force search on the slice code at L = 4
ax = fig.add_subplot(2, 2, 4)
rowsX = (1.0, list(range(2, 31, 2)), 32)       # X: even weights, parity
rowsZ = (0.0, list(range(1, 8)), 8)            # Z: every weight
for y, no, yes in (rowsX, rowsZ):
    ax.plot([no[0] - 0.3, no[-1] + 0.1], [y, y], color=RED, lw=7,
            alpha=0.35, solid_capstyle='butt')
    ax.plot(yes, y, marker='o', color=GREEN, ms=10, markeredgecolor='k',
            mew=0.8, zorder=5)
    ax.text(yes + 1.2, y, f'{yes}', va='center', ha='left', fontsize=12,
            color=GREEN, fontweight='bold')
ax.set_yticks([1.0, 0.0])
ax.set_yticklabels(['$X$-type\n($2L^2=32$)', '$Z$-type\n($2L=8$)'])
ax.set_xlim(-0.5, 37); ax.set_ylim(-0.7, 1.7)
ax.set_xticks(range(0, 33, 4))
ax.set_xlabel('weight tested')
ax.plot([], [], color=RED, lw=7, alpha=0.35,
        label='no logical operator')
ax.plot([], [], ls='none', marker='o', color=GREEN, ms=10,
        markeredgecolor='k', label='smallest found')
ax.legend(frameon=False, loc='upper center', ncol=2,
          bbox_to_anchor=(0.5, 1.02), fontsize=10.5, handletextpad=0.6, handlelength=1.6,
          columnspacing=1.5)
ax.spines[['top', 'right']].set_visible(False)
ax.set_title('(d) Exact search on the three-dimensional\n'
             'slice code, $L=4$')

plt.tight_layout(h_pad=2.5); plt.savefig('fig2_distance.pdf',
                                         bbox_inches='tight')
plt.close()
print("fig2 done")
