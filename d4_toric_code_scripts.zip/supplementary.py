#!/usr/bin/env python3
"""D4 face code -- the three L=4 claims not covered by verify_all.py.

  (1) Section 4: exhaustive weight-4 scan.  The only weight-4 operators that
      commute with every Z-check are the 3072 tetrahedron boundaries, and no
      weight-4 operator commutes with every X-check.
  (2) Section 5: a Z-type logical operator of weight exactly 64 = 4L^2.
      With the lower bound d_Z >= 4L^2 this gives d_Z = 64 at L = 4.
  (3) Sections 5 and 9: upper bounds for classes with no flat
      representative, one class in each of three independent directions.  A seeded local search; the numbers are upper
      bounds, not minima.

Needs numpy.  About ten minutes at L = 4 on a laptop, most of it in (1).
"""
import random
from itertools import product, combinations
import numpy as np

L = 4
pop = lambda x: bin(x).count('1')

# ---------------------------------------------------------------- lattice --
vs = [v for v in product(range(L), repeat=4) if sum(v) % 2 == 0]
add = lambda a, b: tuple((a[i]+b[i]) % L for i in range(4))
adj = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                          for i in range(4)) == [0, 0, 1, 1]
NN = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
nb = {v: [add(v, d) for d in NN] for v in vs}
E, F, T = {}, {}, {}
for v in vs:
    for u in nb[v]:
        k = frozenset((v, u))
        if k not in E: E[k] = len(E)
for ek in list(E):
    a, b = tuple(ek)
    for c in nb[a]:
        if c != b and adj(c, b):
            fk = frozenset((a, b, c))
            if fk not in F: F[fk] = len(F)
for fk in list(F):
    a, b, c = tuple(fk)
    for d in nb[a]:
        if d not in fk and adj(d, b) and adj(d, c):
            tk = frozenset((a, b, c, d))
            if tk not in T: T[tk] = len(T)
nF = len(F)
HZ = [0]*len(E)                                   # Z-checks: edges, weight 8
for fk, fi in F.items():
    for pr in combinations(tuple(fk), 2): HZ[E[frozenset(pr)]] |= 1 << fi
HX = [0]*len(T)                                   # X-checks: tets, weight 4
for tk, ti in T.items():
    for tri in combinations(tuple(tk), 3): HX[ti] |= 1 << F[frozenset(tri)]
print(f"L={L}: n={nF}, Z-checks {len(HZ)}, X-checks {len(HX)}", flush=True)


# ------------------------------------------------------------ GF(2) tools --
def pivots(rows):
    piv = {}
    for r in rows:
        while r:
            h = r.bit_length()-1
            if h in piv: r ^= piv[h]
            else: piv[h] = r; break
    return piv


def reduce_(v, piv):
    while v:
        h = v.bit_length()-1
        if h not in piv: return v
        v ^= piv[h]
    return 0


def kernel(rows, n):
    piv = pivots(rows)
    def clean(v):
        out = 0
        while v:
            h = v.bit_length()-1
            if h in piv: v ^= piv[h]
            else: out |= 1 << h; v ^= 1 << h
        return out
    for h in list(piv):
        piv[h] = (1 << h) | clean(piv[h] ^ (1 << h))
    out = []
    for fc in (c for c in range(n) if c not in piv):
        v = 1 << fc
        for h, r in piv.items():
            if (r >> fc) & 1: v |= 1 << h
        out.append(v)
    return out


def logical_reps(check, other, want):
    """Representatives of ker(check) modulo rowspace(other)."""
    aug, reps = dict(pivots(other)), []
    for v in kernel(check, nF):
        r = reduce_(v, aug)
        if r:
            reps.append(v); aug[r.bit_length()-1] = r
            if len(reps) == want: break
    return reps


def columns(H):
    cols = [0]*nF
    for i, r in enumerate(H):
        m = r
        while m:
            b = (m & -m).bit_length()-1; cols[b] |= 1 << i; m &= m-1
    return cols


def commutes(v, H):
    return all(pop(h & v) % 2 == 0 for h in H)


# ------------------------------------------- (1) exhaustive weight-4 scan --
def weight4(H):
    """All weight-4 kernel elements of H.  {a,b,c,d} is one iff
    col[a]^col[b] == col[c]^col[d].  Columns are hashed by a GF(2)-linear
    64-bit fold, so every true coincidence collides; collisions are then
    confirmed exactly.  The scan is exhaustive."""
    cols = columns(H)
    rng = np.random.default_rng(0)
    M = rng.integers(0, 2**63, size=len(H), dtype=np.uint64)
    key = np.zeros(nF, dtype=np.uint64)
    for i, r in enumerate(H):
        m = r
        while m:
            b = (m & -m).bit_length()-1; key[b] ^= M[i]; m &= m-1
    npairs = nF*(nF-1)//2
    pk = np.empty(npairs, dtype=np.uint64)
    pa = np.empty(npairs, dtype=np.int32)
    pb = np.empty(npairs, dtype=np.int32)
    p = 0
    for a in range(nF-1):
        m = nF-a-1
        pk[p:p+m] = key[a] ^ key[a+1:]
        pa[p:p+m] = a; pb[p:p+m] = np.arange(a+1, nF); p += m
    o = np.argsort(pk, kind='stable')
    pk, pa, pb = pk[o], pa[o], pb[o]
    quads = set()
    starts = np.flatnonzero(np.diff(pk) != 0) + 1
    bounds = np.concatenate(([0], starts, [npairs]))
    for s, e in zip(bounds[:-1], bounds[1:]):
        if e - s < 2: continue
        grp = [(int(pa[t]), int(pb[t])) for t in range(s, e)]
        for (a, b), (c, d) in combinations(grp, 2):
            if len({a, b, c, d}) == 4 and cols[a] ^ cols[b] == cols[c] ^ cols[d]:
                quads.add(frozenset((a, b, c, d)))
    return quads


print("\n(1) exhaustive weight-4 scan", flush=True)
qX = weight4(HZ)
tets = {frozenset(i for i in range(nF) if (h >> i) & 1) for h in HX}
print(f"  weight-4 operators commuting with every Z-check: {len(qX)}")
print(f"  ... exactly the tetrahedron boundaries: {qX == tets}")
qZ = weight4(HX)
print(f"  weight-4 operators commuting with every X-check: {len(qZ)}",
      flush=True)

# --------------------------------------- (2) a Z-logical of weight 64 ------
print("\n(2) Z-type logical operators reduced against the Z-stabilizers")
pZ = pivots(HZ)


def greedy(v, moves):
    improved = True
    while improved:
        improved = False
        for g in moves:
            if pop(v ^ g) < pop(v):
                v ^= g; improved = True
    return v


LZ = [greedy(v, HZ) for v in logical_reps(HX, HZ, 6)]
for v in LZ:
    assert commutes(v, HX) and reduce_(v, pZ)          # valid, nontrivial
w = sorted(pop(v) for v in LZ)
print(f"  weights after greedy reduction: {w}")
print(f"  lightest: {w[0]}  (lower bound 4L^2 = {4*L*L})  "
      f"=> d_Z = {w[0]} at L = {L}" if w[0] == 4*L*L else
      f"  lightest: {w[0]}  (lower bound 4L^2 = {4*L*L})", flush=True)

# --------------------------- (3) the three classes with no flat operator ---
print("\n(3) X-type classes with no flat representative (upper bounds)")
random.seed(3)
pX = pivots(HX)
roots = [tuple(r) for r in product((-1, 0, 1), repeat=4)
         if sum(map(abs, r)) == 2]
cls = lambda v: tuple(pop(v & z) % 2 for z in LZ)

flat_classes = set()
for r, s in combinations(roots, 2):
    if not (adj((0,)*4, tuple(r[i]-s[i] for i in range(4)))
            or adj((0,)*4, tuple(r[i]+s[i] for i in range(4)))):
        continue
    pts = {tuple((a*r[i] + b*s[i]) % L for i in range(4))
           for a in range(L) for b in range(L)}
    m = 0
    for fk in F:
        if all(u in pts for u in fk): m |= 1 << F[fk]
    if m and commutes(m, HZ) and reduce_(m, pX):
        flat_classes.add(cls(m))


def span(vecs):
    S = {tuple([0]*6)}
    for v in vecs:
        S |= {tuple(a ^ b for a, b in zip(x, v)) for x in S}
    return S


flat_span = span(flat_classes)
print(f"  flat classes span {len(flat_span).bit_length()-1} of 6 dimensions")


def anneal(v, moves, kicks):
    best = greedy(v, moves)
    for _ in range(kicks):
        x = best
        for _ in range(random.randint(1, 3)):
            x ^= random.choice(moves)
        x = greedy(x, moves)
        if pop(x) < pop(best): best = x
    return best


# one representative per new direction outside the flat span
reps, seen = [], set(flat_span)
for v in logical_reps(HZ, HX, 6):
    c = cls(v)
    if c not in seen:
        reps.append(v); seen |= {tuple(a ^ b for a, b in zip(x, c))
                                 for x in seen}
    if len(reps) == 3: break
out = []
for v in reps:
    w = anneal(v, HX, 300)
    assert commutes(w, HZ) and reduce_(w, pX) and cls(w) not in flat_span
    out.append(pop(w))
print(f"  lightest operators found in the three non-flat directions: "
      f"{sorted(out)}  (all above 2L^2 = {2*L*L}: "
      f"{all(x > 2*L*L for x in out)})")
