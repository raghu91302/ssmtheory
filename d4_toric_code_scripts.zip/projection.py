#!/usr/bin/env python3
"""Local geometry constants for the projection bound.

A nontrivial 2-cycle must project onto the whole of a coordinate 2-torus of
area L^2, so its weight is at least L^2 / A where A is the largest area any
single cell can project to.  A is a finite local quantity.
"""
from itertools import product, combinations
from fractions import Fraction

roots = [tuple(r) for r in product((-1, 0, 1), repeat=4)
         if sum(map(abs, r)) == 2]
rootset = set(roots)


def area2(a, b, i, j):
    """Twice the area of the projection of triangle (0,a,b) onto (x_i,x_j)."""
    return abs(a[i]*b[j] - a[j]*b[i])


# ---- primal faces: {v, v+r, v+s} with r, s, r-s all roots -------------------
best, witness = 0, None
faces = 0
for r, s in combinations(roots, 2):
    if tuple(r[i]-s[i] for i in range(4)) not in rootset:
        continue
    faces += 1
    for i, j in combinations(range(4), 2):
        a = area2(r, s, i, j)
        if a > best:
            best, witness = a, (r, s, (i, j))
print(f"primal face types (up to translation): {faces}")
print(f"max 2*area of a projected face: {best}  -> A = {Fraction(best,2)}")
print(f"witness: r={witness[0]} s={witness[1]} onto coords {witness[2]}")
print(f"  => d_X >= L^2 / A = {Fraction(2,best)} L^2")

# sanity: can any face pair give 2*area = 2?
print("\ncheck: root pairs with |cross| = 2 in some coordinate pair")
for r, s in combinations(roots, 2):
    if any(area2(r, s, i, j) == 2 for i, j in combinations(range(4), 2)):
        d, t = (tuple(r[i]-s[i] for i in range(4)),
                tuple(r[i]+s[i] for i in range(4)))
        if d in rootset or t in rootset:
            print(f"  FACE with area 1: {r} {s}")
            break
else:
    print("  none of them span a face (r-s and r+s are never roots)")

# ---- dual 2-cells: centres of the three 16-cells containing a face ----------
# 16-cell centres are the deep holes: odd-integer points and half-integer
# points.  A hole h is the centre of the 16-cell on the 8 lattice points at
# distance 1 from h.
def holes_containing(tri):
    out = []
    for h in cand_holes:
        if all(sum((u[i]-h[i])**2 for i in range(4)) == 1 for u in tri):
            out.append(h)
    return out


cand_holes = []
for p in product(range(-2, 3), repeat=4):                     # odd-integer
    if sum(p) % 2 == 1:
        cand_holes.append(tuple(map(Fraction, p)))
for p in product(range(-2, 3), repeat=4):                     # half-integer
    cand_holes.append(tuple(Fraction(2*x+1, 2) for x in p))

best_d, wit_d, seen = 0, None, 0
for r, s in combinations(roots, 2):
    if tuple(r[i]-s[i] for i in range(4)) not in rootset:
        continue
    tri = [(Fraction(0),)*4, tuple(map(Fraction, r)), tuple(map(Fraction, s))]
    hs = holes_containing(tri)
    if len(hs) != 3:
        print(f"  !! face {r},{s} lies in {len(hs)} 16-cells (expected 3)")
        continue
    seen += 1
    o = hs[0]
    a = tuple(hs[1][i]-o[i] for i in range(4))
    b = tuple(hs[2][i]-o[i] for i in range(4))
    for i, j in combinations(range(4), 2):
        v = abs(a[i]*b[j] - a[j]*b[i])
        if v > best_d:
            best_d, wit_d = v, (r, s, (i, j), hs)
print(f"\ndual 2-cells checked: {seen}")
print(f"max 2*area of a projected dual cell: {best_d} "
      f"-> A' = {Fraction(best_d,2) if best_d else 0}")
if best_d:
    print(f"  => d_Z >= L^2 / A' = {Fraction(2,best_d)} L^2")
    print(f"  witness face r={wit_d[0]} s={wit_d[1]} coords {wit_d[2]}")
