#!/usr/bin/env python3
"""The close-packed plane x+y+z = c (mod L), c even, in a slice x4 = 0.

Checks Theorem 3 at L = 4 and L = 6: the plane holds L^2 lattice points
forming a triangular lattice; its 2L^2 triangles are triangles of the
honeycomb, form a cycle (every edge in exactly two of them), and are not a
product of stabilizers.  Weight 2L^2 meets the lower bound of Theorem 2.
Usage: python3 planes.py L
"""
import sys
from itertools import product, combinations
from satdist import pivots, reduce_, kernel, logical_reps

L = int(sys.argv[1]) if len(sys.argv) > 1 else 4

# ---- 3D slice complex (tet-oct honeycomb) -----------------------------------
vs3 = [v for v in product(range(L), repeat=3) if sum(v) % 2 == 0]
add3 = lambda a, b: tuple((a[i]+b[i]) % L for i in range(3))
adj3 = lambda a, b: sorted(min((a[i]-b[i]) % L, (b[i]-a[i]) % L)
                           for i in range(3)) == [0, 1, 1]
NN3 = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
nb3 = {v: [add3(v, d) for d in NN3] for v in vs3}
E3, F3 = {}, {}
for v in vs3:
    for u in nb3[v]:
        k = frozenset((v, u))
        if k not in E3: E3[k] = len(E3)
for ek in list(E3):
    a, b = tuple(ek)
    for c in nb3[a]:
        if c != b and adj3(c, b):
            fk = frozenset((a, b, c))
            if fk not in F3: F3[fk] = len(F3)
nF3 = len(F3)
HZ3 = [0]*len(E3)
for fk, fi in F3.items():
    for pr in combinations(tuple(fk), 2):
        HZ3[E3[frozenset(pr)]] |= 1 << fi
st3 = []
for t in product(range(L), repeat=3):
    c = tuple(x + .5 for x in t)
    near = [v for v in vs3 if sum(min(abs(v[i]-c[i]), L-abs(v[i]-c[i]))**2
                                  for i in range(3)) < 0.751]
    r = 0
    for tri in combinations(near, 3): r |= 1 << F3[frozenset(tri)]
    st3.append(r)
for h in product(range(L), repeat=3):
    if sum(h) % 2 == 1:
        nbh = [add3(h, tuple(int(i == j)*s for j in range(3)))
               for i in range(3) for s in (1, -1)]
        r = 0
        for tri in combinations(nbh, 3):
            fk = frozenset(tri)
            if fk in F3: r |= 1 << F3[fk]
        st3.append(r)
pS3 = pivots(st3)
pop = lambda x: bin(x).count('1')

print(f"L={L}  slice complex: V={len(vs3)} E={len(E3)} F={nF3}")

# ---- close-packed planes ----------------------------------------------------
for c in range(0, L, 2):
    plane = [v for v in vs3 if sum(v) % L == c]
    tris = [fk for fk in F3 if all(sum(u) % L == c for u in fk)]
    memb = 0
    for fk in tris: memb |= 1 << F3[fk]
    is_cycle = all(pop(h & memb) % 2 == 0 for h in HZ3)
    nontriv = reduce_(memb, pS3) != 0
    print(f"  plane x+y+z={c} (mod {L}): {len(plane)} vertices, "
          f"{len(tris)} triangles   cycle={is_cycle}  nontrivial={nontriv}")

print(f"  predicted: L^2 = {L*L} vertices, 2L^2 = {2*L*L} triangles")

# are the three coordinate-type close-packed families independent?
def plane_of(normal, c):
    m = 0
    for fk in F3:
        if all(sum(n*u[i] for i, n in enumerate(normal)) % L == c for u in fk):
            m |= 1 << F3[fk]
    return m

fam = []
for normal in [(1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]:
    m = plane_of(normal, 0)
    if m:
        fam.append((normal, pop(m), reduce_(m, pS3) != 0))
print("\n  {111}-family planes through the origin:")
for nrm, w, nt in fam:
    print(f"    normal {nrm}: weight {w}, nontrivial {nt}")

aug = dict(pS3); indep = 0
for normal in [(1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]:
    m = plane_of(normal, 0)
    r = reduce_(m, aug)
    if r:
        indep += 1
        aug[r.bit_length()-1] = r
print(f"  independent logical classes spanned by close-packed planes: "
      f"{indep}  (k = {nF3 - len(pivots(HZ3)) - len(pS3)})")
