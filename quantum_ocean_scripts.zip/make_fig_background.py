"""Figure 1: the Selection-Stitch Model in brief.
(a) the 12 FCC bonds of a site; (b) the 24 D4 bonds, projected by dropping time, colored by 16-cell;
(c) verification costs C of Refs. partI/meiext against measured mass ratios m/m_e."""
import itertools, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection
plt.rcParams.update({"font.size":8,"font.family":"serif"})
BLUE="#2a6fb0"; COL={"A":"#c0392b","B":"#2a8a4a","C":"#7a4fb0"}; GREY="#9a9a9a"
R=[np.array(v) for v in itertools.product([-1,0,1],repeat=4) if sum(map(abs,v))==2]
def frame(r):
    nz=frozenset(np.nonzero(r)[0])
    return "A" if nz in ({0,1},{2,3}) else "B" if nz in ({0,2},{1,3}) else "C"
fig=plt.figure(figsize=(7.0,2.5))
ax=fig.add_subplot(1,3,1,projection="3d")
P=np.array([r[1:] for r in R if r[0]==0],float)
segs=[[P[i],P[j]] for i,j in itertools.combinations(range(12),2) if np.isclose(np.linalg.norm(P[i]-P[j]),np.sqrt(2))]
ax.add_collection3d(Line3DCollection(segs,colors=GREY,linewidths=0.5))
for p in P: ax.plot([0,p[0]],[0,p[1]],[0,p[2]],color=BLUE,lw=0.9)
ax.scatter(*P.T,color=BLUE,s=10,depthshade=False); ax.scatter([0],[0],[0],color="k",s=14)
ax.set_title("(a) FCC: 12 neighbors",fontsize=8)
bx=fig.add_subplot(1,3,2,projection="3d")
for r in R:
    p=r[1:].astype(float); c=COL[frame(r)]
    bx.plot([0,p[0]],[0,p[1]],[0,p[2]],color=c,lw=0.9,ls="-" if r[0]==0 else "--")
    bx.scatter(*p,color=c,s=10 if r[0]==0 else 16,marker="o" if r[0]==0 else "s",depthshade=False)
bx.scatter([0],[0],[0],color="k",s=14)
bx.set_title("(b) $D_4$: 24 neighbors, three 16-cells",fontsize=8)
for a in (ax,bx):
    a.set_box_aspect((1,1,1)); a.set_axis_off(); a.view_init(18,32)
    a.set_xlim(-1.1,1.1); a.set_ylim(-1.1,1.1); a.set_zlim(-1.1,1.1)
cx=fig.add_subplot(1,3,3)
data=[("$e$",1,1.0),(r"$\mu$",207,206.768),(r"$\pi^\pm$",273,273.132),("$p$",1836,1836.153),("$n$",1839,1838.684),
      (r"$\tau$",3447,3477.23),("$H$",244944,245010)]
C=np.array([d[1] for d in data],float); M=np.array([d[2] for d in data])
xs=np.logspace(-0.2,5.6,10); cx.plot(xs,xs,color=GREY,lw=0.7)
cx.scatter(C,M,color=BLUE,s=14,zorder=3)
off={"$e$":(5,-3),r"$\mu$":(-14,2),r"$\pi^\pm$":(5,-9),"$p$":(-22,2),"$n$":(5,-10),r"$\tau$":(5,-3),"$H$":(-12,-3)}
lab={"$p$":"$p,n$"}
for (n,c,m) in data:
    if n=="$n$": continue
    cx.annotate(lab.get(n,n),(c,m),textcoords="offset points",xytext=off[n],fontsize=7)
cx.set_xscale("log"); cx.set_yscale("log"); cx.set_xlabel("verification cost $C$"); cx.set_ylabel("measured $m/m_e$")
cx.set_title("(c) costs and masses",fontsize=8)
fig.tight_layout(w_pad=0.4)
fig.savefig("fig_background.pdf",bbox_inches="tight"); fig.savefig("fig_background.png",dpi=160,bbox_inches="tight")
print("max |C/m - 1| for e..n:", max(abs(c/m-1) for _,c,m in data[:5]))
