#!/usr/bin/env python3
"""Steady-state correction effort of a zero-temperature bath on MEI's vertex-plaquette code, 13-node cluster.
A persistent (logical) defect keeps its sector checks engaged; each engaged check fires at rate 1 and proposes
corrections.  The effort per unit time depends on which bonds a firing can act on:
  local      : a check acts only on its own bonds inside the footprint -> effort = sum of incidences
  collective : a check acts on every bond of the defect's footprint     -> effort = E_s x (number of sector checks)
MEI's cost C = E_s x C_s - shedding is the collective form.  Which one reproduces the measured mass ratios?"""
import numpy as np
from itertools import product, combinations
V = [np.zeros(3, int)] + [np.array(v) for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]   # 13 nodes
n = len(V); d2 = lambda a, b: int((V[a]-V[b]) @ (V[a]-V[b]))
E = [(a, b) for a, b in combinations(range(n), 2) if d2(a, b) == 2]
tri = [t for t in combinations(range(n), 3) if all(d2(a, b) == 2 for a, b in combinations(t, 2))]
sq = []
for a, c in combinations(range(n), 2):
    if d2(a, c) != 4: continue
    com = [b for b in range(n) if d2(a, b) == 2 and d2(c, b) == 2]
    for b, dd in combinations(com, 2):
        if d2(b, dd) == 4 and np.linalg.matrix_rank(np.array([V[a], V[b], V[c], V[dd]]) - V[a]) == 2:
            s = frozenset((a, b, c, dd))
            if s not in sq: sq.append(s)
Es = len(E)
inc_vert = sum(sum(1 for e in E if v in e) for v in range(n))            # each vertex check on its bonds in the footprint
inc_tri, inc_sq = 3*len(tri), 4*len(sq)
print(f"13-node cluster: E_s = {Es} bonds, {n} vertex checks, {len(tri)} triangle checks, {len(sq)} square checks")
rows = [("muon (sector: squares; shed D^2 = 9)", len(sq), inc_sq, 9, 206.768),
        ("proton (sector: vertices + triangles + squares)", n+len(tri)+len(sq), inc_vert+inc_tri+inc_sq, 0, 1836.153)]
print(f"\n{'defect':48s} {'local effort':>12s} {'collective E_s x C_s':>21s} {'measured m/m_e':>15s}")
for name, Cs, inc, shed, meas in rows:
    print(f"{name:48s} {inc-shed:12d} {Es*Cs-shed:21d} {meas:15.3f}")
mu_l, p_l = inc_sq-9, inc_vert+inc_tri+inc_sq
print(f"\nproton/muon ratio: local {p_l/mu_l:.2f}, collective {(Es*51)/(Es*6-9):.2f}, measured {1836.153/206.768:.2f}")
print("electron: one bond, existence check only -> local = collective = 1")
