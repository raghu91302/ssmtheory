#!/usr/bin/env python3
"""Figures for the quantum-ocean paper."""
import itertools as it, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 9, "font.family": "serif", "mathtext.fontset": "dejavuserif"})
BLUE, GOLD, RED, PURPLE, GREY = "#2c5f9e", "#b7791f", "#c14844", "#6e4694", "#8796ad"

# ---------- Figure 1: one FCC site and its voids; slice fractions ----------
fig = plt.figure(figsize=(7.0, 3.2))
ax = fig.add_subplot(1, 2, 1, projection="3d")
nn = [np.array(v) for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
for v in nn:
    ax.plot([0, v[0]], [0, v[1]], [0, v[2]], color=GREY, lw=0.6, alpha=0.7)
for a_, b_ in it.combinations(nn, 2):
    if np.isclose(np.linalg.norm(a_ - b_), np.sqrt(2)):
        ax.plot(*zip(a_, b_), color=GREY, lw=0.35, alpha=0.45)
P = np.array(nn); ax.scatter(P[:, 0], P[:, 1], P[:, 2], s=9, color=BLUE, depthshade=False)
ax.scatter([0], [0], [0], s=14, color="black", depthshade=False)
octs = np.array([v for v in it.product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 1])
ax.scatter(octs[:, 0], octs[:, 1], octs[:, 2], s=26, marker="o", facecolor="none", edgecolor=GOLD, lw=1.2, depthshade=False)
tets = np.array(list(it.product((-.5, .5), repeat=3)))
up = np.prod(np.sign(tets), axis=1) > 0
ax.scatter(*tets[up].T, s=26, marker="^", color=RED, depthshade=False)
ax.scatter(*tets[~up].T, s=26, marker="v", color=PURPLE, depthshade=False)
ax.set_box_aspect((1, 1, 1)); ax.set_axis_off(); ax.view_init(elev=18, azim=32)
ax.set_title("(a) one FCC site and its 14 voids", fontsize=9)
from matplotlib.lines import Line2D
h = [Line2D([], [], marker="o", ls="", mfc="none", mec=GOLD, label="octahedral void: class V (6)"),
     Line2D([], [], marker="^", ls="", color=RED, label=r"up tetrahedron: $S_+$ to the future (4)"),
     Line2D([], [], marker="v", ls="", color=PURPLE, label=r"down tetrahedron: $S_-$ to the future (4)")]
ax.legend(handles=h, loc="lower center", bbox_to_anchor=(0.5, -0.14), fontsize=7, frameon=False)
ax2 = fig.add_subplot(1, 2, 2)
t = np.linspace(0, 2, 401); tt = t % 1
fV = 2 / 3 * ((1 - tt) ** 3 + tt ** 3)
ax2.plot(t, fV, color=GOLD, lw=1.6, label=r"$f_V(t)$: class $V$ (octahedral voids)")
ax2.plot(t, 1 - fV, color=RED, lw=1.6, label=r"$f_{S_+}+f_{S_-}$: spinor classes")
ax2.axhline(1 / 3, color="k", lw=0.7, ls="--"); ax2.text(1.98, 0.345, "time average 1/3", ha="right", fontsize=7)
ax2.axhline(2 / 3, color="k", lw=0.4, ls=":")
ax2.set_xlabel(r"slice time $t$ (lattice units)"); ax2.set_ylabel("fraction of the slice")
ax2.set_ylim(0, 1.18); ax2.set_xlim(0, 2); ax2.set_yticks([0, 1/6, 1/3, 0.5, 2/3, 5/6, 1]); ax2.set_yticklabels(["0", "1/6", "1/3", "1/2", "2/3", "5/6", "1"]); ax2.set_title("(b) slice fractions of the hole classes", fontsize=9)
ax2.legend(fontsize=7, loc="upper center", frameon=False, bbox_to_anchor=(0.5, 1.0))
fig.tight_layout(); fig.savefig("fig_voids.pdf", bbox_inches="tight"); fig.savefig("fig_voids.png", dpi=160, bbox_inches="tight")

# ---------- Figure 2: bath erasure and crowding interaction ----------
nbr = np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)])
rng = np.random.default_rng(1); M, steps = 20000, 20000
r = np.tile([1, 1, 0], (M, 1)); alive = np.ones(M, bool); frac = []
for s in range(1, steps + 1):
    r[alive] += nbr[rng.integers(12, size=M)][alive]
    alive &= r.any(axis=1); frac.append(1 - alive.mean())
fig, (b1, b2) = plt.subplots(1, 2, figsize=(7.0, 2.7))
b1.semilogx(np.arange(1, steps + 1), frac, color=BLUE, lw=1.2, label="simulation (20000 runs)")
b1.axhline(0.256318, color=RED, ls="--", lw=0.9, label="Pólya return probability 0.2563")
b1.set_xlabel("correction attempts"); b1.set_ylabel("fraction of flips erased"); b1.set_ylim(0, 0.3)
b1.legend(fontsize=7, frameon=False, loc="lower right"); b1.set_title("(a) a flipped bond in a zero-temperature ocean", fontsize=9)
Nk = 160; q = (np.arange(Nk) + .5) * 2 * np.pi / Nk - np.pi
KX, KY, KZ = np.meshgrid(q, q, q, indexing="ij")
inv = 1 / (12 - 4 * (np.cos(KX) * np.cos(KY) + np.cos(KY) * np.cos(KZ) + np.cos(KZ) * np.cos(KX)))
ks = np.arange(0, 13); g = np.array([np.mean(np.cos(k * KX + k * KY) * inv) for k in ks])
m = ks >= 4; A = np.column_stack([1 / ks[m], np.ones(m.sum())]); c, sh = np.linalg.lstsq(A, g[m], rcond=None)[0]
b2.plot(ks[1:], ks[1:] * (g[1:] - sh), "o", color=BLUE, ms=4, label=r"lattice: $r\,G_L(r)$")
b2.axhline(1 / (8 * np.sqrt(2) * np.pi), color=RED, ls="--", lw=0.9, label=r"Newtonian $1/(8\sqrt{2}\pi)$")
b2.set_xlabel("separation $r$ (bonds)"); b2.set_ylabel(r"$r\,G_L(r)$"); b2.set_ylim(0.026, 0.030)
b2.legend(fontsize=7, frameon=False); b2.set_title("(b) crowding interaction falls as $1/r$", fontsize=9)
fig.tight_layout(); fig.savefig("fig_bath_gravity.pdf", bbox_inches="tight"); fig.savefig("fig_bath_gravity.png", dpi=160, bbox_inches="tight")
print("figures written")
