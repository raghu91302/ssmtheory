#!/usr/bin/env python3
"""Crowding of the ocean around defects (Section 8).
Energy of the crowding field n on the FCC bond graph:  E[n] = (kappa/2) sum_bonds (n_i - n_j)^2 - eps sum_k C_k n(x_k).
Minimum: kappa L n = eps b  (L = graph Laplacian),  E_min = -(eps^2 / 2 kappa) b^T L^{-1} b.
Two defects:  E_int = -(eps^2/kappa) C1 C2 G_L(r):  attractive, bilinear in the costs, and G_L(r) -> a/(8 sqrt2 pi r).
Self energy: -(eps^2 / 2 kappa) C^2 G_L(0),  G_L(0) = u/12 with u Watson's FCC integral.
Also: the MICROSCOPE bound on an anomalous gravitational coupling of electrons."""
import numpy as np, itertools as it
import scipy.sparse as sp, scipy.sparse.linalg as spl
Lbox = 36                                                   # integer coordinates, nn distance sqrt2 (a = sqrt2)
sites = [p for p in it.product(range(-Lbox//2, Lbox//2 + 1), repeat=3) if sum(p) % 2 == 0]
idx = {p: i for i, p in enumerate(sites)}
nbr = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
rows, cols = [], []
for p, i in idx.items():
    for d in nbr:
        q = (p[0]+d[0], p[1]+d[1], p[2]+d[2])
        if q in idx: rows.append(i); cols.append(idx[q])
n = len(sites)
A = sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n))
Lap = sp.diags(np.full(n, 12.0)) - A                         # Dirichlet: missing neighbours outside count as n = 0
o = idx[(0, 0, 0)]
e = np.zeros(n); e[o] = 1
G = spl.spsolve(Lap.tocsc(), e)                              # column of L^{-1}
a = np.sqrt(2)
print(f"FCC box with {n} sites (Dirichlet walls at distance {Lbox//2})")
print(f"  G_L(0) = {G[o]:.4f}  (infinite lattice u/12 = {1.344661/12:.4f}; walls lower it slightly)")
print("  infinite-lattice Green function from its Fourier integral (midpoint grid 160^3, cube [-pi,pi]^3):")
Nk = 160
q = (np.arange(Nk) + .5) * 2 * np.pi / Nk - np.pi
KX, KY, KZ = np.meshgrid(q, q, q, indexing='ij')
lam = 12 - 2 * (np.cos(KX) * np.cos(KY) + np.cos(KY) * np.cos(KZ) + np.cos(KZ) * np.cos(KX)) * 2
inv = 1.0 / lam
rs, gs = [], []
for k in (0, 1, 2, 3, 4, 6, 8, 10, 12):
    rs.append(k * np.sqrt(2) / a); gs.append(np.mean(np.cos(k * KX + k * KY) * inv))
rs, gs = np.array(rs), np.array(gs)
# the midpoint grid misses the k ~ 0 neighbourhood, which shifts G by a constant; fit G = c/r + const on r >= 4
m = rs >= 4
c_fit, shift = np.linalg.lstsq(np.column_stack([1 / rs[m], np.ones(m.sum())]), gs[m], rcond=None)[0]
print(f"  G_L(0) = {gs[0] - shift:.4f} (shift-corrected; u/12 = {1.344661/12:.4f})")
print(f"  fit G(r) = c/r + const for r = 4..12 bonds: c = {c_fit:.5f}  vs continuum 1/(8 sqrt2 pi) = {1/(8*np.sqrt(2)*np.pi):.5f}")
print("  r [bonds]   r*(G(r) - const)")
for rr, g in zip(rs[1:], gs[1:]): print(f"  {rr:8.2f}    {rr * (g - shift):.5f}")
# bilinearity and sign: energy of two sources at separation 4 bonds, for several cost pairs
p2 = idx[(4, 4, 0)]
for C1, C2 in [(1, 1), (1, 207), (207, 1836), (1836, 1836)]:
    b = np.zeros(n); b[o] = C1; b[p2] = C2
    nfield = spl.spsolve(Lap.tocsc(), b)
    E_two = -0.5 * b @ nfield
    b1 = np.zeros(n); b1[o] = C1; b2 = np.zeros(n); b2[p2] = C2
    E_sep = -0.5 * b1 @ spl.spsolve(Lap.tocsc(), b1) - 0.5 * b2 @ spl.spsolve(Lap.tocsc(), b2)
    print(f"  C1={C1:5d} C2={C2:5d}: E_int = {E_two - E_sep:12.4f}  (-C1 C2 G_L(r) = {-C1*C2*G[p2]:12.4f})  [box, r = 4 bonds, eps^2/kappa = 1]")
# self-energy relative to rest energy, with the Newton normalisation (eps^2/kappa) a /(8 sqrt2 pi) = G m_e^2
u = 1.344661; G0a = u / 12                                   # G_L(0) is dimensionless (lattice Kronecker normalisation)
coef = 0.5 * 8 * np.sqrt(2) * np.pi * G0a                    # E_self / (C^2 G m_e^2 / a)
me_over_MP = 0.51099895e-3 / 1.220890e19
a_over_lP = np.sqrt(4 * np.log(2) / np.sqrt(2 / 3))           # bond-level Ryu-Takayanagi calibration (black-hole paper): 1.843
print(f"\nself energy: E_self = -{coef:.4f} C^2 G m_e^2 / a")
print(f"  fraction of rest energy C m_e c^2: {coef:.4f} x C x (m_e/M_Pl) x (l_P/a) = {coef/a_over_lP:.3f} x C x {me_over_MP:.3e}")
for name, C in (("electron", 1), ("muon", 207), ("proton", 1836), ("tauon", 3447), ("Higgs", 244944)):
    print(f"  {name:8s} C = {C:7d}: fractional shift {coef/a_over_lP*C*me_over_MP:.2e}")
# MICROSCOPE: Ti vs Pt, eta = (-1.5 +- 2.3 +- 1.5) e-15 (Touboul et al. 2022)
me_u = 5.48579909e-4
zA = {"Ti": 22 / 47.867, "Pt": 78 / 195.084}
dfe = (zA["Ti"] - zA["Pt"]) * me_u
eta_max = 1.5e-15 + 2 * np.hypot(2.3e-15, 1.5e-15)
print(f"\nMICROSCOPE: electron mass fraction differs by {dfe:.3e} between Ti and Pt")
print(f"  |eta| < {eta_max:.1e} (2 sigma, conservative)  ->  anomalous electron coupling |delta_e| < {eta_max/dfe:.1e}")
