"""Section 'The ocean's zero-point energy': size of the naive induced vacuum energy, and the site four-volume.
Lattice spacing a = 1.843 l_P (Eq. arealaw). Cutoff schemes as in ocean_cutoff.py: Lambda a = 4.22, 5.01, 6.61.
Naive one-loop vacuum energy per real mode: rho ~ Lambda^4/(16 pi^2). Observed: rho_Lambda^(1/4) = 2.239 meV (Planck 2018)."""
import numpy as np
lP = 1.616255e-35          # m
EP = 1.220890e28           # eV, Planck energy hbar c / l_P
a = (4*np.log(2)/np.sqrt(2/3))**0.5      # in units of l_P
print(f"a = {a:.3f} l_P")
print(f"four-volume per D4 site = a^4/2 = {a**4/2:.2f} l_P^4 ; site density 2/a^4 = {2/a**4:.4f} per l_P^4")
rho_obs = (2.239e-3)**4   # eV^4
for name, La in [("Gaussian, one mode per site",4.22),("sharp, one mode per site",5.01),("lattice propagator",6.61)]:
    Lam = La/a*EP          # eV
    rho = Lam**4/(16*np.pi**2)
    print(f"{name:30s} Lambda = {Lam:.2e} eV ; Lambda^4/16pi^2 = {rho:.2e} eV^4 ; ratio to observed = 10^{np.log10(rho/rho_obs):.1f}")
# m1 numbers quoted inline (not used in the argument)
m1 = 0.794e-3
print(f"64 m1^4 = {64*m1**4:.3e} eV^4 ; (64 m1^4)^(1/4) = {(64*m1**4)**0.25*1e3:.3f} meV vs observed 2.239 meV")

# m1 for K_nu = 1/2 from the measured splittings (global fit with first JUNO data), and the 64 m1^4 comparison
from scipy.optimize import brentq
d21, d31 = 7.530e-5, 2.521e-3
def masses(d):
    s = 1+np.cos(d+2*np.pi*np.arange(3)/3); s=np.sort(s)
    return s
def f(d):
    s=masses(d); return (s[1]**4-s[0]**4)/(s[2]**4-s[0]**4) - d21/d31
grid=np.linspace(0.01,np.pi/3-1e-6,4000); v=[f(x) for x in grid]
i=[k for k in range(len(v)-1) if v[k]*v[k+1]<0][0]
dd = brentq(f, grid[i], grid[i+1]); s = masses(dd); a2 = np.sqrt(d31/(s[2]**4-s[0]**4)); m = a2*s**2
print(f"K_nu = 1/2: m = {np.round(m*1e3,3)} meV ; m1 = {m[0]*1e3:.3f} meV (uncertainty 0.013 meV from both splittings)")
r = (64*m[0]**4)**0.25; dr = r*0.013/0.794
print(f"(64 m1^4)^(1/4) = {r*1e3:.3f} +- {dr*1e3:.3f} meV vs observed 2.239 +- 0.013 -> {(r*1e3-2.239)/np.hypot(dr*1e3,0.013):.2f} sigma")
# Monte Carlo over both splittings (dm21 = 7.530 +- 0.097e-5, dm31 = 2.521 +- 0.020e-3)
rng = np.random.default_rng(3); M1 = []
for _ in range(4000):
    d21 = rng.normal(7.530e-5, 0.097e-5); d31 = rng.normal(2.521e-3, 0.020e-3)
    v=[f(x) for x in grid]; i=[k for k in range(len(v)-1) if v[k]*v[k+1]<0][0]
    dd=brentq(f, grid[i], grid[i+1]); s=masses(dd); M1.append(np.sqrt(d31/(s[2]**4-s[0]**4))*s[0]**2)
M1=np.array(M1); R=(64*M1**4)**0.25
print(f"MC: m1 = {M1.mean()*1e3:.3f} +- {M1.std()*1e3:.3f} meV ; (64 m1^4)^(1/4) = {R.mean()*1e3:.3f} +- {R.std()*1e3:.3f} meV ; pull vs 2.239 +- 0.013: {(R.mean()*1e3-2.239)/np.hypot(R.std()*1e3,0.013):.2f} sigma")
