#!/usr/bin/env python3
"""Geometry of the quantum ocean (Sections 4-5).
D4 = integer vectors (t,x,y,z) with even coordinate sum; nearest-neighbour distance sqrt2; the t = 0 slice is FCC.
Checks:
 (a) the deep holes of D4 fall into three classes V, S+, S- (cosets), all at the covering radius 1, each the centre of a
     16-cell (8 nearest lattice points);
 (b) the Voronoi cell (24-cell) of a site has its 24 vertices at deep holes, 8 per class; in the FCC slice these are the
     6 octahedral voids + 2 holes on the site's own time axis (class V) and 8+8 holes above/below the 8 tetrahedral voids;
 (c) an FCC octahedral void is the equatorial slice of a V hole whose two remaining vertices lie at t = +-1;
     an FCC tetrahedral void is the facet shared by an S+ hole and an S- hole at t = +-1/2, and its orientation fixes
     which class lies to the future;
 (d) every FCC bond borders 2 tetrahedral and 2 octahedral voids; per site: 1 octahedral, 2 tetrahedral (1 up, 1 down);
 (e) the fraction of a time slice inside V holes is f_V(t) = (2/3)[(1-t)^3 + t^3] (0<=t<=1), time average 1/3.
"""
import itertools as it
import numpy as np
from fractions import Fraction as Fr

R = range(-4, 5)
LAT = np.array([v for v in it.product(R, repeat=4) if sum(v) % 2 == 0], float)

def nearest(p):
    d = np.linalg.norm(LAT - np.asarray(p, float), axis=1)
    m = d.min()
    return m, LAT[np.isclose(d, m)]

def hole_class(h):
    for name, rep in (("V", (1, 0, 0, 0)), ("S+", (.5, .5, .5, .5)), ("S-", (.5, .5, .5, -.5))):
        d = np.asarray(h, float) - rep
        if np.allclose(d, np.round(d)) and round(d.sum()) % 2 == 0:
            return name
    return None

print("(a) deep-hole classes")
for rep in [(1, 0, 0, 0), (.5, .5, .5, .5), (.5, .5, .5, -.5)]:
    m, nb = nearest(rep)
    print(f"  {hole_class(rep):2s} rep {rep}: distance to lattice {m:.4f}, nearest points {len(nb)}")

print("\n(b) Voronoi 24-cell of the origin: holes at distance 1")
cands = set()
for v in it.product([-1, -.5, 0, .5, 1], repeat=4):
    if np.isclose(np.linalg.norm(v), 1) and hole_class(v):
        m, _ = nearest(v)
        if np.isclose(m, 1): cands.add(v)
cands = sorted(cands)
for c in ("V", "S+", "S-"):
    group = [h for h in cands if hole_class(h) == c]
    ts = sorted({h[0] for h in group})
    print(f"  class {c}: {len(group)} holes; t-values {ts}; at t=0: {sum(1 for h in group if h[0]==0)}")
print(f"  total {len(cands)}")

print("\n(c) FCC voids lifted to D4")
m, nb = nearest((0, 1, 0, 0))
poles = [tuple(int(x) for x in v) for v in nb if v[0] != 0]
print(f"  octahedral void (x,y,z)=(1,0,0): class {hole_class((0,1,0,0))}, {len(nb)} vertices, "
      f"{int((nb[:,0]==0).sum())} in the slice, time poles {poles}")
print(f"  time axis point (1,0,0,0) is class {hole_class((1,0,0,0))}")
up_count = {"S+": 0, "S-": 0}
for c in it.product([.5, -.5], repeat=3):
    up = np.prod(np.sign(c)) > 0
    fut, past = hole_class((.5,) + c), hole_class((-.5,) + c)
    tet = {tuple(int(x) for x in v) for v in nearest((0,) + c)[1]}
    ok = all(tet <= {tuple(int(x) for x in v) for v in nearest(h)[1]} for h in [(.5,) + c, (-.5,) + c])
    print(f"  tetra void {c}: {'up  ' if up else 'down'}  future {fut}, past {past}, shared facet: {ok}")
    if up: up_count[fut] += 1
print(f"  up tetrahedra with S+ in the future: {up_count['S+']} of 4")

print("\n(d) bond sharing and voids per site")
b0, b1 = np.zeros(3), np.array([1., 1., 0.])
tets = {tuple(x) for x in (np.array(s) * .5 for s in it.product([-1, 1, 3], repeat=3))}
nt = sum(1 for t in tets if all(np.isclose(np.linalg.norm(np.array(t) - b), np.sqrt(3) / 2) for b in (b0, b1)))
octs = [o for o in it.product(range(-2, 4), repeat=3) if sum(o) % 2 == 1]
no = sum(1 for o in octs if all(np.isclose(np.linalg.norm(np.array(o) - b), 1) for b in (b0, b1)))
print(f"  bond (0,0,0)-(1,1,0) borders {nt} tetrahedral and {no} octahedral voids")
print(f"  per site: octahedral 6/6 = {Fr(6,6)}, tetrahedral 8/4 = {Fr(8,4)} (4 up and 4 down around a site -> 1 up, 1 down)")
vol_oct, vol_tet = Fr(4, 3), Fr(1, 3)           # edge sqrt2: octahedron 4/3, tetrahedron 1/3; site volume 2
print(f"  volume per site: octahedra {vol_oct}, tetrahedra 2 x {vol_tet}; total {vol_oct + 2*vol_tet} (= 1/density = 2)")

print("\n(e) slice volume fractions")
H = np.array([[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, 1, -1], [1, -1, -1, 1]]) / 2.0
def owner(p):
    best, bd = None, 9.
    base = np.floor(p)
    for off in it.product([0, 1], repeat=4):
        q = base + off
        if int(q.sum()) % 2 == 1:
            r = np.abs(p - q).sum()
            if r < bd: best, bd = "V", r
    hb = np.floor(p - .5) + .5
    for off in it.product([0, 1], repeat=4):
        q = hb + off; c = hole_class(q)
        Hc = H if c == "S+" else H @ np.diag([1, 1, 1, -1])
        r = np.abs(Hc @ (p - q)).sum()
        if r < bd: best, bd = c, r
    return best
rng = np.random.default_rng(7)
fV = lambda t: 2 / 3 * ((1 - t) ** 3 + t ** 3)
for t in (0.0, 0.125, 0.25, 0.375, 0.5):
    pts = np.column_stack([np.full(6000, t), rng.random((6000, 3)) * 2])
    own = [owner(p) for p in pts]
    print(f"  t={t:5.3f}: V {own.count('V')/len(own):.3f} (formula {fV(t):.3f})  S+ {own.count('S+')/len(own):.3f}  S- {own.count('S-')/len(own):.3f}")
avg = Fr(2, 3) * (Fr(1, 4) + Fr(1, 4))
print(f"  time average of f_V = {avg}; S+ and S- by symmetry {(1 - avg) / 2} each")
