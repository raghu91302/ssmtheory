#!/usr/bin/env python3
"""Mass as the price of protection (Section 7) and the residuals (Section 8).
Costs from the MEI papers: C = E_s x C_s - shedding.  Leverage = C / E_s (cost per footprint edge).
Residuals: can one universal self-energy correction m ~ C (1 - alpha (C - 1)) explain the deviations?"""
rows = [  # name, E_s, C_s, shed, C, measured m/m_e (MEI Extended table)
    ("electron", 1, 1, 0, 1, 1.0),
    ("muon", 36, 6, 9, 207, 206.768),
    ("proton", 36, 51, 0, 1836, 1836.153),
    ("tauon", 96, 36, 9, 3447, 3477.23),
]
print(f"{'':9s} {'E_s':>4s} {'C_s':>4s} {'shed':>5s} {'C':>6s} {'C/E_s':>7s} {'measured':>10s} {'C/meas-1':>10s}")
for n, Es, Cs, sh, C, m in rows:
    assert Es * Cs - sh == C
    print(f"{n:9s} {Es:4d} {Cs:4d} {sh:5d} {C:6d} {C/Es:7.2f} {m:10.3f} {C/m-1:+10.2e}")
print("proton/muon at the same 36-edge footprint: C_s ratio 51/6 =", 51/6, "; mass ratio", round(1836.153/206.768, 3))
print("\nkissing numbers: K3 = 12 (Schutte-van der Waerden 1953), K4 = 24 (Musin 2008)")
# universal alpha: m_x/m_e = C_x (1 - alpha (C_x - 1))  =>  alpha = (1 - m/C)/(C - 1)
higgs = ("Higgs", 244944, 245010.0)
print("\nalpha needed per particle for m/m_e = C (1 - alpha (C - 1)):")
for n, C, m in [(r[0], r[4], r[5]) for r in rows[1:]] + [higgs]:
    print(f"  {n:8s} alpha = {(1 - m / C) / (C - 1):+.2e}")
print("signs and sizes disagree: no single quadratic self-energy fits the residuals")
