#!/usr/bin/env python3
"""Fix the cutoff of induced gravity from the lattice itself instead of from a mode-counting convention.
For a covariant regulator f(k^2/Lambda^2), the induced term is 1/(16 pi G) = (C/12) * I,  I = int d^4k/(2pi)^4 f/k^2,
and the two common regulators (Gaussian = heat kernel, sharp = Debye) both give I = Lambda^2/(16 pi^2);
they differ only in how Lambda is tied to the site density.
The two mode-counting schemes and the lattice-matched cutoff are compared at the end.  Matching I to the lattice's own coincident propagator
G_lat(0) removes that convention:  Lambda^2 = 16 pi^2 G_lat(0),  so  1/(16 pi G) = C G_lat(0)/12.
Area law: 1/(16 pi G) = ln2/(4 pi L^2)  ->  required C = 3 ln2 / (pi L^2 G_lat(0))."""
import numpy as np
# --- check that both regulators give the same I (numerically, Lambda = 1)
k = np.linspace(1e-6, 12, 400001); dk = k[1]-k[0]; w = 2*np.pi**2*k**3/(2*np.pi)**4      # 4D radial measure
for name, f in (("Gaussian (heat kernel)", np.exp(-k**2)), ("sharp (Debye)", (k <= 1).astype(float))):
    print(f"{name:24s} I = {np.sum(w*f/k**2)*dk*16*np.pi**2:.4f} x Lambda^2/16pi^2,  mode density = {np.sum(w*f)*dk*16*np.pi**2:.4f} x Lambda^4/16pi^2")
# --- lattice coincident propagator on D4 (integer coordinates, nn vectors +-e_i+-e_j, length sqrt2 = L)
N = 40
q = 2*np.pi*(np.arange(N)+0.5)/N - np.pi                    # midpoint grid avoids k = 0
K = np.meshgrid(q, q, q, q, indexing='ij')
lam = np.zeros_like(K[0])
for i in range(4):
    for j in range(i+1, 4):
        for s in (1, -1):
            lam += 2*(1 - np.cos(K[i] + s*K[j]))           # +-(e_i + s e_j): 2 vectors each
lam /= 6.0                                                   # lambda ~ k^2 at small k
G0 = 0.5*np.mean(1/lam)                                      # (1/2)(1/(2pi)^4) int over the Z^4 cube; = int over D4 BZ
L2 = 2.0
print(f"\nD4 lattice: G_lat(0) * L^2 = {G0*L2:.4f}   (grid {N}^4; converges slowly at the k=0 point)")
Lam_L = np.sqrt(16*np.pi**2*G0*L2)
print(f"lattice-matched cutoff: Lambda L = {Lam_L:.3f}")
Creq = 3*np.log(2)/(np.pi*G0*L2*np.sqrt(2/3))
print(f"required C for the area-law G with the lattice-matched cutoff: {Creq:.2f}")

# --- the three ways of tying the cutoff to the lattice, and the C each requires for the area-law G
# calibration: one ebit per (111) bilayer cell of area sqrt(2/3) a^2 obeys S = A/4G  ->  G = sqrt(2/3) a^2/(4 ln2)
# induced:  1/(16 pi G) = (C/12) * Lambda^2/(16 pi^2)   ->   C_req = 48 pi ln2 / (sqrt(2/3) (Lambda a)^2)
# one mode per D4 site: site density = 2/a^4 (a = nn spacing)
dens = 2.0                                                    # per a^4
schemes = {"one mode per site, Gaussian (heat kernel): Lambda^4/(16 pi^2) = density": (16*np.pi**2*dens)**0.25,
           "one mode per site, sharp (Debye): Lambda^4/(32 pi^2) = density": (32*np.pi**2*dens)**0.25,
           "matched to the D4 lattice propagator": Lam_L}
print("\nscheme                                                          Lambda a   required C")
for k, v in schemes.items():
    print(f"{k:64s} {v:7.3f}   {48*np.pi*np.log(2)/(np.sqrt(2/3)*v**2):6.2f}")
# the induced-gravity count for the Standard Model with right-handed neutrinos
Ns, xi, NW, ND, NV = 4, 0, 48, 0, 12
print(f"\nC = Ns(1-6xi) + N_Weyl + 2 N_Dirac - 4 N_V = {Ns*(1-6*xi) + NW + 2*ND - 4*NV}  (4 real scalars, 48 Weyl, 12 vectors)")
