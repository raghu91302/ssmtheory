#!/usr/bin/env python3
"""The ocean across phases (Section 6.3).
Same zero-temperature vertex-check ocean as ocean_bath.py, on each lattice.  A flipped bond's two failing checks
perform the lattice's random walk; the flip is erased iff the walk returns, so the persistent fraction is 1/u,
u = (1/(2pi)^d) int dk / (1 - phi(k)), phi = mean of cos(k.delta) over the K bond vectors (Watson-type integrals).
2D triangular sheets (K=6): recurrent (Polya), every flip is erased.  Diamond (K=4, a stand-in for the tetrahedral
foam, which is not a lattice) is not Bravais: simulated directly."""
import numpy as np, itertools as it
def u_integral(vecs, dim, N):
    q = (np.arange(N) + .5) * 2 * np.pi / N - np.pi
    K = np.meshgrid(*([q] * dim), indexing='ij')
    phi = sum(np.cos(sum(v[i] * K[i] for i in range(dim))) for v in vecs) / len(vecs)
    return np.mean(1 / (1 - phi))
def lat(dim, cond): return [v for v in it.product(range(-2, 3), repeat=dim) if cond(v)]
lattices = [("simple cubic", lat(3, lambda v: sum(map(abs, v)) == 1), 3, (96, 160)),
            ("BCC", list(it.product([-1, 1], repeat=3)), 3, (96, 160)),
            ("FCC (vacuum slice)", lat(3, lambda v: sorted(map(abs, v)) == [0, 1, 1]), 3, (96, 160)),
            ("hypercubic Z4", lat(4, lambda v: sum(map(abs, v)) == 1), 4, (32, 48)),
            ("D4 (spacetime)", lat(4, lambda v: sorted(map(abs, v)) == [0, 0, 1, 1]), 4, (32, 48))]
print(f"{'lattice':20s} {'K':>3s} {'u':>8s} {'erased':>8s} {'persist':>8s}")
for name, vecs, dim, (N1, N2) in lattices:
    u1, u2 = u_integral(vecs, dim, N1), u_integral(vecs, dim, N2)
    p = 1 if dim == 3 else 2                       # midpoint error ~ N^-1 (3D), N^-2 (4D): Richardson extrapolation
    u = (u2 * N2**p - u1 * N1**p) / (N2**p - N1**p)
    print(f"{name:20s} {len(vecs):3d} {u:8.4f} {1-1/u:8.4f} {1/u:8.4f}")
print("literature: SC 0.3405, BCC 0.2822, FCC 0.2563, Z4 0.1932")
# diamond by simulation
dA = np.array([(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)])
rng = np.random.default_rng(3); M, steps = 40000, 40000
pos = np.tile([1, 1, 1], (M, 1)); onA = np.zeros(M, bool); alive = np.ones(M, bool)
for s in range(1, steps + 1):
    k = rng.integers(4, size=M)
    st = np.where(onA[:, None], dA[k], -dA[k])
    pos[alive] += st[alive]; onA[alive] = ~onA[alive]
    alive &= pos.any(1)
print(f"{'diamond (K=4 foam)':20s} {4:3d} {'':>8s} {1-alive.mean():8.4f} {alive.mean():8.4f}   (simulation, {steps} steps; literature 0.4423)")
print(f"{'triangular sheet':20s} {6:3d} {'inf':>8s} {1.0:8.4f} {0.0:8.4f}   (2D walks are recurrent)")
# 2D crowding: lattice Green function grows logarithmically -> no 1/r law in the sheet phase
for N in (64, 256):
    q = (np.arange(N) + .5) * 2 * np.pi / N - np.pi; KX, KY = np.meshgrid(q, q, indexing='ij')
    lam = 6 - 2 * (np.cos(KX) + np.cos(KY) + np.cos(KX + KY))
    g = [np.mean((1 - np.cos(r * KX)) / lam) for r in (1, 4, 16)]
    print(f"  triangular G(0)-G(r) at r = 1, 4, 16 (grid {N}^2): " + ", ".join(f"{x:.4f}" for x in g) + "  -> grows as log r")
