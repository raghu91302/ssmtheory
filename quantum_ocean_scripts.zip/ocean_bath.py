#!/usr/bin/env python3
"""A flipped bond in a zero-temperature correcting ocean (Section 6).
Vertex checks (a site's 12 bonds) detect bit flips; energy = number of failing checks.  Each failing check fires at
rate 1 and flips one of its 12 bonds at random, accepted only if the energy does not rise.  For one flipped bond this
is exact: a move either annihilates the two failing checks (energy -2) or carries one failure to a neighbouring site
(energy 0).  The separation of the two failures is an FCC random walk; the flip is erased when it returns to 0.
The asymptotic erased fraction is the FCC Polya return probability 1 - 1/u, u = Watson's FCC integral."""
import numpy as np
nbr = np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)])
rng = np.random.default_rng(1)
M, steps = 20000, 20000
r = np.tile([1, 1, 0], (M, 1)); alive = np.ones(M, bool); t_erase = np.full(M, np.nan)
marks = {10: None, 100: None, 1000: None, 10000: None, 20000: None}
for s in range(1, steps + 1):
    k = rng.integers(12, size=M)
    r[alive] += nbr[k[alive]]
    hit = alive & ~r.any(axis=1)
    t_erase[hit] = s / 2; alive &= ~hit
    if s in marks: marks[s] = 1 - alive.mean()
print("simulation (20000 runs):")
for s, p in marks.items(): print(f"  after {s:6d} correction attempts: erased fraction {p:.4f}")
print(f"  median erase time among erased runs: {np.nanmedian(t_erase):.2f} (units of 1/rate)")
d = np.sqrt((r[alive] ** 2).sum(1) / 2)
print(f"  survivors: median separation {np.median(d):.0f} bonds -> two isolated failing checks that never meet again")
# Watson's FCC integral u = (1/pi^3) int_0^pi int_0^pi int_0^pi dk / (1 - (cx cy + cy cz + cz cx)/3), midpoint rule
for N in (64, 128, 192):
    q = (np.arange(N) + .5) * np.pi / N
    cx = np.cos(q)[:, None, None]; cy = np.cos(q)[None, :, None]; cz = np.cos(q)[None, None, :]
    u = np.mean(1.0 / (1 - (cx * cy + cy * cz + cz * cx) / 3))
    print(f"  Watson integral, grid {N}^3: u = {u:.5f}  ->  return probability 1 - 1/u = {1 - 1/u:.5f}")
print("  literature: u = 1.344661, return probability 0.256318")
