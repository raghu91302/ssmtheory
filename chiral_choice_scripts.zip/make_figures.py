#!/usr/bin/env python3
"""Figures for 'The Growth Direction and the Chiral Choice in the E6 of the Selection–Stitch Model' (R. Kulkarni, 2026).

Every plotted number is computed by verify_chiral_choice.py, which this
script runs first. Output: vector PDFs in ./figs.
Run: python3 make_figures.py   (needs numpy, matplotlib, and a LaTeX install)
"""
import io, contextlib, runpy, os
import numpy as np
import matplotlib
matplotlib.use("pdf")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Polygon, Circle
from collections import Counter

here = os.path.dirname(os.path.abspath(__file__))
with contextlib.redirect_stdout(io.StringIO()):
    g = runpy.run_path(os.path.join(here, "verify_chiral_choice.py"))
W, F, Q, YL, beta, block, isq, isa, a = (g[k] for k in
    ("W", "F", "Q", "YL", "beta", "block", "isq", "isa", "a"))
os.makedirs(os.path.join(here, "figs"), exist_ok=True)

plt.rcParams.update({
    "text.usetex": True,
    "text.latex.preamble": r"\usepackage{amsmath,amssymb}\usepackage{lmodern}",
    "font.family": "serif", "font.size": 10,
    "axes.linewidth": 0.6, "axes.edgecolor": "#55554f",
    "xtick.color": "#55554f", "ytick.color": "#55554f",
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.03,
})
INK, MUTED, GRID = "#1f1f1c", "#6b6a63", "#d9d8d2"
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"   # validated categorical slots 1-3

def r(x): return round(float(x), 6)

# ------------------------------------------------------------ Figure: twelve roots
def fig_roots():
    fig, axes = plt.subplots(1, 2, figsize=(6.3, 2.9))
    # standard planar A2 picture: simple roots at 120 degrees
    s1 = np.array([1.0, 0.0]); s2 = np.array([-0.5, np.sqrt(3)/2])
    panels = [(axes[0], r"$\mathfrak{su}(3)_L$", a[3], a[5], r"\alpha_4", r"\alpha_6"),
              (axes[1], r"$\mathfrak{su}(3)_R$", a[2], a[4], r"\alpha_3", r"\alpha_5")]
    for ax, title, A, B, nA, nB in panels:
        roots = [(A, s1, nA), (B, s2, nB), (A+B, s1+s2, nA+"+"+nB)]
        roots += [(-x, -p, "-(" + n + ")" if "+" in n else "-" + n) for x, p, n in roots]
        hexp = [p for _, p, _ in roots]
        order = np.argsort([np.arctan2(p[1], p[0]) for p in hexp])
        ax.add_patch(Polygon([hexp[i] for i in order], closed=True, fill=False,
                             ec=GRID, lw=0.8, zorder=0))
        for x, p, n in roots:
            q = r(Q @ x)
            raise_ = abs(q - 1) < 1e-6
            ax.plot([0, p[0]], [0, p[1]], color=INK if raise_ else MUTED,
                    lw=1.4 if raise_ else 0.7, zorder=1)
            ax.add_patch(Circle(p, 0.075, fc=BLUE if raise_ else "white",
                                ec=BLUE if raise_ else MUTED, lw=1.0, zorder=3))
            off = p / np.linalg.norm(p) * 0.42
            qs = {1.0: "+1", -1.0: "-1", 0.0: "0"}[q]
            ax.text(*(p + off), r"$%s$" % n, ha="center", va="center", fontsize=8.5,
                    color=INK)
            ax.text(*(p + off + np.array([0, -0.2])), r"$Q\!\cdot\!\beta=%s$" % qs,
                    ha="center", va="center", fontsize=7.5,
                    color=BLUE if raise_ else MUTED)
        ax.plot(0, 0, "o", ms=2.5, color=INK)
        ax.set_title(title, fontsize=10.5, pad=2)
        ax.set_xlim(-1.8, 1.8); ax.set_ylim(-1.7, 1.6)
        ax.set_aspect("equal"); ax.axis("off")
    arr = FancyArrowPatch((0.455, 0.53), (0.545, 0.53), transform=fig.transFigure,
                          arrowstyle="<|-|>", mutation_scale=10, lw=1.0, color=ORANGE)
    fig.add_artist(arr)
    fig.text(0.5, 0.60, r"$F$", ha="center", fontsize=11, color=ORANGE)
    fig.text(0.5, 0.40, r"$F\alpha_4=\alpha_3$" "\n" r"$F\alpha_6=\alpha_5$", ha="center",
             va="center", fontsize=7.5, color=MUTED)
    fig.subplots_adjust(wspace=0.35)
    fig.savefig(os.path.join(here, "figs", "fig_roots.pdf"))
    plt.close(fig)

# ------------------------------------------------------------ Figure: the 27 and the hop
def fig_weights():
    T3 = lambda m: m @ beta / 2
    cnt = Counter()
    kind = {}
    for mu in W:
        b = "q" if isq(block(mu)) else ("a" if isa(block(mu)) else "s")
        k = (r(T3(mu)), r(YL @ mu)); cnt[(b,) + k] += 1
    style = {"q": (BLUE, "o", "quark block"), "a": (ORANGE, "s", "antiquark block"),
             "s": (AQUA, "D", "color-singlet block")}
    fig, axes = plt.subplots(1, 2, figsize=(6.4, 3.25), sharey=True)
    for ax in axes:
        for qv in [-1, -2/3, -1/3, 0, 1/3, 2/3, 1]:
            t = np.linspace(-0.9, 0.9, 2)
            ax.plot(t, qv - t, color=GRID, lw=0.6, zorder=0)
        ax.axhline(0, color=GRID, lw=0.5, zorder=0); ax.axvline(0, color=GRID, lw=0.5, zorder=0)
        ax.set_xlim(-0.85, 0.85); ax.set_ylim(-1.3, 1.3)
        ax.set_xticks([-0.5, 0, 0.5]); ax.set_xticklabels([r"$-\frac12$", r"$0$", r"$\frac12$"])
        ax.set_yticks([-1, -2/3, -1/3, 0, 1/3, 2/3, 1])
        ax.set_yticklabels([r"$-1$", r"$-\frac23$", r"$-\frac13$", r"$0$", r"$\frac13$",
                            r"$\frac23$", r"$1$"])
        ax.set_xlabel(r"$T_{3L}$")
        for sp in ("top", "right"): ax.spines[sp].set_visible(False)
    axes[0].set_ylabel(r"$Y_L$")
    # (a) the 27
    ax = axes[0]
    for b in "qas":
        col, mk, lab = style[b]
        pts = [(k[1], k[2], v) for k, v in cnt.items() if k[0] == b]
        ax.scatter([p[0] for p in pts], [p[1] for p in pts], s=34, marker=mk, c=col,
                   edgecolors="white", linewidths=0.8, zorder=3, label=lab)
        for x, y, v in pts:
            ax.text(x + 0.07, y + 0.035, r"$%d$" % v, fontsize=7, color=MUTED, va="bottom")
    ax.text(-0.83, 1.22, r"(a) the $\mathbf{27}$ under $Y_L$", fontsize=9, color=INK, va="top")
    ax.text(0.83, -1.02, r"gray lines: constant $Q$", fontsize=7, color=MUTED, ha="right")
    leg = ax.legend(loc="lower left", fontsize=7.5, frameon=False, handletextpad=0.3,
                    borderaxespad=0.1)
    # (b) the hop: weights mu (open) and F mu (filled), for u, d, e, nu
    ax = axes[1]
    tags = {}
    for mu in W:
        b = block(mu)
        q, t, y = r(Q @ mu), r(T3(mu)), r(YL @ mu)
        if isq(b) and abs(t) > 0.1:
            tags[("u_L" if q > 0 else "d_L")] = mu
        if b[0] == "1" and abs(y + 0.5) < 1e-6:
            fy = r(YL @ (F @ mu))
            if q < 0 and abs(fy + 1) < 1e-6: tags["e_L"] = mu
            if q == 0 and abs(fy) < 1e-6: tags["nu_L"] = mu
    names = {"u_L": ("u_L", "u_R"), "d_L": ("d_L", "d_R"), "e_L": ("e_L", "e_R"),
             "nu_L": (r"\nu_L", r"S")}
    cols = {"u_L": BLUE, "d_L": BLUE, "e_L": AQUA, "nu_L": AQUA}
    for k, mu in tags.items():
        p0 = np.array([r(T3(mu)), r(YL @ mu)]); p1 = np.array([r(T3(F @ mu)), r(YL @ (F @ mu))])
        ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=8, lw=1.0,
                                     color=INK, shrinkA=5, shrinkB=5, zorder=2))
        ax.scatter(*p0, s=34, marker="o", facecolors="white", edgecolors=cols[k],
                   linewidths=1.2, zorder=3)
        ax.scatter(*p1, s=34, marker="o", c=cols[k], edgecolors="white", linewidths=0.8,
                   zorder=3)
        n0, n1 = names[k]
        dx0 = 0.07 if p0[0] >= 0 else -0.07
        ax.text(p0[0] + dx0, p0[1] - 0.02, r"$%s$" % n0, fontsize=8.5,
                ha="left" if dx0 > 0 else "right", va="top", color=INK)
        ax.text(p1[0] + 0.07, p1[1], r"$%s$" % n1, fontsize=8.5, ha="left", va="center",
                color=INK)
    ax.text(-0.83, 1.22, r"(b) a hop applies $F$", fontsize=9, color=INK, va="top")
    ax.text(0.83, 1.22, r"open: $\mu$; filled: $F\mu$", fontsize=7, color=MUTED, ha="right", va="top")
    ax.text(0.83, 1.08, r"arrows run along constant $Q$", fontsize=7, color=MUTED, ha="right", va="top")
    fig.subplots_adjust(wspace=0.12)
    fig.savefig(os.path.join(here, "figs", "fig_weights.pdf"))
    plt.close(fig)

# ------------------------------------------------------------ Figure: voids and growth direction
def fig_voids():
    fig, axes = plt.subplots(1, 2, figsize=(6.0, 2.5))
    h = 1.0
    for ax, sgn, title in [(axes[0], +1, r"(a) growth up"), (axes[1], -1, r"(b) growth reversed")]:
        for y in (0, h):
            ax.plot([-0.2, 4.6], [y, y], color=GRID, lw=0.8, zorder=0)
        ax.text(4.7, 0, r"sheet A", fontsize=7.5, color=MUTED, va="center")
        ax.text(4.7, h, r"sheet B", fontsize=7.5, color=MUTED, va="center")
        # void 1: three vertices in A (base), one in B (apex)
        base1 = [(0.2, 0), (1.0, 0), (1.8, 0)]; apex1 = (1.0, h)
        # void 2: one vertex in A (apex), three in B (base)
        base2 = [(2.6, h), (3.4, h), (4.2, h)]; apex2 = (3.4, 0)
        for base, apex in [(base1, apex1), (base2, apex2)]:
            ax.add_patch(Polygon([base[0], apex, base[2]], closed=True, fc="#eef3fb",
                                 ec=MUTED, lw=0.8, zorder=1))
            ax.plot([base[1][0], apex[0]], [base[1][1], apex[1]], color=MUTED, lw=0.6,
                    ls=(0, (2, 2)), zorder=1)
            for p in base + [apex]:
                ax.add_patch(Circle(p, 0.11, fc="white", ec=INK, lw=0.9, zorder=3))
        up1 = sgn > 0
        lab1 = "up" if up1 else "down"; lab2 = "down" if up1 else "up"
        c1 = BLUE if up1 else ORANGE; c2 = ORANGE if up1 else BLUE
        ax.text(1.0, -0.3, r"\textbf{%s}" % lab1, ha="center", va="center", fontsize=8.5, color=c1)
        ax.text(3.4, -0.3, r"\textbf{%s}" % lab2, ha="center", va="center", fontsize=8.5, color=c2)
        y0, y1 = (-0.15, 1.15) if sgn > 0 else (1.15, -0.15)
        ax.add_patch(FancyArrowPatch((-0.75, y0), (-0.75, y1), arrowstyle="-|>",
                                     mutation_scale=11, lw=1.3, color=INK))
        ax.text(-1.05, 0.5 * h, r"growth", rotation=90, ha="center", va="center",
                fontsize=8, color=INK)
        ax.set_title(title, fontsize=9.5, pad=3)
        ax.set_xlim(-1.3, 5.5); ax.set_ylim(-0.5, 1.45)
        ax.set_aspect("equal"); ax.axis("off")
    fig.subplots_adjust(wspace=0.08)
    fig.savefig(os.path.join(here, "figs", "fig_voids.pdf"))
    plt.close(fig)

fig_roots(); fig_weights(); fig_voids()
print("wrote figs/fig_roots.pdf, figs/fig_weights.pdf, figs/fig_voids.pdf")
