#!/usr/bin/env python3
"""Checks for 'The Growth Direction Is the Chiral Bit: Hypercharge and the
Left Factor in the E6 of the Selection-Stitch Model' (R. Kulkarni, 2026).

Builds the 72-root E6 of the orientation unfold exactly as in the published
construction (Symmetry 18, 1813, 2026), identifies color and the swapped pair,
and verifies every numbered claim of the paper.
Run: python3 verify_chiral_choice.py   (numpy only; a few seconds)
"""
import numpy as np, itertools
from collections import Counter

ok = True
def check(name, cond):
    global ok
    ok &= bool(cond)
    print(("PASS  " if cond else "FAIL  ") + name)

# ---------------------------------------------------------------- E6 roots
longr = []
for i, j in itertools.combinations(range(4), 2):
    for si, sj in [(1, 1), (1, -1), (-1, 1), (-1, -1)]:
        v = np.zeros(4); v[i] = si; v[j] = sj; longr.append(v)
shortr = [s*np.eye(4)[i] for i in range(4) for s in (1, -1)] + \
         [np.array(s)/2. for s in itertools.product([1, -1], repeat=4)]
def cls(w):                       # glue class of a short weight: 0=[v], 1=[s], 2=[c]
    w = np.array(w)
    if abs(abs(w).max()-1) < 1e-9: return 0
    return 1 if np.prod(np.sign(w)) > 0 else 2
v3 = [np.array([np.cos(2*np.pi*k/3), np.sin(2*np.pi*k/3)]) for k in range(3)]
def unfold(orient_sign=1):
    R = [np.concatenate([l, [0, 0]]) for l in longr]
    for s in shortr:
        for eps in (1, -1):
            R.append(np.concatenate([s, orient_sign*eps*v3[cls(s)]]))
    return np.array(R)
R = unfold()
key = lambda x: tuple(np.round(x, 9))
Rset = {key(r) for r in R}
refl = lambda a, x: x - 2*(x@a)/(a@a)*a
F = np.diag([1, 1, 1, 1, -1, -1.])                 # orientation flip
X = np.diag([-1, -1, -1, 1, 1, -1.])               # extended inversion
check("E6: 72 roots of squared length 2, closed under reflection, rank 6",
      len(Rset) == 72 and all(abs(r@r-2) < 1e-9 for r in R) and
      all(key(refl(a, b)) in Rset for a in R for b in R) and np.linalg.matrix_rank(R) == 6)
check("F and X are automorphisms of the 72", all(key(F@r) in Rset and key(X@r) in Rset for r in R))

f = np.array([1.001, 0.618, 0.414, 0.302, 0.171, 0.093])
pos = [r for r in R if f@r > 0]; posset = {key(p) for p in pos}
simple = np.array([a for a in pos if not any(key(np.array(a)-b) in posset for b in pos if not np.allclose(a, b))])
C = np.array([[round(2*float(a@b)/float(b@b)) for b in simple] for a in simple])
theta = pos[int(np.argmax([f@p for p in pos]))]
marks = np.round(np.linalg.lstsq(simple.T, theta, rcond=None)[0]).astype(int)
check(f"simple roots as printed in the E6 paper; marks {tuple(int(m) for m in marks)}; det C = {round(np.linalg.det(C))}",
      round(np.linalg.det(C)) == 3 and tuple(marks) == (2, 3, 2, 2, 1, 1))
a = simple                                          # a[0..5] = alpha_1..alpha_6
groot = lambda p: [p[0], p[1], p[0]+p[1], -p[0], -p[1], -(p[0]+p[1])]
colr = [r for r in R if np.allclose(r[4:], 0) and any(np.allclose(r, x) for x in
        [np.array([0,1,-1,0,0,0.]), np.array([1,1,0,0,0,0.]), np.array([1,0,1,0,0,0.])]+
        [-np.array([0,1,-1,0,0,0.]), -np.array([1,1,0,0,0,0.]), -np.array([1,0,1,0,0,0.])])]
L = groot([a[3], a[5]]); Rf = groot([a[2], a[4]])
check("color = flip-fixed A2 with roots +-(e2-e3), +-(e1+e2), +-(e1+e3); L = <alpha_4, alpha_6>, R = <alpha_3, alpha_5>",
      len(colr) == 6 and all(key(F@x) == key(x) for x in colr) and
      {key(F@x) for x in L} == {key(x) for x in Rf} and
      all(abs(x@y) < 1e-9 for x in L for y in Rf+colr) and all(abs(x@y) < 1e-9 for x in Rf for y in colr))

Q = 2/3*np.array([-1, 1, 1, 0, 0, 0.])
check("Q = (2/3)(-e1+e2+e3) commutes with color, is X-odd and F-even (Theorem 7 of the E6 paper)",
      all(abs(Q@c) < 1e-9 for c in colr) and np.allclose(X@Q, -Q) and np.allclose(F@Q, Q))

# ---------------------------------------------------------------- the 27
CM = np.array([[2*float(a[i]@a[j])/float(a[j]@a[j]) for i in range(6)] for j in range(6)])
W = None
for e in range(6):
    om = np.linalg.solve(CM.T, np.eye(6)[e])@a
    orb = {key(om)}; fr = [om]
    while fr:
        new = []
        for x in fr:
            for s in a:
                y = x - round(2*float(x@s)/float(s@s))*s
                if key(y) not in orb: orb.add(key(y)); new.append(y)
        fr = new
    if len(orb) == 27:
        cand = [np.array(w) for w in orb]
        if key(np.array([-1, 0, 0, 0, 0, np.sqrt(3)/3])) in orb:      # first row of Table A3 of the E6 paper
            W = cand; break
spec = sorted(np.round([Q@w for w in W], 6)) if W else []
check("the 27 of Table A3 of the E6 paper, on which Q has the Standard Model trinification spectrum",
      W is not None and spec == sorted(np.round([2/3]*3+[-1/3]*6+[1/3]*6+[-2/3]*3+[1]*2+[0]*5+[-1]*2, 6)))
w3 = {(1, 0), (-1, 1), (0, -1)}; w3b = {(-x, -y) for x, y in w3}
lab = lambda mu, p: tuple(round(2*float(mu@s)/float(s@s)) for s in p)
rt = lambda l: '3' if l in w3 else ('3b' if l in w3b else ('1' if l == (0, 0) else '?'))
block = lambda mu: (rt(lab(mu, [np.array([0,1,-1,0,0,0.]), np.array([-1,-1,0,0,0,0.])])),
                    rt(lab(mu, [a[3], a[5]])), rt(lab(mu, [a[2], a[4]])))    # (color, L, R)
blocks = Counter(block(mu) for mu in W)
check(f"trinification blocks of the 27: {dict(blocks)}", sorted(blocks.values()) == [9, 9, 9])

# ---------------------------------------------------------------- Theorem 1: classification
orth = [r for r in R if all(abs(r@c) < 1e-9 for c in colr)]
raise_ = [r for r in orth if abs(Q@r-1) < 1e-9]
inL = lambda r: any(np.allclose(r, x) for x in L)
check(f"Thm 1: {len(orth)} roots commute with color (L and R); exactly {len(raise_)} raise Q by one unit, two in L and two in R",
      len(orth) == 12 and len(raise_) == 4 and sum(inL(r) for r in raise_) == 2)
def Y_of(beta): return Q - beta/2
check("Thm 1: for each of the four, Y = Q - T3 commutes with color and with its su(2)",
      all(all(abs(Y_of(b)@c) < 1e-9 for c in colr) and abs(Y_of(b)@b) < 1e-9 for b in raise_))
neutral = [r for r in orth if abs(Q@r) < 1e-9]
check("Thm 1: for the neutral roots (Q.beta = 0), Q - T3 fails to commute with the su(2): no hypercharge",
      len(neutral) == 4 and all(abs(Y_of(b)@b) > 0.5 for b in neutral))
bL = [r for r in raise_ if inL(r)]; bR = [r for r in raise_ if not inL(r)]
s = a[3]+a[5]
check("Thm 1: the two choices inside L are related by the Weyl reflection in alpha_4+alpha_6, which fixes Q ; likewise in R",
      abs(Q@s) < 1e-9 and any(np.allclose(refl(s, bL[0]), x) for x in bL[1:]) and
      abs(Q@(a[2]+a[4])) < 1e-9 and any(np.allclose(refl(a[2]+a[4], bR[0]), x) for x in bR[1:]))

# ---------------------------------------------------------------- Theorem 2: the spectrum of Y_L
beta = a[5]                                       # alpha_6, an L root with Q.beta = 1
YL = Y_of(beta)
T3 = lambda mu: mu@beta/2
rows = Counter((block(mu), round(Q@mu, 4), round(T3(mu), 4), round(YL@mu, 4)) for mu in W)
isq = lambda b: b[0] != '1' and b[1] != '1'      # colored and L-charged: the quark block
isa = lambda b: b[0] != '1' and b[2] != '1'      # colored and R-charged: the antiquark block
quark = [(k[1], k[2], k[3]) for k in rows for _ in range(rows[k]) if isq(k[0])]
anti = [(k[1], k[2], k[3]) for k in rows for _ in range(rows[k]) if isa(k[0])]
lept = [(k[1], k[2], k[3]) for k in rows for _ in range(rows[k]) if k[0][0] == '1']
r = lambda x: round(x, 4)
check("Thm 2 quark block: per color one weak doublet (Q = 2/3, -1/3; Y = 1/6) and one singlet (Q = -1/3, Y = -1/3)",
      Counter(quark) == Counter({(r(2/3), .5, r(1/6)): 3, (r(-1/3), -.5, r(1/6)): 3, (r(-1/3), 0, r(-1/3)): 3}))
check("Thm 2 antiquark block: weak singlets with Y = Q: -2/3 (x3) and +1/3 (x6)",
      Counter(anti) == Counter({(r(-2/3), 0, r(-2/3)): 3, (r(1/3), 0, r(1/3)): 6}))
check("Thm 2 color-singlet block: two doublets with Y = -1/2, one with Y = +1/2, and singlets with Y = +1, 0, 0",
      Counter(lept) == Counter({(0., .5, -.5): 2, (-1., -.5, -.5): 2, (1., .5, .5): 1, (0., -.5, .5): 1,
                                (1., 0., 1.): 1, (0., 0., 0.): 2}))
check("Thm 2: Q = T3 + Y_L on every state; six doublets and fifteen singlets in the 27",
      all(abs(Q@mu - T3(mu) - YL@mu) < 1e-12 for mu in W) and
      sum(1 for mu in W if abs(T3(mu)) > 0.1) == 12 and sum(1 for mu in W if abs(T3(mu)) < 0.1) == 15)
check("Thm 2: the charged weak bosons carry Q = +-1 and the neutral one Q = 0", abs(Q@beta-1) < 1e-12)
from fractions import Fraction
def exact(x, den=6):                                            # every charge here is a multiple of 1/6
    n = round(den*x); assert abs(den*x - n) < 1e-6; return Fraction(n, den)
Yx = [exact(YL@mu) for mu in W]; T3x = [exact(T3(mu)) for mu in W]
col = [block(mu)[0] != '1' for mu in W]
TrY = sum(Yx); TrY3 = sum(y**3 for y in Yx)
A3 = sum(y for y, c in zip(Yx, col) if c)/2                     # SU(3)^2 Y  (index 1/2 per triplet)
A2 = sum(t**2*y for t, y in zip(T3x, Yx))                       # SU(2)^2 Y
check(f"Prop. (anomalies of one left-handed 27, exact rational arithmetic): Tr Y = {TrY}, Tr Y^3 = {TrY3}, SU(3)^2 Y = {A3}, SU(2)^2 Y = {A2}",
      TrY == TrY3 == A3 == A2 == 0)

# ---------------------------------------------------------------- Theorem 3: the flip exchanges the two
YR = Y_of(F@beta)
check("Thm 3: F maps the L choice to an R choice (F alpha_6 raises Q by one) and Y_L to Y_R = Q - T3R",
      any(np.allclose(F@beta, x) for x in bR) and np.allclose(F@YL, YR))
W27 = {key(w) for w in W}
check("Thm 3: F maps the 27 onto the 27-bar (the set of negated weights)",
      {key(F@w) for w in W} == {key(-w) for w in W} and not ({key(F@w) for w in W} & W27))
check("Thm 3: under the right placement (T3R) the quark block carries no weak doublet and the antiquark block does (the mirror assignment)",
      all(abs(mu@(F@beta)) < 1e-9 for mu in W if isq(block(mu))) and
      sum(1 for mu in W if isa(block(mu)) and abs(mu@(F@beta)) > 0.1) == 6)
check("Thm 3: none of the four hypercharges Q - beta/2 of Thm 1 is F-invariant (F maps the L pair onto the R pair)",
      all(not np.allclose(F@Y_of(b), Y_of(b)) for b in raise_) and
      {key(F@Y_of(b)) for b in bL} == {key(Y_of(b)) for b in bR})
FX = F@X
YRp = [Y_of(b) for b in bR]
check("Sec. 5: spatial inversion acts as FX; FX maps Y_L to minus a right-placement hypercharge, so it cannot select Y_L either",
      any(np.allclose(FX@YL, -y) for y in YRp))
# hop = F on the worldline (E6 paper, Sec. 8.3): Q and color are kept; Y and T3 shift oppositely
dY = [exact(YL@(F@mu)) - exact(YL@mu) for mu in W]
dT = [exact((F@mu)@beta/2) - exact(mu@beta/2) for mu in W]
check(f"Sec. 5 (hop): F keeps Q and color on all 27 states; dT3 = -dY; dY = +-1/2 on {sum(abs(d)==Fraction(1,2) for d in dY)}, 0 on {sum(d==0 for d in dY)}, +-1 on {sum(abs(d)==1 for d in dY)} states",
      all(abs(Q@(F@mu)-Q@mu) < 1e-9 and block(mu)[0] == rt(lab(F@mu, [np.array([0,1,-1,0,0,0.]), np.array([-1,-1,0,0,0,0.])])) for mu in W) and
      all(a_ == -b_ for a_, b_ in zip(dY, dT)) and
      (sum(abs(d)==Fraction(1,2) for d in dY), sum(d==0 for d in dY), sum(abs(d)==1 for d in dY)) == (16, 9, 2))
pairs = Counter((round(Q@mu, 3), exact(YL@mu), exact(YL@(F@mu))) for mu in W if isq(block(mu)))
lep = Counter((exact(YL@mu), exact(YL@(F@mu))) for mu in W if block(mu)[0] == '1' and abs(Q@mu+1) < 1e-9)
check("Sec. 5 (hop): the quark doublet goes to Y = 2/3 (u) and -1/3 (d), the right-handed values; one charge -1 lepton goes from Y = -1/2 to -1 (e)",
      pairs[(0.667, Fraction(1,6), Fraction(2,3))] == 3 and pairs[(-0.333, Fraction(1,6), Fraction(-1,3))] == 3 and
      lep[(Fraction(-1,2), Fraction(-1))] == 1)

dYof = lambda mu: exact(YL@(F@mu)) - exact(YL@mu)
dbl = []
for mu in W:
    if block(mu)[0] == '1' and abs(T3(mu)-.5) < 1e-9 and abs(YL@mu+.5) < 1e-9:
        lo = mu - beta
        assert key(lo) in W27
        dbl.append(sorted([abs(dYof(mu)), abs(dYof(lo))]))
check(f"Sec. 5 (hop): of the two Y = -1/2 doublets, exactly one has both members shifting by 1/2 (the lepton doublet); the other shifts by 0 and 1",
      sorted(map(tuple, dbl)) == [(0, 1), (Fraction(1,2), Fraction(1,2))])

# ---------------------------------------------------------------- Theorem 4: the growth direction is F-odd
nodes = {p for p in itertools.product(range(-4, 5), repeat=3) if sum(p) % 2 == 0}
nb = [np.array(d) for d in [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]]
tets = set()
for p in [q for q in nodes if max(map(abs, q)) <= 2]:
    P = np.array(p); ns = [tuple(P+d) for d in nb if tuple(P+d) in nodes]
    for x, y, z in itertools.combinations(ns, 3):
        if all(np.dot(np.subtract(u, v), np.subtract(u, v)) == 2 for u, v in ((x, y), (x, z), (y, z))):
            tets.add(frozenset((p, x, y, z)))
def orient(T, U):   # 'up' if the apex points along the growth direction U
    h = sorted(float(np.dot(v, U)) for v in T)
    return 'up' if abs(h[0]-h[1]) < 1e-9 else 'down'    # three vertices below, apex above: up
U = np.array([1, 1, 1.])
up = Counter(orient(T, U) for T in tets)
check(f"Thm 4: with growth along [111], the tetrahedral voids split into up and down: {dict(up)}",
      up['up'] == up['down'] and up['up'] > 0)
check("Thm 4: reversing the growth direction relabels every void, up <-> down",
      all(orient(T, U) != orient(T, -U) for T in tets))
def relabel(r):     # eps -> -eps on a lifted root (s, eps v); bond roots unchanged
    return r if np.allclose(r[4:], 0) else np.concatenate([r[:4], -r[4:]])
check("Thm 4: relabeling every orientation (eps -> -eps) acts on each of the 72 roots exactly as F (immediate from the construction)",
      all(np.allclose(relabel(r), F@r) for r in R) and {key(relabel(r)) for r in R} == Rset)
check("Thm 4: hence reversing the growth direction (relabel on every root) maps Y_L to Y_R",
      np.allclose(sum(np.outer(relabel(r), r) for r in R)/24 @ YL, YR))

# ---------------------------------------------------------------- rank count
check("rank: color (2) + T3 + Y = 4 of the 6 Cartan directions; two further U(1) directions remain",
      np.linalg.matrix_rank(np.array([[0,1,-1,0,0,0.],[1,1,0,0,0,0.], beta, YL])) == 4)

print("\nVERDICT:", "ALL PASS" if ok else "FAILURES")
