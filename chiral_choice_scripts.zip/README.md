# chiral_choice_scripts

Verification script for R. Kulkarni, "The Growth Direction and the Chiral
Choice in the E6 of the Selection–Stitch Model"
(preprint, 2026).

## Run

    python3 verify_chiral_choice.py

Requires Python 3 and NumPy. It runs in a few seconds and prints one
PASS/FAIL line per check, then a verdict.

## What it checks

1. The 72-root E6 of the orientation unfold, as built in Kulkarni,
   *Symmetry* 18, 1813 (2026), https://doi.org/10.3390/sym18111813,
   with the flip F and the extended inversion X as automorphisms.
2. The simple roots, marks (2,3,2,2,1,1) and det C = 3 of that paper.
3. Color as the flip-fixed A2; su(3)_L = <alpha_4, alpha_6> (the factor
   acting on the charge-2/3 quarks) and su(3)_R = <alpha_3, alpha_5>.
4. Q = (2/3)(-e1+e2+e3) and the 27 of Table A3 of that paper.
5. Theorem 1: twelve roots commute with color; exactly four raise Q by one.
6. Theorem 2: the hypercharges Y_L = Q - T3L on the 27 (Table 1).
7. Proposition 1: the four anomaly sums, in exact rational arithmetic.
8. Theorem 3: F exchanges Y_L and Y_R and maps the weights W of the 27 onto -W
   (the 27-bar), with two worked examples (u_L to u_R, e_L to e_R);
   spatial inversion FX cannot select Y_L either.
   Proposition 2: a hop (F) keeps Q and color, and moves the quark and
   charged-lepton states to their right-handed hypercharges.
9. Theorem 4: reversing the growth direction relabels every tetrahedral
   void of an FCC patch and acts on the roots as F.
10. The rank count.

The script uses only NumPy and the Python standard library, and it reads
and writes no files.

## Figures

    python3 make_figures.py

Draws Figures 1-3 of the paper as vector PDFs in ./figs. It runs
verify_chiral_choice.py first and plots only the numbers that script
computes. Requires NumPy, Matplotlib and a LaTeX installation.
