#!/usr/bin/env python3
"""Figure: one node of the FCC lattice and its twelve nearest neighbors (a cuboctahedron).
Run: python3 make_fig_fcc.py (matplotlib, LaTeX)."""
import os, itertools, numpy as np, matplotlib
matplotlib.use("pdf")
import matplotlib.pyplot as plt
here = os.path.dirname(os.path.abspath(__file__))
plt.rcParams.update({"text.usetex": True, "text.latex.preamble": r"\usepackage{lmodern}",
                     "font.family": "serif", "font.size": 10, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
GRID, BLUE, ORANGE = "#bdbcb5", "#2a78d6", "#eb6834"
fig = plt.figure(figsize=(3.0, 3.0))
ax = fig.add_subplot(1, 1, 1, projection="3d")
nb = np.array([v for v in itertools.product([-1, 0, 1], repeat=3) if sum(abs(np.array(v))) == 2], float)
for a, b in itertools.combinations(nb, 2):
    if np.isclose(np.linalg.norm(a - b), np.sqrt(2)):
        ax.plot(*zip(a, b), color=GRID, lw=0.7)
for v in nb:
    ax.plot(*zip([0, 0, 0], v), color=BLUE, lw=0.9, alpha=0.8)
ax.scatter(*nb.T, s=34, c=BLUE, edgecolors="white", linewidths=0.6, depthshade=False)
ax.scatter([0], [0], [0], s=60, c=ORANGE, edgecolors="white", linewidths=0.6, depthshade=False)
ax.set_box_aspect((1, 1, 1)); ax.set_proj_type("ortho"); ax.view_init(elev=24, azim=-33); ax.set_axis_off()
fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
os.makedirs(os.path.join(here, "figs"), exist_ok=True)
fig.savefig(os.path.join(here, "figs", "fig_fcc.pdf"))
print("wrote figs/fig_fcc.pdf")
