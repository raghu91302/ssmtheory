#!/usr/bin/env python3
"""
entropy_complex_completion.py

Reproduces two results of "Exact Dirac-Kahler Harmonic Modes on an FCC
CSS-Code Complex" that are not covered by the other deposited scripts:

  (1) Section 4.2, geometric completion of the 2-cell structure.
      The code complex attaches only the octahedral equatorial 2-cells
      (the X-checks). Adjoining every triangle of the nearest-neighbor
      graph as an oriented 2-cell (each is a boundary, so d1 d2 = 0 is
      preserved) raises rank(d2) from L^3/2 - 1 to 158 (L=4) / 538 (L=6)
      and collapses the first Betti number to b_1 = 3, the ordinary value
      for a three-torus. The octahedral cells are then redundant: the
      triangles alone already attain the full rank.

  (2) Section 4.4, all-void curvature.
      A curvature/mass term supported on a single tetrahedral void's
      42-edge neighborhood lifts exactly 38 of the 130 harmonic modes.
      The same term supported on EVERY tetrahedral void lifts all of
      them: no exactly-harmonic one-form survives, for uniform or random
      positive per-void couplings. Each edge lies in exactly 14 void
      neighborhoods, so any everywhere-positive curvature has positive
      weight on every edge, and no harmonic mode can remain unlifted.

Requires entropy_fcc_real_harmonic.py in the same directory.
Runs in under a minute on a laptop (numpy only).
"""

import numpy as np
from itertools import combinations
from entropy_fcc_real_harmonic import build_lattice, boundary_1, boundary_2


def triangles(nodes, edges, eidx):
    """All triangles of the FCC nearest-neighbor graph, as oriented 2-cells."""
    adj = {i: set() for i in range(len(nodes))}
    for (i, j) in edges:
        adj[i].add(j)
        adj[j].add(i)
    tris = set()
    for (i, j) in edges:
        for k in adj[i] & adj[j]:
            tris.add(tuple(sorted((i, j, k))))
    tris = sorted(tris)
    d2t = np.zeros((len(edges), len(tris)))
    for t, (a, b, c) in enumerate(tris):
        # boundary of [a,b,c] = +[a,b] - [a,c] + [b,c]
        d2t[eidx[(a, b)], t] += 1.0
        d2t[eidx[(a, c)], t] -= 1.0
        d2t[eidx[(b, c)], t] += 1.0
    return tris, d2t


def void_supports(L, nodes, nidx, edges, eidx, octs):
    """The 42-edge neighborhood of each tetrahedral void."""
    def wrapd(p, q):
        d = np.abs(np.array(p, float) - np.array(q, float))
        d = np.minimum(d, L - d)
        return np.sqrt((d ** 2).sum())

    ocs, oes = [], []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x + y + z) % 2 == 1:
                    b = [nidx[p] for p in
                         [((x + 1) % L, y, z), ((x - 1) % L, y, z),
                          (x, (y + 1) % L, z), (x, (y - 1) % L, z),
                          (x, y, (z + 1) % L), (x, y, (z - 1) % L)] if p in nidx]
                    if len(b) == 6:
                        oes.append([eidx[tuple(sorted(pr))]
                                    for pr in combinations(b, 2)
                                    if tuple(sorted(pr)) in eidx])
                        ocs.append((x, y, z))

    supports = []
    for cx in np.arange(0.5, L, 1.0):
        for cy in np.arange(0.5, L, 1.0):
            for cz in np.arange(0.5, L, 1.0):
                c = (cx, cy, cz)
                bnd = [i for i, p in enumerate(nodes)
                       if abs(wrapd(c, p) - np.sqrt(3) / 2) < 1e-9]
                if len(bnd) != 4:
                    continue
                tet = [eidx[tuple(sorted(pr))] for pr in combinations(bnd, 2)
                       if tuple(sorted(pr)) in eidx]
                adj = [k for k, oc in enumerate(ocs)
                       if abs(wrapd(c, oc) - np.sqrt(3) / 2) < 1e-9]
                supports.append(sorted(set(tet) | set(e for k in adj for e in oes[k])))
    return supports


def run(L, rng=None):
    rng = rng or np.random.default_rng(0)
    nodes, nidx, edges, eidx, octs = build_lattice(L)
    d1 = boundary_1(nodes, edges).astype(float)
    d2 = boundary_2(edges, eidx, octs).astype(float)
    n = len(edges)

    # ---- (1) geometric completion
    tris, d2t = triangles(nodes, edges, eidx)
    assert np.abs(d1 @ d2t).max() < 1e-12, "triangles are not cycles"
    r1 = np.linalg.matrix_rank(d1, tol=1e-9)
    r2_code = np.linalg.matrix_rank(d2, tol=1e-9)
    r2_tri = np.linalg.matrix_rank(d2t, tol=1e-9)
    r2_full = np.linalg.matrix_rank(np.hstack([d2, d2t]), tol=1e-9)
    print(f"L={L}: edges={n}, octahedral 2-cells={d2.shape[1]}, triangles={len(tris)}")
    print(f"   code complex   : rank d2={r2_code:4d}  b_1={n - r1 - r2_code}"
          f"   (= 2L^3+2 = {2 * L ** 3 + 2})")
    print(f"   triangles only : rank d2={r2_tri:4d}  b_1={n - r1 - r2_tri}")
    print(f"   full geometric : rank d2={r2_full:4d}  b_1={n - r1 - r2_full}   (3-torus: 3)")
    print(f"   octahedra redundant given triangles: {r2_full == r2_tri}")

    # ---- (2) all-void curvature
    L1 = d1.T @ d1 + d2 @ d2.T
    b1 = int((np.linalg.eigvalsh(L1) < 1e-8).sum())
    sup = void_supports(L, nodes, nidx, edges, eidx, octs)
    cov = np.zeros(n)
    for S in sup:
        for e in S:
            cov[e] += 1
    one = np.zeros(n)
    for e in sup[0]:
        one[e] = 1.0
    lifted_one = b1 - int((np.linalg.eigvalsh(L1 + 0.1 * np.diag(one)) < 1e-8).sum())
    uni = np.zeros(n)
    for S in sup:
        for e in S:
            uni[e] += 1.0
    surv_uni = int((np.linalg.eigvalsh(L1 + 0.01 * np.diag(uni)) < 1e-8).sum())
    rnd = np.zeros(n)
    for S in sup:
        lam = rng.uniform(0.005, 0.05)
        for e in S:
            rnd[e] += lam
    surv_rnd = int((np.linalg.eigvalsh(L1 + np.diag(rnd)) < 1e-8).sum())
    print(f"   harmonic modes b_1={b1}; one-void lift removes {lifted_one}"
          f" (leaves {b1 - lifted_one})")
    print(f"   edge covering multiplicity: min={cov.min():.0f} max={cov.max():.0f}")
    print(f"   all-void uniform curvature : survivors={surv_uni}")
    print(f"   all-void random curvature  : survivors={surv_rnd}")
    print()


if __name__ == "__main__":
    for L in (4, 6):
        run(L)
