#!/usr/bin/env python3
"""
Reading C: label-only, incompatible.  All bonds carry the label L0, including
the four spokes from the trapped node to the void's vertices.  Curvature =
3D Regge deficit on edges, summed over the cells (tetrahedra, octahedra)
meeting each edge, with dihedral angles computed from the labels alone.
"""
import numpy as np
def dihedral_tet(l):
    """Dihedral angle at edge 01 of a tetrahedron with squared lengths dict l[(i,j)]."""
    # use vectors from an embedding of the single tet (always exists for admissible labels)
    L=lambda i,j: np.sqrt(l[tuple(sorted((i,j)))])
    a=L(0,1); p=np.array([0,0,0.]); q=np.array([a,0,0.])
    def place(i, base):
        # third point in xy plane
        b=L(0,i); c=L(1,i); x=(a*a+b*b-c*c)/(2*a); y=np.sqrt(max(b*b-x*x,0)); return np.array([x,y,0.])
    r2=place(2,None)
    # fourth point
    b=L(0,3); c=L(1,3); d=L(2,3)
    x=(a*a+b*b-c*c)/(2*a)
    y=(b*b - x*x + r2[0]**2 + r2[1]**2 - d*d - 2*x*r2[0] )/(2*r2[1])  # from |p3-r2|^2=d^2
    # careful: |p3-r2|^2 = (x-r2x)^2+(y-r2y)^2+z^2 = d^2 and x^2+y^2+z^2=b^2
    y=( (x-r2[0])**2 + b*b - x*x - d*d + r2[1]**2 )/(2*r2[1])
    z=np.sqrt(max(b*b-x*x-y*y,0)); r3=np.array([x,y,z])
    n1=np.cross(q-p,r2-p); n2=np.cross(q-p,r3-p)
    return np.arccos(np.dot(n1,n2)/np.linalg.norm(n1)/np.linalg.norm(n2))

L0=1.0
tet={(i,j):L0**2 for i in range(4) for j in range(i+1,4)}
th_t=dihedral_tet(tet)                         # regular tetrahedron
th_o=np.pi-th_t                                # regular octahedron dihedral = pi - tet dihedral
print(f"regular tet dihedral {np.degrees(th_t):.4f} deg, octahedron {np.degrees(th_o):.4f} deg")
print(f"bulk FCC edge: 2 tets + 2 octs = {np.degrees(2*th_t+2*th_o):.4f} deg  (flat)")
# defected void: 4 inner regular tets around center c
spoke = 2*np.pi - 3*th_t          # each spoke in 3 inner tets
outer = 2*np.pi - (th_t + 2*th_t + 2*th_o)   # outer tet edge: 1 other tet + 2 inner tets + 2 octs
print(f"spoke deficit  = {np.degrees(spoke):+.4f} deg = {spoke:+.4f} rad   (x4)")
print(f"outer-edge deficit = {np.degrees(outer):+.4f} deg = {outer:+.4f} rad   (x6)")
S_regge = L0*(4*spoke+6*outer)
print(f"Regge action sum l*delta = {S_regge:+.4f} L0   (net {np.degrees(4*spoke+6*outer):+.2f} deg)")
print(f"sum of |delta|: {np.degrees(4*spoke+6*abs(outer)):.2f} deg; spokes carry {4*spoke/(4*spoke+6*abs(outer)):.3f} of it")
