#!/usr/bin/env python3
"""Schematic figures for the SSM background section (Sec. 3).
fig_ssm_assembly.pdf: (a) stitch and lift, (b) the K=12 shell = 6 in-plane + 3 above + 3 below,
                      (c) the assembly cascade K = 1 -> 6 -> 4 -> 12.
fig_ssm_code.pdf:     (a) Z-check on a node (its 12 bonds), (b) X-check on an octahedral void (its 12 edges),
                      (c) the 13-node coordination cluster used for the mass count."""
import numpy as np, itertools, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
plt.rcParams.update({"font.size":11,"savefig.bbox":"tight"})
NN=[np.array(v,float) for v in [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]]
def clean(ax,lim=1.25,elev=18,azim=-60):
    ax.set_xlim(-lim,lim);ax.set_ylim(-lim,lim);ax.set_zlim(-lim,lim);ax.set_box_aspect((1,1,1))
    ax.view_init(elev=elev,azim=azim);ax.set_axis_off()
# ---------------- assembly figure
fig=plt.figure(figsize=(10.5,3.4))
ax=fig.add_subplot(1,3,1,projection='3d')
A=np.array([0,0,0.]);B=np.array([1,0,0.]);C=np.array([0.5,np.sqrt(3)/2,0])
Cp=np.array([0.5,-np.sqrt(3)/2,0]);cen=(A+B+C)/3;T=cen+np.array([0,0,np.sqrt(2/3)])
ax.add_collection3d(Poly3DCollection([[A,B,C]],alpha=0.25,facecolor='C0'))
for p,q in [(A,B),(B,C),(C,A)]: ax.plot(*zip(p,q),color='0.3',lw=1.5)
for p in (A,B): ax.plot(*zip(p,Cp),color='C2',lw=2)
for p in (A,B,C): ax.plot(*zip(p,T),color='C3',lw=2)
ax.scatter(*np.array([A,B,C]).T,color='0.2',s=25);ax.scatter(*Cp,color='C2',s=40);ax.scatter(*T,color='C3',s=40)
ax.text(*(Cp+np.array([0,-0.15,0])),'stitch: new node\n2 bonds, in plane',color='C2',ha='center',va='top',fontsize=10)
ax.text(*(T+np.array([0,0,0.12])),'lift: new node, 3 bonds\nout of plane, $h=\\sqrt{2/3}\\,L_0$',color='C3',ha='center',fontsize=10)
ax.set_xlim(-0.3,1.3);ax.set_ylim(-1.1,1.1);ax.set_zlim(-0.3,1.1);ax.set_box_aspect((1,1.2,1));ax.view_init(elev=20,azim=-75);ax.set_axis_off()
ax.set_title('(a) the two assembly operators',fontsize=11.5)
ax=fig.add_subplot(1,3,2,projection='3d')
# ABC stacking: in-plane hexagon (layer B), 3 above (C), 3 below (A), in (111)-oriented frame
h=np.sqrt(2/3)
inpl=[np.array([np.cos(t),np.sin(t),0]) for t in np.arange(6)*np.pi/3]
up=[np.array([np.cos(t)/np.sqrt(3),np.sin(t)/np.sqrt(3),h]) for t in np.pi/6+np.arange(3)*2*np.pi/3]
dn=[np.array([np.cos(t)/np.sqrt(3),np.sin(t)/np.sqrt(3),-h]) for t in -np.pi/6+np.arange(3)*2*np.pi/3]
for grp,c,lab in [(inpl,'C2','6 in plane (stitch)'),(up,'C0','3 above (lift)'),(dn,'C1','3 below (lift)')]:
    for p in grp: ax.plot(*zip((0,0,0),p),color=c,lw=1.6)
    ax.scatter(*np.array(grp).T,color=c,s=30,label=lab)
ax.scatter(0,0,0,color='k',s=50,marker='*')
ax.legend(loc='upper left',fontsize=9.5,frameon=False,bbox_to_anchor=(-0.22,1.0))
clean(ax,1.05,14,-55);ax.set_title('(b) $K=12=6+3+3$ (FCC, ABC stacking)',fontsize=11.5)
ax=fig.add_subplot(1,3,3);ax.set_axis_off();ax.set_xlim(0,1);ax.set_ylim(0,1)
steps=[('Bell pair','$K=1$'),('stitched sheet','$K=6$'),('tetrahedral foam','$K=4$, frustrated'),('FCC crystal','$K=12$, Kepler bound')]
ys=[0.88,0.63,0.38,0.13]
for (t,k),y in zip(steps,ys):
    ax.add_patch(plt.Rectangle((0.08,y-0.08),0.84,0.16,fc='0.95',ec='0.4'))
    ax.text(0.5,y+0.025,t,ha='center',fontsize=11.5);ax.text(0.5,y-0.045,k,ha='center',fontsize=10,color='0.3')
for y0,y1,l in [(ys[0],ys[1],'stitch'),(ys[1],ys[2],'lift, $P_{\\rm lift}=e^{-3}$'),(ys[2],ys[3],'deficit $\\delta=0.128$ rad relieved')]:
    ax.annotate('',xy=(0.5,y1+0.085),xytext=(0.5,y0-0.085),arrowprops=dict(arrowstyle='->',color='0.3'))
    ax.text(0.53,(y0+y1)/2,l,fontsize=10,color='0.25',va='center')
ax.text(0.5,0.0,'a node left in a tetrahedral void = matter',ha='center',fontsize=10,color='C3')
ax.set_title('(c) the assembly cascade',fontsize=11.5)
fig.tight_layout();fig.savefig('fig_ssm_assembly.pdf');plt.close(fig)
# ---------------- code figure
fig=plt.figure(figsize=(10.5,3.4))
ax=fig.add_subplot(1,3,1,projection='3d')
for v in NN: ax.plot(*zip((0,0,0),v),color='C0',lw=1.6)
ax.scatter(*np.array(NN).T,color='0.4',s=18);ax.scatter(0,0,0,color='C0',s=60)
clean(ax,1.2,24,-28);ax.set_title('(a) $Z$-check on a node',fontsize=11.5)
ax=fig.add_subplot(1,3,2,projection='3d')
O=[np.array(v,float) for v in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
for p,q in itertools.combinations(O,2):
    if abs(np.linalg.norm(p-q)-np.sqrt(2))<1e-9: ax.plot(*zip(p,q),color='C1',lw=1.6)
ax.scatter(*np.array(O).T,color='0.3',s=25);ax.scatter(0,0,0,color='C1',marker='x',s=40)
clean(ax,1.2);ax.set_title('(b) $X$-check on an octahedral void',fontsize=11.5)
ax=fig.add_subplot(1,3,3,projection='3d')
for v in NN: ax.plot(*zip((0,0,0),v),color='C3',lw=1.4)
for p,q in itertools.combinations(NN,2):
    if abs(np.linalg.norm(p-q)-np.sqrt(2))<1e-9: ax.plot(*zip(p,q),color='0.55',lw=0.9)
sq=[[NN[i] for i in idx] for idx in ([0,4,1,5],)]
ax.scatter(*np.array(NN).T,color='0.3',s=18);ax.scatter(0,0,0,color='C3',s=60,marker='*')
clean(ax,1.2,20,-40);ax.set_title('(c) the 13-node cluster',fontsize=11.5)
fig.tight_layout();fig.savefig('fig_ssm_code.pdf');plt.close(fig)
print("ok")
