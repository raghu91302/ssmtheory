"""Curvature profile of a solved slice: spoke deficit, K5 and shell sums of l*delta, largest |delta| per shell.
Run: python3 entropy_id_profile.py L Rw q   (needs id_L{L}_q{q}.npy)"""
import sys, numpy as np
import entropy_defect_intrinsic as I, entropy_id_solve as R
L=int(sys.argv[1]); Rw=float(sys.argv[2]); q=float(sys.argv[3])
C=R.setup(L); psi=np.load(f"id_L{L}_q{q}.npy"); l=R.lengths(C,psi); d=I.deficits(l,C['tedge'],C['nE'])
P=C['dv']; mid=np.linalg.norm((P[C['Eu']]+((P[C['Ev']]-P[C['Eu']]+L/2)%L-L/2)/2),axis=1)
sp_e=np.array([k for k,(u,v) in enumerate(C['E']) if C['cdef'] in (u,v)])
k5=np.zeros(C['nE'],bool)
cor=set(C['Eu'][sp_e])|set(C['Ev'][sp_e]); cor.discard(C['cdef'])
for k,(u,v) in enumerate(C['E']):
    if C['cdef'] in (u,v) or (u in cor and v in cor): k5[k]=True
tot=np.sum(l*d); print(f"q={q}: spoke deficit {np.degrees(d[sp_e]).mean():.4f} deg; sum l*delta: K5 {np.sum((l*d)[k5]):.4e} of interior-total (r<Rw-1) {np.sum((l*d)[mid<Rw-1]):.4e}")
for a,b in [(0,1),(1,1.6),(1.6,2.2),(2.2,3),(3,4),(4,5),(5,6)]:
    s=(mid>=a)&(mid<b)&~k5
    if s.any(): print(f"  r in [{a},{b}): {s.sum()} edges, max|delta| {np.degrees(np.abs(d[s]).max()):.4f} deg, sum l*delta {np.sum((l*d)[s]):+.3e}")
