"""Full Dirac-Kahler matter action in the initial-data formulation.
Model R: dual areas fixed (reduced source).  Model M: barycentric spoke dual areas from the labels.
Model F: model M plus the 0-form block, weight eta.  Mass of spoke k: mu0*(a_k/a0)*l_k, half to each end;
0-form energy mu0/a0*eta*[(sum a)^2/V_c at c, a_k^2/V_k at corner k].  Constraint at each free vertex:
sum_{e at v} l_e delta_e = 2*8piG*m_v.  Perturbation test: nudge psi at one corner, re-solve, compare.
Run: python3 entropy_id_fullmatter.py L Rw model eta q1,q2,..."""
import sys, numpy as np
import entropy_defect_intrinsic as I, entropy_id_solve as R
from scipy.optimize import least_squares
L=int(sys.argv[1]); Rw=float(sys.argv[2]); model=sys.argv[3]; eta=float(sys.argv[4]); qs=[float(x) for x in sys.argv[5].split(',')]
C=R.setup(L); free,idx,A,S,sp_e=R.build(C,Rw); E=C['E']; cdef=C['cdef']; tets=None
_,_,tets,_,_,_,_,_=I.build_complex(L)
tedge=C['tedge']; Eu,Ev=C['Eu'],C['Ev']
corner=[(u if v==cdef else v) for (u,v) in [E[k] for k in sp_e]]
defnodes=[cdef]+corner
near=np.array([t for t,T in enumerate(tets) if any(v in defnodes for v in T)])
TE=tedge[near]; TV=np.array([tets[t] for t in near]); pairs=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
spoke_slot=np.full(TE.shape,-1)
for k,e in enumerate(sp_e): spoke_slot[TE==e]=k
node_idx={v:i for i,v in enumerate(defnodes)}; node_slot=np.full(TV.shape,-1)
for v,i in node_idx.items(): node_slot[TV==v]=i
def embed_all(sq):
    a=np.sqrt(sq[:,0]);b=np.sqrt(sq[:,1]);c=np.sqrt(sq[:,3]); z=0*a
    P0=np.stack([z,z,z],1); P1=np.stack([a,z,z],1)
    x2=(a*a+b*b-c*c)/(2*a); y2=np.sqrt(np.maximum(b*b-x2*x2,1e-300)); P2=np.stack([x2,y2,z],1)
    d=np.sqrt(sq[:,2]);e=np.sqrt(sq[:,4]);f=np.sqrt(sq[:,5])
    x3=(a*a+d*d-e*e)/(2*a); y3=((x3-x2)**2+d*d-x3*x3-f*f+y2*y2)/(2*y2); z3=np.sqrt(np.maximum(d*d-x3*x3-y3*y3,1e-300))
    return [P0,P1,P2,np.stack([x3,y3,z3],1)]
def duals(l):
    P=embed_all(l[TE]**2); bT=(P[0]+P[1]+P[2]+P[3])/4
    vol=np.abs(np.einsum('ij,ij->i',np.cross(P[1]-P[0],P[2]-P[0]),P[3]-P[0]))/6
    V=np.zeros(5)
    for q in range(4):
        m=node_slot[:,q]>=0; np.add.at(V,node_slot[m,q],vol[m]/4)
    a=np.zeros(4)
    for kk,(i,j) in enumerate(pairs):
        m=spoke_slot[:,kk]>=0
        if not m.any(): continue
        mid=(P[i][m]+P[j][m])/2; area=0
        for q in [q for q in range(4) if q not in (i,j)]:
            bf=(P[i][m]+P[j][m]+P[q][m])/3; area=area+0.5*np.linalg.norm(np.cross(bf-mid,bT[m]-mid),axis=1)
        np.add.at(a,spoke_slot[m,kk],area)
    return a,V
a0,V0=duals(C['lflat'])
K0=eta*(np.sum(a0)**2/V0[0]+np.sum(a0**2/V0[1:]))/a0.mean(); M0=np.sum(C['lflat'][sp_e])
print(f"L={L} model {model} eta={eta}: flat spoke dual area {a0.mean():.4f}, V_c {V0[0]:.4f}; 0-form/mass at flat = {K0/M0:.3f}",flush=True)
def masses(l,q):
    m=np.zeros(C['nv'])
    if model=='R': a=a0.copy(); V=V0
    else: a,V=duals(l)
    for k,e in enumerate(sp_e):
        mk=q*(a[k]/a0[k])*l[e]; m[Eu[e]]+=mk/2; m[Ev[e]]+=mk/2
    if model=='F':
        m[cdef]+=q*eta*np.sum(a)**2/V[0]/a0.mean()
        for k,v in enumerate(corner): m[v]+=q*eta*a[k]**2/V[k+1]/a0.mean()
    return m
def resid(z,q):
    psi=np.ones(C['nv']); psi[free]=z; l=R.lengths(C,psi); d=I.deficits(l,tedge,C['nE'])
    return (A@(l*d)-2*masses(l,q))[free]
def solve(z,q):
    s=least_squares(resid,z,args=(q,),jac_sparsity=S,method='trf',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=300); return s.x
z=np.ones(free.sum()); ic=idx[corner]
for q in qs:
    z=solve(z,q); r=np.abs(resid(z,q)).max()
    psi=np.ones(C['nv']); psi[free]=z; l=R.lengths(C,psi); a,V=duals(l)
    out=f" q={q}: resid {r:.1e} spokes/L0 {(l[sp_e]/I.L0).round(4)} psi corners {z[ic].round(4)} a/a0 {(a/a0).round(3)} V_c/V0 {V[0]/V0[0]:.3f}"
    if r>1e-10: print(out,flush=True); continue
    pert=[]
    for s in (+0.05,-0.05):
        zp=z.copy(); zp[ic[0]]*=1+s; zp=solve(zp,q); pert.append((np.abs(resid(zp,q)).max(),np.abs(zp-z).max()))
    print(out+f" | nudge +5%: resid {pert[0][0]:.1e} max|dpsi| {pert[0][1]:.1e}; -5%: resid {pert[1][0]:.1e} max|dpsi| {pert[1][1]:.1e}",flush=True)
