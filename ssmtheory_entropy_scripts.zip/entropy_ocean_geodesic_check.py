#!/usr/bin/env python3
"""Check of the second-order geodesic distance used by entropy_ocean_G_scalar.py and entropy_ocean_G_gauge.py ('geo').
Metric g = 1 + A H cos(p.x). For a bond y from x0, the formula gives E_line - E_geo, the drop of the energy functional
int g(dx/dt,dx/dt) dt from the straight segment to the geodesic, at order A^2. We compare it with the drop along the path
predicted by the formula, eta = -(1/2) G J, evaluated on a fine grid (K steps).
Usage: python3 entropy_ocean_geodesic_check.py [A] [K] [NQ]   (NQ Gauss points; the G scripts use 10)"""
import numpy as np, sys
A=float(sys.argv[1]) if len(sys.argv)>1 else 0.01; K=int(sys.argv[2]) if len(sys.argv)>2 else 400; NQ=int(sys.argv[3]) if len(sys.argv)>3 else 10
rng=np.random.default_rng(0)
p=np.array([1.4,0.3,-0.5,0.8]); H=rng.normal(size=(4,4)); H=H+H.T; H/=np.sqrt(np.trace(H@H))
x0=rng.normal(size=4); y=rng.normal(size=4); y*=1.7/np.linalg.norm(y)
t=np.linspace(0,1,K+1)
def E(eta):
    gam=x0+np.outer(t,y)+eta; dg=np.diff(gam,axis=0)*K; xm=(gam[1:]+gam[:-1])/2
    return np.sum(np.einsum('ka,kab,kb->k',dg,np.eye(4)[None]+A*np.cos(xm@p)[:,None,None]*H[None],dg))/K
tq,wq=np.polynomial.legendre.leggauss(NQ); tq=(tq+1)/2; wq=wq/2; Gq=np.minimum.outer(tq,tq)*(1-np.maximum.outer(tq,tq))
th=x0@p+tq*(y@p); q=y@H@y
J=A*(-np.sin(th))[:,None]*(p[None]*q-2*(y@p)*(H@y)[None]); Jw=J*wq[:,None]
drop_formula=0.25*np.einsum('tb,ts,sb->',Jw,Gq,Jw)
th2=x0@p+t*(y@p); Jt=A*(-np.sin(th2))[:,None]*(p[None]*q-2*(y@p)*(H@y)[None])
Gm=np.minimum.outer(t,t)*(1-np.maximum.outer(t,t)); wt=np.full(K+1,1/K); wt[[0,-1]]/=2
eta=-0.5*(Gm*wt[None])@Jt
E0=E(np.zeros((K+1,4))); drop_path=E0-E(eta)
Eline=y@y+A*q*np.sum(wq*np.cos(th)); Emid=y@y+A*q*np.cos((x0+y/2)@p)
print('A=%g: drop formula %.4e, drop along predicted path %.4e (ratio %.3f)'%(A,drop_formula,drop_path,drop_path/drop_formula))
print('for scale: midpoint minus straight-segment value %.3e (first order in A)'%(Emid-Eline))
