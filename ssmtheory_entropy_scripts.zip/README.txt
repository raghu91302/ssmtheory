Reproducibility scripts for

  Exact Dirac-Kahler Harmonic Modes on an FCC CSS-Code Complex:
  A Discrete Matter Sector for Gravity from Entropy
  Raghu Kulkarni, SSMTheory Group

Requirements: Python 3 with NumPy, SciPy, Matplotlib.
The Section 5 script requires NumPy only.

Scripts cited in Data availability
----------------------------------
entropy_fcc_real_harmonic.py
    Integer lift of the octahedral stabilizers, harmonic counts,
    lift-robustness test.

entropy_void_localization.py
    Compact-localized-state enumeration and the rank decomposition
    at L = 4 and L = 6.

entropy_make_figures.py
    Dirac-Kahler spectra, the spectral-identity, torsion, global-mode
    and selective-coupling computations, and all figures.

entropy_complex_completion.py
    Geometric completion of d2 with the triangular 2-cells, the collapse
    of b1 to 3, and the all-void curvature lift.

entropy_action_backreaction_v1.py
    Section 5. Closed-form relative entropy, the variational identity
    reproducing the Dirac-Kahler equation, and the back-reaction
    residuals. Propositions 1-3 and Table 4.

    Usage:  python3 entropy_action_backreaction_v1.py [L]     (default 4)
    L = 4 runs in seconds. L = 6 needs a few minutes and about 2 GB,
    since the graded space has 4L^3 dimensions.

Additional scripts
------------------
entropy_cascade_dynamics_test.py
entropy_lift_barrier_ts.py
    Assembly-kinematics tests from the wider program; not cited in this
    manuscript, retained from the previous archive.

Notes
-----
All computations are exact enumerations or dense diagonalizations.
The only random numbers are the gradient-check vectors in the Section 5
script, whose seed is fixed, so repeated runs give identical output.

SHA256SUMS lists the checksum of every file. Verify with:

    sha256sum -c SHA256SUMS
