"""Overlap of the initial-data strain with the void's six compact localized zero modes (CLS).
cos(eps, diag P) on the void's 42-edge neighborhood S and on all lattice edges.
Run: python3 entropy_id_footprint.py L q   (needs id_L{L}_q{q}.npy from entropy_id_solve.py)"""
import sys, numpy as np
import entropy_fcc_real_harmonic as Sm, entropy_id_solve as R
from entropy_defect_intrinsic import wrapd
from itertools import combinations
L=int(sys.argv[1]); q=float(sys.argv[2])
def neighborhood(L):
    nodes,nidx,edges,eidx,octs=Sm.build_lattice(L)
    c=(0.5,0.5,0.5); bnd=[i for i,p in enumerate(nodes) if abs(wrapd(c,p,L)-np.sqrt(3)/2)<1e-9]
    tet=[eidx[tuple(sorted(pr))] for pr in combinations(bnd,2)]; S=set(tet)
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z)%2==1 and abs(wrapd(c,(x,y,z),L)-np.sqrt(3)/2)<1e-9:
                    b=[nidx[p] for p in [((x+1)%L,y,z),((x-1)%L,y,z),(x,(y+1)%L,z),(x,(y-1)%L,z),(x,y,(z+1)%L),(x,y,(z-1)%L)]]
                    S|=set(eidx[tuple(sorted(pr))] for pr in combinations(b,2) if tuple(sorted(pr)) in eidx)
    return nodes,nidx,edges,eidx,octs,tet,sorted(S)
# zero-mode content overlapping the neighborhood, at L=4 (dense)
n4,_,e4,ei4,o4,_,S4=neighborhood(4)
d14=Sm.boundary_1(n4,e4).astype(float); d24=Sm.boundary_2(e4,ei4,o4).astype(float); L14=d14.T@d14+d24@d24.T
w4,V4=np.linalg.eigh(L14); H4=V4[:,w4<1e-9]; rS=np.linalg.matrix_rank(H4[S4,:],tol=1e-8)
print(f'L=4: zero modes {H4.shape[1]}, rank of their restriction to the 42-edge neighborhood {rS}')
nodes,nidx,edges,eidx,octs=Sm.build_lattice(L); n1=len(edges)
d1=Sm.boundary_1(nodes,edges).astype(float); d2=Sm.boundary_2(edges,eidx,octs).astype(float)
L1=d1.T@d1+d2@d2.T
c=(0.5,0.5,0.5); bnd=[i for i,p in enumerate(nodes) if abs(wrapd(c,p,L)-np.sqrt(3)/2)<1e-9]
tet=[eidx[tuple(sorted(pr))] for pr in combinations(bnd,2)]
S=set(tet)
for x in range(L):
    for y in range(L):
        for z in range(L):
            if (x+y+z)%2==1 and abs(wrapd(c,(x,y,z),L)-np.sqrt(3)/2)<1e-9:
                b=[nidx[p] for p in [((x+1)%L,y,z),((x-1)%L,y,z),(x,(y+1)%L,z),(x,(y-1)%L,z),(x,y,(z+1)%L),(x,y,(z-1)%L)]]
                S|=set(eidx[tuple(sorted(pr))] for pr in combinations(b,2) if tuple(sorted(pr)) in eidx)
S=sorted(S)
u,s,vt=np.linalg.svd(L1[:,S]); k=int((s<1e-8).sum())
Cm=np.zeros((n1,k)); Cm[S,:]=vt[len(s)-k:].T; Q,_=np.linalg.qr(Cm); dP=np.einsum('ij,ij->i',Q,Q)
C=R.setup(L); psi=np.load(f"id_L{L}_q{q}.npy"); l=R.lengths(C,psi)
assert all(tuple(sorted(C['E'][i]))==tuple(sorted(edges[i])) for i in range(n1))
eps=l[:n1]**2/C['lflat'][:n1]**2-1
cS=eps[S]@dP[S]/np.linalg.norm(eps[S])/np.linalg.norm(dP[S]); cA=eps@dP/np.linalg.norm(eps)/np.linalg.norm(dP)
print(f"L={L} q={q}: |S|={len(S)}, CLS {k}; cos(eps,diagP) on S {cS:.3f}, all lattice edges {cA:.3f}; "
      f"share of |eps|^2 on S {np.sum(eps[S]**2)/np.sum(eps**2):.3f}, on tet edges {np.sum(eps[tet]**2)/np.sum(eps**2):.3f}; min eps {eps.min():.2e} max {eps.max():.2e}")
