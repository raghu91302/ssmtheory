"""Route C, minimal coupling between code and labels.
Each bond carries two qubits with H = -J(a) (X1 X2 + Z1 Z2) - h (Z1 + Z2), J(a) = J0 (a/a0)^p.
The ground state is cos(t)|00> + sin(t)|11>. Route C needs d ln s / d ln a = 1 at the vacuum point.
Maximal vacuum entanglement in a ball of fixed boundary area A, crossed by A/a bonds, makes S = (A/a) s(a)
stationary in a; this is d(s/a)/da = 0, equivalent to slope one. The script
  (1) tabulates s0 and the slope against h/J0 for p = 1,
  (2) locates the maximum of s/a for several p, which fixes h/J0 and s0,
  (3) prints the strong-field response and the local Newton constant G_loc/G = s'(a0)/s'(a).
Usage: python3 entropy_routeC_bond_coupling.py"""
import numpy as np
from scipy.optimize import minimize_scalar

def s_of(J, h=1.0):
    """Entanglement entropy (nats) of the bond ground state."""
    H = np.array([[-J - 2*h, -J], [-J, -J + 2*h]])   # basis |00>, |11>
    w, v = np.linalg.eigh(H)
    q = v[:, 0]**2
    q = q[q > 1e-300]
    return -(q*np.log(q)).sum()

def slope(J0, h=1.0, p=1.0, e=1e-6):
    """d ln s / d ln a at a = a0."""
    return (np.log(s_of(J0*(1 + e)**p, h)) - np.log(s_of(J0*(1 - e)**p, h)))/(np.log(1 + e) - np.log(1 - e))

print('(1) p = 1:  h/J0   s0/ln2   dln s/dln a')
for r in [0.1, 0.3, 0.5, 0.69, 1.0, 1.5, 2.0]:
    print('           %5.2f   %.3f    %.3f' % (r, s_of(1/r)/np.log(2), slope(1/r)))

print('\n(2) maximum of s/a (h = 1, a in units where J = a^p)')
print('   p     h/J0     s0/ln2   slope    G_loc/G at stretch 2%, 10%, 20%, 49%, 100%')
for p in [0.5, 1.0, 1.5, 2.0]:
    r = minimize_scalar(lambda a: -s_of(a**p)/a, bounds=(1e-3, 50), method='bounded')
    a0 = r.x
    if a0 < 2e-3 or a0 > 49:
        print('  %.1f    no interior maximum' % p); continue
    J0 = a0**p
    ds = lambda x, d=1e-5: (s_of(J0*(x + d)**p) - s_of(J0*(x - d)**p))/(2*d)
    G = [ds(1)/ds(x) for x in [1.02, 1.10, 1.20, 1.49, 2.0]]
    print('  %.1f   %.4f   %.4f   %.4f   ' % (p, 1/J0, s_of(J0)/np.log(2), slope(J0, p=p)) + ', '.join('%.3f' % g for g in G))

print('\n(3) p = 1 at the maximum: s(a)/s0 against a/a0')
r = minimize_scalar(lambda a: -s_of(a)/a, bounds=(1e-3, 50), method='bounded'); J0 = r.x; s0 = s_of(J0)
for x in [0.5, 0.8, 1.1, 1.2, 1.49, 2.0, 4.0]:
    print('   a/a0 = %.2f   s/s0 = %.3f' % (x, s_of(J0*x)/s0))

print('\n(4) calibration with G held fixed: L_f^2 = 4 G s0, L_0 = (3/2)^(1/4) L_f')
for s0 in [np.log(2), s0]:
    Lf = np.sqrt(4*s0); L0 = (1.5)**0.25*Lf; f = s0/np.log(2)
    print('   s0/ln2 = %.4f  L_f = %.3f lP  L_0 = %.3f lP  Lambda lP = %.2f / %.2f  C req = %.2f / %.2f  G_ind/G(C=4) = %.2f / %.2f'
          % (f, Lf, L0, 4.216/L0, 5.013/L0, 7.20*f, 5.09*f, 1.80*f, 1.27*f))
    print('      beta R_e coefficient %.4f   proton q %.1e   missing crossings at 0.84 fm %.0f   GM %.2f lP'
          % (0.017/f, 4e-19/np.sqrt(f), 18/f, 0.85*L0))
