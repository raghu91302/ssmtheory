#!/usr/bin/env python3
"""Route B: one-loop induced coefficients (proper-time cutoff) for a set of free massless fields,
and the cutoff from one covariant mode per D4 site.
Species: real scalars (xi), Weyl fermions, gauge vectors (with ghosts)."""
import numpy as np

def content(Ns, Nw, Nv, xi=0.0):
    C = Ns*(1 - 6*xi) + Nw - 4*Nv               # Einstein weight
    nBF = Ns + 2*Nv - 2*Nw                        # n_B - n_F
    return dict(C=C, nBF=nBF)

for name, args in [('SSM: 48 Weyl, 12 V, 4 S', (4, 48, 12)), ('no nu_R: 45 Weyl', (4, 45, 12)), ('4th gen: 64 Weyl', (4, 64, 12))]:
    print(name, content(*args))
d = content(4, 48, 12); C = d['C']

# cutoff: one covariant mode per D4 site (four-volume L0^4/2); modes per unit four-volume Lambda^4/16pi^2 (heat kernel,
# the proper-time scheme's own count) or Lambda^4/32pi^2 (sharp ball). L_f = (2/3)^(1/4) L0 is the area-law length.
# The required C is 48 pi s0/(Lambda L_f)^2; printed for s0 = ln2 (it scales as s0).
s0 = np.log(2)
LL0 = ((32*np.pi**2)**.25, (64*np.pi**2)**.25); LLFS = tuple(x*(2/3)**.25 for x in LL0)
for a, b in zip(LL0, LLFS):
    Creq = 48*np.pi*s0/b**2
    print('Lambda L0=%.3f  Lambda L_f=%.3f  C_req=%.2f  G_ind/G_area=%.2f  route-B share of 1/G=%.2f'
          % (a, b, Creq, Creq/C, C/Creq))
print('rho_vac (proper time) = %.4f Lambda^4 ; Lambda_cc = %.2f Lambda^2'
      % (-d['nBF']/(64*np.pi**2), 8*np.pi*12*np.pi/C*(-d['nBF'])/(64*np.pi**2)))
for LLf in LLFS:
    print('Lambda L_f=%.3f  Lambda_cc L_f^2=%.0f' % (LLf, 102/C*LLf**2))
