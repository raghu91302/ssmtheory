# Three Routes to Regge Gravity on the FCC Vacuum Lattice: Relative Entropy, Vacuum Fluctuations, and Entanglement Equilibrium — reproducibility scripts

All scripts run from one flat directory with Python 3, NumPy, SciPy and Matplotlib.
Section numbers refer to the manuscript.

| script | reproduces |
|---|---|
| entropy_fig_ssm.py | schematic Figs. 1–2 of the SSM background section (Sec. 3) |
| entropy_fcc_real_harmonic.py | integer lift, harmonic counts, lift robustness (Sec. 5.2) |
| entropy_void_localization.py | compact localized zero modes, rank decomposition at L=4,6 (Sec. 5.2) |
| entropy_make_figures.py | Hodge spectra (Fig. 3), spectral identity, torsion, global modes |
| entropy_complex_completion.py | geometric completion of d2, collapse of b1 to 3 (Sec. 5.2) |
| entropy_action_backreaction.py | closed-form relative entropy, variation, back-reaction (Sec. 5.3) |
| entropy_induced_action.py | route B: induced coefficients for the field content (C, n_B-n_F), cutoff from one mode per D4 site, required C and route-B share of 1/G at s0 = ln2, vacuum energy (Secs. 4.2, 8) |
| entropy_d4_regulator.py | D4 lattice as a regulator: shear response K of scalar and Wilson-fermion vacuum terms, covariant value 1/4, spin-2 mass for the SSM content (Sec. 7) |
| entropy_d4_regulator_checks.py | other scalar lattice actions (bond-weight freedom, next-nearest neighbors) and an ideal isotropic cutoff (Sec. 7) |
| entropy_spin2_spectrum.py | gauge-constrained spin-2 spectrum of lattice-regulated loops (scalar; Wilson fermion with vierbein and spin connection) at all lattice momenta, with the Regge kinetic term, for the SSM content (Sec. 7) |
| entropy_spin2_checks.py | spin connection: spinor algebra and curvature against the Riemann tensor; optional exact real-space determinants on an 8^4 lattice (argument realspace) (Sec. 7) |
| entropy_ocean_sprinkling.py | covariance test for a randomly sprinkled ocean vs the D4 points with the same operators (scalar, fermion) (Sec. 7) |
| entropy_ocean_G_scalar.py, entropy_ocean_G_fermion.py, entropy_ocean_G_gauge.py | induced Newton constant of the sprinkled ocean per species (TT p^2 coefficient; exact second-order expansion with a validation mode 'check'). Scalar options: bond distance mid / line / geo and the cut; gauge options: mid / geo and the Ricci term on (1) or off (0). The weights depend on these choices (Sec. 7) |
| entropy_ocean_delaunay_shear.py | shear test for the sprinkled points joined by their Delaunay triangulation, finite-element Laplacian from edge lengths, triangulation held fixed: K+kappa1 = +0.24 (Sec. 7) |
| independent_spin2/ | an independent implementation of the D4 uniform-strain responses and the spin-2 spectrum, written from the paper's description and sharing no code with the other scripts: latlib.py (operators), uniform.py, spin2.py, polforms.py (all polarizations, transporter ordering), checks.py (spin connection, real-space determinants), rscan.py (grid convergence, r = 0.5, 2); saved outputs *_out.txt (Sec. 7) |
| entropy_ocean_G_spinor.py | Dirac fermion on the sprinkled ocean from its squared operator D^dag D (spinor graph Laplacian with path-ordered spin transport plus the Lichnerowicz term R/4), no Wilson term; option lich = 1/0 (Sec. 7) |
| entropy_routeC_bond_coupling.py | route C: two-qubit bond with a coupling that grows with the dual area; maximum of s/a (maximal vacuum entanglement) fixes h/J0 and s0 and gives slope one; local Newton constant under stretch (Sec. 9, bond-model tables) |
| entropy_routeC_field_cut.py | route C comparison: lattice scalar entanglement across a plane under a transverse stretch, points carried vs refilled (Sec. 9) |
| entropy_routeC_equilibrium.py | route C: entanglement equilibrium of the solved trapped-node slice, ball by ball (area deficit at fixed volume vs the modular energy of the spoke source) (Sec. 6.5) |
| entropy_ocean_geodesic_check.py | check of the second-order geodesic distance used by the 'geo' option (Sec. 7, Methods) |
| entropy_defect_intrinsic.py | library: the defected complex (octahedra split about their centers) and the deficit routine used by all defect scripts |
| entropy_defect_deficit.py | all defect labels at L0: +148.4 deg / -70.5 deg, Regge sum 2.975 L0 (Sec. 6.1) |
| entropy_3d_obstruction.py | 3D Regge gravity with the spoke source has no solution: residual ~17% of the target (Sec. 6.2) |
| entropy_lapse_variation.py | the vertex constraint from the lapse variation of the 4D Regge action: static 3+1 prism complex over a solved slice, central differences of the 4D Regge sum in N_v (Sec. 6.3) |
| entropy_id_solve.py | Hamiltonian constraint on a conformally flat slice, one equation per node; far-field fit psi = 1 + GM/2r (Secs. 6.3–6.4, Table 5); optional 4th argument 'node' puts the whole rest mass on the trapped node |
| entropy_id_lapse.py | lapse on the solved slice, Newtonian coefficient and gamma (Sec. 6.4) |
| entropy_id_profile.py | curvature profile around the defect (Sec. 6.4) |
| entropy_id_fullmatter.py | label-dependent dual areas (M) and 0-form block (F); existence, symmetry and nudge tests (Sec. 6.6) |
| entropy_id_footprint.py | overlap of the initial-data strain with the void's localized zero modes; rank 38 of the zero modes on the void's neighborhood at L=4 (Sec. 6.8) |
| entropy_defect_hybridization.py | defected-complex Betti count (+3); no bound state (Sec. 6.8) |
| entropy_fig_defect.py | Fig. 4 (defect, and curvature off the spokes); needs id_L16_q0.1.npy, written by the L=16 entropy_id_solve.py command below |
| entropy_fig_initialdata.py | Fig. 5 (spoke length, binding, far-field mass against q); reads fine20.log |

Data: fine20.log is the output of the L=20 scan used for Table 5 and Fig. 5.
Figures: fig_ssm_assembly.pdf (Fig. 1), fig_ssm_code.pdf (Fig. 2), fig_spectra.pdf (Fig. 3), fig_defect.pdf (Fig. 4), fig_initial_data.pdf (Fig. 5).

Typical commands (q = 8 pi G mu):

    python3 entropy_3d_obstruction.py 4 0.5,2,5,10,20
    python3 entropy_3d_obstruction.py 6 0.5,2,5,10,20
    python3 entropy_id_solve.py 20 9.6 0.001,0.01,0.03,0.1,0.2,0.3,0.5,0.75,1,1.25,1.5,1.75,2,2.25,2.5,2.75,2.9,3,3.05,3.1,3.13 > fine20.log
    python3 entropy_id_solve.py 16 7.6 0.001,0.1,1,2,2.5,2.8,3,3.1,3.13,3.135,3.138,3.14,3.1412
    python3 entropy_id_solve.py 16 7.6 0.003465,0.354,1,3 node
    python3 entropy_lapse_variation.py 8 3.6 0.1 3 0.02
    python3 entropy_lapse_variation.py 8 3.6 1.0 3 0.02
    python3 entropy_id_lapse.py 16 7.6 0.001
    python3 entropy_id_profile.py 16 7.6 0.1
    python3 entropy_id_footprint.py 16 0.001
    python3 entropy_id_fullmatter.py 12 5.6 R 0 0.1,1,2
    python3 entropy_id_fullmatter.py 12 5.6 M 0 0.1,0.5,0.6,0.7,0.75,0.8,0.81,0.82
    python3 entropy_id_fullmatter.py 12 5.6 F 0.1 0.1,0.5,0.55,0.6,0.65
    python3 entropy_fig_initialdata.py fine20.log
    python3 entropy_fig_defect.py
    python3 entropy_induced_action.py
    python3 entropy_d4_regulator.py 16
    python3 entropy_d4_regulator_checks.py
    python3 entropy_spin2_spectrum.py 12
    python3 entropy_ocean_sprinkling.py s 8 100 1.0 11 ; python3 entropy_ocean_sprinkling.py f 6 30 1.0 7   # slow
    for d in mid line geo; do python3 entropy_ocean_G_scalar.py 8 1 $d 2.5; done ; python3 entropy_ocean_G_scalar.py 8 1 geo 3.5
    python3 entropy_ocean_G_fermion.py 6 2 0.1 1.0
    # covariant ocean (Sec. 7 table): geodesic distance, smooth cut at 3.5 sigma in proper distance, path-ordered spin transport
    for s in 0.55 0.7 0.8; do
      OCEAN_TAPER=1 OCEAN_SIG=$s python3 entropy_ocean_G_scalar.py 8 1 geo 3.5
      OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=$s OCEAN_DIST=geo python3 entropy_ocean_G_fermion.py 6 2 0.1 1.0     # about 1 h
      for ric in 1 0; do OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=$s python3 entropy_ocean_G_gauge.py 6 1 0.02 run geo $ric; done
    done
    python3 entropy_ocean_delaunay_shear.py 5 2
    OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=0.7 OCEAN_DIST=geo python3 entropy_ocean_G_fermion.py 6 2 0.1 0.5      # Wilson r = 0.5
    for l in 1 0; do OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=0.7 python3 entropy_ocean_G_spinor.py 6 1 0.02 run geo $l; done   # about 1 h each
    python3 entropy_routeC_bond_coupling.py                  # seconds
    python3 entropy_routeC_field_cut.py                      # about 1 min
    python3 entropy_routeC_equilibrium.py 16 7.6 0.01        # about 6 min
    for v in "mid 1" "mid 0" "geo 1" "geo 0"; do python3 entropy_ocean_G_gauge.py 6 1 0.02 run $v; done     # about 20 min each
    python3 entropy_ocean_geodesic_check.py 0.01 400 10 ; python3 entropy_ocean_geodesic_check.py 0.01 400 40
    python3 entropy_spin2_checks.py            # add 'realspace' for the 8^4 determinant check

Run times on one core: setup 10 s (L=12), 40 s (L=16), 3 min (L=20); each constraint solve takes seconds.
All random numbers (gradient-check vectors, sprinklings) come from fixed seeds.
