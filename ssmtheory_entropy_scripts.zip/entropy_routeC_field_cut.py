"""Route C comparison: a lattice scalar field's ground-state entanglement across a plane (2+1 D),
and its response to a transverse stretch.
Normal spacing ax, transverse spacing ay, Ny periodic transverse sites, cut in the middle of Nx sites.
  carried:  same sites, ay -> ay (1+e)
  refilled: same spacing, more sites at fixed density per proper area
Usage: python3 entropy_routeC_field_cut.py"""
import numpy as np

def S_chain(m2, ax, Nx):
    K = (np.diag(np.full(Nx, 2/ax**2 + m2)) - np.diag(np.full(Nx - 1, 1/ax**2), 1)
         - np.diag(np.full(Nx - 1, 1/ax**2), -1))
    w, v = np.linalg.eigh(K)
    X = (v/np.sqrt(w))@v.T/2
    P = (v*np.sqrt(w))@v.T/2
    n = Nx//2
    nu = np.sqrt(np.clip(np.linalg.eigvals(X[:n, :n]@P[:n, :n]).real, 0.25, None))
    a, b = nu + 0.5, np.maximum(nu - 0.5, 1e-14)
    return (a*np.log(a) - b*np.log(b)).sum()

def S(ax, ay, Ny, m=0.05, Nx=200):
    k = 2*np.pi*np.arange(Ny)/Ny
    return sum(S_chain(m**2 + 4*np.sin(q/2)**2/ay**2, ax, Nx) for q in k)

if __name__ == '__main__':
    e = 0.03
    print('carried stretch:  ax    m    dlnS/dlnA')
    for ax in [0.5, 1.0, 2.0]:
        for m in [0.01, 0.05, 0.2, 0.5]:
            s0, s1 = S(ax, 1, 48, m), S(ax, 1 + e, 48, m)
            print('                 %4.1f  %4.2f   %.3f' % (ax, m, np.log(s1/s0)/np.log(1 + e)))
    s0 = S(1, 1, 64)
    print('refilled:')
    for Ny in [72, 80, 96]:
        print('  A/A0 = %.4f   S/S0 = %.4f' % (Ny/64, S(1, 1, Ny)/s0))
