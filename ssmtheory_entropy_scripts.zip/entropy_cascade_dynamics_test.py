#!/usr/bin/env python3
"""
Dynamical test of the exposure cascade against the SSM Part II rule.

The published Part I code (ssm_sim.py) takes P_lift as an INPUT, so the
thermal structure of lift events cannot be tested there. Here we implement
the Part II end-to-end dynamics (Algorithm 1 / Sec. 21): births proposed
wherever geometrically available and always accepted; each node dissolves
with probability dt * P_dissolve(K), where a node fails on losing K-2 of
its K bonds, at bath ratio q(beta) = 1/(1 + e^beta).

Controlled setup: frozen hexagonal layer-0 substrate (quenched, so we
isolate the physics of new-layer nucleation); dynamics acts on the layer-1
apex lattice. A layer-1 node has K = 3 (anchors) + (same-layer degree).
Births: LIFT at any vacant apex site at rate p per tau0; STITCH at any
vacant site with an occupied adjacent wedge (two mutually-adjacent occupied
neighbours -> an occupied layer-1 edge whose in-plane apex is the site) at
rate s = 1 per tau0.

Exposure class at birth (from the TS enumeration, lift_barrier_ts.py):
  E3 pioneer   -- 0 occupied same-layer neighbours (3 exposed bonds)
  E2 adjacent  -- 1 occupied neighbour              (2 exposed bonds)
  E0 covered   -- >=2 occupied neighbours / wedge-born (0 exposed)

MEASUREMENTS
  A. Mean first-passage time to a committed sheet (layer-1 occupancy >= 6)
     vs p at beta = 1.  Cascade prediction: critical nucleus = 2 lifts
     => t_nuc ~ p^-2.  Competing pictures: three-apex seed => p^-3;
     no kinetic bottleneck => p^-1.
  B. Commitment probability (node reaches same-layer degree >= 2 before
     dying) by exposure class, across a beta sweep, vs the race-model
     prediction P_commit(E3) ~ 6p / (6p + Pd(3,beta)).
"""

import numpy as np
from itertools import product

rng = np.random.default_rng(7)

# ------------------------------------------------ apex lattice on patch
R = 5
def in_patch(a, b): return max(abs(a), abs(b), abs(a+b)) <= R
sites = [(m,n) for m,n in product(range(-R-1,R+2), repeat=2)
         if in_patch(m,n) and in_patch(m+1,n) and in_patch(m,n+1)]
idx = {s:i for i,s in enumerate(sites)}
NS = len(sites)
NBR = [(1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1)]

A = np.zeros((NS,NS), dtype=np.int8)
for (m,n),i in idx.items():
    for dm,dn in NBR:
        j = idx.get((m+dm, n+dn))
        if j is not None: A[i,j] = 1

# wedges: pairs of mutually-adjacent neighbours of each site
wedge_i, wedge_j, wedge_site = [], [], []
for (m,n),i in idx.items():
    nbrs = [idx.get((m+dm,n+dn)) for dm,dn in NBR]
    nbrs = [x for x in nbrs if x is not None]
    for a in range(len(nbrs)):
        for b in range(a+1, len(nbrs)):
            if A[nbrs[a], nbrs[b]]:
                wedge_site.append(i); wedge_i.append(nbrs[a]); wedge_j.append(nbrs[b])
wedge_site = np.array(wedge_site); wedge_i = np.array(wedge_i); wedge_j = np.array(wedge_j)

def q_of(beta):  return 1.0/(1.0 + np.exp(beta))

def Pdiss_table(beta, Kmax=9):
    """node fails on losing K-2 of its K bonds (Kulkarni Eq. 19)."""
    from math import comb
    q = q_of(beta); Pd = np.zeros(Kmax+1)
    for K in range(3, Kmax+1):
        Pd[K] = sum(comb(K,j) * q**j * (1-q)**(K-j) for j in range(K-2, K+1))
    return Pd

# ------------------------------------------------ vectorized dynamics
def max_cluster(o_row):
    seen = np.zeros(NS, bool); best = 0
    occ_idx = np.where(o_row)[0]; occset = set(occ_idx.tolist())
    for s in occ_idx:
        if seen[s]: continue
        stack = [s]; seen[s] = True; size = 0
        while stack:
            u = stack.pop(); size += 1
            for v in np.where(A[u])[0]:
                if v in occset and not seen[v]:
                    seen[v] = True; stack.append(v)
        best = max(best, size)
    return best

def run_batch(ntrials, p, beta, dt, max_steps, target=6, tag_events=False,
              use_cluster=True):
    Pd = Pdiss_table(beta)
    occ   = np.zeros((ntrials, NS), dtype=bool)
    t_nuc = np.full(ntrials, np.nan)
    alive = np.ones(ntrials, dtype=bool)          # trials still pre-nucleation
    if tag_events:
        birth_t   = np.full((ntrials, NS), -1.0)
        birth_cls = np.full((ntrials, NS), -1, dtype=np.int8)
        covered   = np.zeros((ntrials, NS), dtype=bool)
        events    = []                            # (class, lifetime, committed)

    for step in range(max_steps):
        t = step * dt
        act = np.where(alive)[0]
        if len(act) == 0: break
        o = occ[act]
        nb = o.astype(np.int8) @ A                # same-layer degree

        # deaths
        K = np.clip(3 + nb, 3, 9)
        die = o & (rng.random(o.shape) < dt * Pd[K])
        if tag_events and die.any():
            ti, si = np.where(die)
            for a_, s_ in zip(ti, si):
                events.append((birth_cls[act[a_], s_],
                               t - birth_t[act[a_], s_],
                               covered[act[a_], s_]))

        # births
        vac = ~o
        lift = vac & (rng.random(o.shape) < dt * p)
        wact = o[:, wedge_i] & o[:, wedge_j]      # occupied wedges
        stitch_ok = np.zeros_like(o)
        np.logical_or.at(stitch_ok, (slice(None), wedge_site), wact)
        stitch = vac & stitch_ok & (rng.random(o.shape) < dt * 1.0)
        born = lift | stitch

        if tag_events and born.any():
            cls = np.minimum(nb, 2)               # 0->E3, 1->E2, >=2->E0
            ti, si = np.where(born)
            for a_, s_ in zip(ti, si):
                birth_t[act[a_], s_] = t
                birth_cls[act[a_], s_] = cls[a_, s_]
                covered[act[a_], s_] = False

        o = (o & ~die) | born
        occ[act] = o
        if tag_events:
            nb2 = o.astype(np.int8) @ A
            cov_now = o & (nb2 >= 2)
            covered[act] |= cov_now

        cand = o.sum(axis=1) >= target
        if use_cluster and cand.any():
            for a_ in np.where(cand)[0]:
                cand[a_] = max_cluster(o[a_]) >= target
        done = cand
        if done.any():
            t_nuc[act[done]] = t
            alive[act[done]] = False
            occ[act[done]] = False                # stop those trials
    if tag_events:
        return t_nuc, events
    return t_nuc

# ================================================ Experiment A
print("="*72)
print(f"apex lattice: {NS} sites, {len(wedge_site)} wedges, patch R={R}")
print("\nEXPERIMENT A: nucleation time vs lift rate (beta = 1)")
print("prediction: t_nuc ~ p^-2 (two-lift nucleus); alternatives p^-3, p^-1")
dt = 0.25
ps = np.array([0.003, 0.006, 0.012, 0.024, 0.048])
tmeans, tmeds = [], []
for p in ps:
    tn = run_batch(ntrials=200, p=p, beta=1.0, dt=dt, max_steps=250000)
    ok = ~np.isnan(tn)
    tmeans.append(tn[ok].mean()); tmeds.append(np.median(tn[ok]))
    print(f"  p={p:.3f}: nucleated {ok.sum():3d}/200, "
          f"mean t_nuc = {tn[ok].mean():9.1f}, median = {np.median(tn[ok]):9.1f}")
lp, lt = np.log(ps), np.log(tmeans)
slope, intercept = np.polyfit(lp, lt, 1)
resid = lt - (slope*lp + intercept)
se = np.sqrt(resid.var(ddof=2) / ((lp - lp.mean())**2).sum())
# also local slopes to expose curvature (lambda_peer ~ Pd3 at large p)
loc = np.diff(lt)/np.diff(lp)
print(f"  global log-log slope = {slope:.3f} +/- {se:.3f}")
print(f"  local slopes (small->large p): {np.round(loc,2)}")
print(f"  race-model note: pure p^-2 requires 6p << Pd(3)={Pdiss_table(1.0)[3]:.3f};"
      f" at p=0.048, 6p={6*0.048:.2f} -> expect flattening at the top end")

# ================================================ Experiment B
print("\nEXPERIMENT B: commitment by exposure class across beta")
print("class: E3 pioneer (3 exposed), E2 adjacent (2), E0 covered (0)")
for beta in (0.6, 1.0, 1.5, 2.0):
    tn, ev = run_batch(ntrials=40, p=0.012, beta=beta, dt=dt,
                       max_steps=60000, target=10**9, tag_events=True)
    ev = [e for e in ev if e[0] >= 0]
    out = {}
    for c in (0,1,2):
        sel = [e for e in ev if e[0] == c]
        if sel:
            life = np.mean([e[1] for e in sel])
            com  = np.mean([e[2] for e in sel])
            out[c] = (len(sel), life, com)
    Pd = Pdiss_table(beta)
    race = 6*0.012 / (6*0.012 + Pd[3])
    lbl = {0:"E3", 1:"E2", 2:"E0"}
    line = "  ".join(f"{lbl[c]}: n={out[c][0]:5d} life={out[c][1]:6.2f} "
                     f"P_com={out[c][2]:.3f}" for c in out)
    print(f"  beta={beta:.1f}  {line}")
    print(f"           race-model P_commit(E3) ~ {race:.3f}   "
          f"[Pd(3)={Pd[3]:.3f}, Pd(4)={Pd[4]:.3f}, Pd(5)={Pd[5]:.3f}]")
