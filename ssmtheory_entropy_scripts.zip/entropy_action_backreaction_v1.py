#!/usr/bin/env python3
"""
The gravity-from-entropy action evaluated on the FCC CSS-code complex.

Reproduces the three results of the "entropic action on the complex" section:

  (1) closed form   L(Phi) = -ln(1 + alpha*lambda) - ln(1 + alpha*m^2)
      for any eigenmode of the Hodge Laplacian, checked against the brute-force
      256x256 matrix logarithm;
  (2) stationarity of the exact relative entropy reproduces the dressed field
      equation, with the G-dressing appearing as two scalar factors;
  (3) the harmonic sector solves the full nonlinear self-consistent equation
      exactly, at m = 0, with back-reaction included.

Usage:  python3 entropy_action_backreaction_v1.py [L]     (default 4)

Requires numpy only.  L = 4 runs in seconds; L = 6 needs a few minutes and
about 2 GB (the graded space has 4L^3 dimensions).
"""
from __future__ import annotations
import sys
import numpy as np

NN = [(1, 1, 0), (1, -1, 0), (-1, 1, 0), (-1, -1, 0),
      (1, 0, 1), (1, 0, -1), (-1, 0, 1), (-1, 0, -1),
      (0, 1, 1), (0, 1, -1), (0, -1, 1), (0, -1, -1)]
AX = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]


# ------------------------------------------------------------------ complex

def build(L):
    """Nodes (even parity), edges (12 nearest neighbours), octahedral cells."""
    nodes, nidx = [], {}
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x + y + z) % 2 == 0:
                    nidx[(x, y, z)] = len(nodes)
                    nodes.append((x, y, z))
    edges, eidx = [], {}
    for i, (x, y, z) in enumerate(nodes):
        for d in NN:
            j = nidx[((x + d[0]) % L, (y + d[1]) % L, (z + d[2]) % L)]
            if i < j:
                eidx[(i, j)] = len(edges)
                edges.append((i, j))
    octs = []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x + y + z) % 2 == 1:
                    octs.append([nidx[((x + d[0]) % L, (y + d[1]) % L,
                                       (z + d[2]) % L)] for d in AX])
    return nodes, edges, eidx, octs


def edge_sign(eidx, u, v):
    if (u, v) in eidx:
        return eidx[(u, v)], 1
    return eidx[(v, u)], -1


def boundaries(L):
    """Signed boundary maps, with the translation-covariant lift of the
    octahedral stabilizers into three oriented equatorial 4-cycles."""
    nodes, edges, eidx, octs = build(L)
    ne, nn, no = len(edges), len(nodes), len(octs)
    d1 = np.zeros((nn, ne))
    for k, (i, j) in enumerate(edges):
        d1[i, k], d1[j, k] = -1, +1
    d2 = np.zeros((ne, no))
    for oi, vs in enumerate(octs):
        px, mx, py, my, pz, mz = vs
        for sq in ((px, py, mx, my), (px, pz, mx, mz), (py, pz, my, mz)):
            for a, b in zip(sq, sq[1:] + sq[:1]):
                k, s = edge_sign(eidx, a, b)
                d2[k, oi] += s
    return d1, d2, nn, ne, no


def dirac(L):
    """Graded Hodge-Dirac operator D = d + delta on C0 + C1 + C2."""
    d1, d2, n0, n1, n2 = boundaries(L)
    assert np.abs(d1.dot(d2)).max() == 0, "chain condition failed"
    N = n0 + n1 + n2
    D = np.zeros((N, N))
    D[:n0, n0:n0 + n1] = d1
    D[n0:n0 + n1, :n0] = d1.T
    D[n0:n0 + n1, n0 + n1:] = d2
    D[n0 + n1:, n0:n0 + n1] = d2.T
    return D, (n0, n1, n2)


# ------------------------------------------------------------------ action

def M_tilde(D, phi, m2):
    """Matter operator  D|Phi><Phi|D + m^2 |Phi><Phi|  (curvature term zero
    on the unstrained lattice, where all Regge deficits vanish)."""
    dphi = D.dot(phi)
    return np.outer(dphi, dphi) + m2 * np.outer(phi, phi)


def L_bruteforce(D, phi, alpha, m2):
    """Relative entropy  Tr(g ln G^-1) = -Tr ln(I + alpha M)  by log-det."""
    G = np.eye(len(D)) + alpha * M_tilde(D, phi, m2)
    return -np.linalg.slogdet(G)[1]


def L_closed(lam, alpha, m2):
    return -np.log(1 + alpha * lam) - np.log(1 + alpha * m2)


def L_linear(lam, alpha, m2):
    return -alpha * (lam + m2)


def L_general(D, D2, phi, alpha, m2):
    dp = D.dot(phi)
    return -np.log(1 + alpha * dp.dot(dp)) - np.log(1 + alpha * m2 * phi.dot(phi))


def grad_analytic(D2, D, phi, alpha, m2):
    dp = D.dot(phi)
    A = 1 + alpha * dp.dot(dp)
    B = 1 + alpha * m2 * phi.dot(phi)
    return -2 * alpha * (D2.dot(phi) / A + m2 * phi / B)


def main(L=4):
    D, (n0, n1, n2) = dirac(L)
    N = len(D)
    D2 = D.dot(D)
    print(f"L = {L}:  graded space C0+C1+C2 = {n0}+{n1}+{n2} = {N}")
    print(f"  D self-adjoint            : {np.allclose(D, D.T)}")
    w, V = np.linalg.eigh(D2)
    nz = int((np.abs(w) < 1e-9).sum())
    print(f"  zero modes of D^2         : {nz}  (b0+b1+b2 = {2 + 2*L**3 + 2})")

    print("\n(1) closed form vs brute-force matrix logarithm,  m^2 = 0.3")
    m2 = 0.3
    print(f"    {'lambda':>9} {'alpha':>7} {'brute force':>15} {'closed form':>15}"
          f" {'linearized':>12} {'lin. error':>11}")
    idxs = []
    for target in sorted(set(np.round(w, 6))):
        if len(idxs) >= 4:
            break
        if idxs and target < 1e-6:
            continue
        idxs.append(int(np.argmin(np.abs(w - target))))
    for idx in idxs:
        phi, lam = V[:, idx], w[idx]
        for alpha in (0.01, 0.1, 1.0):
            lb = L_bruteforce(D, phi, alpha, m2)
            lc = L_closed(lam, alpha, m2)
            ll = L_linear(lam, alpha, m2)
            print(f"    {lam:>9.4f} {alpha:>7.2f} {lb:>15.10f} {lc:>15.10f}"
                  f" {ll:>12.6f} {abs((ll - lb) / lb):>10.1%}")

    print("\n(2) stationarity of the exact action vs the dressed field equation")
    rng = np.random.RandomState(0)
    for t in range(3):
        phi = rng.randn(N)
        alpha, m2 = 0.3, 0.7
        h = 1e-6
        gn = np.empty(N)
        for i in range(N):
            e = np.zeros(N)
            e[i] = h
            gn[i] = (L_general(D, D2, phi + e, alpha, m2)
                     - L_general(D, D2, phi - e, alpha, m2)) / (2 * h)
        ga = grad_analytic(D2, D, phi, alpha, m2)
        print(f"    trial {t}: max|numeric - analytic| = {np.abs(gn - ga).max():.3e}"
              f"   relative = {np.abs(gn - ga).max() / np.abs(ga).max():.2e}")
    print("    => D^2 Phi/(1 + a|D Phi|^2) + m^2 Phi/(1 + a m^2 |Phi|^2) = 0")

    print("\n(3) back-reaction: harmonic modes in the full nonlinear equation")
    harm = [i for i in range(N) if abs(w[i]) < 1e-9]
    alpha = 0.3
    for m2 in (0.0, 0.5):
        res = []
        for i in harm[:20]:
            phi = V[:, i]
            dp = D.dot(phi)
            r = (D2.dot(phi) / (1 + alpha * dp.dot(dp))
                 + m2 * phi / (1 + alpha * m2 * phi.dot(phi)))
            res.append(np.abs(r).max())
        print(f"    m^2 = {m2}: max residual over 20 harmonic modes = {max(res):.3e}")
    i = next(k for k in range(N) if w[k] > 1e-6)
    phi = V[:, i]
    dp = D.dot(phi)
    r = D2.dot(phi) / (1 + alpha * dp.dot(dp))
    print(f"    non-harmonic (lambda = {w[i]:.1f}), m^2 = 0: residual = "
          f"{np.abs(r).max():.3e}")


if __name__ == '__main__':
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
