#!/usr/bin/env python3
"""
Real-coefficient harmonic analysis of the Kulkarni FCC code complex.

Question: the [[3L^3, 2L^3+2, 3]] logical count is a GF(2) statement.
Bianconi's Dirac-Kahler matter fields are real/complex valued, governed by
D = d + delta on a chain complex. Do the 2L^3+2 logical qubits correspond
to real harmonic 1-cochains (zero modes of the Hodge Laplacian), i.e. an
extensive flat band of matter modes?

Construction:
  C_2 (octahedral voids) --d2--> C_1 (edges = qubits) --d1--> C_0 (nodes)

  d1 = signed vertex-edge incidence (edge i->j, i<j: -1 at i, +1 at j).
  d2 = integer lift of H_X. Each octahedral X-stabilizer (12 edges) is,
       mod 2, the sum of the octahedron's 3 equatorial 4-cycles (each edge
       of the skeleton lies in exactly one equatorial square). Orienting
       each square makes each column of d2 a signed 1-cycle, so
       d1 @ d2 = 0 exactly over Z -- a genuine chain complex.
       The lift is NOT canonical: each square's orientation is a sign
       choice. We test the canonical choice + random sign flips to see if
       rank(d2) is robust.

Outputs per L:
  ranks of d1, d2 over R and over GF(2); k_R = n - rk(d1) - rk(d2);
  Hodge-Laplacian zero-mode count as an independent cross-check;
  torsion diagnosis from the rank gap.
"""

import numpy as np
import itertools, sys

NN = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),
      (1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]

def build_lattice(L):
    nodes, nidx = [], {}
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z) % 2 == 0:
                    nidx[(x,y,z)] = len(nodes); nodes.append((x,y,z))
    edges, eidx = [], {}
    for i,(x,y,z) in enumerate(nodes):
        for dx,dy,dz in NN:
            nb = ((x+dx)%L,(y+dy)%L,(z+dz)%L)
            if nb in nidx:
                j = nidx[nb]
                if i < j and (i,j) not in eidx:
                    eidx[(i,j)] = len(edges); edges.append((i,j))
    octs = []   # each: center coord + list of 6 neighbour node indices keyed by axis dir
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z) % 2 == 1:
                    nb = {}
                    for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]:
                        p = ((x+d[0])%L,(y+d[1])%L,(z+d[2])%L)
                        if p in nidx: nb[d] = nidx[p]
                    if len(nb) == 6:
                        octs.append(nb)
    return nodes, nidx, edges, eidx, octs

def boundary_1(nodes, edges):
    d1 = np.zeros((len(nodes), len(edges)), dtype=np.int64)
    for e,(i,j) in enumerate(edges):
        d1[i,e] = -1; d1[j,e] = +1
    return d1

def oct_squares(nb):
    """The 3 equatorial 4-cycles of an octahedral void, as vertex cycles.
    Axes pairs: exclude one antipodal pair, alternate the other two."""
    ax = {'x': ((1,0,0),(-1,0,0)), 'y': ((0,1,0),(0,-1,0)), 'z': ((0,0,1),(0,0,-1))}
    sq = []
    for excl in 'xyz':
        rem = [a for a in 'xyz' if a != excl]
        (ap, am), (bp, bm) = ax[rem[0]], ax[rem[1]]
        cyc = [nb[ap], nb[bp], nb[am], nb[bm]]   # a+ -> b+ -> a- -> b- -> a+
        sq.append(cyc)
    return sq

def boundary_2(edges, eidx, octs, square_signs=None):
    """d2: columns are signed sums of the 3 oriented equatorial squares.
    square_signs: array (n_oct, 3) of +/-1 orientation flips (None = all +1)."""
    ne, no = len(edges), len(octs)
    d2 = np.zeros((ne, no), dtype=np.int64)
    for o, nb in enumerate(octs):
        for s, cyc in enumerate(oct_squares(nb)):
            sgn = 1 if square_signs is None else square_signs[o, s]
            for t in range(4):
                u, v = cyc[t], cyc[(t+1) % 4]
                key = (u,v) if u < v else (v,u)
                e = eidx[key]
                orient = +1 if u < v else -1   # traversal vs stored orientation
                d2[e, o] += sgn * orient
    return d2

def gf2_rank(M):
    M = (M % 2).astype(np.uint8).copy()
    r, c = M.shape; rank = 0
    for col in range(c):
        piv = None
        for row in range(rank, r):
            if M[row, col]:
                piv = row; break
        if piv is None: continue
        M[[rank, piv]] = M[[piv, rank]]
        mask = M[:, col].astype(bool); mask[rank] = False
        M[mask] ^= M[rank]
        rank += 1
    return rank

def analyse(L, n_random=6, seed=0):
    nodes, nidx, edges, eidx, octs = build_lattice(L)
    n, nn, no = len(edges), len(nodes), len(octs)
    print(f"\n=== L = {L}:  nodes {nn}, edges(qubits) {n}, octahedra {no} ===")

    d1 = boundary_1(nodes, edges)
    d2 = boundary_2(edges, eidx, octs)

    # sanity: chain complex over Z, and mod-2 reduction reproduces H_X
    assert np.all(d1 @ d2 == 0), "d1 d2 != 0 -- not a chain complex"
    wt = np.abs(d2).sum(axis=0)
    assert set(np.unique(wt)) == {12}, "columns are not weight-12 mod-2 lifts"
    print("chain complex verified: d1 @ d2 = 0 over Z; all |d2| columns weight 12")

    rk1_R  = np.linalg.matrix_rank(d1.astype(float))
    rk2_R  = np.linalg.matrix_rank(d2.astype(float))
    rk1_F2 = gf2_rank(d1)
    rk2_F2 = gf2_rank(d2)
    k_F2 = n - rk1_F2 - rk2_F2
    k_R  = n - rk1_R  - rk2_R
    print(f"rank d1:  R = {rk1_R:4d}   GF(2) = {rk1_F2:4d}")
    print(f"rank d2:  R = {rk2_R:4d}   GF(2) = {rk2_F2:4d}")
    print(f"k over GF(2) = {k_F2}   (paper: 2L^3+2 = {2*L**3+2})")
    print(f"k over R     = {k_R }   (harmonic 1-cochains, this d2 lift)")

    # independent cross-check: zero modes of the Hodge Laplacian on C_1
    L1 = d1.T.astype(float) @ d1.astype(float) + d2.astype(float) @ d2.T.astype(float)
    ev = np.linalg.eigvalsh(L1)
    tol = max(1e-9, ev.max() * 1e-12) * 100
    nzero = int((ev < tol).sum())
    gap = ev[nzero] if nzero < len(ev) else float('nan')
    print(f"Hodge Laplacian zero modes = {nzero}  (spectral gap above: {gap:.4f})")

    # robustness of the integer lift: random square orientations
    rng = np.random.default_rng(seed)
    ranks = []
    for _ in range(n_random):
        ss = rng.choice([-1, 1], size=(no, 3))
        d2r = boundary_2(edges, eidx, octs, ss)
        assert np.all(d1 @ d2r == 0)
        ranks.append(np.linalg.matrix_rank(d2r.astype(float)))
    print(f"rank d2 over R across {n_random} random sign lifts: {sorted(set(ranks))}")

    # torsion diagnosis
    even_factors = rk2_R - rk2_F2
    print(f"torsion: rk_R(d2) - rk_F2(d2) = {even_factors} even invariant factor(s)"
          f" => H_1 contains {even_factors} Z_2-type summand(s)")
    return dict(L=L, n=n, k_F2=k_F2, k_R=k_R, nzero=nzero,
                rk2_R=rk2_R, rk2_F2=rk2_F2, ranks_random=ranks)

if __name__ == "__main__":
    res4 = analyse(4)
    res6 = analyse(6, n_random=3)
    print("\n=== summary ===")
    for r in (res4, res6):
        print(f"L={r['L']}: qubits {r['n']:4d} | k_GF2 = {r['k_F2']:4d} "
              f"| k_R = {r['k_R']:4d} | Hodge zeros = {r['nzero']:4d} "
              f"| 2L^3+1 = {2*r['L']**3+1}")
