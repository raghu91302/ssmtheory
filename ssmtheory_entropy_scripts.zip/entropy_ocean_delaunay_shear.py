#!/usr/bin/env python3
"""Shear test for a sprinkled ocean joined by its Delaunay triangulation (Sec. 4.5).
Poisson points in a periodic 4D box at density 1; periodic Delaunay complex; P1 finite-element Laplacian and consistent mass
matrix built from edge lengths only (as in Regge calculus). The metric g = 1 + t H (H traceless, tr H^2 = 1) changes the
edge lengths while the triangulation is held fixed. f(g) = [ln det(K + mu M) - ln det M]/N; covariance requires K + kappa1 = 0,
with K = d^2 f/dt^2 and kappa1 = df/d(tr h).
Usage: python3 entropy_ocean_delaunay_shear.py L nsamples [t]"""
import numpy as np, itertools
from scipy.spatial import Delaunay
def periodic_delaunay(X,L,margin=2.5,A=None):
    N=len(X); offs=np.array(list(itertools.product((-1,0,1),repeat=4)))
    P=[];O=[];I=[]
    for o in offs:
        Y=X+L*o; m=np.all((Y>-margin)&(Y<L+margin),1); P.append(Y[m]); O.append(np.repeat(o[None],m.sum(),0)); I.append(np.nonzero(m)[0])
    P=np.concatenate(P); O=np.concatenate(O); I=np.concatenate(I)
    T=Delaunay(P if A is None else P@A.T).simplices
    # keep simplices whose vertex with the smallest original index has offset 0 (one representative per periodic class)
    oi=I[T]; k=np.argmin(oi,1); ref=O[T[np.arange(len(T)),k]]
    keep=np.all(ref==0,1)
    T=T[keep]
    # canonical key to drop duplicates: (orig indices, offsets relative to ref vertex)
    oi=I[T]; oo=O[T]-O[T[np.arange(len(T)),np.argmin(oi,1)]][:,None,:]
    key=np.concatenate([oi,oo.reshape(len(T),-1)],1); order=np.lexsort(key.T[::-1])
    key=key[order]; T=T[order]
    uniq=np.r_[True,np.any(key[1:]!=key[:-1],1)]
    T=T[uniq]
    S_idx=I[T]                      # (S,5) original vertex indices
    S_pos=P[T]                      # (S,5,4) unwrapped coordinates
    return S_idx,S_pos
def edges_of(S_idx,S_pos):
    """unique periodic edges: (i,j, dx) with dx = x_j - x_i unwrapped; and per-simplex edge index map"""
    pairs=list(itertools.combinations(range(5),2))
    a=np.array([p[0] for p in pairs]); b=np.array([p[1] for p in pairs])
    ii=S_idx[:,a]; jj=S_idx[:,b]; dx=S_pos[:,b]-S_pos[:,a]
    sw=ii>jj; ii2=np.where(sw,jj,ii); jj2=np.where(sw,ii,jj); dx2=np.where(sw[...,None],-dx,dx)
    key=np.stack([ii2.ravel(),jj2.ravel()]+[np.round(dx2.reshape(-1,4)[:,c]*1e6).astype(np.int64) for c in range(4)],1)
    uk,inv=np.unique(key,axis=0,return_inverse=True)
    E_i=uk[:,0]; E_j=uk[:,1]
    E_dx=np.zeros((len(uk),4)); E_dx[inv.ravel()]=dx2.reshape(-1,4)
    return E_i,E_j,E_dx,inv.reshape(len(S_idx),10),(a,b)
def simplex_geometry(l2,pairs):
    """l2: (S,10) squared edge lengths in the order of `pairs`. Returns volume (S,) and stiffness K (S,5,5) of P1 FEM."""
    a,b=pairs; S=len(l2); D=np.zeros((S,5,5))
    D[:,a,b]=l2; D[:,b,a]=l2
    G=0.5*(D[:,0,1:,None]+D[:,0,None,1:]-D[:,1:,1:])   # Gram of edge vectors from vertex 0
    det=np.linalg.det(G); vol=np.sqrt(np.abs(det))/24*np.sign(det)
    Gi=np.linalg.inv(G)                                   # gradients of barycentric coords: grad l_a . grad l_b = Gi_ab
    B=np.zeros((S,5,5)); B[:,1:,1:]=Gi; s=Gi.sum(2); B[:,0,1:]=-s; B[:,1:,0]=-s; B[:,0,0]=Gi.sum((1,2))
    return vol, vol[:,None,None]*B

import scipy.sparse as sp
from scipy.sparse.linalg import splu
def assemble_scalar(S_idx,vol,K,N):
    r=np.repeat(S_idx,5,1).ravel(); c=np.tile(S_idx,(1,5)).ravel()
    Ks=sp.coo_matrix((K.ravel(),(r,c)),shape=(N,N)).tocsc()
    Mloc=vol[:,None,None]*(np.ones((5,5))+np.eye(5))/30.0        # P1 consistent mass in 4D: |s|(1+delta_ij)/((n+1)(n+2))
    Ms=sp.coo_matrix((Mloc.ravel(),(r,c)),shape=(N,N)).tocsc()
    return Ks,Ms
def logdet(A):
    lu=splu(A.tocsc(),permc_spec='MMD_AT_PLUS_A'); d=lu.U.diagonal(); return np.sum(np.log(np.abs(d)))

if __name__=='__main__':
    import sys
    L=int(sys.argv[1]); nsamp=int(sys.argv[2]); t=float(sys.argv[3]) if len(sys.argv)>3 else 0.02; mu=0.02
    H=np.zeros((4,4)); H[0,1]=H[1,0]=1/np.sqrt(2); I=np.eye(4); res=[]
    for sd in range(nsamp):
        rng=np.random.default_rng(100+sd); N=L**4; X=rng.random((N,4))*L
        S_idx,S_pos=periodic_delaunay(X,L); E_i,E_j,E_dx,emap,pairs=edges_of(S_idx,S_pos)
        vt=None
        def f(gm):
            l2=np.einsum('ma,ab,mb->m',E_dx,gm,E_dx)[emap]; vol,K=simplex_geometry(l2,pairs)
            if np.any(vol<=0): raise RuntimeError('degenerate simplex')
            Ks,Ms=assemble_scalar(S_idx,vol,K,N); return (logdet(Ks+mu*Ms)-logdet(Ms))/N
        f0=f(I); Ksh=(f(I+t*H)+f(I-t*H)-2*f0)/t**2; k1=(f((1+t)*I)-f((1-t)*I))/(2*t)/4
        res.append(Ksh+k1); print('sample %d: %d simplices, volume %.6f; K %.4f kappa1 %.4f K+kappa1 %.4f'%(sd,len(S_idx),
              simplex_geometry(np.sum(E_dx**2,1)[emap],pairs)[0].sum(),Ksh,k1,Ksh+k1),flush=True)
    r=np.array(res); print('K+kappa1 = %.4f +- %.4f (covariant value 0)'%(r.mean(),r.std()/np.sqrt(len(r)) if len(r)>1 else 0))
