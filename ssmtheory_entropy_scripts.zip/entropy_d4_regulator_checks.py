#!/usr/bin/env python3
"""Robustness checks for entropy_d4_regulator.py (scalar field).
(1) Freedom in the nearest-neighbor bond weights (null space of the weight-to-tensor map) barely changes K.
(2) Adding next-nearest-neighbor couplings, at any strength that keeps the lattice action positive, gives K between
    about 0.30 (strong negative next-nearest coupling) and 0.48; it never reaches 1/4.
(3) An ideal isotropic hard cutoff with a fixed number of modes gives K = 5/12, against the covariant value 1/4.
(4) A dispersion tuned flat at the cutoff is covariant (K = 1/4); detuning it breaks this. So covariance with a fixed
    number of modes is possible in principle but needs tuning, which none of the lattice actions tested provides."""
import numpy as np, itertools
E1=np.array([s*np.eye(4)[a]+t*np.eye(4)[b] for a,b in itertools.combinations(range(4),2) for s in (1,-1) for t in (1,-1)],float)   # 24 roots, |e|^2=2
E2=np.array([2*s*np.eye(4)[a] for a in range(4) for s in (1,-1)]+[np.array(v,float) for v in itertools.product((1,-1),repeat=4)])   # 2nd shell, |e|^2=4
N=16; g1=(np.arange(N)+0.5)/N*2*np.pi-np.pi
K=np.stack(np.meshgrid(g1,g1,g1,g1,indexing='ij'),-1).reshape(-1,4)
def setup(E): return 1-np.cos(K@E.T), np.einsum('ja,jb->jab',E,E).reshape(len(E),16)
C1,A1=setup(E1); C2,A2=setup(E2)
I=np.eye(4); H=np.diag([1,-1,1,-1.])/2; d=0.02
def wsolve(A,target,w0):  # minimum-norm change with sum w e e^T = target
    return w0+np.linalg.lstsq(A.T,(target-(A.T@w0).reshape(4,4)).reshape(16),rcond=None)[0]
# (2) null-space freedom at O(h) for the NN scalar: add lam * n(h) with n in null space of A1^T, chosen randomly but linear in h
ns=np.linalg.svd(A1.T)[2][10:]       # 2 null vectors (12 pairs ->24 roots counts both signs: null dim 14)
print('null space dim of NN weights:',24-np.linalg.matrix_rank(A1.T))
rng=np.random.default_rng(0); Lmap=rng.normal(size=(ns.shape[0],16))
def fs_nn(g,lam):
    w=wsolve(A1,np.linalg.inv(g),np.full(24,1/12.))
    hvec=(g-I).reshape(16); w=w+lam*(ns.T@(Lmap@hvec))
    return np.mean(np.log(C1@w))
for lam in (0,0.05,0.2):
    print('NN scalar, extra null-space weights lam=%.2f: K=%.4f'%(lam,(fs_nn(I+d*H,lam)-2*fs_nn(I,lam)+fs_nn(I-d*H,lam))/d**2))
# (3) NN + NNN scalar: fraction x of the long-wavelength tensor carried by the second shell
def fs_mix(g,x):
    gi=np.linalg.inv(g)
    w1=wsolve(A1,(1-x)*gi,np.full(24,(1-x)/12.)); w2=wsolve(A2,x*gi,np.full(24,x/(np.trace(A2.T@np.ones(24)).real/4 if False else 1)))
    return np.mean(np.log(C1@w1+C2@w2))
# normalize w2 base: sum over 2nd shell e e^T = c*I
c2=np.einsum('ja,jb->ab',E2,E2)[0,0]; c1=np.einsum('ja,jb->ab',E1,E1)[0,0]
def fs_mix(g,x):
    gi=np.linalg.inv(g)
    w1=wsolve(A1,(1-x)*gi,np.full(24,(1-x)/c1)); w2=wsolve(A2,x*gi,np.full(len(E2),x/c2))
    return np.mean(np.log(C1@w1+C2@w2))
for x in (0,0.25,0.5,0.75,1.0,-0.25,-0.5):
    print('NN+NNN scalar, NNN fraction x=%+.2f: K=%.4f'%(x,(fs_mix(I+d*H,x)-2*fs_mix(I,x)+fs_mix(I-d*H,x))/d**2))
print('--- extreme NNN fractions (Q must stay positive)')
for x in (-1.0,-2.0,-5.0,-20.0,-100.0,1.5,2.0,3.0):
    try:
        w1=wsolve(A1,(1-x)*I,np.full(24,(1-x)/c1)); w2=wsolve(A2,x*I,np.full(len(E2),x/c2)); Q=C1@w1+C2@w2
        if Q.min()<=0: print('x=%+.1f: lattice action not positive (min Q=%.3g)'%(x,Q.min())); continue
        print('x=%+.1f: K=%.4f'%(x,(fs_mix(I+d*H,x)-2*fs_mix(I,x)+fs_mix(I-d*H,x))/d**2))
    except Exception as ex: print(x,ex)
# ideal hard cutoff with a fixed number of modes: Q = k^T g^{-1} k over a coordinate ball -> 5/12 analytically
rng=np.random.default_rng(3); X=rng.normal(size=(400000,4)); X*= (rng.random(400000)**0.25/np.linalg.norm(X,axis=1))[:,None]
f=lambda g: np.mean(np.log(np.einsum('ma,ab,mb->m',X,np.linalg.inv(g),X)))
print('ideal isotropic hard cutoff, fixed modes: K=%.4f (analytic 5/12=0.4167)'%((f(I+d*H)-2*f(I)+f(I-d*H))/d**2))
# (4) covariance is possible in principle with a fixed number of modes: a dispersion flat at the cutoff.
#     Q = s F(x/s), x = k^T g^{-1} k on the coordinate ball, s = (det g)^(-1/4), F(y) = y(2 - y) (slope zero at y = 1).
def fflat(g,ym=1.0):
    s=np.linalg.det(g)**-0.25; x=np.einsum('ma,ab,mb->m',X,np.linalg.inv(g),X)*ym
    return np.mean(np.log(s*(x/s)*(2-x/s)))
for ym in (1.0,1.2):
    print('flat-at-cutoff dispersion (cutoff at y=%.1f): K=%.4f, slope=%.4f (covariant: K = -slope = 0.25)'%(ym,(fflat(I+d*H,ym)-2*fflat(I,ym)+fflat(I-d*H,ym))/d**2,(fflat((1+d)*I,ym)-fflat((1-d)*I,ym))/(2*d)/4))
