"""Route C (Sec. 8.5): entanglement equilibrium of the solved trapped-node slice, ball by ball.
Usage: python3 entropy_routeC_equilibrium.py L Rw q     (paper: 16 7.6 0.01)
Each tetrahedron carries the constant metric g_T fixed exactly by its six edge lengths (e^T g_T e = l^2).
Area of a coordinate sphere: dA = sqrt(det g) sqrt(n^T g^-1 n) dA_flat; volume: dV = sqrt(det g) dV_flat.
Equilibrium (rule a): dA|_V = A - A_flat(V) = -8 pi G dK, 8 pi G dK = q sum_spokes int_{in B} (R^2-r^2)/(2R) dl.
At linear order a coordinate sphere is as good as a geodesic one (shape changes at fixed volume cost no area)."""
import sys, numpy as np
import entropy_id_solve as S
from scipy.optimize import least_squares
from scipy.spatial import cKDTree
L=int(sys.argv[1]); Rw=float(sys.argv[2]); q=float(sys.argv[3])
C=S.setup(L); free,idx,A_,Sp,sp_e=S.build(C,Rw)
sol=least_squares(S.residual,np.ones(free.sum()),args=(C,free,A_,sp_e,q),jac_sparsity=Sp,method='trf',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=200)
psi=np.ones(C['nv']); psi[free]=sol.x; l=S.lengths(C,psi)
E=np.array(C['E']); tedge=np.array(C['tedge']); dv=C['dv']
tv=np.array([sorted(set(E[t].ravel())) for t in tedge])
X=dv[tv]; X=X[:,:1]+((X-X[:,:1]+L/2)%L-L/2)               # unwrap each tetrahedron (minimum image)
keep=np.linalg.norm(X.mean(1),axis=1)<Rw+1                # tetrahedra near the source region
tv=tv[keep]; tedge=tedge[keep]; X=X[keep]
# metric per tet: for each edge (a,b) of the tet, e=X_b-X_a, e^T g e = l^2  -> 6 linear equations in 6 unknowns
eid={tuple(sorted(e)):k for k,e in enumerate(map(tuple,E))}
pairs=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
Mrows=np.zeros((len(tv),6,6)); rhs=np.zeros((len(tv),6))
for j,(a,b) in enumerate(pairs):
    e=X[:,b]-X[:,a]
    Mrows[:,j]=np.stack([e[:,0]**2,e[:,1]**2,e[:,2]**2,2*e[:,0]*e[:,1],2*e[:,0]*e[:,2],2*e[:,1]*e[:,2]],1)
    rhs[:,j]=np.array([l[eid[tuple(sorted((tv[t,a],tv[t,b])))]] for t in range(len(tv))])**2
gv=np.linalg.solve(Mrows,rhs[...,None])[...,0]
G=np.zeros((len(tv),3,3)); G[:,0,0],G[:,1,1],G[:,2,2]=gv[:,0],gv[:,1],gv[:,2]
G[:,0,1]=G[:,1,0]=gv[:,3]; G[:,0,2]=G[:,2,0]=gv[:,4]; G[:,1,2]=G[:,2,1]=gv[:,5]
detG=np.linalg.det(G); Ginv=np.linalg.inv(G)
cen=X.mean(1); tree=cKDTree(cen)
Binv=np.linalg.inv(np.transpose(X[:,1:]-X[:,:1],(0,2,1)))   # barycentric solve
def locate(P):
    _,cand=tree.query(P,k=80); out=-np.ones(len(P),int)
    for j in range(cand.shape[1]):
        t=cand[:,j]; lam=np.einsum('pij,pj->pi',Binv[t],P-X[t,0]); ok=(lam.min(1)>-1e-7)&(lam.sum(1)<1+1e-7)&(out<0)
        out[ok]=t[ok]
    if (out<0).any(): print('unlocated',(out<0).sum(),P[out<0][:3]); raise SystemExit
    return out
def fib(n):
    i=np.arange(n)+0.5; th=np.arccos(1-2*i/n); ph=np.pi*(1+5**0.5)*i
    return np.c_[np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)]
NS=30000; U=fib(NS); xr,wr=np.polynomial.legendre.leggauss(32)
def sphere_AV(R,c):
    P=c+R*U; t=locate(P); fac=np.sqrt(detG[t]*np.einsum('pi,pij,pj->p',U,Ginv[t],U))
    A=4*np.pi*R*R*fac.mean()
    V=0
    for x,w in zip(xr,wr):
        r=R*(x+1)/2; t=locate(c+r*U); V+=w*R/2*4*np.pi*r*r*np.sqrt(detG[t]).mean()
    # flat reference with the same quadrature
    A0=4*np.pi*R*R; V0=sum(w*R/2*4*np.pi*(R*(x+1)/2)**2 for x,w in zip(xr,wr))
    return A,V,A0,V0
spk=[(E[k],k) for k in sp_e]
def spoke_weight(R,c):
    tot=0
    for (u,v),k in spk:
        a,b=dv[u]-c,dv[v]-c; ts=(np.arange(2000)+0.5)/2000; r=np.linalg.norm(a[None]+ts[:,None]*(b-a)[None],axis=1)
        tot+=np.where(r<R,(R*R-r*r)/(2*R),0).mean()*l[k]
    return tot
print('L=%d Rw=%.1f q=%g resid %.1e'%(L,Rw,q,np.abs(S.residual(sol.x,C,free,A_,sp_e,q)).max()))
print('  R    dA|_V         -8piG dK      ratio')
for R in [1.5,2.5,3.5,4.5,5.5]:
    A,V,A0,V0=sphere_AV(R,np.zeros(3)); dA=A-A0*(V/V0)**(2/3); pred=-q*spoke_weight(R,np.zeros(3))
    print(' %.1f  %+.5e  %+.5e  %.4f'%(R,dA,pred,dA/pred),flush=True)
print('  source-free balls, R=2:')
for c in ([4,0,0],[0,4.2,0.3],[2.8,2.8,0.4],[-2.6,2.1,1.9]):
    c=np.array(c,float); A,V,A0,V0=sphere_AV(2.0,c); dA=A-A0*(V/V0)**(2/3)
    print('   center %s: dA|_V %+.2e  (A-A0 %+.2e)'%(c,dA,A-A0),flush=True)
