"""Discrete lapse variation of the four-dimensional Regge action (check of the vertex constraint).
A solved time-symmetric slice is extended to a static 4D complex: K layers in time, periodic, each
tetrahedron x [t,t+dt] split into four 4-simplices by the staircase rule (global vertex order).
Edge lengths: spatial l_e (the slice), vertical N_v dt, diagonals sqrt(l_uv^2 + (dt (N_u+N_v)/2)^2).
S(N) = sum over triangles of area * deficit (Euclidean).  Prediction from the Schlaefli identity:
dS/dN_v = K dt/2 * sum_{e at v} l_e delta_e  (the vertical hinges' areas l_e dt (N_u+N_v)/2 carry
the slice deficit delta_e).  We compare a central difference of S with this, node by node.
Run: python3 entropy_lapse_variation.py L Rw q K dt     [amp]   (paper: 8 3.6 0.1 3 0.02 ; 8 3.6 1.0 3 0.02 ; 8 3.6 1.0 3 0.04 0.05 ; 8 3.6 1.0 3 0.02 0.05)"""
import sys, numpy as np
import entropy_defect_intrinsic as I, entropy_id_solve as R
from scipy.optimize import least_squares
L=int(sys.argv[1]); Rw=float(sys.argv[2]); q=float(sys.argv[3]); K=int(sys.argv[4]); dt=float(sys.argv[5]); amp=float(sys.argv[6]) if len(sys.argv)>6 else 0.0
C=R.setup(L); free,idx,A,S,sp_e=R.build(C,Rw)
z=np.ones(free.sum())
for qq in np.linspace(q/4,q,4):
    z=least_squares(R.residual,z,args=(C,free,A,sp_e,qq),jac_sparsity=S,method='trf',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=200).x
psi=np.ones(C['nv']); psi[free]=z; l=R.lengths(C,psi); d3=I.deficits(l,C['tedge'],C['nE'])
print(f"slice: L={L} q={q} constraint residual {np.abs(R.residual(z,C,free,A,sp_e,q)).max():.1e}")
nv=C['nv']; E=C['E']; eidx={tuple(sorted(e)):k for k,e in enumerate(E)}
_,_,tets,_,_,_,_,_=I.build_complex(L)
# 4-simplices
simp=[]
for T in tets:
    a,b,c,d=sorted(T)
    for k in range(K):
        k1=(k+1)%K; X=lambda v,kk: v+nv*kk
        simp+= [(X(a,k),X(b,k),X(c,k),X(d,k),X(d,k1)),(X(a,k),X(b,k),X(c,k),X(c,k1),X(d,k1)),
                (X(a,k),X(b,k),X(b,k1),X(c,k1),X(d,k1)),(X(a,k),X(a,k1),X(b,k1),X(c,k1),X(d,k1))]
simp=np.array(simp)
def length_fn(N):
    def ln(p,r):
        u,ku=p%nv,p//nv; v,kv=r%nv,r//nv
        if ku==kv: return l[eidx[tuple(sorted((u,v)))]]
        if u==v: return N[u]*dt
        return np.sqrt(l[eidx[tuple(sorted((u,v)))]]**2+(dt*(N[u]+N[v])/2)**2)
    return ln
pairs=[(i,j) for i in range(5) for j in range(i+1,5)]
tri=[(i,j,k) for i in range(5) for j in range(i+1,5) for k in range(j+1,5)]
# triangle ids
tkey={}; tid=np.zeros((len(simp),10),int)
for s,Sx in enumerate(simp):
    for t,(i,j,k) in enumerate(tri):
        key=tuple(sorted((Sx[i],Sx[j],Sx[k])))
        tid[s,t]=tkey.setdefault(key,len(tkey))
nT=len(tkey); print(f"4D complex: {len(simp)} simplices, {nT} triangles")
# edge-length matrix per simplex depends on N; precompute which pairs are vertical/diagonal
def dmat(N):
    ln=length_fn(N); D=np.zeros((len(simp),5,5))
    for s,Sx in enumerate(simp):
        for i,j in pairs: D[s,i,j]=D[s,j,i]=ln(Sx[i],Sx[j])
    return D
def action(N):
    D=dmat(N); D2=D**2
    G=0.5*(D2[:,0,1:,None]+D2[:,0,None,1:]-D2[:,1:,1:])        # Gram matrix of P1..P4 - P0
    P=np.zeros((len(simp),5,4)); P[:,1:,:]=np.linalg.cholesky(G+1e-300*np.eye(4))
    ang=np.zeros((len(simp),10)); area=np.zeros((len(simp),10))
    for t,(i,j,k) in enumerate(tri):
        o=[m for m in range(5) if m not in (i,j,k)]
        u=P[:,j]-P[:,i]; w=P[:,k]-P[:,i]
        B=np.stack([u,w],2); Q,_=np.linalg.qr(B)          # basis of the hinge plane
        def perp(x): return x-np.einsum('sab,sb->sa',Q,np.einsum('sba,sb->sa',Q,x))
        x=perp(P[:,o[0]]-P[:,i]); y=perp(P[:,o[1]]-P[:,i])
        cs=np.einsum('sa,sa->s',x,y)/np.linalg.norm(x,axis=1)/np.linalg.norm(y,axis=1)
        ang[:,t]=np.arccos(np.clip(cs,-1,1))
        area[:,t]=0.5*np.sqrt(np.maximum(np.einsum('sa,sa->s',u,u)*np.einsum('sa,sa->s',w,w)-np.einsum('sa,sa->s',u,w)**2,0))
    tot=np.zeros(nT); np.add.at(tot,tid.ravel(),ang.ravel())
    A=np.zeros(nT); A[tid.ravel()]=area.ravel()
    return np.sum(A*(2*np.pi-tot)), 2*np.pi-tot, A
N0=1-amp/np.maximum(C['r'],0.5); S0,def4,A4=action(N0)   # amp>0: non-uniform lapse test
print(f"S(N=1) = {S0:.6e};  K*dt*sum_e l_e delta_e = {K*dt*np.sum(l*d3):.6e}")
inv={v:k for k,v in tkey.items()}
def is_trap(t):
    sp=set(x%nv for x in t); return len(sp)==2      # two spatial nodes: half of an edge x time trapezoid
trap=np.array([is_trap(inv[i]) for i in range(nT)])
print(f"max |deficit| on trapezoid hinges {np.degrees(np.abs(def4[trap]).max()):.3f} deg (slice max {np.degrees(np.abs(d3).max()):.3f}); on all other hinges {np.degrees(np.abs(def4[~trap]).max()):.2e} deg")
r=C['r']; test=[C['cdef']]+[v for v in np.argsort(r)[1:40:6]]
maxdev=0; scale=0
h=1e-5
print(" node      r     dS/dN_v (numerical)    K dt/2 * sum_{e at v} l_e delta_e    16 pi G m_v * K dt/2")
Ld=A@(l*d3); m=np.zeros(nv)
for k in sp_e: m[C['Eu'][k]]+=q*l[k]/2; m[C['Ev'][k]]+=q*l[k]/2
for v in test:
    Np=N0.copy(); Np[v]+=h; Nm=N0.copy(); Nm[v]-=h
    g=(action(Np)[0]-action(Nm)[0])/(2*h)
    print(f"{v:5d}  {r[v]:5.2f}   {g:+.8e}          {K*dt/2*Ld[v]:+.8e}              {K*dt/2*2*m[v]:+.8e}")
    maxdev=max(maxdev,abs(g-K*dt/2*Ld[v])); scale=max(scale,abs(K*dt/2*Ld[v]))
print(f"largest |numerical - predicted| = {maxdev:.2e}, relative to the largest prediction {maxdev/scale:.1e}")
