#!/usr/bin/env python3
"""Hybridization of the trapped node with the harmonic band: diagonalize L1 on the
defected complex (one node, four spokes, no new 2-cells) and compare with the vacuum."""
import sys, numpy as np
from entropy_fcc_real_harmonic import build_lattice, boundary_1, boundary_2
from entropy_defect_intrinsic import wrapd
def run(L):
    nodes,nidx,edges,eidx,octs=build_lattice(L)
    n0,n1=len(nodes),len(edges)
    d1=boundary_1(nodes,edges).astype(float); d2=boundary_2(edges,eidx,octs).astype(float)
    L1=d1.T@d1+d2@d2.T; w=np.linalg.eigvalsh(L1); b1v=int((w<1e-9).sum()); gapv=w[w>1e-9].min()
    c=(0.5,0.5,0.5); bnd=[i for i,p in enumerate(nodes) if abs(wrapd(c,p,L)-np.sqrt(3)/2)<1e-9]
    # extend: node n0 = trapped node; four spokes edges n1..n1+3 oriented n0 -> vertex
    D1=np.zeros((n0+1,n1+4)); D1[:n0,:n1]=d1
    for k,v in enumerate(bnd): D1[n0,n1+k]=-1; D1[v,n1+k]=1
    D2=np.zeros((n1+4,d2.shape[1])); D2[:n1,:]=d2
    L1d=D1.T@D1+D2@D2.T; wd,V=np.linalg.eigh(L1d); b1d=int((wd<1e-9).sum())
    idx=np.where(wd>1e-9)[0][0]; v=V[:,idx]; wsp=np.sum(v[n1:]**2); ipr=1/np.sum(v**4)
    print(f"L={L}: b1 vacuum {b1v} (2L^3+2={2*L**3+2}), b1 defect {b1d}, change {b1d-b1v}; "
          f"kernel residual {np.abs(L1d@V[:,:b1d]).max():.1e}")
    print(f"      gap vacuum {gapv:.4f} (8(1-cos2pi/L)={8*(1-np.cos(2*np.pi/L)):.4f}), gap defect {wd[idx]:.4f}; "
          f"lowest dispersive mode: weight on 4 spokes {wsp:.3f} (uniform {4/(n1+4):.4f}, x{wsp/(4/(n1+4)):.0f}), IPR {ipr:.1f} of {n1+4}")
for L in (4,6,8): run(L)   # L=10 with a sparse shift-invert eigsh takes a few minutes
