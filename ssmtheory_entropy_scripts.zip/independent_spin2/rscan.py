"""Grid convergence at the zone edges (r=1) and r=0.5, 2 at the zone edges: TT-polarization eigenvalue range."""
import numpy as np
from latlib import *
from polforms import form
from spin2 import K_both, POL_AXIS, POL_ROOT
pa, pr = np.array([np.pi,0,0,0.]), np.array([np.pi,np.pi,0,0.])
for N in (8, 12, 16, 20, 24):
    k = midgrid(N)
    out = []
    for p, H in ((pa, POL_AXIS['diag(22-33)']), (pa, POL_AXIS['off(23)']), (pr, POL_ROOT['diag(33-44)']), (pr, POL_ROOT['off(34)'])):
        out.append(m2L2(*K_both(p, H, k)))
    print(f"N={N}: axis edge diag/off {out[0]:.3f} {out[1]:.3f}   root edge diag/off {out[2]:.3f} {out[3]:.3f}", flush=True)
k = midgrid(16)
for r in (0.5, 2.0):
    for p in (pa, pr):
        KS, KF, M = form(p, k, r=r)
        ev = np.linalg.eigvalsh(M)
        print(f"r={r} p={np.round(p,2)}: eig range [{ev.min():.1f},{ev.max():.1f}] mean {ev.mean():.1f}", flush=True)
