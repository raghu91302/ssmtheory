"""Item 2: spin-2 quadratic action K(p) for scalar and Wilson-Dirac fermion (vierbein + spin connection),
then m^2 L0^2 for SSM content (28 scalar-like bosonic dof, 96 fermionic dof)."""
import numpy as np, sys
from latlib import *

def E(a, b):
    M = np.zeros((4, 4)); M[a, b] += 1; M[b, a] += 1
    return M / 2

def norm(H):
    return H / np.sqrt(np.trace(H @ H))

u = np.array([1, -1, 0, 0]) / np.sqrt(2); e3 = np.eye(4)[2]; e4 = np.eye(4)[3]
POL_AXIS = {'diag(22-33)': norm(E(1, 1) - E(2, 2)), 'off(23)': norm(E(1, 2))}
POL_ROOT = {'diag(33-44)': norm(E(2, 2) - E(3, 3)), 'off(34)': norm(E(2, 3)),
            'u.e3': norm(np.outer(u, e3) + np.outer(e3, u)), 'uu-e3e3': norm(np.outer(u, u) - np.outer(e3, e3))}

def K_both(p, H, kpts, r=1.0, order='A', use_U_wilson=True):
    for X in (H,):
        assert abs(np.trace(X)) < 1e-12 and np.allclose(X @ p, 0)
    VS = vertices('scalar', H, p)
    VF = vertices('fermion', H, p, r=r, order=order, use_U_wilson=use_U_wilson)
    return f2_kspace(VS, kpts, False), f2_kspace(VF, kpts, True)

if __name__ == '__main__':
    Ns = [int(a) for a in sys.argv[1:]] or [12, 16]
    cases = [(np.array([q, 0, 0, 0]), POL_AXIS, f'axis {q:.2f}') for q in (1e-4, np.pi / 3, 2 * np.pi / 3, np.pi)]
    cases += [(np.array([q, q, 0, 0]), POL_ROOT, f'root ({q:.2f},{q:.2f},0,0)') for q in (np.pi / 3, 2 * np.pi / 3, np.pi)]
    for N in Ns:
        k = midgrid(N)
        print(f"==== N={N} ====", flush=True)
        for p, pols, lab in cases:
            for pn, H in pols.items():
                KS, KF = K_both(p, H, k)
                print(f"{lab:22s} {pn:12s} KS={KS:.5f} KF={KF:.5f}  m2L0^2={m2L2(KS, KF):9.2f}  Regge 2phat^2={2*phat2(p):.3f}", flush=True)
