"""Item 1: uniform-strain shear response K = d^2 f/dt^2, h = tH, H traceless, tr H^2 = 1."""
import numpy as np, sys
from latlib import *

def f_scalar(g, k):
    w = weights(g)
    return np.mean(np.log((1 - np.cos(k @ E24.T)) @ w))

def f_fermion(g, k, r, variant):
    w = weights(g); d18 = np.linalg.det(g) ** 0.125
    ek = k @ E24.T
    Q = (1 - np.cos(ek)) @ w
    if variant == 'fixed':      # fixed hopping w0, metric via inverse vierbein g^{-1/2}
        s = (np.sin(ek) * W0) @ E24 @ symsqrt(g, -0.5)
    else:                       # weighted / vierbein: n_j = g^{1/2} e_j with scalar weights
        s = (np.sin(ek) * w) @ E24 @ symsqrt(g, 0.5)
    # det_4 of (i gamma.s + m) = (s^2 + m^2)^2
    return 0.5 * np.mean(2 * np.log(np.sum(s * s, 1) + (r * d18 * Q) ** 2))

def Kfd(f, H, h=0.02):
    I = np.eye(4)
    return (f(I + h * H) + f(I - h * H) - 2 * f(I)) / h ** 2

H1 = np.diag([1, -1, 0, 0]) / np.sqrt(2)
H2 = np.zeros((4, 4)); H2[0, 1] = H2[1, 0] = 1 / np.sqrt(2)
if __name__ == '__main__':
    for N in (16, 20, 24):
        k = midgrid(N)
        out = [Kfd(lambda g: f_scalar(g, k), H) for H in (H1, H2)]
        out += [Kfd(lambda g: f_fermion(g, k, 1.0, 'weighted'), H) for H in (H1, H2)]
        print(f"N={N}  scalar K(diag,offdiag)={out[0]:.5f},{out[1]:.5f}  fermion r=1 vierbein K={out[2]:.5f},{out[3]:.5f}", flush=True)
        # kappa1 check
        lam = 1.01
        print("   kappa1 scalar:", (f_scalar(lam * np.eye(4), k) - f_scalar(np.eye(4), k)) / (4 * (lam - 1)),
              " fermion:", (f_fermion(lam * np.eye(4), k, 1, 'weighted') - f_fermion(np.eye(4), k, 1, 'weighted')) / (4 * (lam - 1)))
    k = midgrid(20)
    for var in ('fixed', 'weighted'):
        for r in (0.1, 0.25, 0.5, 1, 2, 4):
            a = Kfd(lambda g: f_fermion(g, k, r, var), H1); b = Kfd(lambda g: f_fermion(g, k, r, var), H2)
            print(f"{var:9s} r={r:4}: K = {a:.4f} (diag)  {b:.4f} (offdiag)", flush=True)
