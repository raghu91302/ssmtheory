"""Checks: (1) spinor curvature of the code's spin connection vs Riemann tensor, both signs;
(2) exact-wave geometry vs numerical derivatives; (3) momentum-space second-order term vs finite differences
of exact real-space log-determinants on a 6^4 (antiperiodic) D4 lattice."""
import numpy as np, sys
from latlib import *
from spin2 import POL_AXIS, POL_ROOT, norm, E

rng = np.random.default_rng(1)

def rand_sym(scale):
    X = rng.normal(size=(4, 4)); return scale * (X + X.T) / 2

S1, S2, S3 = rand_sym(0.15), rand_sym(0.15), rand_sym(0.1)
q1, q2 = rng.normal(size=4), rng.normal(size=4)
def gfun(y):
    return np.eye(4) + S1 * np.cos(q1 @ y) + S2 * np.sin(q2 @ y + 0.3) + S3

def christ_at(y, h=1e-5):
    g = gfun(y); dg = np.array([(gfun(y + h * np.eye(4)[l]) - gfun(y - h * np.eye(4)[l])) / (2 * h) for l in range(4)])
    return christoffel(np.linalg.inv(g), dg)

def curvature_check(sign=+1):
    y0 = rng.normal(size=4)
    def A(y):
        g, om = local_geom_numeric(gfun, y, h=1e-5)
        return sign * A_from_omega(om)
    h = 1e-4
    A0 = A(y0)
    dA = np.array([(A(y0 + h * np.eye(4)[m]) - A(y0 - h * np.eye(4)[m])) / (2 * h) for m in range(4)])
    F = np.einsum('mnij->mnij', dA[:, :, :, :]) - np.einsum('nmij->mnij', dA) \
        + np.einsum('mij,njk->mnik', A0, A0) - np.einsum('nij,mjk->mnik', A0, A0)
    Gam = christ_at(y0)
    dGam = np.array([(christ_at(y0 + h * np.eye(4)[m]) - christ_at(y0 - h * np.eye(4)[m])) / (2 * h) for m in range(4)])
    # R^r_{s m n} = d_m G^r_{n s} - d_n G^r_{m s} + G^r_{m l} G^l_{n s} - G^r_{n l} G^l_{m s};  Gam[r,m,l]
    R = np.einsum('mrns->rsmn', dGam) - np.einsum('nrms->rsmn', dGam) \
        + np.einsum('rml,lns->rsmn', Gam, Gam) - np.einsum('rnl,lms->rsmn', Gam, Gam)
    g = gfun(y0); e = symsqrt(g, 0.5); Ei = symsqrt(g, -0.5)
    Rab = np.einsum('ar,rsmn,sb->abmn', e, R, Ei)
    target = 0.25 * np.einsum('abmn,abij->mnij', Rab, GG)
    return np.max(np.abs(F - target)) / np.max(np.abs(target))

def wave_geom_check():
    B = 0.2 * norm(E(1, 2)); p = np.array([0.7, 0, 0.3, 0]); p = p  # H need not be TT for this check
    th = 0.4
    g1, om1 = local_geom_wave(B, p, th)
    g2, om2 = local_geom_numeric(lambda y: np.eye(4) + B * np.cos(p @ y + th), np.zeros(4), h=1e-5)
    return np.max(np.abs(om1 - om2))

# ---------------- real-space determinants ----------------
def realspace_lndet(field, H, p, eps, L=6, r=1.0, order='A'):
    pts = np.array([x for x in np.ndindex(*(L,) * 4) if sum(x) % 2 == 0])
    idx = {tuple(x): i for i, x in enumerate(pts)}
    ns = len(pts); d = 1 if field == 'scalar' else 4
    M = np.zeros((ns * d, ns * d), complex)
    cache = {}
    B = 2 * eps * H
    def coeff(th):
        key = round(th % (2 * np.pi), 10)
        if key not in cache:
            if field == 'scalar':
                cache[key] = scalar_coeffs(np.eye(4) + np.cos(th) * B)
            else:
                g, om = local_geom_wave(B, p, th)
                cache[key] = fermion_coeffs(g, om, r=r, order=order)
        return cache[key]
    for i, x in enumerate(pts):
        for j, ej in enumerate(E24):
            m = x + ej / 2
            T, S = coeff(p @ m)
            y = x + ej
            wraps = np.sum(np.floor_divide(y, L))
            phase = (-1.0) ** wraps          # antiperiodic in every direction
            jj = idx[tuple(np.mod(y, L).astype(int))]
            if d == 1:
                M[i, jj] += phase * T[j]; M[i, i] += S[j]
            else:
                M[4*i:4*i+4, 4*jj:4*jj+4] += phase * T[j]; M[4*i:4*i+4, 4*i:4*i+4] += S[j]
    s, ld = np.linalg.slogdet(M)
    return (np.log(s) + ld), ns

def realspace_K(field, H, p, L=6, eps=(0.02, 0.01)):
    L0, ns = realspace_lndet(field, H, p, 0.0, L)
    c = []
    for e in eps:
        Lp, _ = realspace_lndet(field, H, p, e, L); Lm, _ = realspace_lndet(field, H, p, -e, L)
        val = (Lp + Lm - 2 * L0) / (2 * e ** 2) / ns
        c.append(val.real if field == 'scalar' else 0.5 * val.real)
    return (4 * c[1] - c[0]) / 3, c

if __name__ == '__main__':
    print("curvature check, rel. error  (+ sign): %.2e   (opposite sign): %.2e" % (curvature_check(+1), curvature_check(-1)))
    print("exact-wave vs numerical spin connection max diff: %.2e" % wave_geom_check())
    k6 = midgrid(6)
    tests = [(np.array([np.pi / 3, 0, 0, 0]), POL_AXIS['off(23)']),
             (np.array([2 * np.pi / 3, 0, 0, 0]), POL_AXIS['diag(22-33)']),
             (np.array([np.pi / 3, np.pi / 3, 0, 0]), POL_ROOT['uu-e3e3']),
             (np.array([2 * np.pi / 3, 2 * np.pi / 3, 0, 0]), POL_ROOT['off(34)'])]
    for p, H in tests:
        for field in ('scalar', 'fermion'):
            V = vertices(field, H, p) if field == 'scalar' else vertices(field, H, p, r=1.0)
            kk = f2_kspace(V, k6, field == 'fermion')
            rs, raw = realspace_K(field, H, p)
            print(f"6^4 antiperiodic  p={np.round(p,3)} {field:8s}: k-space {kk:.7f}   real-space FD {rs:.7f} (raw eps=.02,.01: {raw[0]:.7f},{raw[1]:.7f})  diff {abs(kk-rs):.1e}", flush=True)
