"""Independent implementation: D4 lattice scalar and Wilson-Dirac operators in a metric background.

Conventions (from the paper's written spec only):
  e_j : 24 roots (+-1,+-1,0,0) and permutations.
  scalar   : (Q phi)(x) = sum_j w_j(m_j) [phi(x) - phi(x+e_j)],  m_j = x + e_j/2,
             sum_j w_j e_j e_j^T = g^{-1} (minimal-norm change from w0 = 1/12).
  fermion  : (D psi)(x) = sum_j T_j(m_j) psi(x+e_j) + S(x)
             T_j = w_j gamma.(g^{1/2} e_j) U_j  - r d^{1/8} w_j U_j ,  U_j = exp(e_j^mu A_mu)
             S(x) = sum_j r d^{1/8} w_j(m_j),   d = det g,  A_mu = 1/4 omega_{mu ab} g^a g^b
  Flat momentum space: Q = sum_j w (1-cos k.e),  D = i sum_j w sin(k.e) gamma.n + r d^{1/8} Q.
  Per-dof vacuum term f: scalar f = <ln Q>,  fermion f = (1/2) <ln|det_4 D|>.
"""
import numpy as np
from scipy.linalg import expm

# ---------------- lattice ----------------
def roots():
    E = []
    for a in range(4):
        for b in range(a + 1, 4):
            for sa in (1, -1):
                for sb in (1, -1):
                    v = np.zeros(4); v[a] = sa; v[b] = sb; E.append(v)
    return np.array(E)

E24 = roots()
_A = np.array([np.outer(e, e).ravel() for e in E24]).T      # 16 x 24
_Apinv = np.linalg.pinv(_A)
W0 = np.full(24, 1.0 / 12.0)
assert np.allclose(_A @ W0, np.eye(4).ravel())

def weights(g):
    gi = np.linalg.inv(g)
    w = W0 + _Apinv @ (gi.ravel() - np.eye(4).ravel())
    return w

# ---------------- gamma matrices (Euclidean, hermitian) ----------------
s1 = np.array([[0, 1], [1, 0]], complex); s2 = np.array([[0, -1j], [1j, 0]]); s3 = np.array([[1, 0], [0, -1]], complex)
I2 = np.eye(2); Z2 = np.zeros((2, 2))
GAM = np.array([np.block([[Z2, -1j * s], [1j * s, Z2]]) for s in (s1, s2, s3)] + [np.block([[Z2, I2], [I2, Z2]])])
for a in range(4):
    for b in range(4):
        assert np.allclose(GAM[a] @ GAM[b] + GAM[b] @ GAM[a], 2 * (a == b) * np.eye(4))
GG = np.einsum('aij,bjk->abik', GAM, GAM)   # gamma^a gamma^b

def symsqrt(g, power):
    lam, P = np.linalg.eigh(g)
    return (P * lam ** power) @ P.T

# ---------------- spin connection ----------------
def christoffel(ginv, dg):
    """dg[l,m,n] = d_l g_{mn}.  returns Gam[n,m,l] = Gamma^n_{m l}"""
    T = np.zeros((4, 4, 4))
    for r in range(4):
        for m in range(4):
            for l in range(4):
                T[r, m, l] = dg[m, r, l] + dg[l, r, m] - dg[r, m, l]
    return 0.5 * np.einsum('nr,rml->nml', ginv, T)

def omega_from(g, dg, E, dE):
    """omega[mu,a,b] = e_{a nu} (d_mu E_b^nu + Gamma^nu_{mu lam} E_b^lam).
    E[nu,b] = E_b^nu (= g^{-1/2}),  dE[mu,nu,b]."""
    e = symsqrt(g, 0.5)
    Gam = christoffel(np.linalg.inv(g), dg)
    om = np.empty((4, 4, 4))
    for mu in range(4):
        om[mu] = e @ (dE[mu] + Gam[:, mu, :] @ E)
    return om

def A_from_omega(om):
    return 0.25 * np.einsum('mab,abij->mij', om, GG)

# ---- generic metric field with numerical derivatives (for checks) ----
def local_geom_numeric(gfun, y, h=1e-5):
    g = gfun(y)
    dg = np.empty((4, 4, 4)); dE = np.empty((4, 4, 4))
    for l in range(4):
        d = np.zeros(4); d[l] = h
        gp, gm = gfun(y + d), gfun(y - d)
        dg[l] = (gp - gm) / (2 * h)
        dE[l] = (symsqrt(gp, -0.5) - symsqrt(gm, -0.5)) / (2 * h)
    E = symsqrt(g, -0.5)
    return g, omega_from(g, dg, E, dE)

# ---- plane wave g = I + B cos(p.y + th), exact derivatives at y=0 ----
def local_geom_wave(B, p, th):
    c, s = np.cos(th), np.sin(th)
    beta, P = np.linalg.eigh(B)
    g = np.eye(4) + c * B
    dg = np.einsum('l,mn->lmn', -p * s, B)
    E = (P * (1 + c * beta) ** -0.5) @ P.T
    dEc = (P * (-0.5 * beta * (1 + c * beta) ** -1.5)) @ P.T   # dE/dc
    dE = np.einsum('l,mn->lmn', -p * s, dEc)
    return g, omega_from(g, dg, E, dE)

# ---------------- bond coefficients ----------------
def scalar_coeffs(g):
    w = weights(g)
    return -w.astype(complex), w.astype(complex)          # hop T_j, site S_j  (scalars)

def fermion_coeffs(g, om, r, order='A', use_U_wilson=True, spin=True):
    """hop T_j (24,4,4) and site S_j (24,4,4) for one local geometry."""
    w = weights(g)
    sq = symsqrt(g, 0.5)
    d18 = np.linalg.det(g) ** 0.125
    A = A_from_omega(om) if spin else np.zeros((4, 4, 4), complex)
    T = np.empty((24, 4, 4), complex); S = np.empty((24, 4, 4), complex)
    for j, ej in enumerate(E24):
        n = sq @ ej
        gn = np.einsum('a,aij->ij', n, GAM)
        X = np.einsum('m,mij->ij', ej, A)
        if order == 'A':
            U = expm(X)
            T[j] = w[j] * gn @ U
        else:  # symmetric about the bond
            Uh = expm(0.5 * X); U = Uh @ Uh
            T[j] = w[j] * Uh @ gn @ Uh
        T[j] -= r * d18 * w[j] * (U if use_U_wilson else np.eye(4))
        S[j] = r * d18 * w[j] * np.eye(4)
    return T, S

# ---------------- vertices by finite differences in eps ----------------
def vertices(field, H, p, eps=1e-3, **kw):
    """Return dict with F0,S0 (flat), Fp,Sp (e^{+ip m}), Fm,Sm (e^{-ip m}), F2,S2 (zero-momentum 2nd order).
    Wave: g = I + 2 eps H cos(p.y + th)."""
    p = np.asarray(p, float)
    def coeffs(e, th):
        B = 2 * e * H
        if field == 'scalar':
            g = np.eye(4) + np.cos(th) * B
            T, S = scalar_coeffs(g)
            return T, S
        g, om = local_geom_wave(B, p, th)
        return fermion_coeffs(g, om, **kw)
    T0, S0 = coeffs(0.0, 0.0)
    F1 = {}; F2T = 0; F2S = 0
    for th in (0, np.pi / 2, np.pi, 1.5 * np.pi):
        Tp, Sp = coeffs(eps, th); Tm, Sm = coeffs(-eps, th)
        F1[th] = ((Tp - Tm) / (2 * eps), (Sp - Sm) / (2 * eps))
        F2T = F2T + (Tp + Tm - 2 * T0) / (2 * eps ** 2) / 4
        F2S = F2S + (Sp + Sm - 2 * S0) / (2 * eps ** 2) / 4
    a, b = F1[0], F1[np.pi / 2]
    Fp = (a[0] - 1j * b[0]) / 2; Sp_ = (a[1] - 1j * b[1]) / 2
    Fm = (a[0] + 1j * b[0]) / 2; Sm_ = (a[1] + 1j * b[1]) / 2
    return dict(T0=T0, S0=S0, Tp=Fp, Sp=Sp_, Tm=Fm, Sm=Sm_, T2=F2T, S2=F2S, p=p)

# ---------------- momentum-space second-order term ----------------
def _assemble(T, S, phase_hop, phase_site):
    """sum_j T_j phase_hop[k,j] + S_j phase_site[j]. T: (24,) or (24,4,4)."""
    if T.ndim == 1:
        return phase_hop @ T + np.sum(S * phase_site)
    return np.einsum('kj,jab->kab', phase_hop, T) + np.einsum('j,jab->ab', phase_site, S)[None]

def f2_kspace(V, kpts, fermion, chunk=20000):
    """coefficient of eps^2 in (1/Nsites) ln det (scalar) or (1/2)(1/N) Re ln det (fermion)."""
    p = V['p']
    ep = E24 @ p
    tot = 0.0; n = 0
    for i in range(0, len(kpts), chunk):
        k = kpts[i:i + chunk]
        ek = k @ E24.T
        ph0 = np.exp(1j * ek); ph1 = np.exp(1j * (ek + ep))
        phh = np.exp(1j * (ek + ep / 2))
        M0 = _assemble(V['T0'], V['S0'], ph0, np.ones(24))
        M1 = _assemble(V['T0'], V['S0'], ph1, np.ones(24))
        V2 = _assemble(V['T2'], V['S2'], ph0, np.ones(24))
        Vp = _assemble(V['Tp'], V['Sp'], phh, np.exp(0.5j * ep))   # k -> k+p
        Vm = _assemble(V['Tm'], V['Sm'], phh, np.exp(-0.5j * ep))  # k+p -> k
        if fermion:
            G0 = np.linalg.inv(M0); G1 = np.linalg.inv(M1)
            tad = np.einsum('kab,kba->k', G0, V2)
            bub = np.einsum('kab,kbc,kcd,kda->k', G0, Vm, G1, Vp)
            tot += 0.5 * np.sum((tad - bub).real)
        else:
            tot += np.sum((V2 / M0 - Vm * Vp / (M0 * M1)).real)
        n += len(k)
    return tot / n

def midgrid(N):
    x = -np.pi + 2 * np.pi * (np.arange(N) + 0.5) / N
    return np.stack(np.meshgrid(x, x, x, x, indexing='ij'), -1).reshape(-1, 4)

def fullgrid(L):
    x = 2 * np.pi * np.arange(L) / L
    return np.stack(np.meshgrid(x, x, x, x, indexing='ij'), -1).reshape(-1, 4)

def phat2(p):
    return np.sum(1 - np.cos(E24 @ np.asarray(p, float))) / 6.0

GOVERL2 = np.sqrt(2 / 3) / (4 * np.log(2))   # G/L0^2 from L_f^2 = 4 G ln2, L_f = (2/3)^{1/4} L0

def m2L2(KS, KF, nB=28, nF=96):
    ksh = 0.25 * (nB * (KS - 0.25) - nF * (KF - 0.25))
    return 128 * np.pi * ksh * GOVERL2
