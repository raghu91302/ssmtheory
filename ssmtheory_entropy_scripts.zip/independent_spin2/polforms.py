"""Full 5x5 quadratic form over the transverse-traceless polarizations at each momentum; eigenvalues of m^2 L0^2.
Also: alternative fermion transporter ordering (symmetric about the bond) and the two-polarization average used in Sec. 4.5."""
import numpy as np, sys
from latlib import *
from spin2 import E, norm, K_both

def tt_basis(p):
    p = np.asarray(p, float); n = p / np.linalg.norm(p)
    # orthonormal transverse basis
    Q, _ = np.linalg.qr(np.column_stack([n, np.eye(4)]))
    if abs(abs(n[0]) - 1) < 1e-12:
        t = [np.eye(4)[i] for i in (1, 2, 3)]
    else:
        t = [np.array([1, -1, 0, 0]) / np.sqrt(2), np.eye(4)[2], np.eye(4)[3]]
    a, b, c = t
    B = [np.outer(x, y) + np.outer(y, x) for x, y in ((a, b), (a, c), (b, c))]
    B += [np.outer(b, b) - np.outer(c, c), 2 * np.outer(a, a) - np.outer(b, b) - np.outer(c, c)]
    return [norm(X) for X in B]

def form(p, k, **kw):
    Bs = tt_basis(p); n = len(Bs)
    KS = np.zeros((n, n)); KF = np.zeros((n, n))
    for i in range(n):
        KS[i, i], KF[i, i] = K_both(p, Bs[i], k, **kw)
    for i in range(n):
        for j in range(i + 1, n):
            s1, f1 = K_both(p, Bs[i] + Bs[j], k, **kw)
            KS[i, j] = KS[j, i] = (s1 - KS[i, i] - KS[j, j]) / 2
            KF[i, j] = KF[j, i] = (f1 - KF[i, i] - KF[j, j]) / 2
    c = 128 * np.pi * GOVERL2 * 0.25
    M = c * (28 * KS - 96 * KF + 17 * np.eye(n))
    return KS, KF, M

if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    order = sys.argv[2] if len(sys.argv) > 2 else 'A'
    k = midgrid(N)
    for p in ([np.pi / 3, 0, 0, 0], [2 * np.pi / 3, 0, 0, 0], [np.pi, 0, 0, 0],
              [np.pi / 3, np.pi / 3, 0, 0], [2 * np.pi / 3, 2 * np.pi / 3, 0, 0], [np.pi, np.pi, 0, 0]):
        p = np.array(p)
        KS, KF, M = form(p, k, order=order)
        ev = np.linalg.eigvalsh(M)
        offmax = np.max(np.abs(M - np.diag(np.diag(M))))
        print(f"p={np.round(p,3)} order={order} N={N}: m2L0^2 diag(basis)={np.round(np.diag(M),1)}  eig range [{ev.min():.1f},{ev.max():.1f}]  "
              f"mean={ev.mean():.1f}  max|offdiag|={offmax:.2e}  scalar K diag={np.round(np.diag(KS),4)}  Regge={2*phat2(p):.2f}", flush=True)
