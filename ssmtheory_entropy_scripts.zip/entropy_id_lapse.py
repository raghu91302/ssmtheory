"""Lapse (Newtonian potential) on a solved Regge slice, and isotropy of psi and N.
Static equation D^2 N = 4 pi G rho N, discretized with the 3D cotangent Laplacian of the slice:
  sum_u w_uv (N_u - N_v) = 4 pi G m_v N_v ,  w_uv = (1/6) sum_{T contains uv} l_opp cot(theta_opp).
N = 1 on the wall. Prints far-field fits psi-1 = a/r + b, N-1 = -c/r + e, and gamma = 2a/c.
Run: python3 entropy_id_lapse.py L Rw q"""
import sys, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl
import entropy_defect_intrinsic as I, entropy_id_solve as R
L=int(sys.argv[1]); Rw=float(sys.argv[2]); q=float(sys.argv[3])
C=R.setup(L); free,idx,A,S,sp_e=R.build(C,Rw)
psi=np.load(f"id_L{L}_q{q}.npy"); l=R.lengths(C,psi); tedge=C['tedge']
th=I.dihedrals(l[tedge]**2); opp=[5,4,3,2,1,0]
w=np.zeros(C['nE'])
for k in range(6):
    np.add.at(w, tedge[:,k], l[tedge[:,opp[k]]]/np.tan(th[:,opp[k]])/6)
Eu,Ev,nv=C['Eu'],C['Ev'],C['nv']
Lap=sp.coo_matrix((np.r_[w,w,-w,-w],(np.r_[Eu,Ev,Eu,Ev],np.r_[Ev,Eu,Eu,Ev])),shape=(nv,nv)).tocsr()  # (Lap N)_v = sum_u w (N_u - N_v)
m=np.zeros(nv)
for k in sp_e: m[Eu[k]]+=q*l[k]/2/(8*np.pi); m[Ev[k]]+=q*l[k]/2/(8*np.pi)   # G m_v
M=Lap-sp.diags(4*np.pi*m)
f=free; N=np.ones(nv)
rhs=-(M[f][:,~f]@N[~f])
N[f]=spl.spsolve(M[f][:,f].tocsc(),rhs)
r=C['r']; n=C['n']; sel=(np.arange(nv)<n)&(r>3)&(r<Rw-2)
X=np.c_[1/r[sel],np.ones(sel.sum())]
a,b=np.linalg.lstsq(X,psi[sel]-1,rcond=None)[0]; c,e=np.linalg.lstsq(X,1-N[sel],rcond=None)[0]
GM=q*l[sp_e].sum()/(8*np.pi)
print(f"L={L} q={q}: GM(source)={GM:.5g}  psi: a={a:.5g} (a/(GM/2)={a/(GM/2):.4f})  N: c={c:.5g} (c/GM={c/GM:.4f})  gamma=2a/c={2*a/c:.4f}")
for rr in (4,5,6):
    sh=(np.arange(nv)<n)&(np.abs(r-rr)<0.3)
    if sh.sum()>3:
        u=(psi[sh]-1-b)*r[sh]/a; v=(1-N[sh]-e)*r[sh]/c
        print(f"  shell r~{rr} ({sh.sum()} nodes): psi spread {u.min():.4f}..{u.max():.4f}   N spread {v.min():.4f}..{v.max():.4f}")
eps=l**2/C['lflat']**2-1
print(f"  strain: max|eps| {np.abs(eps).max():.3e}, sum eps^2 {np.sum(eps**2):.3e}; spoke eps {eps[sp_e].mean():.3e}")
