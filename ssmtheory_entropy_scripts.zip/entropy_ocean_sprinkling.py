#!/usr/bin/env python3
"""Usage: python3 entropy_ocean_sprinkling.py s|f Lbox nreal [kernel_width] [seed]   e.g. "s 8 100 1.0 11", "f 6 30 1.0 7"
Is a randomly sprinkled ocean a covariant regulator?  Euclidean, one loop, uniform metric g = I + h.
Points X (comoving with the strain) in a periodic box of side Lb at density 1/2 per coordinate volume (one per D4 cell).
Couplings depend only on proper distance d^2 = dx^T g dx through a Gaussian kernel w(d) = exp(-d^2/2 s^2), cut at 3.2 s.
Scalar: graph Laplacian L; f = (1/N) ln det' L.   Fermion: D_ij = w(d_ij) gamma.(g^{1/2} dx_ij)/s (anti-Hermitian),
f = (1/4N) ln det(D^dag D)^{1/2}... per real component.  Covariance <=> f depends on g only through det g, i.e.
shear response Kcal = d^2 f/dt^2 (g = I + tH, H traceless, tr H^2 = 1) equals -kappa1, kappa1 = (1/4) df/d eps (g = (1+eps) I).
Same operators on the D4 lattice points are the control."""
import numpy as np, itertools, sys
MF=0.3
from scipy.spatial import cKDTree
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); I2=np.eye(2)
GAM=[np.kron(s1,s) for s in (s1,s2,s3)]+[np.kron(s2,I2)]
def msqrt(g): w,V=np.linalg.eigh(g); return (V*np.sqrt(w))@V.T
def pairs(X,Lb,rmax):
    T=cKDTree(X,boxsize=Lb); P=np.array(sorted(T.query_pairs(rmax)))
    dx=X[P[:,1]]-X[P[:,0]]; dx-=Lb*np.round(dx/Lb); return P,dx
def f_scalar(P,dx,N,g,s):
    d2=np.einsum('ma,ab,mb->m',dx,g,dx); w=np.exp(-d2/(2*s*s))*(d2<(3.2*s)**2)
    L=np.zeros((N,N)); L[P[:,0],P[:,1]]=-w; L[P[:,1],P[:,0]]=-w; L[np.arange(N),np.arange(N)]=-L.sum(1)
    ev=np.linalg.eigvalsh(L); return np.sum(np.log(ev[1:]))/N
def f_fermion(P,dx,N,g,s):
    d2=np.einsum('ma,ab,mb->m',dx,g,dx); w=np.exp(-d2/(2*s*s))*(d2<(3.2*s)**2)
    u=(dx@msqrt(g))*(w/s)[:,None]                     # frame components of proper displacement times weight
    B=np.einsum('ma,aij->mij',u,np.array(GAM))       # w gamma.u for each pair (4x4)
    D=np.zeros((4*N,4*N),complex)
    for k,(i,j) in enumerate(P):
        D[4*i:4*i+4,4*j:4*j+4]+=B[k]; D[4*j:4*j+4,4*i:4*i+4]-=B[k]
    ev=np.linalg.eigvalsh(1j*D)                       # Hermitian; eigenvalues +-lambda
    return np.sum(0.5*np.log(ev**2+MF**2))/(4*N)     # ln|det(D+m)| per component; constant mass MF (covariant) removes near-zero modes
def responses(fun,P,dx,N,s,H,t=0.02):
    I=np.eye(4); f0=fun(P,dx,N,I,s)
    K=(fun(P,dx,N,I+t*H,s)-2*f0+fun(P,dx,N,I-t*H,s))/t**2
    k1=(fun(P,dx,N,(1+t)*I,s)-fun(P,dx,N,(1-t)*I,s))/(2*t)/4
    return K,k1
if __name__=='__main__':
    field=sys.argv[1]; Lb=int(sys.argv[2]); nreal=int(sys.argv[3]); s=float(sys.argv[4]) if len(sys.argv)>4 else 1.0
    fun=f_scalar if field=='s' else f_fermion
    rng=np.random.default_rng(int(sys.argv[5]) if len(sys.argv)>5 else 7)
    Hs=[np.diag([1,-1,1,-1.])/2]; H2=np.zeros((4,4)); H2[0,1]=H2[1,0]=2**-.5; Hs.append(H2)
    # control: D4 lattice points
    X=np.array([x for x in itertools.product(range(Lb),repeat=4) if sum(x)%2==0],float); N=len(X)
    P,dx=pairs(X,Lb,3.2*s*1.05)
    out=[responses(fun,P,dx,N,s,H) for H in Hs]
    print('%s D4 lattice  N=%d: K = %s ; -kappa1 = %.4f'%(field,N,' '.join('%.4f'%o[0] for o in out),-out[0][1]),flush=True)
    Ks=[];k1s=[]
    for r in range(nreal):
        X=rng.random((N,4))*Lb; P,dx=pairs(X,Lb,3.2*s*1.05)
        for H in Hs:
            Q=np.linalg.qr(rng.normal(size=(4,4)))[0]; Hr=Q@H@Q.T     # random orientation of the shear
            K,k1=responses(fun,P,dx,N,s,Hr); Ks.append(K); k1s.append(k1)
    Ks=np.array(Ks); k1s=np.array(k1s)
    print('%s sprinkled   N=%d, %d samples: K = %.4f +- %.4f ; -kappa1 = %.4f +- %.4f ; K + kappa1 = %+.4f +- %.4f'%(field,N,len(Ks),Ks.mean(),Ks.std()/np.sqrt(len(Ks)),-k1s.mean(),k1s.std()/np.sqrt(len(k1s)),(Ks+k1s).mean(),(Ks+k1s).std()/np.sqrt(len(Ks))),flush=True)
