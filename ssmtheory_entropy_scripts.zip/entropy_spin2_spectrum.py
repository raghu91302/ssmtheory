#!/usr/bin/env python3
"""Usage: python3 entropy_spin2_spectrum.py [N]  (N=12 is converged)
Gauge-constrained spin-2 spectrum of lattice-regulated vacuum loops on D4 (Euclidean, one loop).
Metric wave g = I + h(x), h(x) = 2 eps H cos(p.x) with H transverse (H p = 0), traceless, tr H^2 = 1 (spin-2).
Per field degree of freedom the one-loop quadratic action per site is (sigma/4) Kcal(p) <tr h^2>, sigma=+1 boson,
-1 fermion; Kcal(0) is the uniform-strain value of entropy_d4_regulator.py, and 1/4 is the part a cosmological
term rho*sqrt(g) would give.
Scalar: (O phi)(x) = (1/sqrt g(x)) sum_j c_j(mid) [phi(x) - phi(x+e_j)],  sum_j c_j e_j e_j^T = sqrt(det g) g^{-1} at mid.
Fermion (Wilson-Dirac): (D psi)(x) = (1/sqrt g(x)) sum_j c_j(mid) [ (gamma.n_j - r a) U_j psi(x+e_j) + r a psi(x) ],
   n_j = g^{1/2} e_j (bond in the orthonormal frame, symmetric vierbein), a = (det g)^{1/8}, U_j = exp(e_j^mu Om_mu(mid)),
   Om_mu = (1/4) omega_mu,ab gamma_a gamma_b,  omega_mu,ab = e_a^nu (d_mu E_b^nu + Gamma^nu_{mu lam} E_b^lam).
Vertices are obtained by finite differences of these exact nonlinear operators; ln det is expanded to second order
and averaged over the Brillouin zone (N^4 midpoint grid over [-pi,pi)^4)."""
import numpy as np, itertools, sys
from scipy.linalg import expm
E=np.array([s*np.eye(4)[a]+t*np.eye(4)[b] for a,b in itertools.combinations(range(4),2) for s in (1,-1) for t in (1,-1)],float)
A16=np.einsum('ja,jb->jab',E,E).reshape(24,16); w0=np.full(24,1/12.)
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); I2=np.eye(2)
G=[np.kron(s1,s) for s in (s1,s2,s3)]+[np.kron(s2,I2)]      # Euclidean hermitian gammas
for a in range(4):
    for b in range(4): assert np.allclose(G[a]@G[b]+G[b]@G[a],2*(a==b)*np.eye(4))
def msqrt(g):
    w,V=np.linalg.eigh(g); return (V*np.sqrt(w))@V.T, (V/np.sqrt(w))@V.T
def weights(g):
    t=np.sqrt(np.linalg.det(g))*np.linalg.inv(g)
    return w0+np.linalg.lstsq(A16.T,(t-np.eye(4)).reshape(16),rcond=None)[0]
class Wave:
    def __init__(s,H,p,amp,phase,kind): s.H,s.p,s.A,s.ph,s.kind=H,p,amp,phase,kind
    def h(s,x):
        a=s.p@x+s.ph; return s.A*s.H*(np.cos(a) if s.kind=='c' else np.sin(a))
    def dh(s,x):
        a=s.p@x+s.ph; d=(-np.sin(a) if s.kind=='c' else np.cos(a)); return np.array([s.A*s.H*s.p[m]*d for m in range(4)])
def spinconn(wave,x,dl=1e-5):
    g=np.eye(4)+wave.h(x); e,Ei=msqrt(g); gi=np.linalg.inv(g); dg=wave.dh(x)
    Gam=0.5*(np.einsum('nr,mrl->nml',gi,dg)+np.einsum('nr,lrm->nml',gi,dg)-np.einsum('nr,rml->nml',gi,dg.transpose(1,0,2)))
    # Gam[nu,mu,lam] = 1/2 g^{nu rho}(d_mu g_rho lam + d_lam g_rho mu - d_rho g_mu lam)
    Gam=0.5*np.einsum('nr,mrl->nml',gi,dg)+0.5*np.einsum('nr,lrm->nml',gi,dg)-0.5*np.einsum('nr,rml->nml',gi,np.array([dg[r] for r in range(4)]))
    om=np.zeros((4,4,4))
    for m in range(4):
        dx=np.zeros(4); dx[m]=dl
        _,Ep=msqrt(np.eye(4)+wave.h(x+dx)); _,Em=msqrt(np.eye(4)+wave.h(x-dx)); dE=(Ep-Em)/(2*dl)   # dE[nu,b]
        om[m]=e@(dE+np.einsum('nl,lb->nb',Gam[:,m,:],Ei))      # omega_mu [a,b]
    return om
def pieces(wave,field,r=1.0):
    """S (site term) and T_j (hop to x+e_j) at x=0 for a given background wave (or None for flat)."""
    zero=np.zeros(4)
    g0=np.eye(4)+(wave.h(zero) if wave else 0); sdet0=np.sqrt(np.linalg.det(g0))
    S=0.; T=[]
    for j in range(24):
        mid=E[j]/2; g=np.eye(4)+(wave.h(mid) if wave else 0); c=weights(g)[j]
        if field=='s':
            S+=c/sdet0; T.append(-c/sdet0)
        else:
            e,_=msqrt(g); n=e@E[j]; a=np.linalg.det(g)**0.125
            if wave:
                om=spinconn(wave,mid); Om=sum(E[j][m]*0.25*sum(om[m][aa,bb]*G[aa]@G[bb] for aa in range(4) for bb in range(4)) for m in range(4))
                U=expm(Om)
            else: U=np.eye(4)
            gn=sum(n[aa]*G[aa] for aa in range(4))
            T.append(c*(gn-r*a*np.eye(4))@U/sdet0); S=S+c*r*a*np.eye(4)/sdet0
    return S,np.array(T)
def assemble(S,T,K):   # operator on plane wave e^{ikx}, evaluated at x=0
    ph=np.exp(1j*K@E.T)          # (M,24)
    if np.ndim(S)==0: return S+ph@T
    return S[None]+np.einsum('mj,jab->mab',ph,T)
def gamma2(field,H,p,N=16,eps=1e-3,r=1.0):
    g1=(np.arange(N)+0.5)/N*2*np.pi-np.pi
    K=np.stack(np.meshgrid(g1,g1,g1,g1,indexing='ij'),-1).reshape(-1,4)
    S0,T0=pieces(None,field,r)
    lin={}
    for kind in ('c','s'):
        Sp,Tp=pieces(Wave(H,p,2*eps,0.,kind),field,r); Sm,Tm=pieces(Wave(H,p,-2*eps,0.,kind),field,r)
        lin[kind]=((Sp-Sm)/2,(Tp-Tm)/2)
    dSp=(lin['c'][0]+1j*lin['s'][0])/2; dTp=(lin['c'][1]+1j*lin['s'][1])/2
    dSm=(lin['c'][0]-1j*lin['s'][0])/2; dTm=(lin['c'][1]-1j*lin['s'][1])/2
    S2=0; T2=0
    for ph in (0,np.pi/2,np.pi,1.5*np.pi):
        Sp,Tp=pieces(Wave(H,p,2*eps,ph,'c'),field,r); Sm,Tm=pieces(Wave(H,p,-2*eps,ph,'c'),field,r)
        S2=S2+((Sp+Sm)/2-S0)/4; T2=T2+((Tp+Tm)/2-T0)/4
    D0k=assemble(S0,T0,K); D0kp=assemble(S0,T0,K+p)
    Ap=assemble(dSp,dTp,K); Am=assemble(dSm,dTm,K+p); B=assemble(S2,T2,K)
    if field=='s':
        g2=0.5*np.mean((B/D0k).real)-0.5*np.mean((Am*Ap/(D0k*D0kp)).real)     # Gamma=+1/2 ln det
        return 2*g2/eps**2                                                   # Kcal per dof
    iD0=np.linalg.inv(D0k); iD1=np.linalg.inv(D0kp)
    t1=np.einsum('mab,mba->m',iD0,B); t2=np.einsum('mab,mbc,mcd,mda->m',iD0,Am,iD1,Ap)
    g2=-np.mean((t1-t2).real)                                                # Gamma=-ln det, Dirac (4 dof)
    return -g2/(2*eps**2)                                                   # Kcal per dof: Gamma2 = 4*(-1/4)*Kcal*2eps^2
def tt_pols(p):
    """two orthonormal transverse-traceless polarizations for momentum p"""
    n=p/np.linalg.norm(p); B=np.linalg.svd(np.outer(n,n))[0][:,1:]   # basis of the plane orthogonal to p
    P1=np.outer(B[:,0],B[:,1]); P1=P1+P1.T; P1/=np.sqrt(np.trace(P1@P1))
    P2=np.outer(B[:,0],B[:,0])-np.outer(B[:,1],B[:,1]); P2/=np.sqrt(np.trace(P2@P2))
    return P1,P2
def phat2(p): return np.sum(1-np.cos(p@E.T))/6
if __name__=='__main__':
    N=int(sys.argv[1]) if len(sys.argv)>1 else 12
    nB,nF=28,96; GL=1/1.843**2        # SSM content (gauge fields as 2 scalar-like dof); G/L0^2 with G = l_P^2
    w=Wave(np.diag([0,1,-1,0.])/np.sqrt(2),np.array([0.3,0.2,0,0.1]),1e-2,0.3,'c')
    om=spinconn(w,np.array([0.1,0.2,0.3,0.4]))
    print('check: spin connection antisymmetric to %.1e'%np.abs(om+om.transpose(0,2,1)).max())
    print('TT spin-2 action for the SSM content; m^2 L0^2 < 0 means unstable. Kcal(0): scalar 0.4644, fermion 0.7523 (uniform strain)')
    for name,d in (('axis',np.array([1,0,0,0.])),('root',np.array([1,1,0,0.])/np.sqrt(2))):
        for n in range(0,N//2+1):
            p=(2*np.pi*max(n,0.02)/N)*(d if name=='axis' else np.array([1,1,0,0.]))   # root: p=(q,q,0,0), edge at (pi,pi,0,0)
            P1,P2=tt_pols(p)
            for r in (0.5,1.0,2.0):
                ks=np.mean([gamma2('s',P,p,N) for P in (P1,P2)]); kf=np.mean([gamma2('f',P,p,N,r=r) for P in (P1,P2)])
                kap=0.25*(nB*(ks-0.25)-nF*(kf-0.25)); loops=128*np.pi*GL*kap; regge=2*phat2(p)
                print('%s |p|=%.3f r=%.1f  Kcal_s=%.4f Kcal_f=%.4f  loops %+6.0f  Regge %+5.1f  total %+6.0f'%(name,np.linalg.norm(p),r,ks,kf,loops,regge,loops+regge),flush=True)
