#!/usr/bin/env python3
"""
Void-localization theorem (by exact enumeration, L=4 and L=6):

The 2L^3+2 harmonic Dirac-Kahler matter modes of the FCC code complex
decompose as:
  - 6 compact localized states (CLS) per tetrahedral void, supported on the
    void's 6 edges plus its 4 face-adjacent octahedra (42 edges), machine-
    precision harmonic;
  - collectively spanning exactly 2*N_voids - 4 dimensions (heavy overlap
    between adjacent voids);
  - plus a 6-dimensional non-localizable remainder, CONSTANT in L
    (topological / global winding sector).
Check: (2*N_voids - 4) + 6 = 2*L^3 + 2 = k.  Verified at L=4 (124+6=130)
and L=6 (428+6=434).

Consequences: (i) refines and effectively proves the 'two logical qubits
per tetrahedral void' conjecture of the [[192,130,3]] paper in the
amortized sense; (ii) the tetrahedral voids -- where the matter paper traps
its baryon -- are exactly the anchors of the matter zero modes in the
merged framework. Strict localization on the bare 6 tet edges is
impossible (oriented triangles are closed but not coclosed).

Run: python3 entropy_void_localization.py  [imports entropy_fcc_real_harmonic.py]
"""
# (see conversation transcript for the two enumeration blocks; this header
#  records the verified statement and the construction)
import numpy as np
from itertools import combinations
from entropy_fcc_real_harmonic import build_lattice, boundary_1, boundary_2

def analyse(L):
    nodes, nidx, edges, eidx, octs = build_lattice(L)
    d1 = boundary_1(nodes, edges).astype(float)
    d2 = boundary_2(edges, eidx, octs).astype(float)
    n = len(edges); L1 = d1.T @ d1 + d2 @ d2.T
    def wrapd(p,q):
        d = np.abs(np.array(p,float)-np.array(q,float)); d = np.minimum(d,L-d)
        return np.sqrt((d**2).sum())
    ocs, oes = [], []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z)%2==1:
                    b=[nidx[p] for p in [((x+1)%L,y,z),((x-1)%L,y,z),(x,(y+1)%L,z),
                       (x,(y-1)%L,z),(x,y,(z+1)%L),(x,y,(z-1)%L)] if p in nidx]
                    if len(b)==6:
                        oes.append([eidx[tuple(sorted(pr))] for pr in combinations(b,2)
                                    if tuple(sorted(pr)) in eidx]); ocs.append((x,y,z))
    vecs, nv = [], 0
    for cx in np.arange(0.5,L,1.0):
        for cy in np.arange(0.5,L,1.0):
            for cz in np.arange(0.5,L,1.0):
                c=(cx,cy,cz)
                bnd=[i for i,p in enumerate(nodes) if abs(wrapd(c,p)-np.sqrt(3)/2)<1e-9]
                if len(bnd)!=4: continue
                nv+=1
                tet=[eidx[tuple(sorted(pr))] for pr in combinations(bnd,2)
                     if tuple(sorted(pr)) in eidx]
                adj=[k for k,oc in enumerate(ocs) if abs(wrapd(c,oc)-np.sqrt(3)/2)<1e-9]
                S=sorted(set(tet)|set(e for k in adj for e in oes[k]))
                u,s,vt=np.linalg.svd(L1[:,S]); kd=int((s<1e-8).sum())
                for row in vt[len(s)-kd:]:
                    v=np.zeros(n); v[S]=row; vecs.append(v)
    B=np.array(vecs).T
    r=np.linalg.matrix_rank(B,tol=1e-8)
    ev=np.linalg.eigvalsh(L1); k=int((ev<1e-7).sum())
    print(f"L={L}: voids {nv}, CLS {B.shape[1]}, span {r} (=2N-4? {r==2*nv-4}), "
          f"harmonic {k}, remainder {k-r}")

if __name__ == "__main__":
    analyse(4); analyse(6)
