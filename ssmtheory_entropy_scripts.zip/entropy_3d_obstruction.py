"""Three-dimensional Regge gravity with the spoke source: Regge action plus the line source on the spokes.
Stationarity: delta_e=0 on every non-spoke edge, delta_s = target on the four spokes.
Least squares from the flat start; reports the smallest residual reachable (nonzero for any nonzero source).
Run: python3 entropy_3d_obstruction.py L t1,t2,...  (targets in degrees)"""
import sys, numpy as np, scipy.sparse as sp
import entropy_defect_intrinsic as I
from scipy.optimize import least_squares
L=int(sys.argv[1]); targets=[float(t) for t in sys.argv[2].split(',')]
E, phys, tets, tedge, lflat, nodes, cdef, n = I.build_complex(L)
nE=len(E)
dsp=np.array([k for k,(u,v) in enumerate(E) if cdef in (u,v)])
isp=np.zeros(nE,bool); isp[dsp]=True
rows=[];cols=[]
for T in tedge:
    for a in T:
        for b in T: rows.append(a); cols.append(b)
S=sp.coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(nE,nE)).tocsr(); S.data[:]=1
print("flat start: spoke",lflat[dsp]/I.L0, "max|delta|",np.abs(I.deficits(lflat,tedge,nE)).max())
x=lflat.copy()
for tg in targets:
    t=np.radians(tg)
    def res(z): d=I.deficits(z,tedge,nE); return np.where(isp,d-t,d)
    sol=least_squares(res,x,jac_sparsity=S,method='trf',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=400,bounds=(0.2*lflat,5*lflat))
    z=sol.x; r=res(z); d=I.deficits(z,tedge,nE)
    print(f"L={L} target {tg:6.2f} deg: max resid {np.abs(r).max():.2e} (deg {np.degrees(np.abs(r).max()):.3f}); spoke delta {np.degrees(d[dsp]).round(3)}; "
          f"max|delta| off spokes {np.degrees(np.abs(d[~isp]).max()):.3f}; spoke l/L0 {(z[dsp]/I.L0).round(4)}",flush=True)
    x=z
