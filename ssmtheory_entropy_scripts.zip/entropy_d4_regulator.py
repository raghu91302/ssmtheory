#!/usr/bin/env python3
"""Does the D4 lattice act as a covariant regulator?  One-loop vacuum term of fields whose modes live on
the D4 lattice, under a uniform metric g = I + h in lattice coordinates (Euclidean).

Per field degree of freedom, f(g) = < ln Q(k;g) >_BZ (one mode per site).  For any isotropic f,
    f = f0 + alpha tr h + beta (tr h)^2 + gamma tr h^2 + ...
A covariant vacuum term  a + rho sqrt(g)  has alpha = rho/2, beta = rho/8, gamma = -rho/4.
Shear (traceless h = t H, tr H^2 = 1): d2f/dt2 = 2 gamma = K.  Covariance requires K = K_cov = -alpha = 1/4
(every field here has alpha = -1/4).  K - 1/4 is a spin-2 mass term of order the cutoff.

Fields: scalar Q = sum_j w_j (1 - cos k.e_j) over the 24 roots e_j of D4;
        Wilson-Dirac Q = v.v + W^2 with naive hopping v and Wilson term W = r a_phys Q_scalar.
Strain prescription: bond weights solve sum_j w_j e_j e_j^T = g^{-1} (minimum-norm change), so every
field sees the metric g exactly at long wavelengths.  (Weights w_j ~ 1/l_j^2 per bond do not: their
long-wavelength operator is I - h/3 for traceless h, not g^{-1}; that prescription is not used.)
Fermion forms: F1 hopping fixed, metric enters through v.v = s^T g^{-1} s;
               F2 hopping uses the bond weights, v.v = s_w^T g s_w.
Covariance only requires f to depend on g through det g; any such f has K = -alpha = 1/4.
Gauge fields are counted as 2 scalar-like dof (Feynman gauge minus ghosts); a lattice gauge field on the
12 links per site has more cutoff-scale modes, which can change kappa by an O(1) factor.
Usage: python3 entropy_d4_regulator.py [N]   (N^4 k-points; N=16 is converged)"""
import numpy as np, itertools, sys
E=np.array([s*np.eye(4)[a]+t*np.eye(4)[b] for a,b in itertools.combinations(range(4),2)
            for s in (1,-1) for t in (1,-1)],float)
N=int(sys.argv[1]) if len(sys.argv)>1 else 16
g1=(np.arange(N)+0.5)/N*2*np.pi-np.pi
K=np.stack(np.meshgrid(g1,g1,g1,g1,indexing='ij'),-1).reshape(-1,4); KE=K@E.T
C=1-np.cos(KE); S=np.sin(KE); A=np.einsum('ja,jb->jab',E,E).reshape(24,16); w0=np.full(24,1/12.)
def weights(g,m):
    if m=='W1': return w0+np.linalg.lstsq(A.T,(np.linalg.inv(g)-np.eye(4)).reshape(16),rcond=None)[0]
    return w0*2/np.einsum('ja,ab,jb->j',E,g,E)
def f_s(g,m): return np.mean(np.log(C@weights(g,m)))
def f_f(g,m,fm,r):
    w=weights(g,m); W=r*np.linalg.det(g)**0.125*(C@w)
    if fm=='F1': s=S@(E/12.); vv=np.einsum('ma,ab,mb->m',s,np.linalg.inv(g),s)
    else: s=S@(E*w[:,None]); vv=np.einsum('ma,ab,mb->m',s,g,s)
    return np.mean(np.log(vv+W**2))
I=np.eye(4); d=0.02
def shear(fun,H): return (fun(I+d*H)-2*fun(I)+fun(I-d*H))/d**2
def dil(fun): return (fun((1+d)*I)-fun((1-d)*I))/(2*d)
Hs=[np.diag([1,-1,1,-1.])/2]; H2=np.zeros((4,4)); H2[0,1]=H2[1,0]=2**-.5; Hs.append(H2)
nB,nF=4+2*12,2*48            # SSM content: 4 Higgs scalars, 12 gauge fields (2 dof each), 48 Weyl (2 dof each)
GL=1/1.843**2                # G/L0^2 with G = l_P^2
print('N=%d; covariant shear value K_cov = 0.25'%N)
fs=lambda g:f_s(g,'W1'); Ks=[shear(fs,H) for H in Hs]
print('scalar: dilation slope %.4f, K = %.4f (diag) %.4f (off-diag)'%(dil(fs),*Ks))
for fm in ('F1','F2'):
    for r in (0.1,0.25,0.5,1.0,2.0,4.0):
        ff=lambda g:f_f(g,'W1',fm,r); Kf=[shear(ff,H) for H in Hs]
        kap=0.25*(nB*(Ks[0]-0.25)-nF*(Kf[0]-0.25))      # noncovariant spin-2 energy per site / tr h^2
        m2=128*np.pi*GL*kap                              # m_g^2 L0^2 (Fierz-Pauli normalization, V_site = L0^4/2)
        print('fermion %s r=%.2f: slope %.4f, K = %.4f %.4f | SSM content: kappa=%+.2f, m_g^2 L0^2=%+.0f, |m_g| L0=%.0f'%(fm,r,dil(ff),*Kf,kap,m2,np.sqrt(abs(m2))))
