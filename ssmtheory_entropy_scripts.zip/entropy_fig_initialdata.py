"""Fig. 5: the trapped node as Regge initial data, against the source q = 8 pi G mu.
Reads the log written by  python3 entropy_id_solve.py 20 9.6 <q list> > fine20.log"""
import re, sys, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
log=sys.argv[1] if len(sys.argv)>1 else 'fine20.log'; L0=np.sqrt(2)
rows=[]
for line in open(log):
    m=re.search(r"q=([\d.e-]+): .*Q=8piG\*mu\*sum l_s=([\d.e+-]+) .*8piG\*M_far\(fit\)=([\d.e+-]+) ratio far/Q ([\d.e+-]+) .*spoke l/L0 ([\d.]+)",line)
    if m: rows.append([float(x) for x in m.groups()])
q,Q,Mf,rat,sp=np.array(rows).T
GM=Mf/(8*np.pi)/L0
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False,"axes.edgecolor":"#888","axes.labelcolor":"#222","xtick.color":"#444","ytick.color":"#444"})
col="#2a5ea8"
fig,ax=plt.subplots(1,3,figsize=(11,3.2))
for a in ax:
    a.axvline(np.pi,color="#999",lw=1,ls=":"); a.set_xlabel(r"source $q=8\pi G\mu$"); a.set_xlim(0,3.3); a.grid(alpha=0.25,lw=0.6)
ax[0].semilogy(q,sp,'-o',color=col,lw=2,ms=4); ax[0].set_ylabel(r"spoke length $/L_0$"); ax[0].set_title("(a) spoke length",loc='left',fontsize=10)
ax[0].text(np.pi-0.05,0.75,r"$q=\pi$",ha='right',color="#666",fontsize=9)
ax[1].plot(q,rat,'-o',color=col,lw=2,ms=4); ax[1].set_ylabel("far-field mass / source mass"); ax[1].set_ylim(0,1.05); ax[1].set_title("(b) binding",loc='left',fontsize=10)
ax[2].plot(q,GM,'-o',color=col,lw=2,ms=4); ax[2].set_ylabel(r"far-field $GM/L_0$"); ax[2].set_title("(c) far-field mass",loc='left',fontsize=10)
fig.tight_layout(); fig.savefig('fig_initial_data.pdf'); fig.savefig('fig_initial_data.png',dpi=110)
print("max GM/L0 =",GM.max())
