#!/usr/bin/env python3
"""Figures for: The matter sector of entropic gravity on a close-packed
code complex. Generates fig1..fig4 as vector PDFs. Reproduces all data."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection
from itertools import combinations, product
from entropy_fcc_real_harmonic import build_lattice, boundary_1, boundary_2

plt.rcParams.update({
    "font.family": "serif", "mathtext.fontset": "stix",
    "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9,
    "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.linewidth": 0.7, "lines.linewidth": 1.2,
    "figure.dpi": 150, "savefig.bbox": "tight"})

def complex_data(L):
    nodes, nidx, edges, eidx, octs = build_lattice(L)
    d1 = boundary_1(nodes, edges).astype(float)
    d2 = boundary_2(edges, eidx, octs).astype(float)
    L0 = d1 @ d1.T; L2 = d2.T @ d2
    L1 = d1.T @ d1 + d2 @ d2.T
    return nodes, nidx, edges, eidx, L0, L1, L2, d1, d2

def wrapd(p, q, L):
    d = np.abs(np.array(p, float) - np.array(q, float)); d = np.minimum(d, L - d)
    return np.sqrt((d ** 2).sum())

# ---------------------------------------------------------------- Fig 1
def fig1():
    pts = [(x, y, z) for x, y, z in product(range(3), repeat=3) if (x + y + z) % 2 == 0]
    fig = plt.figure(figsize=(3.4, 3.1))
    ax = fig.add_subplot(111, projection="3d")
    segs = []
    for a in pts:
        for b in pts:
            if a < b and abs(np.linalg.norm(np.subtract(a, b)) - np.sqrt(2)) < 1e-9:
                segs.append((a, b))
    ax.add_collection3d(Line3DCollection(segs, colors="0.82", linewidths=0.7))
    P = np.array(pts)
    ax.scatter(P[:, 0], P[:, 1], P[:, 2], s=10, c="0.55", depthshade=False)
    # 2-form: octahedral X-stabilizer about center (1,1,1)
    oc = [(0, 1, 1), (2, 1, 1), (1, 0, 1), (1, 2, 1), (1, 1, 0), (1, 1, 2)]
    osegs = [(a, b) for a, b in combinations(oc, 2)
             if abs(np.linalg.norm(np.subtract(a, b)) - np.sqrt(2)) < 1e-9]
    ax.add_collection3d(Line3DCollection(osegs, colors="#2a9d5c", linewidths=2.0))
    # 1-form: one edge qubit
    ax.add_collection3d(Line3DCollection([((0, 0, 0), (1, 1, 0))],
                                         colors="#1f5fbf", linewidths=3.0))
    # 0-form: one node
    ax.scatter([0], [0], [2], s=55, c="#c1272d", depthshade=False, zorder=5)
    from matplotlib.lines import Line2D
    handles = [
        Line2D([0], [0], marker="o", color="w", markerfacecolor="#c1272d",
               markersize=7, label=r"0-form $\phi$ (node)"),
        Line2D([0], [0], color="#1f5fbf", lw=3, label=r"1-form $\omega$ (edge qubit)"),
        Line2D([0], [0], color="#2a9d5c", lw=2,
               label=r"2-form $\zeta$ (octahedral $X$-stabilizer)")]
    ax.legend(handles=handles, loc="upper left", frameon=False,
              bbox_to_anchor=(0.0, 1.02))
    ax.set_axis_off(); ax.view_init(elev=16, azim=-58)
    ax.set_box_aspect((1, 1, 1))
    fig.savefig("fig1_complex.pdf"); plt.close(fig)

# ---------------------------------------------------------------- Fig 2
def fig2():
    fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.5))
    for ax, L in zip(axes, (4, 6)):
        _, _, _, _, L0, L1, L2, _, _ = complex_data(L)
        for M, lab, c in ((L0, r"$\mathcal{L}_0$ (nodes)", "#c1272d"),
                          (L1, r"$\mathcal{L}_1$ (edges)", "#1f5fbf"),
                          (L2, r"$\mathcal{L}_2$ (octahedra)", "#2a9d5c")):
            ev = np.sort(np.linalg.eigvalsh(M))
            x = (np.arange(len(ev)) + 1) / len(ev)
            ax.step(x, ev, where="post", color=c, label=lab)
        gap = 8 * (1 - np.cos(2 * np.pi / L))
        ax.axhline(gap, color="0.4", ls="--", lw=0.8)
        ax.text(0.015, gap + 0.5, r"$8(1-\cos 2\pi/L)=%g$" % gap, fontsize=7.5,
                color="0.25")
        k = 2 * L ** 3 + 2
        ax.annotate(r"flat band, $k=%d$" % k, xy=(0.34, 0.15),
                    xycoords="axes fraction", fontsize=8)
        ax.set_xlabel("eigenvalue index / sector dimension")
        ax.set_title(r"$L=%d$" % L, fontsize=9)
        ax.set_xlim(0, 1); ax.set_ylim(-0.5, 26)
    axes[0].set_ylabel("eigenvalue")
    axes[0].legend(loc="upper left", frameon=False)
    fig.tight_layout()
    fig.savefig("fig2_spectra.pdf"); plt.close(fig)

# ---------------------------------------------------------------- Fig 3
def void_support(L, center, nodes, nidx, eidx):
    bnd = [i for i, p in enumerate(nodes)
           if abs(wrapd(center, p, L) - np.sqrt(3) / 2) < 1e-9]
    tet = [eidx[tuple(sorted(pr))] for pr in combinations(bnd, 2)
           if tuple(sorted(pr)) in eidx]
    ocs, oes = [], []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x + y + z) % 2 == 1:
                    b = [nidx[p] for p in [((x + 1) % L, y, z), ((x - 1) % L, y, z),
                         (x, (y + 1) % L, z), (x, (y - 1) % L, z),
                         (x, y, (z + 1) % L), (x, y, (z - 1) % L)] if p in nidx]
                    if len(b) == 6:
                        oes.append([eidx[tuple(sorted(pr))] for pr in combinations(b, 2)
                                    if tuple(sorted(pr)) in eidx])
                        ocs.append((x, y, z))
    adj = [k for k, oc in enumerate(ocs)
           if abs(wrapd(center, oc, L) - np.sqrt(3) / 2) < 1e-9]
    S = sorted(set(tet) | set(e for k in adj for e in oes[k]))
    return S, bnd

def fig3():
    L = 4
    nodes, nidx, edges, eidx, L0, L1, L2, d1, d2 = complex_data(L)
    c = (0.5, 0.5, 0.5)
    S, bnd = void_support(L, c, nodes, nidx, eidx)
    u, s, vt = np.linalg.svd(L1[:, S]); kd = int((s < 1e-8).sum())
    cls = vt[len(s) - kd:][0]                       # one of the six CLS
    fig = plt.figure(figsize=(6.8, 2.7))
    ax = fig.add_subplot(121, projection="3d")
    # context: edges among nodes within distance 2 of the void (unwrapped view)
    near = [i for i, p in enumerate(nodes) if wrapd(c, p, L) < 2.1]
    ctx = [(nodes[i], nodes[j]) for (i, j) in edges
           if i in near and j in near
           and np.linalg.norm(np.subtract(nodes[i], nodes[j])) < 1.5]
    ax.add_collection3d(Line3DCollection(ctx, colors="0.88", linewidths=0.6))
    w = np.abs(cls) / np.abs(cls).max()
    cmap = plt.cm.viridis
    for wt, e in zip(w, S):
        i, j = edges[e]
        if np.linalg.norm(np.subtract(nodes[i], nodes[j])) > 1.5:
            continue                                  # skip wrapped edges in view
        ax.plot(*zip(nodes[i], nodes[j]), color=cmap(wt),
                lw=0.8 + 3.2 * wt, alpha=0.95)
    B = np.array([nodes[i] for i in bnd])
    ax.scatter(B[:, 0], B[:, 1], B[:, 2], s=22, c="#c1272d", depthshade=False)
    ax.scatter([c[0]], [c[1]], [c[2]], s=30, c="k", marker="*", depthshade=False)
    ax.set_axis_off(); ax.view_init(elev=14, azim=-50); ax.set_box_aspect((1, 1, 1))
    ax.set_title("one compact localized state (edge weights)", fontsize=8.5)
    sm = plt.cm.ScalarMappable(cmap=cmap); sm.set_array([0, 1])
    fig.colorbar(sm, ax=ax, shrink=0.6, pad=0.0, label=r"$|\omega_e|$ (norm.)")

    ax2 = fig.add_subplot(122)
    sizes = {4: (124, 6, 130), 6: (428, 6, 434)}
    ys = [1, 0]
    for y, Ls in zip(ys, (4, 6)):
        loc, topo, k = sizes[Ls]
        ax2.barh(y, loc, color="#1f5fbf", height=0.5)
        ax2.barh(y, topo, left=loc, color="#e0a13a", height=0.5)
        ax2.text(loc / 2, y, r"$2N_{\rm voids}-4=%d$" % loc, ha="center",
                 va="center", color="w", fontsize=8)
        ax2.text(loc + topo + 6, y, r"$k=%d$" % k, va="center", fontsize=8)
    ax2.text(sizes[6][0] + 3, 0.42, "6 topological", fontsize=7.5,
             color="#8a5d10", rotation=0)
    ax2.set_yticks(ys); ax2.set_yticklabels([r"$L=4$", r"$L=6$"])
    ax2.set_xlim(0, 480); ax2.set_xlabel("harmonic dimension")
    ax2.set_title("void-anchored span + topological remainder", fontsize=8.5)
    for sp in ("top", "right"):
        ax2.spines[sp].set_visible(False)
    fig.tight_layout()
    fig.savefig("fig3_cls.pdf"); plt.close(fig)

# ---------------------------------------------------------------- Fig 4
def fig4():
    L = 4
    nodes, nidx, edges, eidx, L0, L1, L2, d1, d2 = complex_data(L)
    S, _ = void_support(L, (0.5, 0.5, 0.5), nodes, nidx, eidx)
    lams = np.linspace(0, 0.6, 13)
    fig, ax = plt.subplots(figsize=(3.3, 2.6))
    for lam in lams:
        Lp = L1.copy(); Lp[S, S] += lam
        ev = np.linalg.eigvalsh(Lp)
        ev = ev[ev < 0.9]
        ax.plot([lam] * len(ev), ev, ".", color="#1f5fbf", ms=2.2, alpha=0.8)
    ax.axhline(0, color="0.6", lw=0.6)
    ax.annotate("92 exact zeros", xy=(0.45, 0.008), fontsize=8, color="0.2")
    ax.annotate("38 lifted levels\n(linear in $\\lambda$)", xy=(0.07, 0.42),
                fontsize=8, color="#1f5fbf")
    ax.set_xlabel(r"curvature coupling $\lambda$ on one void neighborhood")
    ax.set_ylabel("eigenvalue")
    ax.set_xlim(-0.02, 0.62); ax.set_ylim(-0.03, 0.75)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    fig.tight_layout()
    fig.savefig("fig4_selective.pdf"); plt.close(fig)



def verify_spectral_identity():
    """Sec 4.4: spec(L2) == spec(L0) exactly; nonzero spec(L1) is its double."""
    for L in (4, 6):
        _, _, _, _, L0, L1, L2, _, _ = complex_data(L)
        e0 = np.sort(np.linalg.eigvalsh(L0)); e2 = np.sort(np.linalg.eigvalsh(L2))
        e1 = np.sort(np.linalg.eigvalsh(L1)); e1nz = e1[e1 > 1e-7]
        dbl = np.sort(np.concatenate([e0[e0 > 1e-9]] * 2))
        print(f"L={L}: spec(L2)==spec(L0): {np.allclose(e0, e2, atol=1e-9)}; "
              f"nonzero spec(L1)==doubled: {np.allclose(e1nz, dbl, atol=1e-7)}")



def verify_torsion_and_global_modes():
    """Sec 4.1-4.2: unimodular-minor torsion certificate; the six uniform
    direction cochains are harmonic, independent, and complete the CLS span."""
    import sympy as sp, math
    from scipy.linalg import qr
    from entropy_fcc_real_harmonic import build_lattice, boundary_1, boundary_2
    DIRS = [(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1)]
    for L in (4, 6):
        nodes, nidx, edges, eidx, octs = build_lattice(L)
        d1 = boundary_1(nodes, edges); d2 = boundary_2(edges, eidx, octs)
        r = len(octs) - 1
        q_, rr, piv = qr(d2[:, :r].astype(float).T, pivoting=True)
        M = sp.Matrix(d2[np.ix_(piv[:r], range(r))].tolist())
        det = int(M.det(method="bareiss"))
        chi = np.zeros((6, len(edges)))
        wrap = lambda v: tuple(int(((x+L//2) % L) - L//2) for x in v)
        for k, d in enumerate(DIRS):
            for e, (i, j) in enumerate(edges):
                dv = wrap(np.array(nodes[j]) - np.array(nodes[i]))
                chi[k, e] = 1.0 if dv == d else (-1.0 if dv == tuple(-x for x in d) else 0.0)
        h = max(np.abs(d1.astype(float) @ chi.T).max(),
                np.abs(d2.astype(float).T @ chi.T).max())
        print(f"L={L}: |det maximal minor| = {abs(det)} (1 => torsion-free); "
              f"chi harmonic residual {h:.1e}; rank(chi) = "
              f"{np.linalg.matrix_rank(chi)}")

if __name__ == "__main__":
    verify_spectral_identity()
    verify_torsion_and_global_modes()
    fig1(); print("fig1 done")
    fig2(); print("fig2 done")
    fig3(); print("fig3 done")
    fig4(); print("fig4 done")
