#!/usr/bin/env python3
"""Checks for entropy_spin2_spectrum.py.
(1) Spinor algebra: rho(X) = (1/4) X_ab gamma_a gamma_b makes gamma covariantly constant and is a homomorphism.
(2) Curvature: the spinor curvature built from the code's spin connection equals rho(Riemann) at finite amplitude
    (sign +1); the opposite sign fails.
(3) Optional (python3 entropy_spin2_checks.py realspace; several minutes, 8 cores): exact real-space log-determinants
    on an 8^4 periodic D4 lattice reproduce the momentum-space Kcal at p = (pi/2,0,0,0)."""
import sys
import numpy as np
import entropy_spin2_spectrum as M
G=M.G

rng=np.random.default_rng(0)
X=rng.normal(size=(4,4)); X=X-X.T
rho=lambda X: 0.25*sum(X[a,b]*G[a]@G[b] for a in range(4) for b in range(4))
for a in range(4):
    lhs=rho(X)@G[a]-G[a]@rho(X); rhs=-sum(X[a,b]*G[b] for b in range(4))
    print(a, np.abs(lhs-rhs).max(), np.abs(lhs+rhs).max())
Y=rng.normal(size=(4,4)); Y=Y-Y.T
print('homomorphism', np.abs(rho(X)@rho(Y)-rho(Y)@rho(X)-rho(X@Y-Y@X)).max())
# curvature test: F_mn = d_m Om_n - d_n Om_m + [Om_m,Om_n] vs rho(R_mn) with R^a_b from Christoffels
W=[M.Wave(np.diag([0,1,-1,0.])/np.sqrt(2),np.array([0.7,0.2,0,0.1]),0.3,0.3,'c'),
   M.Wave(np.array([[0,0,0,1],[0,0,1,0],[0,1,0,0],[1,0,0,0.]])/2,np.array([0.,0.5,-0.4,0.3]),0.25,1.1,'c')]
class Sum:
    def h(s,x): return sum(w.h(x) for w in W)
    def dh(s,x): return sum(w.dh(x) for w in W)
w=Sum(); x0=np.array([0.1,0.2,0.3,0.4]); d=1e-4
def Om(x,sgn=1): om=M.spinconn(w,x); return [sgn*rho(om[m]) for m in range(4)]
def Gam(x):
    g=np.eye(4)+w.h(x); gi=np.linalg.inv(g); dg=w.dh(x)
    return 0.5*np.einsum('nr,mrl->nml',gi,dg)+0.5*np.einsum('nr,lrm->nml',gi,dg)-0.5*np.einsum('nr,rml->nml',gi,dg)
def dd(f,x,m):
    e=np.zeros(4); e[m]=d; return [(a-b)/(2*d) for a,b in zip(f(x+e),f(x-e))]
Gm=Gam(x0); dG=[ (Gam(x0+np.eye(4)[m]*d)-Gam(x0-np.eye(4)[m]*d))/(2*d) for m in range(4)]
e,Ei=M.msqrt(np.eye(4)+w.h(x0))
for sgn in (1,-1):
    O=Om(x0,sgn); dO=[dd(lambda x:Om(x,sgn),x0,m) for m in range(4)]
    err=0
    for m in range(4):
        for n in range(4):
            F=dO[m][n]-dO[n][m]+O[m]@O[n]-O[n]@O[m]
            # R^r_{s m n} = d_m Gam^r_{n s} - d_n Gam^r_{m s} + Gam^r_{m l}Gam^l_{n s} - Gam^r_{n l}Gam^l_{m s}
            R=dG[m][:,n,:]-dG[n][:,m,:]+Gm[:,m,:]@Gm[:,n,:]-Gm[:,n,:]@Gm[:,m,:]
            Rab=e@R@Ei
            err=max(err,np.abs(F-rho(Rab)).max())
    print('sign',sgn,'curvature mismatch',err, 'scale', np.abs(rho(Rab)).max())

if len(sys.argv)>1 and sys.argv[1]=='realspace':
    import itertools
    from multiprocessing import Pool
    import entropy_spin2_spectrum as M
    E=M.E; N=8; eps=0.01
    sites=[np.array(x) for x in itertools.product(range(N),repeat=4) if sum(x)%2==0]
    idx={tuple(x):i for i,x in enumerate(sites)}; Ns=len(sites)
    p=2*np.pi*2/N*np.array([1,0,0,0.]); P1,P2=M.tt_pols(p); H=P1
    def site_pieces(args):
        x,A,field=args
        return M.pieces(M.Wave(H,p,A,p@x,'c') if A!=0 else None, field)
    def logdet(A,field):
        with Pool(8) as pool: res=pool.map(site_pieces,[(x,A,field) for x in sites])
        d=1 if field=='s' else 4
        Mx=np.zeros((Ns*d,Ns*d),complex)
        for i,(x,(S,T)) in enumerate(zip(sites,res)):
            Mx[i*d:(i+1)*d,i*d:(i+1)*d]+=S if d>1 else S
            for j in range(24):
                y=x+E[j].astype(int); sgn=(-1)**int(np.sum((y<0)|(y>=N))); y=y%N; k=idx[tuple(y)]
                Mx[i*d:(i+1)*d,k*d:(k+1)*d]+=sgn*(T[j] if d>1 else T[j])
        s,l=np.linalg.slogdet(Mx); return l
    for field in ('s','f'):
        l0=logdet(0,field); lp=logdet(2*eps,field); lm=logdet(-2*eps,field)
        sec=(lp+lm-2*l0)/2/Ns
        K = 2*(0.5*sec)/eps**2 if field=='s' else -(-sec)/(2*eps**2)
        print(field,'real-space Kcal=%.5f  momentum-space gamma2(N=8)=%.5f'%(K,M.gamma2(field,H,p,N)),flush=True)
