#!/usr/bin/env python3
"""
Deriving the 3-epsilon lift barrier: transition-state enumeration.

Kulkarni (Part II, Sec. 16) POSITS an exposed-bond barrier DF_lift - DF_stitch
= 3 eps, giving the thermal factor e^{-3} at beta*eps = 1. He flags the
derivation as the outstanding step: "the present Hamiltonian rewards formed
bonds by -eps and does not by itself penalize them for being exposed."

This script builds the two transition states (TS) explicitly:
  TS_stitch : half-plane hexagonal sheet + new node at the in-plane apex of
              a frontier edge (2 anchor bonds).
  TS_lift   : same sheet + new node at tetrahedral height over an interior
              up-triangle (3 anchor bonds).

and evaluates candidate exposure functionals:

  F1 (negative control) - per-bond triangle count at the TS.
  F2 (negative control) - closure-site occupancy debt vs the bulk crystal.
  F3 (partial)          - rank-criticality of anchor bonds (Kulkarni Sec. 13).
  F4 (the derivation)   - EXPOSED-BOND COUNT under the independence criterion:

      An anchor bond b = (P, X) of the new node P is *exposed* at the TS iff
      it has no triangle support independent of P's own birth move, and none
      is fast-reachable:
        (i)  occupied support: an occupied node Q, Q not an anchor of P's
             move, with |QP| = |QX| = 1  (closes a triangle on b through an
             independent node), OR
        (ii) fast relief: an unoccupied, exclusion-respecting site Q with
             |QP| = |QX| = 1 that is creatable by a STITCH (in-plane apex of
             an occupied same-layer edge) whose anchors do not include P.
      If neither exists, consolidating b requires another LIFT (rate p << 1)
      or must bootstrap through P itself (no independent syndrome path --
      Kulkarni's compound-QEC peninsula criterion, made operational).

  This is the code-theoretic content evaluated over the two-hop environment:
  (i)/(ii) search exactly the sites that would give the bond a second,
  P-independent detection path.

Then the same functional is applied to the SECOND and THIRD lifts (adjacent
apexes, given the earlier ones), testing the "cooperative three-apex seed":
prediction of the merged reading is a cascade of exposure counts 3 -> 1 -> 0.
"""

import numpy as np
from itertools import combinations

TOL   = 1e-6
R_EX  = 0.95          # hard-core exclusion (Kulkarni Table 1)
H     = np.sqrt(2/3)  # tetrahedral lift height

A1 = np.array([1.0, 0.0, 0.0])
A2 = np.array([0.5, np.sqrt(3)/2, 0.0])

def site(m, n, z=0.0):
    return m*A1 + n*A2 + np.array([0,0,z])

def d(p, q): return np.linalg.norm(np.asarray(p)-np.asarray(q))
def unit(p, q): return abs(d(p,q) - 1.0) < TOL

# ---------------------------------------------------------------- geometry
# occupied layer-0 sheet: half-plane n <= 0 (frontier row n = 0)
M_RANGE = range(-7, 8); N_RANGE = range(-8, 1)
occ0 = [site(m, n) for n in N_RANGE for m in M_RANGE]

# candidate universe for relief-site searches:
#   layer-0 sites up to n = +3 (vacant frontier side), and tetra apexes at
#   z = +/- h over every up- and down-triangle of the extended grid.
cand = [site(m, n) for n in range(-8, 4) for m in range(-9, 10)]
apexes = []
for m in range(-9, 9):
    for n in range(-9, 4):
        up   = (site(m,n) + site(m+1,n) + site(m,n+1)) / 3.0
        down = (site(m,n) + site(m+1,n) + site(m+1,n-1)) / 3.0
        for c in (up, down):
            for z in (+H, -H):
                apexes.append(c + np.array([0,0,z]))
cand = cand + apexes

def dedup(pts):
    out = []
    for p in pts:
        if not any(d(p,q) < TOL for q in out): out.append(p)
    return out
cand = dedup(cand)

def occupied(pt, config):
    return any(d(pt, q) < TOL for q in config)

def unit_neighbors(p, config):
    return [q for q in config if TOL < d(p,q) and unit(p,q)]

def excl_ok(pt, config):
    return all(d(pt, q) > R_EX - TOL for q in config)

def triangles_on_bond(P, X, config):
    """occupied nodes closing a unit triangle on bond (P, X)"""
    return [q for q in config
            if TOL < d(q,P) and TOL < d(q,X) and unit(q,P) and unit(q,X)]

def stitch_creatable_independent(Q, config, P):
    """Q creatable as the in-plane apex of an occupied same-layer edge whose
    anchors exclude P. In-plane = Q coplanar with the edge's layer (same z)."""
    zQ = Q[2]
    layer = [u for u in config if abs(u[2]-zQ) < TOL and d(u,P) > TOL]
    for U, V in combinations(layer, 2):
        if unit(U,V) and unit(Q,U) and unit(Q,V):
            return True
    return False

def exposure(P, anchors, config):
    """exposed anchor-bond count for new node P born with the given anchors,
    evaluated against config (which already includes P)."""
    others = [q for q in config if d(q,P) > TOL]
    report = []
    n_exposed = 0
    for X in anchors:
        # (i) occupied independent support
        supp = [q for q in triangles_on_bond(P, X, others)
                if not any(d(q,a) < TOL for a in anchors)]
        # (ii) fast (stitch) relief, independent of P
        relief_sites = [Q for Q in cand
                        if not occupied(Q, config)
                        and unit(Q,P) and unit(Q,X)
                        and excl_ok(Q, config)]
        fast = [Q for Q in relief_sites
                if stitch_creatable_independent(Q, config, P)]
        exposed = (len(supp) == 0) and (len(fast) == 0)
        n_exposed += exposed
        report.append((X, len(supp), len(relief_sites), len(fast), exposed))
    return n_exposed, report

def rank_criticality(P, anchors):
    """number of anchor bonds whose removal drops the rank of the bond-
    direction stiffness matrix (Kulkarni Sec. 13 criterion)."""
    dirs = [(np.asarray(X)-P)/d(X,P) for X in anchors]
    def rank(ds): 
        return np.linalg.matrix_rank(sum(np.outer(v,v) for v in ds)) if ds else 0
    r_full = rank(dirs)
    return sum(1 for i in range(len(dirs)) if rank(dirs[:i]+dirs[i+1:]) < r_full), r_full

# ---------------------------------------------------------------- TS setup
A, B   = site(0,0), site(1,0)                 # frontier edge (stitch)
P_s    = site(0,1)                            # in-plane apex, empty side
Af, Bf, Cf = site(0,-4), site(1,-4), site(0,-3)   # interior up-face (lift)
P_l    = (Af+Bf+Cf)/3.0 + np.array([0,0,H])

assert unit(P_s,A) and unit(P_s,B)
assert unit(P_l,Af) and unit(P_l,Bf) and unit(P_l,Cf)
assert not occupied(P_s, occ0) and excl_ok(P_s, occ0)
assert excl_ok(P_l, occ0)

print("="*72)
print("TS geometries verified: stitch apex (2 anchors), lift apex (3 anchors)")
print(f"  sheet: {len(occ0)} occupied layer-0 nodes, frontier at n=0")
print(f"  candidate relief universe: {len(cand)} sites")

# ---------------------------------------------------------------- F1
print("\n--- F1 (negative control): triangles on new bonds at the TS")
for name, P, anchors in (("stitch", P_s, [A,B]), ("lift", P_l, [Af,Bf,Cf])):
    cfg = occ0 + [P]
    counts = [len(triangles_on_bond(P, X, occ0)) for X in anchors]
    print(f"  {name:6s}: per-bond triangle counts {counts}  "
          f"(total incidences {sum(counts)}, bonds {len(anchors)})")

# ---------------------------------------------------------------- F2
print("\n--- F2 (negative control): closure-site occupancy debt (bulk count = 4)")
for name, P, anchors, faces in (("stitch", P_s, [A,B], [(A,B)]),
                                ("lift", P_l, [Af,Bf,Cf], [(Af,Bf),(Bf,Cf),(Af,Cf)])):
    debt = 0
    for X in anchors:
        occ_closures = len(triangles_on_bond(P, X, occ0))
        debt += 4 - occ_closures
    gained = len(faces)   # each pre-existing base edge gains P as a closure
    print(f"  {name:6s}: gross debt {debt}, closures gained by existing edges "
          f"{gained}, net {debt - gained}")

# ---------------------------------------------------------------- F3
print("\n--- F3 (partial): rank-criticality of anchor bonds (Sec. 13 criterion)")
for name, P, anchors in (("stitch", P_s, [A,B]), ("lift", P_l, [Af,Bf,Cf])):
    ncrit, r = rank_criticality(P, anchors)
    print(f"  {name:6s}: stiffness rank {r}, critical bonds {ncrit}")

# ---------------------------------------------------------------- F4
print("\n--- F4 (the derivation): exposed-bond count, independence criterion")
results = {}
for name, P, anchors in (("stitch", P_s, [A,B]), ("lift", P_l, [Af,Bf,Cf])):
    cfg = occ0 + [P]
    n_exp, rep = exposure(P, anchors, cfg)
    results[name] = n_exp
    print(f"  {name:6s}: exposed anchor bonds = {n_exp}")
    for X, ns, nr, nf, e in rep:
        print(f"      bond -> ({X[0]:+.2f},{X[1]:+.2f},{X[2]:+.2f}): "
              f"occ.support {ns}, relief sites {nr}, fast-independent {nf}"
              f"  => {'EXPOSED' if e else 'covered'}")
print(f"\n  Delta F(TS) / eps  =  exposed(lift) - exposed(stitch) "
      f"=  {results['lift']} - {results['stitch']} = "
      f"{results['lift'] - results['stitch']}")

# ---------------------------------------------------------------- cascade
print("\n--- Cooperative-seed cascade: consolidation of the new layer")
cfg1 = occ0 + [P_l]

# Geometry check first: same-family (up-face) apexes form the unit-spaced
# next-layer lattice; edge-sharing up/down apexes sit at 1/sqrt(3) < R_ex.
up_apex = lambda m,n: (site(m,n)+site(m+1,n)+site(m,n+1))/3.0 + np.array([0,0,H])
down_apex_test = (Af+Bf+site(1,-5))/3.0 + np.array([0,0,H])
print(f"  apex spacing check: up-up (vertex-sharing faces) = "
      f"{d(up_apex(0,-4), up_apex(1,-4)):.4f}, "
      f"up-down (edge-sharing) = {d(P_l, down_apex_test):.4f} "
      f"(< R_ex = {R_EX}: excluded)")

# 2nd lift: apex over the vertex-sharing up-face (1,-4); |QP| = 1
E, F = site(2,-4), site(1,-3)
Q_l  = up_apex(1,-4)
assert unit(Q_l,Bf) and unit(Q_l,E) and unit(Q_l,F) and unit(Q_l,P_l)
assert excl_ok(Q_l, cfg1)
n2, rep2 = exposure(Q_l, [Bf,E,F], cfg1 + [Q_l])
print(f"\n  2nd lift (adjacent apex, shares vertex {tuple(np.round(Bf,2))} "
      f"with P's face): exposed = {n2}")
for X, ns, nr, nf, e in rep2:
    print(f"      bond -> ({X[0]:+.2f},{X[1]:+.2f},{X[2]:+.2f}): "
          f"occ.support {ns}, fast-indep {nf} => {'EXPOSED' if e else 'covered'}")

cfg2 = cfg1 + [Q_l]

# 3rd node of the new layer, route (a): as another LIFT on its own face.
# The apex adjacent to both P and Q is up_apex(0,-3).
R_l   = up_apex(0,-3)
anchR = [site(0,-3), site(1,-3), site(0,-2)]
assert all(unit(R_l, X) for X in anchR) and unit(R_l,P_l) and unit(R_l,Q_l)
n3a, rep3a = exposure(R_l, anchR, cfg2 + [R_l])
print(f"\n  3rd node as LIFT on face (0,-3): exposed = {n3a}")
for X, ns, nr, nf, e in rep3a:
    print(f"      bond -> ({X[0]:+.2f},{X[1]:+.2f},{X[2]:+.2f}): "
          f"occ.support {ns}, fast-indep {nf} => {'EXPOSED' if e else 'covered'}")

# 3rd node, route (b): as an in-plane STITCH on the layer-1 edge (P,Q) --
# the same site R_l is the equilateral apex of edge (P_l, Q_l) at z = H.
assert unit(R_l,P_l) and unit(R_l,Q_l) and abs(R_l[2]-H) < TOL
n3b, rep3b = exposure(R_l, [P_l,Q_l], cfg2 + [R_l])
print(f"\n  3rd node as LAYER-1 STITCH on edge (P,Q) [same site]: "
      f"exposed = {n3b}")
for X, ns, nr, nf, e in rep3b:
    print(f"      bond -> ({X[0]:+.2f},{X[1]:+.2f},{X[2]:+.2f}): "
          f"occ.support {ns}, fast-indep {nf} => {'EXPOSED' if e else 'covered'}")

print("\n--- summary")
print(f"  exposed anchor bonds:  1st lift {results['lift']}, "
      f"2nd lift {n2}, 3rd-as-lift {n3a}, 3rd-as-stitch {n3b}   "
      f"[in-sheet stitch: {results['stitch']}]")
print(f"  thermal factors at beta*eps = 1: e^-3, e^-{n2}, then stitch channel "
      f"opens (e^-{n3b})")
print(f"  => critical nucleus of a new sheet = 2 lifts: "
      f"e^-{results['lift']+n2} total, vs e^-6 under the uniform posit; "
      f"thereafter the layer grows by fast stitches (v_2D)")
