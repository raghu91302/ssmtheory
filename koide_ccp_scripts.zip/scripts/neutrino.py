#!/usr/bin/env python3
"""neutrino.py -- Section 7: neutrino masses for K_nu = 1/2 (Proposition 2), with uncertainties.

Oscillation input: NuFIT 6.1 combined with the first JUNO data, with Super-Kamiokande atmospheric
data included (the analysis that gives Delta chi^2 = 9.4 for the ordering), Esteban et al.,
arXiv:2601.09791, Eqs. (3.1) and (5.2):
   dm21 = 7.530 (+0.096 / -0.097) e-5 eV^2
   dm31 = +2.519 (+0.017 / -0.020) e-3 eV^2   (normal ordering)
   dm32 = -2.484 (+0.026 / -0.026) e-3 eV^2   (inverted ordering)
The same fit without the atmospheric data (dm31 = 2.529 +/- 0.021, dm32 = -2.515 +0.031/-0.025) is
printed for comparison. Uncertainties are propagated by Monte Carlo, sampling each splitting from a
split normal distribution with the quoted asymmetric 1-sigma errors; intervals are 16th-84th percentiles.
Requires numpy and scipy.
"""
import numpy as np
from scipy.optimize import brentq

DATA = {"with SK-atm (default)": dict(dm21=(7.530e-5, 0.096e-5, 0.097e-5),
                                      dm31=(2.519e-3, 0.017e-3, 0.020e-3),
                                      dm32=(-2.484e-3, 0.026e-3, 0.026e-3)),
        "without SK-atm":        dict(dm21=(7.530e-5, 0.096e-5, 0.097e-5),
                                      dm31=(2.529e-3, 0.021e-3, 0.021e-3),
                                      dm32=(-2.515e-3, 0.031e-3, 0.025e-3))}

def masses(d, a=1.0):
    s = a*(1 + np.cos(d + 2*np.pi*np.arange(3)/3)); return s**2      # m_k, delocalized rule, K = 1/2
K = lambda m: m.sum()/np.sqrt(m).sum()**2
print("check K for random phases:", [round(K(masses(d)), 6) for d in (0.1, 0.5, 0.9)])

DS = np.linspace(0, np.pi/3, 4001)          # delta mod 2pi/3 and sign -> [0, pi/3]
_MS = np.sort((1 + np.cos(DS[:, None] + 2*np.pi*np.arange(3)/3))**2, axis=1)   # masses on the grid
_R = {"normal": (_MS[:, 1]**2 - _MS[:, 0]**2)/(_MS[:, 2]**2 - _MS[:, 0]**2),
      "inverted": (_MS[:, 2]**2 - _MS[:, 1]**2)/(_MS[:, 2]**2 - _MS[:, 0]**2)}
def solve(order, dm21, dm3):
    """Return (delta_nu, (m1, m2, m3)) in eV in standard labeling, for one ordering."""
    def ratio(d):
        m = np.sort(masses(d))
        if order == "normal":   # m1<m2<m3
            return (m[1]**2 - m[0]**2)/(m[2]**2 - m[0]**2) - dm21/dm3
        return (m[2]**2 - m[1]**2)/(m[2]**2 - m[0]**2) - dm21/abs(dm3)   # m3<m1<m2
    f = _R[order] - dm21/abs(dm3); i = np.where(np.sign(f[:-1]) != np.sign(f[1:]))[0][0]
    d = brentq(ratio, DS[i], DS[i+1]); m = np.sort(masses(d))
    m = m*np.sqrt(abs(dm3)/(m[2]**2 - m[0]**2))
    return d, (m if order == "normal" else np.array([m[1], m[2], m[0]]))

def draw(rng, c, up, lo, n):
    z = rng.standard_normal(n); return c + np.where(z > 0, up, lo)*z

# mixing angles for the effective masses, normal ordering: sin^2 theta12 from NuFIT 6.1 with JUNO (arXiv:2601.09791,
# Eq. 3.1); sin^2 theta13 from NuFIT 6.0, which the JUNO data do not constrain
s12, s13 = 0.3096, 0.02195
cE = np.array([(1-s12)*(1-s13), s12*(1-s13), s13])
def mbeta(m): return np.sqrt((cE*m**2).sum())
def mbb_range(m):
    ph = np.linspace(0, 2*np.pi, 181); A, B = np.meshgrid(ph, ph)
    v = np.abs(cE[0]*m[0] + cE[1]*m[1]*np.exp(1j*A) + cE[2]*m[2]*np.exp(1j*B)); return v.min(), v.max()

rng = np.random.default_rng(2026); N = 4000
for label, D in DATA.items():
    print(f"\n=== oscillation input: NuFIT 6.1 + JUNO, {label}")
    for order, key in (("normal", "dm31"), ("inverted", "dm32")):
        d0, m0 = solve(order, D["dm21"][0], D[key][0])
        a21 = draw(rng, *D["dm21"], N); a3 = draw(rng, *D[key], N)
        S = np.array([[*r[1], r[0]] for r in (solve(order, x, y) for x, y in zip(a21, a3))])
        q = lambda v: (np.percentile(v, 16), np.percentile(v, 84))
        sm = S[:, :3].sum(1)*1e3
        print(f"  {order:8s}: delta_nu = {d0:.4f};  m1, m2, m3 = {m0[0]*1e3:.2f}, {m0[1]*1e3:.2f}, {m0[2]*1e3:.2f} meV;"
              f"  sum = {m0.sum()*1e3:.2f} meV  (68%: {q(sm)[0]:.2f} to {q(sm)[1]:.2f})")
        print("            68% ranges: " + ", ".join(f"m{j+1} {q(S[:, j]*1e3)[0]:.3f}-{q(S[:, j]*1e3)[1]:.3f}" for j in range(3))
              + f" meV; delta_nu {q(S[:, 3])[0]:.4f}-{q(S[:, 3])[1]:.4f}")
        if order == "normal" and label.startswith("with"):
            mb = np.array([mbeta(r[:3]) for r in S[:800]])*1e3; lo_hi = np.array([mbb_range(r[:3]) for r in S[:800]])*1e3
            lo, hi = mbb_range(m0)
            print(f"            m_beta = {mbeta(m0)*1e3:.2f} meV (68%: {q(mb)[0]:.2f}-{q(mb)[1]:.2f});"
                  f" |m_bb| = {lo*1e3:.2f} to {hi*1e3:.2f} meV over Majorana phases"
                  f" (68% of upper end: {q(lo_hi[:,1])[0]:.2f}-{q(lo_hi[:,1])[1]:.2f})")
    D21, D31, D32 = D["dm21"][0], D["dm31"][0], D["dm32"][0]
    print(f"  minimal sums (lightest mass zero): normal {(np.sqrt(D21)+np.sqrt(D31))*1e3:.2f} meV;"
          f" inverted {(np.sqrt(abs(D32))+np.sqrt(abs(D32)-D21))*1e3:.2f} meV")
print("\nconstraints: DESI DR2 + CMB, sum < 64.2 meV (95%, LCDM); KATRIN m_beta < 450 meV; KamLAND-Zen |m_bb| < 28-122 meV")

# lepton mixing implied by using the same sheet-type basis for both sectors
P = np.roll(np.eye(3), 1, axis=0)
Wl = np.sqrt(.5)*np.eye(3) + .5*(np.exp(1j*2/9)*P + np.exp(-1j*2/9)*P.T)     # charged leptons (localized)
Wn = np.eye(3) + .5*(np.exp(1j*0.332)*P + np.exp(-1j*0.332)*P.T)             # neutrinos (delocalized)
U = np.linalg.eigh(Wl)[1].conj().T @ np.linalg.eigh(Wn)[1]
print("\nmixing check: operators commute =", np.allclose(Wl@Wn, Wn@Wl), "; |U|^2 =",
      np.round(np.abs(U)**2, 3).tolist(), "(a permutation: no mixing)")

# localized neutrinos (K = 2/3): no solution with non-negative amplitudes; signed variant below
D21, D31 = DATA["with SK-atm (default)"]["dm21"][0], DATA["with SK-atm (default)"]["dm31"][0]
def amps23(d): return 1 + np.sqrt(2)*np.cos(d + 2*np.pi*np.arange(3)/3)
def ratio23(d):
    m = np.sort(amps23(d)**2); return (m[1]**2-m[0]**2)/(m[2]**2-m[0]**2) - D21/D31
dd = np.linspace(0, 2*np.pi/3, 40001); fv = np.array([ratio23(d) for d in dd])
roots = [brentq(ratio23, dd[i], dd[i+1]) for i in np.where(np.sign(fv[:-1]) != np.sign(fv[1:]))[0]]
print("K = 2/3 (localized) normal-ordering solutions with non-negative amplitudes:",
      len([r for r in roots if (amps23(r) >= 0).all()]))
r = roots[0]; m = np.sort(amps23(r)**2); m = m*np.sqrt(D31/(m[2]**2-m[0]**2))
print(f"signed variant (one negative amplitude): m1 = {m[0]*1e3:.2f} meV, sum = {m.sum()*1e3:.1f} meV")
