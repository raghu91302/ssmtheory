#!/usr/bin/env python3
"""make_fig_ssm.py -- Fig. 2 of the Koide paper: the elements of the Selection-Stitch Model.

(a) growth: a stitch adds a node in the plane of a sheet, a lift adds one above a triangle;
(b) the FCC coordination cluster (cuboctahedron): one bond, the electron's footprint (C = 1),
    and the full 36-edge cluster with its 6 square faces, the muon's (C = 36 x 6 - 9 = 207);
(c) a tetrahedral void with a trapped node, the model's quark site;
(d) the twelve FCC bonds in three groups of four (zero x, y or z coordinate), the spatial parts of
    the three sixteen-cells of D4; the cycle (x,y,z) -> (z,x,y) permutes them and is the threefold
    rotation about [111].
Requires numpy and matplotlib.
"""
import itertools as it
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

INK, GRAY, LIGHT = "#222222", "#9a9a9a", "#d9d9d9"
C1, C2, C3 = "#c0392b", "#2471a3", "#1e8449"      # three groups / highlights
plt.rcParams.update({"font.family": "serif", "font.size": 11.5, "mathtext.fontset": "stix"})

def clean(ax, lim=1.25, elev=18, azim=-60):
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim)
    ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=elev, azim=azim); ax.set_axis_off()

def line(ax, p, q, **kw):
    ax.plot(*np.array([p, q]).T, **kw)

fig = plt.figure(figsize=(7.2, 6.4))

# ---------------------------------------------------------------- (a) stitch and lift
ax = fig.add_subplot(2, 2, 1, projection="3d")
a1, a2 = np.array([1.0, 0, 0]), np.array([0.5, np.sqrt(3) / 2, 0])
sheet = [i * a1 + j * a2 for i in range(-2, 3) for j in range(-2, 3) if abs(i + j) <= 2]
for p, q in it.combinations(sheet, 2):
    if np.isclose(np.linalg.norm(p - q), 1):
        line(ax, p, q, color=LIGHT, lw=0.9)
P = np.array(sheet)
ax.scatter(*P.T, s=14, color=GRAY, depthshade=False)
# stitch: new node at the in-plane apex over a boundary edge of the sheet
e0, e1 = np.array([2.0, 0, 0]), np.array([1.5, -np.sqrt(3) / 2, 0])
s = np.array([2.5, -np.sqrt(3) / 2, 0])
for q in (e0, e1):
    line(ax, s, q, color=C2, lw=2)
ax.scatter(*s, s=40, color=C2, depthshade=False)
ax.text(s[0] + 0.15, s[1] - 0.45, 0, "stitch", color=C2, ha="center")
# lift: new node above a triangle centroid at height sqrt(2/3)
tri = [np.zeros(3), a1, a2]
c = sum(tri) / 3 + np.array([0, 0, np.sqrt(2 / 3)])
for q in tri:
    line(ax, c, q, color=C1, lw=2)
ax.add_collection3d(Poly3DCollection([tri], facecolor=C1, alpha=0.18, edgecolor="none"))
ax.scatter(*c, s=40, color=C1, depthshade=False)
ax.text(c[0] - 0.35, c[1], c[2] + 0.2, "lift", color=C1, ha="center")
clean(ax, lim=1.55, elev=38, azim=-75)
ax.set_title("(a) growth: stitch and lift", loc="left", fontsize=11.7)

# ---------------------------------------------------------------- (b) cuboctahedral cluster
ax = fig.add_subplot(2, 2, 2, projection="3d")
nb = np.array(sorted({p for s_ in it.product((1, -1), repeat=2)
                      for p in it.permutations((s_[0], s_[1], 0))}), float) / np.sqrt(2)
O = np.zeros(3)
for p, q in it.combinations(nb, 2):            # the 24 shell edges
    if np.isclose(np.linalg.norm(p - q), 1):
        line(ax, p, q, color=GRAY, lw=0.8)
for p in nb:                                    # the 12 spokes
    line(ax, O, p, color=LIGHT, lw=0.8)
# the six square faces
sq = []
for ax_i in range(3):
    for sgn in (1, -1):
        pts = [p for p in nb if np.isclose(p[ax_i], sgn / np.sqrt(2))]
        ctr = np.mean(pts, axis=0)
        u = [k for k in range(3) if k != ax_i]
        pts.sort(key=lambda v: np.arctan2(v[u[1]] - ctr[u[1]], v[u[0]] - ctr[u[0]]))
        sq.append(pts)
ax.add_collection3d(Poly3DCollection(sq, facecolor=C2, alpha=0.10, edgecolor="none"))
e = nb[np.argmax(nb @ np.array([0.2, -1, 0.3]))]
line(ax, O, e, color=C1, lw=3)
ax.scatter(*nb.T, s=14, color=INK, depthshade=False)
ax.scatter(*O, s=30, color=C1, depthshade=False)
ax.text2D(0.02, 0.02, "red: one bond, electron ($C=1$)\nshaded squares: 6 of the 14 faces;\nmuon: $36\\times6-9=207$",
          transform=ax.transAxes, fontsize=9.8, va="bottom")
clean(ax, lim=0.85, elev=16, azim=-58)
ax.set_title("(b) coordination cluster and defects", loc="left", fontsize=11.7)

# ---------------------------------------------------------------- (c) tetrahedral void
ax = fig.add_subplot(2, 2, 3, projection="3d")
T = np.array([[0, 0, 0], [1, 1, 0], [1, 0, 1], [0, 1, 1]], float) / np.sqrt(2)
T -= T.mean(axis=0)
faces = [list(f) for f in it.combinations(T, 3)]
ax.add_collection3d(Poly3DCollection(faces, facecolor=LIGHT, alpha=0.08, edgecolor=GRAY, lw=0.8))
for p, q in it.combinations(T, 2):
    line(ax, p, q, color=GRAY, lw=1.0)
for k, v in enumerate(T):
    line(ax, O, v, color=C1 if k else C3, lw=2.2)
ax.scatter(*T.T, s=30, color=INK, depthshade=False)
ax.scatter(*O, s=45, color=C1, depthshade=False)
ax.text(*(T[0] * 0.5 + np.array([0, 0, -0.12])), "anchor", color=C3, fontsize=10.4, ha="center")
ax.text2D(0.02, 0.02, "extra node at the void center,\nbonded to the four corners", transform=ax.transAxes, fontsize=9.8)
clean(ax, lim=0.55, elev=22, azim=-30)
ax.set_title("(c) trapped node in a tetrahedral void", loc="left", fontsize=11.7)

# ---------------------------------------------------------------- (d) three groups of four bonds
ax = fig.add_subplot(2, 2, 4, projection="3d")
cols = [C1, C2, C3]
for p in nb:
    k = int(np.flatnonzero(np.isclose(p, 0))[0])
    line(ax, O, p, color=cols[k], lw=2)
    ax.scatter(*p, s=18, color=cols[k], depthshade=False)
for k in range(3):                                  # outline each group's square
    pts = [p for p in nb if np.isclose(p[k], 0)]
    u = [j for j in range(3) if j != k]
    pts.sort(key=lambda v: np.arctan2(v[u[1]], v[u[0]]))
    ax.add_collection3d(Poly3DCollection([pts], facecolor=cols[k], alpha=0.10, edgecolor=cols[k], lw=0.6))
d = np.ones(3) / np.sqrt(3)
line(ax, -1.05 * d, 1.05 * d, color=INK, lw=1, ls="--")
ax.text(*(1.12 * d), "[111]", fontsize=10.4)
ax.text2D(0.02, 0.02, "$x=0$, $y=0$, $z=0$: three groups of four;\n$(x,y,z)\\mapsto(z,x,y)$ permutes them",
          transform=ax.transAxes, fontsize=9.8)
clean(ax, lim=0.85, elev=16, azim=-58)
ax.set_title("(d) the three groups of FCC bonds", loc="left", fontsize=11.7)

plt.subplots_adjust(left=0.0, right=1.0, top=0.95, bottom=0.02, wspace=0.0, hspace=0.12)
fig.savefig("fig_ssm.pdf", bbox_inches="tight")
fig.savefig("fig_ssm.png", dpi=150, bbox_inches="tight")
print("wrote fig_ssm.pdf")
