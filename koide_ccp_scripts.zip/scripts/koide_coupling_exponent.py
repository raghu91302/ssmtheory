#!/usr/bin/env python3
"""koide_coupling_exponent.py -- the coupling exponent (Section 8, reply to the uniqueness question).

For a circulant family operator with diagonal f(n0) and off-diagonal f(n+), f(n) = n^alpha,
    K = (1 + 2 (n+/n0)^(2 alpha)) / 3 ,
so K = 2/3 needs (n+/n0)^alpha = 1/sqrt2, i.e. alpha* = ln 2 / (2 ln(n0/n+)).
Checks:
  E1  the formula for K against the eigenvalues of the circulant, for several alpha and counts;
  E2  alpha* for the structures of Table 5 that have three sheet types, and for the series A_d;
      for any structure with 0 < n+ < n0 some exponent works, so the exponent must be fixed physically;
  E3  the exponent is set by the extent of the state, not chosen: the coupling between two normalized
      uniform states on m and m' sites joined by b bonds is b / sqrt(m m'); a single site (m = 1)
      coupled to its n neighbors of one type gives sqrt(n) (alpha = 1/2), and two whole sheet types
      (m = m' = N, b = n N) give n (alpha = 1). Checked on an explicit periodic FCC lattice.
Requires numpy.
"""
import itertools as it
import numpy as np

ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")

P = np.roll(np.eye(3), 1, 0)
def K_circ(a, b, d):
    x = np.linalg.eigvalsh(a*np.eye(3) + b*(np.exp(1j*d)*P + np.exp(-1j*d)*P.T)); return (x**2).sum()/x.sum()**2
K_formula = lambda n0, npl, al: (1 + 2*(npl/n0)**(2*al))/3
# E1
for n0, npl in ((6, 3), (2, 3), (12, 4)):
    for al in (0.25, 0.5, 1.0):
        check(f"E1  K formula, counts ({n0},{npl},{npl}), alpha={al}",
              np.isclose(K_circ(n0**al, npl**al, 0.05), K_formula(n0, npl, al)))
# E2
print("\n  structure (n0, n+, n-)          alpha* for K = 2/3")
# counts (n0, n+) as listed in Table 5 of the paper (koide_geometry_survey.py), and the series A_d
rows = [("FCC <111>", 6, 3), ("Z^6 (0,0,0,1,1,1)", 6, 3), ("D_6", 30, 15), ("simple cubic <111>", 0, 3),
        ("BCC <111>", 2, 3), ("ABC graphite (no inter-sheet bonds)", 3, 0)] + \
       [(f"A_{dd}", dd*(dd-1), dd) for dd in (2, 3, 4, 5)]
for name, n0, npl in rows:
    if n0 == 0:   s = "none: no own-sheet bonds, no diagonal"
    elif npl == 0: s = "none: no inter-sheet bonds"
    elif npl >= n0: s = f"none for alpha > 0 (n+/n0 = {npl/n0:g}); alpha* = {np.log(2)/(2*np.log(n0/npl)):.3f}" if npl > n0 else "none: (n+/n0)^alpha = 1"
    else:          s = f"{np.log(2)/(2*np.log(n0/npl)):.3f}"
    print(f"  {name:40s} ({n0},{npl},{npl})   {s}")
check("E2  FCC requires exactly alpha = 1/2", np.isclose(np.log(2)/(2*np.log(2)), 0.5))
check("E2  BCC would need a negative exponent", np.log(2)/(2*np.log(2/3)) < 0)
# E3 on an explicit FCC lattice (even-sum points of a periodic 6^3 box)
L = 6
sites = [p for p in it.product(range(L), repeat=3) if sum(p) % 2 == 0]; idx = {p: i for i, p in enumerate(sites)}
bonds = sorted({q for s in it.product((1, -1), repeat=2) for q in it.permutations((s[0], s[1], 0))})
Nn = len(sites); H = np.zeros((Nn, Nn))
for p in sites:
    for b in bonds:
        q = tuple((np.add(p, b)) % L); H[idx[p], idx[q]] = 1
typ = np.array([(sum(p)//2) % 3 for p in sites])
def uniform(mask): v = mask.astype(float); return v/np.linalg.norm(v)
s0 = idx[(0, 0, 0)]; site = np.zeros(Nn); site[s0] = 1
nbr = H[s0] > 0
for l, n_exp in ((0, 6), (1, 3), (2, 3)):
    shell = uniform(nbr & (typ == l))
    check(f"E3  single site -> normalized shell of type {l}: coupling sqrt({n_exp})", np.isclose(shell@H@site, np.sqrt(n_exp)))
for k, l, n_exp in ((0, 0, 6), (0, 1, 3), (0, 2, 3)):
    A, B = uniform(typ == k), uniform(typ == l)
    check(f"E3  whole sheet type {k} -> whole type {l}: coupling {n_exp}", np.isclose(B@H@A, n_exp))
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
