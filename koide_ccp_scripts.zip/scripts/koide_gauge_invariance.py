#!/usr/bin/env python3
"""koide_gauge_invariance.py -- the gauge-invariant content of the phase delta (Section 6).

Checks:
  G1  on an open stack of sheets (a chain of layers; the argument holds for any layered lattice), a uniform phase e^{i delta} on every up-hop is removed by the
      rephasing U = diag(e^{i delta n}), n the layer index: the spectrum does not depend on delta;
  G2  on a closed ring of N sheets the phase survives only as the total N*delta, and the spectrum is
      that of the real ring with every Bloch momentum shifted by delta per sheet;
  G3  the eigenvalues of the family operator W of Eq. (6) are the values of its symbol,
      sqrt6 + 2 sqrt3 cos(theta) (the dispersion of the effective three-sheet chain defined by the A4
      couplings, not an FCC band), at the Bloch phases theta_k = delta + 2 pi k/3 per sheet;
  G4  inversion and time reversal send theta -> -theta, so they map the sector delta onto the sector
      -delta, which has the same masses; a sector mapped onto itself (delta = 0 or pi/3 mod 2pi/3)
      contains a degenerate pair (Proposition 4);
  G5  with K = 2/3 imposed, the electron and muon fix delta = 0.2222220470(4), which differs from 2/9
      by about 440 standard deviations of the input m_mu/m_e;
  G6  Koide's ratio of the running charged-lepton masses at M_Z (Xing and Zhang, PLB 635 (2006) 107).
Requires numpy and scipy.
"""
import numpy as np
from scipy.optimize import brentq

ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")

d = 0.2222220
# G1
N = 30
H0 = np.zeros((N, N)); Hd = np.zeros((N, N), complex)
for n in range(N-1):
    H0[n+1, n] = H0[n, n+1] = 1; Hd[n+1, n] = np.exp(1j*d); Hd[n, n+1] = np.exp(-1j*d)
U = np.diag(np.exp(1j*d*np.arange(N)))
check("G1  open stack: U H_0 U^dag = H_delta", np.allclose(U@H0@U.conj().T, Hd))
check("G1  open stack: spectrum independent of delta", np.allclose(np.linalg.eigvalsh(H0), np.linalg.eigvalsh(Hd)))
# G2
Hr = Hd.copy(); Hr[0, N-1] = np.exp(1j*d); Hr[N-1, 0] = np.exp(-1j*d)
H0r = H0.copy(); H0r[0, N-1] = H0r[N-1, 0] = 1
check("G2  ring: spectrum depends on delta", not np.allclose(np.linalg.eigvalsh(Hr), np.linalg.eigvalsh(H0r)))
check("G2  ring: spectrum = real ring with Bloch momenta shifted by delta",
      np.allclose(np.sort(np.linalg.eigvalsh(Hr)), np.sort(2*np.cos(2*np.pi*np.arange(N)/N + d))))
# G3
P = np.roll(np.eye(3), 1, 0)
W = lambda x: np.sqrt(6)*np.eye(3) + np.sqrt(3)*(np.exp(1j*x)*P + np.exp(-1j*x)*P.T)
band = lambda th: np.sqrt(6) + 2*np.sqrt(3)*np.cos(th)
for x in (0.0, 0.1, d, 0.25):
    check(f"G3  delta={x:.4f}: eig(W) = symbol at delta + 2 pi k/3",
          np.allclose(np.sort(np.linalg.eigvalsh(W(x))), np.sort(band(x + 2*np.pi*np.arange(3)/3))))
# G4
m = lambda x: np.sort(band(x + 2*np.pi*np.arange(3)/3)**2)
check("G4  sectors delta and -delta have the same masses", np.allclose(m(d), m(-d)))
for x in (0.0, np.pi/3):
    v = m(x); check(f"G4  sector closed under theta->-theta (delta={x:.4f}) has a degenerate pair",
                    np.isclose(v[0], v[1]) or np.isclose(v[1], v[2]))
check("G4  generic sector (fitted delta) is non-degenerate", np.min(np.diff(m(d))) > 1e-3)
# G5
def ratio(x): return ((1+np.sqrt(2)*np.cos(x+4*np.pi/3))/(1+np.sqrt(2)*np.cos(x+2*np.pi/3)))**2
r0, sr = 206.7682830, 0.0000046                      # m_mu/m_e (CODATA 2018 / PDG 2024)
d0 = brentq(lambda x: ratio(x)-r0, 0.15, 0.26); dd = abs(brentq(lambda x: ratio(x)-(r0+sr), 0.15, 0.26)-d0)
print(f"     delta = {d0:.9f} +/- {dd:.1e};  2/9 = {2/9:.9f};  difference {d0-2/9:+.2e} = {(d0-2/9)/dd:+.0f} sigma")
check("G5  with K = 2/3 imposed, delta differs from 2/9 by more than 100 sigma", abs(d0-2/9)/dd > 100)
# G6
me, mmu, mtau = 0.486755106, 102.740394, 1746.56        # MeV, running masses at M_Z (Xing-Zhang 2006)
Kz = (me+mmu+mtau)/(np.sqrt(me)+np.sqrt(mmu)+np.sqrt(mtau))**2
pole = np.array([0.51099895, 105.6583755, 1776.93])
Kp = pole.sum()/np.sqrt(pole).sum()**2
print(f"     K(pole, PDG 2024) = {Kp:.6f};  K(running, M_Z) = {Kz:.6f}")
check("G6  running masses at M_Z exceed K = 2/3 by about 1.3e-3", 1e-3 < Kz-2/3 < 3e-3)
print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
