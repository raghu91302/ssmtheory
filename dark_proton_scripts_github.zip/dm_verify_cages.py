#!/usr/bin/env python3
"""dm_verify_cages.py
Selection-Stitch Model -- dark matter annihilation paper.
Enumerates ALL connected vertex subsets (sizes 3--10) of the ten vertices at the
two-octahedron merger interface, applies the four stability constraints
(a) unique equidistant center, (b) radius >= metric wall L/sqrt(3),
(c) strain balance (unit bond vectors sum to zero), (d) non-coplanar,
and shows that exactly two cage types survive: the regular tetrahedron
(radius 0.612 L) and the regular octahedron (radius 0.707 L).
Reproduces the Result in Section 4. Depends only on numpy.
"""
import numpy as np
from itertools import combinations

a = 2.0
L = a/np.sqrt(2)
wall = L/np.sqrt(3)          # metric wall: minimum equidistant radius

# verified merger interface: oct void A at (1,1,1), nearest-neighbor B at (0,2,1)
cA = np.array([1., 1., 1.]); cB = np.array([0., 2., 1.])
unit = [np.array(u) for u in [(1, 0, 0), (-1, 0, 0), (0, 1, 0),
                              (0, -1, 0), (0, 0, 1), (0, 0, -1)]]
allv = []
for v in [cA+u for u in unit] + [cB+u for u in unit]:
    if not any(np.allclose(v, w) for w in allv):
        allv.append(v)
allv = np.array(allv)
n = len(allv)

# interface bond graph: bonds between interface vertices at distance L
bond = np.zeros((n, n), dtype=bool)
for i, j in combinations(range(n), 2):
    if abs(np.linalg.norm(allv[i]-allv[j]) - L) < 1e-9:
        bond[i, j] = bond[j, i] = True


def is_connected(idx):
    idx = list(idx)
    seen = {idx[0]}; stack = [idx[0]]
    while stack:
        x = stack.pop()
        for y in idx:
            if y not in seen and bond[x, y]:
                seen.add(y); stack.append(y)
    return len(seen) == len(idx)


def equidist_center(P):
    p0 = P[0]
    A = np.array([2*(pj-p0) for pj in P[1:]])
    b = np.array([pj@pj - p0@p0 for pj in P[1:]])
    c, *_ = np.linalg.lstsq(A, b, rcond=None)
    return c


def coplanar(P):
    return np.linalg.matrix_rank(P[1:]-P[0], tol=1e-6) < 3


def main():
    print(f"L = {L:.4f},  metric wall L/sqrt(3) = {wall/L:.4f} L")
    print(f"distinct interface vertices: {n}")
    print(f"interface bonds (length L): {int(bond.sum()//2)}\n")
    total = 0; conn = 0
    survivors = {}
    for k in range(3, n+1):
        for idx in combinations(range(n), k):
            total += 1
            if not is_connected(idx):
                continue
            conn += 1
            P = allv[list(idx)]
            c = equidist_center(P)
            d = np.linalg.norm(P-c, axis=1)
            if d.std() > 1e-6:              # (a) equidistant
                continue
            if d.mean() < wall-1e-9:        # (b) above the wall
                continue
            if np.linalg.norm(((P-c)/d[:, None]).sum(0)) > 1e-6:   # (c) strain balance
                continue
            if coplanar(P):                 # (d) non-coplanar / unique center
                continue
            ev = tuple(sorted({round(np.linalg.norm(P[i]-P[j])/L, 3)
                               for i, j in combinations(range(k), 2)}))
            shape = ("regular tetrahedron" if k == 4 and ev == (1.0,)
                     else "regular octahedron" if k == 6 and ev == (1.0, 1.414)
                     else f"OTHER k={k} edges={ev}")
            survivors[shape] = survivors.get(shape, 0) + 1
    print(f"subsets examined (k=3..{n}): {total}; connected: {conn}")
    print(f"{'survivor type':<24} {'count':>6}")
    for shape, cnt in sorted(survivors.items()):
        print(f"{shape:<24} {cnt:>6}")
    others = [sh for sh in survivors if sh.startswith("OTHER")]
    print()
    if not others:
        print("RESULT: only the regular tetrahedron and regular octahedron survive")
        print("the four constraints, over the FULL connected-subset enumeration.")
    else:
        print("WARNING: additional cage types survive -- see above.")


if __name__ == "__main__":
    main()
