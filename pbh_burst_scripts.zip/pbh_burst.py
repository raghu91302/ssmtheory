"""Numbers and figures for the universal terminal burst under geometric evaporation.
Anchors from Kulkarni, EPJP 141, 916 (2026): xi=1 fm; tau_eff(1e15 g)=1.1 ms with e^{1.5}
code-suppression; tau ∝ M^2 unsuppressed below xi; coefficient uncertain at O(1)."""
import numpy as np, math
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

G,c=6.674e-11,2.998e8
xi=1e-15
M_xi=xi*c**2/(2*G)                      # kg
tau15_eff=1.1e-3; supp=math.exp(1.5)
kappa=(tau15_eff/supp)/(1e12)**2        # s/kg^2, unsuppressed
tau_b=kappa*M_xi**2
E_b=M_xi*c**2
print(f"M_xi = {M_xi:.2e} kg = {M_xi*1e3:.2e} g")
print(f"tau_b (unsuppressed terminal phase) ~ {tau_b*1e3:.2f} ms  [O(1)]")
print(f"E_b = M_xi c^2 = {E_b:.2e} J = {E_b*1e7:.2e} erg")
print(f"mean luminosity ~ {E_b/tau_b:.1e} W")

# Fig 1: light-curve shape, both laws, normalized at t_rem = tau_b
tr=np.logspace(-3,0,300)   # (tau-t)/tau_b
Lg=tr**-0.5; Lh=tr**(-2/3)
fig,ax=plt.subplots(figsize=(5.2,3.6))
ax.loglog(tr,Lg,'b-',lw=1.8,label=r'geometric: $L\propto(\tau-t)^{-1/2}$')
ax.loglog(tr,Lh,'k--',lw=1.4,label=r'Hawking: $L\propto(\tau-t)^{-2/3}$')
ax.set_xlabel(r'remaining lifetime $(\tau-t)/\tau_b$'); ax.set_ylabel('luminosity (normalized)')
ax.legend(fontsize=8); ax.grid(alpha=0.25,which='both')
fig.tight_layout(); fig.savefig("figP1_lightcurve.pdf")

# Fig 2: energy emitted in the final Dt, both laws, with the universal total marked
dt=np.logspace(-4,0,300)
Eg=dt**0.5; Eh=dt**(1/3)
fig,ax=plt.subplots(figsize=(5.2,3.6))
ax.loglog(dt,Eg,'b-',lw=1.8,label=r'geometric: $E(<\Delta t)\propto\Delta t^{1/2}$')
ax.loglog(dt,Eh,'k--',lw=1.4,label=r'Hawking: $E(<\Delta t)\propto\Delta t^{1/3}$')
ax.axhline(1.0,color='b',lw=0.8,ls=':',alpha=0.8)
ax.text(1.3e-4,1.06,r'universal total $E_b=M_\xi c^2\simeq6\times10^{35}$ erg',fontsize=7,color='b')
ax.set_xlabel(r'final interval $\Delta t/\tau_b$'); ax.set_ylabel(r'$E(<\Delta t)/E_b$')
ax.legend(fontsize=8,loc='lower right'); ax.grid(alpha=0.25,which='both')
fig.tight_layout(); fig.savefig("figP2_energy.pdf")

# Fig 3: population inversion timeline
fig,ax=plt.subplots(figsize=(5.6,3.2))
bands=[(1e14,3.8e15,'thermalized\nbefore BBN','0.85'),
       (3.8e15,8.8e15,'BBN /\nphotodissoc.','0.7'),
       (8.8e15,1.75e16,r'CMB $\mu$-dist.','0.55'),
       (1.75e16,2.2e16,r'$y$-dist.','0.4'),
       (2.2e16,10**16.5,'recomb. $\\to$ today','0.25')]
for lo,hi,lab,g in bands:
    ax.axvspan(lo,hi,color=str(g),alpha=0.8)
    ax.text(math.sqrt(lo*hi),0.62,lab,ha='center',fontsize=6.5,rotation=0)
ax.axvline(10**16.5,color='b',lw=2); ax.text(10**16.55,0.9,r'$M_{\rm cut}$: bursting today (geometric)',color='b',fontsize=7)
ax.axvline(5e14,color='r',lw=2,ls='--'); ax.text(5.4e14,0.06,r'$M_\star$: Hawking bursters (long gone here)',color='r',fontsize=7)
ax.set_xscale('log'); ax.set_xlim(1e14,3e17); ax.set_yticks([])
ax.set_xlabel('PBH mass (g)')
ax.set_title('Where each mass dies under the geometric channel',fontsize=9)
fig.tight_layout(); fig.savefig("figP3_inversion.pdf")
print("figures written")
