#!/usr/bin/env python3
"""
nt_anchor.py
------------
Backs Section 5 (the anchor channel is color-diagonal on round-trip).

The cage kinetic term factorizes as T = (J3 - I3) (x) J2 on (3 colors)x(sym/asy).
Color = symmetric sector, dark = antisymmetric. The anchor breaks the within-pair
symmetry: H_anchor = I3 (x) sigma_z. It is genuinely off-diagonal in the
COLOR/DARK axis (it leaks color to dark). But the transport-relevant induced
color->color map (leak to dark, then recover back) is the IDENTITY: zero
off-diagonal color content. The anchor off-diagonality lies entirely in the
color/dark axis, orthogonal to the root directions of su(3). Because the colors
are bond-disjoint, color i leaks only into its own dark partner |-_i>, never into
color j. So the anchor supplies no operator proportional to J3-I3 on the qutrit.

Requires: numpy.  Run:  python3 nt_anchor.py
"""
import numpy as np
np.set_printoptions(precision=3, suppress=True)
J3=np.array([[0,1,1],[1,0,1],[1,1,0]]); I3=np.eye(3)
sym=np.array([1,1])/np.sqrt(2); asy=np.array([1,-1])/np.sqrt(2)
def color(i): v=np.zeros(3); v[i]=1; return np.kron(v,sym)
def dark(i):  v=np.zeros(3); v[i]=1; return np.kron(v,asy)
Pc=np.column_stack([color(i) for i in range(3)]); Pd=np.column_stack([dark(i) for i in range(3)])
Hanchor=np.kron(I3, np.array([[1,0],[0,-1]]))
cd=Pc.T@Hanchor@Pd
print("anchor color<->dark block:\n",cd)
print(f"anchor leaks color->dark (off-diagonal in color/dark axis): {np.any(np.abs(cd)>1e-9)}")
back=(Pc.T@Hanchor@Pd)@(Pd.T@Hanchor@Pc)
off=back-np.diag(np.diag(back))
print("\ninduced color->color map (leak to dark, recover back):\n",back)
print(f"off-diagonal color-mixing (root) content: {np.max(np.abs(off)):.3f}")
print(f"matches a J3-I3 root generator: {np.max(np.abs(off))>1e-9}")
print("=> anchor off-diagonality is color/dark only; round-trip is color-diagonal.")
