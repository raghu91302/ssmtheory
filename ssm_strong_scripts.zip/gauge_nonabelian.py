#!/usr/bin/env python3
"""
gauge_nonabelian.py
-------------------
Backs Sections 4-5 (integer unification, and the well-posed SU(3) gauge theory).

Establishes:
  (1) the integer chain complex closes (d1 d2 = 0 over Z), so an integer-charge
      code exists with triality as its mod-3 reduction; H1 = Z^3 with NO torsion
      (over Q, F2, F3 the rank is 3), so triality here is the mod-3 reduction of
      integer charge, NOT a topologically forced class -- stated as a negative;
  (2) the SU(3) Gauss law at an FCC vertex (12 links = 6 fundamental + 6 anti)
      has a 513-dimensional gauge-invariant subspace; it is nonzero precisely
      because net triality 6-6 = 0 mod 3 -- the abelian triality condition is the
      center-reduction of the non-abelian Gauss law's solvability;
  (3) the SU(3) plaquette term on a triangular plaquette is gauge-invariant
      (commutes with the vertex Gauss law to machine precision): a consistent
      Kogut-Susskind SU(3) Hamiltonian is CONSTRUCTIBLE on this lattice.

This establishes the KINEMATIC scaffold only. Confinement, asymptotic freedom,
and Lambda_QCD are dynamical and remain open.

Requires: numpy.  Run:  python3 gauge_nonabelian.py
"""
import numpy as np, itertools
from collections import defaultdict
Lc=2; basis=[(0,0,0),(.5,.5,0),(.5,0,.5),(0,.5,.5)]
atoms=sorted({tuple(np.round([(c+b[0])%Lc,(d+b[1])%Lc,(e+b[2])%Lc],6))
              for c in range(Lc) for d in range(Lc) for e in range(Lc) for b in basis})
A=[np.array(p) for p in atoms]; N=len(atoms)
def md(p,q):
    x=np.asarray(p,float)-np.asarray(q,float); return x-Lc*np.round(x/Lc)
def dist(p,q): return np.linalg.norm(md(p,q))
NN=1/np.sqrt(2)
edges=[(i,j) for i in range(N) for j in range(i+1,N) if abs(dist(A[i],A[j])-NN)<1e-6]
E=len(edges); eidx={e:k for k,e in enumerate(edges)}
def ek(i,j): return (min(i,j),max(i,j))
adj={v:set() for v in range(N)}
for (i,j) in edges: adj[i].add(j); adj[j].add(i)
tris=sorted({tuple(sorted((i,j,k))) for i in range(N) for j in adj[i] for k in adj[i]&adj[j]})
d1=np.zeros((N,E),int)
for k,(i,j) in enumerate(edges): d1[i,k]=-1; d1[j,k]=1
d2=np.zeros((E,len(tris)),int)
for t,(a,b,c) in enumerate(tris):
    d2[eidx[ek(a,b)],t]+=1; d2[eidx[ek(b,c)],t]+=1; d2[eidx[ek(a,c)],t]-=1
def rmod(M,p):
    M=M.copy()%p; M=M.astype(np.int64); rows,cols=M.shape; r=0
    for c in range(cols):
        pv=None
        for i in range(r,rows):
            if M[i,c]%p: pv=i;break
        if pv is None: continue
        M[[r,pv]]=M[[pv,r]]; M[r]=(M[r]*pow(int(M[r,c]),p-2,p))%p
        for i in range(rows):
            if i!=r and M[i,c]%p: M[i]=(M[i]-M[i,c]*M[r])%p
        r+=1
    return r
print("(1) integer complex d1 d2 = 0 over Z:", np.all(d1@d2==0))
H1Q=E-int(round(np.linalg.matrix_rank(d1.astype(float))))-int(round(np.linalg.matrix_rank(d2.astype(float))))
H12=E-rmod(d1,2)-rmod(d2,2); H13=E-rmod(d1,3)-rmod(d2,3)
print(f"    H1: Q={H1Q}, F2={H12}, F3={H13}  -> 3-torsion: {'YES' if H13>H1Q else 'no (triality is the mod-3 reduction, not forced)'}")

# (2) SU(3) singlet multiplicity at a 12-link vertex (6 fund + 6 antifund)
def tensor_fund(m):
    out=defaultdict(int)
    for (p,q),v in m.items():
        out[(p+1,q)]+=v
        if p>0: out[(p-1,q+1)]+=v
        if q>0: out[(p,q-1)]+=v
    return out
m={(0,0):1}
for _ in range(6): m=tensor_fund(m)
vertex=sum(v*v for v in m.values())
print(f"(2) SU(3) gauge-invariant dim at an FCC vertex (6 fund + 6 anti) = {vertex} "
      f"(nonzero because net triality 0 mod 3)")

# (3) SU(3) plaquette gauge-invariance (machine precision)
lam=[np.array(x,complex) for x in [
 [[0,1,0],[1,0,0],[0,0,0]],[[0,-1j,0],[1j,0,0],[0,0,0]],[[1,0,0],[0,-1,0],[0,0,0]],
 [[0,0,1],[0,0,0],[1,0,0]],[[0,0,-1j],[0,0,0],[1j,0,0]],[[0,0,0],[0,0,1],[0,1,0]],
 [[0,0,0],[0,0,-1j],[0,1j,0]],np.array([[1,0,0],[0,1,0],[0,0,-2]])/np.sqrt(3)]]
T=[l/2 for l in lam]
np.random.seed(0)
def rsu3():
    X=np.random.randn(3,3)+1j*np.random.randn(3,3); Q,_=np.linalg.qr(X); return Q/(np.linalg.det(Q)**(1/3))
mv=0
for _ in range(200):
    Uab,Ubc,Uca=rsu3(),rsu3(),rsu3()
    for a in range(8):
        dW=(-1j*Uab@T[a])@Ubc@Uca + Uab@(1j*T[a]@Ubc)@Uca
        mv=max(mv,abs(np.trace(dW)))
print(f"(3) SU(3) plaquette gauge-invariance: max |d Tr(W)| = {mv:.1e} "
      f"-> Kogut-Susskind SU(3) Hamiltonian is constructible (well-posed).")
print("\nKINEMATIC scaffold only. Confinement / asymptotic freedom / Lambda_QCD remain open.")
