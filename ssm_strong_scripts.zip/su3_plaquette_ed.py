#!/usr/bin/env python3
"""
su3_plaquette_ed.py
-------------------
Backs the dynamical foothold: exact diagonalization of the single-plaquette
SU(3) Kogut-Susskind Hamiltonian H = H_E - lambda H_B on the gauge-invariant
sector (class functions / characters), truncated by Casimir.

H_E = Casimir (diagonal in irreps); H_B = fundamental-character multiplication
(off-diagonal via SU(3) fusion). Results:
  - spectrum is real, Hermitian, and converges fast with the Casimir cutoff;
  - strong-coupling limit (lambda->0): ground = trivial irrep (C2=0), gap =
    C2(fundamental) = 4/3 (the strong-coupling mass gap, no tuning);
  - as lambda grows (weak coupling) the ground spreads over higher irreps and
    the level structure reorganizes (the known single-plaquette crossover).

This confirms the full H_E+H_B is sensible with the correct 4/3 gap. It is the
UNIVERSAL single-plaquette problem (geometry-independent at one plaquette); it
does not probe triangular-specific physics or continuum confinement.

Requires: numpy.  Run:  python3 su3_plaquette_ed.py
"""
import numpy as np
from numpy.linalg import eigh
def C2(pq): p,q=pq; return (p*p+q*q+p*q)/3.0+(p+q)
def fund_fusion(pq):
    p,q=pq; out=[(p+1,q)]
    if p>=1: out.append((p-1,q+1))
    if q>=1: out.append((p,q-1))
    return out
def build(cut):
    irr=sorted({(p,q) for p in range(12) for q in range(12) if C2((p,q))<=cut+1e-9}, key=C2)
    idx={r:i for i,r in enumerate(irr)}; n=len(irr)
    HE=np.diag([C2(r) for r in irr]); Chi=np.zeros((n,n))
    for r in irr:
        for rp in fund_fusion(r):
            if rp in idx: Chi[idx[rp],idx[r]]+=1.0
    return irr,HE,0.5*(Chi+Chi.T)
print("convergence with Casimir cutoff (lambda=1):")
for cut in [2,4,6,10,15]:
    irr,HE,HB=build(cut); w=eigh(HE-HB)[0]
    print(f"  C2<={cut:>2}: dim={len(irr):>3} E0={w[0]:>9.5f} gap={w[1]-w[0]:>9.5f}")
irr,HE,HB=build(15)
print(f"\nspectrum vs coupling (Hermitian: {np.allclose(HB,HB.T)}):")
print(f"  {'lambda':>7} {'E0':>9} {'gap':>9} {'<C2>_ground':>12}")
for lam in [0.0,0.5,1.0,2.0,4.0,8.0]:
    w,V=eigh(HE-lam*HB); g=V[:,0]
    c2=sum((g[i]**2)*C2(irr[i]) for i in range(len(irr)))
    print(f"  {lam:>7.2f} {w[0]:>9.5f} {w[1]-w[0]:>9.5f} {c2:>12.4f}")
print(f"\nstrong-coupling gap (lambda->0) = C2(fundamental) = {C2((1,0)):.4f}")
