#!/usr/bin/env python3
"""
nt_temporal.py
--------------
Backs Section 7 (temporal resolution).

The spatial obstruction (Secs 3-6) forbids an off-diagonal color generator built
from the bond-disjoint cage. The temporal/Wilson direction evades it: a temporal
link is the time-evolution transporter of the color qutrit over one step,
U_t = exp(-i H_cage dt) projected onto the color sector. The cage kinetic term
T = (J3 - I3) (x) J2 acts on the color sector (J2 = +1) as (J3 - I3), which is
OFF-DIAGONAL. Hence the temporal link is color-mixing (non-monomial), supplying
exactly the root direction no spatial channel could.

Moreover the single off-diagonal generator (J3 - I3), together with the Cartan
torus {lambda3, lambda8} from the bond phases, closes under commutation to the
full 8-dimensional su(3). So the 4D construction reaches the entire color algebra.

This is an ALGEBRA-level (kinematic) result. Continuum confinement, running, and
Lambda_QCD are dynamical and remain open.

Requires: numpy, scipy.  Run:  python3 nt_temporal.py
"""
import numpy as np
from scipy.linalg import expm
np.set_printoptions(precision=3, suppress=True)

# (1) temporal link is off-diagonal on color
J3=np.array([[0,1,1],[1,0,1],[1,1,0]],complex); I3=np.eye(3)
sym=np.array([1,1])/np.sqrt(2)
def color(i): v=np.zeros(3); v[i]=1; return np.kron(v,sym)
Pc=np.column_stack([color(i) for i in range(3)])
T=np.kron(J3-I3, np.array([[0,1],[1,0]]))     # full cage kinetic term
Hcol=Pc.T@T@Pc                                 # projected to color sector
print("cage kinetic term on color sector =\n", Hcol.real)
def is_mono(U,t=1e-9):
    A=np.abs(U); return all(np.sum(A[i,:]>t)==1 for i in range(3)) and all(np.sum(A[:,j]>t)==1 for j in range(3))
for dt in (0.3,1.0):
    Ut=expm(-1j*dt*Hcol); Ut=Ut/np.linalg.det(Ut)**(1/3)
    off=np.max(np.abs(Ut-np.diag(np.diag(Ut))))
    print(f"  temporal link dt={dt}: off-diagonal={off:.3f}, monomial={is_mono(Ut)} (color-mixing)")

# (2) closure: torus + temporal generator -> su(3) (dim 8)
g=lambda M:1j*(M-np.trace(M)/3*np.eye(3))
l3=np.array([[1,0,0],[0,-1,0],[0,0,0]],complex); l8=np.array([[1,0,0],[0,1,0],[0,0,-2]],complex)/np.sqrt(3)
su3=[1j*x for x in [
 np.array([[0,1,0],[1,0,0],[0,0,0]],complex),np.array([[0,-1j,0],[1j,0,0],[0,0,0]]),l3,
 np.array([[0,0,1],[0,0,0],[1,0,0]],complex),np.array([[0,0,-1j],[0,0,0],[1j,0,0]]),
 np.array([[0,0,0],[0,0,1],[0,1,0]],complex),np.array([[0,0,0],[0,0,-1j],[0,1j,0]]),l8]]
B=np.array([s.flatten() for s in su3]).T
def proj(M):
    c,_,_,_=np.linalg.lstsq(B,M.flatten(),rcond=None); return B@c
def closure(seeds,tol=1e-9):
    basis=[]
    def indep(v):
        if not basis: return np.linalg.norm(v)>tol
        A=np.array(basis).T; c,_,_,_=np.linalg.lstsq(A,v,rcond=None); return np.linalg.norm(A@c-v)>tol
    def add(M):
        v=proj(M)
        if indep(v): basis.append(v); return True
        return False
    for s in seeds: add(s)
    ch=True
    while ch and len(basis)<8:
        ch=False
        cur=[np.array(b).reshape(3,3) for b in basis]
        for a in cur:
            for b in cur:
                if add(a@b-b@a): ch=True
    return len(basis)
G=g(J3-I3)
print(f"\nLie closure (su(3) = 8):")
print(f"  torus only {{l3,l8}}            : dim {closure([1j*l3,1j*l8])}")
print(f"  torus + temporal {{l3,l8,J3-I3}}: dim {closure([1j*l3,1j*l8,G])}")
print(f"  full Gell-Mann (sanity)        : dim {closure(su3)}")
print("=> the temporal link supplies the off-diagonal generator; with the torus it")
print("   closes the full su(3) algebra. (Algebra/kinematic level; dynamics open.)")
