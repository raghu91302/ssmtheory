#!/usr/bin/env python3
"""
gauge_geometry.py
-----------------
Backs Section 2 (the FCC complex is gauge-ready).

Establishes:
  (1) the minimal closed loops of the FCC nearest-neighbor graph are TRIANGLES
      (close-packed), each bond in exactly four of them: a gauge action on this
      lattice is triangular, not square;
  (2) every triangular plaquette carries exactly one bond of each of the three
      coordinate-plane color classes (R,G,B) -- the elementary loops are not
      color-blind, the geometric prerequisite for color-mixing dynamics.

Requires: numpy.  Run:  python3 gauge_geometry.py
"""
import numpy as np, itertools
from collections import Counter
Lc=2; basis=[(0,0,0),(.5,.5,0),(.5,0,.5),(0,.5,.5)]
atoms=sorted({tuple(np.round([(c+b[0])%Lc,(d+b[1])%Lc,(e+b[2])%Lc],6))
              for c in range(Lc) for d in range(Lc) for e in range(Lc) for b in basis})
A=[np.array(p) for p in atoms]; N=len(atoms)
def md(p,q):
    x=np.asarray(p,float)-np.asarray(q,float); return x-Lc*np.round(x/Lc)
def dist(p,q): return np.linalg.norm(md(p,q))
NN=1/np.sqrt(2)
adj={v:set() for v in range(N)}
for i in range(N):
    for j in range(N):
        if i!=j and abs(dist(A[i],A[j])-NN)<1e-6: adj[i].add(j)
tris=sorted({tuple(sorted((i,j,k))) for i in range(N) for j in adj[i] for k in adj[i]&adj[j]})
def cls(d):
    z=[k for k in range(3) if abs(d[k])<1e-6]; return z[0] if len(z)==1 else -1
def ecls(i,j): return cls(md(A[j],A[i]))

perbond=Counter()
for (i,j,k) in tris:
    for e in [(i,j),(i,k),(j,k)]: perbond[tuple(sorted(e))]+=1
print(f"(1) triangular plaquettes: {len(tris)}; each bond in {sorted(set(perbond.values()))} triangles")
print("    minimal loop length 3 (close-packed) -> the gauge action is triangular.")

allRGB=all(tuple(sorted([ecls(i,j),ecls(i,k),ecls(j,k)]))==(0,1,2) for (i,j,k) in tris)
print(f"(2) every triangular plaquette carries one bond of each color class (R,G,B): {allRGB}")
print("    -> the elementary loops mix the three colors; color-mixing dynamics is geometric.")
