#!/usr/bin/env python3
"""
su3_rank2.py
------------
Backs Section 4 (A2 among the rank-2 simple Lie algebras).

Generates the root systems of the three rank-2 simple Lie algebras and shows
that both data the geometry supplies single out A2 = su(3):
  - Weyl group orders are 6 (A2), 8 (B2), 12 (G2): the order-6 S3 is A2 alone;
  - smallest nontrivial rep dimensions are 3 (A2), 4 (B2), 7 (G2): a three-color
    (dim-3) representation exists only for A2.
Either datum excludes B2 and G2. Selects the representation/Weyl structure,
NOT the gauge dynamics.

Requires: numpy.  Run:  python3 su3_rank2.py
"""
import numpy as np
systems={"A2 = su(3)":[np.array([1.,0.]),np.array([-0.5,np.sqrt(3)/2])],
         "B2 = so(5)":[np.array([1.,-1.]),np.array([0.,1.])],
         "G2":[np.array([1.,0.]),np.array([-1.5,np.sqrt(3)/2])]}
def reflect(b,a): return b-2*np.dot(b,a)/np.dot(a,a)*a
def roots(simple):
    R=[s.copy() for s in simple]+[-s for s in simple]; ch=True
    while ch:
        ch=False
        for b in list(R):
            for a in simple:
                r=reflect(b,a)
                if not any(np.allclose(r,x,atol=1e-9) for x in R): R.append(r); ch=True
    return R
def coords(r,s): return np.linalg.solve(np.array(s).T,r)
def fund(s):
    Am=np.array([2*s[j]/np.dot(s[j],s[j]) for j in range(2)])
    return [np.linalg.solve(Am,np.eye(2)[i]) for i in range(2)]
def wdim(lam,pos):
    rho=sum(pos)/2.; n=d=1.
    for b in pos: n*=2*np.dot(lam+rho,b)/np.dot(b,b); d*=2*np.dot(rho,b)/np.dot(b,b)
    return n/d
print(f"{'algebra':12} {'|W|':>4} {'min nontrivial rep':>18}")
for name,s in systems.items():
    R=roots(s)
    pos=[r for r in R if (lambda c:(c[0]>1e-9 and c[1]>-1e-9) or (c[1]>1e-9 and c[0]>-1e-9))(coords(r,s))]
    om=fund(s); mn=min(round(wdim(om[0],pos)),round(wdim(om[1],pos)))
    print(f"{name:12} {len(R):>4} {mn:>18}")
print("\nS3 (|W|=6) and a dim-3 rep each occur for A2 alone -> A2 = su(3) selected.")
