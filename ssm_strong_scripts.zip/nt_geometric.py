#!/usr/bin/env python3
"""
nt_geometric.py
---------------
Backs Section 3 (the geometric channel realizes the Weyl group; torus+Weyl = N(T)).

(1) A defect hop permutes the four valence bonds, inducing a map on the three
    skew-pair matchings (the three colors). Enumerating all 24 bond permutations
    (S4) yields exactly the six color permutations -- the Weyl group S3 of A2.
(2) Combining these Weyl elements with the continuous Cartan torus (the bond
    phases mod the diagonal U(1)) generates only MONOMIAL matrices = the
    normalizer N(T) = T x| S3, a measure-zero subset of SU(3). A continuous
    root-direction element exp(i t lambda_1) is not monomial, so the root
    generators are not reached.

Requires: numpy.  Run:  python3 nt_geometric.py
"""
import numpy as np, itertools
matchings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def matching_perm(bp):
    out=[]
    for (a,b),(c,d) in matchings:
        pair=frozenset([frozenset((bp[a],bp[b])),frozenset((bp[c],bp[d]))])
        out.append(next(k for k,(e,f) in enumerate(matchings)
                        if frozenset([frozenset(e),frozenset(f)])==pair))
    return tuple(out)
weyl_perms=sorted({matching_perm(bp) for bp in itertools.permutations(range(4))})
print(f"(1) distinct color maps from the 24 bond permutations: {len(weyl_perms)} (= |S3|)")
print(f"    {weyl_perms}")

def pm(p):
    M=np.zeros((3,3),complex)
    for i,pi in enumerate(p): M[i,pi]=1
    return M/np.linalg.det(M)**(1/3)
weyl=[pm(p) for p in itertools.permutations(range(3))]
def torus(a,b): return np.diag(np.exp(1j*np.array([a,b,-a-b])))
def is_monomial(U,t=1e-9):
    A=np.abs(U)
    return all(np.sum(A[i,:]>t)==1 for i in range(3)) and all(np.sum(A[:,j]>t)==1 for j in range(3))
rng=np.random.default_rng(0); mono=True
for _ in range(20000):
    U=np.eye(3,dtype=complex)
    for _ in range(rng.integers(1,6)):
        U=U@(torus(rng.uniform(-np.pi,np.pi),rng.uniform(-np.pi,np.pi)) if rng.random()<.5 else weyl[rng.integers(6)])
    if not is_monomial(U): mono=False;break
print(f"(2) every torus*Weyl product is monomial (in N(T)): {mono}")
from scipy.linalg import expm
lam1=np.array([[0,1,0],[1,0,0],[0,0,0]],complex)
Ur=expm(1j*0.7*lam1); Ur=Ur/np.linalg.det(Ur)**(1/3)
print(f"    a root-direction element exp(i t lambda_1) is monomial: {is_monomial(Ur)}")
print("    => geometry+bond-phases realize N(T)=T x| S3 only; root directions absent.")
