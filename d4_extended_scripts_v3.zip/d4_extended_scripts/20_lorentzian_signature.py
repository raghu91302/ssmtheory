#!/usr/bin/env python3
"""Lorentzian reading of the fourth D4 coordinate.

Verifies, from the lattice vectors alone:

  A. Checkerboard slicing.  With coordinate 0 as time, the Z-stabilizer sites
     (D4 vertices) are D3 sites on even slices and octahedral-void sites on odd
     slices; the X-stabilizer sites are the reverse.  Every time-mixed bond is a
     D3-site-to-void hop between adjacent slices.
  B. Signature of the 24 bonds.  12 spatial bonds have interval^2 = -2
     (spacelike); 12 time-mixed bonds have interval^2 = 0 (null): 6 future,
     6 past.  Shell edges: 48 spacelike, 48 null; no future-past edge.
  C. Time reversal T: t -> -t is an automorphism of the D4 CSS code at L = 4
     and fixes every edge of the spatial sub-complex.
  D. T-orbit counts on the 24-cell: shell edges 96 -> 60, spokes 24 -> 18,
     planar squares 72 -> 45.  Inversion (the old H3) gives 48 / 12 / 36.
     The cuboctahedron is fixed pointwise by T, so the muon count is unchanged.
  E. Tauon under the muon's conventions (shell edges + spokes, all planar
     squares, both mod T, shedding D^depth):  78 x 45 - 27 = 3483.
     The alternatives that appear in the manuscript's table are also printed.
  F. Fourth-order spatial isotropy: the null bonds supply the coordinate-axis
     directions the cuboctahedron lacks; the anisotropic coefficient of
     sum_i k_i^4 is (w - 1), where w is the null/spacelike hop-amplitude ratio.
"""
import itertools
from itertools import product, combinations
from collections import Counter
import numpy as np

failures = []
def check(cond, msg):
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond:
        failures.append(msg)

# ------------------------------------------------------------------ A
print("A. CHECKERBOARD SLICING (L = 4)")
L = 4
pts = list(product(range(L), repeat=4))
even = [p for p in pts if sum(p) % 2 == 0]   # D4 vertices = Z sites
odd  = [p for p in pts if sum(p) % 2 == 1]   # X sites
def sp_parity(p): return sum(p[1:]) % 2
z_even_t = Counter(sp_parity(p) for p in even if p[0] % 2 == 0)
z_odd_t  = Counter(sp_parity(p) for p in even if p[0] % 2 == 1)
x_even_t = Counter(sp_parity(p) for p in odd  if p[0] % 2 == 0)
x_odd_t  = Counter(sp_parity(p) for p in odd  if p[0] % 2 == 1)
print(f"  Z sites, even t: spatial parity {dict(z_even_t)}  (0 = D3 site, 1 = void)")
print(f"  Z sites, odd  t: spatial parity {dict(z_odd_t)}")
print(f"  X sites, even t: spatial parity {dict(x_even_t)}")
print(f"  X sites, odd  t: spatial parity {dict(x_odd_t)}")
check(set(z_even_t) == {0} and set(z_odd_t) == {1}, "Z sites: D3 on even slices, voids on odd slices")
check(set(x_even_t) == {1} and set(x_odd_t) == {0}, "X sites: voids on even slices, D3 on odd slices")

NN = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
mixed = [v for v in NN if v[0] != 0]
hops_ok = all(sp_parity(v) == 1 for v in mixed) and all(abs(v[0]) == 1 for v in mixed)
check(hops_ok, "every time-mixed bond changes spatial parity (D3 site <-> void) and steps one slice")

# ------------------------------------------------------------------ B
print("\nB. SIGNATURE OF THE BONDS")
lor = lambda v: v[0]**2 - sum(x*x for x in v[1:])
sig = Counter(lor(v) for v in NN)
print(f"  bond interval^2 counts: {dict(sig)}")
check(sig == Counter({-2: 12, 0: 12}), "12 spacelike (interval^2 = -2) and 12 null bonds")
fut = [v for v in NN if v[0] > 0]; past = [v for v in NN if v[0] < 0]
check(len(fut) == 6 and len(past) == 6, "null bonds split 6 future + 6 past")
octa = sorted(tuple(v[1:]) for v in fut)
check(octa == sorted(v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 1),
      "spatial parts of the future null bonds are +-e_i: an octahedron, the <100> void directions")

shell = [np.array(v) for v in NN]; n = len(shell)
idx = {tuple(v): i for i, v in enumerate(shell)}
adj = lambda a, b: int(np.sum((a - b)**2)) == 2
E = [(i, j) for i, j in combinations(range(n), 2) if adj(shell[i], shell[j])]
isE = set(E); ie = lambda i, j: (min(i, j), max(i, j)) in isE
cls = lambda i: 's' if shell[i][0] == 0 else ('f' if shell[i][0] > 0 else 'p')
ecls = Counter(tuple(sorted((cls(i), cls(j)))) for i, j in E)
esig = Counter(int(np.sign(lor(shell[i] - shell[j]))) for i, j in E)
print(f"  shell edges by endpoint class: {dict(ecls)}")
print(f"  shell edges by signature (0 null, -1 spacelike): {dict(esig)}")
check(len(E) == 96 and ecls[('f', 'p')] == 0, "96 shell edges, none joins future to past")
check(esig == Counter({-1: 48, 0: 48}), "48 spacelike + 48 null shell edges")

# ------------------------------------------------------------------ C
print("\nC. TIME REVERSAL AS A CODE AUTOMORPHISM (L = 4)")
vid = {p: i for i, p in enumerate(even)}
xid = {p: i for i, p in enumerate(odd)}
add = lambda p, d: tuple((p[k] + d[k]) % L for k in range(4))
edges = []; eid = {}
for p in even:
    for d in NN:
        q = add(p, d)
        if q in vid and vid[p] < vid[q]:
            eid[(p, q)] = len(edges); edges.append((p, q))
def edge_index(p, q):
    return eid[(p, q)] if (p, q) in eid else eid[(q, p)]
ne = len(edges)
HZ = np.zeros((len(even), ne), dtype=np.int8)
for k, (p, q) in enumerate(edges):
    HZ[vid[p], k] = 1; HZ[vid[q], k] = 1
AX = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 1]
HX = np.zeros((len(odd), ne), dtype=np.int8)
for o in odd:
    nbs = [add(o, a) for a in AX]
    for a, b in combinations(nbs, 2):
        if (a, b) in eid or (b, a) in eid:
            HX[xid[o], edge_index(a, b)] = 1
check(ne == 1536 and not (HX @ HZ.T % 2).any(), "D4 code rebuilt: n = 1536, HX HZ^T = 0")
T = lambda p: ((-p[0]) % L, p[1], p[2], p[3])
vperm = [vid[T(p)] for p in even]
xperm = [xid[T(p)] for p in odd]
eperm = [edge_index(T(p), T(q)) for p, q in edges]
check(np.array_equal(HZ[vperm][:, eperm], HZ) and np.array_equal(HX[xperm][:, eperm], HX),
      "T is a code automorphism: permutes Z- and X-stabilizers among themselves")
spatial_edges = [k for k, (p, q) in enumerate(edges) if p[0] == q[0]]
fixed_spatial = sum(1 for k in spatial_edges if eperm[k] == k)
# T maps slice t to slice -t; spatial edges on the t = 0 and t = L/2 slices are fixed pointwise,
# and the spatial sub-complex as a whole is mapped onto itself.
check(all(edges[eperm[k]][0][0] == edges[eperm[k]][1][0] for k in spatial_edges),
      "T maps the spatial sub-complex onto itself")
check(all(eperm[k] == k for k in spatial_edges if edges[k][0][0] in (0, L // 2)),
      "T fixes every spatial edge of a slice pointwise (checked on the T-invariant slices)")

# ------------------------------------------------------------------ D
print("\nD. T-ORBITS ON THE 24-CELL")
Tsh = lambda i: idx[tuple(shell[i] * np.array([-1, 1, 1, 1]))]
Psh = lambda i: idx[tuple(-shell[i])]
def orbits(objs, g):
    seen = set(); orb = 0; fixed = 0
    for o in objs:
        if o in seen: continue
        img = frozenset(g(i) for i in o); seen |= {o, img}; orb += 1; fixed += (img == o)
    return orb, fixed
sq = set()
for a in range(n):
    for b in range(n):
        if not ie(a, b): continue
        for c in range(n):
            if c == a or not ie(b, c) or ie(a, c): continue
            for d in range(n):
                if d in (a, b, c) or not ie(c, d) or not ie(d, a) or ie(b, d): continue
                if np.array_equal(shell[a] + shell[c], shell[b] + shell[d]):
                    sq.add(frozenset((a, b, c, d)))
sq = list(sq)
check(len(sq) == 72, "72 planar squares on the 24-cell")
edges24 = [frozenset(e) for e in E]; spokes = [frozenset((i,)) for i in range(n)]
res = {}
for name, g in (("T", Tsh), ("inversion", Psh)):
    oe, fe = orbits(edges24, g); os_, fs = orbits(spokes, g); oq, fq = orbits(sq, g)
    res[name] = (oe, os_, oq)
    print(f"  {name:9s}: shell edges 96 -> {oe:2d} (fixed {fe:2d}), spokes 24 -> {os_:2d} (fixed {fs:2d}), squares 72 -> {oq:2d} (fixed {fq:2d})")
check(res["T"] == (60, 18, 45), "under T: 60 edge orbits, 18 spoke orbits, 45 square orbits")
check(res["inversion"] == (48, 12, 36), "under inversion: 48 / 12 / 36 (the old H3 halved squares only)")
sq_classes = Counter(tuple(sorted(int(shell[i][0]) for i in s)) for s in sq)
print(f"  squares by time coordinates of vertices: {dict(sq_classes)}")
check(sq_classes[(0, 0, 0, 0)] == 6 and sq_classes[(-1, 0, 0, 1)] == 12,
      "6 spatial squares and 12 straddling squares, all T-fixed; 24+24 and 3+3 pair up")
# cuboctahedron pointwise fixed
cub = [i for i in range(n) if shell[i][0] == 0]
check(all(Tsh(i) == i for i in cub), "T fixes the spatial cuboctahedron pointwise: muon count unchanged (36 x 6 - 9 = 207)")

# ------------------------------------------------------------------ E
print("\nE. TAUON COUNT UNDER THE MUON'S CONVENTIONS")
D = 3
Es_T, F_T = 60 + 18, 45
C_tau = Es_T * F_T - D**3
print(f"  E_s = 60 + 18 = {Es_T}, F_box = {F_T}, shedding D^3 = {D**3}")
print(f"  C_tau = {Es_T} x {F_T} - {D**3} = {C_tau}   (measured 3477.23, deviation {abs(C_tau-3477.23)/3477.23*100:.2f}%)")
check(C_tau == 3483, "C_tau = 3483")
print("  alternatives (each changes exactly one element of the rule):")
alts = [("inversion instead of T (uniform)", 48 + 12, 36, D**3),
        ("D^2 instead of D^3", 78, 45, D**2),
        ("shell edges only", 60, 45, D**3),
        ("no identification at all", 120, 72, D**3),
        ("published count (inversion on squares only, shell edges only, D^2)", 96, 36, D**2)]
for lab, e, f, k in alts:
    v = e * f - k
    print(f"    {lab:70s} {e:3d} x {f:2d} - {k:2d} = {v:5d}  ({abs(v-3477.23)/3477.23*100:6.2f}%)")
static = Es_T * F_T + D
print(f"  static candidate rejected by Axiom 4: {Es_T} x {F_T} + {D} = {static}  ({abs(static-3477.23)/3477.23*100:.2f}%)")
check(static == 3513, "static candidate 3513")

# ------------------------------------------------------------------ F
print("\nF. FOURTH-ORDER SPATIAL ISOTROPY AND THE NULL BONDS")
import sympy as sp
kx, ky, kz, w = sp.symbols('k_x k_y k_z w', real=True)
k = sp.Matrix([kx, ky, kz])
sp3 = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
nul = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 1]
M4 = sp.expand(sum((k.dot(sp.Matrix(b)) / sp.sqrt(2))**4 for b in sp3)
              + sum(2 * w * (k.dot(sp.Matrix(b)) / sp.sqrt(2))**4 for b in nul))
P = sp.Poly(M4, kx, ky, kz)
a_iso = P.coeff_monomial(kx**2 * ky**2) / 2          # coefficient of |k|^4
b_aniso = sp.simplify(P.coeff_monomial(kx**4) - a_iso)  # coefficient of sum k_i^4
print(f"  M4 = {a_iso} |k|^4 + ({b_aniso}) sum_i k_i^4")
check(sp.simplify(b_aniso - (w - 1)) == 0, "anisotropic coefficient is (w - 1): isotropic iff null and spacelike hops have equal weight")
check(sp.simplify(M4.subs(w, 1) - 3 * (kx**2 + ky**2 + kz**2)**2) == 0, "at w = 1 the spatial fourth moment is 3|k|^4 exactly")

print()
if failures:
    print(f"{len(failures)} check(s) failed:"); [print("  -", f) for f in failures]
    raise SystemExit(1)
print("All Lorentzian-signature checks passed.")
