"""
Figure 2: Mass spectrum comparison. Predicted topological costs vs
experimental mass ratios for the seven first-shell particles.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'figure.facecolor': 'white',
    'axes.facecolor':   'white',
    'savefig.facecolor': 'white',
    'savefig.edgecolor': 'white',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

particles = ['$e$', '$\\mu$', '$\\pi^\\pm$', '$\\tau$', '$p$', '$n$', '$H$']
predicted = [1, 207, 273, 3483, 1836, 1839, 244944]
experimental = [1.0, 206.768, 273.132, 3477.23, 1836.153, 1838.684, 245010.0]
formulas = ['1', '36{\\times}6{-}9', '16{\\times}17{+}1', '96{\\times}36{-}9', '36{\\times}51', '36{\\times}51{+}3', 'K^2(K^3{-}D^3)']

deviations = [100 * (e - p) / e for p, e in zip(predicted, experimental)]
abs_dev = [max(abs(d), 1e-3) for d in deviations]  # floor for log scale

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2), gridspec_kw={'width_ratios': [1.4, 1], 'wspace': 0.35})

# ---------- Left: log-scale predicted vs experimental ----------
x = np.arange(len(particles))
width = 0.36

bars1 = ax1.bar(x - width/2, predicted, width, label='Predicted $C_x$',
                color='#2c5f9e', edgecolor='black', linewidth=0.4)
bars2 = ax1.bar(x + width/2, experimental, width, label='Experimental $m_x / m_e$',
                color='#e07a5f', edgecolor='black', linewidth=0.4)

ax1.set_yscale('log')
ax1.set_xticks(x)
ax1.set_xticklabels(particles)
ax1.set_ylabel('Mass ratio $m_x / m_e$ (log scale)')
ax1.set_title('(a) Predicted vs experimental mass ratios')
ax1.legend(loc='upper left', frameon=False)
ax1.set_ylim(0.6, 1.5e6)
ax1.grid(True, which='both', axis='y', alpha=0.25, linewidth=0.4)
ax1.set_axisbelow(True)

# Annotate the new predictions
ax1.annotate('new', xy=(3, 3483), xytext=(3.0, 250),
             fontsize=8, ha='center', style='italic',
             arrowprops=dict(arrowstyle='->', color='black', lw=0.6))
ax1.annotate('new', xy=(6, 247536), xytext=(6.0, 15000),
             fontsize=8, ha='center', style='italic',
             arrowprops=dict(arrowstyle='->', color='black', lw=0.6))

# ---------- Right: deviation in percent ----------
colors_dev = ['#e07a5f' if name in ['$\\tau$', '$H$'] else '#4a90c2' for name in particles]
bars3 = ax2.barh(particles, abs_dev, color=colors_dev,
                 edgecolor='black', linewidth=0.4)

ax2.set_xlabel('|deviation| (%)')
ax2.set_title('(b) Deviation from experiment')
ax2.set_xscale('log')
ax2.set_xlim(1e-3, 2)
ax2.invert_yaxis()
ax2.grid(True, which='both', axis='x', alpha=0.25, linewidth=0.4)
ax2.set_axisbelow(True)

# Annotate each bar with the percent value
for i, (bar, d, raw_d) in enumerate(zip(bars3, abs_dev, deviations)):
    w = bar.get_width()
    if abs(raw_d) < 1e-5:
        label = 'exact'
    elif d >= 0.1:
        label = f'{d:.2f}%'
    elif d >= 0.01:
        label = f'{d:.3f}%'
    else:
        label = f'{d:.4f}%'
    ax2.text(w * 1.4, bar.get_y() + bar.get_height()/2,
             label, va='center', ha='left', fontsize=8)

plt.subplots_adjust(left=0.08, right=0.97, top=0.90, bottom=0.15, wspace=0.35)
plt.savefig('./fig4_mass_spectrum.pdf', format='pdf', bbox_inches='tight', facecolor='white')
plt.savefig('./fig4_mass_spectrum.png', format='png', bbox_inches='tight', dpi=200, facecolor='white')
print("Figure 2 saved.")
print(f"Largest deviation: {max(abs_dev):.3f}% (tauon)")
print(f"Smallest deviation: {min(abs_dev):.4f}% (electron)")
