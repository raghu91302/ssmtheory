"""How a defect hopping on <110> couples to a gauge field on <100>."""
import itertools
from itertools import product
L=6
add=lambda a,b: tuple((a[i]+b[i])%L for i in range(3))
pts=[v for v in product(range(L),repeat=3)]
nodes=[v for v in pts if sum(v)%2==0]
NN110=[d for d in product((-1,0,1),repeat=3) if sum(map(abs,d))==2]
AX=[d for d in product((-1,0,1),repeat=3) if sum(map(abs,d))==1]
print("DOES A <110> HOP DECOMPOSE INTO <100> HOPS?\n")
d=(1,1,0)
print("   a <110> step is %s"%(d,))
print("   two <100> steps: (1,0,0) then (0,1,0) sum to %s  -> yes"%(tuple(a+b for a,b in zip((1,0,0),(0,1,0))),))
v0=(0,0,0); v1=add(v0,d)
print("\n   node %s -> node %s"%(v0,v1))
mids=[m for m in [add(v0,a) for a in AX] if any(add(m,b)==v1 for b in AX)]
print("   intermediate sites reachable in one <100> step from both ends: %s"%mids)
for m in mids:
    print("      %s : parity %s -> %s"%(m,"odd" if sum(m)%2 else "even",
          "octahedral void" if sum(m)%2 else "fcc node"))
print()
print("   so every <110> edge is covered by TWO two-step <100> paths,")
print("   each passing through an octahedral void.\n")
# check for all <110> edges
bad=0; counts=set()
for v in nodes:
    for dd in NN110:
        u=add(v,dd)
        ms=[m for m in [add(v,a) for a in AX] if any(add(m,b)==u for b in AX)]
        counts.add(len(ms))
        if any(sum(m)%2==0 for m in ms): bad+=1
print("   over all %d nodes x 12 directions = %d directed edge steps (%d edges,\n"
      "   each in both directions): number of covering paths is always %s ; all"
      %(len(nodes),len(nodes)*12,len(nodes)*6,sorted(counts)))
print("   intermediates are voids (violations: %d)\n"%bad)
print("THE TWO PATHS DIFFER BY A PLAQUETTE\n")
a,b=mids[0],mids[1]
print("   path A: %s -> %s -> %s"%(v0,a,v1))
print("   path B: %s -> %s -> %s"%(v0,b,v1))
print("   the closed loop A then B reversed is")
print("      %s -> %s -> %s -> %s -> %s"%(v0,a,v1,b,v0))
print("   which is a unit square of the cubic sublattice: a PLAQUETTE.\n")
print("   so the phase a defect picks up hopping along a <110> edge is the")
print("   product of two <100> link phases, well defined up to the flux")
print("   through that plaquette. That is exactly a gauge coupling: the")
print("   ambiguity IS the field strength.")
