# Verification suite

Companion code for *The Mass–Energy–Information Equivalence Extended: D4
Lattice, Triality, and the Three-Generation Structure of Matter*
(Physics Open, PHYSO-D-26-00405).

Every quantitative claim in the manuscript is reproduced here. The lattices are
built from their defining rules and the ranks are computed, not quoted.

## Requirements

    python >= 3.8, numpy, scipy, sympy
    matplotlib (figure generators only)

## Running everything

    python3 d4_run_all.py

Runs all twenty verifications in about two minutes and reports pass/fail for
each. Individual scripts can be run directly and print their own results.

## What each script verifies

| script | claim |
|---|---|
| `01_structure_tensor.py` | rank-2 and rank-4 moments of the D4 shell; exact isotropy |
| `02_24cell_triality.py` | the 24-cell, its three 16-cell sub-structures, the order-3 triality |
| `03_d4_css_code.py` | the D4 CSS code: HX HZ^T = 0, k = 5L^4 + 2, distance 3 |
| `04_mass_spectrum.py` | the seven mass counts and their deviations (tauon 3483) |
| `05_triality_code_automorphism.py` | triality as a code automorphism; three logical classes |
| `06_statistics.py` | the statistical weight of the mass agreements |
| `07_sector_map.py` | the muon–proton footprint degeneracy; sector rules |
| `08_logical_classification.py` | census of the 1282 logical classes; the weight bound |
| `09_code_functional_validation.py` | the code functional on the ladder |
| `10_d4_plaquette_code.py` | the plaquette code variant |
| `11_face_qubit_code.py` | qubits on faces; k = b_2(T^4) = 6 |
| `12_complete_cells.py` | cell completeness of the homological ladder |
| `13_top_rungs.py` | the top of the ladder; the fundamental class |
| `14_rule_space_scan.py` | exhaustive scan of the stated rule grammar |
| `15_spherical_design.py` | the t-design property of the D4 shell |
| `16_distance_exact.py` | exact distance at L = 4 and L = 6 |
| `17_photon_sublattice.py` | the ⟨100⟩ cubic sublattice: bipartiteness, the Hodge split giving two transverse modes per site, disjointness from the code qubits, the vanishing rank-three moment |
| `18_matter_coupling.py` | every ⟨110⟩ edge is covered by two two-step ⟨100⟩ paths through octahedral voids, differing by one cubic plaquette |
| `19_gluon_confinement.py` | 24 odd cycles through each site; the ⟨110⟩ shell is not two-colourable |
| `20_lorentzian_signature.py` | Lorentzian reading of coordinate 0: checkerboard slicing of Z/X sites, 12 null + 12 spacelike bonds, time reversal T as a code automorphism fixing the spatial sub-complex, T-orbit counts 60/18/45 on the 24-cell, the tauon count 78 × 45 − 27 = 3483 with its one-change alternatives, and fourth-order isotropy iff null and spacelike hops have equal weight |

## Figures

`gen_fig1_hasse.py`, `gen_fig2_isotropy.py`, `gen_fig3_24cell.py` and
`gen_fig4_mass_spectrum.py` regenerate the four manuscript figures. Each
computes its own numbers and prints them rather than taking them as given.

## Note on figure 4

The deviation labels use two decimal places above 0.1 %, matching the precision
used in the manuscript text. An earlier version printed three, which made the
tauon deviation appear as 0.869 % in the figure against 0.87 % in the text.
