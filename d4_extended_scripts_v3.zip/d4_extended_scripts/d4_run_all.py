#!/usr/bin/env python3
"""Mass-Energy-Information Equivalence Extended -- verification suite.

Runs all twenty verification scripts in order and reports timings.
Exits 0 if every script passes, 1 otherwise.

    python3 d4_run_all.py

Works from any working directory: each script is located relative to this
file, not to the shell's current directory. Requires numpy, scipy, sympy
and matplotlib.
"""

import os
import subprocess
import sys
import time

SCRIPTS = [
    ("01_structure_tensor.py",
     "structure tensor S = 12 I, T = 0, D3 sub-lattice"),
    ("02_24cell_triality.py",
     "24-cell f-vector, triality 8+8+8, 72 squares -> 36"),
    ("03_d4_css_code.py",
     "CSS code [[1536, 1282, >=3]] at L = 4"),
    ("04_mass_spectrum.py",
     "all seven rest-mass predictions and the Higgs"),
    ("05_triality_code_automorphism.py",
     "triality as a code automorphism; three inequivalent logical worldlines"),
    ("06_statistics.py",
     "look-elsewhere analysis of the mass matches"),
    ("07_sector_map.py",
     "worldline sector rule against all seven assignments"),
    ("08_logical_classification.py",
     "census of the 1282 logical classes; H4a refuted for the D4 code"),
    ("09_code_functional_validation.py",
     "sector counts are not functionals of the D4 code"),
    ("10_d4_plaquette_code.py",
     "vertex-plaquette code; sector counts as exact stabilizer counts"),
    ("11_face_qubit_code.py",
     "ladder rung 2: k = 6 = dim H_2(T^4)"),
    ("12_complete_cells.py",
     "complete cell structure of the D4 honeycomb"),
    ("13_top_rungs.py",
     "ladder rungs 3 and 4: k = 4 and k = 1"),
    ("14_rule_space_scan.py",
     "exhaustive scan of the binary rule grammar"),
    ("15_spherical_design.py",
     "D3 is a 3-design, D4 a 5-design; anisotropy exponents 2 and 4"),
    ("16_distance_exact.py",
     "all 4096 D4 triangles are weight-3 logicals; d = 3 exactly"),
    ("17_photon_sublattice.py",
     "the <100> cubic sublattice: bipartite, Maxwell polarization count, "
     "disjoint from the code qubits, centrosymmetric bond star"),
    ("18_matter_coupling.py",
     "every <110> edge is two <100> hops through a void; the two paths "
     "differ by a cubic plaquette"),
    ("19_gluon_confinement.py",
     "24 odd cycles per site; the <110> shell is not two-colourable"),
    ("20_lorentzian_signature.py",
     "checkerboard slicing, null/spacelike split, T as code automorphism, "
     "T-orbit counts on the 24-cell, tauon 78 x 45 - 27 = 3483, isotropy iff w = 1"),
]


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    print("=" * 78)
    print("Mass-Energy-Information Equivalence Extended  --  verification suite")
    print("=" * 78)

    total = 0.0
    failed = []
    for fname, label in SCRIPTS:
        path = os.path.join(here, fname)
        print("\n>>> %s -- %s" % (fname, label))
        print("-" * 78)
        if not os.path.exists(path):
            print("!!! MISSING: %s" % path)
            failed.append(fname)
            continue
        t0 = time.time()
        r = subprocess.run([sys.executable, path], cwd=here)
        dt = time.time() - t0
        total += dt
        if r.returncode != 0:
            print("\n!!! FAILED: %s (exit code %d)" % (fname, r.returncode))
            failed.append(fname)
        else:
            print("--- %s OK in %.2fs" % (fname, dt))

    print("\n" + "=" * 78)
    if failed:
        print("%d of %d scripts failed: %s"
              % (len(failed), len(SCRIPTS), ", ".join(failed)))
        print("=" * 78)
        return 1
    print("All %d verifications passed in %.1fs total." % (len(SCRIPTS), total))
    print("=" * 78)
    return 0


if __name__ == '__main__':
    sys.exit(main())
