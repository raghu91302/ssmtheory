#!/usr/bin/env python3
"""Figures for the <100> electromagnetic sector paper.
Produces fig5_sublattices.pdf and fig5_polarizations.pdf.
Requires numpy and matplotlib. All geometry is computed, not drawn by hand."""
import itertools
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

mpl.rcParams.update({
    "font.family": "serif",
    "font.size": 8.5,
    "axes.linewidth": 0.6,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

NODE = "#2b5d8c"      # fcc node, blue
VOID_O = "#c0504d"    # octahedral void, red
VOID_T = "#4f8a4f"    # tetrahedral void, green
GREY = "#9a9a9a"
ODD = "#d98c00"       # odd-cycle highlight
PATH = "#7b3fa0"      # propagation path


def equal_box(ax, R=1.75):
    ax.set_xlim(-R, R); ax.set_ylim(-R, R); ax.set_zlim(-R, R)
    ax.set_box_aspect([1, 1, 1])
    ax.set_axis_off()
    ax.view_init(elev=18, azim=32)


def draw_bonds(ax, centre, pts, colour, lw=0.9, alpha=0.85, ls="-"):
    for p in pts:
        ax.plot(*zip(centre, p), color=colour, lw=lw, alpha=alpha, ls=ls,
                solid_capstyle="round", zorder=1)


# ----------------------------------------------------------------- figure 1
def figure1(path="fig5_sublattices.pdf"):
    fig = plt.figure(figsize=(7.0, 2.6))
    a = 2.0  # conventional cube edge, so nearest fcc neighbour is at |d|=sqrt2

    # (a) <110>: the cuboctahedral shell, non-bipartite
    ax = fig.add_subplot(1, 3, 1, projection="3d")
    nn = [np.array(d, float) for d in itertools.product((-1, 0, 1), repeat=3)
          if sum(map(abs, d)) == 2]
    draw_bonds(ax, np.zeros(3), nn, NODE, lw=0.8, alpha=0.55)
    # cuboctahedron skeleton
    for p, q in itertools.combinations(nn, 2):
        if abs(np.linalg.norm(p - q) - np.sqrt(2)) < 1e-9:
            ax.plot(*zip(p, q), color=GREY, lw=0.5, alpha=0.5, zorder=0)
    # one odd cycle: node + two adjacent shell vertices
    best, area = None, -1.0
    for p, q in itertools.combinations(nn, 2):
        if abs(np.linalg.norm(p - q) - np.sqrt(2)) > 1e-9:
            continue
        # projected area in the current view; maximise so it reads as a triangle
        el, az = np.radians(18), np.radians(32)
        e1 = np.array([-np.sin(az), np.cos(az), 0.0])
        e2 = np.array([-np.cos(az) * np.sin(el), -np.sin(az) * np.sin(el), np.cos(el)])
        P2 = np.array([[v @ e1, v @ e2] for v in (np.zeros(3), p, q)])
        A = abs(np.cross(P2[1] - P2[0], P2[2] - P2[0])) / 2
        if A > area:
            area, best = A, (p, q)
    tri = [np.zeros(3), best[0], best[1]]
    ax.add_collection3d(Poly3DCollection([tri], facecolor=ODD, alpha=0.75,
                                         edgecolor="#8a5a00", lw=1.8, zorder=6))
    for p, q in itertools.combinations(tri, 2):
        ax.plot(*zip(p, q), color="#8a5a00", lw=2.0, zorder=7)
    ax.scatter(*np.array(nn).T, s=13, c=NODE, depthshade=False, zorder=4)
    ax.scatter([0], [0], [0], s=30, c=NODE, depthshade=False, zorder=5,
               edgecolors="white", linewidths=0.5)
    equal_box(ax)
    ax.set_title("(a) " r"$\langle110\rangle$" " nearest neighbours""\n"
                 r"$K{=}12$, non-bipartite: no photon", fontsize=8, pad=-2)

    # (b) <111>: diamond, node to tetrahedral voids
    ax = fig.add_subplot(1, 3, 2, projection="3d")
    t = [np.array(s, float) / 2 for s in
         [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]]
    draw_bonds(ax, np.zeros(3), t, VOID_T, lw=1.4)
    for p in t:  # second shell, to show bipartite alternation
        for s in [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]:
            q = p + np.array(s, float) / 2
            if np.linalg.norm(q) > 0.1:
                draw_bonds(ax, p, [q], VOID_T, lw=0.7, alpha=0.4)
                ax.scatter(*q, s=9, c=NODE, depthshade=False, zorder=4)
    ax.scatter(*np.array(t).T, s=22, c=VOID_T, depthshade=False, zorder=4,
               marker="^")
    ax.scatter([0], [0], [0], s=30, c=NODE, depthshade=False, zorder=5,
               edgecolors="white", linewidths=0.5)
    equal_box(ax)
    ax.set_title("(b) " r"$\langle111\rangle$" " diamond""\n"
                 r"$K{=}4$, bipartite, not centrosymmetric", fontsize=8, pad=-2)

    # (c) <100>: node to octahedral voids, simple cubic
    ax = fig.add_subplot(1, 3, 3, projection="3d")
    ax_dirs = [np.array(d, float) for d in itertools.product((-1, 0, 1), repeat=3)
               if sum(map(abs, d)) == 1]
    draw_bonds(ax, np.zeros(3), ax_dirs, VOID_O, lw=1.4)
    for p in ax_dirs:  # one further step, showing the cubic grid alternating
        for d in ax_dirs:
            q = p + d
            if np.linalg.norm(q) > 0.1 and np.linalg.norm(q) < 1.8:
                draw_bonds(ax, p, [q], VOID_O, lw=0.7, alpha=0.35)
                ax.scatter(*q, s=9, c=NODE, depthshade=False, zorder=4)
    ax.scatter(*np.array(ax_dirs).T, s=22, c=VOID_O, depthshade=False, zorder=4,
               marker="s")
    ax.scatter([0], [0], [0], s=30, c=NODE, depthshade=False, zorder=5,
               edgecolors="white", linewidths=0.5)
    # a propagation path: alternating node and void, never broken
    walk = [np.array([x, 0.0, 0.0]) for x in (-1.5, -1, 0, 1, 1.5)]
    for p, q in zip(walk[:-1], walk[1:]):
        ax.plot(*zip(p, q), color=PATH, lw=2.6, zorder=8,
                solid_capstyle="round")
    for j, p in enumerate(walk):
        even = (j % 2 == 0)
        ax.scatter(*p, s=34 if even else 26, c=(NODE if even else VOID_O),
                   marker=("o" if even else "s"), depthshade=False, zorder=9,
                   edgecolors=PATH, linewidths=1.0)
    equal_box(ax)
    ax.set_title("(c) " r"$\langle100\rangle$" " simple cubic""\n"
                 r"$K{=}6$, bipartite: Maxwell", fontsize=8, pad=-2)


    fig.subplots_adjust(left=0.005, right=0.995, top=0.90, bottom=0.00,
                        wspace=0.0)
    fig.text(0.175, 0.06, "odd cycle", color="#8a5a00", fontsize=7.5, ha="center")
    fig.text(0.845, 0.06, "propagation path", color=PATH, fontsize=7.5, ha="center")
    fig.savefig(path, dpi=600)
    plt.close(fig)
    print("wrote", path)


# ----------------------------------------------------------------- figure 2
def hodge_cubic(L):
    pts = list(itertools.product(range(L), repeat=3))
    idx = {v: i for i, v in enumerate(pts)}
    add = lambda a, b: tuple((a[i] + b[i]) % L for i in range(3))
    e = [tuple(1 if k == m else 0 for k in range(3)) for m in range(3)]
    E = {(v, m): i for i, (v, m) in enumerate((v, m) for v in pts for m in range(3))}
    D1 = np.zeros((len(E), len(pts)))
    for (v, m), ei in E.items():
        D1[ei, idx[v]] = -1
        D1[ei, idx[add(v, e[m])]] = 1
    FA = [(v, m, l) for v in pts for m, l in itertools.combinations(range(3), 2)]
    D2 = np.zeros((len(E), len(FA)))
    for fi, (v, m, l) in enumerate(FA):
        D2[E[(v, m)], fi] += 1
        D2[E[(add(v, e[m]), l)], fi] += 1
        D2[E[(add(v, e[l]), m)], fi] -= 1
        D2[E[(v, l)], fi] -= 1
    n = len(E)
    r1 = np.linalg.matrix_rank(D1, tol=1e-9)
    r2 = np.linalg.matrix_rank(D2, tol=1e-9)
    return len(pts), n, r1, r2, n - r1 - r2


def figure2(path="fig5_polarizations.pdf"):
    ns, n, r1, r2, h = hodge_cubic(6)
    cubic = (r1 / ns, r2 / ns, h / ns)
    code = (1.0, 1.0, 4.0)          # per node, from the code complex
    maxwell = (1.0, 2.0, 0.0)

    fig, ax = plt.subplots(figsize=(5.0, 2.55))
    labels = ["Maxwell\n(continuum)",
              r"$\langle100\rangle$ cubic" "\n(this paper)",
              "FCC code complex\n(edge qubits)"]
    data = np.array([maxwell, cubic, code])
    colours = [GREY, "#2b5d8c", "#c0504d"]
    names = ["pure gauge", "transverse (physical)", "harmonic / flat"]
    hatches = ["///", "", ".."]
    y = np.arange(len(labels))[::-1]
    left = np.zeros(len(labels))
    for k in range(3):
        ax.barh(y, data[:, k], left=left, height=0.52, color=colours[k],
                edgecolor="white", linewidth=0.7, hatch=hatches[k],
                label=names[k], alpha=0.92)
        left += data[:, k]
    for j, yy in enumerate(y):
        ax.text(data[j].sum() + 0.12, yy, "%.0f dof" % round(data[j].sum()),
                va="center", fontsize=7.5, color="#444444")
    ax.axvline(3.0, color="#333333", lw=0.6, ls=":", zorder=0)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("one-form degrees of freedom per site")
    ax.set_xlim(0, 6.9)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.20), frameon=False,
              fontsize=7.4, ncol=3, columnspacing=1.2, handlelength=1.5)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=0.4, rect=(0, 0, 1, 0.93))
    fig.savefig(path, dpi=600)
    plt.close(fig)
    print("wrote", path)
    print("  cubic per site: exact %.3f, coexact %.3f, harmonic %.3f"
          % cubic)


if __name__ == "__main__":
    figure1()
    figure2()
