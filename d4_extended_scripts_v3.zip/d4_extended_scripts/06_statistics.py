#!/usr/bin/env python3
"""M/E/I D4 -- Statistical significance of the mass-formula matches.

Quantifies the look-elsewhere effect: given the space of integers reachable
by formulas of the framework's form, how likely is it that each experimental
mass ratio is matched as well as observed, by chance?

Two formula spaces are evaluated:

  NARROW: only axiom-generated forms E_s x C_s + corr, with E_s, C_s, corr
          drawn from the structural constants the two papers actually use.
  BROAD:  any product a x b + corr over the full set of structural integers
          appearing anywhere in Parts I-II (an adversarial reviewer's space).

Null model: achievable integers are treated as a point set; for target T with
achieved absolute deviation Delta = |C_pred - T|, we report
  k        = number of achievable integers matching at least as well (>= 1),
  rho      = local density of the space in the +/-10% band around T,
  lam      = rho * 2*Delta  (expected count under a uniform-density null),
  p        = 1 - exp(-lam)  (Poisson prob. of >= 1 chance match this good).
The electron is excluded (it is the normalization, m_e/m_e = 1).
"""

import math
from itertools import product

# ----- structural constants used across Parts I-III -----------------------
F_VECTORS = {  # f0, f1, F_tri, F_sq, f2 per sub-structure (Part I Table 1)
    '1-sheet': (5, 4, 0, 0, 0),
    '2-sheet': (9, 16, 8, 2, 10),
    '3-sheet': (13, 36, 32, 6, 38),
}
K, D = 12, 3
EDGE_COUNTS   = [1, 4, 16, 36, 78, 96, K**2]          # E_s values incl. 24-cell mod T, K^2
SECTOR_COUNTS = [1, 2, 5, 6, 8, 9, 13, 17, 18, 32, 36, 38, 45, 51, K**3]
CORRECTIONS   = [0, 1, -1, D, -D, D**2, -D**2, D**3, -D**3,
                 K**2 * D**3, -K**2 * D**3]           # incl. Higgs shedding

BROAD_SET = sorted({1, 2, 3, 4, 5, 6, 8, 9, 12, 13, 16, 17, 24, 27,
                    32, 36, 38, 45, 51, 78, 96, K**2, K**3})

# ----- paper's predictions and experimental targets ------------------------
# (name, predicted C_x, experimental m_x/m_e)
CASES = [
    ('muon',    207,    206.768),
    ('pion',    273,    273.132),
    ('tauon',   3483,   3477.23),
    ('proton',  1836,   1836.153),
    ('neutron', 1839,   1838.684),
    ('Higgs',   244944, 245010.0),  # excluded from the joint figure (circular)
]


def build_space(es, cs, corrs):
    vals = set()
    for e, c, k in product(es, cs, corrs):
        v = e * c + k
        if v >= 1:
            vals.add(v)
    return sorted(vals)


def analyse(space, label):
    print(f"\n=== {label}: {len(space)} distinct achievable integers ===")
    print(f"{'particle':<9} {'pred':>8} {'target':>10} {'Delta':>8} "
          f"{'k(as good)':>10} {'rho(/unit)':>11} {'lambda':>8} {'p':>9}")
    joint_p = 1.0
    for name, pred, T in CASES:
        delta = abs(pred - T)
        k = sum(1 for v in space if abs(v - T) <= delta)
        band = [v for v in space if 0.9 * T <= v <= 1.1 * T]
        rho = len(band) / (0.2 * T)
        lam = rho * 2 * delta
        p = 1 - math.exp(-lam)
        joint_p *= max(p, 1e-12)
        print(f"{name:<9} {pred:>8} {T:>10.2f} {delta:>8.2f} "
              f"{k:>10} {rho:>11.4f} {lam:>8.3f} {p:>9.4f}")
    print(f"joint chance probability (independence approx.): {joint_p:.2e}")
    # sanity: every paper prediction must itself be in the space
    missing = [n for n, pred, _ in CASES if pred not in space]
    print("all paper predictions reachable in this space:",
          "YES" if not missing else f"NO -- missing {missing}")
    return joint_p


narrow = build_space(EDGE_COUNTS, SECTOR_COUNTS, CORRECTIONS)
broad  = build_space(BROAD_SET, BROAD_SET, CORRECTIONS)

p_narrow = analyse(narrow, "NARROW (axiom-generated) formula space")
p_broad  = analyse(broad,  "BROAD (adversarial) formula space")

print("\nSummary: the framework's joint match probability under chance lies "
      f"between {p_broad:.1e} (broad) and {p_narrow:.1e} (narrow).")
print("Per-particle: matches with lambda >> 1 are individually unremarkable; "
      "matches with lambda << 1 carry the statistical weight.")
