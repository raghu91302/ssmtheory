
NN = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),
      (1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
OCT = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]

def build(L):
    nidx, nodes = {}, []
    for x in range(L):
      for y in range(L):
        for z in range(L):
          if (x+y+z) % 2 == 0:
            nidx[(x,y,z)] = len(nodes); nodes.append((x,y,z))
    edges, eidx = [], {}
    for i,(x,y,z) in enumerate(nodes):
      for dx,dy,dz in NN:
        j = nidx.get(((x+dx)%L,(y+dy)%L,(z+dz)%L))
        if j is not None:
          e = (i,j) if i<j else (j,i)
          if e not in eidx: eidx[e] = len(edges); edges.append(e)
    ne = len(edges)
    adj = [set() for _ in nodes]
    for a,b in edges: adj[a].add(b); adj[b].add(a)
    vmask = [0]*len(nodes)
    for ei,(a,b) in enumerate(edges):
      vmask[a] |= 1<<ei; vmask[b] |= 1<<ei
    omask = []
    for x in range(L):
      for y in range(L):
        for z in range(L):
          if (x+y+z) % 2 == 1:
            nbs = [nidx.get(((x+d[0])%L,(y+d[1])%L,(z+d[2])%L))
                   for d in OCT]
            if all(v is not None for v in nbs):
              s, m = set(nbs), 0
              for ei,(a,b) in enumerate(edges):
                if a in s and b in s: m |= 1<<ei
              omask.append(m)
    E = lambda u,v: eidx[(u,v)] if u<v else eidx[(v,u)]
    faces, claws = [], []
    for i in range(len(nodes)):
      nb = sorted(adj[i])
      for x in range(len(nb)):
        for y in range(x+1, len(nb)):
          j, k = nb[x], nb[y]
          if k not in adj[j]: continue
          if i < j:                       # triangular face
            faces.append((1<<E(i,j))|(1<<E(j,k))|(1<<E(i,k)))
          for l in nb[y+1:]:              # claw at apex i
            if l in adj[j] and l in adj[k]:
              claws.append((1<<E(i,j))|(1<<E(i,k))|(1<<E(i,l)))
    return nodes, edges, ne, vmask, omask, faces, claws

def rank(vecs):
    piv, r = {}, 0
    for v in vecs:
      while v:
        h = v.bit_length()-1
        if h in piv: v ^= piv[h]
        else: piv[h] = v; r += 1; break
    return r, piv

def pairing_rank(faces, claws):
    rows = []
    for f in faces:
        w = 0
        for j, c in enumerate(claws):
            if bin(f & c).count('1') & 1: w |= 1 << j
        rows.append(w)
    return rank(rows)[0]

for L in [4,6,8,10]:
    nodes, edges, ne, vmask, omask, faces, claws = build(L)
    rZ,_ = rank(vmask); rX,_ = rank(omask)
    rF,_ = rank(faces); rC,_ = rank(claws)
    rFX,_ = rank(list(omask)+list(faces))
    rCZ,_ = rank(list(vmask)+list(claws))
    print(L, ne, ne-rZ-rX, len(faces), len(claws), rF, rC,
          rFX-rX, rCZ-rZ, pairing_rank(faces, claws), ne-rZ-rFX)
