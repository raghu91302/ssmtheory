"""FULL AUDIT

  I    independent reconstruction of the lattice (guards against a systematic
       bug in the shared builder)
  II   every premise used inside a proof
  III  every numeric literal in the manuscript prose
  IV   appendix code output vs Table 1, row by row
  V    LaTeX integrity
  VI   response vs manuscript: cross-refs, numbers, claims, stale text
"""
import re, subprocess, itertools
from collections import Counter
from structure import build, rank, reduce_by
from claws import claws as build_claws

TEX = open('manuscript_v3.tex').read()
MS = subprocess.run(['pdftotext', '-layout', 'manuscript_v3.pdf', '-'],
                    capture_output=True, text=True).stdout
RS = subprocess.run(['pdftotext', '-layout',
                     '/mnt/user-data/outputs/response_to_reviewers.pdf', '-'],
                    capture_output=True, text=True).stdout
FTEX = re.sub(r'\s+', ' ', TEX)
FMS = re.sub(r'\s+', ' ', MS)
FRS = re.sub(r'\s+', ' ', RS)

R = []
def chk(g, label, cond, detail=""):
    R.append((g, label, bool(cond), detail))


# ══════════ I. independent lattice reconstruction ══════════
def build_independent(L):
    """FCC from the conventional cubic cell with a four-point basis."""
    basis = [(0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 0)]
    nodes = set()
    for cx in range(0, L, 2):
        for cy in range(0, L, 2):
            for cz in range(0, L, 2):
                for b in basis:
                    nodes.add(((cx + b[0]) % L, (cy + b[1]) % L,
                               (cz + b[2]) % L))
    nodes = sorted(nodes)
    nidx = {c: i for i, c in enumerate(nodes)}
    D = [d for d in itertools.product((-1, 0, 1), repeat=3)
         if sum(abs(x) for x in d) == 2]
    edges = set()
    for c in nodes:
        for d in D:
            nb = tuple((c[i] + d[i]) % L for i in range(3))
            if nb in nidx:
                edges.add(tuple(sorted((nidx[c], nidx[nb]))))
    return len(nodes), len(edges), len(D)

for L in [4, 6]:
    nV, nE, deg = build_independent(L)
    nodes, edges, ne, vmask, omask, tris = build(L)
    chk('I', f'L={L} node count agrees ({nV})', nV == len(nodes) == L**3 // 2)
    chk('I', f'L={L} edge count agrees ({nE})', nE == ne == 3 * L**3)
    chk('I', f'L={L} coordination is 12', deg == 12)

# ══════════ II. proof premises ══════════
DATA = {}
for L in [4, 6, 8, 10]:
    nodes, edges, ne, vmask, omask, tris = build(L)
    cl = build_claws(nodes, edges)
    rZ, pivZ = rank(vmask); rX, pivX = rank(omask)
    rF, _ = rank(tris); rC, _ = rank(cl)
    rFX, _ = rank(list(omask) + list(tris))
    rCZ, _ = rank(list(vmask) + list(cl))
    DATA[L] = dict(nodes=nodes, edges=edges, ne=ne, vmask=vmask, omask=omask,
                   tris=tris, cl=cl, rZ=rZ, rX=rX, rF=rF, rC=rC,
                   rFX=rFX, rCZ=rCZ, k=ne - rZ - rX, kg=ne - rZ - rFX,
                   pivZ=pivZ, pivX=pivX)

for L in [4, 6, 8, 10]:
    d = DATA[L]
    ne, tris, cl, vmask, omask = d['ne'], d['tris'], d['cl'], d['vmask'], d['omask']

    # Lemma 1: one edge per triad sheet, both families
    def sheet(ei):
        a, b = d['edges'][ei]
        va, vb = d['nodes'][a], d['nodes'][b]
        q = tuple((vb[i] - va[i]) % L for i in range(3))
        q = tuple(x - L if x > L // 2 else x for x in q)
        return q.index(0)
    def sheets_of(v):
        return {sheet(ei) for ei in range(ne) if (v >> ei) & 1}
    chk('II', f'L={L} Lemma 1 faces use 3 sheets',
        all(len(sheets_of(t)) == 3 for t in tris))
    chk('II', f'L={L} Lemma 1 claws use 3 sheets',
        all(len(sheets_of(c)) == 3 for c in cl))

    # Lemma 4: each edge in exactly two octahedra
    per = Counter(sum(1 for m in omask if m & (1 << ei)) for ei in range(ne))
    chk('II', f'L={L} Lemma 4 every edge in 2 octahedra', per == {2: ne})

    # Theorem 2: (1,1,1,3) for faces vs octahedra
    pf = Counter(tuple(sorted(bin(m & t).count('1') for m in omask if m & t))
                 for t in tris)
    chk('II', f'L={L} Thm 2 face overlap (1,1,1,3)', pf == {(1, 1, 1, 3): len(tris)})
    # dual: (1,1,1,3) for claws vs vertices
    pc = Counter(tuple(sorted(bin(m & c).count('1') for m in vmask if m & c))
                 for c in cl)
    chk('II', f'L={L} claw overlap (1,1,1,3)', pc == {(1, 1, 1, 3): len(cl)})

    # Prop 1 / Prop 2 membership
    chk('II', f'L={L} faces in ker(HZ)',
        all(all(bin(m & t).count('1') % 2 == 0 for m in vmask) for t in tris))
    chk('II', f'L={L} claws in ker(HX)',
        all(all(bin(m & c).count('1') % 2 == 0 for m in omask) for c in cl))
    chk('II', f'L={L} faces non-stabilizer',
        all(reduce_by(t, d['pivX']) != 0 for t in tris))
    chk('II', f'L={L} claws non-stabilizer',
        all(reduce_by(c, d['pivZ']) != 0 for c in cl))

    # Prop 3 premise: no weight-1 or weight-2 in either kernel
    if L <= 6:
        bad = 0
        for i in range(ne):
            if all(bin(m & (1 << i)).count('1') % 2 == 0 for m in vmask): bad += 1
            if all(bin(m & (1 << i)).count('1') % 2 == 0 for m in omask): bad += 1
            for j in range(i + 1, ne):
                v = (1 << i) | (1 << j)
                if all(bin(m & v).count('1') % 2 == 0 for m in vmask): bad += 1
                if all(bin(m & v).count('1') % 2 == 0 for m in omask): bad += 1
        chk('II', f'L={L} Prop 3 premise: no wt-1/2 in either kernel', bad == 0)

    # Prop 3 core: face and claw supports are disjoint sets
    chk('II', f'L={L} Prop 3 no support is both face and claw',
        not (set(tris) & set(cl)))

    # Prop 4: syndrome ambiguity, both sectors
    def amb(fams, stabs):
        for v in fams[:300]:
            e = [ei for ei in range(ne) if (v >> ei) & 1]
            s1 = tuple(bin(m & ((1 << e[0]) | (1 << e[1]))).count('1') % 2
                       for m in stabs)
            s2 = tuple(bin(m & (1 << e[2])).count('1') % 2 for m in stabs)
            if s1 != s2: return False
        return True
    chk('II', f'L={L} Prop 4 face syndrome ambiguity', amb(tris, vmask))
    chk('II', f'L={L} Prop 4 claw syndrome ambiguity', amb(cl, omask))

    # Theorem 1: homology identity
    V = len(d['nodes'])
    chk('II', f'L={L} Thm 1 dim Z1 = 5L^3/2+1', ne - V + 1 == 5 * L**3 // 2 + 1)
    chk('II', f'L={L} Thm 1 B1 = span(F) = span(C)',
        ne - V + 1 - 3 == d['rF'] == d['rC'] == 5 * L**3 // 2 - 2)
    chk('II', f'L={L} Thm 1 rk(HX) = L^3/2-1', d['rX'] == L**3 // 2 - 1)
    chk('II', f'L={L} Thm 1 rk(HZ) = L^3/2-1', d['rZ'] == L**3 // 2 - 1)
    chk('II', f'L={L} Thm 1 classes = 2L^3-1',
        d['rF'] - d['rX'] == d['rC'] - d['rZ'] == 2 * L**3 - 1)
    chk('II', f'L={L} split k = (2L^3-1)+3', (2 * L**3 - 1) + 3 == d['k'])

    # Theorem 4: span condition, and one short leaves a survivor
    piv = dict(d['pivX']); c = 0
    for t in tris:
        r = reduce_by(t, piv)
        if r: piv[r.bit_length() - 1] = r; c += 1
        if c == 2 * L**3 - 1: break
    chk('II', f'L={L} Thm 4 full span leaves no face', c == 2 * L**3 - 1
        and sum(1 for s in tris if reduce_by(s, piv) != 0) == 0)
    piv2 = dict(d['pivX']); c2 = 0
    for t in tris:
        r = reduce_by(t, piv2)
        if r:
            if c2 == 2 * L**3 - 2: break
            piv2[r.bit_length() - 1] = r; c2 += 1
    chk('II', f'L={L} Thm 4 one short leaves a survivor',
        sum(1 for s in tris if reduce_by(s, piv2) != 0) > 0)
    chk('II', f'L={L} Thm 4 minimal gauging gives k=3', d['kg'] == 3)

# ══════════ III. numeric literals in the manuscript ══════════
LIT = [
    (r'\$4L\^3\$', None),
    (r'256 of the', 256), (r'\\binom\{192\}\{3\}', None),
    (r'256 and 864', None),
    (r'912 of the 1840', 912), (r'\[\[192, 3, 4\]\]', None),
    (r'\[\[648, 3, 6\]\]', None),
    (r'4\.7 \\times 10\^4', None),
    (r'1\.2 \\times 10\^\{-2\}', None),
    (r'256\n?violations at \$L = 4\$ and 864', None),
    (r'\\tfrac\{3\}\{2\}L\^3', None),
    (r'324, 768 and 1500', None),
    (r'432 rather than 96', None),
    (r'512 of the\n?1\{,\}161\{,\}280', None),
    (r'4\.4 \\times 10\^\{-4\}', None),
]
for pat, _ in LIT:
    chk('III', f'manuscript contains {pat[:34]}',
        re.search(pat, TEX) or re.search(pat.replace('\\n?', ' '), FTEX))

chk('III', 'C(192,3) = 1,161,280', 192 * 191 * 190 // 6 == 1161280)
chk('III', 'faces+claws / triples = 4.4e-4',
    abs(512 / 1161280 - 4.4e-4) < 5e-6)
chk('III', '1.2e-2 / (256 p^3) = 4.7e4',
    abs(1.2e-2 / (256 * 1e-9) / 1e4 - 4.7) < 0.1,
    f"{1.2e-2/(256*1e-9):.3g}")
chk('III', 'gauged rate L=4 1.56%', abs(3 / 192 * 100 - 1.5625) < 1e-6)
chk('III', 'gauged rate L=6 0.46%', abs(3 / 648 * 100 - 0.463) < 5e-3)
chk('III', '3L^3/2 at L=6,8,10 = 324,768,1500',
    [3 * L**3 // 2 for L in (6, 8, 10)] == [324, 768, 1500])

# Table 1 rows vs computation
for L in [4, 6, 8, 10]:
    d = DATA[L]
    m = re.search(rf"^{L}\s+&\s*(\d+)\s*&\s*(\d+)\s*&\s*(\d+)\s*&\s*(\d+)"
                  rf"\s*&\s*(\d+)\s*&\s*(\d+)\s*&\s*(\d+)", TEX, re.M)
    chk('III', f'Table 1 row L={L}', m)
    if m:
        n, k, N, span, cls, pair, kg = map(int, m.groups())
        chk('III', f'L={L} table n', n == d['ne'])
        chk('III', f'L={L} table k', k == d['k'])
        chk('III', f'L={L} table N=4L^3', N == 4 * L**3 == len(d['tris']) == len(d['cl']))
        chk('III', f'L={L} table span', span == d['rF'] == d['rC'])
        chk('III', f'L={L} table classes', cls == d['rF'] - d['rX'])
        chk('III', f'L={L} table pairing = 2L^3-4', pair == 2 * L**3 - 4)
        chk('III', f'L={L} table k_gauged', kg == d['kg'] == 3)

# ---- symbolic formulas must evaluate to real quantities ----
def tex_to_py(e):
    e = e.replace('\\tfrac{5}{2}', '(5/2)*').replace('\\tfrac{3}{2}', '(3/2)*')
    e = e.replace('\\tfrac{1}{2}', '(1/2)*')
    e = e.replace('L^3', 'L**3')                    # exponent first
    e = re.sub(r'(\d)\s*L\*\*3', r'\1*L**3', e)     # then implicit product
    return e

FORMULAS = re.findall(
    r'((?:\d+L\^3\s*[-+]\s*)?(?:\\tfrac\{\d\}\{\d\})?\d*L\^3'
    r'\s*[-+]\s*\d+)', TEX)
# bare coefficient forms with no additive constant, e.g. 4L^3
BARE = re.findall(r'(?<![-+]\s)(?<![\d}])(\d*L\^3)(?!\s*[-+]\s*\d)', TEX)
FORMULAS = FORMULAS + BARE
LEGIT = {}
for L in [4, 6, 8, 10]:
    d = DATA[L]
    LEGIT[L] = {d['ne'], len(d['nodes']), len(d['tris']), d['rF'], d['rC'],
                d['rF'] - d['rX'], 2 * L**3 - 4, d['k'], d['rX'], d['rZ'],
                d['ne'] - len(d['nodes']) + 1, 3 * L**3 // 2, d['kg'],
                L**3, L**3 // 2, 2 * L**3,
                6 * L**3}   # 6L^3 = edge-octahedron incidences (Lemma 4)
bad_formulas = []
for f in set(FORMULAS):
    try:
        vals = {L: eval(tex_to_py(f), {'L': L}) for L in [4, 6, 8, 10]}
    except Exception as exc:
        bad_formulas.append((f, f'unparseable: {exc}'))   # never skip silently
        continue
    if not all(abs(v - round(v)) < 1e-9 and round(v) in LEGIT[L]
               for L, v in vals.items()):
        bad_formulas.append((f, vals))
chk('III', f'every L^3 formula matches a computed quantity '
    f'({len(set(FORMULAS))} distinct)', not bad_formulas,
    str(bad_formulas[:2]))

# ---- named identities: right formula must be in the right place ----
IDENT = [
 (r'\$n = (3L\^3)\$',                       lambda L, d: d['ne']),
 (r'\$n = 3L\^3\$ and \$k = (2L\^3 \+ 2)\$', lambda L, d: d['k']),
 (r'N_\{\\rm tri\} \\;=\\;[^=]*\\;=\\; (4L\^3)', lambda L, d: len(d['tris'])),
 (r'\$V = (L\^3/2)\$',                      lambda L, d: len(d['nodes'])),
 (r'\\mathrm\{rk\}\(H_X\) = (\\tfrac\{1\}\{2\}L\^3 - 1)',
                                            lambda L, d: d['rX']),
 (r'\\mathrm\{rk\}\(H_Z\) = (\\tfrac\{1\}\{2\}L\^3 - 1)',
                                            lambda L, d: d['rZ']),
 (r'\\dim Z_1 = n - V \+ 1 = [^=]*= (\\tfrac\{5\}\{2\}L\^3 \+ 1)',
                                            lambda L, d: d['ne'] - len(d['nodes']) + 1),
 (r'\\dim \\mathcal\{F\} = \\dim \\mathcal\{C\} = (\\tfrac\{5\}\{2\}L\^3 - 2)',
                                            lambda L, d: d['rF']),
 (r'\\mathrm\{rk\}\(H_Z\) = (2L\^3 - 1)', lambda L, d: d['rC'] - d['rZ']),
 (r'pairing has rank \$(2L\^3 - 4)\$',        lambda L, d: 2*L**3 - 4),
 (r'is \$\\tfrac\{3\}\{2\}L\^3\$ for', lambda L, d: 3*L**3//2),
]
for pat, want in IDENT:
    m = re.search(pat, TEX)
    chk('III', f'identity present: {pat[:36]}', m)
    if not m or not m.groups():
        continue
    expr = m.group(1).replace('L^3/2', '(L**3)/2')
    try:
        ok = all(round(eval(tex_to_py(expr), {'L': L})) == want(L, DATA[L])
                 for L in [4, 6, 8, 10])
    except Exception as exc:
        ok, exc = False, exc
    chk('III', f'identity correct: {m.group(1)[:26]}', ok)

# ══════════ IV. appendix code reproduces Table 1 ══════════
code = re.search(r'\\begin\{verbatim\}(.*?)\\end\{verbatim\}', TEX, re.S).group(1)
open('_app.py', 'w').write(code)
out = subprocess.run(['python3', '_app.py'], capture_output=True, text=True,
                     timeout=1200).stdout.strip().splitlines()
chk('IV', 'appendix runs without error', len(out) == 4, out[:1])
for line in out:
    f = list(map(int, line.split()))
    L, n, k, nf, nc, rF, rC, cf, cc, pair, kg = f
    d = DATA[L]
    chk('IV', f'appendix L={L} n,k', n == d['ne'] and k == d['k'])
    chk('IV', f'appendix L={L} faces=claws=4L^3', nf == nc == 4 * L**3)
    chk('IV', f'appendix L={L} spans', rF == rC == d['rF'])
    chk('IV', f'appendix L={L} classes', cf == cc == 2 * L**3 - 1)
    chk('IV', f'appendix L={L} pairing', pair == 2 * L**3 - 4)
    chk('IV', f'appendix L={L} k_gauged', kg == 3)
    m = re.search(rf"^{L}\s+&\s*(\d+)\s*&\s*(\d+)\s*&\s*(\d+)\s*&\s*(\d+)"
                  rf"\s*&\s*(\d+)\s*&\s*(\d+)\s*&\s*(\d+)", TEX, re.M)
    tab = list(map(int, m.groups()))
    chk('IV', f'appendix L={L} matches Table 1 exactly',
        tab == [n, k, nf, rF, cf, pair, kg], f"{tab} vs {[n,k,nf,rF,cf,pair,kg]}")

# ══════════ V. LaTeX integrity (incl. PDF freshness) ══════════
import os
chk('V', 'PDF is newer than .tex',
    os.path.getmtime('manuscript_v3.pdf') >= os.path.getmtime('manuscript_v3.tex'),
    'recompile before auditing')
# content sync, auto-generated: sample real sentences from the source and
# require each to appear in the compiled PDF. Catches a stale PDF regardless
# of timestamps (latexmk can report "up-to-date" and leave one behind).
def strip_tex(x):
    x = re.sub(r'\\begin\{verbatim\}.*?\\end\{verbatim\}', ' ', x, flags=re.S)
    x = re.sub(r'%.*', ' ', x)
    x = re.sub(r'\$[^$]*\$', ' MATH ', x)
    # macros that swallow their argument entirely
    for mac in ['label', 'cite', 'ref', 'eqref', 'includegraphics', 'caption']:
        x = re.sub(r'\\' + mac + r'\{[^{}]*\}', ' ', x)
    x = re.sub(r'\\begin\{[a-z*]+\}(\[[^\]]*\])?', ' ', x)
    x = re.sub(r'\\end\{[a-z*]+\}', ' ', x)
    x = re.sub(r'\\[a-zA-Z]+\*?(\[[^\]]*\])?', ' ', x)
    x = re.sub(r'[{}~\\]', ' ', x)
    return re.sub(r'\s+', ' ', x)

def norm_words(x):
    x = re.sub(r'[\x00-\x1f]', '', x)               # ligature control bytes
    x = re.sub(r'(?m)^\s*\d+\s*$', ' ', x)          # page-number-only lines
    x = x.lower()
    x = re.sub(r'-\s+', '', x)          # undo PDF hyphenation at line breaks
    x = re.sub(r'\[\d+(,\s*\d+)*\]', ' ', x)   # citation markers
    x = re.sub(r'[^a-z0-9 ]+', ' ', x)
    return ' ' + re.sub(r'\s+', ' ', x).strip() + ' '

PDFW = norm_words(FMS)
body = TEX[TEX.index('\\section{Introduction}'):TEX.index('\\appendix')]
# split the SOURCE into sentences first, then keep only those free of
# cross-references, math and macros, so the comparison is apples to apples
raw = re.sub(r'\\begin\{verbatim\}.*?\\end\{verbatim\}', ' ', body, flags=re.S)
raw = re.sub(r'%.*', ' ', raw)
sync = []
for c in re.split(r'(?<=[.])\s', raw):
    if re.search(r'\\ref\{|\\cite\{|\\eqref\{|\$|\\[a-zA-Z]+\{', c):
        continue
    w = norm_words(strip_tex(c)).split()
    if len(w) >= 8:
        sync.append(' ' + ' '.join(w[:8]) + ' ')
sync = sync[::max(1, len(sync)//15)][:15]
missing = [f.strip() for f in sync if f not in PDFW]
# tolerate a few pdftotext artifacts (ligatures, mid-sentence page breaks);
# a stale PDF misses essentially all of them, which still fails this check
chk('V', f'tex/pdf content sync ({len(sync)-len(missing)}/{len(sync)} sampled '
    f'sentences found)', len(missing) <= 3, f"missing: {missing[:3]}")

labels = set(re.findall(r'\\label\{([^}]+)\}', TEX))
refs = set(re.findall(r'\\(?:eq)?ref\{([^}]+)\}', TEX))
cites = set()
for g in re.findall(r'\\cite\{([^}]+)\}', TEX):
    cites.update(x.strip() for x in g.split(','))
bibs = set(re.findall(r'\\bibitem\{([^}]+)\}', TEX))
secl = {l for l in labels if l.startswith(('sec:', 'app:'))}
chk('V', 'all refs resolve', refs <= labels, str(refs - labels))
chk('V', 'all cites resolve', cites <= bibs, str(cites - bibs))
chk('V', 'no uncited bibitems', not (bibs - cites), str(bibs - cites))
chk('V', 'no unused non-section labels', not (labels - refs - secl),
    str(labels - refs - secl))
chk('V', 'no ?? in PDF', '??' not in MS)
chk('V', 'no broken notin glyph', '\u2208/' not in MS)
chk('V', 'American spellings', not re.search(
    r'neighbour|colour|behaviour|maximis|minimis|analyse\b', TEX + RS))
chk('V', 'no em dash', '\u2014' not in TEX and '\u2014' not in RS)
chk('V', 'bold paragraph headings >= 15',
    len(re.findall(r'\\paragraph\{\\textbf', TEX)) >= 15)

# ══════════ VI. response vs manuscript ══════════
NAMES = {}
for kind in ['Theorem', 'Lemma', 'Proposition', 'Corollary']:
    for m in re.finditer(rf'{kind} (\d+) \(([^)]*)', FMS):
        NAMES[f'{kind} {m.group(1)}'] = m.group(2)
SECS = dict(re.findall(r'(\d)\s+([A-Z][A-Za-z0-9 \-,]+)', FMS))

for ref in sorted(set(re.findall(
        r'(?:Theorem|Lemma|Proposition|Corollary) \d', FRS))):
    chk('VI', f'response {ref} exists in manuscript', ref in NAMES,
        str(sorted(NAMES)))
for s in sorted(set(re.findall(r'Sec\. (\d)', FRS))):
    chk('VI', f'response Sec. {s} exists', s in SECS, str(SECS))
for f in sorted(set(re.findall(r'Fig\. (\d)', FRS))):
    chk('VI', f'response Fig. {f} exists', f'Figure {f}:' in MS)
for e in sorted(set(re.findall(r'Eq\. \((\d)\)', FRS))):
    chk('VI', f'response Eq. ({e}) exists', f'({e})' in MS)
chk('VI', 'response Appendix A exists', 'A Verification Code' in MS)

# semantic spot-checks: the response describes the right result
SEM = [
 ('Theorem 1', 'homolog', 'Dimension'),
 ('Theorem 2', 'anticommut', 'three'),
 ('Theorem 3', 'measurement', 'state-independent'),
 ('Theorem 4', 'span', 'Cost'),
 ('Corollary 1', 'classif', 'Complete'),
 ('Corollary 2', 'logical', 'Detection'),
 ('Proposition 3', 'mix', 'No mixed'),
 ('Proposition 4', 'syndrome', 'Syndrome'),
]
for ref, _kw, expect in SEM:
    if ref in NAMES:
        chk('VI', f'{ref} name contains "{expect}"', expect.lower()
            in NAMES[ref].lower(), NAMES[ref])

# numbers quoted in the response must appear in the manuscript
for num in ['256', '864', '2048', '4000', '127', '4.7', '1.2', '3', '432']:
    chk('VI', f'response number {num} in manuscript', num in FMS)

# stale text that must NOT appear anywhere
STALE = ['d_eff', 'd eff', 'flag round', 'five orders', '255 of 256',
         'effective distance', '29.0%', 'adaptive scheduling',
         'Monte Carlo threshold']
RSRC = open('make_response11.py').read()          # response generator source
for st in STALE:
    chk('VI', f'no stale "{st}" in manuscript source',
        st.lower() not in FTEX.lower())
    if st not in ('adaptive scheduling', 'Monte Carlo threshold', 'd eff',
                  'effective distance', 'd_eff'):
        chk('VI', f'no stale "{st}" in response source',
            st.lower() not in RSRC.lower())

# titles agree
T = 'Faces and Claws: A Complete Classification of the Weight-3'
chk('VI', 'titles agree', T in FMS and T in FRS)
# all ten reviewer quotes verbatim
QUOTES = [
 "I think the paper reads well and recommend for publication in its form",
 "Two system sizes are insufficient to establish the scaling trend",
 "The FCC simulations use a greedy single-qubit corrector",
 "hardware requirements, decoding complexity, and a fair comparison",
 "the ability to perform fault-tolerant logical operations is an important issue",
 "The manuscript presents an interesting and original idea",
 "the assumptions behind the relation",
 "limited to relatively small lattice sizes",
 "adaptive flag scheduling approach is promising",
 "could benefit from additional intuitive explanations",
]
for q in QUOTES:
    chk('VI', f'quote "{q[:34]}..."', q in FRS)

# ══════════ report ══════════
G = {'I': 'independent reconstruction', 'II': 'proof premises',
     'III': 'manuscript numbers', 'IV': 'appendix vs Table 1',
     'V': 'LaTeX integrity', 'VI': 'response vs manuscript'}
print("=" * 70)
for g, name in G.items():
    rs = [r for r in R if r[0] == g]
    f = [r for r in rs if not r[2]]
    print(f"  {g:<4} {name:30s} {len(rs)-len(f):3d} pass  {len(f):2d} fail")
print("=" * 70)
fails = [r for r in R if not r[2]]
if fails:
    print("\nFAILURES:")
    for g, l, _, d in fails:
        print(f"  [{g}] {l}" + (f"   ({d})" if d else ""))
else:
    print("\nALL CHECKS PASS")
print(f"\ntotal: {len(R)} checks, {len(fails)} failures")
