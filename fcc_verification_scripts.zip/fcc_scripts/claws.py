"""The dual weight-3 sector: claws.

Conjecture from the L=4 data: the weight-3 Z-type logicals are the 'claws'
formed by the three edges of a tetrahedron meeting at one of its vertices.
Indexed by (tetrahedron, apex), so 4L^3 of them, matching the face count.

Verifies:
  - claws are exactly the weight-3 vectors of ker(H_X)  (exhaustive, L=4,6)
  - claw count 4L^3, span rank, independent classes 2L^3-1  (L=4,6,8,10)
  - the (3,1,1,1) vertex-overlap pattern dual to the face (1,1,1,3)
  - the symplectic pairing between the two sectors is non-degenerate
"""
import sys
import numpy as np
from itertools import combinations
from structure import build, rank, reduce_by


def claws(nodes, edges):
    """Three edges of a tetrahedron meeting at one vertex, as bitmasks."""
    eidx = {}
    for ei, (a, b) in enumerate(edges):
        eidx[(a, b)] = ei
    adj = [set() for _ in nodes]
    for a, b in edges:
        adj[a].add(b); adj[b].add(a)
    def E(u, v):
        return eidx[(u, v)] if u < v else eidx[(v, u)]
    out = []
    for i in range(len(nodes)):
        # triangles among the neighbors of i  ->  tetrahedron (i,j,k,l)
        nb = sorted(adj[i])
        for a in range(len(nb)):
            for b in range(a + 1, len(nb)):
                j, k = nb[a], nb[b]
                if k not in adj[j]:
                    continue
                for l in nb[b + 1:]:
                    if l in adj[j] and l in adj[k]:
                        out.append((1 << E(i, j)) | (1 << E(i, k))
                                   | (1 << E(i, l)))
    return out


def exhaustive_wt3_kernel(ne, cols):
    """All weight-3 vectors v with cols[a]^cols[b]^cols[c] == 0."""
    found = []
    M = np.array(cols, dtype=np.uint8)
    for a in range(ne):
        for b in range(a + 1, ne):
            ab = M[a] ^ M[b]
            hits = np.where(~(M[b + 1:] ^ ab).any(axis=1))[0]
            for h in hits:
                found.append((a, b, b + 1 + int(h)))
    return found


for L in [int(x) for x in (sys.argv[1:] or [4, 6, 8, 10])]:
    nodes, edges, ne, vmask, omask, tris = build(L)
    rZ, pivZ = rank(vmask)
    rX, pivX = rank(omask)
    cl = claws(nodes, edges)
    print(f"\n===== L = {L} =====")
    print(f"  claws found: {len(cl)}   4L^3 = {4*L**3}   "
          f"distinct: {len(set(cl))}")

    # every claw is in ker(H_X) and is not a stabilizer
    inker = sum(1 for c in cl if all(bin(m & c).count('1') % 2 == 0
                                     for m in omask))
    nonstab = sum(1 for c in cl if reduce_by(c, pivZ) != 0)
    print(f"  in ker(H_X): {inker}/{len(cl)}    "
          f"non-stabilizer: {nonstab}/{len(cl)}")

    # vertex-overlap pattern (dual to the face pattern)
    from collections import Counter
    pat = Counter()
    for c in cl:
        pat[tuple(sorted(bin(m & c).count('1') for m in vmask if m & c))] += 1
    print(f"  vertex-overlap patterns: {dict(pat)}")

    # span and independent classes
    rC, _ = rank(cl)
    rCZ, _ = rank(list(vmask) + list(cl))
    print(f"  span(claws) rank {rC};  rank(rowsp(HZ)+claws) {rCZ}  "
          f"-> independent {rCZ-rZ}  (2L^3-1 = {2*L**3-1})")
    print(f"  rowspace(HZ) inside claw span: {rCZ == rC}")
    print(f"  k after gauging all claws: {ne - rX - rCZ}")

    # exhaustive check that claws are ALL the weight-3 kernel vectors
    if L <= 6:
        cols = [[(m >> ei) & 1 for m in omask] for ei in range(ne)]
        found = exhaustive_wt3_kernel(ne, cols)
        S = {(1 << a) | (1 << b) | (1 << c) for a, b, c in found}
        print(f"  exhaustive weight-3 in ker(H_X): {len(found)}   "
              f"equals claw set: {S == set(cl)}")

    # symplectic pairing between the two sectors
    A = np.zeros((len(tris), len(cl)), dtype=np.uint8)
    for i, t in enumerate(tris):
        for j, c in enumerate(cl):
            A[i, j] = bin(t & c).count('1') & 1
    rows = [int(''.join(map(str, A[i])), 2) for i in range(len(tris))]
    rP, _ = rank(rows)
    print(f"  symplectic pairing rank between sectors: {rP}  "
          f"(2L^3-1 = {2*L**3-1})")
