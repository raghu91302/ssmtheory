"""
Exact GF(2) structural analysis of the FCC CSS code.

Establishes, for each even L:
  (1) every triangular face of the FCC graph carries a weight-3 X-type logical
      (invisible to the Z-syndrome, outside the X-stabilizer rowspace);
  (2) the corresponding Z-type parity Z_ea Z_eb Z_ec ANTICOMMUTES with the
      octahedral X-stabilizers (odd overlap), hence is not a measurable check;
  (3) the triangle logicals span exactly 2L^3 - 1 independent logical
      directions, so gauging them all leaves k = 3.

All arithmetic is exact linear algebra over GF(2) using Python big-int bitmasks.
No Monte Carlo, no statistical floor.
"""
import sys
from collections import Counter

NN = [(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),
      (1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
      (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
OCT = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]


def build(L):
    nidx = {}
    nodes = []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z) % 2 == 0:
                    nidx[(x,y,z)] = len(nodes)
                    nodes.append((x,y,z))
    edges, eidx = [], {}
    for i,(x,y,z) in enumerate(nodes):
        for dx,dy,dz in NN:
            nb = ((x+dx)%L, (y+dy)%L, (z+dz)%L)
            j = nidx.get(nb)
            if j is not None:
                e = (i,j) if i < j else (j,i)
                if e not in eidx:
                    eidx[e] = len(edges); edges.append(e)
    ne = len(edges)

    # adjacency
    adj = [set() for _ in range(len(nodes))]
    for a,b in edges:
        adj[a].add(b); adj[b].add(a)

    # Z-stabilizers: vertices, as bitmasks over edges
    vmask = [0]*len(nodes)
    for ei,(a,b) in enumerate(edges):
        vmask[a] |= 1 << ei
        vmask[b] |= 1 << ei

    # X-stabilizers: octahedral voids
    omask = []
    for x in range(L):
        for y in range(L):
            for z in range(L):
                if (x+y+z) % 2 == 1:
                    nbs = []
                    for dx,dy,dz in OCT:
                        nb = ((x+dx)%L, (y+dy)%L, (z+dz)%L)
                        j = nidx.get(nb)
                        if j is not None: nbs.append(j)
                    if len(nbs) == 6:
                        s = set(nbs); m = 0
                        for ei,(a,b) in enumerate(edges):
                            if a in s and b in s: m |= 1 << ei
                        omask.append(m)

    # triangular faces
    tris = []
    for i in range(len(nodes)):
        for j in adj[i]:
            if j > i:
                for k in adj[i] & adj[j]:
                    if k > j:
                        m = (1 << eidx[(i,j)]) | (1 << eidx[(j,k)]) | (1 << eidx[(i,k)])
                        tris.append(m)
    return nodes, edges, ne, vmask, omask, tris


def rank(vecs):
    """GF(2) rank of a list of big-int bitmask vectors."""
    piv = {}
    r = 0
    for v in vecs:
        while v:
            h = v.bit_length() - 1
            if h in piv:
                v ^= piv[h]
            else:
                piv[h] = v; r += 1; break
    return r, piv


def reduce_by(v, piv):
    """Reduce v against a pivot dict; returns residual (0 iff v in the span)."""
    while v:
        h = v.bit_length() - 1
        if h in piv:
            v ^= piv[h]
        else:
            return v
    return 0


def analyse(L):
    nodes, edges, ne, vmask, omask, tris = build(L)
    out = {}
    out['L'] = L
    out['nodes'] = len(nodes)
    out['n'] = ne
    out['octs'] = len(omask)
    out['tris'] = len(tris)

    rZ, _ = rank(vmask)
    rX, pivX = rank(omask)
    out['rkHZ'] = rZ
    out['rkHX'] = rX
    out['k'] = ne - rZ - rX

    # (1) syndrome-invisibility: HZ.v == 0 for every triangle
    #     vertex v sees an even number of triangle edges <=> popcount(vmask & t) even
    silent = sum(1 for t in tris
                 if all(bin(m & t).count('1') % 2 == 0 for m in vmask))
    out['silent_Z'] = silent

    # (2) overlap of each triangle with the octahedral stabilizers
    ctr = Counter()
    commuting = 0
    for t in tris:
        odd = 0
        for m in omask:
            c = bin(m & t).count('1')
            if c: ctr[c] += 1
            if c % 2: odd += 1
        if odd == 0: commuting += 1
    out['overlaps'] = dict(ctr)
    out['ZZZ_commuting'] = commuting

    # (1b) genuine logicals: in ker(HZ), outside rowspace(HX)
    nonstab = sum(1 for t in tris if reduce_by(t, pivX) != 0)
    out['nonstab'] = nonstab

    # (3) how many independent logical directions the triangles carry
    rT, _ = rank(tris)
    rTX, _ = rank(list(omask) + list(tris))
    out['rk_tri'] = rT
    out['rk_tri_plus_HX'] = rTX
    out['new_indep'] = rTX - rX
    out['k_gauged'] = ne - rZ - rTX
    out['HX_in_tri_span'] = (rTX == rT)
    return out


def main(Ls):
    rows = []
    for L in Ls:
        r = analyse(L)
        rows.append(r)
        print(f"\n===== L = {L} =====", flush=True)
        print(f"  nodes={r['nodes']}  n=3L^3={r['n']}  octs={r['octs']}  "
              f"triangles={r['tris']} (4L^3={4*L**3})")
        print(f"  rk(HZ)={r['rkHZ']}  rk(HX)={r['rkHX']}  k={r['k']}  "
              f"(2L^3+2={2*L**3+2})")
        print(f"  [1] triangles with HZ.v=0            : {r['silent_Z']}/{r['tris']}")
        print(f"      triangles outside rowspace(HX)   : {r['nonstab']}/{r['tris']}")
        print(f"  [2] triangles with ZZZ commuting     : {r['ZZZ_commuting']}/{r['tris']}")
        print(f"      overlap multiset (triangle,oct)  : {r['overlaps']}")
        print(f"  [3] rank(span triangles)             : {r['rk_tri']}")
        print(f"      rank(rowsp HX + triangles)       : {r['rk_tri_plus_HX']}")
        print(f"      new independent logicals gauged  : {r['new_indep']}  "
              f"(2L^3-1={2*L**3-1})")
        print(f"      k after gauging all triangles    : {r['k_gauged']}")
        print(f"      rowspace(HX) inside triangle span: {r['HX_in_tri_span']}")

    print("\n\n=== SUMMARY TABLE ===")
    hdr = f"{'L':>3} {'n':>6} {'k':>6} {'N_tri':>7} {'indep':>7} {'2L^3-1':>8} {'k_gauged':>9}"
    print(hdr); print('-'*len(hdr))
    for r in rows:
        print(f"{r['L']:>3} {r['n']:>6} {r['k']:>6} {r['tris']:>7} "
              f"{r['new_indep']:>7} {2*r['L']**3-1:>8} {r['k_gauged']:>9}")


if __name__ == '__main__':
    Ls = [int(a) for a in sys.argv[1:]] or [4,6,8]
    main(Ls)
