"""Does restricting errors to a known sheet raise the effective distance?

Every triangle uses one edge from each triad sheet (Lemma 1).  So an error
confined to one or two sheets cannot form a triangle logical.  This script
finds the minimum-weight logical operator supported inside each sheet subset.

Also tests the erasure case: if the LOCATIONS of errors are known, how many
can be corrected?
"""
import sys
from itertools import combinations
from structure import build, rank, reduce_by

L = int(sys.argv[1]) if len(sys.argv) > 1 else 4
nodes, edges, ne, vmask, omask, tris = build(L)
rZ, _ = rank(vmask)
rX, pivX = rank(omask)
k0 = ne - rZ - rX
print(f"L={L}: n={ne}, k={k0}, d=3 (unrestricted)\n")

# --- classify every edge by triad sheet -----------------------------------
nidx = {c: i for i, c in enumerate(nodes)}
sheet_of = {}
for ei, (a, b) in enumerate(edges):
    va, vb = nodes[a], nodes[b]
    d = tuple((vb[i] - va[i]) % L for i in range(3))
    d = tuple(x - L if x > L // 2 else x for x in d)
    z = d.index(0)                      # which component is zero
    sheet_of[ei] = ('S_yz', 'S_xz', 'S_xy')[z]

sheets = {}
for ei, s in sheet_of.items():
    sheets.setdefault(s, []).append(ei)
print("edges per sheet:", {s: len(v) for s, v in sheets.items()})

# sanity: every triangle should have one edge per sheet
ok = all(len({sheet_of[ei] for ei in range(ne) if (t >> ei) & 1}) == 3
         for t in tris)
print(f"every triangle uses all three sheets: {ok}\n")


def min_logical_in(support, maxw=4):
    """Smallest weight of a vector supported in `support` that is in ker(HZ)
    and outside rowspace(HX).  Returns (weight, example) or None."""
    sup = list(support)
    for w in range(1, maxw + 1):
        for combo in combinations(sup, w):
            v = 0
            for ei in combo:
                v |= 1 << ei
            if any(bin(m & v).count('1') % 2 for m in vmask):
                continue                     # visible to the syndrome
            if reduce_by(v, pivX) == 0:
                continue                     # it is a stabilizer
            return w, combo
    return None


print("=" * 62)
print("ERRORS CONFINED TO ONE SHEET")
print("=" * 62)
for s, sup in sheets.items():
    r = min_logical_in(sup, maxw=5)
    if r:
        w, combo = r
        print(f"  {s}: minimum logical weight = {w}   edges {list(combo)}")
    else:
        print(f"  {s}: no logical of weight <= 5 inside this sheet")

print()
print("=" * 62)
print("ERRORS CONFINED TO TWO SHEETS")
print("=" * 62)
for s1, s2 in combinations(sheets, 2):
    sup = sheets[s1] + sheets[s2]
    r = min_logical_in(sup, maxw=4)
    if r:
        w, combo = r
        print(f"  {s1}+{s2}: minimum logical weight = {w}")
    else:
        print(f"  {s1}+{s2}: no logical of weight <= 4")

print()
print("=" * 62)
print("ALL THREE SHEETS (the actual code)")
print("=" * 62)
r = min_logical_in(range(ne), maxw=3)
print(f"  minimum logical weight = {r[0]}   edges {list(r[1])}")

print()
print("=" * 62)
print("KNOWN LOCATIONS (erasure channel)")
print("=" * 62)
print("  If error positions are known, the code corrects any erasure pattern")
print("  that does not contain a logical operator.  The smallest logical has")
print("  weight 3, so:")
print("    - any 2 erasures      : always correctable")
print("    - 3 erasures          : correctable unless they form a triangle")
print(f"    - number of bad triples: {len(tris)} of {ne*(ne-1)*(ne-2)//6} "
      f"= {len(tris)/(ne*(ne-1)*(ne-2)/6):.2e}")
