# Verification scripts for "Every Weight-3 Logical Operator of the Face Centered Cubic Lattice Code Is a Face or a Claw"

Raghu Kulkarni, SSMTheory Group, IDrive Inc. — raghu@idrive.com

All exact results are Gaussian elimination over GF(2); there is no sampling.

| Script | Purpose | Requirements |
|---|---|---|
| `appendix_a.py` | Standalone script printed in Appendix A. Code parameters, face/claw counts, span dimensions, logical-class counts, pairing rank, and k after gauging, for L = 4, 6, 8, 10. | stdlib only, a few seconds |
| `structure.py` | Lattice builder and GF(2) linear algebra; establishes the face sector. | stdlib |
| `claws.py` | The dual weight-3 sector (claws); imports `structure.py`. | stdlib |
| `verify_symmetric.py` | Table of both sectors, homology counts, k = (2L³−1)+3. | stdlib |
| `options.py` | Rate–distance options: gauging all faces ([[192,3,4]], [[648,3,6]], 4-cycle counts) and the tetrahedral-void stabilizer no-go. | stdlib |
| `sheets.py` | Minimum-weight logicals under errors restricted to triad sheets. | stdlib |
| `audit.py` | Independent lattice reconstruction and check of every numeric literal in the manuscript. | stdlib |
| `figures.py` | Regenerates the three vector-PDF figures. | numpy, matplotlib |

Run any script with `python3 <script>.py`. Python 3.8 or later.
