"""What the FCC lattice actually offers on the rate-distance plane.

(A) Gauging all faces: what are [[n, k, d]]?
(B) Adding tetrahedral-void stabilizers as a third layer (the route proposed
    in arXiv:2603.20294 Sec. 9(a)): does it preserve CSS validity, and what
    does it do to k?
"""
import sys
from itertools import combinations
from structure import build, rank, reduce_by


def tetrahedra(nodes, edges):
    """4-cliques of the FCC graph, returned as 6-edge bitmasks."""
    eidx = {}
    for ei, (a, b) in enumerate(edges):
        eidx[(a, b)] = ei
    adj = [set() for _ in range(len(nodes))]
    for a, b in edges:
        adj[a].add(b); adj[b].add(a)
    def E(u, w):
        return eidx[(u, w)] if u < w else eidx[(w, u)]
    tets = []
    for i in range(len(nodes)):
        for j in adj[i]:
            if j <= i: continue
            for k in adj[i] & adj[j]:
                if k <= j: continue
                for l in adj[i] & adj[j] & adj[k]:
                    if l <= k: continue
                    m = 0
                    for u, w in combinations((i, j, k, l), 2):
                        m |= 1 << E(u, w)
                    tets.append(m)
    return tets


def cycles_of_weight(nodes, edges, w):
    """All simple cycles of length w, as bitmasks (w = 4 or 5)."""
    eidx = {}
    for ei, (a, b) in enumerate(edges):
        eidx[(a, b)] = ei
    adj = [set() for _ in range(len(nodes))]
    for a, b in edges:
        adj[a].add(b); adj[b].add(a)
    def E(u, v):
        return eidx[(u, v)] if u < v else eidx[(v, u)]
    out, seen = [], set()
    def walk(start, path, used):
        if len(path) == w:
            if start in adj[path[-1]]:
                key = frozenset(path)
                if len(key) == w and key not in seen:
                    seen.add(key)
                    m = 0
                    ok = True
                    for i in range(w):
                        u, v = path[i], path[(i + 1) % w]
                        if u == v: ok = False; break
                        m ^= 1 << E(u, v)
                    if ok and bin(m).count('1') == w:
                        out.append(m)
            return
        for nb in adj[path[-1]]:
            if nb > start and nb not in used:
                walk(start, path + [nb], used | {nb})
    for s in range(len(nodes)):
        walk(s, [s], {s})
    return out


for L in [int(a) for a in (sys.argv[1:] or [4, 6])]:
    nodes, edges, ne, vmask, omask, tris = build(L)
    rZ, pivZ = rank(vmask)
    rX, _ = rank(omask)
    print(f"\n===== L = {L} =====")
    print(f"  base code: n={ne}  k={ne-rZ-rX}  d=3")

    # ---------- (A) gauge every triangular face ----------
    rTX, pivTX = rank(list(omask) + list(tris))
    k_g = ne - rZ - rTX
    print(f"\n  (A) gauge all {len(tris)} faces:")
    print(f"      k = {k_g}")
    dmin = None
    for w in (4, 5):
        cyc = cycles_of_weight(nodes, edges, w)
        outside = sum(1 for c in cyc if reduce_by(c, pivTX) != 0)
        print(f"      weight-{w} logicals: {outside} (of {len(cyc)} {w}-cycles)")
        if outside and dmin is None:
            dmin = w
    if dmin:
        print(f"      => d = {dmin}   parameters [[{ne}, {k_g}, {dmin}]]")
    else:
        print(f"      => d >= 6   (shortest non-contractible cycle is L = {L})")
    print(f"      rate = {k_g/ne:.4%}")

    # ---------- (B) add tetrahedral-void Z-stabilizers ----------
    tets = tetrahedra(nodes, edges)
    print(f"\n  (B) add {len(tets)} tetrahedral Z-stabilizers (expect L^3={L**3}):")
    # CSS validity: every new Z row must overlap every X stabilizer evenly
    bad = 0
    ov = {}
    for t in tets:
        for m in omask:
            c = bin(m & t).count('1')
            if c: ov[c] = ov.get(c, 0) + 1
            if c % 2: bad += 1
    print(f"      overlap sizes (tet, oct): {ov}")
    print(f"      odd overlaps (CSS violations): {bad}")
    if bad == 0:
        rZ2, _ = rank(list(vmask) + list(tets))
        print(f"      rk(HZ') = {rZ2}   k = {ne - rZ2 - rX}")
    else:
        print(f"      => CSS validity FAILS: HX HZ'^T != 0")
        # would the tet checks at least see the face errors?
        det = sum(1 for t in tris
                  if any(bin(m & t).count('1') % 2 for m in tets))
        print(f"      (faces detected by tet checks: {det}/{len(tris)})")
