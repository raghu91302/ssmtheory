"""Figures for the revised manuscript.  Vector PDF output, no raster."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
from structure import build, rank, reduce_by

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif"],
    "font.size": 9,
    "axes.linewidth": 0.8,
    "axes.labelsize": 9,
    "axes.titlesize": 9.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "legend.frameon": False,
    "pdf.fonttype": 42,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
})

C_XY, C_XZ, C_YZ = "#c0392b", "#1a6fb5", "#1e8449"
C_OCT, C_NODE, C_GRAY = "#e08a1e", "#2c3e50", "#95a5a6"


# ══════════════════════════════════════════════════════════════════
# Figure 1 -- the shared-face geometry and the no-go
# ══════════════════════════════════════════════════════════════════
def fig_geometry():
    fig = plt.figure(figsize=(7.2, 2.75))

    A, B, C = np.array([0, 0, 0]), np.array([1, 0, 1]), np.array([0, 1, 1])
    D = np.array([1, 1, 0])
    oc = np.array([0, 0, 1])
    oct_v = np.array([[1, 0, 1], [-1, 0, 1], [0, 1, 1],
                      [0, -1, 1], [0, 0, 2], [0, 0, 0]], float)
    EDGES = [(A, B, C_XZ, r"$S_{xz}$"), (A, C, C_YZ, r"$S_{yz}$"),
             (C, B, C_XY, r"$S_{xy}$")]
    CLAW = [(A, B, C_XZ), (A, C, C_YZ), (A, D, C_XY)]

    def frame(ax, lo=-0.35, hi=1.25, zlo=-0.1, zhi=1.5):
        ax.set_box_aspect((1, 1, 1)); ax.set_axis_off()
        ax.view_init(elev=15, azim=40)
        ax.set_xlim(lo, hi); ax.set_ylim(lo, hi); ax.set_zlim(zlo, zhi)

    # (a) triangular face
    ax = fig.add_subplot(141, projection="3d")
    for p, q, col, lab in EDGES:
        ax.plot(*zip(p, q), color=col, lw=3.0, solid_capstyle="round",
                label=lab, zorder=3)
    ax.add_collection3d(Poly3DCollection([[A, B, C]], alpha=0.18,
                                         facecolor="#7f8c8d"))
    for p in (A, B, C):
        ax.scatter(*p, s=34, color=C_NODE, depthshade=False, zorder=4)
    frame(ax)
    ax.set_title("(a) face\n$X$-type", y=0.94, fontsize=8.5)
    ax.legend(loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.10),
              handlelength=0.9, columnspacing=0.7, handletextpad=0.3,
              fontsize=7)

    # (b) claw at an apex of the same tetrahedron
    ax = fig.add_subplot(142, projection="3d")
    for p, q in [(B, C), (B, D), (C, D)]:
        ax.plot(*zip(p, q), color=C_GRAY, lw=0.9, ls=":", zorder=1)
    for p, q, col in CLAW:
        ax.plot(*zip(p, q), color=col, lw=3.0, solid_capstyle="round",
                zorder=3)
    for p in (B, C, D):
        ax.scatter(*p, s=26, facecolor="white", edgecolor=C_NODE,
                   linewidths=0.9, depthshade=False, zorder=4)
    ax.scatter(*A, s=52, color=C_OCT, depthshade=False, zorder=5)
    frame(ax, zlo=-0.15, zhi=1.45)
    ax.set_title("(b) claw at apex\n$Z$-type", y=0.94, fontsize=8.5)

    # (c) the octahedron containing the face
    ax = fig.add_subplot(143, projection="3d")
    faces = []
    for i in range(6):
        for j in range(i + 1, 6):
            for k in range(j + 1, 6):
                v = oct_v[[i, j, k]]
                if np.linalg.norm(v.mean(0) - oc) > 0.1:
                    faces.append(v)
    ax.add_collection3d(Poly3DCollection(faces, alpha=0.11, facecolor=C_OCT,
                                         edgecolor=C_OCT, linewidths=0.6))
    ax.scatter(oct_v[:, 0], oct_v[:, 1], oct_v[:, 2], s=18, color=C_OCT,
               depthshade=False)
    for p, q, col, _ in EDGES:
        ax.plot(*zip(p, q), color=col, lw=3.0, solid_capstyle="round",
                zorder=6)
    ax.add_collection3d(Poly3DCollection([[A, B, C]], alpha=0.34,
                                         facecolor="#7f8c8d"))
    frame(ax, -1.05, 1.25, -0.15, 2.05)
    ax.set_title("(c) shared octahedron\noverlap 3", y=0.94, fontsize=8.5)

    # (d) the four odd overlaps
    ax = fig.add_subplot(144, projection="3d")
    ax.add_collection3d(Poly3DCollection([[A, B, C]], alpha=0.16,
                                         facecolor="#7f8c8d"))
    for p, q, col, _ in EDGES:
        ax.plot(*zip(p, q), color=col, lw=3.0, solid_capstyle="round",
                zorder=6)
    for cen, (p, q), col in [(np.array([1, 0, 0]), (A, B), C_XZ),
                             (np.array([0, 1, 0]), (A, C), C_YZ),
                             (np.array([1, 1, 1]), (C, B), C_XY)]:
        mid = (np.asarray(p) + np.asarray(q)) / 2.0
        ax.plot(*zip(cen, mid), color=col, lw=0.8, ls=":", zorder=2)
        ax.scatter(*cen, s=40, marker="s", facecolor="white", edgecolor=col,
                   linewidths=1.4, depthshade=False, zorder=7)
    cmid = (A + B + C) / 3.0
    ax.plot(*zip(oc, cmid), color=C_OCT, lw=0.8, ls=":", zorder=2)
    ax.scatter(*oc, s=40, marker="s", facecolor="white", edgecolor=C_OCT,
               linewidths=1.4, depthshade=False, zorder=7)
    for p in (A, B, C):
        ax.scatter(*p, s=28, color=C_NODE, depthshade=False, zorder=5)
    frame(ax)
    ax.set_title("(d) odd overlaps\n$(1,1,1,3)$", y=0.94, fontsize=8.5)

    fig.subplots_adjust(wspace=-0.04, left=-0.01, right=1.01,
                        top=1.02, bottom=-0.06)
    fig.savefig("fig_geometry.pdf", bbox_inches=None)
    plt.close(fig)
    print("fig_geometry.pdf")


# ══════════════════════════════════════════════════════════════════
# Figure 2 -- rate against distance: the two-point structure
# ══════════════════════════════════════════════════════════════════
def fig_tradeoff():
    L = 4
    nodes, edges, ne, vmask, omask, tris = build(L)
    rZ, _ = rank(vmask)
    rX, pivX = rank(omask)
    k0 = ne - rZ - rX

    piv = dict(pivX)
    xs, ks, left = [0], [k0], [len(tris)]
    indep = 0
    for t in tris:
        r = reduce_by(t, piv)
        if r:
            piv[r.bit_length() - 1] = r
            indep += 1
            xs.append(indep); ks.append(k0 - indep)
            left.append(sum(1 for s in tris if reduce_by(s, piv) != 0))

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.65))

    ax = axes[0]
    ax.plot(xs, ks, color=C_XZ, lw=1.8, label=r"logical qubits $k$")
    ax.plot(xs, left, color=C_OCT, lw=1.4, ls="--",
            label="faces outside span")
    ax.axhline(3, color=C_GRAY, ls=":", lw=0.9)
    ax.axvline(xs[-1], color=C_XY, ls="--", lw=1.0)
    ax.text(xs[-1] - 4, 150, r"$d\geq4$ only here", color=C_XY, fontsize=7.5,
            ha="right")
    ax.text(4, 12, r"$k=3$", color=C_GRAY, fontsize=8)
    ax.set_xlabel(r"independent face directions adjoined")
    ax.set_ylabel("count")
    ax.set_title(r"(a) $d=3$ until the span closes")
    ax.set_xlim(0, 135); ax.set_ylim(0, 275)
    ax.legend(loc="upper right", handlelength=1.6)

    ax = axes[1]
    ax.scatter([3], [67.7], s=52, color=C_XZ, zorder=5)
    ax.annotate("FCC base\n[[192, 130, 3]]", (3, 67.7), xytext=(3.1, 40),
                fontsize=8, color=C_XZ,
                arrowprops=dict(arrowstyle="-", color=C_XZ, lw=0.7))
    ax.scatter([4], [1.56], s=52, color=C_XY, zorder=5)
    ax.annotate("FCC gauged\n[[192, 3, 4]]", (4, 1.56), xytext=(4.25, 0.85),
                fontsize=8, color=C_XY,
                arrowprops=dict(arrowstyle="-", color=C_XY, lw=0.7))
    ax.scatter([4], [2.78], s=52, marker="^", color=C_NODE, zorder=5)
    ax.annotate("3D toric\n[[108, 3, 4]]", (4, 2.78), xytext=(4.25, 7.5),
                fontsize=8, color=C_NODE,
                arrowprops=dict(arrowstyle="-", color=C_NODE, lw=0.7))
    ax.scatter([4], [3.1], s=52, marker="D", color=C_GRAY, zorder=4)
    ax.annotate("2D surface", (4, 3.1), xytext=(3.05, 4.6),
                fontsize=8, color=C_GRAY,
                arrowprops=dict(arrowstyle="-", color=C_GRAY, lw=0.7))
    ax.plot([3, 4], [67.7, 1.56], color=C_GRAY, ls="--", lw=1.0, zorder=1)
    ax.text(3.52, 17, "no code on this line", color=C_GRAY, fontsize=7.5,
            ha="center")
    ax.set_yscale("log")
    ax.set_xlabel("distance $d$")
    ax.set_ylabel("encoding rate (%)")
    ax.set_title("(b) no intermediate point from\npartial face-sector removal",
                 fontsize=8.6)
    ax.set_xlim(2.7, 5.1)
    ax.set_ylim(0.5, 160)
    ax.set_xticks([3, 4, 5])

    for a in axes:
        a.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(w_pad=2.2)
    fig.savefig("fig_tradeoff.pdf")
    plt.close(fig)
    print("fig_tradeoff.pdf")


# ══════════════════════════════════════════════════════════════════
# Figure 3 -- the decomposition scales as 2L^3 - 1 plus 3
# ══════════════════════════════════════════════════════════════════
def fig_scaling():
    Ls = np.array([4, 6, 8, 10])
    n = 3 * Ls ** 3
    nw3 = 4 * Ls ** 3
    span = (5 * Ls ** 3) // 2 - 2
    cls = 2 * Ls ** 3 - 1
    k = 2 * Ls ** 3 + 2
    pair = 2 * Ls ** 3 - 4

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.65))

    ax = axes[0]
    ax.plot(Ls, n, "o-", color=C_GRAY, lw=1.5, ms=4, label=r"$n=3L^3$")
    ax.plot(Ls, nw3, "s-", color=C_OCT, lw=1.5, ms=4,
            label=r"faces $=$ claws $=4L^3$")
    ax.plot(Ls, span, "D-", color=C_YZ, lw=1.5, ms=4,
            label=r"span $=\frac{5}{2}L^3-2$")
    ax.plot(Ls, k, "^-", color=C_XZ, lw=1.5, ms=4, label=r"$k=2L^3+2$")
    ax.plot(Ls, cls, "v--", color=C_XY, lw=1.5, ms=4,
            label=r"classes/sector $=2L^3-1$")
    ax.set_yscale("log")
    ax.set_xlabel("lattice size $L$")
    ax.set_ylabel("count")
    ax.set_title("(a) both sectors, exact")
    ax.set_xticks(Ls)
    ax.legend(loc="upper left", handlelength=1.6, fontsize=7)

    ax = axes[1]
    ax.plot(Ls, k, "^-", color=C_XZ, lw=1.6, ms=5,
            label=r"before, $k=2L^3+2$")
    ax.plot(Ls, np.full_like(Ls, 3), "o-", color=C_XY, lw=1.6, ms=5,
            label=r"after, $k=3$")
    for L, kk in zip(Ls, k):
        ax.annotate(f"{kk}", (L, kk), textcoords="offset points",
                    xytext=(0, 7), ha="center", fontsize=7.5, color=C_XZ)
    ax.annotate("3", (Ls[0], 3), textcoords="offset points",
                xytext=(0, 8), ha="center", fontsize=7.5, color=C_XY)
    ax.set_yscale("log")
    ax.set_xlabel("lattice size $L$")
    ax.set_ylabel(r"logical qubits $k$")
    ax.set_title("(b) removing the sector returns $k=3$")
    ax.set_xticks(Ls)
    ax.set_ylim(1.4, 12000)
    ax.legend(loc="lower left", handlelength=1.6, bbox_to_anchor=(0.02, 0.14))

    for a in axes:
        a.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(w_pad=2.2)
    fig.savefig("fig_scaling.pdf")
    plt.close(fig)
    print("fig_scaling.pdf")


if __name__ == "__main__":
    fig_geometry()
    fig_tradeoff()
    fig_scaling()
