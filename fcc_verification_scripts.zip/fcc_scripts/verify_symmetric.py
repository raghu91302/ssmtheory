"""Verification for the symmetric (two-sector) manuscript."""
import sys
from structure import build, rank, reduce_by
from claws import claws

print(f"{'L':>3} {'n':>5} {'V':>5} {'dimZ1':>7} {'B1=Z1-3':>8} "
      f"{'span(F)':>8} {'span(C)':>8} {'2L^3-1':>7} {'pairing':>8}")
print("-" * 70)

for L in [int(x) for x in (sys.argv[1:] or [4, 6, 8, 10])]:
    nodes, edges, ne, vmask, omask, tris = build(L)
    V = len(nodes)
    rZ, pivZ = rank(vmask); rX, pivX = rank(omask)
    cl = claws(nodes, edges)
    rF, _ = rank(tris)
    rC, _ = rank(cl)
    dimZ1 = ne - V + 1                      # cycle space of a connected graph
    B1 = dimZ1 - 3                          # H_1(T^3; F_2) = F_2^3
    print(f"{L:>3} {ne:>5} {V:>5} {dimZ1:>7} {B1:>8} {rF:>8} {rC:>8} "
          f"{2*L**3-1:>7}", end="")

    # ---- homological identity ----
    assert dimZ1 == ne - V + 1
    assert B1 == rF == rC, (B1, rF, rC)
    assert rF - rX == 2*L**3 - 1
    assert rC - rZ == 2*L**3 - 1
    assert dimZ1 == (5*L**3)//2 + 1
    assert B1 == (5*L**3)//2 - 2

    # ---- syndrome ambiguity: s(X_a X_b) = s(X_c) on every face ----
    ok = True
    for t in tris[:400]:
        eids = [ei for ei in range(ne) if (t >> ei) & 1]
        a, b, c = eids
        sab = tuple(bin(m & ((1 << a) | (1 << b))).count('1') % 2
                    for m in vmask)
        sc = tuple(bin(m & (1 << c)).count('1') % 2 for m in vmask)
        if sab != sc: ok = False; break
    assert ok, "syndrome ambiguity failed"

    # dual: s(Z_a Z_b) = s(Z_c) on every claw
    ok = True
    for cw in cl[:400]:
        eids = [ei for ei in range(ne) if (cw >> ei) & 1]
        a, b, c = eids
        sab = tuple(bin(m & ((1 << a) | (1 << b))).count('1') % 2
                    for m in omask)
        sc = tuple(bin(m & (1 << c)).count('1') % 2 for m in omask)
        if sab != sc: ok = False; break
    assert ok, "dual syndrome ambiguity failed"

    # ---- corrected partial-gauging statement ----
    # any generating set whose span omits some face leaves d = 3;
    # any spanning set (however few generators) gives d >= 4
    piv = dict(pivX); chosen = 0
    for t in tris:
        r = reduce_by(t, piv)
        if r:
            piv[r.bit_length() - 1] = r; chosen += 1
        if chosen == 2*L**3 - 1: break
    left = sum(1 for s in tris if reduce_by(s, piv) != 0)
    assert left == 0, f"{left} faces outside span after {chosen} independents"
    # drop one independent direction -> some face survives
    piv2 = dict(pivX); c2 = 0
    for t in tris:
        r = reduce_by(t, piv2)
        if r:
            if c2 == 2*L**3 - 2: break
            piv2[r.bit_length() - 1] = r; c2 += 1
    left2 = sum(1 for s in tris if reduce_by(s, piv2) != 0)
    assert left2 > 0, "expected surviving face at one dimension short"

    # ---- symplectic pairing rank between the two local sectors ----
    rows = []
    for t in tris:
        w = 0
        for j, cw in enumerate(cl):
            if bin(t & cw).count('1') & 1: w |= 1 << j
        rows.append(w)
    rP, _ = rank(rows)
    assert rP == 2*L**3 - 4, (rP, 2*L**3 - 4)
    print(f" {rP:>8}")

print("\nAll symmetric-version identities hold at every size tested.")
print("  dim Z_1 = 5L^3/2 + 1     span(faces) = span(claws) = B_1 = 5L^3/2 - 2")
print("  independent classes per sector = 2L^3 - 1")
print("  cross-sector pairing rank      = 2L^3 - 4")
print("  minimum independent directions to reach d >= 4: 2L^3 - 1")
