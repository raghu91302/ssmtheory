#!/usr/bin/env python3
"""photon_framework_figure.py -- the framework schematic (Figure 1 of the
revised manuscript). Every position is computed from the lattice rules:
FCC nodes at even-sum integer points, octahedral voids at odd-sum integer
points, tetrahedral voids at half-integer points (cubic cell side a = 2).

(a) Z-check: the twelve <110> bonds at one node (the cuboctahedral star).
(b) X-check: the twelve bonds among the six nodes around an octahedral void.
(c) The baryon defect of the matter paper: an extra node at a tetrahedral
    void, bonded to the four nodes of its tetrahedron (one anchor, three
    valence bonds).
(d) The tetrahedral-void sublattice of the migration paper: a simple cubic
    lattice of spacing a/2, two-coloured P/N, with one hop.
"""
import itertools
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.family": "serif", "font.size": 8.5})
NN = [np.array(v) for v in itertools.product([-1, 0, 1], repeat=3)
      if sum(map(abs, v)) == 2]
C_NODE, C_OCT, C_TET = "#2f5d8a", "#c0504d", "#e3a33b"


def setup(ax, title, lim=1.25):
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim)
    ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev=18, azim=-58)
    ax.set_axis_off()
    ax.set_title(title, fontsize=8, pad=-2)


def seg(ax, p, q, **kw):
    ax.plot(*zip(p, q), **kw)


fig = plt.figure(figsize=(7.4, 2.4))

# (a) Z-check at a node
ax = fig.add_subplot(1, 4, 1, projection="3d")
setup(ax, "(a) $Z$-check:\n12 bonds at a node")
o = np.zeros(3)
shell = NN
for p in shell:
    for q in shell:
        if tuple(p) < tuple(q) and np.isclose(np.linalg.norm(p - q), np.sqrt(2)):
            seg(ax, p, q, color="0.8", lw=0.5)
for p in shell:
    seg(ax, o, p, color=C_NODE, lw=1.3)
ax.scatter(*np.array(shell).T, s=10, color=C_NODE, depthshade=False)
ax.scatter(*o, s=40, color="k", depthshade=False)

# (b) X-check on an octahedral void
ax = fig.add_subplot(1, 4, 2, projection="3d")
setup(ax, "(b) $X$-check:\n12 bonds of an octahedron")
c = np.array([1, 0, 0]); verts = [c + s * e for e in np.eye(3, dtype=int) for s in (1, -1)]
for p, q in itertools.combinations(verts, 2):
    if np.isclose(np.linalg.norm(p - q), np.sqrt(2)):
        seg(ax, p - c, q - c, color=C_NODE, lw=1.3)
ax.scatter(*(np.array(verts) - c).T, s=14, color=C_NODE, depthshade=False)
ax.scatter(0, 0, 0, s=40, marker="s", color=C_OCT, depthshade=False)

# (c) trapped node in a tetrahedral void
ax = fig.add_subplot(1, 4, 3, projection="3d")
setup(ax, "(c) baryon defect:\nnode in a tetrahedral void", lim=0.95)
T = [np.array(v) for v in [(0, 0, 0), (1, 1, 0), (1, 0, 1), (0, 1, 1)]]
ctr = np.mean(T, axis=0)
for p, q in itertools.combinations(T, 2):
    seg(ax, p - ctr, q - ctr, color="0.55", lw=0.9)
for i, p in enumerate(T):
    seg(ax, np.zeros(3), p - ctr, color="#7a1f1f" if i == 0 else C_TET,
        lw=2.0 if i == 0 else 1.5)
ax.scatter(*(np.array(T) - ctr).T, s=16, color=C_NODE, depthshade=False)
ax.scatter(0, 0, 0, s=55, marker="*", color=C_TET, edgecolor="k",
           lw=0.4, depthshade=False)
ax.text2D(0.05, 0.02, "dark: anchor bond\nlight: three valence bonds",
          transform=ax.transAxes, fontsize=6.5)

# (d) tetrahedral-void sublattice, P/N checkerboard, one hop
ax = fig.add_subplot(1, 4, 4, projection="3d")
setup(ax, "(d) tetrahedral-void\nsublattice and one hop", lim=1.1)
pts = [np.array(p) * 0.5 for p in itertools.product((-1, 1), repeat=3)]
for p, q in itertools.combinations(pts, 2):
    if np.isclose(np.linalg.norm(p - q), 1.0):
        seg(ax, p, q, color="0.75", lw=0.6)
for p in pts:
    s = int(round(sum(2 * p))) % 4   # sums of odd numbers: 3 -> P, 1 -> N
    col = C_OCT if s in (3, -1) else C_NODE
    ax.scatter(*p, s=26, marker="^" if col == C_OCT else "v", color=col,
               depthshade=False)
a, b = pts[0], pts[0] + np.array([1.0, 0, 0])
ax.quiver(*a, *(b - a) * 0.92, color="k", lw=1.2, arrow_length_ratio=0.25)
ax.text2D(0.03, 0.02, "up/down: the two void classes;\nevery hop changes class",
          transform=ax.transAxes, fontsize=6.5)

fig.subplots_adjust(left=0.0, right=1.0, top=0.92, bottom=0.0, wspace=0.0)
fig.savefig("Figure1_framework.pdf", bbox_inches="tight")
fig.savefig("Figure1_framework.png", dpi=160, bbox_inches="tight")
print("wrote Figure1_framework.pdf")
