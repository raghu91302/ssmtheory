Scripts added in revision 1 (Symmetry manuscript symmetry-4576823)

photon_revision_verify.py   All new numbers in the revised manuscript: Hodge splits
                            of the three complexes, Bloch spectra, staggered-weight
                            test, two-path covering, bond-star moments, D4* spectrum,
                            isotropy and quartic coefficient. Prints OK/FAIL per claim
                            (20 checks). Requires numpy.
photon_revision_figure.py   Figure 3 (Figure3_polarizations.pdf), computed from the
                            spectra. Imports photon_revision_verify.py, so keep both in
                            the same folder. Requires numpy, matplotlib.
photon_framework_figure.py  Figure 1 (Figure1_framework.pdf), drawn from the lattice
                            rules. Requires numpy, matplotlib.

Scripts from the original submission (photon_verify_100.py, photon_two_codes.py,
photon_make_figures.py, ...) are unchanged. Note: photon_make_figures.py draws
Figure 2 with the original panel titles; in the revised manuscript those titles
are removed from the graphic and set in the LaTeX source instead.

Usage:  python3 photon_revision_verify.py
        python3 photon_revision_figure.py
        python3 photon_framework_figure.py
