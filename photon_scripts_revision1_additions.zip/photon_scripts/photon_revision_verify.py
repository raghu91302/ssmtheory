#!/usr/bin/env python3
"""photon_revision_verify.py

Verifies every number introduced or changed in the revised manuscript
"Centrosymmetry, bipartiteness, and the photon polarization count on
close-packed lattices" (Symmetry, revision 1). Requires numpy only.

Units: the cubic grid of FCC nodes and octahedral voids has spacing 1
(= a/2). FCC nodes are the even-sum integer points, octahedral voids the
odd-sum points, tetrahedral voids the half-integer points.

Sections
  A  Hodge split on three complexes (finite tori, L = 4, 6)
  B  Gaussian (harmonic) Maxwell spectra by Bloch analysis
  C  Staggered couplings do not gap the photon
  D  Two-path covering of every <110> edge
  E  Rank-three and rank-four moments of the bond stars
  F  D4*: polarization count, isotropy, quartic coefficient
"""
import itertools
import numpy as np

np.set_printoptions(precision=4, suppress=True)
rank = lambda M: int(np.linalg.matrix_rank(M)) if M.size else 0
OK = []


def check(label, cond):
    OK.append(bool(cond))
    print(f"  [{'OK' if cond else 'FAIL'}] {label}")


# ----------------------------------------------------------------- helpers
def complex_on_torus(L, sites, steps, faces):
    """Build d1 (links x sites) and d2 (faces x links) on a periodic torus.

    sites : list of integer 3-tuples (already reduced mod L)
    steps : list of link vectors; a link is (s, s+v) for each site s
    faces : function(site) -> list of closed vertex loops (lists of points)
    """
    sidx = {s: i for i, s in enumerate(sites)}
    red = lambda p: tuple(int(x) % L for x in p)
    links = {}
    for s in sites:
        for v in steps:
            t = red(np.add(s, v))
            if t in sidx:
                key = (s, t) if (s, t) not in links and (t, s) not in links else None
                if key:
                    links[key] = len(links)
    d1 = np.zeros((len(links), len(sites)))
    for (s, t), k in links.items():
        d1[k, sidx[s]] -= 1
        d1[k, sidx[t]] += 1

    def lk(a, b):
        a, b = red(a), red(b)
        if (a, b) in links:
            return links[(a, b)], 1
        return links[(b, a)], -1

    rows = []
    for s in sites:
        for loop in faces(s):
            r = np.zeros(len(links))
            for p, q in zip(loop, loop[1:] + loop[:1]):
                k, sg = lk(p, q)
                r[k] += sg
            rows.append(r)
    d2 = np.array(rows) if rows else np.zeros((0, len(links)))
    assert np.allclose(d2 @ d1, 0), "d2 d1 != 0"
    return d1, d2


def hodge(d1, d2, nsites):
    r1, r2 = rank(d1), rank(d2)
    n = d1.shape[0]
    return r1 / nsites, r2 / nsites, n - r1 - r2


E3 = [np.array(e) for e in np.eye(3, dtype=int)]
NN = [np.array(v) for v in itertools.product([-1, 0, 1], repeat=3)
      if sum(map(abs, v)) == 2]


def cubic(L):
    sites = [p for p in itertools.product(range(L), repeat=3)]
    def faces(s):
        s = np.array(s)
        out = []
        for i, j in ((0, 1), (1, 2), (2, 0)):
            out.append([s, s + E3[i], s + E3[i] + E3[j], s + E3[j]])
        return out
    return sites, complex_on_torus(L, sites, E3, faces)


def fcc_triangle_shapes():
    """The eight triangle shapes per FCC site, translated so that their
    lexicographically smallest vertex is the origin."""
    shapes, seen = [], set()
    for u in NN:
        for w in NN:
            uw = u + w
            if any((uw == x).all() for x in NN):
                pts = [np.zeros(3, int), u, uw]
                o = min(pts, key=tuple)
                key = tuple(sorted(tuple(p - o) for p in pts))
                if key not in seen:
                    seen.add(key)
                    shapes.append([p - o for p in pts])
    return shapes


def fcc_triangles(L):
    sites = [p for p in itertools.product(range(L), repeat=3) if sum(p) % 2 == 0]
    shapes = fcc_triangle_shapes()
    def faces(s):
        return [[np.array(s) + p for p in sh] for sh in shapes]
    return sites, complex_on_torus(L, sites, NN, faces)


def code_complex(L, signs=(1, 1, 1)):
    """FCC with the octahedral X-checks as 2-cells. An octahedron's twelve
    edges are the 1-skeleton of a solid, not the boundary of a disk, so a
    real-coefficient lift needs a sign convention: here the sum of its three
    oriented great squares, each with sign signs[i]."""
    sites = [p for p in itertools.product(range(L), repeat=3) if sum(p) % 2 == 0]
    def faces(s):
        return []
    d1, _ = complex_on_torus(L, sites, NN, faces)
    red = lambda p: tuple(int(x) % L for x in p)
    # rebuild link index consistently
    links = {}
    for s in sites:
        for v in NN:
            t = red(np.add(s, v))
            if (s, t) not in links and (t, s) not in links:
                links[(s, t)] = len(links)
    def lk(a, b):
        a, b = red(a), red(b)
        return (links[(a, b)], 1) if (a, b) in links else (links[(b, a)], -1)
    rows = []
    for o in itertools.product(range(L), repeat=3):
        if sum(o) % 2 == 0:
            continue
        o = np.array(o)
        r = np.zeros(len(links))
        for sg, (i, j) in zip(signs, ((0, 1), (1, 2), (2, 0))):
            cyc = [o + E3[i], o + E3[j], o - E3[i], o - E3[j]]
            for p, q in zip(cyc, cyc[1:] + cyc[:1]):
                k, s_ = lk(p, q)
                r[k] += sg * s_
        rows.append(r)
    d2 = np.array(rows)
    assert np.allclose(d2 @ d1, 0)
    return sites, (d1, d2)


print("A. Hodge split per site (exact, coexact) and harmonic count")
for L in (4, 6):
    for name, fn in (("cubic <100>, squares", cubic),
                     ("FCC <110>, triangles", fcc_triangles),
                     ("FCC <110>, octahedra (code complex)", code_complex)):
        sites, (d1, d2) = fn(L)
        ex, co, h = hodge(d1, d2, len(sites))
        print(f"  L={L} {name:38s} links/site={d1.shape[0]/len(sites):.0f}"
              f"  exact={ex:.3f} coexact={co:.3f} harmonic={h}")
        if "triangles" in name:
            check(f"FCC triangles L={L}: harmonic = 3", h == 3)
        if "cubic" in name:
            check(f"cubic L={L}: harmonic = 3", h == 3)
        if "octahedra" in name:
            # any sign convention: rank d2 <= number of octahedra = number of nodes
            for sg in itertools.product((1, -1), repeat=3):
                _, (_, d2s) = code_complex(L, sg)
                assert rank(d2s) <= len(sites)
            check(f"code complex L={L}: coexact <= 1 per node for all 8 sign conventions", True)


# ----------------------------------------------------------------- Bloch
def bloch_d2(cells_faces, link_vecs, q):
    """cells_faces: list of faces, each a list of points (origin cell);
    link_vecs: representative link vectors (one per class) -> Bloch d2(q)."""
    M = np.zeros((len(cells_faces), len(link_vecs)), complex)
    for r, loop in enumerate(cells_faces):
        for p, s in zip(loop, loop[1:] + loop[:1]):
            v = np.asarray(s, float) - np.asarray(p, float)
            for i, b in enumerate(link_vecs):
                if np.allclose(v, b):
                    M[r, i] += np.exp(1j * q @ np.asarray(p, float))
                    break
                if np.allclose(v, -b):
                    M[r, i] -= np.exp(1j * q @ np.asarray(s, float))
                    break
            else:
                raise ValueError("not a link")
    return M


def spectrum(faces, links, q):
    D = bloch_d2(faces, links, q)
    return np.linalg.eigvalsh(D.conj().T @ D)


Z = np.zeros(3)
cub_links = [e.astype(float) for e in E3]
cub_faces = [[Z, E3[i], E3[i] + E3[j], E3[j]] for i, j in ((0, 1), (1, 2), (2, 0))]

fcc_links = [v.astype(float) for v in NN if tuple(v) > tuple(-v)]
fcc_tris = fcc_triangle_shapes()

o0 = np.array([1, 0, 0])
oct_loops = []
for i, j in ((0, 1), (1, 2), (2, 0)):
    oct_loops.append([o0 + E3[i], o0 + E3[j], o0 - E3[i], o0 - E3[j]])


def code_spectrum(q):
    D = sum(bloch_d2([lp], fcc_links, q) for lp in oct_loops)  # one 2-cell
    return np.linalg.eigvalsh(D.conj().T @ D)


print("\nB. Gaussian Maxwell spectra, eigenvalues of d2^dag d2 at small q")
dirs = {"[100]": [1, 0, 0], "[110]": [1, 1, 0], "[111]": [1, 1, 1]}
for qa in (1e-2,):
    for dn, d in dirs.items():
        q = qa * np.array(d, float) / np.linalg.norm(d)
        c = spectrum(cub_faces, cub_links, q)
        f = spectrum(fcc_tris, fcc_links, q)
        k = code_spectrum(q)
        print(f"  {dn}  cubic /q^2: {c/qa**2}")
        print(f"         FCC-tri small/q^2: {f[:3]/qa**2}  gapped: {f[3:]}")
        print(f"         code complex: {k}")
q = 1e-2 * np.array([1, 0, 0.])
f = spectrum(fcc_tris, fcc_links, q)
check("FCC triangles: 1 gauge + 2 gapless (omega^2 = q^2/2) + 3 gapped at 8",
      np.allclose(f[1:3] / 1e-4, 0.5, atol=1e-3) and np.allclose(f[3:], 8, atol=1e-2))
c = spectrum(cub_faces, cub_links, q)
check("cubic: 1 gauge + 2 gapless (omega^2 = q^2)",
      abs(c[0]) < 1e-12 and np.allclose(c[1:] / 1e-4, 1, atol=1e-3))
# code complex: one nonzero branch; its small-q scaling
vals = []
for qa in (2e-2, 1e-2):
    vals.append(max(code_spectrum(qa * np.array([1, 2, 3.]) / np.sqrt(14))))
expo = np.log(vals[0] / vals[1]) / np.log(2)
zeros_bz = [np.sum(code_spectrum(np.random.default_rng(i).uniform(-np.pi, np.pi, 3)) < 1e-10)
            for i in range(20)]
print(f"  code complex: one dispersive branch, scaling exponent {expo:.2f};"
      f" zero eigenvalues at random BZ points: {set(zeros_bz)}")
check("code complex: 5 zero branches throughout the zone (1 gauge + 4 flat)",
      set(zeros_bz) == {5})

# isotropy of the FCC-triangle photon at qa = 0.1
sp = []
for d in dirs.values():
    qq = 0.1 * np.array(d, float) / np.linalg.norm(d)
    sp.append(spectrum(fcc_tris, fcc_links, qq)[1:3].mean() / 0.01)
print(f"  FCC-triangle photon omega^2/q^2 at qa=0.1 along [100],[110],[111]: {np.array(sp)}")

# ----------------------------------------------------------------- C
print("\nC. Staggered plaquette weights on the cubic sublattice")


def stagger_test(L, eps):
    sites, (d1, d2) = cubic(L)
    rng = np.random.default_rng(1)
    # plaquette weights: 1 +/- eps by parity of the plaquette's base site
    pw = []
    for s in sites:
        for _ in range(3):
            pw.append(1 + eps * (-1) ** sum(s))
    W = np.diag(pw)
    K = d2.T @ W @ d2
    ev = np.sort(np.linalg.eigvalsh(K))
    n_gauge = rank(d1)
    nz = ev[ev > 1e-9]
    zero = len(ev) - len(nz)
    return zero - n_gauge, nz[0]


for eps in (0.0, 0.1, 0.3):
    out = []
    for L in (6, 10):
        h, lam = stagger_test(L, eps)
        out.append((L, h, lam, lam / (2 * np.sin(np.pi / L)) ** 2))
    print("  eps=%.1f  " % eps + "  ".join(
        f"L={L}: harmonic zeros={h}, lowest nonzero={lam:.4f}, /(2sin(pi/L))^2={r:.3f}"
        for L, h, lam, r in out))
    check(f"eps={eps}: lowest nonzero eigenvalue scales as (2 sin(pi/L))^2 (no gap)",
          abs(out[0][3] - out[1][3]) < 0.15 and out[0][1] == 3 and out[1][1] == 3)

# ----------------------------------------------------------------- D
print("\nD. Two-path covering of every <110> edge through an octahedral void")
total = 0
for L in (4, 6):
    sites, (d1, _) = fcc_triangles(L)
    n_edges = d1.shape[0]
    ok = 0
    for v in NN:
        if tuple(v) < tuple(-v):
            continue
        for s in sites:
            ax = [i for i in range(3) if v[i] != 0]
            mids = [np.array(s) + v[i] * E3[i] for i in ax]
            if len(mids) == 2 and all(sum(m) % 2 == 1 for m in mids):
                ok += 1
    total += n_edges
    print(f"  L={L}: {n_edges} edges, {ok} covered by exactly two paths through odd sites")
    check(f"L={L}: all edges covered", ok == n_edges)

# ----------------------------------------------------------------- E
print("\nE. Moments of the bond stars")


def moments(V):
    V = np.array([v / np.linalg.norm(v) for v in V], float)
    r3 = np.einsum("ni,nj,nk->ijk", V, V, V)
    r4 = np.einsum("ni,nj,nk,nl->ijkl", V, V, V, V)
    return np.abs(r3).max(), r4[0, 0, 0, 0], r4[0, 0, 1, 1]


stars = {
    "<100> (6)": [s * e for e in E3 for s in (1, -1)],
    "<110> (12)": NN,
    "<111> one void class (4)": [np.array(v) for v in itertools.product([-1, 1], repeat=3) if np.prod(v) == 1],
    "<111> both void classes (8)": [np.array(v) for v in itertools.product([-1, 1], repeat=3)],
}
for k, V in stars.items():
    m3, t1, t2 = moments(V)
    print(f"  {k:30s} max|rank-3| = {m3:.3f}   T_xxxx = {t1:.3f}, T_xxyy = {t2:.3f}")
check("<111> diamond rank-3 = 4/(3 sqrt 3)", abs(moments(stars["<111> one void class (4)"])[0] - 4 / (3 * np.sqrt(3))) < 1e-12)
check("<111> fluorite (both classes) rank-3 = 0", moments(stars["<111> both void classes (8)"])[0] < 1e-12)

# ----------------------------------------------------------------- F
print("\nF. D4*: polarization count, isotropy, quartic coefficient")
V4 = [np.array(v, float) for v in itertools.product([-1, 0, 1], repeat=4) if sum(map(abs, v)) == 1]
V4 += [np.array(v) / 2 for v in itertools.product([-1, 1], repeat=4)]
L4 = []
for v in V4:
    if not any(np.allclose(v, -b) for b in L4):
        L4.append(v)
tri4, seen = [], set()
for u in V4:
    for w in V4:
        s = u + w
        if any(np.allclose(s, x) for x in V4):
            pts = [np.zeros(4), u, s]
            o = min(pts, key=lambda p: tuple(np.round(p, 6)))
            key = tuple(sorted(tuple(np.round(p - o, 6)) for p in pts))
            if key not in seen:
                seen.add(key)
                tri4.append([p - o for p in pts])
print(f"  minimal vectors {len(V4)}, link classes {len(L4)}, triangles per site {len(tri4)}")
check("D4*: 24 minimal vectors, 12 links/site, 32 triangles/site", (len(V4), len(L4), len(tri4)) == (24, 12, 32))
rng = np.random.default_rng(0)
qa = 1e-2
n = rng.normal(size=4); n /= np.linalg.norm(n)
ev = spectrum(tri4, L4, qa * n)
print(f"  small-q spectrum: gauge {ev[0]:.1e}, gapless/q^2 {ev[1:4]/qa**2}, gapped {ev[4:]}")
check("D4*: 1 gauge + 3 gapless at q^2/3 + 8 gapped at 12",
      np.allclose(ev[1:4] / qa**2, 1 / 3, atol=1e-4) and np.allclose(ev[4:], 12, atol=1e-2))

# quartic moment of the star over random directions
Q = []
for _ in range(400):
    n = rng.normal(size=4); n /= np.linalg.norm(n)
    Q.append(sum((n @ v) ** 4 for v in V4))
Qh = []
H4 = [s * e for e in np.eye(4) for s in (1, -1)]
for _ in range(400):
    n = rng.normal(size=4); n /= np.linalg.norm(n)
    Qh.append(sum((n @ v) ** 4 for v in H4))
print(f"  quartic moment: D4* {min(Q):.6f}-{max(Q):.6f};  hypercubic {min(Qh):.3f}-{max(Qh):.3f} (exact range 0.5-2)")
check("D4* quartic moment = 3 in every direction", np.ptp(Q) < 1e-12)

# directional spread of the photon branch and quartic coefficient
hyp_links = [e for e in np.eye(4)]
hyp_faces = [[np.zeros(4), np.eye(4)[i], np.eye(4)[i] + np.eye(4)[j], np.eye(4)[j]]
             for i in range(4) for j in range(i + 1, 4)]


def photon_branch(faces, links, q, ngap):
    ev = spectrum(faces, links, q)
    return ev[1:4].mean()


for qa in (0.1, 0.05):
    rd, rh = [], []
    for _ in range(100):
        n = rng.normal(size=4); n /= np.linalg.norm(n)
        rd.append(photon_branch(tri4, L4, qa * n, 8) / (qa**2 / 3))
        rh.append(photon_branch(hyp_faces, hyp_links, qa * n, 0) / qa**2)
    print(f"  qa={qa}: directional spread of omega^2/(leading)  D4* {np.ptp(rd):.2e}   Z^4 {np.ptp(rh):.2e}")

coef = []
for _ in range(50):
    n = rng.normal(size=4); n /= np.linalg.norm(n)
    vals = []
    for qa in (0.04, 0.02):
        lam = photon_branch(tri4, L4, qa * n, 8)
        vals.append((lam / (qa**2 / 3) - 1) / qa**2)
    coef.append(2 * vals[1] - vals[0])  # Richardson to remove O(q^4)
coef = np.array(coef)
print(f"  quartic coefficient c in lambda = (q^2/3)(1 - c q^2): mean {-coef.mean():.6f}"
      f" (1/72 = {1/72:.6f}), spread {np.ptp(coef):.1e}")
check("D4* quartic coefficient = 1/72, direction independent",
      abs(-coef.mean() - 1 / 72) < 1e-4 and np.ptp(coef) < 1e-4)

print(f"\n{sum(OK)}/{len(OK)} checks passed")
