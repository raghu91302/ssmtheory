#!/usr/bin/env python3
"""photon_revision_figure.py -- revised Figure 2.

(a) One-form degrees of freedom per site on four complexes, computed from
    the Gaussian spectra (no hand-entered numbers).
(b) Gaussian Maxwell spectra omega^2(q) along [100] for the three
    three-dimensional complexes.
Imports the lattice constructions from photon_revision_verify.py.
"""
import contextlib, io
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

with contextlib.redirect_stdout(io.StringIO()):
    import photon_revision_verify as V

plt.rcParams.update({"font.family": "serif", "font.size": 8.5,
                     "axes.linewidth": 0.6})


def classify(spec_fn, q_small=1e-3, n=None):
    """gauge / gapless transverse / gapped / flat-zero counts at small q."""
    ev = spec_fn(q_small * np.array([0.267, 0.534, 0.802]))
    ev2 = spec_fn(2 * q_small * np.array([0.267, 0.534, 0.802]))
    zero = int(np.sum(np.abs(ev) < 1e-12) - 1)          # minus the gauge mode
    gapless = int(np.sum((ev > 1e-12) & (ev < 1e-3)))
    gapped = int(np.sum(ev >= 1e-3))
    return 1, gapless, gapped, zero


rows = [
    ("Maxwell (continuum)", (1, 2, 0, 0)),
    (r"$\langle100\rangle$ cubic, square plaquettes",
     classify(lambda q: V.spectrum(V.cub_faces, V.cub_links, q))),
    (r"$\langle110\rangle$ FCC, triangular plaquettes",
     classify(lambda q: V.spectrum(V.fcc_tris, V.fcc_links, q))),
    (r"$\langle110\rangle$ FCC, octahedral checks (code)",
     classify(V.code_spectrum)),
]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 2.5),
                               gridspec_kw={"width_ratios": [1.25, 1]})
cols = {"gauge": "#b0b0b0", "gapless": "#2f6b9a", "gapped": "#e3a33b",
        "flat": "#c0504d"}
for y, (name, (g, gl, gp, fz)) in enumerate(rows[::-1]):
    x = 0
    for val, key, hatch in ((g, "gauge", "///"), (gl, "gapless", ""),
                            (gp, "gapped", ""), (fz, "flat", "...")):
        if val:
            ax1.barh(y, val, left=x, color=cols[key], hatch=hatch,
                     edgecolor="white", lw=0.5, height=0.62)
            x += val
    ax1.text(x + 0.1, y, f"{g+gl+gp+fz}", va="center", fontsize=7.5)
ax1.set_yticks(range(len(rows)))
ax1.set_yticklabels([r[0] for r in rows[::-1]])
ax1.set_xlim(0, 6.8)
ax1.set_xlabel("one-form degrees of freedom per site")
for s in ("top", "right"):
    ax1.spines[s].set_visible(False)
from matplotlib.patches import Patch
ax1.legend(handles=[Patch(fc=cols["gauge"], hatch="///", label="pure gauge"),
                    Patch(fc=cols["gapless"], label="gapless transverse"),
                    Patch(fc=cols["gapped"], label="gapped (optical)"),
                    Patch(fc=cols["flat"], hatch="...", label="flat, zero frequency")],
           loc="upper center", bbox_to_anchor=(0.45, 1.27), ncol=2,
           frameon=False, fontsize=7)
ax1.set_title("(a)", loc="left", fontsize=9, pad=24)

qs = np.linspace(1e-4, np.pi, 160)
e = np.array([1.0, 0, 0])
cub = np.array([V.spectrum(V.cub_faces, V.cub_links, q * e) for q in qs])
fcc = np.array([V.spectrum(V.fcc_tris, V.fcc_links, q * e) for q in qs])
cod = np.array([V.code_spectrum(q * e) for q in qs])
for k in (1, 2):
    ax2.plot(qs, cub[:, k], color="#2f6b9a", lw=1.4,
             label=r"$\langle100\rangle$ cubic" if k == 1 else None)
for k in range(1, 6):
    ax2.plot(qs, fcc[:, k], color="#e3a33b", lw=1.1, ls="-" if k < 3 else "--",
             label=r"$\langle110\rangle$ triangles" if k == 1 else None)
ax2.plot(qs, cod[:, 5], color="#c0504d", lw=1.1,
         label=r"$\langle110\rangle$ code complex")
ax2.plot(qs, cod[:, 1], color="#c0504d", lw=2.2, ls=":",
         label="code complex, 4 flat bands")
ax2.set_xlim(0, np.pi)
ax2.set_xlabel(r"$q$ along [100] (units of $2/a$)")
ax2.set_ylabel(r"$\omega^2$ (Gaussian limit)")
ax2.legend(frameon=False, fontsize=6.5, loc="upper left")
for s in ("top", "right"):
    ax2.spines[s].set_visible(False)
ax2.set_title("(b)", loc="left", fontsize=9)
fig.tight_layout()
fig.savefig("Figure3_polarizations.pdf", bbox_inches="tight")
fig.savefig("Figure3_polarizations.png", dpi=150, bbox_inches="tight")
for r in rows:
    print(r)
