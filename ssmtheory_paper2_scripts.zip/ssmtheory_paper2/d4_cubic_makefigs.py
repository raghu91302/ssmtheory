import numpy as np, itertools as it, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams.update({'font.size':11,'font.family':'serif','mathtext.fontset':'cm',
                 'axes.linewidth':0.8,'figure.dpi':150})

# ---- 24 minimal vectors of D4 ----
mins=[]
for i,j in it.combinations(range(4),2):
    for si in(1,-1):
        for sj in(1,-1):
            v=[0,0,0,0]; v[i]=si; v[j]=sj; mins.append(v)
mins=np.array(mins,float)

def aniso(deg,trials=4000,seed=0):
    rng=np.random.default_rng(seed); vals=[]
    for _ in range(trials):
        u=rng.standard_normal(4); u/=np.linalg.norm(u)
        vals.append(np.sum((mins@u)**deg))
    vals=np.array(vals); m=vals.mean()
    return abs(vals.std()/m) if m!=0 else vals.std()

degs=[2,4,6,8,10,12]
spread=[max(aniso(d),1e-17) for d in degs]

# ===== Figure 1: the spherical-design ladder =====
fig,ax=plt.subplots(figsize=(7.0,4.3))
ax.set_yscale('log')
ax.axhspan(1e-18,1e-10,color='#dfeede',alpha=0.7,zorder=0)
ax.axhspan(1e-10,1.0,color='#f6e3e0',alpha=0.7,zorder=0)
ax.plot(degs,spread,'o-',color='#22386b',lw=1.8,ms=8,zorder=5,mfc='white',mew=1.8)
ax.text(2.05,2.5e-13,'isotropic\n(design holds)',fontsize=9.5,color='#2f6d33',va='center')
ax.text(11.8,0.30,'anisotropic\n(design fails)',fontsize=9.5,color='#9b3b30',ha='right',va='center')
# mark the physics
ax.annotate('linear theory (Paper I)\n$\\sim$ degree 4 : EXACT',
            xy=(4,spread[1]),xytext=(4.4,1.2e-8),fontsize=9.5,color='#2f6d33',
            ha='left',va='center',
            arrowprops=dict(arrowstyle='->',color='#2f6d33',lw=1.1))
ax.annotate('cubic vertex (Paper II)\n$\\sim$ degree 6 : ANISOTROPIC',
            xy=(6,spread[2]),xytext=(6.3,2.2e-4),fontsize=9.5,color='#9b3b30',
            ha='left',va='center',
            arrowprops=dict(arrowstyle='->',color='#9b3b30',lw=1.1))
ax.axvline(5,color='0.5',ls='--',lw=0.9)
ax.text(5.08,3e-16,'5-design\nboundary',fontsize=8.5,color='0.35',va='bottom')
ax.set_xlabel('polynomial degree $d$ of the moment $\\sum_{v\\in\\mathcal{V}_{24}}(v\\cdot u)^d$')
ax.set_ylabel('relative anisotropy  $\\mathrm{std}_u/\\mathrm{mean}_u$')
ax.set_title('The spherical-design ladder of the 24-cell',fontsize=12)
ax.set_xticks(degs); ax.set_ylim(1e-17,1.2); ax.set_xlim(1.3,12.7)
ax.grid(True,which='major',axis='y',ls=':',lw=0.5,alpha=0.6)
fig.tight_layout(); fig.savefig('fig1_design_ladder.pdf'); plt.close(fig)
print("fig1 written; design ladder:",[f'{d}:{s:.2e}' for d,s in zip(degs,spread)])

# ===== Figure 2: the cubic-vertex anisotropy (Aut(D4) data) =====
from fractions import Fraction as Fr
au=json.load(open('d4_cubic_vertex_autD4_data.json'))['rows']
b4=json.load(open('d4_cubic_vertex_groupavg_data.json'))['rows']
def perp_int(k):
    for e in np.eye(4,dtype=int):
        w=e*int(k@k)-k*int(e@k)
        if np.any(w): return w
def TT(k):
    a=perp_int(k); b=None
    for e in np.eye(4,dtype=int):
        cand=e*int(k@k)-k*int(e@k); cand=cand*int(a@a)-a*int(a@cand)
        if np.any(cand): b=cand;break
    g=np.gcd.reduce(np.abs(b)) if np.any(b) else 1
    if g:b=b//g
    return np.outer(a,b)+np.outer(b,a)
def O4(k,e):
    K=k;E=e;v=[];tr=lambda A,B:float(np.tensordot(A,B))
    for l in range(3):
        i,j=[m for m in range(3) if m!=l]
        for a in range(3):
            for b in range(3): v.append(tr(E[i],E[j])*float(K[a]@E[l]@K[b]))
    for perm in it.permutations((0,1,2)):
        M=E[perm[0]]@E[perm[1]]@E[perm[2]]
        for a in range(3):
            for b in range(3): v.append(float(K[a]@M@K[b]))
    for perm in [(0,1,2),(0,2,1)]:
        t3=float(np.tensordot(E[perm[0]]@E[perm[1]],E[perm[2]]))
        for a in range(3):
            for b in range(a,3): v.append(t3*float(K[a]@K[b]))
    return v
def fit(rows):
    M=[];y=[]
    for r in rows:
        k=[np.array(r[x]) for x in('k1','k2','k3')]; e=[TT(k[0]),TT(k[1]),TT(k[2])]
        M.append(O4(k,e)); y.append(float(Fr(r['c2_sym_rational'])))
    M=np.array(M);y=np.array(y); c,_,_,_=np.linalg.lstsq(M,y,rcond=None)
    return y,M@c
ya,fa=fit(au); yb,fb=fit(b4)
fra=np.linalg.norm(ya-fa)/np.linalg.norm(ya); frb=np.linalg.norm(yb-fb)/np.linalg.norm(yb)
fig,(ax1,ax2)=plt.subplots(1,2,figsize=(9.4,4.2))
# left: c2_sym vs best O(4) fit
lim=[min(ya.min(),fa.min())-15,max(ya.max(),fa.max())+15]
ax1.plot(lim,lim,'-',color='0.6',lw=1,zorder=1)
ax1.scatter(fa,ya,s=34,color='#22386b',alpha=0.85,edgecolor='white',lw=0.6,zorder=3)
ax1.set_xlim(lim);ax1.set_ylim(lim)
ax1.set_xlabel('best Einstein--Hilbert [$O(4)$] fit'); ax1.set_ylabel('exact $c_2^{\\rm sym}$ (Aut$(D_4)$)')
ax1.set_title('Vertex vs.\\ Einstein--Hilbert',fontsize=11)
ax1.text(0.05,0.92,f'irreducible off-diagonal\nscatter $=$ anisotropy\n({fra*100:.1f}\\%)',
         transform=ax1.transAxes,fontsize=9,va='top',color='#9b3b30')
# right: stability bar
groups=['$B_4$\n(384)','Aut$(D_4)$\n(1152)']; vals=[frb*100,fra*100]
bars=ax2.bar(groups,vals,color=['#7f97c9','#22386b'],width=0.55,zorder=3)
ax2.axhline(7.6,color='#9b3b30',ls='--',lw=1.2,zorder=2)
ax2.text(1.45,7.9,'degree-6 moment\ndefect (7.6\\%)',fontsize=8.5,color='#9b3b30',ha='right')
for bnd,v in zip(bars,vals): ax2.text(bnd.get_x()+bnd.get_width()/2,v+0.25,f'{v:.1f}\\%',ha='center',fontsize=10)
ax2.set_ylabel('fractional anisotropy'); ax2.set_ylim(0,15)
ax2.set_title('Stable under full symmetrization',fontsize=11)
fig.tight_layout(); fig.savefig('fig2_anisotropy.pdf'); plt.close(fig)
print(f"fig2 written; B4 frac={frb:.4f} AutD4 frac={fra:.4f}")
