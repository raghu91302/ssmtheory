# Emergent Gravity from the Intrinsic D4 Lattice II — code and data

Computational pipeline for *"Emergent Gravity from the Intrinsic D4 Lattice II:
A Spherical-Design Obstruction to Einstein Gravity at the Cubic Graviton Vertex"*
(R. Kulkarni, 2026). Part I is archived at https://doi.org/10.5281/zenodo.20144486.

The central result: the subdivision-symmetrized cubic graviton vertex on the D4
lattice, averaged over the full lattice automorphism group Aut(D4) (order 1152),
is not Einstein–Hilbert. It carries an irreducible ~12.7% hypercubic anisotropy
at two-derivative order, forced by the 24-cell being a spherical 5-design but not
a 6-design.

## Scripts

- `d4_cubic_vertex_autD4.py` — exact average of the translation-invariant cubic
  vertex over the full automorphism group Aut(D4) (1152 elements; signed
  permutations + triality, rational kinematics). Primary computation; writes
  `d4_cubic_vertex_autD4_data.json`.
- `d4_cubic_vertex_groupavg.py` — exact average over the signed-permutation
  subgroup B4 (384). Used for the B4 → Aut(D4) stability comparison.
- `d4_cubic_vertex_symmetrized.py` — random-subdivision (Monte Carlo)
  symmetrization. Independent cross-check; converges to the same vertex but
  slowly, and is superseded by the exact group average.
- `d4_cubic_anisotropy_analysis.py` — reconstructs the polarizations, builds the
  complete 9-dimensional O(4) (Einstein–Hilbert) structure basis, runs the exact
  rational rank test (9 → 10), quantifies the fractional anisotropy, splits it
  into off-shell and irreducible on-shell parts, and computes the spherical-design
  ladder of the 24-cell.
- `d4_cubic_makefigs.py` — generates Figures 1 (design ladder) and 2 (anisotropy
  and B4/Aut(D4) stability).

## Data

- `d4_cubic_vertex_autD4_data.json` — exact Aut(D4)-averaged vertex for 40
  kinematic configurations (c2 as exact rationals; nine Lorentz invariants per
  configuration; self-check block).

## Reproduce

```
python3 d4_cubic_anisotropy_analysis.py   # rank test, anisotropy, design ladder
python3 d4_cubic_makefigs.py              # figures
```

The vertex runs (`d4_cubic_vertex_autD4.py`, etc.) are heavy and parallelized in
production; tunables (precision, group, configuration count) are at the top of
each file.

## Requirements

Python 3 with numpy, scipy, mpmath, matplotlib. No network access required.
