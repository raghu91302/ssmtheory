"""
SSM dynamics paper -- Sec. 3
Three-sheet convergence: K goes 6->12 directly (no foam) when sheets arrive together -- contrast to the two-sheet stage.
See README.md for the full script-to-section map.
"""
import numpy as np
from scipy.spatial import cKDTree

L=1.0; Rb=1.05
a1=np.array([1.0,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0])
def sheet(z, offset):
    pts=[]
    for i in range(-4,5):
        for j in range(-4,5):
            p=i*a1+j*a2+offset
            p=p.copy(); p[2]=z
            pts.append(p)
    return np.array(pts)

# FCC ABC offsets (in-plane): A=0, B=centroid of up-triangle, C=centroid of down-triangle
offB=(a1+a2)/3.0
offC=2*(a1+a2)/3.0
hfcc=np.sqrt(2/3)  # ideal interlayer spacing

print("Bringing B and C sheets from far -> FCC spacing. Tracking central node coordination.")
print(" sep/h_fcc   K_central   local_geometry")
mid=np.array([0.0,0.0,0.0])  # central node of bottom (A) sheet at origin
for frac in [3.0,2.0,1.5,1.2,1.05,1.0]:
    z=hfcc*frac
    A=sheet(0.0,np.zeros(3))
    B=sheet(z,offB)
    Bd=sheet(-z,offB)   # symmetric below too (A is middle layer)
    allpts=np.vstack([A,B,Bd])
    tree=cKDTree(allpts)
    # central node = the A-sheet node nearest origin
    ci=np.argmin(np.linalg.norm(A-mid,axis=1))
    c=A[ci]
    d=np.linalg.norm(allpts-c,axis=1)
    nbr=allpts[(d>0.1)&(d<=Rb)]
    K=len(nbr)
    # classify: 6=flat sheet; 12=fcc; 4 with tetra angles=foam
    geom=""
    if K==6: geom="flat K=6 sheet (in-plane only)"
    elif K==12: geom="FCC K=12 (close-packed)"
    elif K<=5:
        # check tetra angles
        geom="K=%d (partial)"%K
    else: geom="K=%d (intermediate)"%K
    print("  %.2f        %2d         %s"%(frac,K,geom))

print("""
Interpretation:
 - If K goes 6 -> (4, tetra) -> 12 : a transient tetrahedral foam forms -> homogeneous deficit.
 - If K goes 6 -> 6 -> 12 (jumps to 12 when sheets reach h_fcc, never sits at 4): NO foam stage;
   flat sheets stack directly to FCC; deficit only at seeds.
""")

# More careful: when the third sheet arrives at EXACTLY h_fcc, is the coordination 12 directly,
# and at intermediate separations is the central node ever 4-coordinated with tetra geometry?
print("Fine scan of central-node K vs separation (does it ever sit at K=4 tetra?):")
for frac in np.linspace(0.95,2.5,16):
    z=hfcc*frac
    allpts=np.vstack([sheet(0,np.zeros(3)),sheet(z,offB),sheet(-z,offB)])
    tree=cKDTree(allpts); ci=np.argmin(np.linalg.norm(sheet(0,np.zeros(3))-mid,axis=1))
    c=sheet(0,np.zeros(3))[ci]; d=np.linalg.norm(allpts-c,axis=1)
    K=int(((d>0.1)&(d<=Rb)).sum())
    print("   sep=%.2f h_fcc : K=%d"%(frac,K))
