"""
SSM dynamics paper -- Sec. 3 / Sec. 14 (code selection of the regular registration)
Comparative CSS-stabilizer metrics for three second-sheet registrations (regular FCC, eclipsed AA,
relaxed irregular). Shows only the regular registration forms tetrahedral cells and maximizes the
satisfiable Z-stabilizers (faced fraction 0.73 vs 0.00) -> the code selects it (Table tab:codeselect).
Stabilizer-satisfiability proxy, not a full code-distance calculation.
See README.md for the full script-to-section map.
"""
import numpy as np, itertools, networkx as nx
from scipy.spatial import cKDTree
L=1.0; Rb=1.05; h=np.sqrt(2/3)
a1=np.array([1.0,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0])

def first_sheet(rng=2):
    return [ (i*a1+j*a2).astype(float) for i in range(-rng,rng+1) for j in range(-rng,rng+1)]

def second_sheet(kind, rng=2):
    """Different registrations of the 2nd sheet onto the 1st."""
    pts=[]
    if kind=="regular_fcc":      # B-site close packing: over up-triangle centroids, height h
        off=(a1+a2)/3.0; z=h
        for i in range(-rng,rng+1):
            for j in range(-rng,rng+1):
                pts.append((i*a1+j*a2+off).astype(float)+np.array([0,0,z]))
    elif kind=="eclipsed":       # AA stacking: directly above (wrong, no tetra), height 1
        z=1.0
        for i in range(-rng,rng+1):
            for j in range(-rng,rng+1):
                pts.append((i*a1+j*a2).astype(float)+np.array([0,0,z]))
    elif kind=="relaxed":        # irregular: B-site but jittered height + lateral (relaxed angles)
        rngd=np.random.default_rng(0); off=(a1+a2)/3.0
        for i in range(-rng,rng+1):
            for j in range(-rng,rng+1):
                jit=rngd.normal(0,0.10,3); jit[2]=abs(jit[2])
                pts.append((i*a1+j*a2+off).astype(float)+np.array([0,0,0.85])+jit)
    return pts

def build_graph(P):
    P=np.array(P); T=cKDTree(P); G=nx.Graph()
    for i in range(len(P)): G.add_node(i,pos=P[i])
    for i,j in T.query_pairs(Rb): 
        if np.linalg.norm(P[i]-P[j])>0.1: G.add_edge(i,j)
    return G,P

def code_metrics(G,P):
    # CSS on a graph: X-stabilizers = vertices (star), Z-stabilizers = independent cycles (plaquettes).
    # Frustration proxy: triangles that are NOT faces of a consistent tetrahedral tiling create
    # conflicting plaquette constraints. We measure:
    #  - n_tri: triangles (3-cycles) ; n_tetra: tetrahedra (4-cliques)
    #  - closed_frac: fraction of triangles that belong to >=1 tetra (i.e. are faces, satisfiable)
    #  - cycle_rank (Z-stabilizer count) = E - V + C
    V=G.number_of_nodes(); E=G.number_of_edges(); C=nx.number_connected_components(G)
    cyc=E-V+C
    tris=[c for c in nx.enumerate_all_cliques(G) if len(c)==3]
    tets=[c for c in nx.enumerate_all_cliques(G) if len(c)==4]
    # a triangle is 'satisfiable' (a genuine tetra face) if it is a face of some 4-clique
    tetset=[set(t) for t in tets]
    faced=0
    for tr in tris:
        s=set(tr)
        if any(s<=tt for tt in tetset): faced+=1
    # regularity: std of edge lengths (0 = perfectly regular)
    edges=[np.linalg.norm(P[i]-P[j]) for i,j in G.edges()]
    return dict(V=V,E=E,cycles=cyc,tris=len(tris),tetra=len(tets),
                faced_frac=faced/max(len(tris),1),
                edge_std=np.std(edges), edge_mean=np.mean(edges))

print("Comparative code metrics for three second-sheet registrations:\n")
S1=first_sheet()
rows=[]
for kind in ["regular_fcc","eclipsed","relaxed"]:
    P=S1+second_sheet(kind)
    G,Pa=build_graph(P)
    m=code_metrics(G,Pa)
    rows.append((kind,m))
    print("%-12s: V=%d E=%d  Z-stab(cycles)=%d  triangles=%d  tetra=%d  faced=%.2f  edge_std=%.3f"%(
        kind,m['V'],m['E'],m['cycles'],m['tris'],m['tetra'],m['faced_frac'],m['edge_std']))

print("""
READING:
 faced_frac = fraction of triangles that are genuine tetra faces = fraction of Z-stabilizers that
 can be consistently satisfied (low frustration). edge_std = irregularity (0 = regular).
 If regular_fcc has the HIGHEST faced_frac and LOWEST edge_std AND the most tetrahedra, then the
 code (max satisfiable stabilizers) genuinely SELECTS the regular registration -> claim shown.
""")
# explicit verdict
best=max(rows,key=lambda r:(r[1]['faced_frac'],r[1]['tetra'],-r[1]['edge_std']))
print("configuration maximizing satisfiable stabilizers / tetra / regularity:",best[0])
