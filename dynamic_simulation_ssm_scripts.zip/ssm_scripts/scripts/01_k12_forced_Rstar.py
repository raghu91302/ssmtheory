"""
Verify: (1) the exact K=12-forcing exclusion threshold R*, (2) that termination at K=12
is lift-rate-INDEPENDENT for R_ex in (R*,1), (3) the resulting stiffness lower bound,
(4) the Lindemann/scale-separation reading. No tuning: we SCAN lift rate and stiffness.
"""
import numpy as np
from itertools import combinations
from scipy.optimize import minimize
np.random.seed(0)
L=1.0
nn=np.array([[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],[1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
             [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]],float)/np.sqrt(2)

# (1) exact largest-hole distance (refine)
def negmin(x):
    th,ph=x; p=np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])
    return -min(np.linalg.norm(p-s) for s in nn)
best=0
for _ in range(20000):
    r=minimize(negmin,[np.arccos(1-2*np.random.rand()),2*np.pi*np.random.rand()],
               method='Nelder-Mead',options={'xatol':1e-7,'fatol':1e-7})
    best=max(best,-r.fun)
print("Exact R* (13th-neighbor exclusion threshold) = %.5f L"%best)
print("Closed form check: the largest hole in a cuboctahedron is a SQUARE face;")
print("  square face of cuboctahedron has vertices at mutual 60deg; hole center to vertex:")
# square face center sits at distance: cos = ... compute angular radius of square-face hole
# vertices of one square face:
sq=np.array([[1,1,0],[1,0,1],[1,-1,0],[1,0,-1]],float)/np.sqrt(2)  # the x>0 square
c=sq.mean(0); c/=np.linalg.norm(c)
ang=np.degrees(np.arccos(np.clip(sq@c,-1,1)))
chord=np.linalg.norm(sq[0]-c)
print("  square-face hole: center-to-vertex angle=%.3f deg, chord=%.5f L"%(ang.mean(),chord))

# (2) lift-rate independence of the K=12 terminus, INSIDE the window.
# Minimal demonstration: grow by adding nodes at registered FCC sites with hard exclusion R_ex;
# at each step choose stitch(in-plane) vs lift(new layer) with prob (1-pl, pl). Measure terminal
# bulk modal K. Use an FCC site lattice + exclusion; vary pl over 2 orders of magnitude.
def grow(pl, Rex, N=900):
    # FCC integer lattice sites; grow a cluster by BFS adding sites that satisfy exclusion;
    # lift vs stitch only affects ORDER of addition, not the final occupancy (exclusion does).
    pts=[np.zeros(3)]; occ={(0,0,0)}
    cand=set()
    def addcand(p):
        for d in nn:
            q=tuple(np.round(p+d,6)); 
            if q not in occ: cand.add(q)
    addcand(np.zeros(3))
    while len(pts)<N and cand:
        # lift = pick a candidate that starts a new z-layer; stitch = same-layer; bias by pl
        cl=list(cand)
        zs=np.array([c[2] for c in cl])
        same=[c for c in cl if abs(c[2]-pts[-1][2])<0.3]
        new =[c for c in cl if abs(c[2]-pts[-1][2])>=0.3]
        pool = (new if (np.random.rand()<pl and new) else (same if same else cl))
        q=pool[np.random.randint(len(pool))]
        p=np.array(q)
        if all(np.linalg.norm(p-np.array(o))>=Rex-1e-9 for o in occ):
            occ.add(q); pts.append(p); addcand(p); cand.discard(q)
        else:
            cand.discard(q)
    P=np.array(pts)
    # bulk modal K (>=42 within 2L)
    from collections import Counter
    deg=[]; 
    for i in range(len(P)):
        d=np.linalg.norm(P-P[i],axis=1)
        if np.sum(d<2*L)-1>=42:
            deg.append(int(np.sum((d>0.5)&(d<1.1))))
    return Counter(deg).most_common(1)[0][0] if deg else None

Rex=0.95  # inside window (0.765,1.0)
print("\nK=12 terminus vs lift rate (R_ex=0.95, inside window):")
for pl in [0.002,0.02,0.05,0.2,0.5]:
    ks=[grow(pl,Rex) for _ in range(3)]
    print("  P_lift=%.3f -> bulk modal K = %s"%(pl,ks))

print("\nK=12 terminus vs exclusion (fixed P_lift=0.05):")
for Rex in [0.70,0.78,0.90,0.99,1.02]:
    ks=[grow(0.05,Rex) for _ in range(3)]
    inwin = best<Rex<1.0
    print("  R_ex=%.2f (%s) -> bulk modal K = %s"%(Rex,'in' if inwin else 'OUT',ks))

# (3)-(4) stiffness bound + Lindemann
print("\nStiffness/scale-separation reading:")
print("  R* = %.4f -> need exclusion turning point > R*, i.e. kappa >~ 20 eps/L^2"%best)
print("  Lindemann: solid requires RMS amplitude < ~0.1 L. <x^2>=kT0/K_eff, K_eff=4*kappa,")
for kappa in [2,20,50,100]:
    msd=1.0/(4*kappa)   # kT0=eps=1
    print("   kappa=%3d -> RMS=%.3f L  %s"%(kappa,np.sqrt(msd),'SOLID' if np.sqrt(msd)<0.1 else 'molten/soft'))
