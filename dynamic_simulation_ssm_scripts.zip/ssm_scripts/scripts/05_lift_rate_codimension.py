"""
SSM dynamics paper -- Sec. 10
Codimension/measure analysis of lift (point target) vs stitch (line target).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np

# --- geometry, all in units of bond length L=1, energy eps=1, T0=eps/kB so beta*eps=1 ---
L=1.0
# stitch: new node = equilateral apex on an EDGE; bonds to 2 nodes; in the sheet plane
#   solution manifold of the 2-sphere intersection: a CIRCLE (1-parameter), radius:
#   two unit spheres distance L apart intersect in a circle of radius r2 = sqrt(1 - (L/2)^2)
r_stitch = np.sqrt(1 - (L/2)**2)          # = sqrt(3)/2
# lift: new node above a triangular FACE centroid; bonds to 3 nodes
#   three unit spheres on an equilateral triangle (edge L) intersect in 2 POINTS (0-parameter)
#   apex height h above centroid; centroid-vertex = L/sqrt3
h_lift = np.sqrt(2/3)
n_stitch_bonds = 2
n_lift_bonds   = 3

print("="*70)
print("CONTRIBUTION 1: final-state binding energy (detailed balance, final state)")
print("="*70)
# naive detailed balance on final-state energy: rate ~ exp(+beta * |dE|), dE = -n*eps
# ratio lift/stitch = exp(beta eps (3-2)) = e^{+1}  -> lift would be FAVORED, not suppressed
ratio_final = np.exp(1*(n_lift_bonds - n_stitch_bonds))
print(f"  ratio(lift/stitch) from final-state energy = e^(+1) = {ratio_final:.3f}")
print("  -> WRONG SIGN: more bonds = lower energy = lift favored. So e^-3 is NOT a")
print("     final-state Boltzmann factor. The suppression must be ENTROPIC/kinetic.")

print("\n"+"="*70)
print("CONTRIBUTION 2: solution-manifold measure (the codimension, made quantitative)")
print("="*70)
# A sigma^+ jump must land on the registered apex. The PHASE-SPACE WEIGHT of available
# landing sites differs: stitch's apex lies on a 1-parameter circle of valid unit-distance
# positions (codim 2 in 3D), lift's on a 0-parameter point set (codim 3). The probability
# that a diffusing node finds the apex scales with the measure of the target tube of width w.
# measure(stitch target) ~ (2 pi r_stitch) * w^2   [1D manifold, 2 transverse dims]
# measure(lift target)   ~ 2 * w^3                  [0D manifold, 3 transverse dims, 2 points]
for w in [0.2,0.1,0.05]:
    m_stitch = 2*np.pi*r_stitch * w**2
    m_lift   = 2 * w**3
    print(f"  w={w}:  measure ratio lift/stitch = {m_lift/m_stitch:.4f}")
print("  -> ratio ~ w/(pi*sqrt3). This is w-DEPENDENT: NOT a parameter-free e^-3.")
print("     The codimension gives a SUPPRESSION but its value depends on the capture")
print("     width w (the tolerance). No clean 'e^-3' emerges without fixing w.")

print("\n"+"="*70)
print("CONTRIBUTION 3: does the Regge-deficit tolerance window give w that yields e^-3?")
print("="*70)
# The paper sets the bond tolerance window to +-5% from the Regge deficit delta=0.128 rad.
delta = 2*np.pi - 5*np.arccos(1/3)
w_regge = delta/ (2*np.pi)   # fraction of full turn ~ angular jitter
print(f"  Regge deficit delta = {delta:.4f} rad = {np.degrees(delta):.2f} deg")
print(f"  paper's tolerance ~ +-5% ~ {0.05:.3f};  delta/2pi = {w_regge:.4f}")
for w in [0.05, w_regge]:
    ratio = (2*w**3)/(2*np.pi*r_stitch*w**2)
    print(f"   w={w:.4f}: lift/stitch measure ratio = {ratio:.4f}   (e^-3 = {np.exp(-3):.4f})")
print("  -> Even at the paper's own tolerance, the geometric measure ratio is NOT e^-3.")

print("\n"+"="*70)
print("VERDICT")
print("="*70)
print("""  - Final-state energy gives the WRONG SIGN (lift would be favored).
  - The codimension argument gives a suppression but it is TOLERANCE-DEPENDENT,
    not a parameter-free constant, and does not evaluate to e^-3 at the paper's
    own +-5% window.
  - 'e^-3 = 4.98%' is therefore NOT derived by this dynamics. It is the value the
    published simulation REQUIRES to terminate at K=12 (the paper says as much:
    'the unique exponential amplitude consistent with termination at K=12').
  - CONCLUSION: lift rate is a TUNED INPUT, not a physical constant. If the physics
    does not give 5%, the cascade as simulated is fitted, and any 'complete dynamics'
    claim must either (a) derive the rate, or (b) state plainly that it is imported.""")
