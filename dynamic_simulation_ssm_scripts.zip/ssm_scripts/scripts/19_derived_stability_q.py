"""
DERIVED relative stability (no fitted p*). Bond = Bell pair, entanglement S=ln2; only scale is S,
so temperature T=S and per-bond failure probability is the Boltzmann two-state value
    q = 1/(1+e^{S/T}) = 1/(1+e) ~ 0.2689   (DERIVED, no free parameter).
A node unbinds when it loses rigidity (<3 bonds), i.e. when (K-2) of its K bonds fail:
    P_dissolve(K) = sum_{j=K-2}^{K} C(K,j) q^j (1-q)^{K-j}.
Stability is thus driven by ENTANGLEMENT BINDING (coordination K), which registered packing
maximizes (K->12, near-immortal) and the frustrated foam cannot (K~6). Births coherence-weighted
(frame inheritance) + fecundity, as before. Test: does derived stability let the crystal reach
and HOLD K=12 instead of being capped by an imposed death rate?
"""
import numpy as np, itertools
from math import comb, e
rng=np.random.default_rng(8)
L=1.0; TOL=0.06; DMIN=L-TOL; R2=np.sqrt(2); dt=0.3; SIG=0.12
q=1.0/(1.0+e)                              # DERIVED per-bond failure prob
def Pdiss(K):
    if K<3: return 1.0
    thr=K-2
    return sum(comb(K,j)*q**j*(1-q)**(K-j) for j in range(thr,K+1))
PD=[Pdiss(K) for K in range(0,13)]
print("derived q=%.4f ; P_dissolve(K): "%q + " ".join(f"K{K}={PD[K]:.3f}" for K in (3,4,6,8,10,12)))
CP=np.array([0.5,0.0,-0.5,-1.0]); s=1/np.sqrt(2)
P=np.array([[s,0,0],[-s,0,0],[0,s,0],[0,-s,0],[0,0,s],[0,0,-s]])
def adjacency(P):
    n=len(P); D=np.linalg.norm(P[:,None]-P[None],axis=2); adj=[set() for _ in range(n)]
    I,J=np.where((np.abs(D-L)<TOL)&np.triu(np.ones((n,n),bool),1))
    for a,b in zip(I,J): adj[a].add(b); adj[b].add(a)
    return adj,D
def coherence(cand,nb,P,adj):
    w=1.0
    for j in nb:
        v=cand-P[j]; v/=np.linalg.norm(v); sj=1.0
        for k in adj[j]:
            ek=(P[k]-P[j]); ek/=np.linalg.norm(ek); c=np.dot(v,ek)
            sj=min(sj,np.exp(-np.min((c-CP)**2)/(2*SIG**2)))
        w*=sj
    return w
for cyc in range(60):
    adj,D=adjacency(P)
    deg=np.array([len(a) for a in adj])
    faces=[]; fw=[]
    for i in range(len(P)):
        ai=list(adj[i])
        for x in range(len(ai)):
            for y in range(x+1,len(ai)):
                a,b=ai[x],ai[y]
                if b in adj[a] and i<a<b:
                    faces.append((i,a,b)); fw.append(1.0+deg[i]+deg[a]+deg[b])   # fecundity ~ binding
    if not faces: break
    fw=np.array(fw,float); fw/=fw.sum()
    Plive=list(P)
    for _ in range(3000):
        f=faces[rng.choice(len(faces),p=fw)]; tri=P[list(f)]
        ctr=tri.mean(0); nrm=np.cross(tri[1]-tri[0],tri[2]-tri[0]); nrm/=np.linalg.norm(nrm)
        hh=np.sqrt(max(L**2-((tri[0]-ctr)**2).sum(),0))
        cand=ctr+(1 if rng.random()<0.5 else -1)*hh*nrm
        arr=np.array(Plive); dd=np.linalg.norm(arr-cand,axis=1)
        if dd.min()<DMIN: continue
        nb=list(np.where(np.abs(dd-L)<TOL)[0])
        if len(nb)<2: continue
        if rng.random()<coherence(cand,nb,arr,adj if len(arr)==len(P) else adjacency(arr)[0]):
            Plive.append(cand)
    P=np.array(Plive)
    adj,D=adjacency(P); deg=np.array([len(a) for a in adj])
    keep=rng.random(len(P))>np.array([dt*PD[min(k,12)] for k in deg]); keep[:6]=True   # DERIVED death
    P=P[keep]
    if cyc%10==0 or cyc==59:
        adj,_=adjacency(P); deg=np.array([len(a) for a in adj])
        ctr=P.mean(0); rad=np.linalg.norm(P-ctr,axis=1); core=rad<np.percentile(rad,30)
        print(f"cyc {cyc:2d}: N={len(P):4d} <K>all={deg.mean():5.2f} <K>core={deg[core].mean() if core.any() else 0:5.2f} maxK={deg.max():2d}")
adj,_=adjacency(P); deg=np.array([len(a) for a in adj])
ctr=P.mean(0); rad=np.linalg.norm(P-ctr,axis=1); core=rad<np.percentile(rad,30)
kc=deg[core].mean() if core.any() else 0
print(f"\nfinal core <K>={kc:.2f} -> "+("CLOSE PACKED (K->12), derived stability holds it" if kc>9.5
      else "intermediate K~%.1f"%kc if kc>6.5 else "did not crystallize"))
