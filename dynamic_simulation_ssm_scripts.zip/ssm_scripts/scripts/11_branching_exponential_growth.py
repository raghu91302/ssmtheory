"""
SSM dynamics paper -- Sec. 13 (branching growth)
Moment equations: V(t) ~ exp(Gamma t), Gamma ~ P_lift^(1/3), self-terminating on foam depletion.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
e=np.e; q=1/(1+e); v_lat=1.0; L=1.0; tau0=1.0
v2=(1-2*q)*(np.sqrt(3)/2)*v_lat
h=np.sqrt(2/3)

def run(p, Vfoam=1e12, tmax=20000, dt=0.25):
    sigma=p/(tau0*L**2)
    N=1.0; R=0.0; A=np.pi*(0.5)**2; Vc=A*h   # seed: one small disk r~0.5
    out_t=[]; out_V=[]; out_N=[]
    t=0.0
    while t<tmax:
        foam_frac=max(0.0,1-Vc/Vfoam)
        S=sigma*A*foam_frac
        dN=S
        dR=v2*N
        dA=2*np.pi*v2*R + np.pi*(0.5)**2*S   # growth of existing + birth area of new seeds
        N+=dN*dt; R+=dR*dt; A+=dA*dt
        Vc=min(A*h,Vfoam)
        t+=dt
        if len(out_t)==0 or t-out_t[-1]>=10:
            out_t.append(t); out_V.append(Vc); out_N.append(N)
        if foam_frac<=0: 
            out_t.append(t); out_V.append(Vc); out_N.append(N); break
    return np.array(out_t),np.array(out_V),np.array(out_N)

print("v2 = %.4f v_lat ; h=%.4f L"%(v2,h))
print("\n--- exponential? fit ln Vc vs t in foam-rich window (Vc in [1e2,1e8]) ---")
res={}
for p in [0.05,0.005,0.0005,0.00005]:
    t,V,N=run(p,Vfoam=1e14,tmax=200000,dt=0.5)
    m=(V>1e2)&(V<1e8)
    if m.sum()>5:
        G=np.polyfit(t[m],np.log(V[m]),1)[0]
        res[p]=G
        print(f"  p={p:.5f}: Gamma={G:.5e}/tau0, e-fold={1/G:8.1f} tau0, Gamma/sqrt(p)={G/np.sqrt(p):.4f}")
print("  -> if Gamma/sqrt(p) is ~constant, the inflation rate scales as sqrt(lift rate).")

print("\n--- e-folds and graceful exit (finite foam) ---")
for Vf in [1e6,1e9,1e12]:
    t,V,N=run(0.005,Vfoam=Vf,tmax=200000,dt=0.5)
    efolds=np.log(V[-1]/V[0])
    print(f"  Vfoam={Vf:.0e}: saturates at t={t[-1]:.0f} tau0, total e-folds(volume)={efolds:.1f}, "
          f"final/foam={V[-1]/Vf:.3f}")
print("  -> growth halts exactly when foam consumed; #e-folds = ln(Vfoam/Vseed) (reservoir-set).")

print("\n--- analytic check: V'' ~ V (exponential) ---")
print("  dA/dt=2 pi v2 R, dR/dt=v2 N, dN/dt=sigma A  => d^3A/dt^3 = 2 pi v2^2 sigma A")
G_an=(2*np.pi*v2**2*(0.005/1.0))**(1/3)
print("  characteristic rate (cube-root form) Gamma_an=(2 pi v2^2 sigma)^(1/3) at p=0.005: %.5f/tau0"%G_an)
print("  (third-order because seeding->radius->area is a 3-step chain; still EXPONENTIAL growth)")
