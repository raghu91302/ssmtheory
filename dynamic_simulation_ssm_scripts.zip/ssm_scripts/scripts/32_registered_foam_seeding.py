"""
Test the user's argument: the foam is NOT a free disordered tetrahedral packing. The second sheet
can only seed where lifted apexes project to EQUIDISTANT points (so they can form the next K=6
sheet). That constraint + QEC stabilization SELECTS a registered tetrahedral structure, not an
arbitrary one. Question: does the REGISTERED structure carry the deficit 7.36 deg?

Construction: instead of lifting to arbitrary apexes, build the configuration that the seeding
constraint forces: a first K=6 sheet, lift every up-triangle to its apex, and REQUIRE those apexes
to themselves form a regular K=6 sheet (equidistant). Then measure the Regge deficit around the
edges shared between the original sheet and the apex-sheet -- i.e. the registered two-layer hinge.
"""
import numpy as np, itertools
from scipy.spatial import cKDTree
from collections import defaultdict
L=1.0; Rb=1.05; h=np.sqrt(2/3); LAT=np.sqrt(3)/2
a1=np.array([1.0,0,0]); a2=np.array([0.5,LAT,0])

# First sheet: triangular lattice
S1=[]
for i in range(-4,5):
    for j in range(-4,5):
        S1.append(i*a1+j*a2+np.array([0,0,0.]))
S1=np.array(S1)

# Lift EVERY up-pointing triangle of S1 to its apex. Up-triangles have vertices
# v, v+a1, v+a2. Apex = centroid + h*zhat.
apex=[]
for i in range(-4,4):
    for j in range(-4,4):
        v=i*a1+j*a2
        tri=np.array([v,v+a1,v+a2])
        cen=tri.mean(0)+np.array([0,0,0.])
        apex.append(cen+np.array([0,0,h]))
apex=np.array(apex)

# CHECK the user's premise: do these apexes form a regular (equidistant) triangular sheet?
ta=cKDTree(apex)
dists=[]
for p in apex:
    dd,ii=ta.query(p,k=4)
    dists.extend(dd[1:])
dists=np.array(dists)
print("apex-sheet nearest-neighbor distances: mean=%.4f std=%.4f (regular sheet => all = L=1)"%(dists.mean(),dists.std()))
reg = abs(dists.mean()-1.0)<0.05 and dists.std()<0.05
print("apexes form a REGULAR equidistant sheet?  %s"%reg)
if not reg:
    # the apex spacing equals the in-plane lattice spacing of S1 (centroids of up-triangles
    # form a triangular lattice scaled by... let's report the actual apex spacing)
    print("  (apex lattice spacing = %.4f L; this is the natural spacing of up-triangle centroids)"%dists.mean())

# Now the key measurement: with BOTH sheets present (S1 + apex sheet), in the registered stacking,
# measure the deficit around an interior vertical hinge. The registered structure is exactly the
# FCC two-layer; an interior edge between S1 and apex sheet is shared by tetrahedra. Count them and
# measure 2pi - sum(dihedrals).
pts=np.vstack([S1,apex]); N=len(pts)
def bonded(i,j):
    d=np.linalg.norm(pts[i]-pts[j]); return 0.1<d<=Rb
tree=cKDTree(pts)
tetra=set()
for i in range(N):
    nb=[j for j in tree.query_ball_point(pts[i],Rb) if j!=i]
    for j,k,l in itertools.combinations(nb,3):
        if all(bonded(*e) for e in [(i,j),(i,k),(i,l),(j,k),(j,l),(k,l)]):
            tetra.add(tuple(sorted((i,j,k,l))))
tetra=list(tetra)
def dih(edge,t):
    e0,e1=edge; o=[v for v in t if v not in edge]
    if len(o)!=2: return None
    p0,p1=pts[e0],pts[e1]; ax=(p1-p0)/np.linalg.norm(p1-p0); vs=[]
    for x in o:
        w=pts[x]-p0; w=w-np.dot(w,ax)*ax; nn=np.linalg.norm(w)
        if nn<1e-9: return None
        vs.append(w/nn)
    return np.arccos(np.clip(np.dot(vs[0],vs[1]),-1,1))
edge_t=defaultdict(list)
for t in tetra:
    for e in itertools.combinations(t,2):
        if bonded(*e): edge_t[tuple(sorted(e))].append(t)

delta0=np.degrees(2*np.pi-5*np.arccos(1/3))
print("\nregistered two-sheet structure: %d tetrahedra"%len(tetra))
# Look at edges and their tetra-coordination and deficit, interior only
from collections import Counter
defs=[]; coordcount=Counter()
for e,ts in edge_t.items():
    mid=(pts[e[0]]+pts[e[1]])/2
    if np.linalg.norm(mid[:2])>2.5: continue
    coordcount[len(ts)]+=1
    s=sum(d for d in (dih(e,t) for t in ts) if d is not None)
    defs.append((len(ts),np.degrees(2*np.pi-s)))
print("edge tetra-coordination histogram (interior):",dict(coordcount))
for nt in sorted(set(c for c,_ in defs)):
    vals=[d for c,d in defs if c==nt]
    print("  %d-tetra edges: deficit mean=%.2f std=%.2f (n=%d)"%(nt,np.mean(vals),np.std(vals),len(vals)))
print("\nidealized single-frustration delta0 = %.2f deg"%delta0)
