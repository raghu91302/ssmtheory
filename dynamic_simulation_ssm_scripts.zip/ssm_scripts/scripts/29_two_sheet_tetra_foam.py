"""
SSM dynamics paper -- Sec. 3 (two-sheet foam)
Two stacked sheets form a regular-tetrahedron (K=9) foam carrying deficit delta, homogeneous over the interface.
See README.md for the full script-to-section map.
"""
import numpy as np
from scipy.spatial import cKDTree
L=1.0; Rb=1.05
a1=np.array([1.0,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0])
h=np.sqrt(2/3)
def sheet(z,off):
    pts=[]
    for i in range(-5,6):
        for j in range(-5,6):
            p=i*a1+j*a2+off; p=p.astype(float); p[2]=z; pts.append(p)
    return np.array(pts)

offB=(a1+a2)/3.0
A=sheet(0.0,np.zeros(3))
B=sheet(h,offB)        # ONE sheet above, in close-packed hollow positions
two=np.vstack([A,B])
tree=cKDTree(two)

# central lower-sheet node
ci=np.argmin(np.linalg.norm(A[:,:2],axis=1)); c=A[ci]
d=np.linalg.norm(two-c,axis=1)
nbrs=two[(d>0.1)&(d<=Rb)]
K2=len(nbrs)
# upper-sheet neighbors of c
up=nbrs[nbrs[:,2]>0.1]
print("TWO-SHEET STATE (no third sheet yet):")
print("  central node coordination K = %d  (6 in-plane + %d from sheet above)"%(K2,len(up)))

# Is c + the 3 upper nodes a regular tetrahedron? check all edges ~ L
if len(up)>=3:
    tet=np.vstack([c,up[:3]])
    edges=[]
    for i in range(4):
        for j in range(i+1,4):
            edges.append(np.linalg.norm(tet[i]-tet[j]))
    edges=np.array(edges)
    print("  c + 3 upper nodes: edge lengths = %s"%np.round(edges,4))
    print("  all edges ~ L=1? %s  -> %s"%(np.allclose(edges,1.0,atol=0.05),
          "REGULAR TETRAHEDRON" if np.allclose(edges,1.0,atol=0.05) else "not regular"))

# Deficit around an EDGE shared between lower node and one upper node:
# how many tetrahedra meet around that edge, and the angle deficit.
# In the two-sheet packing, around a lower-upper bond, regular tetrahedra pack; measure deficit.
theta=np.arccos(1/3)  # regular-tetra dihedral
print("\n  regular-tetra dihedral theta = %.4f rad ; 5*theta = %.4f ; 2pi = %.4f"%(theta,5*theta,2*np.pi))
print("  Regge deficit delta = 2pi - 5 theta = %.4f rad = %.2f deg"%(2*np.pi-5*theta,np.degrees(2*np.pi-5*theta)))

print("""
KEY QUESTION: is the two-sheet bridging geometry tetrahedral (deficit-carrying) and EXTENDED?
 - If every lower node bridges to an upper triangle forming regular tetrahedra across the whole
   interface, then the two-sheet state is a SPATIALLY EXTENDED tetrahedral foam carrying delta
   everywhere -> homogeneous deficit during the 2nd-3rd sheet delay. (Rescues homogeneity.)
""")
# Check extendedness: what fraction of lower nodes have exactly 3 upper neighbors forming a tetra?
tetra_count=0; tot=0
for i in range(len(A)):
    cc=A[i]; dd=np.linalg.norm(two-cc,axis=1)
    upn=two[(dd>0.1)&(dd<=Rb)&(two[:,2]>0.1)]
    tot+=1
    if len(upn)>=3:
        # regular tetra check on nearest 3
        order=np.argsort(np.linalg.norm(upn-cc,axis=1))[:3]
        t=np.vstack([cc,upn[order]]); ed=[np.linalg.norm(t[a]-t[b]) for a in range(4) for b in range(a+1,4)]
        if np.allclose(ed,1.0,atol=0.06): tetra_count+=1
print("fraction of lower-sheet nodes forming a regular tetrahedron with the sheet above: %.2f"%(tetra_count/tot))
print("(interior nodes; edge effects lower the average. High interior fraction = EXTENDED tetra foam.)")
# interior only
inner=0; innertet=0
for i in range(len(A)):
    cc=A[i]
    if np.linalg.norm(cc[:2])>3.0: continue
    inner+=1; dd=np.linalg.norm(two-cc,axis=1)
    upn=two[(dd>0.1)&(dd<=Rb)&(two[:,2]>0.1)]
    if len(upn)>=3:
        order=np.argsort(np.linalg.norm(upn-cc,axis=1))[:3]
        t=np.vstack([cc,upn[order]]); ed=[np.linalg.norm(t[a]-t[b]) for a in range(4) for b in range(a+1,4)]
        if np.allclose(ed,1.0,atol=0.06): innertet+=1
print("interior fraction forming regular tetrahedra: %.2f (%d/%d)"%(innertet/max(inner,1),innertet,inner))
