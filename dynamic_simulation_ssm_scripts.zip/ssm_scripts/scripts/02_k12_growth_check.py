"""
SSM dynamics paper -- Sec. 9-10
Growth check: terminus vs lift rate and exclusion window.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
from collections import Counter
np.random.seed(1)
L=1.0
nn=np.array([[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],[1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
             [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]],float)/np.sqrt(2)

def grow(pl, Rex, N=2500):
    occ=set([(0.,0.,0.)]); pts=[np.zeros(3)]
    def neigh(p): return [tuple(np.round(p+d,4)) for d in nn]
    cand=set(neigh(np.zeros(3)))
    last_z=0.0
    while len(pts)<N and cand:
        cl=list(cand)
        same=[c for c in cl if abs(c[2]-last_z)<0.35]
        new =[c for c in cl if abs(c[2]-last_z)>=0.35]
        if np.random.rand()<pl and new: q=new[np.random.randint(len(new))]
        elif same:                      q=same[np.random.randint(len(same))]
        else:                           q=cl[np.random.randint(len(cl))]
        cand.discard(q); p=np.array(q)
        # exclusion against all occupied
        ok=True
        for o in occ:
            if np.linalg.norm(p-np.array(o))<Rex-1e-9: ok=False;break
        if ok:
            occ.add(q); pts.append(p); last_z=q[2]
            for c in neigh(p):
                if c not in occ: cand.add(c)
    P=np.array(pts)
    # bulk modal K
    degs=[]
    for i in range(len(P)):
        d=np.linalg.norm(P-P[i],axis=1)
        if np.count_nonzero(d<2*L)-1>=42:
            degs.append(int(np.count_nonzero((d>0.5)&(d<1.1))))
    return (Counter(degs).most_common(1)[0][0], len(degs), len(P)) if degs else (None,0,len(P))

print("R* = sqrt(2-sqrt2) = %.5f  (cuboctahedron square-face hole)"%np.sqrt(2-np.sqrt(2)))
print("\nK=12 terminus vs LIFT RATE (R_ex=0.95, inside window (0.765,1.0)):")
for pl in [0.005,0.05,0.2,0.5]:
    k,nb,ntot=grow(pl,0.95)
    print("  P_lift=%.3f -> bulk modal K=%s  (%d bulk of %d nodes)"%(pl,k,nb,ntot))
print("\nK=12 terminus vs EXCLUSION (P_lift=0.05):")
for Rex in [0.70,0.78,0.90,0.99,1.02]:
    k,nb,ntot=grow(0.05,Rex)
    inw='in ' if np.sqrt(2-np.sqrt(2))<Rex<1.0 else 'OUT'
    print("  R_ex=%.2f (%s) -> bulk modal K=%s  (%d bulk of %d)"%(Rex,inw,k,nb,ntot))
