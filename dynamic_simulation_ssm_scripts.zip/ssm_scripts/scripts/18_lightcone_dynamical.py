"""
SSM dynamics paper -- Sec. 6 (signal cone)
Dynamical Hamiltonian; single-excitation signal cone v = 2 v_lat.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
# ----- physical scales (inherit from constants paper) -----
hbar=1.0                      # work in hbar=1; restore at the end
l_lat=1.0                    # bond length in lattice units (= l_Planck physically)
eps=1.0                      # entanglement energy scale (= E_Planck/4 physically; see below)
Gamma=eps                    # single scale: kinetic coupling = binding scale
N=401                        # chain of bond-qubits (single-excitation sector = tight binding)
# tight-binding Hamiltonian (single excitation hopping between adjacent bonds)
H=np.zeros((N,N))
for i in range(N-1):
    H[i,i+1]=H[i+1,i]=-Gamma         # hopping
np.fill_diagonal(H,-eps*0.0)         # binding is a uniform shift in 1-particle sector (drops out)
# diagonalize and evolve a localized excitation at center
E,V=np.linalg.eigh(H)
x0=N//2; psi0=np.zeros(N); psi0[x0]=1.0
c0=V.T@psi0
times=np.linspace(0,80,160)
P=np.zeros((len(times),N))
for ti,t in enumerate(times):
    psit=V@(np.exp(-1j*E*t/hbar)*c0)
    P[ti]=np.abs(psit)**2
# extract light-cone front velocity: position of the outermost site with P>threshold vs t
thr=1e-3; front=[]
for ti,t in enumerate(times):
    idx=np.where(P[ti]>thr)[0]
    if len(idx): front.append((t,(idx.max()-x0)*l_lat))
front=np.array(front)
# fit late-time front slope = v_front
mask=front[:,0]>20
v_front=np.polyfit(front[mask,0],front[mask,1],1)[0]
v_unit=l_lat*eps/hbar
print(f"emergent signal (light-cone) front velocity v_front = {v_front:.3f} l_lat*eps/hbar")
print(f"  natural velocity unit v_lat = l_lat*eps/hbar = {v_unit:.3f}")
print(f"  tight-binding band gives v_front = 2*l_lat*eps/hbar (max group velocity) = {2*v_unit:.3f}  [check]")
print(f"\n  => TIME enters as the Schrodinger parameter t (units hbar/eps);")
print(f"     LENGTH enters as l_lat; they COMBINE into the emergent speed v = l_lat*eps/hbar.")
print(f"     A LOCAL Hamiltonian has a finite Lieb-Robinson cone -> an emergent speed of light.")
np.save("lightcone_P.npy",P); np.save("lightcone_t.npy",times)
# ---- physical calibration to c = 4 v_lat ----
print("\nPHYSICAL CALIBRATION (where the numbers get units):")
print("  set l_lat = l_Planck and eps = E_Planck/4. Then")
print("  v_lat = l_lat*eps/hbar = l_P*(E_P/4)/hbar = (l_P E_P/hbar)/4 = c/4   since l_P E_P = hbar c.")
print("  => c = 4 v_lat, recovering the constants-paper relation as this Hamiltonian's signal speed.")
print("  (the factor 4 is the lattice Dirac-cone velocity computed separately; the hopping sets v_lat.)")
