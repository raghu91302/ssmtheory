"""
SSM dynamics paper -- Sec. 17 (CSS code)
[[192,130,3]] CSS code construction and verification (H_X H_Z^T = 0, d = 3).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, itertools
from math import isclose

a=np.sqrt(2.0); tol=1e-6
NN=1.0; SECOND=a            # second-neighbor distance = a = sqrt2 (the L*sqrt2 shell)
VOID_R=a/2                  # octahedral void to surrounding atom

def fcc_atoms(n):
    basis=[(0,0,0),(0.5,0.5,0),(0.5,0,0.5),(0,0.5,0.5)]
    pts=[]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                for b in basis:
                    pts.append(a*np.array([i+b[0],j+b[1],k+b[2]]))
    return np.array(pts)

def build(n):
    A=fcc_atoms(n); nA=len(A)
    # edges (NN)
    edges=[]; eidx={}
    for i in range(nA):
        for j in range(i+1,nA):
            if abs(np.linalg.norm(A[i]-A[j])-NN)<1e-3:
                eidx[(i,j)]=len(edges); edges.append((i,j))
    nE=len(edges)
    def eid(i,j): return eidx[(min(i,j),max(i,j))]
    # adjacency
    adj=[[] for _ in range(nA)]
    for (i,j) in edges: adj[i].append(j); adj[j].append(i)
    # octahedral voids: midpoints of second-neighbor (distance a) atom pairs
    voidset={}
    for i in range(nA):
        for j in range(i+1,nA):
            if abs(np.linalg.norm(A[i]-A[j])-SECOND)<1e-3:
                m=tuple(np.round((A[i]+A[j])/2,4))
                voidset.setdefault(m,0)
    # for each candidate void, collect atoms at VOID_R; keep those with exactly 6
    voids=[]
    Acoords={tuple(np.round(p,4)):k for k,p in enumerate(A)}
    for m in voidset:
        mv=np.array(m)
        surround=[k for k in range(nA) if abs(np.linalg.norm(A[k]-mv)-VOID_R)<1e-3]
        if len(surround)==6:
            # the 12 octahedron edges = NN pairs among the 6
            oedges=[]
            for x in range(6):
                for y in range(x+1,6):
                    p,q=surround[x],surround[y]
                    if abs(np.linalg.norm(A[p]-A[q])-NN)<1e-3:
                        oedges.append(eid(p,q))
            if len(oedges)==12:
                voids.append(oedges)
    # H_Z: vertices x edges (incidence)
    HZ=np.zeros((nA,nE),dtype=np.uint8)
    for e,(i,j) in enumerate(edges):
        HZ[i,e]=1; HZ[j,e]=1
    # H_X: voids x edges
    HX=np.zeros((len(voids),nE),dtype=np.uint8)
    for v,oe in enumerate(voids):
        for e in oe: HX[v,e]=1
    return A,edges,eid,adj,voids,HZ,HX,nE

def gf2_rank(M):
    M=M.copy()%2; r=0; rows,cols=M.shape; pr=0
    for c in range(cols):
        piv=None
        for i in range(pr,rows):
            if M[i,c]: piv=i;break
        if piv is None: continue
        M[[pr,piv]]=M[[piv,pr]]
        for i in range(rows):
            if i!=pr and M[i,c]: M[i]^=M[pr]
        pr+=1
        if pr==rows: break
    return pr

def in_rowspace(M, v):
    # is vector v in GF(2) rowspace of M?  rank(M) == rank(M + v)?
    r1=gf2_rank(M)
    r2=gf2_rank(np.vstack([M, v.reshape(1,-1)]))
    return r1==r2

for n in [2,3]:
    A,edges,eid,adj,voids,HZ,HX,nE=build(n)
    comm=(HX.astype(int)@HZ.T.astype(int))%2
    ok=not comm.any()
    rZ=gf2_rank(HZ); rX=gf2_rank(HX)
    k=nE-rZ-rX
    print(f"n={n} cells: atoms={len(A)}  edges(qubits)={nE}  vertices(Z)={HZ.shape[0]}  voids(X)={len(voids)}")
    print(f"   CSS commutation H_X H_Z^T = 0 (mod2)? {ok}")
    print(f"   rank(H_Z)={rZ}  rank(H_X)={rX}  ->  k = n-rZ-rX = {k}")
    # distance: shortest cycle = triangle (girth 3). check a triangle is a nontrivial X-logical:
    #  triangle in ker(H_Z) (cycle) and NOT in rowspace(H_X)
    # find a triangle
    tri=None
    for i in range(len(A)):
        for j in adj[i]:
            if j<=i: continue
            for kk in adj[i]:
                if kk<=j: continue
                if kk in adj[j]:
                    tri=(i,j,kk); break
            if tri: break
        if tri: break
    if tri:
        i,j,kk=tri
        tvec=np.zeros(nE,dtype=np.uint8)
        for (p,q) in [(i,j),(j,kk),(i,kk)]: tvec[eid(p,q)]=1
        is_cycle = not ((HZ.astype(int)@tvec.astype(int))%2).any()
        in_X = in_rowspace(HX, tvec)
        print(f"   triangle weight-3: is a cycle (ker H_Z)? {is_cycle};  in rowspace(H_X)(=trivial)? {in_X}")
        print(f"   -> triangle is a {'TRIVIAL' if in_X else 'NONTRIVIAL'} weight-3 X-logical; girth=3 => d_X = 3")
    print()
