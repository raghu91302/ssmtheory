"""
SSM dynamics paper -- Sec. 13
Spatial power spectrum of the branching process (n ~ -3.3, red; honest negative).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
np.random.seed(1)

Lbox=1.0
def branch(N0=2000, G=14, m=1.6, sigma=0.020, cap=600000):
    """self-exciting branching: each point spawns Poisson(m) children at parent+Gaussian(sigma)."""
    pts=np.random.rand(N0,3)*Lbox
    allpts=[pts]
    cur=pts
    for g in range(G):
        nchild=np.random.poisson(m,size=len(cur))
        tot=nchild.sum()
        if tot==0: break
        parents=np.repeat(cur,nchild,axis=0)
        child=(parents+np.random.normal(0,sigma,size=(tot,3)))%Lbox
        allpts.append(child); cur=child
        if sum(len(a) for a in allpts)>cap:
            break
    P=np.concatenate(allpts,axis=0)
    return P

def power_spectrum(P, ngrid=128):
    # grid density, FFT, radial average
    H,_=np.histogramdd(P,bins=(ngrid,ngrid,ngrid),range=[[0,Lbox]]*3)
    d=H/H.mean()-1.0           # density contrast
    dk=np.fft.fftn(d)
    Pk=np.abs(dk)**2/ngrid**3
    kx=np.fft.fftfreq(ngrid,d=Lbox/ngrid)*2*np.pi
    KX,KY,KZ=np.meshgrid(kx,kx,kx,indexing='ij')
    kmag=np.sqrt(KX**2+KY**2+KZ**2)
    kbins=np.logspace(np.log10(2*np.pi/Lbox),np.log10(kx.max()),22)
    kc=0.5*(kbins[1:]+kbins[:-1]); Pr=[]
    for i in range(len(kbins)-1):
        msk=(kmag>=kbins[i])&(kmag<kbins[i+1])
        Pr.append(Pk[msk].mean() if msk.sum()>0 else np.nan)
    return kc,np.array(Pr)

print("Simulating self-exciting branching crystallization (sheets seeding sheets)...")
P=branch()
print("total nucleation sites: %d"%len(P))
kc,Pk=power_spectrum(P)
ok=np.isfinite(Pk)&(Pk>0)
kc,Pk=kc[ok],Pk[ok]
# fit P(k) ~ k^n over the inertial range (between kernel scale and box)
kmin_fit=2*np.pi/0.3; kmax_fit=2*np.pi/0.04
mfit=(kc>kmin_fit)&(kc<kmax_fit)
n=np.polyfit(np.log(kc[mfit]),np.log(Pk[mfit]),1)[0]
print("\nP(k) ~ k^n over inertial range: n = %.3f"%n)
# dimensionless Delta^2 = k^3 P(k) ~ k^(n+3); scale-invariant (Harrison-Zel'dovich) is n=-3 (P~k^-3? no)
# CONVENTION: primordial CURVATURE P_R(k) ~ k^(ns-4) so that Delta^2_R ~ k^(ns-1); HZ ns=1 -> P_R~k^-3.
# For a DENSITY field, scale-invariant clustering (fractal dim 3, white) is n=0; HZ density P~k^1.
print("\n--- interpretation (with explicit, honest caveats) ---")
print("  measured density-field slope n = %.3f"%n)
print("  scale-invariant references: white/Poisson n=0 ; Harrison-Zel'dovich density n=+1")
print("  observed primordial (Planck) n_s=0.965 -> density P~k^0.965 at horizon crossing")
ns_equiv=n  # crude: if density P(k)~k^n, the 'tilt' analogue
print("  IF this density slope mapped directly to n_s, n_s ~ %.3f"%(1+ (n-1)))
print("""
HONEST CAVEATS (large):
 - This is the spatial clustering spectrum of the NUCLEATION point process, NOT the
   gauge-invariant primordial curvature spectrum. Mapping one to the other needs the
   full perturbation-theory machinery (horizon crossing, transfer to curvature) we do NOT have.
 - The slope depends on the branching kernel sigma and offspring number m (inputs), so a
   single n is not yet a parameter-free prediction.
 - What IS meaningful: whether the spectrum is a POWER LAW over a range (self-similar) vs
   having a strong preferred scale. A power law = scale-free = the inflation-like signature.
""")
# report whether it's a clean power law (R^2 of the fit)
res=np.log(Pk[mfit])-np.polyval(np.polyfit(np.log(kc[mfit]),np.log(Pk[mfit]),1),np.log(kc[mfit]))
ss=1-np.var(res)/np.var(np.log(Pk[mfit]))
print("power-law quality over inertial range: R^2 = %.3f (1.0 = perfect power law / scale-free)"%ss)
print("kernel sigma=0.020, offspring m=1.6 -> growth factor/gen=1.6, %d gens"%14)
