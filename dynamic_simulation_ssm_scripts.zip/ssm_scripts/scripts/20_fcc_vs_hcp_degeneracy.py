"""
SSM dynamics paper -- Sec. 18 (FCC vs HCP)
Local-measure degeneracy of FCC and HCP.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, itertools
L=1.0; H=np.sqrt(2/3)            # in-plane bond length L, interlayer spacing
# hexagonal sheet (triangular lattice) generator
def sheet(nx,ny,z,off):
    pts=[]
    for i in range(nx):
        for j in range(ny):
            x=(i+0.5*j)*L+off[0]; y=(j*np.sqrt(3)/2)*L+off[1]
            pts.append([x,y,z])
    return pts
# A,B,C in-plane offsets (the three close-packed registries)
oA=np.array([0,0]); oB=np.array([0.5*L,0.5*L/np.sqrt(3)]); oC=np.array([ -0*L, (L/np.sqrt(3))])
# use proper hollow offsets: B at centroid of up-triangle, C at centroid of down-triangle
oB=np.array([0.5*L, L/(2*np.sqrt(3))]); oC=np.array([0.0, L/np.sqrt(3)])
def build_stack(seq,nx=6,ny=6):
    off={'A':oA,'B':oB,'C':oC}
    pos=[]
    for k,s in enumerate(seq): pos+=sheet(nx,ny,k*H,off[s])
    return np.array(pos)
def analyze(pos,tag):
    nA=len(pos)
    # nearest-neighbor bonds (length ~L)
    edges=[]; eidx={}
    for i in range(nA):
        for j in range(i+1,nA):
            d=np.linalg.norm(pos[i]-pos[j])
            if abs(d-L)<0.06:
                eidx[(i,j)]=len(edges); edges.append((i,j))
    nE=len(edges)
    deg=np.zeros(nA,int)
    for (i,j) in edges: deg[i]+=1; deg[j]+=1
    bulk=deg==12
    # octahedral voids: a point with 6 mutually-close atoms forming an octahedron.
    # find them as centroids of atom-6-sets is expensive; instead detect octahedra by
    # midpoints of 2nd-neighbor (distance ~ sqrt(2)L? in close packing 2nd nbr = sqrt(2)*? )
    # Simpler robust proxy: count, per bulk atom, the cubocta vs anticubocta signature.
    # FCC bulk shell = cuboctahedron (24 shell-edges, no triangle between the two triangular caps aligned);
    # HCP bulk shell = anticuboctahedron (also 24 edges). Distinguish by 2nd-shell.
    return nE,deg,bulk
print("Comparing FCC (ABCABC) vs HCP (ABABAB) close-packed clusters:\n")
for tag,seq in [("FCC ABCABC","ABCABC"),("HCP ABABAB","ABABAB")]:
    pos=build_stack(seq)
    nE,deg,bulk=analyze(pos,tag)
    # bulk coordination distribution
    vals,counts=np.unique(deg[ (deg>0) ],return_counts=True)
    print(f"{tag}: atoms={len(pos)} bonds={nE} bulkK12={bulk.sum()} meanK={deg.mean():.2f}")
    # first-shell signature for a deep bulk atom
    ci=np.argmax(deg)
    nb=[j for j in range(len(pos)) if abs(np.linalg.norm(pos[ci]-pos[j])-L)<0.06 and j!=ci]
    # count bonds among neighbors (shell edges) and triangles
    se=0
    for a in range(len(nb)):
        for b in range(a+1,len(nb)):
            if abs(np.linalg.norm(pos[nb[a]]-pos[nb[b]])-L)<0.06: se+=1
    print(f"   deepest atom K={deg[ci]}, shell-edges among neighbors = {se} (cuboctahedron=24)")
