"""
SSM dynamics paper -- Sec. 18
Global code-rate / distance degeneracy of FCC and HCP.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, itertools
L=1.0
def gf2_rank(M):
    M=M.copy()%2; r=0; rows,cols=M.shape
    for c in range(cols):
        piv=next((i for i in range(r,rows) if M[i,c]),None)
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        r+=1
    return r
def fcc(n=3):
    a=np.sqrt(2.0); basis=[(0,0,0),(.5,.5,0),(.5,0,.5),(0,.5,.5)]
    P=[a*np.array([i+b[0],j+b[1],k+b[2]]) for i in range(n) for j in range(n) for k in range(n) for b in basis]
    C=np.diag([a*n]*3); return np.array(P),C
def hcp(n=3):
    a=1.0;c=a*np.sqrt(8/3)
    a1=np.array([a,0,0]);a2=np.array([a/2,a*np.sqrt(3)/2,0]);a3=np.array([0,0,c])
    basis=[np.zeros(3), (1/3)*a1+(1/3)*a2+(1/2)*a3]
    P=[i*a1+j*a2+k*a3+b for i in range(n) for j in range(n) for k in range(n) for b in basis]
    C=np.array([n*a1,n*a2,n*a3]); return np.array(P),C
def code(P,C,label):
    nA=len(P); Cinv=np.linalg.inv(C)
    def mi(d):
        f=d@Cinv; f-=np.round(f); return f@C
    edges=[];eidx={}
    for i in range(nA):
        for j in range(i+1,nA):
            if abs(np.linalg.norm(mi(P[i]-P[j]))-L)<0.05: eidx[(i,j)]=len(edges);edges.append((i,j))
    nE=len(edges); eid=lambda i,j: eidx.get((min(i,j),max(i,j)))
    HZ=np.zeros((nA,nE),np.uint8)
    for e,(i,j) in enumerate(edges):HZ[i,e]=1;HZ[j,e]=1
    # octahedral voids: midpoint of atoms at sqrt(2)L apart, with 6 atoms at L/sqrt2
    voids=set()
    for i in range(nA):
        for j in range(i+1,nA):
            dij=mi(P[i]-P[j])
            if abs(np.linalg.norm(dij)-np.sqrt(2)*L)>0.05: continue
            ctr=P[i]+dij/2
            near=[t for t in range(nA) if abs(np.linalg.norm(mi(P[t]-ctr))-L/np.sqrt(2))<0.05]
            if len(near)==6: voids.add(tuple(sorted(near)))
    HXrows=[]
    for v in voids:
        oe=[eid(a,b) for a,b in itertools.combinations(v,2)
            if eid(a,b) is not None and abs(np.linalg.norm(mi(P[a]-P[b]))-L)<0.05]
        if len(oe)==12:
            r=np.zeros(nE,np.uint8)
            for e in oe:r[e]=1
            HXrows.append(r)
    HX=np.array(HXrows,np.uint8) if HXrows else np.zeros((0,nE),np.uint8)
    css=(HX@HZ.T%2).sum()==0 if HX.shape[0] else True
    rZ=gf2_rank(HZ);rX=gf2_rank(HX) if HX.shape[0] else 0;k=nE-rZ-rX
    deg=HZ.sum(0)  # not used
    Kmean=2*nE/nA
    print(f"{label}: atoms={nA} meanK={Kmean:.2f} qubits={nE} Xchecks={HX.shape[0]} "
          f"voids/atom={len(voids)/nA:.3f} rankZ={rZ} rankX={rX}")
    print(f"      [[n,k]]=[[{nE},{k}]]  k/atom={k/nA:.3f}  CSS_ok={css}")
    return k/nA,len(voids)/nA
P,C=fcc(3); kf,vf=code(P,C,"FCC ABCABC")
P,C=hcp(4); kh,vh=code(P,C,"HCP ABABAB")
print(f"\nvoids/atom: FCC={vf:.3f} HCP={vh:.3f}   k/atom: FCC={kf:.3f} HCP={kh:.3f}")
print("MATCH => global codes equivalent (QEC stacking-degenerate). DIFFER => multi-cluster QEC selects.")
