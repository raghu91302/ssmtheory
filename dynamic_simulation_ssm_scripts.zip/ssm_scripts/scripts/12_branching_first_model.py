"""
SSM dynamics paper -- Sec. 13
First per-sheet branching model (superseded by the moment version).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np

e=np.e; q=1/(1+e)
v_lat=1.0; L=1.0; tau0=L/v_lat
v2=(1-2*q)*(np.sqrt(3)/2)*v_lat        # 2D radial build speed
h=np.sqrt(2/3)*L                        # interlayer spacing (a sheet occupies a slab of thickness h)
print("2D radial build speed v2 = (1-2q)*sqrt3/2 * v_lat = %.4f v_lat"%v2)

def run(p, Vfoam=1e9, tmax=4000, dt=0.5):
    """p = lift seeding amplitude (free). Returns t, crystallized volume Vc(t), n_active sheets."""
    # sheets: list of nucleation times. We track via binned ages for speed.
    # seeding rate of NEW sheets at time t: S(t) = sigma * (total growing sheet AREA in contact with foam)
    # sigma = p * (1/tau0) / L^2  (per unit area lift attempt rate)
    sigma = p*(1/tau0)/L**2
    ts=np.arange(0,tmax,dt)
    # use age-structured population: density n(a)=number of sheets of age a
    # d/dt of crystallized volume = sum over sheets of (perimeter growth)*h ~ dA/dt * h
    # We evolve number of sheets N and total area Atot with the area of a sheet ~ (v2 a)^2 pi
    # Simpler: track list of nucleation times but cap; use moments.
    nuc=[0.0]                # seed one initial sheet at t=0
    Vc=[]; Nsheet=[]; 
    Vcryst=0.0; seeded_total=1
    nuc=np.array([0.0])
    for t in ts:
        ages=t-nuc; ages=ages[ages>=0]
        # area of each sheet (cap radius so a sheet can't exceed remaining foam slab)
        areas=np.pi*(v2*ages)**2
        Atot=areas.sum()
        # crystallized volume = Atot * h (each sheet is a slab of thickness h), capped at Vfoam
        Vcryst=min(Atot*h, Vfoam)
        frac_foam_left=max(0.0,1-Vcryst/Vfoam)
        # number of NEW sheets seeded this step: proportional to growing area * foam availability
        # growing area = perimeter region; use total area * sigma * frac_foam_left
        dN = sigma*Atot*frac_foam_left*dt
        # add integer-ish new sheets (Poisson mean dN) -> add as fractional via many seeds:
        if dN>0 and frac_foam_left>0:
            k=np.random.poisson(dN) if dN<1e4 else int(dN)
            if k>0: nuc=np.concatenate([nuc, np.full(k,t)])
        Vc.append(Vcryst); Nsheet.append(len(nuc))
        if frac_foam_left<=0: 
            # fill rest of array
            Vc+= [Vcryst]*(len(ts)-len(Vc)); Nsheet+=[len(nuc)]*(len(ts)-len(Nsheet)); break
    return ts[:len(Vc)], np.array(Vc), np.array(Nsheet)

np.random.seed(0)
print("\n--- Is growth exponential? Fit Vc(t) ~ exp(Gamma t) in the early (foam-rich) phase ---")
for p in [0.05, 0.005, 0.0005]:
    t,Vc,N=run(p, Vfoam=1e10, tmax=6000, dt=1.0)
    # early exponential region: where Vc between 10 and 1e6 (well before foam runs out)
    m=(Vc>10)&(Vc<1e6)
    if m.sum()>5:
        G=np.polyfit(t[m],np.log(Vc[m]),1)[0]
        # doubling time
        print(f"  p={p:.4f}: Gamma={G:.5f}/tau0 -> e-fold time={1/G:.1f} tau0 ; "
              f"sqrt(p)-scaling check: Gamma/sqrt(p)={G/np.sqrt(p):.4f}")
    else:
        print(f"  p={p:.4f}: insufficient exponential range")

print("\n--- Does it END when foam depletes? (finite reservoir) ---")
t,Vc,N=run(0.01, Vfoam=1e6, tmax=8000, dt=1.0)
imax=np.argmax(Vc>=0.999e6) if (Vc>=0.999e6).any() else len(Vc)-1
print(f"  foam reservoir V=1e6: crystallization saturates at t~{t[imax]:.0f} tau0,")
print(f"  Vc plateaus at {Vc[-1]:.3e} (=foam) -> growth STOPS when foam is consumed (reheating-like).")

print("\n--- analytic structure ---")
print("  Branching: dV/dt ~ sigma*v2^2 * (built area) -> V'' ~ V => EXPONENTIAL, rate")
print("  Gamma ~ sqrt(sigma * v2^2 * h) ~ sqrt(p) * v_lat/L  (inflation rate scales as sqrt(lift))")
print("  -> Gamma INHERITS the lift-rate freedom (as sqrt). e-folds set by ln(Vfoam/Vseed).")
print("  -> Ends when foam consumed: built-in graceful exit (no fine-tuning of 'end of inflation').")
