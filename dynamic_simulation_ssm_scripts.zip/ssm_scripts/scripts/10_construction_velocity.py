"""
Derive the SPEED of K=12 construction: the velocity of the crystallization front.

Ingredients (all already established):
  tau0 = hbar/eps                 fundamental time
  L    = ell_lat                  bond length
  q    = 1/(1+e)                  per-bond failure prob (detailed balance)
  v_lat= L eps/hbar = L/tau0      base lattice velocity
  c    = 4 v_lat                  emergent light cone (3D Dirac factor)

Mechanism: the front advances by ATTACHMENTS (sigma^+ births) minus detachments (sigma^- deaths).
With attempt frequency 1/tau0 and detailed balance, the per-site rates are
  gamma_up = [e/(1+e)]/tau0,  gamma_dn = [1/(1+e)]/tau0
so the NET forward rate per site is (gamma_up - gamma_dn) = (e-1)/(e+1)/tau0 = (1-2q)/tau0.
Each layer added advances the front by the inter-layer spacing h_d (the regular d-simplex
apex height, = the 'lift' height generalized to d dimensions):
  h_d = L sqrt((d+1)/(2d))     [d=3 -> sqrt(2/3) L, the FCC lift height]
=> front velocity  v_build(d) = (1-2q) * h_d / tau0 = (e-1)/(e+1) * sqrt((d+1)/(2d)) * v_lat.
"""
import numpy as np
e=np.e
q=1/(1+e)
net=(e-1)/(e+1)          # = 1-2q, net forward fraction
print("q = 1/(1+e) = %.4f ;  net forward fraction (1-2q) = (e-1)/(e+1) = %.4f"%(q,net))

def h(d): return np.sqrt((d+1)/(2*d))     # regular d-simplex apex height /L
# known/best kissing numbers (terminal coordination K in each dimension)
kiss={1:2,2:6,3:12,4:24,5:40,6:72,7:126,8:240}

print("\n d   K(kiss)   h_d/L    v_build/v_lat   v_build/c (3D: c=4v_lat)")
for d in range(2,9):
    vb=net*h(d)               # in units v_lat
    print("  %d    %4d    %.4f      %.4f          %.4f"%(d,kiss[d],h(d),vb,vb/4))
print("  ...  ->        %.4f      %.4f          %.4f   (d->inf, h->1/sqrt2)"%(1/np.sqrt(2),net/np.sqrt(2),net/np.sqrt(2)/4))

print("\n=== 3D RESULT (K=12) ===")
vb3=net*h(3)
print("v_build(3) = (e-1)/(e+1) * sqrt(2/3) * v_lat = %.4f v_lat"%vb3)
print("           = %.4f c            (using c = 4 v_lat)"%(vb3/4))
print("           = c / %.2f"%(4/vb3))
print("In Planck units (eps=E_P/4 -> tau0=4 t_P, L=l_P, v_lat=c/4):")
print("   v_build(3) = %.4f * (c/4) ... wait, v_build is already in v_lat=c/4 units:"%vb3)
print("   v_build(3) = %.4f v_lat = %.4f c = %.3e m/s"%(vb3,vb3/4,vb3/4*2.998e8))

print("\n=== local shell-completion time (one cuboctahedron) ===")
# time to fill 12 shell sites, each at net rate net/tau0; coupon-collector-ish ~ H_12/net
H12=sum(1/k for k in range(1,13))
print("tau_shell ~ H_12/net * tau0 = %.2f/%.3f tau0 = %.2f tau0  (parallel fill: ~1/net=%.2f tau0)"%(H12,net,H12/net,1/net))

print("\n=== KEY OBSERVATIONS ===")
print("1. v_build/v_lat is nearly DIMENSION-INDEPENDENT: 0.400 (d=2) -> 0.327 (d->inf).")
print("   Because h_d is bounded in [1/sqrt2, sqrt3/2]. So the build speed is ~0.33-0.40 v_lat")
print("   in ANY dimension -- a near-universal fraction of the base lattice velocity.")
print("2. In 3D: v_build = 0.377 v_lat = 0.094 c ~ c/10.6.  Causal (< light cone 2v_lat=0.5c).")
print("3. This is the ROUGH/isotropic front. Layer-by-layer growth is ANISOTROPIC: the")
print("   STACKING-direction speed is set by the (free) lift rate, the IN-PLANE speed by stitch.")
print("   The parameter-free number above is the in-plane / rough-front speed.")
