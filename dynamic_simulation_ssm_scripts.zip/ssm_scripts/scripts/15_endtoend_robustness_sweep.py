"""
SSM dynamics paper -- Sec. 15
Temperature x seed sweep: K=12 generic across a factor-of-eight in T (robustness).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
from scipy.spatial import cKDTree
from collections import Counter
from math import comb

L=1.0; Rex=0.95; Rb_lo,Rb_hi=0.90,1.10

def make_q(beta):  # detailed balance failure prob at inverse temp beta (energy gap eps=1)
    return 1.0/(1.0+np.exp(beta))
def Pdiss(K,q):
    if K<2: return 1.0
    return sum(comb(K,j)*q**j*(1-q)**(K-j) for j in range(K-2,K+1))
def bonds(P):
    t=cKDTree(P); adj=[set() for _ in range(len(P))]
    for i,j in t.query_pairs(Rb_hi):
        if Rb_lo<=np.linalg.norm(P[i]-P[j])<=Rb_hi: adj[i].add(j); adj[j].add(i)
    return adj,t
def tris(adj):
    T=[]
    for a in range(len(adj)):
        nb=[x for x in adj[a] if x>a]
        for i in range(len(nb)):
            for j in range(i+1,len(nb)):
                if nb[j] in adj[nb[i]]: T.append((a,nb[i],nb[j]))
    return T
def step(P,beta,q,dt=0.5):
    P=list(P); arr=np.array(P); adj,tree=bonds(arr); Tr=tris(adj); births=[]
    bondlist=[(i,j) for i in range(len(P)) for j in adj[i] if j>i]; np.random.shuffle(bondlist)
    for (i,j) in bondlist[:50]:
        A,B=arr[i],arr[j]; mid=(A+B)/2; common=adj[i]|adj[j]; ref=None
        for c in common:
            if c not in (i,j): ref=arr[c]; break
        ab=(B-A)/np.linalg.norm(B-A)
        if ref is None:
            rnd=np.random.randn(3); perp=rnd-rnd.dot(ab)*ab
        else:
            pc=ref-mid; perp=-(pc-pc.dot(ab)*ab)
        if np.linalg.norm(perp)<1e-6: continue
        perp/=np.linalg.norm(perp); cand=mid+(np.sqrt(3)/2)*L*perp
        if tree.query(cand)[0]>=Rex:
            dd=np.linalg.norm(arr-cand,axis=1); nb=np.sum((dd>=Rb_lo)&(dd<=Rb_hi))
            if nb>=2 and np.random.rand()<min(1,np.exp(beta*nb)): births.append(cand)
    np.random.shuffle(Tr)
    for (a,b,c) in Tr[:50]:
        A,B,C=arr[a],arr[b],arr[c]; ctr=(A+B+C)/3; n=np.cross(B-A,C-A)
        if np.linalg.norm(n)<1e-6: continue
        n/=np.linalg.norm(n)
        for s in (1,-1):
            cand=ctr+s*np.sqrt(2/3)*L*n
            if tree.query(cand)[0]>=Rex:
                dd=np.linalg.norm(arr-cand,axis=1); nb=np.sum((dd>=Rb_lo)&(dd<=Rb_hi))
                if nb>=3 and np.random.rand()<min(1,np.exp(beta*nb)): births.append(cand); break
    for cand in births:
        if len(P)==0 or min(np.linalg.norm(np.array(P)-cand,axis=1))>=Rex: P.append(cand)
    arr=np.array(P); adj,_=bonds(arr); keep=[]
    for i in range(len(P)):
        if np.random.rand()>=dt*Pdiss(len(adj[i]),q): keep.append(P[i])
    return keep
def run(beta,seed,iters=90):
    np.random.seed(seed); P=[np.array([0,0,0.]),np.array([1,0,0.])]
    for it in range(iters):
        P=step(P,beta,make_q(beta))
        if len(P)<2: P=[np.array([0,0,0.]),np.array([1.,0,0])]
    arr=np.array(P); 
    if len(arr)<3: return 0,0,None
    adj,_=bonds(arr); deg=np.array([len(a) for a in adj])
    cnt2=np.array([np.sum(np.linalg.norm(arr-arr[i],axis=1)<2*L)-1 for i in range(len(arr))])
    bulk=cnt2>=42; bm=Counter(deg[bulk]).most_common(1)[0][0] if bulk.sum() else None
    return len(P),deg.mean(),bm

print("Sweep: inverse-temp beta (cold=high beta) x seeds. reduced T t=1/beta.")
print(" beta   t=1/b   q=1/(1+e^b)   <N>    <K>    bulk_modal_K (over 4 seeds)   outcome")
for beta in [0.4,0.7,1.0,1.5,2.0,3.0]:
    Ns=[];Ks=[];BMs=[]
    for s in range(4):
        n,k,bm=run(beta,s); Ns.append(n);Ks.append(k);BMs.append(bm)
    bmc=Counter([b for b in BMs if b is not None])
    q=make_q(beta)
    frac12=sum(1 for b in BMs if b==12)/4
    out=("K=12 generic" if frac12>=0.75 else "K=12 sometimes" if frac12>0 else
         ("GLASS" if np.mean(Ks)<6 else "partial"))
    print("  %.1f   %.2f    %.4f      %5.0f  %.2f   %s   [K12 in %d/4]  %s"%(
        beta,1/beta,q,np.mean(Ns),np.mean(Ks),dict(bmc),int(frac12*4),out))

print("""
READING:
 - K=12 GENERIC across a broad beta range -> robust, your doubt substantially answered.
 - K=12 only in a narrow beta window -> that window is a hidden tuning; fragility located.
 - GLASS at high T (low beta), FREEZE/sparse at very low T -> expected physical bracketing.
""")
