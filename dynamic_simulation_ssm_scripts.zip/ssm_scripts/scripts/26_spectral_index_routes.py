"""
SSM dynamics paper -- Sec. 14
Cross-check of transfer-coefficient routes (only sqrt3 lands on Planck).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
delta=2*np.pi-5*np.arccos(1/3)
zeta=delta/(2*np.pi)
L=1.0
print("delta = %.5f rad, zeta=delta/2pi = %.5f"%(delta,zeta))
print("Planck n_s = 0.9649 +/- 0.0042. Target tilt 1-n_s = %.4f\n"%(1-0.9649))

# --- Route A: Regge action area-per-hinge vs hinge length (the paper's stated basis) ---
# Each hinge (edge length L) is dual to a triangular face area A_tri = sqrt3/4 L^2.
# The paper's J = (transverse altitude)/(half-base) = (sqrt3/2 L)/(L/2) = sqrt3.
A_tri=np.sqrt(3)/4*L**2
J_paper=(np.sqrt(3)/2*L)/(L/2)
print("Route A (triangle aspect ratio, paper): J = %.4f  -> n_s = %.4f"%(J_paper,1-J_paper*zeta))

# --- Route B: curvature DENSITY ratio (curvature per boundary area / curvature per bulk length) ---
# Bulk: deficit delta concentrated on a hinge of length L -> linear curvature density delta/L.
# Boundary: the SAME deficit spread over the dual triangular face area A_tri -> areal density delta/A_tri.
# The transfer of the dimensionless perturbation picks up the ratio of the relevant measures.
# Dimensionless amplitude on boundary / in bulk = (length scale)/(area scale per length) = L/(A_tri/L)?
C_B = L**2/A_tri        # = 1/(sqrt3/4) = 4/sqrt3
print("Route B (area-density ratio): C = L^2/A_tri = %.4f -> n_s = %.4f"%(C_B,1-C_B*zeta))
# note 4/sqrt3 = 2.309, NOT sqrt3. This route disagrees with the paper.

# --- Route C: coherent mode accumulation (the paper's stated PHYSICAL mechanism) ---
# The paper says: 'larger wavelength modes span more hinges and accumulate curvature COHERENTLY,
# shorter modes sample hinges INCOHERENTLY.' That is a random-walk vs ballistic statement.
# A mode of wavelength lambda spans N = lambda/L hinges. Coherent accumulation ~ N, incoherent ~ sqrt(N).
# The tilt is the LOG-derivative of power w.r.t. scale from this differential accumulation.
# Power P(k) ~ <curv^2>. Coherent piece scales as N^2 zeta^2, incoherent as N zeta^2.
# The number of hinges per unit length along a boundary face vs along a hinge differ by the
# face's transverse extent. The geometric factor relating boundary-spanning to hinge-spanning
# is the number of hinges a boundary face touches per hinge length.
# A triangular face touches its 3 edges; per unit hinge length, the transverse reach is the altitude.
# Coherence factor = altitude/(edge) along the propagation = (sqrt3/2 L)/L = sqrt3/2 ... times 2 edges
# Let's compute the actual hinge-count ratio on the FCC boundary.

# FCC (111) boundary is a triangular lattice of hinges. Count hinges spanned by a mode along
# a boundary direction vs along the bulk hinge direction.
# Build a patch of the triangular boundary lattice and measure the ratio of hinge line-density
# in the transverse vs longitudinal directions.
a1=np.array([1,0]); a2=np.array([0.5,np.sqrt(3)/2])
pts=np.array([i*a1+j*a2 for i in range(-8,9) for j in range(-8,9)])
# longitudinal = along a1 (hinge direction); transverse = along the altitude (perp to a1)
# line density of lattice rows: spacing along a1 is 1; spacing of rows perp to a1 is sqrt3/2.
long_density=1.0/1.0
trans_density=1.0/(np.sqrt(3)/2)
C_C=trans_density/long_density
print("Route C (boundary hinge line-density transverse/longitudinal): C = %.4f -> n_s=%.4f"%(C_C,1-C_C*zeta))
# = 2/sqrt3 = 1.1547 ... also not sqrt3.

print("\n--- SUMMARY: what multiplies (delta/2pi)? ---")
for name,C in [("sqrt3 (paper)",np.sqrt(3)),("4/sqrt3 (area density)",4/np.sqrt(3)),
               ("2/sqrt3 (line density)",2/np.sqrt(3)),("1 (no Jacobian)",1.0),
               ("sqrt3/... 2*(sqrt3/2)=sqrt3",2*(np.sqrt(3)/2))]:
    print("  C=%-22s -> n_s = %.4f  (Planck 0.9649+/-0.0042: %s)"%(
        "%.4f"%C, 1-C*zeta, "WITHIN" if abs(1-C*zeta-0.9649)<0.0042 else "outside"))
print("""
HONEST READING:
 - delta/2pi = %.4f is solid and parameter-free (the Regge deficit, already in our model).
 - The COEFFICIENT C is NOT uniquely fixed by geometry: different defensible projection
   definitions give sqrt3=1.732, 2/sqrt3=1.155, 4/sqrt3=2.309, or 1. Only C=sqrt3 (and the
   algebraically equal 2*(sqrt3/2)) hits Planck.
 - So the paper's n_s=0.9646 requires C=sqrt3 SPECIFICALLY; our independent routes do NOT
   uniquely reproduce it. The match is real IF the transfer is the triangle aspect ratio,
   but that identification is an assumption, not forced by the front dynamics.
"""%zeta)
