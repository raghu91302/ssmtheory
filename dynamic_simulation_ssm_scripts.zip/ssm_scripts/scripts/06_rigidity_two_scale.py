"""
SSM dynamics paper -- Sec. 11 (rigidity scale)
Two-scale rigidity: kT/(kappa L^2) < 0.028 and zero-point floor 14.8.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
L=1.0; hbar=1.0; kB=1.0
nn=np.array([[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],[1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
             [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]],float)/np.sqrt(2)*L

def spectrum(Nq=16):
    """Return all phonon frequencies in units of sqrt(kappa/m), kappa=m=1 here."""
    a=np.sqrt(2)*L; qs=(np.arange(Nq)+0.5)*2*np.pi/(a*Nq)-np.pi/a
    ws=[]
    for qx in qs:
        for qy in qs:
            for qz in qs:
                q=np.array([qx,qy,qz])
                if np.allclose(q,0): continue
                M=np.zeros((3,3))
                for d in nn:
                    dh=d/np.linalg.norm(d); M+=(1-np.cos(q@d))*np.outer(dh,dh)
                w2=np.clip(np.linalg.eigvalsh(M),1e-9,None)
                ws+=list(np.sqrt(w2))
    return np.array(ws)

w=spectrum()            # in units Omega=sqrt(kappa/m)
wD=w.max()              # Debye freq in same units
print("FCC central-force spectrum: <w>=%.3f, w_Debye=%.3f (units sqrt(kappa/m))"%(w.mean(),wD))

Rstar=np.sqrt(2-np.sqrt(2))
# <u^2> in units (hbar/(m*Omega)) as function of reduced temp t=kT/(hbar*Omega):
# <u^2> = (1/N) sum_modes (hbar/(2 m w~)) coth(w~/(2t)) ,  w~ in units Omega
# In physical units <u^2> = [hbar/(m Omega)] * f(t).  And hbar*Omega = hbar*sqrt(kappa/m).
# The bond fluctuation sqrt(2<u^2>) must be < L - R*. We need the PHYSICAL <u^2>; express
# via the rigidity ratio r = hbar*Omega/(kappa L^2/ ... ) -- cleanest: define dimensionless
# A = hbar/(m Omega L^2) = hbar Omega/(kappa L^2) = (hbar Omega)/(kappa L^2).
# Since Omega=sqrt(kappa/m): A = hbar/(L^2 sqrt(kappa m)). This is the QUANTUM/zero-point size.
# Physical condition: 2*A*f(t) < (L-R*)^2/L^2 = (1-R*)^2.
def f(t):
    return np.mean(hbar/(2*w)/np.tanh(w/(2*t))) if t>0 else np.mean(hbar/(2*w))
target=(1-Rstar)**2
print("\nNeed 2*A*f(t) < (1-R*)^2 = %.4f, where A=hbar/(L^2 sqrt(kappa m)) is the zero-point size."%target)
print("Two regimes:")
print(" (i) classical/thermal: f(t)->t for t>>1, so condition ~ 2*A*t < (1-R*)^2")
print(" (ii) quantum/zero-point floor: f(0)=<1/(2w)>=%.3f sets a MINIMUM even at T=0.\n"%f(1e-6))

print(" reduced T   f(t)      with A=0.02   bond_min   rigid?")
for t in [0.01,0.1,0.5,1,2,5]:
    for A in [0.02]:
        u2=A*f(t); bm=L-np.sqrt(2*u2)
        print("   %.2f      %.3f     u2=%.4f    %.4f    %s"%(t,f(t),u2,bm,'YES' if bm>Rstar else 'no'))

# The KEY derived numbers:
print("\n=== DERIVED CONDITIONS ===")
fz=f(1e-6)
A_max_zeropoint = target/(2*fz)
print("1) ZERO-POINT floor: even at T=0, need A=hbar/(L^2 sqrt(kappa m)) < %.4f"%A_max_zeropoint)
print("   => sqrt(kappa m) L^2/hbar > %.2f : the lattice must be heavy/stiff enough that"%(1/A_max_zeropoint))
print("      its quantum zero-point motion alone stays inside the K=12 window.")
# classical: at the binding temperature kT=eps, with hbar*wD = eps would give t~1/wD...
# scale separation needed:
print("2) THERMAL: bond fluctuation < window needs kT/(kappa L^2) < %.4f"%( ((1-Rstar)**2)/2 ))
print("   i.e. binding rigidity kappa L^2 must exceed bath temperature kT by >~ %.0fx"%(2/((1-Rstar)**2)))
print("\nCONCLUSION: the missing parameter is the dimensionless ratio kT/(kappa L^2).")
print("Rigidity of the FORCED K=12 lattice requires kT/(kappa L^2) < %.3f (a DERIVED bound)."%(((1-Rstar)**2)/2))
print("A single-scale model (kT=eps=binding depth, kappa L^2~eps) gives ratio ~1 >> bound -> melts.")
print("Two scales with separation > %.0f make the K=12 vacuum rigid; lift rate stays free."%(2/((1-Rstar)**2)))
