"""
SSM dynamics paper -- Sec. 10
Kinetic/TST attempt to derive a fixed lift rate (negative result: not parameter-free).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
from scipy.optimize import minimize_scalar

L=1.0; eps=1.0; beta=1.0/eps   # T0 = eps/kB

# --- pairwise node potential: attractive well at L, hard-ish exclusion below R_ex ---
# Use a smooth Morse-like form whose ONLY scale is eps and whose minimum is at L.
# u(r) = eps*[ (1-exp(-a(r-L)))^2 - 1 ]  Morse; a fixed by requiring the curvature match
# the lattice (a sets vibrational freq). We take a from the Regge jitter so it is geometric.
delta = 2*np.pi - 5*np.arccos(1/3)      # 0.1284 rad
a = 1.0/np.sin(delta)                    # stiffness scale from the geometric jitter; ~1/0.128
def u(r):
    return eps*((1-np.exp(-a*(r-L)))**2 - 1.0)

# attempt frequency from curvature of the well: omega0 = sqrt(u''(L)/m); set m so hbar*omega ~ eps
upp = 2*eps*a**2                         # u''(L)
# nondimensional attempt freq (same for both channels -> cancels in ratio). Keep =1.

print("Stiffness a = 1/sin(delta) = %.3f ; well curvature u''(L)=%.3f eps/L^2"%(a,upp))

# ============ STITCH path ============
# Incoming node approaches the midpoint of an edge (2 anchor nodes at +-L/2 on x-axis),
# along the in-plane perpendicular (y). Apex at y_apex = sqrt(3)/2.
A1=np.array([-0.5,0,0.]); A2=np.array([0.5,0,0.])
def E_stitch(y):
    p=np.array([0,y,0.])
    return u(np.linalg.norm(p-A1))+u(np.linalg.norm(p-A2))
ys=np.linspace(0.30,1.6,400)
Es=np.array([E_stitch(y) for y in ys])
E_inf_s = 2*u(3.0)                      # ~0 (far)
barrier_stitch = Es.max()-Es[-1] if Es.max()>Es[-1] else 0.0
Emin_s = Es.min()
print("\nSTITCH: well depth %.3f eps ; barrier above incoming = %.4f eps"%(Emin_s,max(0,Es.max()-E_inf_s)))

# ============ LIFT path ============
# 3 anchor nodes = equilateral triangle edge L in z=0; centroid at origin.
t=np.array([[ 0.5,-np.sqrt(3)/6,0],[-0.5,-np.sqrt(3)/6,0],[0,np.sqrt(3)/3,0]])*1.0
# rescale to edge L:
def tri(edge=L):
    R=edge/np.sqrt(3)
    return np.array([[np.cos(a_),np.sin(a_),0] for a_ in [np.pi/2,np.pi/2+2*np.pi/3,np.pi/2+4*np.pi/3]])*R
T=tri(L)
def E_lift(z):
    p=np.array([0,0,z])
    return sum(u(np.linalg.norm(p-v)) for v in T)
zs=np.linspace(0.30,1.6,400)
El=np.array([E_lift(z) for z in zs])
E_inf_l=3*u(3.0)
z_apex=np.sqrt(2/3)
print("LIFT: apex height check sqrt(2/3)=%.4f, E(apex)=%.3f eps"%(z_apex,E_lift(z_apex)))
barrier_lift=max(0,El.max()-E_inf_l)
Emin_l=El.min()
print("LIFT: well depth %.3f eps ; barrier above incoming = %.4f eps"%(Emin_l,barrier_lift))

# The approach barrier alone may be small; the REAL suppression is that the lift apex is a
# codim-3 point target while stitch is a codim-2 line target. Capture cross-section from
# thermal fluctuations of width sigma_th = sqrt(kT/u'') = sqrt(eps/(eps*a^2)) = 1/a (geometric!).
sigma_th=1.0/a
print("\nThermal capture width sigma_th = 1/a = %.4f L  (FIXED by geometry, not chosen)"%sigma_th)

# target 'volume' in the transverse directions that lands in the well:
# stitch apex: 1D manifold (the intersection circle of radius r=sqrt(3)/2) x 2 transverse gaussian dirs
r_circle=np.sqrt(1-(L/2)**2)
Xsec_stitch = (2*np.pi*r_circle) * sigma_th**2      # line target, 2 transverse dims
# lift apex: 0D (2 points) x 3 transverse gaussian dirs
Xsec_lift   = 2 * sigma_th**3                        # point target, 3 transverse dims
print("Capture cross-section: stitch=%.4f  lift=%.4f"%(Xsec_stitch,Xsec_lift))

# ============ assemble the rate ratio (TST) ============
ratio = (Xsec_lift/Xsec_stitch) * np.exp(-beta*(barrier_lift-barrier_stitch))
print("\n"+"="*64)
print("DERIVED  P_lift/P_stitch = %.4f"%ratio)
print("compare published e^-3 = %.4f"%np.exp(-3))
print("="*64)
# decompose
print("  geometric (cross-section) factor = %.4f"%(Xsec_lift/Xsec_stitch))
print("  barrier (Arrhenius) factor       = %.4f  (barrier_lift-stitch=%.3f eps)"%(np.exp(-(barrier_lift-barrier_stitch)),barrier_lift-barrier_stitch))
print("  -ln(ratio) = %.3f   (e^-3 would need -ln = 3.000)"%(-np.log(ratio)))
