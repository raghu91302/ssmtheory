"""
Self-consistent derivation of the binding stiffness kappa.

Build the REAL FCC phonon spectrum from the central-bond Hamiltonian, compute the exact
mean-square displacement <u^2> (zero-point + thermal) at T0 = eps/k_B, and find the kappa
for which the lattice is self-consistently rigid: the displacement distribution must keep
neighbouring nodes from wandering across the K=12 exclusion threshold R* = sqrt(2-sqrt2).

Inputs: ONLY eps, L, and the bond curvature kappa (eps/L^2). Mass fixed by the model's
single energy quantum, hbar*omega_max ~ eps is NOT imposed; instead we keep m as the unit
that makes the Debye/Einstein quantum dimensionless and report the rigidity condition as a
pure number on kappa. No tolerance, no Lindemann coefficient assumed.
"""
import numpy as np

L=1.0; eps=1.0; hbar=1.0; kB=1.0; T0=eps/kB

# 12 FCC nearest-neighbour vectors (unit length L)
nn=np.array([[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],[1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
             [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]],float)/np.sqrt(2)*L

# Central-force dynamical matrix: each bond contributes curvature kappa along its axis.
# D(q) = (kappa/m) * sum_d  (1 - cos(q.d)) * (d^ d^)   [3x3], d^ = unit bond vector
def Dmat(q,kappa,m):
    M=np.zeros((3,3))
    for d in nn:
        dh=d/np.linalg.norm(d)
        M+=(1-np.cos(np.dot(q,d)))*np.outer(dh,dh)
    return (kappa/m)*M

# Brillouin-zone average of <u^2> = (hbar/2) * <1/(m w) coth(hbar w/2kT)> summed over 3 pol.
# We set m=1; then omega in units sqrt(kappa). Report <u^2> as function of kappa.
def msd(kappa,m=1.0,Nq=14):
    # FCC conventional cubic reciprocal sampling over the BZ (a=sqrt2 L for unit nn)
    a=np.sqrt(2)*L
    qs=np.linspace(-np.pi/a,np.pi/a,Nq,endpoint=False)+ (np.pi/a)/Nq
    tot=0.0; cnt=0
    for qx in qs:
        for qy in qs:
            for qz in qs:
                q=np.array([qx,qy,qz])
                if np.allclose(q,0): continue
                w2,_=np.linalg.eigh(Dmat(q,kappa,m))
                w2=np.clip(w2,1e-9,None); w=np.sqrt(w2)
                for wi in w:
                    x=hbar*wi/(2*kB*T0)
                    tot+=(hbar/(2*m*wi))/np.tanh(x)   # <u^2> contribution per mode/3
                cnt+=1
    return tot/(3*cnt)*3   # average per cartesian -> total <u^2>; keep total

Rstar=np.sqrt(2-np.sqrt(2))
print("R* (K=12 exclusion threshold) = %.5f L"%Rstar)
print("Rigidity condition: nearest-neighbour separation L must not fluctuate below R*.")
print("Relative bond fluctuation sqrt(<du^2>) where du = projection of (u_i - u_j) on bond.")
print("Conservatively <du^2> ~ 2<u^2> (two independent nodes).  Need L - sqrt(2<u^2>) > R*.\n")
print(" kappa   sqrt<u^2>/L   bond_min=L-sqrt(2<u2>)   rigid(>R*)?")
sol=None
for kappa in [5,10,20,30,40,50,75,100,150,200]:
    u2=msd(kappa)
    rms=np.sqrt(u2)
    bondmin=L-np.sqrt(2*u2)
    rigid=bondmin>Rstar
    if rigid and sol is None: sol=kappa
    print("  %4d    %.4f        %.4f               %s"%(kappa,rms/L,bondmin,'YES' if rigid else 'no'))

print("\nThreshold: smallest kappa giving a self-consistently rigid K=12 lattice ~ %s eps/L^2"%sol)

# refine the threshold
lo,hi=(sol-10 if sol else 40), (sol if sol else 60)
for _ in range(30):
    mid=(lo+hi)/2; u2=msd(mid); bondmin=L-np.sqrt(2*u2)
    if bondmin>Rstar: hi=mid
    else: lo=mid
kappa_c=hi
u2=msd(kappa_c)
print("Refined kappa_c = %.2f eps/L^2  (RMS=%.4f L, bond_min=%.4f vs R*=%.4f)"%(
      kappa_c,np.sqrt(u2),L-np.sqrt(2*u2),Rstar))
print("\nINTERPRETATION:")
print(" - kappa_c is the DERIVED minimum binding stiffness for a rigid K=12 vacuum.")
print(" - It is a pure number x eps/L^2: the missing scale, fixed self-consistently.")
print(" - hbar*omega_max/eps at kappa_c (scale separation thermal vs rigidity):")
# max phonon freq at zone boundary
wmax=0
for q in [np.array([np.pi/np.sqrt(2),0,0]),np.array([np.pi/np.sqrt(2)]*3)/np.sqrt(3)*np.sqrt(2)]:
    w2,_=np.linalg.eigh(Dmat(q,kappa_c,1.0)); wmax=max(wmax,np.sqrt(max(w2)))
print("     omega_max ~ %.2f sqrt(eps/mL^2);  thermal/rigidity separation ~ kappa_c = %.0f"%(wmax,kappa_c))
