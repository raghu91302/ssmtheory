"""
SSM dynamics paper -- Sec. 18
Vector-phonon vibrational entropy FCC vs HCP (sign only; tiebreaker).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
rng=np.random.default_rng(2)
def recip(a1,a2,a3):
    V=np.dot(a1,np.cross(a2,a3)); return np.array([np.cross(a2,a3),np.cross(a3,a1),np.cross(a1,a2)])*2*np.pi/V
# FCC
a1=np.array([1,1,0.])/np.sqrt(2);a2=np.array([1,0,1.])/np.sqrt(2);a3=np.array([0,1,1.])/np.sqrt(2);Bf=recip(a1,a2,a3)
fcc_nn=[]
for A in [(1,1,0),(1,0,1),(0,1,1)]:
    nz=[i for i in range(3) if A[i]!=0]
    for s1 in(1,-1):
        for s2 in(1,-1):
            v=np.array(A,float);v[nz[0]]*=s1;v[nz[1]]*=s2;fcc_nn.append(v/np.sqrt(2))
fcc_nn=np.array(fcc_nn)
fcc_P=np.array([np.outer(d,d) for d in fcc_nn])   # n n^T (unit already)
# HCP
a=1.;c=a*np.sqrt(8/3)
h1=np.array([a,0,0]);h2=np.array([a/2,a*np.sqrt(3)/2,0]);h3=np.array([0,0,c]);Bh=recip(h1,h2,h3)
tau=[np.zeros(3),(1/3)*h1+(1/3)*h2+(1/2)*h3]
cells=[(i,j,k) for i in range(-2,3) for j in range(-2,3) for k in range(-2,3)]
nbr={0:[],1:[]}
for s in(0,1):
    for (i,j,k) in cells:
        R=i*h1+j*h2+k*h3
        for sp in(0,1):
            d=R+tau[sp]-tau[s]
            if abs(np.linalg.norm(d)-1)<0.02: nbr[s].append((sp,R,d))
for s in(0,1): assert len(nbr[s])==12
def K(d,kL,kT):
    P=np.outer(d,d); return kL*P+kT*(np.eye(3)-P)
def lnw_fcc(kpts,kL,kT,batch=20000):
    out=[]; mn=1e9
    Ks=np.array([K(d,kL,kT) for d in fcc_nn])           # (12,3,3)
    Ksum=Ks.sum(0)
    for s in range(0,len(kpts),batch):
        k=kpts[s:s+batch]                                # (b,3)
        ph=np.exp(1j*(k@fcc_nn.T))                       # (b,12)
        D=np.broadcast_to(Ksum,(len(k),3,3)).astype(complex).copy()
        D=D-np.einsum('bm,mij->bij',ph,Ks)
        D=(D+np.conj(np.transpose(D,(0,2,1))))/2
        w=np.linalg.eigvalsh(D); mn=min(mn,w.min())
        out.append(0.5*np.log(np.clip(w,1e-12,None)))
    return np.concatenate(out).mean(),mn
def lnw_hcp(kpts,kL,kT,batch=20000):
    out=[]; mn=1e9
    # precompute per-bond K and R for each sublattice
    data={s:[(sp,R,K(d,kL,kT)) for (sp,R,d) in nbr[s]] for s in(0,1)}
    Kself={s:sum(K(d,kL,kT) for (sp,R,d) in nbr[s]) for s in(0,1)}
    for st in range(0,len(kpts),batch):
        k=kpts[st:st+batch]; b=len(k)
        D=np.zeros((b,6,6),complex)
        for s in(0,1):
            D[:,3*s:3*s+3,3*s:3*s+3]+=Kself[s]
            for (sp,R,Kb) in data[s]:
                ph=np.exp(1j*(k@R))                      # (b,)
                D[:,3*s:3*s+3,3*sp:3*sp+3]-=ph[:,None,None]*Kb
        D=(D+np.conj(np.transpose(D,(0,2,1))))/2
        w=np.linalg.eigvalsh(D); mn=min(mn,w.min())
        out.append(0.5*np.log(np.clip(w,1e-12,None)))
    return np.concatenate(out).mean(),mn
M=120000
kf=rng.random((M,3))@Bf; kh=rng.random((M,3))@Bh
for (kL,kT) in [(1.0,0.0),(1.0,0.25),(1.0,0.5)]:
    mf,minf=lnw_fcc(kf,kL,kT); mh,minh=lnw_hcp(kh,kL,kT)
    dS=-(mf-mh)
    print(f"kT={kT}: <lnw> FCC={mf:.6f} HCP={mh:.6f}  S_FCC-S_HCP={dS:+.6f} kB/atom  "
          f"minw2(FCC={minf:.1e},HCP={minh:.1e}) -> {'FCC higher' if dS>0 else 'HCP higher'}")
print("(+ => FCC higher entropy/lower F => HCP->FCC downhill at T>0)")
