"""
SSM dynamics paper -- Sec. 3
Bulk-interior coordination diagnostic (>=42 neighbors within 2L).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

# Bulk-interior coordination diagnostic for the SSM kinematic lattice.
# A node is bulk-interior iff >=42 nodes lie within 2L (full FCC first three shells, 12+6+24).
# Reports all-node vs bulk-interior coordination; reproduces Table (finite-size scaling) bulk modal K=12.
# See 27_kinematic_substrate_sim.py for the growth algorithm.
