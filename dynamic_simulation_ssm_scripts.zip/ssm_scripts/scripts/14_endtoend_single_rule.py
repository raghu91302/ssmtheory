"""
ONE dynamics, end to end: Bell pair -> triangle -> sheet -> lift -> foam/branching -> front.
SINGLE fixed rule set, no per-stage switches. We test whether the SAME local rule that
nucleates a triangle also grows sheets, lifts, branches, and forms a K=12 front -- or whether
it breaks at a seam (nucleation, or foam->FCC).

THE SINGLE RULE (applied identically every step):
 - State: node positions. Bond if |xi-xj| in [Rb_lo,Rb_hi]. Exclusion |xi-xj|>=Rex.
 - BIRTH (sigma^+): pick a random existing bond OR triangle; propose a new node at a
   registered apex (stitch: equilateral apex on a bond, in the local plane; lift: tetra apex
   on a triangle). Accept iff exclusion satisfied. NO tuned lift rate: we PROPOSE both moves
   wherever geometrically available and let exclusion + the energy criterion decide.
 - DEATH (sigma^-): each node dissolves with prob dt*P_dissolve(K), K=its current degree,
   P_dissolve from q=1/(1+e). (the derived stability)
 - ACCEPT/REJECT births by the SAME energy rule everywhere: accept a birth with prob
   min(1, exp(beta*dE)), dE = -eps*(new bonds formed), beta*eps=1. (detailed balance, one T)
 This is ONE Metropolis-kinetic rule. We watch <K>, the bond network, and whether a coherent
 growing front with bulk K=12 emerges, or whether it glasses / stalls / blows up.
"""
import numpy as np
from scipy.spatial import cKDTree
from collections import Counter
np.random.seed(3)

L=1.0; Rex=0.95; Rb_lo,Rb_hi=0.90,1.10; q=1/(1+np.e); beta=1.0
def Pdiss(K):
    from math import comb
    if K<2: return 1.0
    return sum(comb(K,j)*q**j*(1-q)**(K-j) for j in range(K-2,K+1))

def bonds(P):
    t=cKDTree(P); adj=[set() for _ in range(len(P))]
    for i,j in t.query_pairs(Rb_hi):
        if Rb_lo<=np.linalg.norm(P[i]-P[j])<=Rb_hi:
            adj[i].add(j); adj[j].add(i)
    return adj,t

def tris(adj):
    T=[]
    for a in range(len(adj)):
        nb=[x for x in adj[a] if x>a]
        for i in range(len(nb)):
            for j in range(i+1,len(nb)):
                if nb[j] in adj[nb[i]]: T.append((a,nb[i],nb[j]))
    return T

def step(P, dt=0.5):
    P=list(P)
    adj,tree=bonds(np.array(P)); Tr=tris(adj)
    # ---- BIRTH: propose stitch and lift wherever available, accept by energy ----
    births=[]
    # stitch proposals: from boundary-ish bonds (pick random bonds)
    arr=np.array(P)
    bondlist=[(i,j) for i in range(len(P)) for j in adj[i] if j>i]
    np.random.shuffle(bondlist)
    for (i,j) in bondlist[:60]:
        A,B=arr[i],arr[j]; mid=(A+B)/2
        # in-plane apex: need a reference plane; use a neighbour to define it
        common=adj[i]|adj[j]
        ref=None
        for c in common:
            if c!=i and c!=j: ref=arr[c]; break
        if ref is None: 
            # free orientation: pick perpendicular in a random plane
            ab=(B-A)/np.linalg.norm(B-A); rnd=np.random.randn(3); perp=rnd-rnd.dot(ab)*ab; perp/=np.linalg.norm(perp)
        else:
            ab=(B-A)/np.linalg.norm(B-A); pc=ref-mid; perp=pc-pc.dot(ab)*ab
            if np.linalg.norm(perp)<1e-6: continue
            perp/=np.linalg.norm(perp); perp=-perp  # opposite side from ref (extend sheet)
        cand=mid+(np.sqrt(3)/2)*L*perp
        if tree.query(cand)[0]>=Rex:
            nb=np.sum((np.linalg.norm(arr-cand,axis=1)>=Rb_lo)&(np.linalg.norm(arr-cand,axis=1)<=Rb_hi))
            if np.random.rand()<min(1,np.exp(beta*nb)) and nb>=2: births.append(cand)
    # lift proposals: from triangles
    np.random.shuffle(Tr)
    for (a,b,c) in Tr[:60]:
        A,B,C=arr[a],arr[b],arr[c]; ctr=(A+B+C)/3
        n=np.cross(B-A,C-A); 
        if np.linalg.norm(n)<1e-6: continue
        n/=np.linalg.norm(n)
        for s in (1,-1):
            cand=ctr+s*np.sqrt(2/3)*L*n
            if tree.query(cand)[0]>=Rex:
                nb=np.sum((np.linalg.norm(arr-cand,axis=1)>=Rb_lo)&(np.linalg.norm(arr-cand,axis=1)<=Rb_hi))
                if np.random.rand()<min(1,np.exp(beta*nb)) and nb>=3: births.append(cand); break
    # add non-conflicting births
    for cand in births:
        if len(P)==0 or min(np.linalg.norm(np.array(P)-cand,axis=1))>=Rex:
            P.append(cand)
    # ---- DEATH ----
    arr=np.array(P); adj,_=bonds(arr)
    keep=[]
    for i in range(len(P)):
        K=len(adj[i])
        if np.random.rand()>=dt*Pdiss(K): keep.append(P[i])
    return keep

# seed: a Bell pair
P=[np.array([0,0,0.]),np.array([1,0,0.])]
hist=[]
for it in range(140):
    P=step(P)
    if len(P)<2: P=[np.array([0,0,0.]),np.array([1.,0,0])]  # re-nucleate if died out
    if it%14==0 or it==139:
        arr=np.array(P); adj,tree=bonds(arr)
        deg=np.array([len(a) for a in adj])
        cnt2=np.array([np.sum(np.linalg.norm(arr-arr[i],axis=1)<2*L)-1 for i in range(len(arr))]) if len(arr)<4000 else np.array([0])
        bulk=cnt2>=42
        bm=Counter(deg[bulk]).most_common(1)[0][0] if bulk.sum() else None
        hist.append((it,len(P),deg.mean() if len(deg) else 0,bulk.sum(),bm))
        print("it=%3d  N=%5d  <K>=%.2f  bulk_nodes=%4d  bulk_modal_K=%s"%(it,len(P),deg.mean() if len(deg) else 0,bulk.sum(),bm))

print("\n--- DIAGNOSIS ---")
Ns=[h[1] for h in hist]; Ks=[h[2] for h in hist]
print("final N=%d, final <K>=%.2f, final bulk_modal=%s"%(hist[-1][1],hist[-1][2],hist[-1][4]))
if hist[-1][2]<5.5: print("OUTCOME: GLASSED/STALLED (<K> stuck near foam ~5) -- breaks at foam->FCC seam.")
elif hist[-1][4]==12: print("OUTCOME: COHERENT -- reached bulk K=12 under one rule. Holds together.")
elif hist[-1][1]>3000: print("OUTCOME: ran away in N -- branching but check coordination.")
else: print("OUTCOME: partial -- grew past foam but did not reach bulk K=12; seam at sheet->bulk.")
