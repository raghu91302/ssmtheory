"""
SSM dynamics paper -- Sec. 3 (kinematic substrate)
Independent replication check of the published stitch-lift simulation.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
from scipy.spatial import cKDTree
from collections import defaultdict, Counter

L=1.0; REX=0.95*L; RB=1.05*L; PLIFT=np.exp(-3); H=np.sqrt(2/3)*L

def build(P):
    P=np.asarray(P); t=cKDTree(P); adj=defaultdict(set)
    for a,b in t.query_pairs(RB):
        adj[a].add(b); adj[b].add(a)
    return adj,t

def triangles(adj):
    tris=[]
    for a in adj:
        nb=[x for x in adj[a] if x>a]
        for i in range(len(nb)):
            for j in range(i+1,len(nb)):
                if nb[j] in adj[nb[i]]: tris.append((a,nb[i],nb[j]))
    return tris

def boundary_edges(adj,tris):
    cnt=Counter()
    for (a,b,c) in tris:
        for e in [(a,b),(a,c),(b,c)]: cnt[tuple(sorted(e))]+=1
    # third vertex for each boundary edge
    edge_tri={}
    for (a,b,c) in tris:
        for e in [(a,b),(a,c),(b,c)]:
            es=tuple(sorted(e)); third=[x for x in (a,b,c) if x not in es][0]
            edge_tri.setdefault(es,[]).append(third)
    return [e for e in cnt if cnt[e]==1], edge_tri

def grow(seed_rng, Ntarget=700, max_steps=60000):
    rng=np.random.default_rng(seed_rng)
    s=np.sqrt(3)/2
    P=[np.array([0,0,0.]),np.array([1,0,0.]),np.array([0.5,s,0.])]  # seed triangle, z=0
    steps=0
    while len(P)<Ntarget and steps<max_steps:
        steps+=1
        Parr=np.array(P); adj,tree=build(Parr); tris=triangles(adj)
        if not tris: break
        do_lift = rng.random()<PLIFT
        placed=False
        if do_lift:
            a,b,c=tris[rng.integers(len(tris))]
            A,B,C=Parr[a],Parr[b],Parr[c]; ctr=(A+B+C)/3
            n=np.cross(B-A,C-A); n/=np.linalg.norm(n)
            for sgn in ([1,-1] if rng.random()<0.5 else [-1,1]):
                cand=ctr+sgn*H*n
                if tree.query(cand)[0]>=REX: P.append(cand); placed=True; break
        if not placed:
            be,edge_tri=boundary_edges(adj,tris)
            if not be: continue
            e=be[rng.integers(len(be))]; a,b=e; A,B=Parr[a],Parr[b]
            c=Parr[edge_tri[e][0]]; mid=(A+B)/2
            ab=(B-A)/np.linalg.norm(B-A)
            perp=(c-mid)-np.dot(c-mid,ab)*ab
            if np.linalg.norm(perp)<1e-9: continue
            perp/=np.linalg.norm(perp)
            cand=mid-s*L*perp   # equilateral apex opposite c, in-plane
            if tree.query(cand)[0]>=REX: P.append(cand); placed=True
    return np.array(P)

def analyze(P):
    adj,tree=build(P); n=len(P)
    deg=np.array([len(adj[i]) for i in range(n)])
    # bulk-interior diagnostic: >=42 neighbors within 2L
    cnt2=np.array([len(tree.query_ball_point(P[i],2*L))-1 for i in range(n)])
    bulk=cnt2>=42
    return deg,bulk

def stacking(P):
    # group into layers by z (structure grows along a normal; use PCA to align)
    Pc=P-P.mean(0)
    # principal axis of smallest spread = stacking normal
    u,sng,vt=np.linalg.svd(Pc,full_matrices=False)
    normal=vt[2]  # smallest-variance direction
    zc=Pc@normal
    # cluster z into layers
    order=np.argsort(zc); zs=zc[order]
    layers=[]; cur=[order[0]]; 
    for k in range(1,len(zs)):
        if zs[k]-zs[k-1]>0.3*L: layers.append(cur); cur=[]
        cur.append(order[k])
    layers.append(cur)
    # in-plane basis from two largest-variance directions
    e1,e2=vt[0],vt[1]
    # for each layer compute mean fractional position in the triangular cell
    labels=[]
    for lay in layers:
        if len(lay)<5: labels.append('?'); continue
        xy=np.c_[Pc[lay]@e1, Pc[lay]@e2]
        # triangular lattice primitive vectors (edge L): a1=(1,0), a2=(1/2, sqrt3/2)
        a1=np.array([1,0.]); a2=np.array([0.5,np.sqrt(3)/2])
        M=np.linalg.inv(np.array([a1,a2]).T)
        frac=(xy@M.T)%1.0
        # cluster center -> nearest of 3 sublattice positions {(0,0),(1/3,2/3),(2/3,1/3)}
        cen=np.array([np.angle(np.exp(1j*2*np.pi*frac[:,d]).mean())/(2*np.pi)%1 for d in range(2)])
        cands={'A':np.array([0,0.]),'B':np.array([1/3,2/3]),'C':np.array([2/3,1/3])}
        lab=min(cands, key=lambda L_: min(np.linalg.norm((cen-cands[L_]-np.array([i,j]))%1.0)
                                          for i in (-1,0,1) for j in (-1,0,1)))
        labels.append(lab)
    return [x for x in labels if x!='?'], len(layers)

allK=[]; bulkmod=[]; k12frac=[]; seqs=[]
for sd in range(6):
    P=grow(sd, Ntarget=700)
    deg,bulk=analyze(P)
    allK.append(deg.mean()); k12frac.append(100*(deg==12).mean())
    if bulk.sum()>0: bulkmod.append(Counter(deg[bulk]).most_common(1)[0][0])
    seq,nlay=stacking(P)
    seqs.append("".join(seq))
print(f"N=700, 6 seeds (published params P_lift=e^-3, R_ex=0.95, R_b=1.05):")
print(f"  mean K (all)      = {np.mean(allK):.2f} +/- {np.std(allK):.2f}   [paper Table2 ~8.6-8.9]")
print(f"  K=12 frac (all)   = {np.mean(k12frac):.1f}% +/- {np.std(k12frac):.1f}   [paper ~22-25%]")
print(f"  BULK modal K      = {Counter(bulkmod).most_common()}   [paper claims 12]")
print(f"\n  STACKING sequences read from each seed (A/B/C layers):")
for i,s in enumerate(seqs): print(f"    seed {i}: {s}")
# classify each sequence
def classify(s):
    s=s.strip()
    if len(s)<3: return "too few layers"
    abab=all(s[i]==s[i+2] for i in range(len(s)-2))   # period-2 -> HCP
    abc =all(s[i]!=s[i+1] and s[i]!=s[i+2] and s[i+1]!=s[i+2] for i in range(len(s)-2)) # period-3 distinct -> FCC
    return "FCC(ABC)" if abc else ("HCP(ABAB)" if abab else "mixed/faulted")
print("\n  classification:")
for i,s in enumerate(seqs): print(f"    seed {i}: {s}  -> {classify(s)}")
