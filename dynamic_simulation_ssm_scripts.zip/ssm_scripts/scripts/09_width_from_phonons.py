"""
SSM dynamics paper -- Sec. 11
Bond-shell width from vibrational amplitude (shows the circularity).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np

L=1.0; eps=1.0; hbar=1.0; kB=1.0; T0=eps/kB

# Morse with RANGE = bond length (a*L = 1): the only choice with no extra scale.
a = 1.0/L
upp = 2*eps*a**2          # u''(L) = 2 eps a^2 = 2 eps/L^2
k_bond = upp              # = 2 eps/L^2
print("Non-tuned choice: Morse range = L  => a=1/L, k_bond=u''(L)=%.3f eps/L^2"%k_bond)

# per-axis effective spring in FCC: 12 bonds, <cos^2> per axis from S_uv=4delta:
# sum_j (n_j . e_x)^2 = S_xx = 4, so K_eff = k_bond * 4   (4 unit-bond projections per axis)
K_eff = 4*k_bond
print("Per-axis effective spring K_eff = 4 k_bond = %.3f eps/L^2"%K_eff)

# mass fixed by Einstein quantum = eps: hbar*omega_E = eps, omega_E=sqrt(K_eff/m)
# => m = K_eff hbar^2 / eps^2
m = K_eff*hbar**2/eps**2
omegaE=np.sqrt(K_eff/m)
print("Mass from hbar*omega_E=eps: m=%.3f ; omega_E=%.3f (hbar omega_E=%.3f=eps OK)"%(m,omegaE,hbar*omegaE))

# thermal+zero-point mean-square displacement per axis (quantum harmonic oscillator at T0):
# <x^2> = (hbar/(2 m omega)) coth(hbar omega / 2kT)
x=hbar*omegaE/(2*kB*T0)   # = 1/2 since hbar omegaE = eps = kT0
msd = (hbar/(2*m*omegaE))/np.tanh(x)
amp = np.sqrt(msd)
print("\n<x^2>=%.4f L^2 ; RMS amplitude sqrt<x^2> = %.4f L"%(msd,amp))
# bond-length fluctuation: a bond between two nodes each fluctuating -> sqrt(2)*amp projected
w_phys = np.sqrt(2)*amp     # half-width of the bond-length distribution in units of L
print("Derived bond-shell half-width w = sqrt(2)*amp = %.4f  (paper used ~0.05)"%w_phys)

# Now feed THIS w into the parameter-free capture-volume ratio (reuse the scaling we measured:
# ratio ~ C * w, with C fit from the clean scan). From ssm_lift_clean.py: ratio/w was ~const:
# at w=0.10 ratio=0.0902 -> C=0.902 ; at w=0.05 ratio=0.0453 -> C=0.906 ; use C=0.904
C=0.904
ratio_phys = C*w_phys
print("\n"+"="*60)
print("PHYSICAL lift/stitch ratio = C*w = %.4f  (C=%.3f from clean scan)"%(ratio_phys,C))
print("published e^-3            = %.4f"%np.exp(-3))
print("ratio of the two          = %.2f x"%(ratio_phys/np.exp(-3)))
print("="*60)
print("""
If w_phys lands near 0.05 -> e^-3 is RESCUED by physics (vibrational amplitude sets it).
If w_phys is far from 0.05 -> the PHYSICAL lift rate is C*w_phys, a DEFINITE number that
   REPLACES the paper's 5%, and the cascade's true terminal coordination must be re-derived.
""")
