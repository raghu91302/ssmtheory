"""
SSM dynamics paper -- Sec. 3 (kinematic substrate)
Full stitch-lift growth with proximity bonding; reproduces bulk modal K=12, scaling, R_ex plateau.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, networkx as nx, random, time
from scipy.spatial import cKDTree
from collections import Counter
UNIT_LENGTH=1.0; HARD_SHELL=0.95; BOND_RADIUS=1.05
LIFT_HEIGHT=np.sqrt(2.0/3.0); LATERAL_HEIGHT=np.sqrt(3.0)/2
class SSMSim:
    def __init__(self,target_nodes=5000,lift_prob=0.05,hard_shell=HARD_SHELL):
        self.target=target_nodes; self.lift_prob=lift_prob; self.hs=hard_shell
        self.nodes=[]; self.G=nx.Graph(); self.triangles=set()
        self.active_triangles=set(); self.active_edges=set(); self.buffer=[]
    def _add_node(self,pos):
        idx=len(self.nodes); self.nodes.append(np.array(pos,dtype=float))
        self.buffer.append(self.nodes[-1]); self.G.add_node(idx); return idx
    def _add_edge(self,u,v):
        if self.G.has_edge(u,v) or u==v: return
        self.G.add_edge(u,v); self.active_edges.add((min(u,v),max(u,v)))
        for w in (set(self.G.neighbors(u))&set(self.G.neighbors(v))):
            tri=tuple(sorted((u,v,w)))
            if tri not in self.triangles: self.triangles.add(tri); self.active_triangles.add(tri)
    def _proximity_stitch(self,tree):
        for u,v in tree.query_pairs(r=BOND_RADIUS):
            if not self.G.has_edge(u,v): self._add_edge(u,v)
    def _is_valid(self,cand,tree):
        if tree and tree.query_ball_point(cand,self.hs): return False
        for p in self.buffer:
            if np.linalg.norm(cand-p)<self.hs: return False
        return True
    def _stitch_lateral(self,edge,tree):
        u,v=edge; p1,p2=self.nodes[u],self.nodes[v]; mid=(p1+p2)/2.0
        att=[t for t in self.active_triangles if u in t and v in t]
        if att:
            w=[n for n in att[0] if n!=u and n!=v][0]; d=mid-self.nodes[w]
        else: d=np.cross(p2-p1,[0,0,1])
        norm=np.linalg.norm(d); d=d/norm if norm>0 else np.array([0.0,1.0,0.0])
        c1=mid+d*LATERAL_HEIGHT*UNIT_LENGTH; c2=mid-d*LATERAL_HEIGHT*UNIT_LENGTH
        v1=self._is_valid(c1,tree); v2=self._is_valid(c2,tree)
        if not v1 and not v2: self.active_edges.discard((min(u,v),max(u,v))); return False
        cand=c1 if v1 else c2; nid=self._add_node(cand); self._add_edge(nid,u); self._add_edge(nid,v); return True
    def _lift_triangle(self,tri,tree):
        u,v,w=tri; p0,p1,p2=self.nodes[u],self.nodes[v],self.nodes[w]
        centroid=(p0+p1+p2)/3.0; normal=np.cross(p1-p0,p2-p0); norm=np.linalg.norm(normal)
        if norm==0: self.active_triangles.discard(tri); return False
        normal/=norm; signs=[1,-1] if random.random()<0.5 else [-1,1]
        for s in signs:
            cand=centroid+normal*LIFT_HEIGHT*UNIT_LENGTH*s
            if self._is_valid(cand,tree):
                nid=self._add_node(cand); self._add_edge(nid,u); self._add_edge(nid,v); self._add_edge(nid,w); return True
        self.active_triangles.discard(tri); return False
    def run(self):
        self._add_node([0.,0.,0.]); self._add_node([UNIT_LENGTH,0.,0.]); self._add_node([0.5*UNIT_LENGTH,LATERAL_HEIGHT*UNIT_LENGTH,0.])
        self._add_edge(0,1); self._add_edge(1,2); self._add_edge(2,0)
        tree=cKDTree(self.nodes); self.buffer=[]; attempts=0
        while len(self.nodes)<self.target and attempts<500000:
            if len(self.buffer)>40:
                tree=cKDTree(self.nodes); self.buffer=[]; self._proximity_stitch(tree)
            can_lift=len(self.active_triangles)>0; can_stitch=len(self.active_edges)>0
            if random.random()<self.lift_prob and can_lift:
                ok=self._lift_triangle(random.choice(sorted(self.active_triangles)),tree)
            elif can_stitch:
                ok=self._stitch_lateral(random.choice(sorted(self.active_edges)),tree)
            else: ok=False
            attempts=0 if ok else attempts+1
        tree=cKDTree(self.nodes); self._proximity_stitch(tree); return self
    def bulk_stats(self):
        pos=np.array(self.nodes); deg=np.array([d for _,d in self.G.degree()])
        tree=cKDTree(pos); n2=tree.query_ball_point(pos,2.0,return_length=True)-1
        bulk=n2>=42; bm=Counter(deg[bulk].tolist()).most_common(1)[0][0] if bulk.sum() else None
        return dict(N=len(pos),meanK=deg.mean(),K12all=100*np.mean(deg==12),
                    nbulk=int(bulk.sum()),bulkmodal=bm,K12bulk=100*np.mean(deg[bulk]==12) if bulk.sum() else 0)

print("REAL published algorithm (SSMSim, proximity-bonding) -- scaling reproduction:")
print(" N     meanK   K12all%   nbulk   bulk_modal_K   K12bulk%")
for N in [500,750,1000]:
    random.seed(42); np.random.seed(42)
    s=SSMSim(N,0.05).run().bulk_stats()
    print(" %4d   %.2f    %.1f      %4d      %s            %.1f"%(s['N'],s['meanK'],s['K12all'],s['nbulk'],s['bulkmodal'],s['K12bulk']))
print("\npublished Table: N=1000 meanK=8.90, K12all=25.4%, bulk_modal=12, K12bulk=64.2%")
