"""
SSM dynamics paper -- Sec. 18
Rank-4 tensor (T_zzzz), bond-orientational order, monogamy vs codeability.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np
from scipy.special import sph_harm_y
# FCC cuboctahedron: 12 <110> directions
fcc=[]
for a in [(1,1,0),(1,0,1),(0,1,1)]:
    nz=[i for i in range(3) if a[i]!=0]
    for s1 in(1,-1):
        for s2 in(1,-1):
            v=np.array(a,float);v[nz[0]]*=s1;v[nz[1]]*=s2;fcc.append(v/np.sqrt(2))
fcc=np.array(fcc)
# HCP anticuboctahedron: 6 in-plane + 3 up + 3 down (eclipsed, ABA)
a=1.;h=np.sqrt(2/3)
inpl=np.array([[np.cos(np.pi/3*k),np.sin(np.pi/3*k),0] for k in range(6)])*a
low=np.array([[ (a/np.sqrt(3))*np.cos(np.pi/3*2*k+np.pi/6),(a/np.sqrt(3))*np.sin(np.pi/3*2*k+np.pi/6),-h] for k in range(3)])
up =np.array([[ (a/np.sqrt(3))*np.cos(np.pi/3*2*k+np.pi/6),(a/np.sqrt(3))*np.sin(np.pi/3*2*k+np.pi/6),+h] for k in range(3)])
hcp=np.vstack([inpl,low,up]); hcp=hcp/np.linalg.norm(hcp,axis=1,keepdims=True)
def Ql(N,l):
    th=np.arccos(np.clip(N[:,2],-1,1)); ph=np.arctan2(N[:,1],N[:,0])
    q=np.array([np.mean(sph_harm_y(l,m,th,ph)) for m in range(-l,l+1)])
    return np.sqrt(4*np.pi/(2*l+1)*np.sum(np.abs(q)**2))
def angle_energy(N,kind):
    G=np.clip(N@N.T,-1,1); iu=np.triu_indices(len(N),1); c=G[iu]
    if kind=="thomson":  return np.sum(1/np.sqrt(2-2*c+1e-9))      # 1/chord, repulsive
    if kind=="P2":       return np.sum(0.5*(3*c**2-1))             # quadrupole
    if kind=="P4":       return np.sum((35*c**4-30*c**2+3)/8)      # hexadecapole (rank-4)
    if kind=="LJ":       d=np.sqrt(2-2*c+1e-9); return np.sum(d**-12-d**-6)
print(f"{'measure':18}{'FCC cuboct':>14}{'HCP anticuboct':>16}{'  picks (min)':>14}")
for l in (4,6):
    qf,qh=Ql(fcc,l),Ql(hcp,l)
    print(f"Steinhardt Q{l:<6}{qf:14.4f}{qh:16.4f}{('FCC' if qf<qh else 'HCP'):>14}")
for k in ("thomson","P2","P4","LJ"):
    ef,eh=angle_energy(fcc,k),angle_energy(hcp,k)
    print(f"energy {k:<11}{ef:14.4f}{eh:16.4f}{('FCC' if ef<eh else 'HCP'):>14}")
# rank-4 anisotropy: deviation of 4th-moment tensor from isotropic, split cubic vs axial
def T4(N):
    T=np.einsum('ai,aj,ak,al->ijkl',N,N,N,N)
    return T
def aniso_parts(N):
    T=T4(N)
    # axial (preferred-axis) indicator: |Tzzzz - Txxxx|; cubic indicator: |Txxxx - 3 Txxyy|
    ax=abs(T[2,2,2,2]-T[0,0,0,0])
    cub=abs(T[0,0,0,0]-3*T[0,0,1,1])
    return ax,cub
af,cf=aniso_parts(fcc); ah,ch=aniso_parts(hcp)
print(f"\nrank-4 AXIAL term |Tzzzz-Txxxx|:  FCC={af:.4f}  HCP={ah:.4f}  (SO(3)-breaking; FCC must be ~0)")
print(f"rank-4 CUBIC term |Txxxx-3Txxyy|: FCC={cf:.4f}  HCP={ch:.4f}  (harmless lattice anisotropy)")
print("""
KEY: total anisotropy MAGNITUDE (Q4,Q6) and the harmless cubic term can be LARGER for FCC.
What is uniquely ~0 for FCC is the AXIAL (preferred-direction) term. So 'minimize anisotropy
magnitude' does NOT pick FCC; only 'kill the preferred-axis term' does -- a SYMMETRY-TYPE
criterion, not a magnitude to minimize.""")
