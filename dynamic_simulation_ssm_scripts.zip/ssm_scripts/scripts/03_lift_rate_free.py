"""
Honest, parameter-free attempt. Strip ALL invented scales. The question:
does the geometric capture-ratio of a codim-3 (lift) vs codim-2 (stitch) target
have a parameter-FREE value, or does it always carry a width w?

A sigma^+ jump captures a node into a registered apex if the node lands within the
bonding shell. The RATE ~ (measure of landing configs that bond) / (measure of all
approach configs). We compute this WITHOUT choosing w, by integrating over the actual
accessible configuration volume set ONLY by the bond geometry (bond forms in [R_ex,R_b]
= [0.95,1.05], the ONE window the model already fixes -- but we will SCAN it to see if
the ratio is robust or knob-dependent).
"""
import numpy as np
from scipy import integrate

L=1.0
# bond shell: a node bonds to an anchor if its distance is in [rb_lo, rb_hi].
# We compute the VOLUME of positions where a new node simultaneously bonds to the
# required anchors (2 for stitch, 3 for lift), normalized by a common reference,
# and take the ratio. This is pure geometry; the only input is the shell half-width w.

def stitch_volume(w, n=240):
    # 2 anchors at (+-0.5,0,0); node bonds to both if both distances in [1-w,1+w].
    lo,hi=1-w,1+w
    rng=1.6
    xs=np.linspace(-rng,rng,n); ys=np.linspace(-rng,rng,n); zs=np.linspace(-rng,rng,n)
    dx=xs[1]-xs[0]
    A1=np.array([-0.5,0,0]); A2=np.array([0.5,0,0])
    vol=0.0
    X,Y=np.meshgrid(xs,ys,indexing='ij')
    for z in zs:
        d1=np.sqrt((X-A1[0])**2+(Y-A1[1])**2+(z-A1[2])**2)
        d2=np.sqrt((X-A2[0])**2+(Y-A2[1])**2+(z-A2[2])**2)
        vol+=np.sum((d1>=lo)&(d1<=hi)&(d2>=lo)&(d2<=hi))*dx**3
    return vol

def lift_volume(w, n=240):
    lo,hi=1-w,1+w
    R=L/np.sqrt(3)
    T=np.array([[R*np.cos(a),R*np.sin(a),0] for a in [np.pi/2,np.pi/2+2*np.pi/3,np.pi/2+4*np.pi/3]])
    rng=1.6
    xs=np.linspace(-rng,rng,n); ys=np.linspace(-rng,rng,n); zs=np.linspace(-rng,rng,n)
    dx=xs[1]-xs[0]
    vol=0.0
    X,Y=np.meshgrid(xs,ys,indexing='ij')
    for z in zs:
        ok=np.ones_like(X,dtype=bool)
        for v in T:
            d=np.sqrt((X-v[0])**2+(Y-v[1])**2+(z-v[2])**2)
            ok&=(d>=lo)&(d<=hi)
        vol+=np.sum(ok)*dx**3
    return vol

print("scan bond-shell half-width w -> is lift/stitch volume ratio robust?")
print(" w     V_stitch   V_lift    ratio    -ln(ratio)")
for w in [0.15,0.10,0.075,0.05,0.03]:
    vs=stitch_volume(w); vl=lift_volume(w)
    r=vl/vs if vs>0 else np.nan
    print(f" {w:.3f}  {vs:.5f}   {vl:.6f}  {r:.4f}   {-np.log(r):.3f}")
print(f"\n e^-3 = {np.exp(-3):.4f}  (-ln = 3.000)")
print("""
READING:
 If 'ratio' stays ~constant as w shrinks -> a parameter-free number exists (and we read it).
 If 'ratio' scales with w (ratio ~ w^1, so -ln(ratio) grows as w shrinks) -> NO parameter-free
   value; the codim difference is exactly one power of w, and 'e^-3' is just the value at
   the particular w the paper chose. That would CONFIRM e^-3 is tuned, not physical.
""")
