"""
REFRAME: K=12 is the REQUIRED terminus (it IS the kissing number / close packing).
We do NOT tune lift rate. Instead we ask: is there a stiffness kappa (the missing scale,
= bond curvature in units of eps/L^2) such that the cascade ROBUSTLY terminates at K=12
for a RANGE of lift rates? If so, kappa is the physical parameter, and lift rate is free.

Mechanism that enforces K=12 without tuning: HARD-CORE EXCLUSION.
A node at unit distance to a K-coordinated site: once 12 neighbors fill the cuboctahedral
shell, NO 13th position exists at distance >= R_ex from all 12 (kissing number bound, proven).
So K=12 termination is GEOMETRIC, automatic, for ANY lift rate -- PROVIDED the exclusion
radius R_ex is in the window that (a) forbids a 13th neighbor but (b) allows all 12.
THAT window is set by stiffness: R_ex is where the bond potential turns from attractive
(r>R_ex bonds) to hard (r<R_ex excluded). We compute the R_ex window for K=12 robustness,
then show the terminus is lift-rate-INDEPENDENT inside it.
"""
import numpy as np
from itertools import combinations

L=1.0
# the 12 FCC nearest-neighbor directions (cuboctahedral shell)
nn=np.array([[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],
             [1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
             [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]],float)/np.sqrt(2)*L

# Q1: with all 12 shell sites filled, what is the closest distance between any two shell
# neighbors? A 13th node would have to sit at unit distance from center AND >=R_ex from all 12.
d_nn = np.array([np.linalg.norm(a-b) for a,b in combinations(nn,2)])
print("12-shell: min neighbor-neighbor distance = %.4f L (=L, the kissing contacts)"%d_nn.min())

# minimum gap on the unit sphere between shell sites (angular): nearest shell sites are at 60 deg
cosmin=max(np.dot(a,b)/L**2 for a,b in combinations(nn,2) if not np.allclose(a,b))
print("max cos between shell dirs = %.4f -> min angular sep = %.2f deg"%(cosmin,np.degrees(np.arccos(cosmin))))

# A would-be 13th node at unit distance from center: best it can do is the center of the
# largest 'hole' in the 12-point cuboctahedral arrangement on the sphere. Find max-min distance.
from scipy.optimize import minimize
def neg_min_dist(angles):
    th,ph=angles
    p=np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])*L
    return -min(np.linalg.norm(p-s) for s in nn)
best=0; bestp=None
for _ in range(4000):
    a0=[np.arccos(1-2*np.random.rand()),2*np.pi*np.random.rand()]
    r=minimize(neg_min_dist,a0,method='Nelder-Mead',options={'xatol':1e-4,'fatol':1e-4})
    if -r.fun>best: best=-r.fun; bestp=r.x
print("\nlargest hole: a 13th node at unit dist is at most %.4f L from its nearest shell node"%best)
print(" => any exclusion R_ex > %.4f L forbids a 13th neighbor (K=12 is FORCED)"%best)

# Q2: lower bound -- R_ex must not forbid the 12 themselves. Shell sites are mutually >= L apart
print(" => any exclusion R_ex < %.4f L allows all 12 (they sit at mutual distance L)"%d_nn.min())
print("\n"+"="*64)
print("K=12 ROBUSTNESS WINDOW:  %.4f L  <  R_ex  <  %.4f L"%(best,d_nn.min()))
print("="*64)
print("""width of window = %.4f L. INSIDE it, the kissing-number theorem forbids a 13th
neighbor while permitting all 12 -> the cascade terminates at K=12 GEOMETRICALLY,
for ANY lift rate. Lift rate is free; the physical parameter is R_ex in this window."""%(d_nn.min()-best))

# Q3: connect R_ex window to STIFFNESS. R_ex is where bond potential turns hard.
# For a potential of curvature kappa (eps/L^2) and depth eps, the classical turning point
# at thermal energy kT0=eps below the well sits at r where u(r)-u(L)=eps. For Morse range b:
# we INVERT: what curvature places the turning point inside the [best, 1] window?
print("\nStiffness that places the hard turn R_ex inside the window:")
for kappa in [2,5,10,20,50,100]:
    b=np.sqrt(kappa/(2))   # Morse a from u''=2 eps a^2 = kappa -> a=sqrt(kappa/2)
    # turning point where u(r)=u(L)+eps i.e. (1-e^{-a(r-L)})^2 -1 = 0 ... = 0 -> r where well rises by eps
    # (1-e^{-a(R-L)})^2 = 1 -> e^{-a(R-L)}=0 (r>>L) hot side; cold side 2: (1-e^{-a(R-L)})^2=1 -> R<L:
    # e^{-a(R-L)} = 2 -> R = L - ln(2)/a
    Rin = L - np.log(2)/b
    inwin = best < Rin < d_nn.min()
    print(f"  kappa={kappa:3d} eps/L^2 -> a={b:.2f}, R_ex(turn)={Rin:.4f} L  {'INSIDE window' if inwin else 'outside'}")
