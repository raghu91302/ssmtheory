import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":10.5,"font.family":"serif","mathtext.fontset":"cm",
                     "savefig.dpi":300,"savefig.bbox":"tight"})

# FIG A: robustness sweep -- K=12 generic across temperature (from ssm_sweep.py results)
beta=np.array([0.4,0.7,1.0,1.5,2.0,3.0]); t=1/beta
frac12=np.array([1.0,1.0,1.0,1.0,1.0,0.75])   # fraction of 4 seeds reaching bulk modal K=12
meanK=np.array([8.53,8.91,9.18,9.08,8.89,7.83])
fig,ax=plt.subplots(figsize=(5.2,3.2))
ax.plot(t,frac12*100,"o-",c="#2e7d32",ms=8,lw=1.6,label="bulk reaches $K{=}12$ (\\% of seeds)")
ax.axvline(1.0,ls=":",c="#c0504d"); ax.text(1.02,40,"$q=1/(1+e)$\noperating point",fontsize=8,c="#c0504d")
ax.set_xlabel("reduced bath temperature $t=k_BT/\\varepsilon$"); ax.set_ylabel("$K{=}12$ success (\\%)",color="#2e7d32")
ax.set_ylim(0,108); ax.set_xlim(0.28,2.7)
ax2=ax.twinx(); ax2.plot(t,meanK,"s--",c="#1f4e79",ms=5,lw=1,alpha=0.6); ax2.set_ylabel("$\\langle K\\rangle$",color="#1f4e79"); ax2.set_ylim(5,12)
ax.set_title("$K{=}12$ is generic across temperature (single end-to-end rule)",fontsize=9.5)
ax.legend(fontsize=8,loc="lower center")
plt.savefig("fig_robustness.pdf"); plt.close()

# FIG B: branching exponential growth + graceful exit (from ssm_branching2.py)
e=np.e; q=1/(1+e); v2=(1-2*q)*(np.sqrt(3)/2); h=np.sqrt(2/3)
def run(p,Vf,tmax,dt=0.5):
    sigma=p; N=1.0;R=0.0;A=np.pi*0.25;Vc=A*h; T=[];V=[];tt=0
    while tt<tmax:
        ff=max(0,1-Vc/Vf); S=sigma*A*ff
        N+=S*dt; R+=v2*N*dt; A+=(2*np.pi*v2*R+np.pi*0.25*S)*dt; Vc=min(A*h,Vf); tt+=dt
        if not T or tt-T[-1]>=2: T.append(tt);V.append(Vc)
        if ff<=0: T.append(tt);V.append(Vc);break
    return np.array(T),np.array(V)
fig,ax=plt.subplots(figsize=(5.2,3.2))
for p,c in [(0.005,"#7030a0"),(0.0005,"#1f4e79")]:
    T,V=run(p,1e9,300); ax.semilogy(T,V,lw=1.8,c=c,label="lift amp $p=%.4f$"%p)
ax.axhline(1e9,ls="--",c="#c0504d",lw=1.2,label="foam reservoir (exit)")
ax.set_xlabel("time $/\\tau_0$"); ax.set_ylabel("crystallized volume $V(t)$")
ax.set_title("Branching growth: exponential, self-terminating",fontsize=9.5)
ax.legend(fontsize=8,loc="lower right"); ax.set_ylim(1,3e9)
plt.savefig("fig_branching.pdf"); plt.close()
print("fig_robustness.pdf, fig_branching.pdf written")
