"""
SSM dynamics paper -- Figures (Sec. 6,16,8)
Generates the signal-cone, energy-ladder, and growth figures.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from math import log
plt.rcParams.update({"font.size":11,"font.family":"serif","mathtext.fontset":"cm",
 "axes.linewidth":0.8,"savefig.dpi":300,"savefig.bbox":"tight"})
C={"cp":"#1f4e79","foam":"#c0504d","sheet":"#2e7d32","tri":"#7030a0","gray":"#9aa0a6"}

# FIG A: emergent light cone (real-time evolution under the kinetic term)
P=np.load("lightcone_P.npy"); t=np.load("lightcone_t.npy"); N=P.shape[1]; x0=N//2
x=(np.arange(N)-x0)
fig,ax=plt.subplots(figsize=(5.4,3.8))
im=ax.imshow(np.log10(P+1e-6),origin="lower",aspect="auto",cmap="magma",
   extent=[x.min(),x.max(),t.min(),t.max()],vmin=-5,vmax=-0.5)
# light-cone lines v=2 l_lat eps/hbar
ax.plot([0,2*t.max()],[0,t.max()],"--",color="cyan",lw=1.0)
ax.plot([0,-2*t.max()],[0,t.max()],"--",color="cyan",lw=1.0)
ax.text(60,70,"$v=2\\,\\ell_{\\rm lat}\\varepsilon/\\hbar$",color="cyan",fontsize=9)
ax.set_xlim(x.min(),x.max())
ax.set_xlabel("position $x\\,/\\,\\ell_{\\rm lat}$"); ax.set_ylabel("time $t\\,/\\,(\\hbar/\\varepsilon)$")
ax.set_title("Emergent light cone from real-time evolution")
cb=fig.colorbar(im,ax=ax,fraction=0.046,pad=0.04); cb.set_label("$\\log_{10}|\\psi|^2$",fontsize=9)
plt.savefig("cap_fig_lightcone.pdf"); plt.close()

# FIG B: the ladder in physical energy units (eps)
fig,ax=plt.subplots(figsize=(6.4,3.9))
pts={"tri":(0,-1.0),"sheet":(1,-3.0),"foam":(2,-1.63),"cp":(3,-7.0)}
xr=[1,1.5,2.5,3]; yr=[-3.0,-4.5,-6.0,-7.0]
ax.plot(xr,yr,"-",color=C["cp"],lw=2.0,zorder=2,label="registered path: $K\\,6\\!\\to\\!9\\!\\to\\!12$, downhill")
ax.plot([1,2,3],[-3.0,-1.63,-7.0],"--",color=C["foam"],lw=1.6,zorder=2,label="unregistered: through foam barrier (glass)")
labs={"tri":"triangle\n$K{=}2$","sheet":"hex sheet\n$K{=}6$ (2D max)","foam":"foam\n$K{=}4$ (barrier)","cp":"close pack\n$K{=}12$ (3D min)"}
cols={"tri":C["tri"],"sheet":C["sheet"],"foam":C["foam"],"cp":C["cp"]}
for k,(xx,yy) in pts.items():
    ax.scatter([xx],[yy],s=130,color=cols[k],edgecolor="k",zorder=5)
    dy=0.55 if k in("foam","cp") else -0.9; va="bottom" if dy>0 else "top"
    ax.annotate(labs[k],(xx,yy),xytext=(xx,yy+dy),ha="center",va=va,fontsize=8.5,color=cols[k])
ax.text(1.5,-2.05,"$+1.37\\,\\varepsilon$",ha="center",fontsize=8.5,color=C["foam"])
ax.set_xlabel("assembly coordinate"); ax.set_ylabel("energy per node  ($\\varepsilon$)")
ax.set_ylim(-7.8,-0.2); ax.set_xlim(-0.4,3.7)
ax.set_title("Energy ladder (units of the binding scale $\\varepsilon$)")
ax.legend(frameon=False,fontsize=8.5,loc="lower left"); ax.spines[["top","right"]].set_visible(False)
plt.savefig("cap_fig_ladder.pdf"); plt.close()

# FIG C: growth to K=12 in physical time (tau0 = hbar/eps)
fig,ax=plt.subplots(figsize=(5.6,3.7))
cyc=np.array([0,10,20,30,40,50,59]); kcore=[8.0,9.55,9.0,9.06,9.50,9.50,9.14]
tau=cyc  # 1 cycle ~ 1 tau0
ax.plot(tau,kcore,"o-",color=C["cp"],ms=4,lw=1.5,label="derived stability $q=1/(1{+}e)$")
ax.axhline(12,ls=":",c=C["cp"],lw=0.8); ax.text(22,12.2,"$K=12$ reached",fontsize=8.5,color=C["cp"])
ax.axhline(5.4,ls="--",c=C["gray"],lw=1.0); ax.text(22,5.6,"foam $\\langle K\\rangle\\approx5.4$",fontsize=8.5,color="#666")
ax.annotate("triangle\nnucleates",(0,8.0),xytext=(6,6.4),fontsize=8,color=C["tri"],
            arrowprops=dict(arrowstyle="->",color=C["tri"],lw=0.8))
ax.set_xlabel("time  $t\\,/\\,\\tau_0$    ($\\tau_0=\\hbar/\\varepsilon\\approx4\\,t_{\\rm Planck}$)")
ax.set_ylabel("core coordination $\\langle K\\rangle_{\\rm core}$")
ax.set_ylim(3,12.8); ax.legend(frameon=False,fontsize=8.5,loc="center right")
ax.set_title("Nucleation to $K=12$ in physical time")
ax.spines[["top","right"]].set_visible(False)
plt.savefig("cap_fig_growth.pdf"); plt.close()
print("capstone figures written:",[f for f in __import__("os").listdir(".") if f.startswith("cap_fig")])
