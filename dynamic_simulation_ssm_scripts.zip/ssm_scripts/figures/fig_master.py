import matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.size":11,"font.family":"serif","mathtext.fontset":"cm","savefig.dpi":300,"savefig.bbox":"tight"})
fig,ax=plt.subplots(figsize=(7.2,3.4)); ax.axis("off"); ax.set_xlim(0,10); ax.set_ylim(0,5)
C={"cp":"#1f4e79","coh":"#2e7d32","dis":"#c0504d"}
# central box: master equation
box=FancyBboxPatch((3.1,3.2),3.8,1.4,boxstyle="round,pad=0.1",fc="#eef2f7",ec=C["cp"],lw=1.4)
ax.add_patch(box)
ax.text(5.0,4.15,"Lindblad master equation",ha="center",fontsize=11,color=C["cp"],weight="bold")
ax.text(5.0,3.55,r"$\dot\rho=-\frac{i}{\hbar}[H,\rho]+\sum_b(\gamma_\uparrow\mathcal{D}[\sigma^+_b]+\gamma_\downarrow\mathcal{D}[\sigma^-_b])\rho$",ha="center",fontsize=10.5)
# left limit: coherent
lb=FancyBboxPatch((0.2,0.4),3.2,1.9,boxstyle="round,pad=0.08",fc="#eef7ee",ec=C["coh"],lw=1.2); ax.add_patch(lb)
ax.text(1.8,1.95,"coherent limit",ha="center",fontsize=10,color=C["coh"],weight="bold")
ax.text(1.8,1.45,r"bath off: $\dot\rho=-\frac{i}{\hbar}[H,\rho]$",ha="center",fontsize=9)
ax.text(1.8,0.95,"unitary evolution",ha="center",fontsize=9)
ax.text(1.8,0.6,r"$\Rightarrow$ light cone, $v=2\ell_{\rm lat}\varepsilon/\hbar$",ha="center",fontsize=9,color=C["coh"])
# right limit: dissipative
rb=FancyBboxPatch((6.6,0.4),3.2,1.9,boxstyle="round,pad=0.08",fc="#f7eeee",ec=C["dis"],lw=1.2); ax.add_patch(rb)
ax.text(8.2,1.95,"dissipative limit",ha="center",fontsize=10,color=C["dis"],weight="bold")
ax.text(8.2,1.45,r"thermal jumps at $T_0=\varepsilon/k_B$",ha="center",fontsize=9)
ax.text(8.2,0.95,"quantum-trajectory assembly",ha="center",fontsize=9)
ax.text(8.2,0.6,r"$\Rightarrow$ growth, $q=\frac{1}{1+e}$",ha="center",fontsize=9,color=C["dis"])
ax.add_patch(FancyArrowPatch((3.6,3.2),(1.9,2.35),arrowstyle="-|>",mutation_scale=14,color=C["coh"],lw=1.3))
ax.add_patch(FancyArrowPatch((6.4,3.2),(8.1,2.35),arrowstyle="-|>",mutation_scale=14,color=C["dis"],lw=1.3))
ax.text(5.0,2.55,"one dynamics, two limits",ha="center",fontsize=9.5,style="italic",color="#555")
plt.savefig("cap_fig_master.pdf"); plt.close(); print("master-equation schematic written")
