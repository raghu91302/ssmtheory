"""
SSM dynamics paper -- Figure (cascade)
Generates the kinematic cascade figure.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
plt.rcParams.update({"font.size":10.5,"font.family":"serif","mathtext.fontset":"cm","savefig.dpi":300,"savefig.bbox":"tight"})
fig,ax=plt.subplots(figsize=(7.6,3.0)); ax.axis("off"); ax.set_xlim(0,12); ax.set_ylim(0,4)
C=["#7030a0","#2e7d32","#c0504d","#1f4e79"]
stages=[("Bell pair","$K=1$","nucleation",0.9),
        ("hex sheet","$K=6$","stitch (2D)",3.4),
        ("tetra foam","$K=4$","lift, frustrated",6.2),
        ("FCC bulk","$K=12$","interlock (ABC)",9.4)]
for (name,k,op,x),c in zip(stages,C):
    ax.add_patch(plt.Circle((x,2.4),0.62,color=c,alpha=0.9,ec="k",lw=1))
    ax.text(x,2.4,k,ha="center",va="center",color="white",fontsize=11,weight="bold")
    ax.text(x,1.45,name,ha="center",fontsize=9.5,color=c,weight="bold")
    ax.text(x,0.95,op,ha="center",fontsize=8.5,color="#555",style="italic")
for i in range(3):
    x0=stages[i][3]+0.7; x1=stages[i+1][3]-0.7
    ax.add_patch(FancyArrowPatch((x0,2.4),(x1,2.4),arrowstyle="-|>",mutation_scale=15,color="#333",lw=1.3))
ax.text((stages[0][3]+stages[1][3])/2,2.95,"$P_{\\rm stitch}$",ha="center",fontsize=8.5)
ax.text((stages[1][3]+stages[2][3])/2,2.95,"$P_{\\rm lift}=e^{-3}$",ha="center",fontsize=8.5,color=C[2])
ax.text((stages[2][3]+stages[3][3])/2,2.95,"Regge $\\delta$ relaxes",ha="center",fontsize=8.5,color=C[3])
ax.text(6,3.7,"Kinematic cascade (Kulkarni 2026): nucleation $\\to$ $K=12$ at the Kepler bound",
        ha="center",fontsize=10,weight="bold")
ax.text(9.4,3.55,"",ha="center")
plt.savefig("cap_fig_cascade.pdf"); plt.close(); print("cascade figure written")
