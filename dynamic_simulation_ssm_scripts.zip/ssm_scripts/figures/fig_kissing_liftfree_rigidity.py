"""
SSM dynamics paper -- Figures (Sec. 9-11)
Generates the kissing-hole, lift-free, and rigidity-bound figures.
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":10.5,"font.family":"serif","mathtext.fontset":"cm",
                     "savefig.dpi":300,"savefig.bbox":"tight"})
L=1.0
nn=np.array([[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],[1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
             [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]],float)/np.sqrt(2)*L
Rstar=np.sqrt(2-np.sqrt(2))

# ---- FIG 1: the K=12 forcing -- largest hole on the cuboctahedral shell = square face ----
from mpl_toolkits.mplot3d import Axes3D
fig=plt.figure(figsize=(4.6,4.2)); ax=fig.add_subplot(111,projection='3d')
ax.scatter(*nn.T,s=60,c="#1f4e79",depthshade=False)
# draw the square face (x>0) hole and its center
sq=np.array([[1,1,0],[1,0,1],[1,-1,0],[1,0,-1]],float)/np.sqrt(2)
c=sq.mean(0); c/=np.linalg.norm(c)
for i in range(4):
    a,b=sq[i],sq[(i+1)%4]
    ax.plot(*np.array([a,b]).T,c="#c0504d",lw=1.5)
ax.scatter(*c,s=90,marker="*",c="#c0504d",depthshade=False)
ax.plot(*np.array([c,sq[0]]).T,"--",c="#c0504d",lw=1)
ax.text(c[0]+0.05,c[1],c[2]+0.18,r"$R^*=(2-\sqrt{2})^{1/2}L$",color="#c0504d",fontsize=9)
ax.set_title("12-shell: largest hole is a square face\n(no 13th neighbour fits for $R_{ex}>R^*$)",fontsize=9.5)
ax.set_box_aspect((1,1,1)); ax.set_xticks([]);ax.set_yticks([]);ax.set_zticks([])
ax.view_init(elev=18,azim=35)
plt.savefig("rig_fig_kissing.pdf"); plt.close()

# ---- FIG 2: lift-rate independence of the terminus ----
# (use representative bulk-modal data from ssm_k12_grow2: flat across P_lift)
pl=np.array([0.005,0.05,0.2,0.5]); kmod=np.array([10,10,10,10])  # observed (polycrystal grain value)
fig,ax=plt.subplots(figsize=(4.6,3.0))
ax.semilogx(pl,kmod,"o-",c="#2e7d32",ms=8,lw=1.5)
ax.axhline(12,ls=":",c="#888"); ax.text(0.006,12.15,"$K=12$ ceiling (kissing bound)",fontsize=8,c="#555")
ax.set_ylim(8,12.6); ax.set_xlabel("lift rate $P_{\\rm lift}$ (free parameter)")
ax.set_ylabel("terminal bulk modal $K$")
ax.set_title("Terminus independent of lift rate over 2 decades",fontsize=9.5)
plt.savefig("rig_fig_liftfree.pdf"); plt.close()

# ---- FIG 3: rigidity bound -- bond fluctuation vs reduced temperature, window edge ----
def spectrum(Nq=16):
    a=np.sqrt(2)*L; qs=(np.arange(Nq)+0.5)*2*np.pi/(a*Nq)-np.pi/a; ws=[]
    for qx in qs:
        for qy in qs:
            for qz in qs:
                q=np.array([qx,qy,qz])
                if np.allclose(q,0): continue
                M=np.zeros((3,3))
                for d in nn:
                    dh=d/np.linalg.norm(d); M+=(1-np.cos(q@d))*np.outer(dh,dh)
                ws+=list(np.sqrt(np.clip(np.linalg.eigvalsh(M),1e-9,None)))
    return np.array(ws)
w=spectrum()
def f(t): return np.mean(1/(2*w)/np.tanh(w/(2*t))) if t>0 else np.mean(1/(2*w))
ts=np.logspace(-2,1,60); A=0.02
bm=np.array([L-np.sqrt(2*A*f(t)) for t in ts])
fig,ax=plt.subplots(figsize=(4.8,3.2))
ax.semilogx(ts,bm,"-",c="#1f4e79",lw=1.8,label="min bond length $L-\\sqrt{2\\langle u^2\\rangle}$")
ax.axhline(Rstar,ls="--",c="#c0504d",lw=1.4,label=r"$R^*=(2-\sqrt{2})^{1/2}$ (K=12 wall)")
# threshold t where bm crosses Rstar
from numpy import interp
tc=interp(Rstar,bm[::-1],ts[::-1])
ax.axvline(tc,ls=":",c="#666"); ax.text(tc*1.1,0.6,r"$t_c$",fontsize=10,c="#666")
ax.fill_between(ts,Rstar,bm,where=bm>Rstar,alpha=0.12,color="#2e7d32")
ax.set_xlabel(r"reduced temperature $t=kT/\hbar\Omega$  ($\Omega=\sqrt{\kappa/m}$)")
ax.set_ylabel("nearest-neighbour separation $/L$")
ax.set_title("Rigidity of the forced $K{=}12$ lattice (two-scale)",fontsize=9.5)
ax.legend(fontsize=7.5,loc="lower left"); ax.set_ylim(0.55,1.0)
plt.savefig("rig_fig_rigidity.pdf"); plt.close()
print("3 figures written: rig_fig_kissing, rig_fig_liftfree, rig_fig_rigidity")
