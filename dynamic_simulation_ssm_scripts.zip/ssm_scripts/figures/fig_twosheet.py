"""
SSM dynamics paper -- Figure (Sec. 3): two-sheet foam deficit + seeding registration.
Left: five regular tetrahedra about a hinge leaving the exact Regge gap delta=7.36 deg
(frame held rigid by the code stabilizers; relaxation would give a larger, variable deficit).
Right: each lifted apex caps one up-triangle (3 bonds, regular tetra); the apexes are
mutually equidistant (unit spacing), forming the next regular sheet -> registration is regular.
See README.md for the full script-to-section map.
"""
