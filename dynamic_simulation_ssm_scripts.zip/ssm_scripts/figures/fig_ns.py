"""
SSM dynamics paper -- Figure (Sec. 14)
Generates the spectral-index figure (superseded; kept for reference).
Paper: 'The Complete Dynamics of the Close-Packed Vacuum' (R. Kulkarni).
See README.md for the full script-to-section map.
"""

import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":10.5,"font.family":"serif","mathtext.fontset":"cm",
                     "savefig.dpi":300,"savefig.bbox":"tight"})
delta=2*np.pi-5*np.arccos(1/3); zeta=delta/(2*np.pi)
# candidate transfer coefficients and the curvature-placement each corresponds to
cands=[("per-edge kick\n$2/\\sqrt{3}$",2/np.sqrt(3),"#888"),
       ("3-family avg\n$4/3$",4/3,"#888"),
       ("Regge face-weight\n$\\sqrt{3}$",np.sqrt(3),"#1f4e79"),
       ("area density\n$4/\\sqrt{3}$",4/np.sqrt(3),"#888")]
fig,ax=plt.subplots(figsize=(5.6,3.3))
planck=0.9649; err=0.0042
ax.axhspan(planck-err,planck+err,color="#2e7d32",alpha=0.18,zorder=0)
ax.axhline(planck,color="#2e7d32",lw=1.2,zorder=1)
ax.text(3.6,planck+err+0.0015,"Planck 2018\n$n_s=0.9649\\pm0.0042$",fontsize=8,color="#2e7d32",ha="right")
for i,(lab,C,col) in enumerate(cands):
    ns=1-C*zeta
    ax.plot(i,ns,"o",ms=11,color=col,zorder=3)
    ax.annotate(lab,(i,ns),xytext=(0,-30 if col=="#888" else 14),textcoords="offset points",
                ha="center",fontsize=8,color=col,
                fontweight=("bold" if col!="#888" else "normal"))
    ax.text(i,ns+0.0016 if col!="#888" else ns+0.0016,"%.4f"%ns,ha="center",fontsize=8,color=col)
ax.set_xlim(-0.6,3.6); ax.set_ylim(0.948,0.982)
ax.set_xticks([]); ax.set_ylabel("$n_s = 1-C\\,(\\delta/2\\pi)$")
ax.set_title("Only the Regge face-weighted coefficient $\\sqrt{3}$ lands on Planck",fontsize=9.8)
plt.savefig("fig_ns.pdf"); plt.close()
print("fig_ns.pdf written; sqrt3 -> n_s=%.4f (Planck 0.9649+/-0.0042)"%(1-np.sqrt(3)*zeta))
