# Selection-Stitch Vacuum: Dynamics from Nucleation to K=12

Computational scripts backing the paper
**"The Complete Dynamics of the Close-Packed Vacuum: From Bell-Pair Nucleation to a Forced K=12
Terminus"** (R. Kulkarni, SSMTheory Group).

Every numerical claim in the paper is reproducible from the scripts below. Each script is
self-contained (standard scientific-Python stack) and prints its key results to stdout.

## Requirements
```
python >= 3.9
numpy
scipy
matplotlib   # figure scripts only
```
Install: `pip install numpy scipy matplotlib`

## How results map to the paper

Scripts are numbered in the order they appear in the paper's argument.

| script | backs |
|---|---|
| `scripts/01_k12_forced_Rstar.py` | Sec 8: K=12 forced terminus; R*=sqrt(2-sqrt2)L (exact, kissing-number) |
| `scripts/02_k12_growth_check.py` | Sec 8/9: growth check, terminus vs lift rate and exclusion window |
| `scripts/03_lift_rate_free.py` | Sec 9: lift rate is free; capture-volume ratio ~ w, no fixed value |
| `scripts/04_lift_rate_kinetic_attempt.py` | Sec 9: kinetic TST attempt to derive lift rate (shows it is not parameter-free) |
| `scripts/05_lift_rate_codimension.py` | Sec 9: codimension/measure analysis of lift vs stitch |
| `scripts/06_rigidity_two_scale.py` | Sec 10: two-scale rigidity; kT/(kappa L^2)<0.028, zero-point floor 14.8 |
| `scripts/07_rigidity_phonon_selfconsistent.py` | Sec 10: FCC phonon spectrum, self-consistent <u^2> (single-scale fails) |
| `scripts/08_stiffness_window.py` | Sec 10: exclusion/stiffness window for forced K=12 |
| `scripts/09_width_from_phonons.py` | Sec 10: bond-shell width from vibrational amplitude (shows circularity) |
| `scripts/10_construction_velocity.py` | Sec 11: in-plane build speed v2D=(1-2q)(sqrt3/2)v_lat; dimension analysis |
| `scripts/11_branching_exponential_growth.py` | Sec 12: branching moment eqns; V(t)~exp(Gamma t), Gamma ~ p^(1/3), foam exit |
| `scripts/12_branching_first_model.py` | Sec 12: first (per-sheet) branching model (superseded by moment version) |
| `scripts/13_branching_power_spectrum.py` | Sec 12: spatial power spectrum of branching process (n~-3.3, red) |
| `scripts/14_endtoend_single_rule.py` | Sec 13: single fixed-rule run Bell pair -> bulk K=12 (coherence) |
| `scripts/15_endtoend_robustness_sweep.py` | Sec 13: temperature x seed sweep; K=12 generic (robustness) |
| `scripts/16_published_sim_replication.py` | Sec 2: replication attempt of the published stitch-lift simulation |
| `scripts/17_bulk_diagnostic_check.py` | Sec 2/9: bulk diagnostic on ideal FCC & HCP (stacking-blindness) |
| `scripts/18_lightcone_dynamical.py` | Sec 5: dynamical Hamiltonian, single-excitation signal cone v=2v_lat |
| `scripts/19_derived_stability_q.py` | Sec 6: q=1/(1+e) detailed-balance stability; P_dissolve(K) ladder |
| `scripts/20_fcc_vs_hcp_degeneracy.py` | Sec 16: FCC/HCP local-measure degeneracy |
| `scripts/21_fcc_vs_hcp_global.py` | Sec 16: global code-rate / distance degeneracy |
| `scripts/22_fcc_hcp_rank4_monogamy.py` | Sec 16: rank-4 tensor (T_zzzz), bond-orientational, monogamy vs codeability |
| `scripts/23_vibrational_entropy_fcc_hcp.py` | Sec 16: vector-phonon vibrational entropy FCC vs HCP (tiebreaker, sign only) |
| `scripts/24_css_code_192_130_3.py` | Sec 15: [[192,130,3]] CSS code construction & verification |

## Figure generators

| script | produces |
|---|---|
| `figures/fig_master.py` | Figure: Lindblad two-limit schematic |
| `figures/fig_cascade.py` | Figure: kinematic cascade |
| `figures/fig_kissing_liftfree_rigidity.py` | Figures: kissing hole, lift-free, rigidity bound |
| `figures/fig_robustness_branching.py` | Figures: robustness sweep, branching growth |
| `figures/fig_lightcone_ladder_growth.py` | Figures: light cone, energy ladder, growth |

## Key results and where to find them

- **K=12 is a forced terminus** (theorem-level). `scripts/01_k12_forced_Rstar.py` computes the
  exact exclusion threshold R* = sqrt(2 - sqrt(2)) L (the cuboctahedral square-face hole), below
  which a 13th neighbour intrudes and above which all 12 are admitted.

- **The lift rate is free** (no derivable value). `scripts/03_lift_rate_free.py` shows the
  lift/stitch capture-volume ratio scales as one power of the bond-shell width w with no plateau,
  so the published e^-3 is the value at one chosen tolerance, not a constant.
  `scripts/04_lift_rate_kinetic_attempt.py` and `05_lift_rate_codimension.py` are the
  (unsuccessful, honestly reported) attempts to derive a fixed value.

- **The rigidity scale** (derived bound). `scripts/06_rigidity_two_scale.py` gives the requirement
  kT/(kappa L^2) < 0.028 (a >~36x separation) and the zero-point floor sqrt(kappa m) L^2/hbar > 14.8,
  from the real FCC phonon spectrum. `07_*` shows the single-scale model melts.

- **Derived stability** q = 1/(1+e). `scripts/19_derived_stability_q.py` (detailed-balance ratio,
  no free parameter) and the dissolution ladder P_dissolve(K).

- **End-to-end coherence and robustness** (derived + tested). `scripts/14_endtoend_single_rule.py`
  carries a bare Bell pair to bulk K=12 under one fixed rule; `15_endtoend_robustness_sweep.py`
  shows K=12 is generic across a factor-of-eight temperature range.

- **Branching exponential growth** (speculative, geometric analogue of inflation).
  `scripts/11_branching_exponential_growth.py` (V(t) ~ exp(Gamma t), Gamma ~ p^(1/3),
  self-terminating on foam depletion); `13_branching_power_spectrum.py` shows the raw clustering
  spectrum is steeply red (n ~ -3.3), NOT the observed n_s ~ 0.965 -- the honest caveat.

- **Single-excitation signal cone**: `scripts/18_lightcone_dynamical.py` (v = 2 v_lat, c = 4 v_lat).

- **FCC over HCP**: `20`-`23` (local degeneracy, rank-4 isotropy, monogamy vs codeability,
  vibrational-entropy tiebreaker -- sign robust, magnitude small).

- **CSS code**: `scripts/24_css_code_192_130_3.py` ([[192,130,3]], H_X H_Z^T = 0, d=3).

## Confidence tiers (as labeled in the paper)
- **(T) theorem-level**: forced K=12 terminus, R* (script 01).
- **(D) derived + robustly tested**: q=1/(1+e), end-to-end assembly (14, 15, 19).
- **(C) consistent but separately grounded**: signal cone, rigidity bounds (06, 18).
- **(S) speculative, with stated gaps**: branching/inflation analogue (11, 13).

## Notes
- Several scripts are stochastic (assembly, sweep, branching); rerun for statistics.
- The published stitch-lift simulation itself (ssm_sim.py) is from Kulkarni, Phys. Open 27 (2026)
  100423; scripts 16-17 here are independent replication/diagnostic checks, not that code.
- Scripts print results; figure scripts write PDFs into `figures/`.
