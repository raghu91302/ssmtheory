#!/usr/bin/env python3
"""SU(2) pure gauge theory on the D4 lattice with the single-coupling triangular
Wilson action  S = beta * sum_triangles [1 - (1/2) Re Tr U_tri].
Heat-bath (Creutz) updates, vectorized per link-direction class (links of one
class never share a triangle).  Observables: average triangle, rectangular
Wilson loops in planes spanned by orthogonal nearest-neighbour vectors, and
the Creutz ratio chi(R,T) -> sigma * l^2 with l the link length.
SU(2) elements are stored as quaternions (a0, a1, a2, a3), |a| = 1.
"""
import numpy as np, itertools, sys, time

L = int(sys.argv[1]) if len(sys.argv) > 1 else 6
rng = np.random.default_rng(1)

# ---------------------------------------------------------------- lattice
NN = [v for v in itertools.product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]      # 24 vectors
POS = [v for v in NN if v > tuple(-x for x in v)]                                        # 12 canonical directions
POS = sorted(POS)
dir_index = {}
for i, v in enumerate(POS):
    dir_index[v] = (i, +1); dir_index[tuple(-x for x in v)] = (i, -1)
sites = np.array([p for p in itertools.product(range(L), repeat=4) if sum(p) % 2 == 0])
N = len(sites)
site_id = {tuple(p): i for i, p in enumerate(sites)}
def shift(d):
    """array mapping site index -> index of site + d"""
    return np.array([site_id[tuple((sites[i] + d) % L)] for i in range(N)])
SH = {v: shift(v) for v in NN}
# triangles through link direction d: third vertex x+e with e in NN, e != d, d-e in NN
tri_of = {}
for d in POS:
    tri_of[d] = [e for e in NN if e != d and tuple(np.array(d) - e) in set(NN)]
    assert len(tri_of[d]) == 8
n_tri = N * 12 * 8 // 3
print(f"D4 lattice L={L}: {N} sites, {12*N} links, {n_tri} triangles, 8 triangles per link")

# ---------------------------------------------------------------- SU(2) quaternion algebra
def qmul(a, b):
    a0, a1, a2, a3 = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    b0, b1, b2, b3 = b[..., 0], b[..., 1], b[..., 2], b[..., 3]
    return np.stack([a0*b0 - a1*b1 - a2*b2 - a3*b3,
                     a0*b1 + a1*b0 + a2*b3 - a3*b2,
                     a0*b2 - a1*b3 + a2*b0 + a3*b1,
                     a0*b3 + a1*b2 - a2*b1 + a3*b0], axis=-1)
def qconj(a):
    return a * np.array([1, -1, -1, -1])
def link(U, x_idx, v):
    """U on the link from site x to x+v (v any of the 24), as quaternion array over x_idx"""
    i, s = dir_index[v]
    if s > 0: return U[i][x_idx]
    return qconj(U[i][SH[v][x_idx]])   # link from x to x-|v| is the inverse of the link at x-|v| in +direction

# ---------------------------------------------------------------- staples and heat bath
def staple_sum(U, d):
    """for every site x: sum over the 8 triangles of  U(x+d -> x+e) U(x+e -> x)"""
    idx = np.arange(N); xd = SH[d]
    W = np.zeros((N, 4))
    for e in tri_of[d]:
        e_minus_d = tuple(np.array(e) - d); xe = SH[e]
        W += qmul(link(U, xd, e_minus_d), link(U, xe, tuple(-np.array(e))))
    return W
def heatbath(U, d, beta):
    """Creutz heat bath: new U ~ exp(beta/2 Re Tr(U W)); W = k * Wbar with Wbar in SU(2)"""
    W = staple_sum(U, d)
    k = np.sqrt((W**2).sum(-1)); Wbar = W / k[:, None]
    # sample a0 from  P(a0) ~ sqrt(1-a0^2) exp(beta k a0), a0 in [-1,1]   (Creutz rejection)
    bk = beta * k
    a0 = np.empty(N); todo = np.ones(N, bool)
    while todo.any():
        n = todo.sum()
        # Creutz: x = 1 + ln(r)/(beta k) is exp(beta k x)-distributed; accept with prob sqrt(1-x^2)
        r = rng.random(n); x = 1 + np.log(r + 1e-300) / bk[todo]
        acc = (x > -1) & (rng.random(n) < np.sqrt(np.clip(1 - x*x, 0, 1)))
        ids = np.nonzero(todo)[0][acc]; a0[ids] = x[acc]; todo[ids] = False
    # random direction for the vector part
    r = np.sqrt(1 - a0**2)
    ct = 2 * rng.random(N) - 1; st = np.sqrt(1 - ct**2); ph = 2 * np.pi * rng.random(N)
    A = np.stack([a0, r*st*np.cos(ph), r*st*np.sin(ph), r*ct], axis=-1)
    U[dir_index[d][0]] = qmul(A, qconj(Wbar))    # U = A Wbar^{-1} so that U W = k A
def sweep(U, beta):
    for d in POS: heatbath(U, d, beta)

# ---------------------------------------------------------------- observables
def avg_triangle(U):
    tot = 0.0; cnt = 0
    for d in POS:
        W = staple_sum(U, d)                     # sum over 8 triangles of the two other links
        P = qmul(U[dir_index[d][0]], W)          # sum over triangles of U_tri
        tot += P[:, 0].sum(); cnt += 8 * N       # Re Tr / 2 = a0
    return tot / cnt   # every triangle is counted once from each of its 3 links; cnt = 96 N = 3 n_tri
def wilson_loop(U, u, v, R, T):
    """rectangular loop R steps along u then T along v then back; u,v orthogonal NN vectors"""
    idx = np.arange(N); x = idx.copy()
    P = np.tile(np.array([1.0, 0, 0, 0]), (N, 1))
    for _ in range(R): P = qmul(P, link(U, x, u)); x = SH[u][x]
    for _ in range(T): P = qmul(P, link(U, x, v)); x = SH[v][x]
    mu = tuple(-np.array(u)); mv = tuple(-np.array(v))
    for _ in range(R): P = qmul(P, link(U, x, mu)); x = SH[mu][x]
    for _ in range(T): P = qmul(P, link(U, x, mv)); x = SH[mv][x]
    return P[:, 0].mean()
planes = [((1,1,0,0), (-1,1,0,0)), ((1,0,1,0), (-1,0,1,0)), ((0,1,1,0), (0,-1,1,0)), ((0,0,1,1), (0,0,-1,1))]
def loops(U, Rmax=3):
    Wl = {}
    for R in range(1, Rmax+1):
        for T in range(1, Rmax+1):
            Wl[(R, T)] = np.mean([wilson_loop(U, u, v, R, T) for u, v in planes])
    return Wl

# ---------------------------------------------------------------- run
betas = [float(b) for b in sys.argv[2].split(",")] if len(sys.argv) > 2 else [1.0, 1.5, 2.0, 2.3, 2.6, 3.0]
n_therm, n_meas, gap = 100, 50, 2
print(f"\n{'beta':>5s} {'<tri>':>8s} {'strong-c. beta/4':>17s} {'W(1,1)':>8s} {'W(2,2)':>8s} {'W(3,3)':>8s} {'chi(2,2)':>9s} {'chi(3,3)':>9s}  time")
for beta in betas:
    t0 = time.time()
    U = [np.tile(np.array([1.0, 0, 0, 0]), (N, 1)) for _ in POS]      # cold start
    for _ in range(n_therm): sweep(U, beta)
    acc = {}; tri = []
    for m in range(n_meas):
        for _ in range(gap): sweep(U, beta)
        tri.append(avg_triangle(U))
        for k, w in loops(U).items(): acc.setdefault(k, []).append(w)
    W = {k: np.mean(v) for k, v in acc.items()}
    def chi(R, T):
        num = W[(R, T)] * W[(R-1, T-1)]; den = W[(R, T-1)] * W[(R-1, T)]
        return -np.log(num / den) if num > 0 and den > 0 else float('nan')
    print(f"{beta:5.2f} {np.mean(tri):8.4f} {beta/4:17.4f} {W[(1,1)]:8.4f} {W[(2,2)]:8.4f} {W[(3,3)]:8.4f} {chi(2,2):9.4f} {chi(3,3):9.4f}  {time.time()-t0:5.0f}s")
