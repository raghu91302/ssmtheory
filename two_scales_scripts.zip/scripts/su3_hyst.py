import numpy as np, sys
b=float(sys.argv[1]); sys.argv=["x","6",str(b),"1","1"]; exec(open("su3_d4.py").read().split('if __name__ == "__main__":')[0])
def series(hot, nsw):
    if hot:
        U=[]
        for _ in POS:
            A=rng.normal(size=(N,3,3))+1j*rng.normal(size=(N,3,3)); q,r=np.linalg.qr(A); d=np.linalg.det(q); U.append(q/(d**(1/3))[:,None,None])
    else:
        U=[np.tile(np.eye(3,dtype=complex),(N,1,1)) for _ in POS]
    out=[]
    for s in range(nsw):
        sweep(U)
        if s%10==9: reunitarize(U)
        if s%20==19: out.append(avg_tri(U))
    return out
c=series(False,260); h=series(True,260)
print(f"beta={b}: <tri> every 20 sweeps")
print("  cold:", np.round(c,3).tolist())
print("  hot :", np.round(h,3).tolist())
print(f"  last-100-sweep means: cold {np.mean(c[-5:]):.4f}  hot {np.mean(h[-5:]):.4f}")
