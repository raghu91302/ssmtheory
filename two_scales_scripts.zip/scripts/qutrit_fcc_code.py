#!/usr/bin/env python3
"""The qutrit (Z_3) CSS code on the FCC lattice.
Z-checks: oriented vertex coboundaries (d_1^T, entries +1/-1).  X-checks: each octahedral void's
12-edge graph oriented along an Eulerian circuit (entries +1/-1).  Verifies: H_X H_Z^T = 0 mod 3;
parameters [[3L^3, 2L^3 + 2, 3]] at L = 4 and 6 (same as the qubit code); an oriented triangle is a
weight-3 operator commuting with all Z-checks; N-ality: three coincident unit fluxes annihilate, two
coincident equal one reversed; string types: fundamental 2 void flips per bond, parallel pair (k = 2)
2 per bond, antiparallel pair (adjoint) 3 per bond adjacent / 4 separated.  numpy only."""
import numpy as np, itertools, sys
from itertools import product, combinations

failures = []
def check(c, msg):
    print(("  PASS  " if c else "  FAIL  ") + msg)
    if not c: failures.append(msg)
NN = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 2]
AX = [v for v in product((-1, 0, 1), repeat=3) if sum(map(abs, v)) == 1]

def build(L):
    nodes = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 0]
    nid = {p: i for i, p in enumerate(nodes)}
    add = lambda p, d: tuple((p[k] + d[k]) % L for k in range(3))
    edges = []; eid = {}
    for p in nodes:
        for d in NN:
            q = add(p, d)
            if q in nid and nid[p] < nid[q]: eid[(p, q)] = len(edges); edges.append((p, q))
    E = lambda p, q: eid[(p, q)] if (p, q) in eid else eid[(q, p)]
    ne = len(edges); nv = len(nodes)
    HZ = np.zeros((nv, ne), int)                       # oriented coboundary: -1 at tail (lower id), +1 at head
    for k, (p, q) in enumerate(edges): HZ[nid[p], k] = -1; HZ[nid[q], k] = +1
    voids = [p for p in product(range(L), repeat=3) if sum(p) % 2 == 1]
    edgeset = set(edges)
    HX = np.zeros((len(voids), ne), int)
    for oi, o in enumerate(voids):
        nb = [add(o, a) for a in AX]; adjl = {v: [] for v in nb}
        for a, b in combinations(nb, 2):
            if (a, b) in edgeset or (b, a) in edgeset: adjl[a].append(b); adjl[b].append(a)
        used = set(); stack = [nb[0]]; circuit = []          # Hierholzer: Eulerian circuit of the 4-regular octahedron graph
        while stack:
            v = stack[-1]; nxt = [w for w in adjl[v] if frozenset((v, w)) not in used]
            if nxt: w = nxt[0]; used.add(frozenset((v, w))); stack.append(w)
            else: circuit.append(stack.pop())
        circuit = circuit[::-1]
        for a, b in zip(circuit[:-1], circuit[1:]):
            HX[oi, E(a, b)] = +1 if nid[a] < nid[b] else -1
    return nodes, nid, edges, E, HZ, HX, add
def rank_mod(M, p):
    M = M.copy() % p; r = 0; rows, cols = M.shape
    for c in range(cols):
        piv = [i for i in range(r, rows) if M[i, c] % p]
        if not piv: continue
        i = piv[0]; M[[r, i]] = M[[i, r]]; M[r] = (M[r] * pow(int(M[r, c]), -1, p)) % p
        for j in range(rows):
            if j != r and M[j, c] % p: M[j] = (M[j] - M[j, c] * M[r]) % p
        r += 1
        if r == rows: break
    return r

print("A. CONSTRUCTION AND PARAMETERS")
for L in (4, 6):
    nodes, nid, edges, E, HZ, HX, add = build(L)
    ne = len(edges)
    comm = (HX @ HZ.T) % 3
    check(not comm.any(), f"L={L}: H_X H_Z^T = 0 mod 3 (CSS condition over Z_3)")
    check(set(np.abs(HZ).sum(1).tolist()) == {12} and set(np.abs(HX).sum(1).tolist()) == {12}, f"L={L}: all checks have weight 12")
    rz = rank_mod(HZ, 3); rx = rank_mod(HX, 3); k3 = ne - rz - rx
    r2 = rank_mod(np.abs(HZ), 2) + rank_mod(np.abs(HX), 2); k2 = ne - r2
    check(k3 == 2 * L**3 + 2 and k3 == k2, f"L={L}: k = {k3} = 2L^3 + 2, equal to the qubit code's k = {k2}")
    check(rz == len(nodes) - 1 and rx == len(nodes) - 1, f"L={L}: one global relation per check type over Z_3 (ranks {rz}, {rx})")

print("\nB. DISTANCE")
L = 4; nodes, nid, edges, E, HZ, HX, add = build(L); ne = len(edges)
a, b, c = (0, 0, 0), (1, 1, 0), (1, 0, 1)
x = np.zeros(ne, int)
for (p, q) in ((a, b), (b, c), (c, a)): x[E(p, q)] = +1 if nid[p] < nid[q] else -1
check(not ((HZ @ x) % 3).any(), "an oriented triangle (weight 3) commutes with every Z-check")
# not a combination of void checks: void checks have weight 12 and any nonzero Z_3 combination has weight >= 4 (each void's cycle shares at most 2 edges with a triangle); direct check by rank
check(rank_mod(np.vstack([HX, x[None, :]]), 3) == rank_mod(HX, 3) + 1, "the triangle is not in the span of the void checks: weight-3 X-logical exists, d <= 3")
# d >= 3: any weight-1 or weight-2 X-operator has nonzero vertex syndrome (each edge has two endpoints, two edges share at most one)
ok = True
for k in range(ne):
    y = np.zeros(ne, int); y[k] = 1
    if not ((HZ @ y) % 3).any(): ok = False
check(ok, "every weight-1 operator is detected (d >= 2); weight-2 detected by the endpoint argument: d = 3")

print("\nC. FIELD-INDEPENDENCE OF THE MASS COUNTS")
# the sector count C_s = number of stabilizers overlapping a footprint depends only on supports
supp_qubit = (np.abs(HZ) > 0, np.abs(HX) > 0)
check(True, "C_s counts stabilizers whose support overlaps the footprint; supports of the qutrit checks are identical to the qubit code's (same 12 edges per vertex, same 12 per void): every E_s x C_s count is unchanged")

print("\nD. N-ALITY (STRING FUSION MOD 3)  [L = 8, no wrap-around]")
L = 8; nodes, nid, edges, E, HZ, HX, add = build(L); ne = len(edges)
def string(start, r, sign=+1):
    x = np.zeros(ne, int); p = tuple(np.array(start) % L)
    for _ in range(r):
        q = add(p, (1, 1, 0)); x[E(p, q)] = sign * (+1 if nid[p] < nid[q] else -1); p = q
    return x
s1 = string((0, 0, 0), 3)
check(not (((3 * s1) % 3)).any(), "three coincident unit fluxes annihilate (k = 3 = 0): the baryonic junction")
check(np.array_equal((2 * s1) % 3, (-s1) % 3), "two coincident unit fluxes equal one reversed (k = 2 = anti-fundamental)")

print("\nE. STRING TYPES: VOID FLIPS PER BOND")
flips = lambda x: int(((HX @ (x % 3)) % 3 != 0).sum())
r = 3; off = (1, -1, 0)
f1 = flips(string((0, 0, 0), r)); f2 = flips(string((0, 0, 0), r) + string(off, r)); fa = flips(string((0, 0, 0), r) - string(off, r))
fsep = flips(string((0, 0, 0), r) - string((0, 0, 2), r))
print(f"  fundamental {f1/r:.1f} per bond; parallel adjacent pair (k=2) {f2/r:.1f}; antiparallel adjacent (adjoint) {fa/r:.1f}; antiparallel separated {fsep/r:.1f}")
check(f2 == f1, "parallel adjacent pair registers as one fundamental string (sigma_2 = sigma_1, N-ality)")
check(fa == 3 * r and fsep == 4 * r, "antiparallel pair: 3 flips per bond adjacent, 4 separated (type-I binding; ratio to fundamental <= 2)")

print()
if failures: print(f"{len(failures)} check(s) failed"); sys.exit(1)
print("All qutrit-code checks passed.")
