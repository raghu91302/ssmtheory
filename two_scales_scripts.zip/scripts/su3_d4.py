#!/usr/bin/env python3
"""SU(3) pure gauge on the D4 lattice, triangular Wilson action
S = beta * sum_tri [1 - (1/3) Re Tr U_tri], Cabibbo-Marinari heat bath (three SU(2)
subgroups, Creutz SU(2) heat bath), vectorized per link-direction class.
Usage: python3 su3_d4.py L beta n_therm n_meas outfile   (saves configurations)"""
import numpy as np, itertools, sys, time, pickle

L = int(sys.argv[1]); beta = float(sys.argv[2]); n_therm = int(sys.argv[3]); n_meas = int(sys.argv[4])
out = sys.argv[5] if len(sys.argv) > 5 else None
rng = np.random.default_rng(int(sys.argv[6]) if len(sys.argv) > 6 else 7)
NN = [v for v in itertools.product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
POS = sorted(v for v in NN if v > tuple(-x for x in v))
dir_index = {}
for i, v in enumerate(POS): dir_index[v] = (i, +1); dir_index[tuple(-x for x in v)] = (i, -1)
sites = np.array([p for p in itertools.product(range(L), repeat=4) if sum(p) % 2 == 0]); N = len(sites)
site_id = {tuple(p): i for i, p in enumerate(sites)}
SH = {v: np.array([site_id[tuple((sites[i] + v) % L)] for i in range(N)]) for v in NN}
NNset = set(NN)
tri_of = {d: [e for e in NN if e != d and tuple(np.array(d) - e) in NNset] for d in POS}

def dag(U): return np.conj(np.swapaxes(U, -1, -2))
def link(U, x, v):
    i, s = dir_index[v]
    return U[i][x] if s > 0 else dag(U[i][SH[v][x]])
def staple_sum(U, d):
    x = np.arange(N); xd = SH[d]; W = np.zeros((N, 3, 3), complex)
    for e in tri_of[d]:
        W += link(U, xd, tuple(np.array(e) - d)) @ link(U, SH[e], tuple(-np.array(e)))
    return W
def su2_heatbath(a, b, c, d, bk):
    """Given the SU(2) subblock parameters of k*Wbar (as quaternion Wbar with weight k in bk = beta*k),
    return a new SU(2) quaternion distributed ~ exp(bk a0). Creutz method."""
    n = len(bk); a0 = np.empty(n); todo = np.ones(n, bool)
    while todo.any():
        m = todo.sum(); r = rng.random(m); x = 1 + np.log(r + 1e-300) / bk[todo]
        acc = (x > -1) & (rng.random(m) < np.sqrt(np.clip(1 - x*x, 0, 1)))
        ids = np.nonzero(todo)[0][acc]; a0[ids] = x[acc]; todo[ids] = False
    rr = np.sqrt(1 - a0**2); ct = 2*rng.random(n) - 1; st = np.sqrt(1 - ct**2); ph = 2*np.pi*rng.random(n)
    return np.stack([a0, rr*st*np.cos(ph), rr*st*np.sin(ph), rr*ct], -1)
def quat_to_su2(q):
    a0, a1, a2, a3 = q[:, 0], q[:, 1], q[:, 2], q[:, 3]
    M = np.zeros((len(q), 2, 2), complex)
    M[:, 0, 0] = a0 + 1j*a3; M[:, 0, 1] = a2 + 1j*a1; M[:, 1, 0] = -a2 + 1j*a1; M[:, 1, 1] = a0 - 1j*a3
    return M
SUBS = [(0, 1), (0, 2), (1, 2)]
def heatbath(U, d):
    i = dir_index[d][0]
    for (p, q) in SUBS:
        W = staple_sum(U, d)                      # sum of 8 staples: action term (beta/3) Re Tr(U W)
        M = U[i] @ W                              # 3x3
        # SU(2) subblock projection of M onto the (p,q) subgroup: R = a0 + i a.sigma  from  M_pq
        m = M[:, [p, q], :][:, :, [p, q]]
        a0 = (m[:, 0, 0].real + m[:, 1, 1].real); a3 = (m[:, 0, 0].imag - m[:, 1, 1].imag)
        a1 = (m[:, 0, 1].imag + m[:, 1, 0].imag); a2 = (m[:, 0, 1].real - m[:, 1, 0].real)
        k = np.sqrt(a0**2 + a1**2 + a2**2 + a3**2) + 1e-300
        wbar = np.stack([a0, a1, a2, a3], -1) / k[:, None]
        bk = beta * k / 3.0 * 1.0                 # weight exp((beta/3) Re Tr(A R)) with |R| = k -> exp(bk * a0(A Wbar^-1 ...))
        # new subgroup element A with A*Rbar having distribution ~ exp(bk a0): sample X ~ exp(bk x0), set A = X Wbar^{-1}
        X = su2_heatbath(None, None, None, None, bk)   # exponent (beta/3)*Re Tr(A R) = (beta/3)*(k/2)*2*a0 = bk*a0
        wconj = wbar * np.array([1, -1, -1, -1])
        # quaternion product X * wconj
        x0, x1, x2, x3 = X.T; w0, w1, w2, w3 = wconj.T
        A = np.stack([x0*w0 - x1*w1 - x2*w2 - x3*w3, x0*w1 + x1*w0 + x2*w3 - x3*w2,
                      x0*w2 - x1*w3 + x2*w0 + x3*w1, x0*w3 + x1*w2 - x2*w1 + x3*w0], -1)
        A2 = quat_to_su2(A)
        G = np.tile(np.eye(3, dtype=complex), (N, 1, 1))
        G[:, p, p] = A2[:, 0, 0]; G[:, p, q] = A2[:, 0, 1]; G[:, q, p] = A2[:, 1, 0]; G[:, q, q] = A2[:, 1, 1]
        U[i] = G @ U[i]
def reunitarize(U):
    for i in range(len(U)):
        q, r = np.linalg.qr(U[i]); ph = np.diagonal(r, axis1=1, axis2=2) / np.abs(np.diagonal(r, axis1=1, axis2=2))
        q = q * ph[:, None, :]; det = np.linalg.det(q); U[i] = q / (det ** (1/3))[:, None, None]
def sweep(U):
    for d in POS: heatbath(U, d)
def avg_tri(U):
    tot = 0.0
    for d in POS:
        tot += np.einsum('nii->n', U[dir_index[d][0]] @ staple_sum(U, d)).real.sum()
    return tot / (96 * N) / 3.0
def wilson(U, u, v, R, T):
    x = np.arange(N); P = np.tile(np.eye(3, dtype=complex), (N, 1, 1))
    for _ in range(R): P = P @ link(U, x, u); x = SH[u][x]
    for _ in range(T): P = P @ link(U, x, v); x = SH[v][x]
    mu = tuple(-np.array(u)); mv = tuple(-np.array(v))
    for _ in range(R): P = P @ link(U, x, mu); x = SH[mu][x]
    for _ in range(T): P = P @ link(U, x, mv); x = SH[mv][x]
    return np.einsum('nii->n', P).real.mean() / 3.0
planes = [((1,1,0,0), (-1,1,0,0)), ((1,0,1,0), (-1,0,1,0)), ((0,1,1,0), (0,-1,1,0)), ((0,0,1,1), (0,0,-1,1))]

if __name__ == "__main__":
    U = [np.tile(np.eye(3, dtype=complex), (N, 1, 1)) for _ in POS]
    t0 = time.time()
    for s in range(n_therm):
        sweep(U)
        if s % 10 == 9: reunitarize(U)
    print(f"L={L} beta={beta}: thermalized {n_therm} sweeps in {time.time()-t0:.0f}s, <tri>={avg_tri(U):.4f}", flush=True)
    tri = []; W = {}; configs = []
    for m in range(n_meas):
        for _ in range(3): sweep(U)
        reunitarize(U)
        tri.append(avg_tri(U))
        for R in (1, 2, 3):
            for T in (1, 2, 3):
                W.setdefault((R, T), []).append(np.mean([wilson(U, u, v, R, T) for u, v in planes]))
        if out: configs.append([u.copy() for u in U])
    Wm = {k: np.mean(v) for k, v in W.items()}
    chi = lambda R, T: -np.log(Wm[(R,T)]*Wm[(R-1,T-1)]/(Wm[(R,T-1)]*Wm[(R-1,T)]))
    print(f"  <tri>={np.mean(tri):.4f}  W11={Wm[(1,1)]:.4f} W22={Wm[(2,2)]:.4f} W33={Wm[(3,3)]:.4f}  chi22={chi(2,2):.3f} chi33={chi(3,3):.3f} chi32={chi(3,2):.3f}  ({time.time()-t0:.0f}s)", flush=True)
    if out:
        pickle.dump(dict(L=L, beta=beta, configs=configs, POS=POS), open(out, 'wb'))
