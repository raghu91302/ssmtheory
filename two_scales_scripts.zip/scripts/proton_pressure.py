#!/usr/bin/env python3
"""Proton mechanical structure from the elastic stabilizer code (two-scales paper, Section 'The proton's
mechanical structure'). Paper III's proton: an extra node at a tetrahedral void centre with four bonds of
rest length L_c forced to 0.612 L_c, in the harmonic FCC lattice (L = 12), node as a degree of freedom.
Linear equilibrium; site stresses from the bond virial; uniform image stress of the fixed-volume periodic
box removed; shell averages of p = -tr(sigma)/3 and s = -(sigma_rr - sigma_tt) about the void.
Outputs: positive core, pressure sign change between 0.53 and 1.15 L_c (0.45-0.97 fm), positive shear
peaking at the cage. The D-term is not determined (elastic 1/r^3 tail, no confinement)."""
import numpy as np, itertools
from itertools import product
L=12; s=1/np.sqrt(2)
sites=[p for p in product(range(L),repeat=3) if sum(p)%2==0]; sid={p:i for i,p in enumerate(sites)}; N=len(sites)
NN=[v for v in product((-1,0,1),repeat=3) if sum(map(abs,v))==2]
add=lambda p,d: tuple((p[k]+d[k])%L for k in range(3))
bonds=[]
for p in sites:
    for d in NN:
        q=add(p,d)
        if sid[p]<sid[q]: bonds.append((sid[p],sid[q],np.array(d)*s))
cage=[(0,0,0),(1,1,0),(1,0,1),(0,1,1)]; vc=np.array([0.5,0.5,0.5])*s
node=N; ndof=3*(N+1); K=np.zeros((ndof,ndof))
def addspring(a,b,n):
    P=np.outer(n,n)
    for x,y,sg in ((a,a,1),(b,b,1),(a,b,-1),(b,a,-1)): K[3*x:3*x+3,3*y:3*y+3]+=sg*P
for i,j,d in bonds: addspring(i,j,d/np.linalg.norm(d))
nodebonds=[]
for c in cage:
    dvec=np.array(c)*s-vc; l0=np.linalg.norm(dvec); n=dvec/l0; addspring(node,sid[c],n); nodebonds.append((sid[c],n,l0,dvec))
pre=1-nodebonds[0][2]; F=np.zeros(ndof)
for ci,n,l0,dvec in nodebonds: F[3*ci:3*ci+3]+=pre*n; F[3*node:3*node+3]-=pre*n
u=np.linalg.lstsq(K,F,rcond=None)[0]; U=u.reshape(-1,3)
sigma=np.zeros((N+1,3,3))
for i,j,d in bonds:
    n=d/np.linalg.norm(d); t=n@(U[j]-U[i]); T=t*np.outer(d,n)/2; sigma[i]+=T; sigma[j]+=T
for ci,n,l0,dvec in nodebonds:
    t=-pre+n@(U[ci]-U[node]); T=t*np.outer(dvec,n)/2; sigma[ci]+=T; sigma[node]+=T
sigma/=1/np.sqrt(2); sigma-=sigma.mean(0)
def wrapv(v): return ((v+L*s/2)%(L*s))-L*s/2
pos=np.array([wrapv(np.array(p)*s-vc) for p in sites]+[np.zeros(3)]); r=np.linalg.norm(pos,axis=1)
p=-np.trace(sigma,axis1=1,axis2=2)/3
rh=np.where(r[:,None]>1e-9,pos/np.maximum(r,1e-9)[:,None],0)
srr=np.einsum('ni,nij,nj->n',rh,sigma,rh); srr[r<1e-9]=np.trace(sigma[r<1e-9],axis1=1,axis2=2)/3
stt=(np.trace(sigma,axis1=1,axis2=2)-srr)/2; shear=-(srr-stt)
edges=np.array([0,0.3,0.75,1.0,1.3,1.6,2.0,2.5,3.1,3.8])
print(f"{'r/L_c':>7s} {'r (fm)':>7s} {'sites':>6s} {'p (kappa)':>10s} {'shear':>8s}")
for a,b in zip(edges[:-1],edges[1:]):
    m=(r>=a)&(r<b)
    if m.sum(): print(f"{(a+b)/2:>7.2f} {(a+b)/2*0.84:>7.2f} {int(m.sum()):>6d} {p[m].mean():>10.4f} {shear[m].mean():>8.4f}")
