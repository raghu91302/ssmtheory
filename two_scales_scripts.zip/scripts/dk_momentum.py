#!/usr/bin/env python3
"""Momentum-space Dirac-Kahler operator on the infinite D4 lattice.
Each cell is assigned to a base site (its vertex with lexicographically smallest
difference set), giving 1 + 12 + 32 + 24 + 3 = 72 cell types per site.  The boundary
maps become 72x72 blocks d(k) with Bloch phases; Delta(k) = d(k) d(k)^+ + d(k)^+ d(k).
The Dirac-Kahler spectrum is +/- sqrt(eig Delta(k)).  We scan the Brillouin zone for
zeros of Delta(k) (Dirac points) and report the low-energy structure."""
import numpy as np, itertools
from itertools import product, combinations

NN = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]
NNs = set(NN)
def is_site(p): return sum(p) % 2 == 0
def adj(a, b): return tuple(b[k]-a[k] for k in range(4)) in NNs
# local cells around the origin (all cells containing the origin), then canonicalize by base vertex
O = (0, 0, 0, 0)
def cells_containing_origin():
    nb = NN
    E = [(O, v) for v in nb]
    T = [(O, a, b) for a, b in combinations(nb, 2) if adj(a, b)]
    Tt = [(O, a, b, c) for a, b, c in combinations(nb, 3) if adj(a, b) and adj(a, c) and adj(b, c)]
    # 16-cells containing the origin: deep holes at unit distance from the origin
    holes = [h for h in [tuple(x) for x in product((-1, 0, 1), repeat=4) if sum(map(abs, x)) == 1]]
    holes += [tuple(x) for x in product((-0.5, 0.5), repeat=4)]
    C = []
    for h in holes:
        if all(float(x).is_integer() for x in h):
            cand = [tuple(int(h[k]) + a[k] for k in range(4)) for a in product((-1, 0, 1), repeat=4) if sum(map(abs, a)) == 1]
        else:
            cand = [tuple(int(h[k] + a[k]) for k in range(4)) for a in product((-0.5, 0.5), repeat=4)]
        verts = [c for c in cand if is_site(c)]
        assert len(verts) == 8 and O in verts
        C.append(tuple(sorted(verts)))
    return E, T, Tt, sorted(set(C))
def canon(cell):
    """translate so that the base vertex is the origin; base = vertex giving lexicographically smallest sorted difference set"""
    best = None
    for v in cell:
        diffs = tuple(sorted(tuple(u[k]-v[k] for k in range(4)) for u in cell))
        if best is None or diffs < best[0]: best = (diffs, v)
    return best[0]           # tuple of offsets from base, sorted, base itself is (0,0,0,0)
E, T, Tt, C = cells_containing_origin()
types = {p: sorted({canon(c) for c in cells}) for p, cells in ((1, E), (2, T), (3, Tt), (4, C))}
types[0] = [((0, 0, 0, 0),)]
counts = {p: len(types[p]) for p in range(5)}
print("cell types per site:", counts, " total", sum(counts.values()))
tindex = {p: {t: i for i, t in enumerate(types[p])} for p in range(5)}
# oriented boundary of a canonical cell: faces as (offset-tuple relative to base, sign); each face then re-canonicalized
def sort_key(v): return v
def simplex_faces(cell):
    verts = list(cell)   # already sorted lexicographically
    out = []
    for i in range(len(verts)):
        f = tuple(verts[:i] + verts[i+1:]); out.append((f, (-1)**i))
    return out
# 16-cell facets with signs from d d = 0, computed once per type using the simplicial d3 on the local patch
def cell16_faces(cell):
    verts = list(cell)
    def antipodal(a, b): return sum((a[k]-b[k])**2 for k in range(4)) == 4
    facets = [tuple(sorted(q)) for q in combinations(verts, 4) if not any(antipodal(a, b) for a, b in combinations(q, 2))]
    assert len(facets) == 16
    # boundary of each facet as triangles (sorted) with simplicial signs
    tri_index = {}
    rows = []
    for f in facets:
        col = {}
        for i in range(4):
            t = tuple(f[:i] + f[i+1:]); tri_index.setdefault(t, len(tri_index)); col[tri_index[t]] = (-1)**i
        rows.append(col)
    M = np.zeros((len(tri_index), 16))
    for j, col in enumerate(rows):
        for r, s in col.items(): M[r, j] = s
    u, s, vt = np.linalg.svd(M); null = vt[-1]; null = null/np.abs(null).max()
    assert np.allclose(np.abs(null), 1) and np.allclose(M @ null, 0, atol=1e-9)
    return [(f, int(np.sign(null[j]))) for j, f in enumerate(facets)]
def rel(cell, base):
    return tuple(sorted(tuple(u[k]-base[k] for k in range(4)) for u in cell))
def face_data(p):
    """for each cell type of degree p: list of (face type index, sign, translation of face base relative to cell base)"""
    out = []
    for t in types[p]:
        cell = t   # offsets from base at origin
        faces = cell16_faces(cell) if p == 4 else simplex_faces(cell)
        lst = []
        for f, sgn in faces:
            # canonical form of the face and where its base sits
            best = None
            for v in f:
                d = tuple(sorted(tuple(u[k]-v[k] for k in range(4)) for u in f))
                if best is None or d < best[0]: best = (d, v)
            ftype, fbase = best
            lst.append((tindex[p-1][ftype], sgn, fbase))
        out.append(lst)
    return out
FD = {p: face_data(p) for p in range(1, 5)}
def d_k(p, k):
    """boundary block from degree p to p-1 at Bloch momentum k (cells of type i at site x -> faces at site x + fbase)"""
    M = np.zeros((counts[p-1], counts[p]), complex)
    for j, lst in enumerate(FD[p]):
        for fi, sgn, fbase in lst:
            M[fi, j] += sgn * np.exp(1j * np.dot(k, fbase))
    return M
def laplacian_k(k):
    blocks = []
    for p in range(5):
        L = np.zeros((counts[p], counts[p]), complex)
        if p > 0:
            d = d_k(p, k); L += d.conj().T @ d
        if p < 4:
            d = d_k(p+1, k); L += d @ d.conj().T
        blocks.append(L)
    return blocks
# sanity: d d = 0 at random k
k = np.random.default_rng(0).uniform(-np.pi, np.pi, 4)
for p in (2, 3, 4):
    print(f"  d{p-1}(k) d{p}(k) = 0: {np.abs(d_k(p-1, k) @ d_k(p, k)).max() < 1e-12}")
# k = 0: harmonic forms
print("\nzero modes of Delta(k) at k = 0, by degree:", [int((np.linalg.eigvalsh(B) < 1e-9).sum()) for B in laplacian_k(np.zeros(4))])
# Brillouin-zone scan for zeros: sample a grid, report points where min eigenvalue < tol
print("\nBrillouin-zone scan (grid step pi/4 per component, k in [-pi, pi)^4): momenta where Delta(k) has zero modes")
grid = np.arange(-np.pi, np.pi, np.pi/4)
found = []
for k in product(grid, repeat=4):
    kk = np.array(k)
    lam = min(np.linalg.eigvalsh(B).min() for B in laplacian_k(kk))
    if lam < 1e-9:
        nz = [int((np.linalg.eigvalsh(B) < 1e-9).sum()) for B in laplacian_k(kk)]
        found.append((tuple(np.round(kk/np.pi, 2)), nz))
for f in found: print("  k/pi =", f[0], " zero modes by degree", f[1], " total", sum(f[1]))
print(f"{len(found)} zero-mode momenta on the grid")
# low-energy dispersion near k = 0: smallest nonzero eigenvalue vs |k| along two directions
print("\nlowest nonzero eigenvalue of Delta(k) (squared Dirac-Kahler energy) near k = 0:")
for direc in (np.array([1,0,0,0.]), np.array([1,1,0,0.])/np.sqrt(2), np.array([1,1,1,1.])/2):
    row = []
    for s in (0.05, 0.1, 0.2, 0.4):
        kk = s*direc; w = np.sort(np.concatenate([np.linalg.eigvalsh(B) for B in laplacian_k(kk)]))
        row.append(w[w > 1e-9][0] if (w > 1e-9).any() else 0)
    print(f"  direction {direc.round(2)}: {np.array(row).round(5)}   ratio to |k|^2: {(np.array(row)/np.array([0.05,0.1,0.2,0.4])**2).round(3)}")
