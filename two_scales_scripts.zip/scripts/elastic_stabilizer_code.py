#!/usr/bin/env python3
"""Elastic stabilizer code on FCC (minimal model, 2026-09-10).
Quantum layer: H_code = -J sum_v Z_v - J sum_o X_o.  Metric layer: FCC sites with nearest-neighbour
springs (kappa), harmonic.  Coupling: a check's strength depends on the strain of its bonds,
J_c(l) = J [1 - g_c sum_{b in c} (l_b - L)/L], so an excited check exerts a force f = g_c J / L on each
of its bonds.  Statics: K u = F on the FCC spring lattice (L = 8, periodic), Green's function by pinv.
Results: (1) a vertex syndrome's elastic self-energy sits 71% on the 36-bond coordination-shell footprint;
(2) the electric-magnetic composite (vertex + adjacent void) is bound, E12 - E1 - E2 = -1.92 f^2/kappa,
iff g_Z and g_X have opposite signs (electric dilates, magnetic contracts); same sign gives +1.92 (repulsion);
(3) the bound composite's far field cancels (2% of energy beyond two bonds).  Elastic energies are additive
over bonds: this model gives binding and localization, not the bilinear mass count."""
import numpy as np, itertools
from itertools import product, combinations
L=8; s=1/np.sqrt(2)
sites=[p for p in product(range(L),repeat=3) if sum(p)%2==0]; sid={p:i for i,p in enumerate(sites)}; N=len(sites)
NN=[v for v in product((-1,0,1),repeat=3) if sum(map(abs,v))==2]; AX=[v for v in product((-1,0,1),repeat=3) if sum(map(abs,v))==1]
add=lambda p,d: tuple((p[k]+d[k])%L for k in range(3))
bonds=[]; bidx={}
for p in sites:
    for d in NN:
        q=add(p,d)
        if sid[p]<sid[q]: bidx[(sid[p],sid[q])]=len(bonds); bonds.append((sid[p],sid[q],np.array(d)*s))
def B(a,b): return bidx[(a,b)] if (a,b) in bidx else bidx[(b,a)]
K=np.zeros((3*N,3*N))
for i,j,d in bonds:
    n=d/np.linalg.norm(d); P=np.outer(n,n)
    for a,b,sgn in ((i,i,1),(j,j,1),(i,j,-1),(j,i,-1)): K[3*a:3*a+3,3*b:3*b+3]+=sgn*P
Kinv=np.linalg.pinv(K)
def F_of(bond_ids,f):
    F=np.zeros(3*N)
    for k in bond_ids:
        i,j,d=bonds[k]; n=d/np.linalg.norm(d); F[3*j:3*j+3]+=f*n; F[3*i:3*i+3]-=f*n
    return F
def vertex_bonds(p): return [B(sid[p],sid[add(p,d)]) for d in NN]
def void_bonds(o):
    nb=[add(o,a) for a in AX]; return [B(sid[a],sid[b]) for a,b in combinations(nb,2) if (sid[a],sid[b]) in bidx or (sid[b],sid[a]) in bidx]
def wrapv(v): return ((v+L*s/2)%(L*s))-L*s/2
r=np.array([np.linalg.norm(wrapv(np.array(sites[i])*s)+d/2) for i,j,d in bonds])
def energy(F): return 0.5*F@(Kinv@F)
def profile(F,label):
    u=Kinv@F; strain=np.array([(d/np.linalg.norm(d))@(u[3*j:3*j+3]-u[3*i:3*i+3]) for i,j,d in bonds]); E=0.5*F@u
    print(f"  {label:44s} E = {E:7.4f}  inside 36-bond footprint {100*0.5*np.sum(strain[r<1.01]**2)/E:5.1f}%  beyond 2 bonds {100*0.5*np.sum(strain[r>2.01]**2)/E:5.1f}%")
    return E
print("elastic stabilizer code on FCC, L = 8 (energies in f^2/kappa)")
Ee=profile(F_of(vertex_bonds((0,0,0)),1.0),"vertex syndrome (electric)")
Em=profile(F_of(void_bonds((1,0,0)),1.0),"void syndrome (magnetic)")
Es=profile(F_of(vertex_bonds((0,0,0)),1.0)+F_of(void_bonds((1,0,0)),1.0),"e + m, same-sign couplings")
Eo=profile(F_of(vertex_bonds((0,0,0)),1.0)-F_of(void_bonds((1,0,0)),1.0),"e + m, opposite-sign couplings")
print(f"binding E(e+m) - E(e) - E(m): opposite sign {Eo-Ee-Em:+.4f} (bound); same sign {Es-Ee-Em:+.4f} (repulsive)")
