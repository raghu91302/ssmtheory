#!/usr/bin/env python3
"""Quenched hadron correlators on D4 with the gauged Dirac-Kahler fermion.
D_m = K + m with K = d - d^T (anti-Hermitian, gauged), acting on 72 cell types x 3 colors
per site.  Gauging: a cell of type c at site x with face at site x + fbase gets the
transporter U(x -> x + fbase); for antipodal fbase (16-cell facets) a fixed two-link route.
Propagators from point sources on the vertex (0-form) component at the origin, all three
colors, by CG on D_m^+ D_m.  Correlators summed over time slices x0 = t:
  pion:    C_pi(t)  = sum_x sum_{cells,colors} |G(x; 0)|^2      (Goldstone channel)
  nucleon: C_N(t)   = sum_x eps eps G G G   (local three-quark, vertex component)
Usage: python3 dk_hadrons.py configs.pkl m1,m2,...  [ncfg]
"""
import numpy as np, itertools, sys, pickle, time
import scipy.sparse as sp
from scipy.sparse.linalg import cg, LinearOperator
from itertools import product, combinations

cfgfile = sys.argv[1]; masses = [float(m) for m in sys.argv[2].split(",")]
ncfg = int(sys.argv[3]) if len(sys.argv) > 3 else 999
data = pickle.load(open(cfgfile, 'rb')); L = data['L']; POS = data['POS']; configs = data['configs'][:ncfg]
NN = [v for v in product((-1, 0, 1), repeat=4) if sum(map(abs, v)) == 2]; NNset = set(NN)
dir_index = {}
for i, v in enumerate(POS): dir_index[v] = (i, +1); dir_index[tuple(-x for x in v)] = (i, -1)
sites = [p for p in product(range(L), repeat=4) if sum(p) % 2 == 0]; N = len(sites)
site_id = {p: i for i, p in enumerate(sites)}
add = lambda p, d: tuple((p[k] + d[k]) % L for k in range(4))
SH = {v: np.array([site_id[add(sites[i], v)] for i in range(N)]) for v in NN}

# ---- cell types and face data (from dk_momentum.py, position-space use)
exec(open('dk_momentum.py').read().split("# sanity: d d = 0")[0])
NT = sum(counts.values()); offs = {}; o = 0
for p in range(5): offs[p] = o; o += counts[p]
assert NT == 72
def route(fb):
    """list of NN steps from x to x + fb (fb is 0, an NN vector, or an antipodal vector of length 2)"""
    fb = tuple(fb)
    if fb == (0, 0, 0, 0): return []
    if fb in NNset: return [fb]
    for v in NN:
        w = tuple(fb[k] - v[k] for k in range(4))
        if w in NNset: return [v, w]
    raise ValueError(fb)
def transporter(U, x, steps):
    """3x3 product of links along steps starting at site index x"""
    M = np.eye(3, dtype=complex); cur = x
    for v in steps:
        i, s = dir_index[v]
        # transporter from cur to cur+v: U_v(cur)^+ for a +direction link (U_v(x) -> g(x) U g(x+v)^+),
        # and U_{|v|}(cur+v) itself for a -direction step
        Uv = np.conj(U[i][cur]).T if s > 0 else U[i][SH[v][cur]]
        # antiperiodic boundary condition in time (x0) for the fermion
        if (sites[cur][0] + v[0]) // L != 0: Uv = -Uv
        M = M @ Uv; cur = SH[v][cur]
    return M, cur
def build_d(U):
    rows, cols, vals = [], [], []
    for p in range(1, 5):
        for j, lst in enumerate(FD[p]):
            for fi, sgn, fbase in lst:
                steps = route(fbase)
                for x in range(N):
                    T, y = transporter(U, x, steps)
                    ci = (x * NT + offs[p] + j) * 3; ri = (y * NT + offs[p-1] + fi) * 3
                    for a in range(3):
                        for b in range(3):
                            if abs(T[a, b]) > 1e-14:
                                rows.append(ri + a); cols.append(ci + b); vals.append(sgn * T[a, b])
    return sp.csr_matrix((vals, (rows, cols)), shape=(N*NT*3, N*NT*3), dtype=complex)
def solve(K, m, b):
    A = LinearOperator(K.shape, matvec=lambda v: (K.conj().T @ (K @ v)) + m*m*v, dtype=complex)
    Dm = lambda v: K @ v + m*v
    # (D_m^+ D_m)^{-1} D_m^+ b
    rhs = K.conj().T @ b + m*b
    x, info = cg(A, rhs, rtol=1e-7, maxiter=3000)
    return x
tslice = np.array([sites[i][0] for i in range(N)])
def correlators(K, m):
    Cpi = np.zeros(L); CN = np.zeros(L, complex)
    src_site = site_id[(0,0,0,0)]
    G = np.zeros((3, N*NT*3), complex)     # G[c0] = propagator from vertex component, color c0
    for c0 in range(3):
        b = np.zeros(N*NT*3, complex); b[(src_site*NT + offs[0])*3 + c0] = 1.0
        G[c0] = solve(K, m, b)
    Gm = G.reshape(3, N, NT, 3)             # [source color, site, cell, sink color]
    for t in range(L):
        sel = tslice == t
        Cpi[t] = np.sum(np.abs(Gm[:, sel, :, :])**2)
        # nucleon: vertex component only: g[x][sink a, source a'] = Gm[a', x, 0, a]
        g = Gm[:, sel, 0, :]                # [src, x, sink]
        g = np.transpose(g, (1, 2, 0))      # [x, sink, src]
        eps = np.zeros((3,3,3)); eps[0,1,2]=eps[1,2,0]=eps[2,0,1]=1; eps[0,2,1]=eps[2,1,0]=eps[1,0,2]=-1
        CN[t] = np.einsum('abc,ijk,xai,xbj,xck->', eps, eps, g, g, g)
    return Cpi, CN.real
print(f"L={L}, {len(configs)} configs, masses {masses}", flush=True)
t0 = time.time()
res = {m: {'pi': [], 'N': []} for m in masses}
for ic, U in enumerate(configs):
    d = build_d(U); K = d - d.conj().T
    for m in masses:
        Cpi, CN = correlators(K, m); res[m]['pi'].append(Cpi); res[m]['N'].append(CN)
    print(f"  config {ic+1}/{len(configs)} done ({time.time()-t0:.0f}s)", flush=True)
for m in masses:
    Cpi = np.mean(res[m]['pi'], 0); CN = np.mean(res[m]['N'], 0)
    epi = [np.log(Cpi[t]/Cpi[t+1]) if Cpi[t+1] > 0 else np.nan for t in range(L-1)]
    eN = [np.log(abs(CN[t])/abs(CN[t+1])) if CN[t+1] != 0 else np.nan for t in range(L-1)]
    print(f"\nm = {m}:")
    print("  C_pi(t):", np.array2string(Cpi, precision=4))
    print("  C_N (t):", np.array2string(CN, precision=4))
    print("  m_pi_eff(t):", np.round(epi, 3), "  m_N_eff(t):", np.round(eN, 3))
pickle.dump(res, open(cfgfile.replace('.pkl', '_hadrons.pkl'), 'wb'))
