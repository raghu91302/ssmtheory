#!/usr/bin/env python3
"""
04_void_code_fcc_vs_hcp_distance.py
-----------------------------------
Builds the octahedral-void CSS code (qubits on edges, Z-stabilizers = vertex stars,
X-stabilizers = octahedral voids) on FCC (ABC stacking) and HCP (ABA stacking) on a
periodic supercell, and computes:

  * CSS validity  H_X H_Z^T = 0  (commuting-projector / local-Hamiltonian property)
  * stabilizer weights (uniform 12 for both)
  * octahedral-void : node ratio (1:1 for both close packings)
  * rate k/n  ->  2/3
  * Z-sector distance lower bound (exhaustive weight<=2 in ker H_Z)
  * X-sector distance: weight-2 LOGICALS in ker(H_X) \\ rowspace(H_Z)

Result reproduced in the paper (Section 2):
  FCC : d_Z = 3, d_X >= 3  (0 weight-2 X-logicals)        -> full d = 3
  HCP : d_Z = 3, d_X = 2   (108 at 36-node, 192 at 64-node) -> full d = 2
The HCP weight-2 X-logical count scales with cell size, confirming it is structural
(the c-axis octahedral-void columns) and not a finite-size artifact. This is the
coding-theoretic fingerprint of HCP's broken inversion symmetry.

Requires: numpy.  Runs in a few seconds.
"""
import numpy as np, itertools

def gf2_rref(M):
    M=M.copy().astype(np.uint8); rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=None
        for i in range(r,rows):
            if M[i,c]: p=i; break
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
    return M,piv,r

def gf2_rank(M):
    return 0 if np.asarray(M).size==0 else gf2_rref(np.asarray(M)%2)[2]

def in_rowspace(basis,piv,v):
    v=v.copy().astype(np.uint8)
    for i,c in enumerate(piv):
        if v[c]: v^=basis[i]
    return not v.any()

def build(stacking,n):
    """stacking='ABCABC' (FCC) or 'ABAB' (HCP); n cells per in-plane direction.
       NN bond length = 1.  Returns edge list and H_Z, H_X."""
    a1=np.array([1.0,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0]); cz=np.sqrt(2/3)
    off={'A':np.zeros(3),'B':(a1+a2)/3,'C':2*(a1+a2)/3}
    cell=np.array([n*a1,n*a2,np.array([0,0,cz*len(stacking)])]).T
    inv=np.linalg.inv(cell)
    pts=[]
    for k,layer in enumerate(stacking):
        for i in range(n):
            for j in range(n):
                pts.append(i*a1+j*a2+off[layer]+np.array([0,0,cz*k]))
    pts=np.array(pts); V=len(pts)
    minimg=lambda d:(cell@((inv@d.T)-np.round(inv@d.T))).T
    edges=[]; eidx={}; D=np.zeros((V,V))
    for i in range(V):
        dist=np.linalg.norm(minimg(pts-pts[i]),axis=1); D[i]=dist
        for j in range(V):
            if i<j and abs(dist[j]-1.0)<1e-6:
                eidx[(i,j)]=len(edges); edges.append((i,j))
    E=len(edges); adj=[set() for _ in range(V)]
    for (i,j) in edges: adj[i].add(j); adj[j].add(i)
    # octahedral void = 6 vertices whose induced NN-subgraph is the octahedron;
    # seed on antipodal pairs at distance sqrt(2) whose 4 common neighbours complete it
    voids=set()
    for i in range(V):
        for j in range(i+1,V):
            if abs(D[i,j]-np.sqrt(2))<1e-6:
                common=sorted(adj[i]&adj[j])
                if len(common)>=4:
                    for quad in itertools.combinations(common,4):
                        s={i,j}|set(quad)
                        if len(s)==6:
                            ie=sum(1 for (a,b) in itertools.combinations(sorted(s),2) if b in adj[a])
                            if ie==12 and all(len(adj[v]&s)==4 for v in s):
                                voids.add(tuple(sorted(s)))
    voids=[set(v) for v in voids]
    HZ=np.zeros((V,E),np.uint8)
    for (i,j),e in eidx.items(): HZ[i,e]=1; HZ[j,e]=1
    HX=np.zeros((len(voids),E),np.uint8)
    for vi,s in enumerate(voids):
        for (i,j),e in eidx.items():
            if i in s and j in s: HX[vi,e]=1
    return V,E,HZ,HX,voids

def analyze(stack,name,n):
    V,E,HZ,HX,voids=build(stack,n)
    css=int(((HX@HZ.T)%2).sum())
    k=E-gf2_rank(HZ)-gf2_rank(HX)
    xw=HX.sum(1); zw=HZ.sum(1)
    # d_Z lower bound: weight<=2 in ker(H_Z)
    zcols=[HZ[:,i] for i in range(E)]
    z1=sum(1 for i in range(E) if not zcols[i].any())
    z2=sum(1 for i in range(E) for j in range(i+1,E) if not (zcols[i]^zcols[j]).any())
    # d_X: weight-2 logicals = weight-2 in ker(H_X) \ rowspace(H_Z)
    rrefZ,pivZ,rkZ=gf2_rref(HZ%2); basisZ=rrefZ[:rkZ]
    xcols=[HX[:,i] for i in range(E)]
    x1=0
    for i in range(E):
        if not xcols[i].any():
            v=np.zeros(E,np.uint8); v[i]=1
            if not in_rowspace(basisZ,pivZ,v): x1+=1
    x2=0
    for i in range(E):
        ci=xcols[i]
        for j in range(i+1,E):
            if not (ci^xcols[j]).any():
                v=np.zeros(E,np.uint8); v[i]=1; v[j]=1
                if not in_rowspace(basisZ,pivZ,v): x2+=1
    dX = 1 if x1>0 else (2 if x2>0 else ">=3")
    print(f"{name} ({stack}) n={n}: V={V} E={E} voids={len(voids)} ratio={len(voids)/V:.2f} "
          f"CSS_viol={css} k={k} rate={k/E:.3f} Zwt=({zw.min()},{zw.max()}) Xwt=({xw.min()},{xw.max()})")
    print(f"   d_Z lower bound: wt1={z1} wt2={z2} in ker(H_Z)  => d_Z >= 3")
    print(f"   d_X: weight-2 X-logicals = {x2}  => d_X = {dX}")
    return dict(k=k,E=E,x2=x2)

if __name__=="__main__":
    print("FCC vs HCP octahedral-void CSS code\n"+"-"*50)
    for stack,name in [('ABCABC','FCC'),('ABAB','HCP')]:
        for n in [3,4]:
            analyze(stack,name,n)
        print()
