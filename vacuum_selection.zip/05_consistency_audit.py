import numpy as np, itertools, re

# ============ PART A: recompute the claims the paper now makes ============
def gf2_rref(M):
    M=M.copy().astype(np.uint8); rows,cols=M.shape; piv=[]; r=0
    for c in range(cols):
        p=None
        for i in range(r,rows):
            if M[i,c]: p=i;break
        if p is None: continue
        M[[r,p]]=M[[p,r]]
        for i in range(rows):
            if i!=r and M[i,c]: M[i]^=M[r]
        piv.append(c); r+=1
    return M,piv,r
def rank(M): return 0 if np.asarray(M).size==0 else gf2_rref(np.asarray(M)%2)[2]
def in_rs(basis,piv,v):
    v=v.copy().astype(np.uint8)
    for i,c in enumerate(piv):
        if v[c]: v^=basis[i]
    return not v.any()

def build(stacking,n):
    a1=np.array([1.0,0,0]); a2=np.array([0.5,np.sqrt(3)/2,0]); cz=np.sqrt(2/3)
    off={'A':np.zeros(3),'B':(a1+a2)/3,'C':2*(a1+a2)/3}
    cell=np.array([n*a1,n*a2,np.array([0,0,cz*len(stacking)])]).T; inv=np.linalg.inv(cell)
    pts=[]
    for k,l in enumerate(stacking):
        for i in range(n):
            for j in range(n): pts.append(i*a1+j*a2+off[l]+np.array([0,0,cz*k]))
    pts=np.array(pts); V=len(pts)
    md=lambda d:(cell@((inv@d.T)-np.round(inv@d.T))).T
    edges=[]; eidx={}; D=np.zeros((V,V))
    for i in range(V):
        dist=np.linalg.norm(md(pts-pts[i]),axis=1); D[i]=dist
        for j in range(V):
            if i<j and abs(dist[j]-1)<1e-6: eidx[(i,j)]=len(edges); edges.append((i,j))
    E=len(edges); adj=[set() for _ in range(V)]
    for (i,j) in edges: adj[i].add(j); adj[j].add(i)
    voids=set()
    for i in range(V):
        for j in range(i+1,V):
            if abs(D[i,j]-np.sqrt(2))<1e-6:
                cm=sorted(adj[i]&adj[j])
                if len(cm)>=4:
                    for q in itertools.combinations(cm,4):
                        s={i,j}|set(q)
                        if len(s)==6:
                            ie=sum(1 for (a,b) in itertools.combinations(sorted(s),2) if b in adj[a])
                            if ie==12 and all(len(adj[v]&s)==4 for v in s): voids.add(tuple(sorted(s)))
    voids=[set(v) for v in voids]
    HZ=np.zeros((V,E),np.uint8)
    for (i,j),e in eidx.items(): HZ[i,e]=1; HZ[j,e]=1
    HX=np.zeros((len(voids),E),np.uint8)
    for vi,s in enumerate(voids):
        for (i,j),e in eidx.items():
            if i in s and j in s: HX[vi,e]=1
    return V,E,HZ,HX,voids

print("PAPER CLAIM AUDIT")
print("="*55)
for stack,name in [('ABCABC','FCC'),('ABAB','HCP')]:
    res={}
    for n in [3,4]:
        V,E,HZ,HX,voids=build(stack,n)
        rrefZ,pivZ,rkZ=gf2_rref(HZ%2); basisZ=rrefZ[:rkZ]
        HXcols=[HX[:,i] for i in range(E)]
        # d_X weight-2 logicals
        w2=0
        for i in range(E):
            ci=HXcols[i]
            for j in range(i+1,E):
                if not (ci^HXcols[j]).any():
                    v=np.zeros(E,np.uint8); v[i]=1; v[j]=1
                    if not in_rs(basisZ,pivZ,v): w2+=1
        css=int(((HX@HZ.T)%2).sum())
        xw=HX.sum(1); zw=HZ.sum(1)
        res[n]=dict(V=V,E=E,nv=len(voids),css=css,w2=w2,
                    xwu=(int(xw.min()),int(xw.max())),zwu=(int(zw.min()),int(zw.max())))
    print(f"\n{name}: voids/node ratio = {res[3]['nv']}/{res[3]['V']} = {res[3]['nv']/res[3]['V']:.2f} (claim 1:1)")
    print(f"  CSS valid both sizes: {res[3]['css']==0 and res[4]['css']==0}")
    print(f"  weight-12 uniform: Z{res[3]['zwu']} X{res[3]['xwu']} -> {res[3]['zwu']==(12,12) and res[3]['xwu']==(12,12)}")
    print(f"  weight-2 X-logicals: n=3 -> {res[3]['w2']}, n=4 -> {res[4]['w2']}  (paper cites 108, 192)")
    if name=='HCP':
        print(f"    PAPER SAYS 108 at 36-node, 192 at 64-node: "
              f"{res[3]['w2']==108 and res[3]['V']==36 and res[4]['w2']==192 and res[4]['V']==64}")
    else:
        print(f"    d_X(FCC)>=3 (zero wt-2 logicals): {res[3]['w2']==0 and res[4]['w2']==0}")


print("\n"+"="*55)
print("All recomputed values above should match the manuscript:")
print("  FCC void code [[192,130,3]] / [[648,434,3]], uniform weight 12, d_Z=3, d_X>=3")
print("  HCP void code: same rate & d_Z=3, but d_X=2 (108 @ 36-node, 192 @ 64-node)")
print("  1:1 octahedral-void:node ratio for both close packings")
