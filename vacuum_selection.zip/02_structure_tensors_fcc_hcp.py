import numpy as np
import itertools

def nn_FCC():
    v=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),
       (1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
       (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
    v=np.array(v,float)
    return v/np.linalg.norm(v[0])   # normalize to unit bond length

def nn_HCP():
    # 6 in-plane hexagon, unit length
    inpl=[(np.cos(t),np.sin(t),0) for t in np.deg2rad([0,60,120,180,240,300])]
    h=np.sqrt(2/3); r=1/np.sqrt(3)
    # HCP: 3 above and 3 below at SAME azimuths (eclipsed) -> anticuboctahedron
    az=np.deg2rad([30,150,270])
    up=[(r*np.cos(a),r*np.sin(a),h) for a in az]
    dn=[(r*np.cos(a),r*np.sin(a),-h) for a in az]   # same az = HCP
    v=np.array(inpl+up+dn,float)
    return v

def nn_FCC_stagger():
    # cross-check: FCC = staggered (3 below rotated 60 deg)
    inpl=[(np.cos(t),np.sin(t),0) for t in np.deg2rad([0,60,120,180,240,300])]
    h=np.sqrt(2/3); r=1/np.sqrt(3)
    up=[(r*np.cos(a),r*np.sin(a),h) for a in np.deg2rad([30,150,270])]
    dn=[(r*np.cos(a),r*np.sin(a),-h) for a in np.deg2rad([90,210,330])]  # staggered
    return np.array(inpl+up+dn,float)

def tensors(v,name):
    # bond lengths check
    L=np.linalg.norm(v,axis=1)
    S=np.einsum('ja,jb->ab',v,v)               # rank-2
    T=np.einsum('ja,jb,jc->abc',v,v,v)         # rank-3
    Q=np.einsum('ja,jb,jc,jd->abcd',v,v,v,v)   # rank-4
    print(f"--- {name} ---  (12 NN, bond lengths {L.min():.4f}-{L.max():.4f})")
    print("  S (rank-2):")
    print("   ", np.array2string(S,precision=3,suppress_small=True).replace('\n','\n    '))
    iso2 = np.allclose(S, S[0,0]*np.eye(3))
    print(f"    isotropic (S = c*I)?  {iso2}   diag={np.round(np.diag(S),3)}")
    print(f"  T (rank-3) max|component| = {np.abs(T).max():.4f}   -> centrosymmetric? {np.allclose(T,0)}")
    # rank-4 isotropy test: isotropic Q would be c*(d_ab d_cd + d_ac d_bd + d_ad d_bc)
    I=np.eye(3)
    iso4=sum(np.einsum('ab,cd->abcd',I,I)[p] for p in [ (slice(None),)*4 ])  # placeholder
    Qiso = (np.einsum('ab,cd->abcd',I,I)+np.einsum('ac,bd->abcd',I,I)+np.einsum('ad,bc->abcd',I,I))
    # best-fit scalar c
    c=np.sum(Q*Qiso)/np.sum(Qiso*Qiso)
    resid=np.abs(Q-c*Qiso).max()
    print(f"  Q (rank-4): fully-isotropic fit residual max = {resid:.4f}  (0 = perfectly isotropic at O(k^4))")
    # diagonal anisotropy fingerprint
    print(f"    Q_xxxx={Q[0,0,0,0]:.3f}  Q_yyyy={Q[1,1,1,1]:.3f}  Q_zzzz={Q[2,2,2,2]:.3f}")
    print()

for f,nm in [(nn_FCC,"FCC (vec form)"),(nn_FCC_stagger,"FCC (staggered ABC)"),(nn_HCP,"HCP (eclipsed ABA)")]:
    tensors(f(),nm)

# --- Thomson energies for N=12 shells (Section 2 / reviewer cross-check) ---
def thomson(p):
    p=np.array(p,float); p=p/np.linalg.norm(p,axis=1,keepdims=True); E=0.0
    for i,j in itertools.combinations(range(len(p)),2): E+=1.0/np.linalg.norm(p[i]-p[j])
    return E
phi=(1+np.sqrt(5))/2
ico=[]
for a in (-1,1):
    for b in (-phi,phi): ico+=[(0,a,b),(a,b,0),(b,0,a)]
cubo=[(x,y,0) for x in(-1,1) for y in(-1,1)]+[(x,0,z) for x in(-1,1) for z in(-1,1)]+[(0,y,z) for y in(-1,1) for z in(-1,1)]
print("\nThomson N=12: icosahedron =", round(thomson(ico),6),
      "| cuboctahedron =", round(thomson(cubo),6))
