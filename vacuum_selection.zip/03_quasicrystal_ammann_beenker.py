import numpy as np
import itertools

# ---------- Ammann-Beenker via cut-and-project from Z^4 ----------
# Physical projection angles 0,45,90,135 ; internal angles = 3x  (8-fold AB standard)
ap = np.deg2rad([0,45,90,135]); ai = np.deg2rad([0,135,270,45])
PHYS = np.array([[np.cos(a),np.sin(a)] for a in ap])     # 4x2
INT  = np.array([[np.cos(a),np.sin(a)] for a in ai])     # 4x2

# Acceptance window = projection of unit 4-cube into internal space = regular octagon
# vertices: all sign combos of (1/2)*INT_i summed
signs = np.array(list(itertools.product([-0.5,0.5],repeat=4)))
win_pts = signs @ INT
# convex hull (octagon) for point-in-polygon
from scipy.spatial import ConvexHull
hull = ConvexHull(win_pts)
hv = win_pts[hull.vertices]   # ordered CCW

def in_octagon(p, poly=hv, eps=1e-9):
    # point in convex polygon via sign of cross products
    n=len(poly); s=None
    for i in range(n):
        a=poly[i]; b=poly[(i+1)%n]
        cr=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
        if abs(cr)<eps: continue
        sg=cr>0
        if s is None: s=sg
        elif sg!=s: return False
    return True

# Generate Z^4 in a box, accept those whose internal proj is in window
R=10
verts=[]; keys=[]
for n in itertools.product(range(-R,R+1),repeat=4):
    n=np.array(n)
    pi=n@INT
    if in_octagon(pi):
        pp=n@PHYS
        verts.append(pp); keys.append(tuple(n))
verts=np.array(verts)
# keep a central disk to reduce boundary effects
c=verts.mean(0); rad=np.linalg.norm(verts-c,axis=1)
Rdisk=6.5
mask=rad<Rdisk
verts=verts[mask]
V=len(verts)

# edges = unit distance pairs
from scipy.spatial import cKDTree
tree=cKDTree(verts)
pairs=tree.query_pairs(r=1.0+1e-6)
edges=sorted((min(i,j),max(i,j)) for i,j in pairs if abs(np.linalg.norm(verts[i]-verts[j])-1.0)<1e-6)
E=len(edges)
deg=np.zeros(V,int)
for i,j in edges: deg[i]+=1; deg[j]+=1

# interior vertices = those with full coordination environment (all faces present)
# heuristic: interior if within Rdisk-1.2 of center
rad2=np.linalg.norm(verts-c,axis=1)
interior=rad2<(Rdisk-1.8)
print("=== Ammann-Beenker approximant (cut-and-project) ===")
print(f"vertices={V}, edges={E}")
print(f"ALL vertex coordination (Z-stabilizer weights): "
      f"{dict(zip(*np.unique(deg,return_counts=True)))}")
print(f"INTERIOR vertex coordination (boundary removed): "
      f"{dict(zip(*np.unique(deg[interior],return_counts=True)))}")

# ---------- build faces (squares + 45-rhombi) as 4-cycles, check CSS ----------
vset={tuple(np.round(v,6)):i for i,v in enumerate(verts)}
eset=set(edges)
def has_edge(a,b): return (min(a,b),max(a,b)) in eset
faces=[]
adj=[[] for _ in range(V)]
for i,j in edges: adj[i].append(j); adj[j].append(i)
seen=set()
for v in range(V):
    for a,b in itertools.combinations(adj[v],2):
        w=verts[a]+verts[b]-verts[v]   # parallelogram 4th corner
        key=tuple(np.round(w,6))
        if key in vset:
            wi=vset[key]
            if has_edge(a,wi) and has_edge(b,wi):
                f=tuple(sorted([v,a,wi,b]))
                if f not in seen:
                    seen.add(f); faces.append((v,a,wi,b))
faces=[f for f in faces if True]

eidx={e:k for k,e in enumerate(edges)}
def edge_id(a,b): return eidx[(min(a,b),max(a,b))]
HX=np.zeros((len(faces),E),dtype=np.uint8)
for fi,(v,a,w,b) in enumerate(faces):
    for (p,q) in [(v,a),(a,w),(w,b),(b,v)]:
        HX[fi,edge_id(p,q)]^=1
HZ=np.zeros((V,E),dtype=np.uint8)
for ei,(i,j) in enumerate(edges): HZ[i,ei]=1; HZ[j,ei]=1

css=((HX@HZ.T)%2).sum()
xw=HX.sum(1); 
print(f"CSS commutation  HX·HZ^T mod2 sum = {css}   (0 => valid commuting-projector code)")
print(f"X-stabilizer (plaquette) weights: {dict(zip(*np.unique(xw,return_counts=True)))}")
print(f"Z-stabilizer (vertex) weights:    range {deg.min()}-{deg.max()}  (NON-uniform)")

print("\n=== FCC (Paper 1), for contrast ===")
print("Z-stabilizer weights: all 12 (uniform)")
print("X-stabilizer weights: all 12 (uniform)")
print("CSS commutation: 0 (valid)")
