import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import os
os.makedirs("figs", exist_ok=True)

mpl.rcParams.update({
    "font.family":"serif","font.serif":["DejaVu Serif"],
    "mathtext.fontset":"dejavuserif",
    "axes.linewidth":0.8,"font.size":9,"axes.labelsize":9,
    "xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":8,
    "axes.titlesize":9.5,"figure.dpi":160,
})
INK="#1a1a1a"; ACC="#2b6cb0"; ACC2="#c05621"; GRN="#2f855a"; GRY="#a0aec0"; RED="#c53030"

# ---------------- FIG 1: rate ceiling 1-2/K across 3D lattices ----------------
# computed values from lattice_compare.py
lat = ["Diamond","SC","BCC","FCC / HCP"]
K   = [4,6,8,12]
ceil= [1-2/k for k in K]
achieved = [None, 0.037, None, 0.677]  # SC toric k=3, FCC void k=130 (computed)
fig,ax=plt.subplots(figsize=(5.0,3.1))
x=np.arange(len(lat))
ax.plot(x, ceil, "-o", color=ACC, lw=1.6, ms=6, label=r"rate ceiling $1-2/K$", zorder=3)
for xi,(k,c) in enumerate(zip(K,ceil)):
    ax.annotate(f"K={k}", (xi,c), textcoords="offset points", xytext=(0,7),
                ha="center", fontsize=7.5, color=INK)
# achieved points
ax.scatter([1],[0.037], color=ACC2, s=40, zorder=4, marker="s")
ax.annotate("3D toric\n$k{=}3$, 3.7%", (1,0.037), textcoords="offset points",
            xytext=(8,2), fontsize=7, color=ACC2)
ax.scatter([3],[0.677], color=GRN, s=40, zorder=4, marker="D")
ax.annotate("FCC void code\n[[192,130,3]], 67.7%", (3,0.677), textcoords="offset points",
            xytext=(-6,-26), fontsize=7, color=GRN, ha="right")
ax.set_xticks(x); ax.set_xticklabels(lat)
ax.set_ylabel("encoding rate  $k/n$"); ax.set_ylim(0,0.95)
ax.axhline(2/3, ls=":", color=GRY, lw=1)
ax.annotate(r"$2/3$ asymptote", (0.02,2/3+0.01), fontsize=7, color="#555")
ax.set_title("Rate ceiling is set by coordination $K$ (computed)")
ax.legend(loc="upper left", frameon=False)
ax.spines[["top","right"]].set_visible(False)
fig.tight_layout(); fig.savefig("figs/fig_rate_ceiling.pdf", bbox_inches="tight"); plt.close(fig)

# ---------------- FIG 2: FCC vs HCP structure tensors ----------------
# computed: S diag, T max, Q_xxxx/zzzz
fig,axs=plt.subplots(1,3,figsize=(6.6,2.5))
# rank-2 S
for ax,(title,fccv,hcpv,ylab,ymax) in zip(
    axs,
    [("Rank-2  $S_{\\mu\\nu}$\n(leading dispersion)",[4,4,4],[4,4,4],"diagonal value",5.2),
     ("Rank-3  $\\max|T_{\\mu\\nu\\lambda}|$\n(inversion symmetry)",[0.0],[0.289],"max component",0.38),
     ("Rank-4  $Q$ diagonal\n(c-axis anisotropy)",[2.0,2.0,2.0],[2.5,2.5,2.667],"value",3.1)]):
    n=len(fccv); idx=np.arange(n); w=0.36
    ax.bar(idx-w/2, fccv, w, color=ACC, label="FCC")
    ax.bar(idx+w/2, hcpv, w, color=ACC2, label="HCP")
    ax.set_title(title, fontsize=8.2)
    ax.set_ylim(0,ymax); ax.set_ylabel(ylab, fontsize=7.5)
    ax.spines[["top","right"]].set_visible(False)
    if n==3: ax.set_xticks(idx); ax.set_xticklabels(["xx","yy","zz"] if "Rank-2" in title else ["xxxx","yyyy","zzzz"], fontsize=7)
    else: ax.set_xticks([0]); ax.set_xticklabels(["|T|"], fontsize=7)
axs[0].legend(frameon=False, fontsize=7, loc="lower center", ncol=2)
axs[1].annotate("FCC = 0\n(centrosymmetric)", (0,0.02), fontsize=6.6, color=ACC, ha="center", va="bottom")
fig.suptitle("FCC and HCP tie at rank 2; split at rank 3 (T=0 only for FCC)", fontsize=8.8, y=1.04)
fig.tight_layout(); fig.savefig("figs/fig_tensors.pdf", bbox_inches="tight"); plt.close(fig)

# ---------------- FIG 3: AB quasicrystal coordination spectrum vs FCC ----------------
# computed interior spectrum from ab_code.py
fig,axs=plt.subplots(1,2,figsize=(6.4,2.7),gridspec_kw={"width_ratios":[1.6,1]})
ax=axs[0]
coords=[3,4,5,6,7,8]; counts=[24,32,16,8,0,1]  # interior; 7 unsampled in finite patch
bars=ax.bar(coords,counts,color=ACC,width=0.7)
bars[4].set_color(GRY); bars[4].set_hatch("///")
ax.set_xlabel("vertex coordination = Z-stabilizer weight")
ax.set_ylabel("count (interior vertices)")
ax.set_title("Ammann–Beenker approximant:\nnon-uniform local environments", fontsize=8.4)
ax.annotate("7 not sampled\nin finite patch",(7,1.5),fontsize=6.3,color="#777",ha="center")
ax.spines[["top","right"]].set_visible(False)
ax=axs[1]
ax.bar([12],[1],color=GRN,width=0.7)
ax.set_xlim(8,16); ax.set_xticks([12])
ax.set_xlabel("Z-stabilizer weight")
ax.set_title("FCC:\nsingle local term", fontsize=8.4)
ax.set_yticks([])
ax.annotate("weight 12\neverywhere",(12,1.02),fontsize=7,color=GRN,ha="center",va="bottom")
ax.set_ylim(0,1.25)
ax.spines[["top","right","left"]].set_visible(False)
fig.suptitle("Both are valid CSS codes ($H_XH_Z^{T}{=}0$); only FCC is translation-homogeneous",
             fontsize=8.6, y=1.03)
fig.tight_layout(); fig.savefig("figs/fig_quasicrystal.pdf", bbox_inches="tight"); plt.close(fig)

# ---------------- FIG 4: selection cascade (exclusion tree) ----------------
fig,ax=plt.subplots(figsize=(6.6,3.6)); ax.axis("off")
ax.set_xlim(0,10); ax.set_ylim(0,10)
def box(x,y,w,h,txt,fc="#ffffff",ec=INK,fs=7.6,tc=INK):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.04,rounding_size=0.12",
                 fc=fc,ec=ec,lw=1.0))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",fontsize=fs,color=tc,wrap=True)
def arrow(x1,y1,x2,y2,txt="",col=INK):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=11,
                 lw=1.0,color=col,shrinkA=2,shrinkB=2))
    if txt: ax.text((x1+x2)/2+0.15,(y1+y2)/2,txt,fontsize=6.6,color="#444",ha="left",va="center")
# spine boxes (left), excluded (right)
box(3.2,8.6,3.6,1.0,"All discrete geometries\n(candidate vacua)",fc="#ebf4ff",ec=ACC)
box(3.2,6.7,3.6,1.0,"(A1) local-Hamiltonian\nground state",fc="#ffffff")
box(3.2,4.8,3.6,1.0,"(A2) translational\nhomogeneity  $\\Rightarrow$ Bravais",fc="#ffffff")
box(3.2,2.9,3.6,1.0,"(A3) maximal coordination\nat single bond length",fc="#ffffff")
box(3.6,1.0,2.8,1.0,"FCC  [[3$L^3$,2$L^3{+}2$,3]]",fc="#f0fff4",ec=GRN,tc=GRN,fs=8.2)
arrow(5,8.6,5,7.7); arrow(5,6.7,5,5.8); arrow(5,4.8,5,3.9); arrow(5,2.9,5,2.0)
# excluded boxes
box(7.4,6.7,2.5,1.0,"geometric / holographic\nQECC (Penrose, E8)",fc="#fff5f5",ec=RED,fs=6.6,tc=RED)
arrow(6.8,7.2,7.4,7.2,col=RED)
box(7.4,4.8,2.5,1.0,"quasicrystals (5–6 sites)\nHCP + Barlow polytypes",fc="#fff5f5",ec=RED,fs=6.6,tc=RED)
arrow(6.8,5.3,7.4,5.3,col=RED)
box(7.4,2.9,2.5,1.0,"SC, BCC, diamond ($K{<}12$)\nFrank–Kasper (unequal $L$)",fc="#fff5f5",ec=RED,fs=6.6,tc=RED)
arrow(6.8,3.4,7.4,3.4,col=RED)
box(0.1,4.8,2.5,1.0,"witness:\ncoordination {3..8}\n(computed)",fc="#fffaf0",ec=ACC2,fs=6.3,tc=ACC2)
arrow(3.2,5.3,2.6,5.3,col=ACC2)
ax.text(5,0.2,"each exclusion carries a computed or cited witness",fontsize=6.8,
        color="#666",ha="center",style="italic")
fig.savefig("figs/fig_cascade.pdf", bbox_inches="tight"); plt.close(fig)
print("figures written:", )
import os
for f in sorted(os.listdir("figs")): print("  figs/"+f)
