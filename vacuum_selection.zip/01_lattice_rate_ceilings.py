import numpy as np
from itertools import combinations

# ---------- GF(2) rank ----------
def gf2_rank(M):
    M = (np.asarray(M) % 2).astype(np.uint8).copy()
    if M.size == 0: return 0
    rows, cols = M.shape
    r = 0
    for c in range(cols):
        piv = None
        for i in range(r, rows):
            if M[i, c]:
                piv = i; break
        if piv is None: continue
        M[[r, piv]] = M[[piv, r]]
        mask = M[:, c].copy(); mask[r] = 0
        M[mask.astype(bool)] ^= M[r]
        r += 1
        if r == rows: break
    return r

# ---------- lattice builders on an L^3 torus ----------
def build_graph(nodes_set, neighbor_vecs, L, basis_offsets=None):
    """nodes given by integer keys; edges = nearest-neighbor vecs (periodic)."""
    nodes = sorted(nodes_set)
    nidx = {p:i for i,p in enumerate(nodes)}
    edges = set()
    for (x,y,z) in nodes:
        for (dx,dy,dz) in neighbor_vecs:
            nb = ((x+dx)%(2*L),(y+dy)%(2*L),(z+dz)%(2*L))
            if nb in nidx:
                i,j = nidx[(x,y,z)], nidx[nb]
                if i!=j: edges.add((min(i,j),max(i,j)))
    edges = sorted(edges)
    return nodes, nidx, edges

def HZ_from_edges(V, edges):
    H = np.zeros((V, len(edges)), dtype=np.uint8)
    for ei,(i,j) in enumerate(edges):
        H[i,ei]=1; H[j,ei]=1
    return H

# Simple cubic: all integer points, NN = ±e
def lat_SC(L):
    nodes={(x,y,z) for x in range(L) for y in range(L) for z in range(L)}
    nv=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
    # remap to torus side L
    nidx={p:i for i,p in enumerate(sorted(nodes))}
    edges=set()
    for (x,y,z) in nodes:
        for (dx,dy,dz) in nv:
            nb=((x+dx)%L,(y+dy)%L,(z+dz)%L)
            i,j=nidx[(x,y,z)],nidx[nb]
            if i!=j: edges.add((min(i,j),max(i,j)))
    return sorted(nodes),nidx,sorted(edges)

# FCC: x+y+z even on 2L box, NN = 12 face-diagonal vecs
def lat_FCC(L):
    side=2*L
    nodes={(x,y,z) for x in range(side) for y in range(side) for z in range(side) if (x+y+z)%2==0}
    nv=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),
        (1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
        (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
    nidx={p:i for i,p in enumerate(sorted(nodes))}
    edges=set()
    for (x,y,z) in nodes:
        for (dx,dy,dz) in nv:
            nb=((x+dx)%side,(y+dy)%side,(z+dz)%side)
            if nb in nidx:
                i,j=nidx[(x,y,z)],nidx[nb]
                if i!=j: edges.add((min(i,j),max(i,j)))
    return sorted(nodes),nidx,sorted(edges)

# BCC: integer points + body centers; in 2x scaled integer coords,
# nodes = points with all-even or all-odd coords; NN = (±1,±1,±1)
def lat_BCC(L):
    side=2*L
    nodes={(x,y,z) for x in range(side) for y in range(side) for z in range(side)
           if (x%2==y%2==z%2)}
    nv=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(-1,1,1),(-1,1,-1),(-1,-1,1),(-1,-1,-1)]
    nidx={p:i for i,p in enumerate(sorted(nodes))}
    edges=set()
    for (x,y,z) in nodes:
        for (dx,dy,dz) in nv:
            nb=((x+dx)%side,(y+dy)%side,(z+dz)%side)
            if nb in nidx:
                i,j=nidx[(x,y,z)],nidx[nb]
                if i!=j: edges.add((min(i,j),max(i,j)))
    return sorted(nodes),nidx,sorted(edges)

# Diamond: FCC + (1,1,1) basis. Use scaled coords side 4L.
def lat_DIAMOND(L):
    side=4*L
    # FCC sublattice A: x+y+z ... use standard diamond: two interpenetrating FCC
    # nodes at FCC positions and FCC+ (1,1,1)/4 -> in side-4 units offset (1,1,1)
    A={(x,y,z) for x in range(0,side,2) for y in range(0,side,2) for z in range(0,side,2) if ((x//2)+(y//2)+(z//2))%2==0}
    B={((x+1)%side,(y+1)%side,(z+1)%side) for (x,y,z) in A}
    nodes=A|B
    nidx={p:i for i,p in enumerate(sorted(nodes))}
    nv=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(-1,1,1),(-1,1,-1),(-1,-1,1),(-1,-1,-1)]
    edges=set()
    for (x,y,z) in nodes:
        for (dx,dy,dz) in nv:
            nb=((x+dx)%side,(y+dy)%side,(z+dz)%side)
            if nb in nidx:
                i,j=nidx[(x,y,z)],nidx[nb]
                if i!=j: edges.add((min(i,j),max(i,j)))
    return sorted(nodes),nidx,sorted(edges)

def analyze(name, nodes, nidx, edges):
    V=len(nodes); E=len(edges)
    HZ=HZ_from_edges(V, edges)
    degs=HZ.sum(0)  # not used
    K = int(round(2*E/V))
    rkZ=gf2_rank(HZ)
    cyc = E - rkZ          # cycle space dim (= max possible k with vertex Z-checks)
    ceil = cyc/E
    # actual node degrees
    nodedeg=np.zeros(V,dtype=int)
    for (i,j) in edges: nodedeg[i]+=1; nodedeg[j]+=1
    Kmode=int(np.bincount(nodedeg).argmax())
    return dict(name=name,V=V,E=E,K=Kmode,rkZ=rkZ,cyc=cyc,ceil=ceil)

for L in [2,3]:
    print(f"\n===== L={L} =====")
    for nm,fn in [("SC",lat_SC),("BCC",lat_BCC),("FCC",lat_FCC),("Diamond",lat_DIAMOND)]:
        nodes,nidx,edges=fn(L)
        d=analyze(nm,nodes,nidx,edges)
        print(f"{d['name']:8s} V={d['V']:4d} E={d['E']:5d} K={d['K']:2d} rk(HZ)={d['rkZ']:4d} "
              f"cycle_dim={d['cyc']:5d}  rate_ceiling(1-2/K? )={d['ceil']:.3f}  1-2/K={1-2/d['K']:.3f}")

print("\n\n########## ACHIEVED CODES (X-stabilizer choice matters) ##########")

# ---- FCC with octahedral-void X-stabilizers (Paper 1 construction) ----
def fcc_void_code(L):
    side=2*L
    nodes=sorted({(x,y,z) for x in range(side) for y in range(side) for z in range(side) if (x+y+z)%2==0})
    nidx={p:i for i,p in enumerate(nodes)}
    nv=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),(-1,0,-1),
        (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
    edges=[]; eidx={}
    for (x,y,z) in nodes:
        i=nidx[(x,y,z)]
        for (dx,dy,dz) in nv:
            nb=((x+dx)%side,(y+dy)%side,(z+dz)%side)
            if nb in nidx:
                j=nidx[nb]
                if i<j: eidx[(i,j)]=len(edges); edges.append((i,j))
    # octahedral voids at odd-parity sites, 6 axis neighbors
    octs=[]
    for x in range(side):
        for y in range(side):
            for z in range(side):
                if (x+y+z)%2==1:
                    nbs=[]
                    for d in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]:
                        nb=((x+d[0])%side,(y+d[1])%side,(z+d[2])%side)
                        if nb in nidx: nbs.append(nidx[nb])
                    if len(nbs)==6: octs.append(set(nbs))
    E=len(edges)
    HZ=np.zeros((len(nodes),E),dtype=np.uint8)
    for (i,j),ei in eidx.items(): HZ[i,ei]=1; HZ[j,ei]=1
    HX=np.zeros((len(octs),E),dtype=np.uint8)
    for oi,s in enumerate(octs):
        for (i,j),ei in eidx.items():
            if i in s and j in s: HX[oi,ei]=1
        # parity
    css_ok = ((HX@HZ.T)%2).sum()==0
    rkZ=gf2_rank(HZ); rkX=gf2_rank(HX)
    k=E-rkZ-rkX
    xw=HX.sum(1); 
    return E,len(nodes),len(octs),rkZ,rkX,k,css_ok,(int(xw.min()),int(xw.max()))

for L in [2,3]:
    E,V,no,rkZ,rkX,k,css,xw=fcc_void_code(L)
    print(f"FCC void-code  L={L} (Paper-L={2*L}):  n={E} k={k} rate={k/E:.3f}  CSS_ok={css}  Xweight={xw}  [matches Paper1 k=130/434]")

# ---- SC standard toric (square plaquettes) -> should give k=3 ----
def sc_toric_code(L):
    nodes=sorted({(x,y,z) for x in range(L) for y in range(L) for z in range(L)})
    nidx={p:i for i,p in enumerate(nodes)}
    nv=[(1,0,0),(0,1,0),(0,0,1)]
    edges=[]; eidx={}
    for (x,y,z) in nodes:
        i=nidx[(x,y,z)]
        for (dx,dy,dz) in nv:
            nb=((x+dx)%L,(y+dy)%L,(z+dz)%L)
            j=nidx[nb]
            key=(min(i,j),max(i,j))
            if key not in eidx and i!=j: eidx[key]=len(edges); edges.append(key)
    E=len(edges)
    # plaquettes: for each vertex, 3 square faces (xy,yz,zx)
    def edge(a,b):
        return eidx[(min(a,b),max(a,b))]
    plaqs=[]
    for (x,y,z) in nodes:
        v=nidx[(x,y,z)]
        for (d1,d2) in [((1,0,0),(0,1,0)),((0,1,0),(0,0,1)),((1,0,0),(0,0,1))]:
            a=nidx[(x,y,z)]
            b=nidx[((x+d1[0])%L,(y+d1[1])%L,(z+d1[2])%L)]
            c=nidx[((x+d1[0]+d2[0])%L,(y+d1[1]+d2[1])%L,(z+d1[2]+d2[2])%L)]
            dd=nidx[((x+d2[0])%L,(y+d2[1])%L,(z+d2[2])%L)]
            try:
                plaqs.append([edge(a,b),edge(b,c),edge(c,dd),edge(dd,a)])
            except KeyError:
                pass
    HZ=np.zeros((len(nodes),E),dtype=np.uint8)
    for (i,j),ei in eidx.items(): HZ[i,ei]=1; HZ[j,ei]=1
    HX=np.zeros((len(plaqs),E),dtype=np.uint8)
    for pi,es in enumerate(plaqs):
        for e in es: HX[pi,e]^=1
    css=((HX@HZ.T)%2).sum()==0
    rkZ=gf2_rank(HZ); rkX=gf2_rank(HX)
    return E,len(nodes),rkZ,rkX,E-rkZ-rkX,css

for L in [3,4]:
    E,V,rkZ,rkX,k,css=sc_toric_code(L)
    print(f"SC toric-code  L={L}: n={E} k={k} rate={k/E:.3f} CSS_ok={css}  [standard 3D toric: k=3]")
