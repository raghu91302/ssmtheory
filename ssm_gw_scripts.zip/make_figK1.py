import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
L02=1.843**2; cS=2*np.pi; cF=8.108
INK='#222222'; MUTED='#6b6b6b'; ACC='#2a6fdb'; ACC2='#c2571a'
plt.rcParams.update({'font.size':9,'axes.edgecolor':MUTED,'xtick.color':MUTED,'ytick.color':MUTED})
j=np.linspace(0.1,0.6,200)
fig,ax=plt.subplots(figsize=(5.2,3.6))
jS,jF=L02/(2*cS),L02/(2*cF)
ax.axvspan(jF,jS,color='0.88',lw=0,zorder=0)
ax.axhline(1,color=INK,lw=1.2,ls='--')
ax.text(0.585,1.06,'Kerr bound',ha='right',fontsize=8,color=INK)
ax.plot(j,2*cS*j/L02,color=ACC,lw=2,label='single circuit per ring ($c_W=2\\pi$)')
ax.plot(j,2*cF*j/L02,color=ACC2,lw=2,label='every row independent ($c_W=8.11$)')
for k in (3,4,5):
    ax.axvline(1/k,color=MUTED,lw=0.8,ls=':')
    ax.text(1/k+0.008,0.12,f'$\\hbar/{k}$',ha='left',fontsize=8,color=INK)
ax.axvline(0.5,color=MUTED,lw=0.8,ls=':'); ax.text(0.512,0.12,'$\\hbar/2$',ha='left',fontsize=8,color=INK)
ax.set_xlim(0.1,0.6)
ax.text(0.24,2.05,'saturation\nbracket',ha='center',fontsize=8,color=INK); ax.set_ylim(0,2.9)
ax.set_xlabel('angular momentum per unit winding $j_w$ [$\\hbar$]')
ax.set_ylabel('winding capacity / Kerr bound')
ax.legend(fontsize=8,frameon=False,loc='upper right',bbox_to_anchor=(0.62,1.0))
for s in ['right','top']: ax.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig('figK1_bound.pdf'); fig.savefig('figK1_bound.png',dpi=130)
print(f"bracket {jF:.3f}-{jS:.3f}")
