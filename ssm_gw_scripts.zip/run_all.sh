#!/usr/bin/env bash
# Reproduces every number and figure in "Bond-Counted Horizon Entropy and the
# Black-Hole Area Quantum: a Test Against 18 Ringdowns and a Spin Cap".
set -e
python3 gw_area_quant.py        # alpha = 4 ln 2, line spacings; Figs. 1-2 (figA_ladder, figB_alpha)
python3 kerr_faceted.py         # FCC winding capacity, Kerr saturation bracket (slow: ~minutes)
python3 make_figK1.py           # Fig. 3 (figK1_bound)
python3 gw250114_area_quant.py  # GW250114 test, alpha scan (writes alpha_scan.txt)
python3 make_figG1.py           # Fig. 4 (figG1_gw250114)
python3 gwtc4_stack.py          # 17 GWTC-4.0 events + GW250114, stacked test (writes alpha_scan_stack.txt)
python3 make_figG2.py           # Fig. 5 (figG2_stack)
