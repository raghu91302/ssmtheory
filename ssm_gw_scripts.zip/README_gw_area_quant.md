# Scripts for "Bond-Counted Horizon Entropy and the Black-Hole Area Quantum: a Test Against 18 Ringdowns and a Spin Cap"

R. Kulkarni, SSMTheory Group. Every number and figure in the paper is produced by the scripts here.

| script | what it computes | paper |
|---|---|---|
| `gw_area_quant.py` | area quantum alpha = 4 ln 2, transition-line spacings, rival combs | Sec. 2-3, Figs. 1-2 |
| `kerr_faceted.py` | FCC enumeration of the Nyquist winding capacity; isotropy; Kerr saturation bracket j_w = 0.209-0.270 hbar | Sec. 4 |
| `make_figK1.py` | winding capacity vs Kerr bound | Fig. 3 |
| `gw250114_area_quant.py` | GW250114: predicted delta f_220 = +1.1%, Bayes factors vs GR | Sec. 5, Fig. 4 |
| `make_figG1.py` | GW250114 figure | Fig. 4 |
| `gwtc4_stack.py` | stacked test against 17 GWTC-4.0 events + GW250114; alpha scan; expected sensitivity | Sec. 5, Fig. 5 |
| `make_figG2.py` | catalog figure | Fig. 5 |

Run everything: `pip install -r requirements.txt && ./run_all.sh`

Data inputs are the published summary values (90% intervals) of LVK, arXiv:2509.08054, arXiv:2509.08099 (GW250114) and arXiv:2603.19021 (GWTC-4.0 remnant tests, pSEOBNR Table 3), typed into the scripts. These are summary-statistic analyses, not strain-level fits; see limitation L4 of the paper.
