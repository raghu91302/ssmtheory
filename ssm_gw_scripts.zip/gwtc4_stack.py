"""Stacked test of fixed-alpha horizon-area quantization against the GWTC-4.0 ringdown
results (pSEOBNR, Table 3 of LVK, arXiv:2603.19021) plus GW250114 (arXiv:2509.08099).

For each event the model predicts the fractional offset of the observed l=m=2, n=0
frequency from its GR value: the frequency is pulled to the nearest allowed line
omega_n = n alpha kappa/(8pi) + 2 Omega_H.  The offset depends on the remnant spin only.
GR predicts zero.  Likelihoods: published 90% intervals -> split normals; spin from the
IMR (GR) remnant column, marginalized as a split normal.
"""
import numpy as np
Z=1.6449
def wgr(chi): return 1.5251-1.1568*(1-chi)**0.1292           # Berti-Cardoso-Will 220 fit
def kap(chi): s=np.sqrt(1-chi**2); return s/(2*(1+s))
def omH(chi): return chi/(2*(1+np.sqrt(1-chi**2)))
def dpred(chi,alpha):
    w=wgr(chi); sp=alpha*kap(chi)/(8*np.pi); b=2*omH(chi)
    n=np.round((w-b)/sp); return (b+n*sp-w)/w
def splitnorm_draw(rng,med,up,lo,N):
    u=rng.random(N); s_up=up/Z; s_lo=lo/Z; z=np.abs(rng.normal(size=N))
    return np.where(u<s_up/(s_up+s_lo), med+z*s_up, med-z*s_lo)
def like(x,med,up,lo):
    s=np.where(x>med,up/Z,lo/Z); return np.exp(-0.5*((x-med)/s)**2)

# event, dF med, +, -, chi_IMR med, +, -        (pSEOBNR delta f_220; IMR remnant spin)
EV=[("GW150914",0.02,0.10,0.07,0.68,0.05,0.05),
("GW170104",-0.02,0.16,0.14,0.67,0.06,0.08),
("GW190519_153544",-0.15,0.19,0.13,0.79,0.07,0.12),
("GW190521_074359",0.06,0.19,0.10,0.71,0.06,0.06),
("GW190630_185205",-0.06,0.14,0.19,0.70,0.06,0.07),
("GW190828_063405",0.10,0.13,0.12,0.74,0.07,0.07),
("GW190910_112807",0.01,0.13,0.10,0.69,0.07,0.08),
("GW200129_065458",-0.01,0.06,0.08,0.73,0.06,0.05),
("GW200224_222234",0.01,0.15,0.12,0.73,0.07,0.07),
("GW200311_115853",0.02,0.17,0.09,0.69,0.07,0.08),
("GW230628_231200",0.08,0.17,0.11,0.69,0.07,0.06),
("GW230914_111401",-0.12,0.15,0.11,0.71,0.09,0.13),
("GW230927_153832",-0.01,0.09,0.07,0.69,0.04,0.03),
("GW231028_153006",-0.23,0.19,0.11,0.84,0.05,0.08),
("GW231102_071736",0.25,0.32,0.27,0.70,0.09,0.10),
("GW231206_233901",-0.03,0.12,0.09,0.67,0.06,0.07),
("GW231226_101520",0.02,0.14,0.07,0.67,0.04,0.04),
("GW250114 (O4c)",0.02,0.02,0.02,0.68,0.01,0.01)]

def lnB(alpha, ev, N=200000, seed=3):
    rng=np.random.default_rng(seed)
    _,d,du,dl,c,cu,cl=ev
    chi=splitnorm_draw(rng,c,cu,cl,N); chi=chi[(chi>0.01)&(chi<0.995)]
    return np.log(np.mean(like(dpred(chi,alpha),d,du,dl))/like(np.zeros(1),d,du,dl)[0])

A={"4ln2 (SSM)":4*np.log(2),"4ln3 (Hod)":4*np.log(3),"8pi":8*np.pi}
print(f"{'event':18s} {'meas dF':>13s} {'chi':>5s} {'SSM pred':>9s} {'lnB 4ln2':>9s} {'lnB 4ln3':>9s} {'lnB 8pi':>8s}")
tot={k:0.0 for k in A}; tot_o4a={k:0.0 for k in A}
for ev in EV:
    r={k:lnB(a,ev) for k,a in A.items()}
    for k in A:
        tot[k]+=r[k]
        if "250114" not in ev[0]: tot_o4a[k]+=r[k]
    print(f"{ev[0]:18s} {ev[1]:+.2f}+{ev[2]:.2f}-{ev[3]:.2f} {ev[4]:5.2f} {dpred(np.array([ev[4]]),A['4ln2 (SSM)'])[0]*100:+8.2f}% "
          f"{r['4ln2 (SSM)']:+9.2f} {r['4ln3 (Hod)']:+9.2f} {r['8pi']:+8.2f}")
print("\nsummed ln Bayes factor vs GR (17 GWTC-4.0 events):", {k:round(v,2) for k,v in tot_o4a.items()})
print("summed ln Bayes factor vs GR (17 + GW250114):       ", {k:round(v,2) for k,v in tot.items()})

# expected sensitivity: if SSM were true, expected summed lnB; and if GR true
rng=np.random.default_rng(9)
def expected(true_ssm, M=400):
    out=[]
    for m in range(M):
        s=0.0
        for ev in EV:
            _,d,du,dl,c,cu,cl=ev
            sig=(du+dl)/2/Z
            mu=dpred(np.array([c]),A["4ln2 (SSM)"])[0] if true_ssm else 0.0
            dsim=rng.normal(mu,sig)
            s+=lnB(A["4ln2 (SSM)"],(None,dsim,du,dl,c,cu,cl),N=4000,seed=m)
        out.append(s)
    return np.mean(out),np.std(out)
for t in (False,True):
    m,sd=expected(t)
    print(f"expected summed lnB(4ln2 vs GR) if {'SSM' if t else 'GR'} true: {m:+.2f} +/- {sd:.2f}")

# alpha scan of the summed evidence
al=np.linspace(1.5,40,300); S=[]
for a in al: S.append(sum(lnB(a,ev,N=20000) for ev in EV))
S=np.array(S); np.savetxt("alpha_scan_stack.txt",np.c_[al,S],header="alpha summed_lnB")
print(f"\nalpha scan: summed lnB max {S.max():+.2f} at alpha={al[S.argmax()]:.2f}; at 4ln2 {S[np.argmin(abs(al-4*np.log(2)))]:+.2f}")
for a0 in (5,10,15,20,25,30,35): print(f"  alpha={a0}: {S[np.argmin(abs(al-a0))]:+.1f}")
