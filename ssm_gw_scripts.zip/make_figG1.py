import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from gw250114_area_quant import omega_gr, kappa, omega_H
Tm=68.4*4.925491e-6; chi=0.68
fgr=omega_gr(chi)/Tm/2/np.pi
def lines(a):
    base=2*omega_H(chi)/Tm/2/np.pi; sp=a*kappa(chi)/(8*np.pi)/Tm/2/np.pi
    return [base+n*sp for n in range(0,40) if 200<base+n*sp<300]
INK='#222222'; MUTED='#6b6b6b'; ACC='#2a6fdb'; ACC2='#c2571a'
plt.rcParams.update({'font.size':9,'axes.edgecolor':MUTED,'axes.labelcolor':INK,
                     'xtick.color':MUTED,'ytick.color':MUTED})
fig,(ax1,ax2)=plt.subplots(2,1,figsize=(6.0,5.4),gridspec_kw={'height_ratios':[1,1.15]})
# (a) frequency picture
rows=[("$4\\ln2$ (SSM)",4*np.log(2),ACC),("$4\\ln3$ (Hod)",4*np.log(3),MUTED),("$8\\pi$",8*np.pi,ACC2)]
ax1.axvspan(251.7-5.0,251.7+5.1,color='0.85',lw=0,zorder=0)
ax1.axvline(251.7,color='0.45',lw=1,zorder=1)
ax1.text(257.4,3.45,'measured $f_{220}$ (90%)',ha='left',fontsize=8,color=INK)
ax1.axvline(fgr,color=INK,lw=1.2,ls='--',zorder=2)
ax1.text(fgr-0.6,-0.62,'GR',ha='right',fontsize=8,color=INK)
for i,(lab,a,col) in enumerate(rows):
    y=2.6-i*1.05
    for f in lines(a): ax1.plot([f,f],[y-0.35,y+0.35],color=col,lw=2,solid_capstyle='round')
    ax1.text(-0.01,(y+0.8)/4.7,lab,va='center',ha='right',fontsize=8,color=INK,transform=ax1.transAxes)
ax1.set_xlim(200,300); ax1.set_ylim(-0.8,3.9); ax1.set_yticks([])
for s in ['left','right','top']: ax1.spines[s].set_visible(False)
ax1.set_xlabel('frequency [Hz]  (GW250114 remnant, $\\chi_f=0.68$)')
ax1.set_title('(a) allowed $\\ell=m=2$ emission lines vs the measured frequency',fontsize=9,loc='left',color=INK)
# (b) Bayes factor scan
al,lb=np.loadtxt('alpha_scan.txt',unpack=True)
ax2.axhline(0,color=MUTED,lw=0.8)
ax2.plot(al,lb,color=INK,lw=1.4)
for lab,a,col in rows:
    from gw250114_area_quant import log_bf
    v=log_bf(a,0.02,0.02/1.6449,0.02/1.6449)
    ax2.plot(a,v,'o',ms=7,color=col,mec='white',mew=1.5,zorder=5)
    off={'$4\\ln2$ (SSM)':(-4,-16),'$4\\ln3$ (Hod)':(8,8)}.get(lab,(8,-4))
    ax2.annotate(lab,(a,v),textcoords='offset points',xytext=off,fontsize=8,color=INK)
ax2.set_xlim(1,40); ax2.set_ylim(-60,5)
ax2.set_xlabel('area-quantization constant $\\alpha$  ($\\Delta A=\\alpha\\,\\ell_P^2$)')
ax2.set_ylabel('$\\ln$ Bayes factor vs GR')
ax2.grid(axis='y',color='0.9',lw=0.6)
for s in ['right','top']: ax2.spines[s].set_visible(False)
ax2.set_title('(b) narrow-line quantization vs GR, pSEOBNR $\\delta\\hat f_{220}$',fontsize=9,loc='left',color=INK)
fig.tight_layout(); fig.savefig('figG1_gw250114.pdf'); fig.savefig('figG1_gw250114.png',dpi=130)
print('ok')
