import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
src=open("gwtc4_stack.py").read().split("A={")[0]; ns={}; exec(src,ns)
EV,dpred=ns['EV'],ns['dpred']
INK='#222222'; MUTED='#6b6b6b'; ACC='#2a6fdb'; ACC2='#c2571a'
plt.rcParams.update({'font.size':8.5,'axes.edgecolor':MUTED,'xtick.color':MUTED,'ytick.color':MUTED})
fig,(ax1,ax2)=plt.subplots(1,2,figsize=(7.6,4.6),gridspec_kw={'width_ratios':[1.7,1]})
y=np.arange(len(EV))[::-1]
for yi,ev in zip(y,EV):
    n,d,du,dl,c,cu,cl=ev
    ax1.errorbar(d*100,yi,xerr=[[dl*100],[du*100]],fmt='o',ms=4,color=INK,ecolor='0.55',elinewidth=1.2,capsize=0,zorder=3)
    p=dpred(np.array([c]),4*np.log(2))[0]*100
    ax1.plot(p,yi,'D',ms=5,color=ACC,mec='white',mew=0.8,zorder=4)
    p8=dpred(np.array([c]),8*np.pi)[0]*100
    ax1.plot(p8,yi,'s',ms=4.5,color=ACC2,mec='white',mew=0.8,zorder=4)
ax1.axvline(0,color=MUTED,lw=0.9,ls='--')
ax1.set_yticks(y); ax1.set_yticklabels([e[0] for e in EV],fontsize=7.5)
ax1.set_xlabel(r'$\delta\hat f_{220}$ [%]   (measured: black, 90%)')
ax1.set_xlim(-45,60)
ax1.plot([],[],'D',color=ACC,label=r'$\alpha=4\ln2$ prediction')
ax1.plot([],[],'s',color=ACC2,label=r'$\alpha=8\pi$ prediction')
ax1.legend(fontsize=7.5,frameon=False,loc='lower right')
for s in ['right','top']: ax1.spines[s].set_visible(False)
ax1.set_title('(a) per-event ringdown frequency shift',fontsize=9,loc='left',color=INK)
al,S=np.loadtxt('alpha_scan_stack.txt',unpack=True)
ax2.axhline(0,color=MUTED,lw=0.8); ax2.plot(al,S,color=INK,lw=1.4)
for lab,a,col in [(r'$4\ln2$',4*np.log(2),ACC),(r'$4\ln3$',4*np.log(3),'0.45'),(r'$8\pi$',8*np.pi,ACC2)]:
    v=S[np.argmin(abs(al-a))]; ax2.plot(a,v,'o',ms=6,color=col,mec='white',mew=1.2,zorder=5)
    off={r'$4\ln2$':(-6,-14),r'$4\ln3$':(6,-14)}.get(lab,(6,4))
    ax2.annotate(lab,(a,v),textcoords='offset points',xytext=off,fontsize=8,color=INK,ha='right' if lab==r'$4\ln2$' else 'left')
ax2.set_xlim(0,40); ax2.set_ylim(-100,8)
ax2.set_xlabel(r'area quantum $\alpha$'); ax2.set_ylabel(r'summed $\ln$ Bayes factor vs GR')
ax2.grid(axis='y',color='0.9',lw=0.6)
for s in ['right','top']: ax2.spines[s].set_visible(False)
ax2.set_title('(b) 18 events combined',fontsize=9,loc='left',color=INK)
fig.tight_layout(); fig.savefig('figG2_stack.pdf'); fig.savefig('figG2_stack.png',dpi=130); print('ok')
