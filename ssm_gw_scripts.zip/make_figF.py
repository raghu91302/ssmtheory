"""Fig. 1: the SSM framework in four panels.
(a) Z-check: one FCC node and its 12 bonds (weight 12).
(b) X-check: the 12 bonds among the 6 nodes around an octahedral void (weight 12).
(c) Schematic horizon cross-section on a close-packed (111) plane.
(d) Direct count of FCC bonds crossing spheres vs. area, and the RT-cell count
    that carries the entropy (Kulkarni, EPJ Plus 141, 916 (2026), Secs. 5-6).
Requires numpy, matplotlib.
"""
import numpy as np, matplotlib, itertools
matplotlib.use('Agg'); import matplotlib.pyplot as plt
INK = '#222222'; MUTED = '#6b6b6b'; ACC = '#2a6fdb'; ACC2 = '#c2571a'; LIGHT = '#c9c9c9'
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': MUTED,
                     'xtick.color': MUTED, 'ytick.color': MUTED})
C1 = np.sqrt(4*np.log(2)/np.sqrt(2/3))   # L0/l_P = 1.843 (companion Eq. 4)
NU_STAR = 2*np.sqrt(3)             # bulk bonds per RT cell (companion Eq. 7)

# FCC nearest-neighbour vectors in cubic units (bond length sqrt 2)
NN = np.array([v for v in itertools.product((-1, 0, 1), repeat=3)
               if sorted(map(abs, v)) == [0, 1, 1]], float)
assert len(NN) == 12

fig = plt.figure(figsize=(7.2, 6.2))

# ---- (a) vertex Z-check ------------------------------------------------------
ax = fig.add_subplot(2, 2, 1, projection='3d')
for i, j in itertools.combinations(range(12), 2):      # cuboctahedron of neighbours
    if np.isclose(np.linalg.norm(NN[i]-NN[j]), np.sqrt(2)):
        ax.plot(*zip(NN[i], NN[j]), color=LIGHT, lw=0.7)
for v in NN:
    ax.plot([0, v[0]], [0, v[1]], [0, v[2]], color=ACC, lw=1.6)
ax.scatter(NN[:, 0], NN[:, 1], NN[:, 2], s=22, color='white', edgecolor=INK, depthshade=False)
ax.scatter([0], [0], [0], s=60, color=ACC, edgecolor=INK, depthshade=False)
ax.set_title('(a) $Z$-check: one node, 12 bonds', fontsize=9, color=INK)

# ---- (b) octahedral X-check -------------------------------------------------
ax2 = fig.add_subplot(2, 2, 2, projection='3d')
octn = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], float)
ne = 0
for i, j in itertools.combinations(range(6), 2):
    if np.isclose(np.linalg.norm(octn[i]-octn[j]), np.sqrt(2)):
        ax2.plot(*zip(octn[i], octn[j]), color=ACC2, lw=1.6); ne += 1
assert ne == 12
ax2.scatter(octn[:, 0], octn[:, 1], octn[:, 2], s=40, color='white', edgecolor=INK, depthshade=False)
ax2.scatter([0], [0], [0], s=30, marker='x', color=INK, depthshade=False)
ax2.set_title('(b) $X$-check: octahedral void, 12 bonds', fontsize=9, color=INK)
for a in (ax, ax2):
    a.set_box_aspect((1, 1, 1)); a.set_axis_off(); a.view_init(elev=18, azim=32)
    lim = 1.05; a.set_xlim(-lim, lim); a.set_ylim(-lim, lim); a.set_zlim(-lim, lim)

# ---- (c) horizon schematic on a (111) plane -----------------------------------
ax3 = fig.add_subplot(2, 2, 3)
a1, a2 = np.array([1, 0]), np.array([0.5, np.sqrt(3)/2])
pts = np.array([i*a1 + j*a2 for i in range(-12, 13) for j in range(-12, 13)])
pts = pts[(np.abs(pts[:, 0]) < 7.2) & (np.abs(pts[:, 1]) < 5.6)]
c0 = np.array([0.23, 0.17]); R = 3.6
inside = np.linalg.norm(pts - c0, axis=1) < R
for i, j in itertools.combinations(range(len(pts)), 2):
    if abs(np.linalg.norm(pts[i]-pts[j]) - 1) < 1e-6:
        cross = inside[i] != inside[j]
        ax3.plot(*zip(pts[i], pts[j]), color=ACC2 if cross else (LIGHT if not inside[i] else '#9a9a9a'),
                 lw=1.5 if cross else 0.7, zorder=2 if cross else 1)
ax3.scatter(*pts[~inside].T, s=12, color='white', edgecolor=MUTED, lw=0.6, zorder=3)
ax3.scatter(*pts[inside].T, s=12, color='#555555', zorder=3)
th = np.linspace(0, 2*np.pi, 300)
ax3.plot(c0[0] + R*np.cos(th), c0[1] + R*np.sin(th), color=INK, lw=1.0, ls='--', zorder=4)
ax3.text(c0[0], c0[1], 'interior:\nfrozen $\\mathbb{Z}_2$ bonds\n($K=0$ vacancy\nseen from outside)',
         ha='center', va='center', fontsize=7, color='white', zorder=5,
         bbox=dict(boxstyle='round,pad=0.25', fc='#555555', ec='none'))
ax3.text(0, -6.1, 'open nodes: $K=12$ exterior vacuum;  red: bonds cut by the horizon',
         ha='center', va='top', fontsize=7.2, color=INK)
ax3.set_ylim(-6.9, 5.8)
ax3.set_aspect('equal'); ax3.set_axis_off()
ax3.set_title('(c) horizon on a close-packed plane (schematic)', fontsize=9, color=INK)

# ---- (d) direct bond count ----------------------------------------------------
def crossing_bonds(R, centre):
    """Bonds of the FCC lattice (bond length 1) with exactly one end inside a sphere."""
    s = 1/np.sqrt(2); n = int(np.ceil(R/s)) + 2
    g = np.arange(-n, n+1)
    X, Y, Z = np.meshgrid(g, g, g, indexing='ij')
    P = np.stack([X.ravel(), Y.ravel(), Z.ravel()], 1)
    P = P[(P.sum(1) % 2) == 0] * s
    ins = np.linalg.norm(P - centre, axis=1) < R
    Pin = P[ins]
    cnt = 0
    for v in NN*s:
        cnt += np.count_nonzero(np.linalg.norm(Pin + v - centre, axis=1) >= R)
    return cnt

rng = np.random.default_rng(1)
radii = np.linspace(4, 16, 24) / C1          # 4-16 l_P, in units of L0
A_lP, Nb = [], []
for R in radii:
    centre = rng.uniform(0, 1, 3)
    A_lP.append(4*np.pi*(R*C1)**2); Nb.append(crossing_bonds(R, centre))
A_lP, Nb = np.array(A_lP), np.array(Nb)
coef_bulk = 3*np.sqrt(2)/C1**2               # bonds per l_P^2, companion Eq. (6)
fit = np.sum(Nb*A_lP)/np.sum(A_lP**2)

ax4 = fig.add_subplot(2, 2, 4)
Ax = np.linspace(0, A_lP.max()*1.03, 100)
ax4.plot(Ax, coef_bulk*Ax, color=INK, lw=1.0, label='$3\\sqrt{2}\\,A/L_0^2$ (bulk bond count)')
ax4.plot(A_lP, Nb, 'o', ms=3.5, color=ACC2, label='direct count, bonds cut')
ax4.plot(Ax, Ax/(4*np.log(2)), color=ACC, lw=2,
         label='RT cells $A/(4\\ln2\\,\\ell_P^2)$ = bits')
ax4.set_xlabel('horizon area $A$ [$\\ell_P^2$]'); ax4.set_ylabel('count')
ax4.legend(fontsize=7.5, frameon=False, loc='upper left')
ax4.text(0.97, 0.06, f'bonds per cell $\\nu^*=2\\sqrt{{3}}={NU_STAR:.3f}$',
         transform=ax4.transAxes, ha='right', fontsize=7.5, color=INK)
for s_ in ['right', 'top']: ax4.spines[s_].set_visible(False)
ax4.set_title('(d) entropy counts are linear in area', fontsize=9, color=INK)
ax4.set_xlim(0, None); ax4.set_ylim(0, None)

fig.tight_layout(h_pad=1.2)
fig.savefig('figF_framework.pdf'); fig.savefig('figF_framework.png', dpi=130)
print(f"direct-count slope {fit:.4f} bonds/l_P^2 vs 3 sqrt2/c1^2 = {coef_bulk:.4f} "
      f"(ratio {fit/coef_bulk:.4f}); RT cells {1/(4*np.log(2)):.4f}/l_P^2; "
      f"bulk/RT = {coef_bulk*4*np.log(2):.4f} (2 sqrt3 = {NU_STAR:.4f})")
