#!/usr/bin/env python3
"""Summary-statistic test of horizon area quantization with GW250114.

Model (Foit-Kleban / Laghi et al.): a quantized Kerr horizon emits only at
  hbar*omega = kappa*DeltaA/(8 pi) + Omega_H*DeltaJ,  DeltaA = n*alpha*l_P^2, DeltaJ = 2 hbar
for the l=m=2 mode, i.e. in G=c=hbar=1 units
  omega_n = n*alpha*kappa/(8 pi) + 2*Omega_H .
The emitted 220 frequency is pulled to the nearest line, so the fractional
deviation from the GR value,
  delta_f = (omega_line - omega_GR)/omega_GR ,
depends only on the remnant spin chi (the mass cancels).  The SSM fixes
alpha = 4 ln 2, and with j_w = hbar/2 its winding extension carries DeltaJ = 2 hbar
in w = 4 units, so its line positions for the 220 mode coincide with these.

Inputs (LVK, arXiv:2509.08054 and 2509.08099, 90% intervals):
  chi_f = 0.68 +/- 0.01  (IMR, NRSur7dq4)
  delta f_220 = 0.02 +0.02 -0.02   (pSEOBNR, full signal)
  delta f_220 = 0.09 +0.34 -0.22   (pyRing KerrPostmerger, post-peak)
Approximation: published 90% intervals turned into Gaussians, chi and delta f
treated as independent.  This is a summary-statistic analysis, not a strain fit.
"""
import numpy as np
Z90 = 1.6449

def omega_gr(chi):           # Berti, Cardoso & Will (2006) fit, l=m=2, n=0; omega*M
    return 1.5251 - 1.1568*(1.0-chi)**0.1292
def kappa(chi):              # surface gravity * M
    s = np.sqrt(1-chi**2); return s/(2*(1+s))
def omega_H(chi):            # horizon angular velocity * M
    return chi/(2*(1+np.sqrt(1-chi**2)))

def delta_pred(chi, alpha):
    """fractional offset of the nearest quantized line from the GR 220 frequency"""
    w_gr = omega_gr(chi); sp = alpha*kappa(chi)/(8*np.pi); base = 2*omega_H(chi)
    n = np.round((w_gr-base)/sp)
    return (base + n*sp - w_gr)/w_gr, sp/w_gr

def log_bf(alpha, d_obs, s_lo, s_hi, chi0=0.68, chi_s=0.01/Z90, N=400000, seed=1):
    rng = np.random.default_rng(seed)
    chi = rng.normal(chi0, chi_s, N); chi = chi[(chi>0)&(chi<0.999)]
    d, _ = delta_pred(chi, alpha)
    def L(x):                # split-normal likelihood for the measured deviation
        s = np.where(x > d_obs, s_lo, s_hi)   # model above obs -> obs's lower error applies
        return np.exp(-0.5*((x-d_obs)/s)**2)
    return np.log(np.mean(L(d))/L(np.zeros(1))[0])

if __name__ == "__main__":
    a_ssm = 4*np.log(2)
    d0, sp0 = delta_pred(np.array([0.68]), a_ssm)
    M_det = 68.4; Tm = M_det*4.925491e-6
    print(f"chi=0.68, (1+z)Mf=68.4 Msun:")
    print(f"  GR f220 = {omega_gr(0.68)/Tm/(2*np.pi):.1f} Hz;   measured (pSEOBNR) 251.7 +5.1/-5.0 Hz")
    print(f"  alpha=4ln2 line spacing = {sp0[0]*100:.2f}% of f220 = {sp0[0]*omega_gr(.68)/Tm/2/np.pi:.2f} Hz")
    base = 2*omega_H(.68)/Tm/2/np.pi; sp = a_ssm*kappa(.68)/(8*np.pi)/Tm/2/np.pi
    print("  nearby lines [Hz]:", ", ".join(f"{base+n*sp:.1f}" for n in range(4,9)))
    print(f"  predicted offset at chi=0.68: {d0[0]*100:+.2f}%  (measured +2 +/-2 %)")
    # sensitivity of the offset to spin
    c = np.linspace(0.670,0.690,9)
    print("  offset vs chi:", "  ".join(f"{x:.3f}:{y*100:+.1f}%" for x,y in zip(c,delta_pred(c,a_ssm)[0])))
    print()
    s = 0.02/Z90
    rows = [("SSM / Bekenstein-Mukhanov 4ln2", a_ssm), ("Hod 4ln3", 4*np.log(3)), ("8pi", 8*np.pi)]
    print(f"{'alpha':>34} {'lnBF (pSEOBNR)':>15} {'lnBF (pyRing)':>14}")
    for name,a in rows:
        print(f"{name:>34} {log_bf(a,0.02,s,s):15.2f} {log_bf(a,0.09,0.22/Z90,0.34/Z90):14.2f}")
    # scan alpha
    al = np.linspace(1.0,40,391); lb = np.array([log_bf(a,0.02,s,s,N=60000) for a in al])
    np.savetxt("alpha_scan.txt", np.c_[al,lb], header="alpha lnBF_pSEOBNR")
    print(f"\nalpha scan 1-40: lnBF range [{lb.min():.2f}, {lb.max():.2f}], max at alpha={al[lb.argmax()]:.2f}")
    print(f"lnBF at 4ln2 vs scan median: {log_bf(a_ssm,0.02,s,s):.2f} vs {np.median(lb):.2f}")
