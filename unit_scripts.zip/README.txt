Verification scripts for:
  "The Integer Charge Unit from Spectral Flow: Anomaly Inflow, the
   Witten Effect, and the Photon Grid of the Vacuum Code"
  (R. Kulkarni, 2026)

Contents:
  fcc_code.py        rebuilds and verifies the [[192,130,3]] code
  verify_unit.py     recomputes the worldline amplitudes from the code
                     and reproduces the spectral flow with all controls,
                     robustness checks, and the quantization statement
                     (8 labeled checks)
  PL_protocol.md     the series pre-registration, including Amendment 2
                     (this paper's hypothesis, outcomes, and controls,
                     dated before the computation ran)
  PL_extraction.md   the execution record with the Outcome-A verdict

Requirements: Python 3 with numpy.
Run:          python3 verify_unit.py
Expected:     8x PASS, then ALL PASS. Runtime: ~2 minutes.
