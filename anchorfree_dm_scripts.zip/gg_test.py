#!/usr/bin/env python3
"""Pre-registered 1.719 GeV gamma-gamma line test (PREREGISTRATION_1719.md)."""
import os
import sys
import warnings

import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings("ignore")
from line_test import load, fit_line  # noqa: E402
from flex_test import SRC, A, EDGES as FEDGES  # noqa: E402

E0 = 1719.0
FX = 0.5 * (np.log(FEDGES[1:]) + np.log(FEDGES[:-1])) - np.log(1500.0)
SHAPE = norm.cdf(FEDGES[1:], E0, 0.09 * E0) - norm.cdf(FEDGES[:-1], E0, 0.09 * E0)


def poly_fit(n, order, line=None):
    nc = order + 1

    def nll(p, L):
        m = np.exp(sum(p[k] * FX ** k for k in range(nc))) + L * SHAPE
        return 1e30 if np.any(m <= 0) else float((m - n * np.log(m)).sum())

    p0 = [np.log(n.mean() + 1), -1.5] + [0.0] * (order - 1)
    best = None
    for _ in range(3):
        r = minimize(lambda p: nll(p, 0.0 if line is None else line), p0, method="Nelder-Mead",
                     options={"maxiter": 60000, "xatol": 1e-9, "fatol": 1e-9})
        if best is None or r.fun < best.fun:
            best = r
        p0 = list(r.x)
    return best, nll


def poly_test(n, order):
    r0, nll = poly_fit(n, order)
    r1 = minimize(lambda q: nll(q[:-1], q[-1]), list(r0.x) + [0.0], method="Nelder-Mead",
                  options={"maxiter": 80000, "xatol": 1e-9, "fatol": 1e-9})
    N = r1.x[-1]
    s = np.sign(N) * np.sqrt(max(2 * (r0.fun - r1.fun), 0))
    ref = r1.fun if N >= 0 else r0.fun
    for t in np.linspace(max(N, 0), max(N, 0) + 10 * np.sqrt(n.sum()) + 50, 500):
        if t <= 0:
            continue
        rt = minimize(lambda p: nll(p, t), r0.x, method="Nelder-Mead",
                      options={"maxiter": 20000})
        if 2 * (rt.fun - ref) > 2.71:
            return N, s, t
    return N, s, None


def main():
    stack, uls = [], []
    for name, (ra, dec, files) in SRC.items():
        E, sep, _ = load([A + f for f in files], ra, dec)
        for reg, m in (("ON ", sep < 1.0), ("OFF", (sep > 4) & (sep < 10))):
            prim = fit_line(E[m], E0)
            n, _ = np.histogram(E[m], FEDGES)
            c3 = poly_test(n, 3)
            c4 = poly_test(n, 4)
            ul = max(prim["ul"], c3[2], c4[2])
            print(f"{name} {reg}: primary N={prim['N']:+8.1f} s={prim['s']:+.2f} UL={prim['ul']:.0f} | "
                  f"cubic s={c3[1]:+.2f} UL={c3[2]:.0f} | quartic s={c4[1]:+.2f} UL={c4[2]:.0f} "
                  f"-> adopted UL {ul:.0f}")
            if reg == "OFF":
                stack.append(prim["s"]); uls.append(ul)
    print(f"\nSTACKED OFF primary s = {sum(stack)/np.sqrt(3):+.2f}")
    np.save("gg_off_ul.npy", np.array(uls))


if __name__ == "__main__":
    main()
