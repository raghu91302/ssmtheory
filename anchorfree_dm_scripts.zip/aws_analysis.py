#!/usr/bin/env python3
"""
Analysis of the spectra pulled from the AWS mirror of the Fermi-LAT weekly
photon files (filtered in the browser, see PREREGISTRATION_J0250.md and
inner/PREREGISTRATION_inner_outer.md).

Input: hists.csv, one row per region:
    name,c0,c1,...,c{NB-1}
with NB log-spaced energy bins over 0.5-5 GeV (SOURCE class, zenith < 90).
Fits use bin centers as event energies; the bin width (<= 0.5%) is far
below the 9% energy resolution.
"""
import os
import sys
import warnings

import numpy as np
from scipy.optimize import minimize, brentq
from scipy.stats import norm

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from line_test import fit_line  # noqa: E402

warnings.filterwarnings("ignore")
EMIN, EMAX = 500.0, 5000.0
SR_FIELD = 2 * np.pi * (1 - np.cos(np.radians(8)))     # 0.0611 sr


def read(path="hists.csv"):
    H = {}
    for line in open(path):
        p = line.strip().split(",")
        if len(p) > 1:
            H[p[0]] = np.array([int(v) for v in p[1:]])
    nb = len(next(iter(H.values())))
    edges = np.logspace(np.log10(EMIN), np.log10(EMAX), nb + 1)
    centers = np.sqrt(edges[1:] * edges[:-1])
    return H, centers


def events(h, centers):
    """Spread each bin's counts evenly in log E across the bin, so that
    rebinning into the fit bins does not alias the coarse input bins."""
    r = np.sqrt(centers[1] / centers[0])          # half bin width ratio
    out = []
    for c, n in zip(centers, h):
        if n:
            u = (np.arange(n) + 0.5) / n
            out.append(c / r * r ** (2 * u))
    return np.concatenate(out)


# ---------------------------------------------------------------- J0250 / J2329
def point_source_tests(H, c, tag, kang=None):
    on, off = events(H[tag + "_ON"], c), events(H[tag + "_OFF"], c)
    print(f"\n{tag}: ON {len(on)} photons, OFF {len(off)} photons (0.5-5 GeV)")
    res = {}
    for reg, E in (("ON", on), ("OFF", off)):
        r = fit_line(E, 1591.0)
        res[reg] = r
        print(f"  1.591 {reg}: N={r['N']:+8.1f} s={r['s']:+.2f} UL={r['ul']:.0f}")
        for sf in (0.07, 0.12):
            rr = fit_line(E, 1591.0, sig_frac=sf)
            print(f"      width {sf:.2f}: s={rr['s']:+.2f}")
    if kang:
        rk = fit_line(on, kang)
        rko = fit_line(off, kang)
        print(f"  Kang energy {kang/1000:.3f} ON: N={rk['N']:+.1f} s={rk['s']:+.2f}; "
              f"OFF: N={rko['N']:+.1f} s={rko['s']:+.2f} UL={rko['ul']:.0f}")
        if rk["N"] > 0:
            print(f"    Milky Way test: 83.8 x N_ON = {83.8*rk['N']:.0f} vs OFF UL {rko['ul']:.0f} "
                  f"-> excluded by x{83.8*rk['N']/rko['ul']:.1f}")
    r = res["ON"]
    if r["N"] > 0:
        print(f"  Milky Way test at 1.591: 83.8 x N_ON = {83.8*r['N']:.0f} vs OFF UL "
              f"{res['OFF']['ul']:.0f} -> x{83.8*r['N']/res['OFF']['ul']:.1f}")
    r = fit_line(off, 1719.0)
    print(f"  1.719 OFF: N={r['N']:+.1f} s={r['s']:+.2f} UL={r['ul']:.0f}")
    return res


# ----------------------------------------------------------------- inner/outer
M, MP = 3.438, 0.938


def t1_density(E):
    """Two-residue phase space chi chi -> chi' chi' gamma, E in MeV."""
    e = E / 1000.0
    arg = 1 - 4 * MP**2 / np.maximum(M**2 - 2 * M * e, 1e-12)
    return np.where((arg > 0) & (M**2 - 2 * M * e > 0), e * np.sqrt(np.clip(arg, 0, None)), 0.0)


def component_shape(kind, edges):
    if kind in ("L1", "F1", "F2"):
        e0 = {"L1": 1591.0, "F1": 1207.0, "F2": 1620.0}[kind]
        s = 0.09 * e0
        return norm.cdf(edges[1:], e0, s) - norm.cdf(edges[:-1], e0, s), e0
    # T1: fine grid, convolve with sigma/E = 0.09, integrate over bins
    g = np.linspace(1.0, 1300.0, 6000)
    w = t1_density(g)
    w /= w.sum()
    cdf_bins = np.array([np.sum(w * (norm.cdf(edges[i + 1], g, 0.09 * g) -
                                     norm.cdf(edges[i], g, 0.09 * g)))
                         for i in range(len(edges) - 1)])
    fine = np.linspace(700, 2200, 3001)
    dens = np.array([np.sum(w * norm.pdf(x, g, 0.09 * g)) for x in fine])
    return cdf_bins, fine[np.argmax(dens)]


WINDOWS = {"L1": (1000, 2550), "F1": (750, 2200), "F2": (1000, 2600), "T1": (700, 2200)}


def cubic_fit(E, kind):
    lo, hi = WINDOWS[kind]
    edges = np.logspace(np.log10(lo), np.log10(hi), 61)
    n, _ = np.histogram(E, edges)
    x = 0.5 * (np.log(edges[1:]) + np.log(edges[:-1])) - np.log(1500.0)
    shape, peak = component_shape(kind, edges)

    def cont(p):
        return np.exp(p[0] + p[1] * x + p[2] * x**2 + p[3] * x**3)

    def nll(p, L):
        m = cont(p) + L * shape
        return 1e30 if np.any(m <= 0) else float((m - n * np.log(m)).sum())

    def prof(L, start):
        best = None
        for _ in range(2):
            r = minimize(lambda p: nll(p, L), start, method="Nelder-Mead",
                         options={"maxiter": 40000, "xatol": 1e-9, "fatol": 1e-9})
            if best is None or r.fun < best.fun:
                best = r
            start = r.x
        return best

    r0 = prof(0.0, [np.log(n.mean() + 1), -1.5, 0.0, 0.0])
    best = None
    start = list(r0.x) + [0.0]
    for _ in range(3):
        r = minimize(lambda q: nll(q[:4], q[4]), start, method="Nelder-Mead",
                     options={"maxiter": 80000, "xatol": 1e-9, "fatol": 1e-9})
        if best is None or r.fun < best.fun:
            best = r
        start = r.x
    N = best.x[4]
    ts = max(2 * (r0.fun - best.fun), 0)
    s = np.sign(N) * np.sqrt(ts)
    # 1-sigma from the profile (Delta 2NLL = 1), symmetric average
    scale = np.sqrt(n.sum()) + 10

    def d(L):
        return 2 * (prof(L, best.x[:4]).fun - best.fun) - 1.0
    try:
        up = brentq(d, N, N + 20 * scale, xtol=0.5)
        dn = brentq(d, N - 20 * scale, N, xtol=0.5)
        sig = 0.5 * (up - dn)
    except ValueError:
        sig = abs(N / s) if s else np.nan
    sp = 0.09 * peak
    cin = ((E > peak - sp) & (E < peak + sp)).sum()
    return dict(N=N, s=s, sig=sig, frac=N / cin, frac_sig=sig / cin, total=int(n.sum()), cin=int(cin))


def inner_outer(H, c):
    inner = ["F_30_20", "F_-30_20", "F_30_-20", "F_-30_-20"]
    outer = ["F_150_20", "F_210_20", "F_150_-20", "F_210_-20"]
    tot = {k: H[k][(c > 700) & (c < 2700)].sum() for k in inner + outer}
    print("\nInner/outer fields, photons 0.7-2.7 GeV:")
    for k in inner + outer:
        print(f"  {k:12s} {tot[k]:8d}")
    cr = np.mean([tot[k] for k in inner]) / np.mean([tot[k] for k in outer])
    print(f"  continuum ratio inner/outer = {cr:.2f}   (NFW J ratio 11.9)")
    out = {}
    for kind in ("L1", "F1", "F2", "T1"):
        print(f"\n  component {kind}")
        rows = {}
        for k in inner + outer:
            r = cubic_fit(events(H[k], c), kind)
            rows[k] = r
            print(f"    {k:12s} N={r['N']:+9.1f} +/- {r['sig']:7.1f}  s={r['s']:+.2f}  "
                  f"frac={100*r['frac']:+.2f}% +/- {100*r['frac_sig']:.2f}%")
        si = sum(rows[k]["s"] for k in inner) / 2.0
        so = sum(rows[k]["s"] for k in outer) / 2.0
        Ni = np.mean([rows[k]["N"] for k in inner]) / SR_FIELD
        No = np.mean([rows[k]["N"] for k in outer]) / SR_FIELD
        eNi = np.sqrt(sum(rows[k]["sig"]**2 for k in inner)) / 4 / SR_FIELD
        eNo = np.sqrt(sum(rows[k]["sig"]**2 for k in outer)) / 4 / SR_FIELD
        R = Ni / No
        eR = abs(R) * np.sqrt((eNi / Ni)**2 + (eNo / No)**2)
        fi = np.mean([rows[k]["frac"] for k in inner])
        fo = np.mean([rows[k]["frac"] for k in outer])
        efi = np.sqrt(sum(rows[k]["frac_sig"]**2 for k in inner)) / 4
        efo = np.sqrt(sum(rows[k]["frac_sig"]**2 for k in outer)) / 4
        Q = fi / fo
        eQ = abs(Q) * np.sqrt((efi / fi)**2 + (efo / fo)**2)
        print(f"    stacked s: inner {si:+.2f}, outer {so:+.2f}")
        print(f"    N/sr: inner {Ni:+.0f} +/- {eNi:.0f}, outer {No:+.0f} +/- {eNo:.0f};  "
              f"R = {R:.2f} +/- {eR:.2f}")
        print(f"    fraction: inner {100*fi:+.2f}% +/- {100*efi:.2f}, outer {100*fo:+.2f}% "
              f"+/- {100*efo:.2f};  Q = {Q:.2f} +/- {eQ:.2f}")
        out[kind] = dict(si=si, so=so, R=R, eR=eR, Q=Q, eQ=eQ, rows=rows)
    return out, cr


def main():
    H, c = read()
    print("regions:", ", ".join(f"{k}={v.sum()}" for k, v in H.items()))
    print("\n=== Cross-check: J2329.7-2118 (paper: ON +1.74, OFF -1.40, 1.719 OFF -0.88) ===")
    point_source_tests(H, c, "J2329", kang=1530.0)
    print("\n=== J0250.2-8224 (pre-registered) ===")
    res = point_source_tests(H, c, "J0250", kang=1554.0)
    off = events(H["J0250_OFF"], c)
    import decay_test as dt  # noqa: E402
    n, _ = np.histogram(off, dt.EDGES)
    for order in (2, 3):
        N, s, ul = dt.test(n, order=order)
        print(f"  0.603 OFF (order {order}): N={N:+.1f} s={s:+.2f} UL={ul}")
    print("\n=== Inner / outer (pre-registered) ===")
    inner_outer(H, c)


if __name__ == "__main__":
    main()
