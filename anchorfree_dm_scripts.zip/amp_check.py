import os
import sys, warnings
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings("ignore")
from flex_test import SRC, A, EDGES, fit
from line_test import load
from astropy.coordinates import SkyCoord
import astropy.units as u

off_sr = 2*np.pi*(np.cos(np.radians(4))-np.cos(np.radians(10)))
print(f"{'region':14s} {'l':>6s} {'b':>6s}  order  line N   frac of continuum   N per sr")
for name, (ra, dec, files) in SRC.items():
    E, sep, _ = load([A+f for f in files], ra, dec)
    n, _ = np.histogram(E[(sep > 4) & (sep < 10)], EDGES)
    c = SkyCoord(ra=ra*u.deg, dec=dec*u.deg).galactic
    for order in (3, 4):
        r = fit(n, order, 1207.0)
        N = r.x[-1]
        sig = 0.09*1207
        inband = (EDGES[:-1] > 1207-sig) & (EDGES[1:] < 1207+sig)
        cont = n[inband].sum() - 0.68*N
        print(f"{name:14s} {c.l.deg:6.1f} {c.b.deg:6.1f}   {order}   {N:7.0f}   {N/cont*100:6.2f} %          {N/off_sr:9.0f}")
