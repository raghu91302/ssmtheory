#!/usr/bin/env python3
"""
Pre-registered 0.603 GeV decay-line test (PREREGISTRATION_0603.md).
Requires numpy, scipy, astropy.
"""
import os
import sys
import warnings

import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from line_test import load  # noqa: E402

warnings.filterwarnings("ignore")
A = os.path.dirname(os.path.abspath(__file__)) + "/"
SRC = {
    "J2329.7-2118": (352.425, -21.300, ["L261022042147496B1F9D20_PH00.fits"]),
    "J0604.9-0000": (91.225, 0.000, [f"L261022042050496B1F9D35_PH0{i}.fits" for i in range(7)]),
    "J0749.6+1324": (117.400, 13.400, [f"L261022042225496B1F9D22_PH0{i}.fits" for i in range(6)]),
}
E_DEC = 603.0
LO, HI, NB = 500.0, 1100.0, 40
EDGES = np.logspace(np.log10(LO), np.log10(HI), NB + 1)
X = 0.5 * (np.log(EDGES[1:]) + np.log(EDGES[:-1])) - np.log(700.0)


def fit(n, order, e=None, sf=0.11, fix_line=None):
    shape = 0.0
    if e is not None:
        s = sf * e
        shape = norm.cdf(EDGES[1:], e, s) - norm.cdf(EDGES[:-1], e, s)
    nc = order + 1

    def mu(p, line):
        return np.exp(sum(p[k] * X ** k for k in range(nc))) + line * shape

    def nll(p, line):
        m = mu(p, line)
        return 1e30 if np.any(m <= 0) else float((m - n * np.log(m)).sum())

    p0 = [np.log(n.mean() + 1), -1.5] + [0.0] * (order - 1)
    r0 = minimize(lambda p: nll(p, 0.0), p0, method="Nelder-Mead",
                  options={"maxiter": 40000, "xatol": 1e-9, "fatol": 1e-9})
    if e is None:
        return r0
    if fix_line is not None:
        return minimize(lambda p: nll(p, fix_line), r0.x, method="Nelder-Mead",
                        options={"maxiter": 20000, "xatol": 1e-9, "fatol": 1e-9})
    r1 = minimize(lambda q: nll(q[:nc], q[nc]), list(r0.x) + [0.0],
                  method="Nelder-Mead",
                  options={"maxiter": 60000, "xatol": 1e-9, "fatol": 1e-9})
    return r0, r1


def test(n, order=2, e=E_DEC, sf=0.11):
    r0, r1 = fit(n, order, e, sf)
    N = r1.x[-1]
    ts = max(2 * (r0.fun - r1.fun), 0.0)
    s = np.sign(N) * np.sqrt(ts)
    ref = r1.fun if N >= 0 else r0.fun
    ul = None
    for trial in np.linspace(max(N, 0), max(N, 0) + 10 * np.sqrt(n.sum()) + 50, 600):
        if trial <= 0:
            continue
        rr = fit(n, order, e, sf, fix_line=trial)
        if 2 * (rr.fun - ref) > 2.71:
            ul = trial
            break
    return N, s, ul


def main():
    stack, out = [], {}
    for name, (ra, dec, files) in SRC.items():
        E, sep, _ = load([A + f for f in files], ra, dec)
        for reg, m in (("ON ", sep < 1.0), ("OFF", (sep > 4) & (sep < 10))):
            n, _ = np.histogram(E[m], EDGES)
            N, s, ul = test(n)
            var = [test(n, order=o, sf=f)[1] for o, f in ((3, 0.11), (2, 0.09), (2, 0.13))]
            print(f"{name} {reg}: window counts {n.sum():7d}  N = {N:+8.1f}  s = {s:+.2f}"
                  f"  95% UL = {ul:.0f}   [cubic {var[0]:+.2f}, sig .09 {var[1]:+.2f}, sig .13 {var[2]:+.2f}]")
            if reg == "OFF":
                stack.append(s)
                out[name] = ul
                grid = np.linspace(550, 950, 17)
                sc = np.array([test(n, e=g)[1] for g in grid])
                print(f"      control scan 0.55-0.95 GeV: rms {sc.std():.2f}, max |s| {np.abs(sc).max():.2f}")
    print(f"\nSTACKED OFF at 0.603 GeV: s = {sum(stack)/np.sqrt(3):+.2f}")
    np.save("decay_off_ul.npy", np.array([out[k] for k in SRC]))


if __name__ == "__main__":
    main()
