import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ink, ink2, blue, orange, grey = "#0b0b0b", "#52514e", "#2a78d6", "#eb6834", "#c3c2b7"
fig, ax = plt.subplots(figsize=(7.2, 2.4))
lo, hi = 937.6, 939.0
ax.set_xlim(lo, hi); ax.set_ylim(0, 1)
ax.axvspan(937.900, 938.783, ymin=0.25, ymax=0.55, color=blue, alpha=0.18, lw=0)
ax.annotate("", xy=(937.900, 0.40), xytext=(938.783, 0.40), arrowprops=dict(arrowstyle="<->", color=blue, lw=1.5))
ax.text(938.34, 0.45, "allowed window: stable nuclei, stable proton, stable $\\chi$", ha="center", va="bottom", fontsize=8, color=ink)
for x, lab, y in ((937.900, "$^9$Be stable\n937.900", 0.62), (938.783, "$m_p+m_e$\n938.783", 0.62), (937.761, "$m_p-m_e$\n937.761", 0.62), (938.272, "$m_p$", 0.08))[:3]:
    ax.axvline(x, ymin=0.2, ymax=0.6, color=ink2, lw=1)
    ax.text(x, y, lab, ha="center", va="bottom", fontsize=7.5, color=ink2)
ax.axvline(938.272, ymin=0.2, ymax=0.6, color=ink, lw=1.2, ls=":")
ax.text(938.272, 0.07, "$m_p$ = 938.272", ha="center", fontsize=7.5, color=ink)
ax.plot([938.233-0.25, 938.233+0.25], [0.30, 0.30], color=orange, lw=7, alpha=0.25, solid_capstyle="butt")
ax.plot([938.194, 938.272], [0.30, 0.30], color=orange, lw=4, solid_capstyle="butt")
ax.text(938.10, 0.17, "SSM: $C_\\chi = 1836$", ha="right", fontsize=8, color=orange)
ax.set_yticks([]); [ax.spines[s].set_visible(False) for s in ("left", "right", "top")]
ax.set_xlabel("dark-matter mass (MeV)", fontsize=9, color=ink)
ax.tick_params(labelsize=8, colors=ink2)
fig.tight_layout(); fig.savefig("fig_window.pdf"); fig.savefig("fig_window.png", dpi=170)
