#!/usr/bin/env python3
"""Residual spectra (data minus smooth background) near 1.59 GeV, for the
1-deg patch around each of Kang's four sources and the 4-10 deg ring around
it.  The dashed curve in the ring panels shows what a Milky Way dark-matter
line big enough to make the patch excess would add to the ring (x83.8)."""
import os
import sys, warnings
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from line_test import load, fit_line
from flex_test import SRC, A
import aws_analysis as aw
warnings.filterwarnings("ignore")

LO, HI = 1000.0, 2550.0
ED = np.logspace(np.log10(LO), np.log10(HI), 41)
X = 0.5 * (np.log(ED[1:]) + np.log(ED[:-1])) - np.log(1591.0)

def background(E):
    n, _ = np.histogram(E, ED)
    nll = lambda p: float((np.exp(p[0]+p[1]*X+p[2]*X*X) - n*(p[0]+p[1]*X+p[2]*X*X)).sum())
    r = minimize(nll, [np.log(n.mean()), -1.5, 0], method="Nelder-Mead", options={"maxiter": 20000, "xatol":1e-9,"fatol":1e-9})
    return n, np.exp(r.x[0]+r.x[1]*X+r.x[2]*X*X)

def rebin(a, k=2): return a.reshape(-1, k).sum(1)

H, c = aw.read()
regions = {}
kang = {"J2329.7-2118": 1530., "J0604.9-0000": 1590., "J0749.6+1324": 1620., "J0250.2-8224": 1554.}
for name, (ra, dec, files) in SRC.items():
    E, sep, _ = load([A+f for f in files], ra, dec)
    regions[name] = (E[sep < 1], E[(sep > 4) & (sep < 10)])
regions["J0250.2-8224"] = (aw.events(H["J0250_ON"], c), aw.events(H["J0250_OFF"], c))

ED2 = ED[::2]; EC = np.sqrt(ED2[1:]*ED2[:-1]) / 1000
ink, ink2, blue, orange = "#0b0b0b", "#52514e", "#2a78d6", "#eb6834"
stack = {"ON": [0, 0], "OFF": [0, 0, 0]}
for name, (on, off) in regions.items():
    r_on = fit_line(on, kang[name])
    sh = norm.cdf(ED2[1:], kang[name], .09*kang[name]) - norm.cdf(ED2[:-1], kang[name], .09*kang[name])
    for E, key in ((on, "ON"), (off, "OFF")):
        n, b = background(E); n2, b2 = rebin(n), rebin(b)
        stack[key][0] += n2 - b2; stack[key][1] += b2
        if key == "OFF": stack["OFF"][2] += 83.8*max(r_on["N"], 0)*sh
fig, axes = plt.subplots(1, 2, figsize=(9, 3.3), sharex=True)
for j, key in enumerate(("ON", "OFF")):
    d, b = stack[key][0], stack[key][1]; ax = axes[j]
    ax.axhline(0, color=ink2, lw=0.8)
    ax.errorbar(EC, 100*d/b, 100*np.sqrt(b)/b, fmt="o", ms=4, color=blue if j == 0 else orange, lw=1.2, capsize=0)
    ax.axvline(1.591, color=ink, lw=1, ls=":")
    if j == 1: ax.plot(EC, 100*stack["OFF"][2]/b, color=ink, lw=1.5, ls="--")
    ax.set_ylim(-30, 30) if j == 0 else ax.set_ylim(-5, 20)
    ax.set_title(["(a) 1$^\\circ$ around the four sources", "(b) 4$-$10$^\\circ$ rings around them"][j], fontsize=10, color=ink)
    ax.set_xlabel("photon energy (GeV)", fontsize=9, color=ink)
    if j == 0: ax.set_ylabel("excess over background (%)", fontsize=9, color=ink)
    ax.tick_params(labelsize=8, colors=ink2)
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)
fig.tight_layout(); fig.savefig("fig_lines.pdf"); fig.savefig("fig_lines.png", dpi=150)
print("ok")
