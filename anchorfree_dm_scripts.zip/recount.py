#!/usr/bin/env python3
"""Recount the proton's structural mass count on an explicit FCC lattice,
with one of the trapped node's four bonds labeled as the anchor and with none.

Lattice: nodes at integer points with even coordinate sum (bond vectors
(+-1,+-1,0) and permutations, L = sqrt 2, K = 12).  Tetrahedral void with
corners A=(0,0,0), B=(1,1,0), C=(1,0,1), D=(0,1,1), centre T=(1/2,1/2,1/2).
"""
import itertools
import numpy as np

NB = [np.array(v) for v in set(itertools.permutations((1, 1, 0))) |
      set(itertools.permutations((1, -1, 0))) | set(itertools.permutations((-1, -1, 0)))]
NB = [v for v in {tuple(x) for x in NB}]
NB = [np.array(v) for v in NB]
assert len(NB) == 12
K = 12
corners = {"A": (0, 0, 0), "B": (1, 1, 0), "C": (1, 0, 1), "D": (0, 1, 1)}
T = (0.5, 0.5, 0.5)

def neighbors(p):
    return [tuple(np.array(p) + v) for v in NB]

# ---------- 1. the published rules, applied literally to this geometry -------------
edges = list(itertools.combinations(corners, 2))                     # 6 tetrahedron edges
skew = [(e, f) for e, f in itertools.combinations(edges, 2) if not set(e) & set(f)]
internal = {c: [e for e in edges if c in e] for c in corners}        # 3 internal bonds per corner
def published_count(anchor=None):
    # K+1 = 4 corners x 3 internal bonds + 1 trapped node
    structural = sum(len(internal[c]) for c in corners) + 1
    second = structural * K * K                                      # each disrupts K^2
    overlap = len(skew) * K                                          # K shared bonds per skew pair
    return structural, second, len(skew), second - overlap
for lab, a in (("anchored (anchor = T-A)", "A"), ("anchor-free", None)):
    print("published rules,", lab, "->", published_count(a))

# ---------- 2. literal lattice counts -------------------------------------------------
# Disrupted bonds: every bulk bond (u,v) of the FCC lattice with an endpoint among the
# K neighbors of a structural site, i.e. bonds in the second-neighbor shell.
def bonds_touching(sites):
    out = set()
    for s in sites:
        for n in neighbors(s):
            for m in neighbors(n):
                out.add(tuple(sorted((n, m))))
    return out
cset = list(corners.values())
walks_corners = sum(len(neighbors(n)) for c in cset for n in neighbors(c))
print("\nliteral: length-2 walks from the 4 corners =", walks_corners, "(= 4 K^2 =", 4*K*K, ")")
print("literal: distinct bulk bonds within two steps of the 4 corners =", len(bonds_touching(cset)))
# skew pairs: shared second-neighbor bonds between the two edges of each skew pair
for (e, f) in skew:
    be = bonds_touching([corners[x] for x in e]); bf = bonds_touching([corners[x] for x in f])
    print(f"skew pair {e}-{f}: bonds shared between their two-step shells = {len(be & bf)}")
# shared first neighbors of the two ends of each edge (common-neighbor count)
for e in edges[:1]:
    a, b = corners[e[0]], corners[e[1]]
    print("common first neighbors of an edge's two ends:", len(set(neighbors(a)) & set(neighbors(b))))

# ---------- 3. the QEC route, 36 x 51, counted literally --------------------------------
# Coordination cluster: a node and its 12 neighbors (cuboctahedron + centre).
O = (0, 0, 0)
cl = [O] + neighbors(O)
isnb = lambda p, q: tuple(np.subtract(p, q)) in {tuple(v) for v in NB}
E = [(p, q) for p, q in itertools.combinations(cl, 2) if isnb(p, q)]
tri = [t for t in itertools.combinations(cl, 3) if all(isnb(a, b) for a, b in itertools.combinations(t, 2))]
sh = neighbors(O)
sq = [q for q in itertools.combinations(sh, 4)
      if sum(isnb(a, b) for a, b in itertools.combinations(q, 2)) == 4
      and np.isclose(np.ptp(np.array(q) @ np.cross(np.subtract(q[1], q[0]), np.subtract(q[2], q[0]))), 0)
      and all(sum(isnb(a, b) for b in q if b != a) == 2 for a in q)]
print(f"\ncoordination cluster: vertices {len(cl)}, edges {len(E)}, triangles {len(tri)}, squares {len(sq)}")
print(f"E_s x C_s = {len(E)} x ({len(cl)} + {len(tri)+len(sq)}) = {len(E)*(len(cl)+len(tri)+len(sq))}")
# Where is the anchor in this route?  The cluster is that of a lattice node; the trapped
# node's four bonds (and so the anchor label) do not appear in any of the three counts.
