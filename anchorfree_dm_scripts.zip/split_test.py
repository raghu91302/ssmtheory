"""
Exploratory: split each OFF ring (4-10 deg) into the half nearer the
Galactic plane and the half farther from it, fit a flexible continuum
(order 3 and 4 in log E, 0.6-4.0 GeV) plus a Gaussian at 1.207 GeV and at
1.591 GeV, and compare the feature as a fraction of the continuum.
  gas-tracking component -> larger fraction on the plane side
  instrumental (multiplicative) -> same fraction on both sides
"""
import os
import sys, warnings
import numpy as np
from astropy.io import fits
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings("ignore")
from flex_test import SRC, A, EDGES, fit

def load_lb(files, ra0, dec0):
    E, sep, b = [], [], []
    for f in files:
        with fits.open(f, memmap=True) as h:
            d = h["EVENTS"].data
            ok = np.asarray(d["EVENT_CLASS"])[:, 24].astype(bool) & (d["ZENITH_ANGLE"] < 90)
            ra = np.radians(d["RA"][ok]); de = np.radians(d["DEC"][ok])
            r0, d0 = np.radians(ra0), np.radians(dec0)
            c = np.sin(de)*np.sin(d0) + np.cos(de)*np.cos(d0)*np.cos(ra-r0)
            sep.append(np.degrees(np.arccos(np.clip(c, -1, 1))))
            E.append(d["ENERGY"][ok].astype(float)); b.append(d["B"][ok].astype(float))
    return np.concatenate(E), np.concatenate(sep), np.concatenate(b)

def frac(n, order, e):
    r = fit(n, order, e); N = r.x[-1]
    s = 0.09*e
    band = (EDGES[:-1] > e-s) & (EDGES[1:] < e+s)
    return N, N/(n[band].sum()-0.68*N)*100

print(f"{'region':14s} {'half':10s} {'photons':>8s} | {'1.207 GeV, % of continuum':>26s} | {'1.591 GeV, % of continuum':>26s}")
for name, (ra, dec, files) in SRC.items():
    E, sep, b = load_lb([A+f for f in files], ra, dec)
    ring = (sep > 4) & (sep < 10)
    med = np.median(np.abs(b[ring]))
    for label, m in (("near plane", ring & (np.abs(b) < med)), ("far", ring & (np.abs(b) >= med))):
        n, _ = np.histogram(E[m], EDGES)
        r1 = [frac(n, o, 1207.0)[1] for o in (3, 4)]
        r2 = [frac(n, o, 1591.0)[1] for o in (3, 4)]
        print(f"{name:14s} {label:10s} {n.sum():8d} |   {r1[0]:+6.2f} %   {r1[1]:+6.2f} %     |   {r2[0]:+6.2f} %   {r2[1]:+6.2f} %")
    print(f"{'':14s} median |b| in ring = {med:.1f} deg")
print("\n(each pair: continuum order 3, order 4)")
