// In-browser filter used to build hists.csv from the Fermi-LAT weekly photon files
// on the AWS mirror of HEASARC (s3://nasa-heasarc/fermi/data/lat/weekly/photon/).
// Run in a browser tab open on https://nasa-heasarc.s3.amazonaws.com/ (same origin).
// Cuts: SOURCE class (EVENT_CLASS bit 7), zenith < 90 deg, 0.5-5 GeV.
// Regions: J0250.2-8224 and J2329.7-2118 (patch < 1 deg, ring 4-10 deg, all < 12 deg),
// and eight 8-deg fields at (l, b) = (+-30, +-20), (150, +-20), (210, +-20).
// Output: 2000 log energy bins per region; RUN.exportCSV(8) gives the 250-bin
// spectra in hists.csv.  Progress is checkpointed in localStorage after every file.
(async function () {
  const D2R = Math.PI / 180, NB = 2000, EMIN = 500, EMAX = 5000, LR = Math.log(EMAX / EMIN);
  const unit = (a, b) => { a *= D2R; b *= D2R; return [Math.cos(b) * Math.cos(a), Math.cos(b) * Math.sin(a), Math.sin(b)]; };
  const cel = [["J0250", 42.55, -82.40], ["J2329", 352.43, -21.31]];
  const fields = [[30, 20], [-30, 20], [30, -20], [-30, -20], [150, 20], [210, 20], [150, -20], [210, -20]];
  const names = []; cel.forEach(s => names.push(s[0] + "_ON", s[0] + "_OFF", s[0] + "_ALL12"));
  fields.forEach(f => names.push(`F_${f[0]}_${f[1]}`));
  const ck = JSON.parse(localStorage.getItem("ssm_ckpt") || "null");
  const H = {}; names.forEach(n => H[n] = ck ? Int32Array.from(ck.H[n]) : new Int32Array(NB));
  const uC = cel.map(s => unit(s[1], s[2])), uF = fields.map(f => unit(f[0], f[1]));
  const c1 = Math.cos(D2R), c4 = Math.cos(4 * D2R), c10 = Math.cos(10 * D2R), c12 = Math.cos(12 * D2R), c8 = Math.cos(8 * D2R);
  const SZ = { L: 1, B: 1, I: 2, J: 4, K: 8, E: 4, D: 8, A: 1 };
  function hdr(u8, off) {
    const c = {}; let p = off;
    while (true) {
      const s = String.fromCharCode.apply(null, u8.subarray(p, p + 80)); p += 80;
      const k = s.slice(0, 8).trim(); if (k === "END") break;
      if (s[8] === "=") { let v = s.slice(10); const q = v.indexOf("'");
        if (q >= 0 && q < 3) v = v.slice(q + 1, v.indexOf("'", q + 1)).trim(); else v = v.split("/")[0].trim(); c[k] = v; }
    }
    return { c, ds: Math.ceil(p / 2880) * 2880 };
  }
  function proc(buf) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    let h = hdr(u8, 0); h = hdr(u8, h.ds); const c = h.c; if (c.EXTNAME !== "EVENTS") throw "ext";
    const col = {}; let o = 0;
    for (let i = 1; i <= +c.TFIELDS; i++) { const m = c["TFORM" + i].match(/^(\d*)([A-Z])/); const n = m[1] === "" ? 1 : +m[1];
      col[c["TTYPE" + i]] = o; o += m[2] === "X" ? Math.ceil(n / 8) : n * SZ[m[2]]; }
    const RL = +c.NAXIS1, NR = +c.NAXIS2, b0 = h.ds; if (b0 + RL * NR > buf.byteLength) throw "short";
    const L = {}; names.forEach(n => L[n] = new Int32Array(NB));
    for (let r = 0; r < NR; r++) {
      const p = b0 + r * RL, E = dv.getFloat32(p + col.ENERGY);
      if (!(E >= EMIN && E < EMAX)) continue;
      if (!(dv.getUint32(p + col.EVENT_CLASS) & 128)) continue;
      if (!(dv.getFloat32(p + col.ZENITH_ANGLE) < 90)) continue;
      const bin = Math.floor(Math.log(E / EMIN) / LR * NB), v = unit(dv.getFloat32(p + col.RA), dv.getFloat32(p + col.DEC));
      for (let s = 0; s < 2; s++) { const cs = v[0] * uC[s][0] + v[1] * uC[s][1] + v[2] * uC[s][2];
        if (cs > c12) { L[names[3 * s + 2]][bin]++; if (cs > c1) L[names[3 * s]][bin]++; else if (cs < c4 && cs > c10) L[names[3 * s + 1]][bin]++; } }
      const g = unit(dv.getFloat32(p + col.L), dv.getFloat32(p + col.B));
      for (let k = 0; k < 8; k++) if (g[0] * uF[k][0] + g[1] * uF[k][1] + g[2] * uF[k][2] > c8) L[names[6 + k]][bin]++;
    }
    names.forEach(n => { const a = H[n], b = L[n]; for (let i = 0; i < NB; i++) a[i] += b[i]; });
  }
  const st = { done: ck ? ck.done.slice() : [], errors: [], workers: 0, target: 4, inflight: {} };
  async function getFile(key) {   // streamed; aborted if no data arrive for 60 s
    const ac = new AbortController(); let timer = setTimeout(() => ac.abort(), 60000);
    try { const r = await fetch("/" + key, { signal: ac.signal, cache: "no-store" }); if (!r.ok) throw "http " + r.status;
      const len = +r.headers.get("content-length"), out = new Uint8Array(len); let off = 0; const rd = r.body.getReader();
      while (true) { const { done, value } = await rd.read(); if (done) break; out.set(value, off); off += value.length;
        clearTimeout(timer); timer = setTimeout(() => ac.abort(), 60000); }
      if (off !== len) throw "short"; return out.buffer; }
    finally { clearTimeout(timer); }
  }
  let tok = null; const weeks = [];
  do { const u = "/?list-type=2&prefix=fermi/data/lat/weekly/photon/lat_photon_weekly&max-keys=1000" + (tok ? "&continuation-token=" + encodeURIComponent(tok) : "");
    const x = new DOMParser().parseFromString(await (await fetch(u)).text(), "text/xml");
    x.querySelectorAll("Contents").forEach(c => { const k = c.querySelector("Key").textContent; if (k.endsWith(".fits")) weeks.push(k); });
    const t = x.querySelector("NextContinuationToken"); tok = t ? t.textContent : null; } while (tok);
  const wk = k => +k.match(/w(\d+)_/)[1], doneSet = new Set(st.done);
  const queue = []; for (const ph of [0, 2, 1, 3]) weeks.filter(k => wk(k) % 4 === ph && !doneSet.has(wk(k))).forEach(k => queue.push(k));
  const save = () => { try { localStorage.setItem("ssm_ckpt", JSON.stringify({ names, H: Object.fromEntries(names.map(n => [n, Array.from(H[n])])), done: st.done })); } catch (e) {} };
  async function worker() { st.workers++;
    while (queue.length && st.workers <= st.target) { const k = queue.shift(); let ok = false;
      for (let a = 0; a < 5 && !ok; a++) { try { proc(await getFile(k)); st.done.push(wk(k)); ok = true; save(); }
        catch (e) { await new Promise(z => setTimeout(z, 5000 * (a + 1))); } }
      if (!ok) { st.errors.push(k); queue.push(k); } }
    st.workers--; }
  window.RUN = { H, names, st, queue,
    exportCSV: (f = 8) => names.filter(n => !n.endsWith("ALL12")).map(n => { const h = H[n], o = [];
      for (let i = 0; i < h.length; i += f) { let s = 0; for (let j = 0; j < f; j++) s += h[i + j]; o.push(s); } return n + "," + o.join(","); }).join("\n") };
  for (let i = 0; i < st.target; i++) worker();
})();
