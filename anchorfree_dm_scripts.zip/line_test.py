#!/usr/bin/env python3
"""
Pre-registered line test at 1.591 GeV on Fermi-LAT photon files.
Implements PREREGISTRATION.md.  Requires numpy, scipy, astropy.

usage: python3 line_test.py RA DEC label file1.fits [file2.fits ...]
"""
import sys
import warnings

import numpy as np
from astropy.io import fits
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

E_LINE = 1591.0           # MeV, the SSM prediction
SIG_FRAC = 0.09
SOURCE_BIT = 7            # P8R3 SOURCE class


def load(files, ra0, dec0):
    E, sep, t = [], [], []
    for f in files:
        with fits.open(f, memmap=True) as h:
            d = h["EVENTS"].data
            # EVENT_CLASS is a 32-bit FITS bit array, most significant bit first
            ok = np.asarray(d["EVENT_CLASS"])[:, 31 - SOURCE_BIT].astype(bool)
            ok &= d["ZENITH_ANGLE"] < 90
            ra = np.radians(d["RA"][ok]); de = np.radians(d["DEC"][ok])
            r0, d0 = np.radians(ra0), np.radians(dec0)
            c = np.sin(de) * np.sin(d0) + np.cos(de) * np.cos(d0) * np.cos(ra - r0)
            sep.append(np.degrees(np.arccos(np.clip(c, -1, 1))))
            E.append(d["ENERGY"][ok].astype(float))
            t.append(d["TIME"][ok])
    return np.concatenate(E), np.concatenate(sep), np.concatenate(t)


def fit_line(E, e_test, sig_frac=SIG_FRAC, nbins=40):
    lo, hi = e_test / 1.591, e_test * 1.6025      # 1.00-2.55 GeV at 1.591
    edges = np.logspace(np.log10(lo), np.log10(hi), nbins + 1)
    n, _ = np.histogram(E, edges)
    lc = 0.5 * (np.log(edges[1:]) + np.log(edges[:-1]))
    x = lc - np.log(e_test)
    sig = sig_frac * e_test
    # expected line counts per bin for unit normalization
    from scipy.stats import norm
    shape = norm.cdf(edges[1:], e_test, sig) - norm.cdf(edges[:-1], e_test, sig)

    def mu(p, line):
        cont = np.exp(p[0] + p[1] * x + p[2] * x * x)
        return cont + line * shape

    def nll(p, line):
        m = mu(p, line)
        if np.any(m <= 0):
            return 1e30
        return float((m - n * np.log(m)).sum())

    p0 = [np.log(max(n.mean(), 1.0)), -1.0, 0.0]
    r0 = minimize(lambda p: nll(p, 0.0), p0, method="Nelder-Mead",
                  options={"maxiter": 20000, "xatol": 1e-8, "fatol": 1e-8})
    r1 = minimize(lambda q: nll(q[:3], q[3]), list(r0.x) + [0.0],
                  method="Nelder-Mead",
                  options={"maxiter": 40000, "xatol": 1e-8, "fatol": 1e-8})
    ts = max(2 * (r0.fun - r1.fun), 0.0)
    N = r1.x[3]
    s = np.sign(N) * np.sqrt(ts)
    # one-sided 95% upper limit on line counts by profile scan.  If the best
    # fit is negative, the reference is the fit at N = 0 (physical boundary),
    # which gives a conservative limit rather than collapsing to zero.
    ref = r1.fun if N >= 0 else r0.fun
    ul = None
    for trial in np.linspace(max(N, 0), max(N, 0) + 20 * np.sqrt(n.sum()) + 50, 800):
        rr = minimize(lambda p: nll(p, trial), r1.x[:3], method="Nelder-Mead",
                      options={"maxiter": 8000})
        if 2 * (rr.fun - ref) > 2.71 and trial > 0:
            ul = trial
            break
    return dict(N=N, ts=ts, s=s, ul=ul, total=int(n.sum()))


def report(label, E, sep, region, mask):
    Es = E[mask]
    print(f"\n[{label}] {region}: {mask.sum()} photons in 0.5-5 GeV")
    r = fit_line(Es, E_LINE)
    print(f"  PRIMARY  E=1.591 GeV  line counts N = {r['N']:8.1f}  "
          f"s = {r['s']:+.2f} sigma   (window counts {r['total']}, "
          f"95% UL on N = {r['ul']:.0f})")
    for sf in (0.07, 0.12):
        rr = fit_line(Es, E_LINE, sig_frac=sf)
        print(f"  width sigma/E={sf:.2f}:  N = {rr['N']:8.1f}  s = {rr['s']:+.2f}")
    return Es


def scan(Es, label):
    grid = np.exp(np.linspace(np.log(800), np.log(3000), 61))
    out = [(e, fit_line(Es, e)["s"]) for e in grid]
    s = np.array([v for _, v in out])
    print(f"  CONTROL scan 0.8-3.0 GeV ({len(grid)} energies, ~{len(grid)/4:.0f} independent):")
    print(f"     max |s| = {np.abs(s).max():.2f} at "
          f"{grid[np.argmax(np.abs(s))]:.0f} MeV;  fraction |s|>=3: "
          f"{(np.abs(s) >= 3).mean():.2f};  rms s = {s.std():.2f}")
    return grid, s


def main():
    ra0, dec0, label = float(sys.argv[1]), float(sys.argv[2]), sys.argv[3]
    kang = float(sys.argv[4]); files = sys.argv[5:]
    E, sep, t = load(files, ra0, dec0)
    print(f"{label}: {len(E)} SOURCE-class photons, MET {t.min():.0f}-{t.max():.0f}")
    on = report(label, E, sep, "ON  (<1 deg)", sep < 1.0)
    rk = fit_line(on, kang)
    print(f"  Kang's energy {kang/1000:.3f} GeV in ON: N = {rk['N']:.1f}  s = {rk['s']:+.2f}")
    g_on, s_on = scan(on, label)
    off = report(label, E, sep, "OFF (4-10 deg annulus)", (sep > 4) & (sep < 10))
    g_off, s_off = scan(off, label)
    np.savez(f"scan_{label}.npz", g=g_on, s_on=s_on, s_off=s_off)


if __name__ == "__main__":
    main()
