import itertools, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ink, ink2, blue, orange, green, red, grey = "#0b0b0b", "#52514e", "#2a78d6", "#eb6834", "#1baf7a", "#e34948", "#9a9993"
corners = [np.array(c, float) for c in itertools.product((0, 1), repeat=3)]
faces = [np.array(p) for p in ([.5,.5,0],[.5,.5,1],[.5,0,.5],[.5,1,.5],[0,.5,.5],[1,.5,.5])]
atoms = corners + faces
tet_v = [np.array(v) for v in ([0,0,0],[.5,.5,0],[.5,0,.5],[0,.5,.5])]; tet_c = sum(tet_v)/4
oct_c = np.array([.5,.5,.5])
def setup(ax, title):
    ax.set_proj_type("ortho"); ax.set_box_aspect((1,1,1)); ax.view_init(elev=18, azim=-58)
    ax.set_axis_off(); ax.set_title(title, fontsize=11, color=ink, pad=0)
def seg(ax, a, b, **k): ax.plot(*zip(a, b), **k)
fig = plt.figure(figsize=(9, 3.4))
# (a) unit cell with one tetrahedral and one octahedral void
ax = fig.add_subplot(1, 3, 1, projection="3d"); setup(ax, "(a)")
for a, b in itertools.combinations(corners, 2):
    if np.isclose(np.linalg.norm(a-b), 1): seg(ax, a, b, color=grey, lw=0.6, alpha=0.6)
for a, b in itertools.combinations(tet_v, 2): seg(ax, a, b, color=orange, lw=1.8)
for a, b in itertools.combinations(faces, 2):
    if np.isclose(np.linalg.norm(a-b), np.sqrt(0.5)): seg(ax, a, b, color=blue, lw=1.4)
P = np.array(atoms); ax.scatter(*P.T, s=38, color=ink2, depthshade=False)
ax.scatter(*tet_c, s=60, color=orange, marker="*", depthshade=False)
ax.scatter(*oct_c, s=60, color=blue, marker="*", depthshade=False)
ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_zlim(0,1)
# (b) anchored, (c) anchor-free
for k, (title, anchored) in enumerate((("(b)", True),
                                       ("(c)", False))):
    ax = fig.add_subplot(1, 3, k+2, projection="3d"); setup(ax, title)
    for a, b in itertools.combinations(tet_v, 2): seg(ax, a, b, color=orange, lw=1.2, alpha=0.7)
    for i, v in enumerate(tet_v):
        if anchored: col, lw = (red, 3.2) if i == 0 else (green, 2.2)
        else: col, lw = ("#6250d6", 2.4)
        seg(ax, tet_c, v, color=col, lw=lw)
    ax.scatter(*np.array(tet_v).T, s=55, color=ink2, depthshade=False)
    ax.scatter(*tet_c, s=90, color=ink, marker="o", depthshade=False)
    if anchored:
        ax.text(*(tet_c + 0.62*(tet_v[0]-tet_c)) + np.array([0.05,-0.02,-0.05]), "anchor", color=red, fontsize=8)
    lo, hi = -0.02, 0.52; ax.set_xlim(lo,hi); ax.set_ylim(lo,hi); ax.set_zlim(lo,hi)
fig.tight_layout(); fig.savefig("fig_framework.pdf"); fig.savefig("fig_framework.png", dpi=150)
