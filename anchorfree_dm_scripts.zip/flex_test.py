#!/usr/bin/env python3
"""
Robustness check on the OFF-region residual wave (+ near 1.19 GeV, - near
1.6 GeV).  Exploratory, NOT pre-registered.

For each region, refit with continua of increasing flexibility over a wide
window (0.6-4.0 GeV) and scan a Gaussian line (sigma/E = 0.09).  A real
narrow feature should persist as the continuum gains freedom; a broad
curvature mismatch should shrink.
"""
import os
import sys
import warnings

import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from line_test import load  # noqa: E402

warnings.filterwarnings("ignore")
A = os.path.dirname(os.path.abspath(__file__)) + "/"
SRC = {
    "J2329.7-2118": (352.425, -21.300, ["L261022042147496B1F9D20_PH00.fits"]),
    "J0604.9-0000": (91.225, 0.000, [f"L261022042050496B1F9D35_PH0{i}.fits" for i in range(7)]),
    "J0749.6+1324": (117.400, 13.400, [f"L261022042225496B1F9D22_PH0{i}.fits" for i in range(6)]),
}
LO, HI, NB = 600.0, 4000.0, 80
EDGES = np.logspace(np.log10(LO), np.log10(HI), NB + 1)
X = 0.5 * (np.log(EDGES[1:]) + np.log(EDGES[:-1])) - np.log(1500.0)


def fit(n, order, e_test=None):
    shape = 0.0
    if e_test is not None:
        s = 0.09 * e_test
        shape = norm.cdf(EDGES[1:], e_test, s) - norm.cdf(EDGES[:-1], e_test, s)

    def mu(p):
        poly = sum(p[k] * X ** k for k in range(order + 1))
        return np.exp(poly) + (p[-1] * shape if e_test is not None else 0.0)

    def nll(p):
        m = mu(p)
        return 1e30 if np.any(m <= 0) else float((m - n * np.log(m)).sum())

    p0 = [np.log(n.mean() + 1), -1.5] + [0.0] * (order - 1)
    p0 = p0 + ([0.0] if e_test is not None else [])
    best = None
    for _ in range(3):
        r = minimize(nll, p0, method="Nelder-Mead",
                     options={"maxiter": 60000, "xatol": 1e-9, "fatol": 1e-9})
        if best is None or r.fun < best.fun:
            best = r
        p0 = list(r.x)
    return best


def scan(n, order):
    r0 = fit(n, order)
    out = []
    for e in (1000, 1100, 1190, 1207, 1300, 1450, 1591, 1750, 2000, 2200):
        r1 = fit(n, order, e)
        ts = max(2 * (r0.fun - r1.fun), 0)
        out.append((e, np.sign(r1.x[-1]) * np.sqrt(ts)))
    return out


def main():
    energies = None
    stacks = {}
    for name, (ra, dec, files) in SRC.items():
        E, sep, _ = load([A + f for f in files], ra, dec)
        off = E[(sep > 4) & (sep < 10)]
        n, _ = np.histogram(off, EDGES)
        print(f"\n{name} OFF, 0.6-4.0 GeV: {n.sum()} photons")
        for order in (2, 3, 4, 5):
            res = scan(n, order)
            energies = [e for e, _ in res]
            stacks.setdefault(order, []).append([s for _, s in res])
            print(f"  poly order {order}: " +
                  "  ".join(f"{e/1000:.3f}:{s:+.2f}" for e, s in res))
    print("\nSTACKED OFF (Stouffer over 3 regions)")
    print("  order  " + "  ".join(f"{e/1000:6.3f}" for e in energies))
    for order, rows in stacks.items():
        st = np.sum(rows, axis=0) / np.sqrt(len(rows))
        print(f"    {order}    " + "  ".join(f"{v:+6.2f}" for v in st))


if __name__ == "__main__":
    main()
