#!/usr/bin/env python3
"""Route 1: equilibrium split between anchored and anchor-free trapped nodes.
Rules fixed before counting:
  * a configuration assigns roles to the trapped node's 4 bonds;
  * anchored: one of the 4 bonds is the anchor, the other 3 are valence bonds,
    each with winding w in {0,1}; charge Q = -1 + W (Matter paper);
  * anchor-free: no anchor. Two variants: (a) bonds carry no windings;
    (b) each of the 4 equivalent bonds may carry a winding (charge undefined -> 0);
  * void orientation, color (3 skew pairs) and spin (j=1/2 for both) are common
    to both kinds and are listed but cancel in the ratio;
  * equal masses (count 1836 for both), so n_chi/n_B = g_chi / g_B.
Observed target: Omega_c/Omega_b = 0.1200/0.02237 = 5.36.
"""
import itertools
spin = 2
anch = [(a, w) for a in range(4) for w in itertools.product((0, 1), repeat=3)]
Q = lambda w: -1 + sum(w)
g_nucleon = sum(1 for a, w in anch if Q(w) in (0, 1)) * spin      # n and p only
g_all = len(anch) * spin                                            # also Q=-1, +2 (Delta-like)
g_free_a = 1 * spin
g_free_b = 2**4 * spin
print(f"anchored: nucleons (Q=0,+1) g_B = {g_nucleon};  all charges g_B = {g_all}")
print(f"anchor-free: (a) no windings g = {g_free_a};  (b) windings on all 4 bonds g = {g_free_b}")
target = 0.1200 / 0.02237
for gb_lab, gb in (("nucleons", g_nucleon), ("all charges", g_all)):
    for gf_lab, gf in (("(a)", g_free_a), ("(b)", g_free_b)):
        r = gf / gb
        print(f"  {gf_lab} vs {gb_lab:11s}: n_chi/n_B = {r:.3f}   anchor-free fraction {r/(1+r):.0%}")
print(f"needed: {target:.2f} (anchor-free fraction {target/(1+target):.0%})")
import math
for gf, gb in ((g_free_a, g_nucleon), (g_free_b, g_nucleon), (g_free_b, g_all)):
    print(f"  equilibrium would need the anchored state heavier at freeze-out by "
          f"Delta E/T = ln({target:.2f} x {gb}/{gf}) = {math.log(target*gb/gf):.2f}")
