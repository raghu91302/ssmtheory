Reproducibility bundle for:
"Geometric evaporation of primordial black holes: early-Universe energy-injection
 signatures, a shifted constraint landscape, and the fate of information"
R. Kulkarni (2026)

Contents
--------
compute_pbh.py        Single script that computes every number and figure in the paper:
                      - geometric lifetime tau_Geo and the M^2 scaling
                      - code-distance (threshold-theorem) suppression and the survival cutoff
                      - evaporation-epoch mapping (BBN / photodissociation / mu / y / recombination)
                      - computed BBN/photodissociation bound zeta_EM(t_evap) -> f_PBH(M)
                      - mu/y spectral-distortion bounds vs COBE/FIRAS
                      - combined exclusion with O(1) uncertainty bands
fig1_lifetime.pdf     Lifetime vs mass (Hawking / geometric / code-suppressed)
fig2_epochs.pdf       Evaporation redshift vs mass (epoch bands)
fig3_constraints.pdf  f_PBH(M) exclusion: computed BBN + mu + y + combined band + Hawking comparison

Requirements
------------
Python 3, numpy, scipy, matplotlib.

Run
---
    python3 compute_pbh.py
Regenerates the three PDF figures and prints all tabulated numbers to stdout.

Repository: https://github.com/raghu91302/ssmtheory/blob/main/compute_pbh.py
