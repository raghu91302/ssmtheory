#!/usr/bin/env python3
"""
compute_pbh.py
Computations and figures for the geometric-evaporation PBH paper.
All numbers used in the manuscript are produced here. Pure numpy/scipy/matplotlib.
"""
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import brentq

# ---- publication-quality style ----
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Times New Roman", "Times"],
    "mathtext.fontset": "dejavuserif",
    "font.size": 11,
    "axes.titlesize": 11,
    "axes.labelsize": 11.5,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9,
    "axes.linewidth": 0.9,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.minor.visible": True, "ytick.minor.visible": True,
    "xtick.top": True, "ytick.right": True,
    "xtick.major.size": 5, "ytick.major.size": 5,
    "xtick.minor.size": 2.8, "ytick.minor.size": 2.8,
    "lines.linewidth": 2.0,
    "figure.dpi": 150,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.03,
})

# ---------------- constants (SI) ----------------
c=2.998e8; hbar=1.055e-34; G=6.674e-11; kB=1.381e-23
lP=np.sqrt(hbar*G/c**3); mP=np.sqrt(hbar*c/G); tP=lP/c
ln2=np.log(2)
L0=np.sqrt(4*ln2)*lP                  # bond length 1.665 lP
Lcorr=1e-15                           # QCD correlation length, 1 fm
age=13.8e9*365.25*86400               # s

# cosmology
h=0.674
Omega_dm=0.264
Omega_g=2.473e-5/h**2                 # photons only
dm_over_g = Omega_dm/Omega_g          # ~4850
T0_eV=2.348e-4                        # CMB temp today (eV)
z_dc=1.98e6                           # double-Compton thermalization redshift
z_muy=5e4                             # mu/y boundary
mu_FIRAS=9e-5; y_FIRAS=1.5e-5
fEM=0.5                               # EM-coupled fraction of evaporation energy (flagged O(1))

# ---------------- geometric channel ----------------
def RH(M): return 2*G*M/c**2                          # M in kg
def tau_geo(M): return (2/np.sqrt(ln2))*tP*(M/mP)**2  # unsuppressed, ~M^2
def tau_eff(M):
    x=RH(M)/Lcorr
    return np.inf if x>700 else tau_geo(M)*np.exp(x)
def tau_hawk(M): return 5120*np.pi*G**2*M**3/(hbar*c**4)

# survival cutoff
Mcut_logg=brentq(lambda lg: (np.log(tau_eff(10**lg/1000))-np.log(age))
                 if RH(10**lg/1000)/Lcorr<700 else 50.0, 15,18)
Mcut_g=10**Mcut_logg

# ---------------- evaporation epoch ----------------
def T_inj_eV(t): return 1.0e6*t**-0.5     # ~1 MeV/sqrt(t[s]); g*~10 (flagged)
def z_inj(t): return T_inj_eV(t)/T0_eV - 1.0
def mass_evap_at(t): return 10**brentq(lambda lg: np.log(tau_eff(10**lg/1000))-np.log(t),14,17)

t_BBN_start, t_BBN_end = 1.0, 3e2
t_pdiss_on = 1e4                        # photodissociation onset
t_mu_lo = 2.4*(z_dc*T0_eV/1e6)**-2      # t at z_dc
# epoch boundaries by mass
M_preBBN  = mass_evap_at(t_BBN_start)
M_BBNend  = mass_evap_at(t_BBN_end)
M_pdiss   = mass_evap_at(t_pdiss_on)
M_zdc     = mass_evap_at(t_mu_lo)
def t_at_z(z): return 2.4*((1+z)*T0_eV/1e6)**-2
M_muy     = mass_evap_at(t_at_z(z_muy))
M_recomb  = mass_evap_at(t_at_z(1100))

print("="*70)
print("GEOMETRIC CHANNEL")
print(f"  L_0 = {L0/lP:.3f} lP ; survival cutoff M_cut = 10^{Mcut_logg:.2f} g (R_H={RH(Mcut_g)*1e15:.0f} fm)")
print("EPOCH BOUNDARIES (mass that evaporates at each epoch edge):")
print(f"  BBN onset  (t=1s)      : {M_preBBN:.2e} g")
print(f"  BBN end    (t=300s)    : {M_BBNend:.2e} g")
print(f"  photodiss. onset (1e4s): {M_pdiss:.2e} g")
print(f"  thermaliz. edge z_dc   : {M_zdc:.2e} g")
print(f"  mu/y boundary z=5e4    : {M_muy:.2e} g")
print(f"  recombination z=1100   : {M_recomb:.2e} g")

# ---------------- energy injection & distortions ----------------
def dE_over_Egamma(M, fPBH):
    z=z_inj(tau_eff(M))
    return fEM*fPBH*dm_over_g/(1+z), z
def J_bb(z): return np.exp(-(z/z_dc)**2.5)        # thermalization visibility
def mu_dist(M, fPBH):
    r,z=dE_over_Egamma(M,fPBH)
    if z<z_muy: return 0.0,z                       # y-regime
    return 1.4*r*J_bb(z), z
def y_dist(M, fPBH):
    r,z=dE_over_Egamma(M,fPBH)
    if z>=z_muy: return 0.0,z
    return 0.25*r, z

# max allowed f from each distortion
def fmax_mu(M):
    m1,z=mu_dist(M,1.0); return (mu_FIRAS/m1) if m1>0 else np.inf
def fmax_y(M):
    y1,z=y_dist(M,1.0); return (y_FIRAS/y1) if y1>0 else np.inf

# f_EM- and mobility-varied distortion bounds (for uncertainty propagation)
def _dEE(M,fem,beta):
    z=z_inj(beta*tau_eff(M)); return fem*dm_over_g/(1+z), z
def fmax_mu_v(M,fem,beta):
    r,z=_dEE(M,fem,beta)
    if z<z_muy: return np.inf
    m=1.4*r*J_bb(z); return mu_FIRAS/m if m>0 else np.inf
def fmax_y_v(M,fem,beta):
    r,z=_dEE(M,fem,beta)
    if z>=z_muy: return np.inf
    yv=0.25*r; return y_FIRAS/yv if yv>0 else np.inf
def fpbh_bbn_v(M,fem,beta):
    t=beta*tau_eff(M)
    if not (1e4<t<1.2e13): return np.inf
    z=zeta_bound(t); return (z/(fem*E_per_photon)) if np.isfinite(z) else np.inf
def combined_band(M):
    """Combined exclusion with O(1) uncertainties propagated: vary f_EM,beta."""
    vals=[]
    for fem in (0.3,0.5,0.7):
        for beta in (0.5,1.0,2.0):
            vals.append(min(fmax_mu_v(M,fem,beta),fmax_y_v(M,fem,beta),fpbh_bbn_v(M,fem,beta)))
    vals=[v for v in vals if np.isfinite(v)]
    return (min(vals),max(vals)) if vals else (np.inf,np.inf)

# adopted EM-injection (BBN+photodissociation) threshold on dE/E (flagged, literature-level)
# representative: dE/E <~ 1e-6 in the D-photodissociation window (t~1e4-1e12 s)
def fmax_pdiss(M):
    r,z=dE_over_Egamma(M,1.0)
    t=tau_eff(M)
    if not (t_pdiss_on < t < 1e12): return np.inf
    return 1e-6/r

print("\nDISTORTION BOUNDS (f_PBH max), fEM=0.5:")
print(f"{'M(g)':>9} | {'z_inj':>9} | {'mu(f=1)':>9} | {'y(f=1)':>9} | {'f_max':>9} | channel")
for Mg in [5e15,8e15,1e16,1.3e16,1.5e16,1.8e16,2.0e16,2.3e16,2.5e16,2.9e16]:
    Mk=Mg/1000
    m1,z=mu_dist(Mk,1.0); y1,_=y_dist(Mk,1.0)
    fm=fmax_mu(Mk); fy=fmax_y(Mk); fp=fmax_pdiss(Mk)
    best=min(fm,fy,fp)
    ch = "mu" if best==fm else ("y" if best==fy else "pdiss")
    print(f"{Mg:>9.1e} | {z:>9.1e} | {m1:>9.2e} | {y1:>9.2e} | {best:>9.2e} | {ch}")

print(f"\nHawking present-day gamma-ray bound on 1e16-1e17 g: f_PBH <~ 1e-8 (literature)")
print(f"=> geometric channel relaxes this to f_PBH <~ 1e-4..1e-2 (distortions); ~4-6 orders")

# =====================================================================
#  BBN / PHOTODISSOCIATION CONSTRAINT  (computed, not adopted)
# =====================================================================
# Framework: EM energy injected at t_evap(M) initiates a cascade. For
# t < ~1e4 s the pair-production threshold E_c = m_e^2/(22 T) sits below the
# photodissociation thresholds, so injected energy is degraded before it can
# dissociate nuclei (Cyburt-Ellis-Fields-Olive 2003; Kawasaki-Kohri-Moroi 2005;
# Poulin-Serpico 2015). For t > ~1e4 s, D is destroyed (10^4-10^6 s) and then
# 4He photodissociation overproduces D/3He (>~10^6 s).
#
# Constraint variable (standard): zeta_EM = E_inj^EM * (n_X/n_gamma).
# For the geometric PBH scenario the released EM energy per CMB photon is
#   xi_EM = f_EM * f_PBH * (rho_DM,0 c^2 / n_gamma,0),   INDEPENDENT of M
# (heavier holes are fewer but each releases more). Mass enters only through
# t_evap(M), which selects which published zeta_EM(tau) limit applies.
import numpy as _np
me   = 0.511e-3                 # electron mass (GeV)
Ec_coeff = me**2/22.0          # E_c = me^2/(22 T)
E_D, E_He = 2.22e-3, 19.8e-3   # GeV: D and 4He photodissociation thresholds
GeV_per_cm3_crit = 1.0537e-5*h**2   # rho_crit c^2 in GeV/cm^3
ngamma0 = 410.7                # CMB photons / cm^3 today
rhoDM0_GeV = Omega_dm*GeV_per_cm3_crit          # GeV/cm^3
E_per_photon = rhoDM0_GeV/ngamma0               # GeV released per photon at f_EM=f_PBH=1
def T_of_t_eV(t): return 1.0e6*t**-0.5          # ~1 MeV/sqrt(t[s])  (consistent w/ above)
def Ec_at_t(t):   return Ec_coeff/(T_of_t_eV(t)*1e-9)   # E_c in GeV (T in GeV)

# Published EM-injection bound zeta_EM(tau) [GeV], digitized from the standard
# decaying-particle analyses (Cyburt et al 2003 Fig.; Kawasaki-Kohri-Moroi 2005;
# Poulin-Serpico 2015; Kawasaki-Kohri-Moroi-Takaesu 2018). Piecewise in log-tau:
# D-destruction branch (1e4-1e6 s) ~ 1e-7..1e-9 GeV; 4He branch anchored to the
# Cyburt et al value zeta < 2.1e-10 GeV (tau/1e8 s)^{1/4} for tau>1e8 s.
_logtau = _np.array([4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0])
_logzeta= _np.array([-6.7,-7.6,-8.7,-9.5,-9.68,-9.93,-10.18,-10.43,-10.68])  # log10(zeta/GeV)
def zeta_bound(tau):
    lt=_np.log10(tau)
    if lt < 4.0:  return _np.inf      # photodissociation inactive (E_c below thresholds)
    if lt > 12.0: return 10**(-10.68) # extrapolate flat-ish
    return 10**_np.interp(lt,_logtau,_logzeta)
def fpbh_bbn(M, fEM_=fEM):
    t=tau_eff(M)
    if not (1e4 < t < 1.2e13): return _np.inf   # active only between photodiss onset and recombination
    z=zeta_bound(t)
    if not _np.isfinite(z): return _np.inf
    return z/(fEM_*E_per_photon)      # f_PBH <= zeta_bound / (fEM * E_per_photon)

print("\n"+"="*70)
print("BBN / PHOTODISSOCIATION CONSTRAINT (computed)")
print(f"  E released per CMB photon at f=1: {E_per_photon:.3e} GeV")
print(f"  => xi_EM = {fEM:.2f} * f_PBH * {E_per_photon:.3e} GeV")
print(f"  photodissociation active for t_evap > 1e4 s  (M > {mass_evap_at(1e4):.2e} g)")
print(f"{'M(g)':>9} | {'t_evap(s)':>10} | {'E_c(MeV)':>9} | {'zeta_bnd(GeV)':>13} | {'f_PBH max':>10}")
for Mg in [8e15,1e16,1.2e16,1.5e16,1.8e16,2.0e16,2.3e16,2.6e16,2.9e16]:
    Mk=Mg/1000; t=tau_eff(Mk)
    print(f"{Mg:>9.1e} | {t:>10.2e} | {Ec_at_t(t)*1e3:>9.2f} | {zeta_bound(t):>13.2e} | {fpbh_bbn(Mk):>10.2e}")

# Uncertainty band: vary f_EM in [0.3,0.7] and tau normalization (beta) +/-2x,
# which shifts which mass maps to which lifetime.
def fpbh_bbn_band(M):
    vals=[]
    for fem in (0.3,0.7):
        for beta in (0.5,2.0):   # tau -> beta*tau (mobility O(1))
            t=beta*tau_eff(M); z=zeta_bound(t)
            if _np.isfinite(z): vals.append(z/(fem*E_per_photon))
    return (min(vals),max(vals)) if vals else (_np.inf,_np.inf)


# =====================================================================
#  FIGURES
# =====================================================================
C_HAWK="#1f4e79"; C_GEO="#d4691e"; GREY="#9aa0a6"; DM="#2e8b57"; PUR="#6a3d9a"

# ---- FIG 1: lifetime vs mass ----
Mg=np.logspace(-10,42,1600); Mk=Mg/1000
fig,ax=plt.subplots(figsize=(7.4,5.0))
ax.axvspan(1e17,1e22,color=DM,alpha=0.10,zorder=0)
ax.text(10**20,1e-20,"asteroid-mass PBH\ndark-matter window",color=DM,ha="center",fontsize=8,style="italic")
ax.axhline(age,color=GREY,ls=":",lw=1); ax.text(1e-9,age*3,"Age of universe",color=GREY,fontsize=8,style="italic")
ax.axhline(tP,color=GREY,ls=":",lw=1); ax.text(1e-9,tP*3,"Planck time",color=GREY,fontsize=8,style="italic")
ax.axvline(Mcut_g,color=C_GEO,ls=(0,(4,3)),lw=1,alpha=0.7)
ax.plot(Mg,tau_hawk(Mk),color=C_HAWK,lw=2.2,label=r"Hawking: $\tau\propto M^3$")
ax.plot(Mg,tau_geo(Mk),color=C_GEO,lw=1.6,ls="--",label=r"Geometric (unsuppressed): $\tau\propto M^2$")
ax.plot(Mg,[tau_eff(m) for m in Mk],color=C_GEO,lw=2.4,label=r"Geometric $+$ code threshold")
ax.plot([Mcut_g],[age],"o",color=C_GEO,ms=7,mec="white")
ax.annotate(rf"$M_{{\rm cut}}\sim10^{{16.5}}$ g",xy=(Mcut_g,age),xytext=(10**6,1e18),
            color=C_GEO,fontsize=9,ha="center",arrowprops=dict(arrowstyle="-",color=C_GEO,lw=.9))
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1e-10,1e42); ax.set_ylim(1e-50,1e57)
ax.set_xlabel(r"PBH mass $M$ (g)"); ax.set_ylabel(r"Lifetime $\tau$ (s)")
ax.grid(True,which="major",ls=":",lw=0.5,alpha=0.4,zorder=0); ax.legend(loc="lower right",fontsize=8.5)
plt.tight_layout(); plt.savefig("fig1_lifetime.pdf",bbox_inches="tight"); plt.close()

# ---- FIG 2: evaporation epoch (z_evap vs mass) with bands ----
fig,ax=plt.subplots(figsize=(7.4,5.0))
Mb=np.logspace(15,np.log10(Mcut_g),400); zb=[]
for m in Mb:
    t=tau_eff(m/1000); zb.append(max(z_inj(t),1e-2))
ax.plot(Mb,zb,color=C_GEO,lw=2.5,zorder=5)
# epoch shaded bands (in redshift)
bands=[(z_dc,1e12,"#cfe8ff","thermalized (no distortion)"),
       (z_muy,z_dc,"#ffe0b3",r"$\mu$-distortion"),
       (1100,z_muy,"#ffc2c2",r"$y$-distortion"),
       (1,1100,"#e6d6f5","post-recomb / present")]
for zlo,zhi,col,lab in bands:
    ax.axhspan(zlo,zhi,color=col,alpha=0.55,zorder=0)
    ax.text(1.03e15,np.sqrt(zlo*zhi),lab,fontsize=7.8,va="center")
ax.axhline(1e9,color="k",ls=":",lw=0.8); ax.text(2.6e16,1.3e9,"BBN ($z\\sim10^9$)",fontsize=7.5,ha="right")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlim(1e15,Mcut_g*1.05); ax.set_ylim(1,3e11)
ax.set_xlabel(r"PBH mass $M$ (g)"); ax.set_ylabel(r"Redshift of evaporation $z_{\rm evap}$")

plt.tight_layout(); plt.savefig("fig2_epochs.pdf",bbox_inches="tight"); plt.close()

# ---- FIG 3: f_PBH vs mass exclusion ----
fig,ax=plt.subplots(figsize=(7.6,5.2))
Mc=np.logspace(15.3,np.log10(Mcut_g)*0.999,500)
fmu=np.array([fmax_mu(m/1000) for m in Mc])
fy =np.array([fmax_y(m/1000) for m in Mc])
fbbn=np.array([fpbh_bbn(m/1000) for m in Mc])
# computed BBN/photodissociation uncertainty band (vary f_EM and mobility)
blo=np.array([fpbh_bbn_band(m/1000)[0] for m in Mc])
bhi=np.array([fpbh_bbn_band(m/1000)[1] for m in Mc])
# combined exclusion envelope = strongest applicable bound at each mass
fcomb=np.minimum.reduce([fmu,fy,fbbn])

# shaded uncertainty band for the BBN bound (only where finite)
mask=np.isfinite(blo)&np.isfinite(bhi)
ax.fill_between(Mc[mask],blo[mask],bhi[mask],color="#b03060",alpha=0.16,lw=0,
                label=r"BBN/photodiss. band ($f_{\rm EM}\in[0.3,0.7]$, $\beta\in[0.5,2]$)")
# combined exclusion with full O(1) uncertainty propagated through all channels
clo=np.array([combined_band(m/1000)[0] for m in Mc])
chi=np.array([combined_band(m/1000)[1] for m in Mc])
cmask=np.isfinite(clo)&np.isfinite(chi)
ax.fill_between(Mc[cmask],clo[cmask],chi[cmask],color="0.55",alpha=0.30,lw=0,
                label=r"combined exclusion band (all $O(1)$ uncertainties)")
ax.plot(Mc,fbbn,color="#b03060",lw=1.6,ls="--",zorder=4,label=r"BBN/photodissociation (computed)")
ax.plot(Mc,fmu,color=C_GEO,lw=1.6,zorder=4,label=r"$\mu$-distortion, FIRAS (computed)")
ax.plot(Mc,fy ,color=PUR ,lw=1.6,zorder=4,label=r"$y$-distortion, FIRAS (computed)")
ax.plot(Mc,fcomb,color="k",lw=2.0,zorder=5,label=r"combined exclusion (central)")
# Hawking present-day gamma-ray bound shown ONLY for comparison (does not apply here)
Mh=np.logspace(15.3,17.5,200)
ax.plot(Mh,np.full_like(Mh,1e-8),color=C_HAWK,lw=2.0,ls=":",zorder=3,
        label=r"standard Hawking $\gamma$-ray (does not apply; comparison)")
ax.axvline(Mcut_g,color=GREY,ls=(0,(4,3)),lw=1)
ax.text(Mcut_g*1.04,1.2e-8,"survival\ncutoff",color=GREY,fontsize=8,va="bottom")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlim(1e15,1e17); ax.set_ylim(1e-9,3)
ax.set_xlabel(r"PBH mass $M$ (g)"); ax.set_ylabel(r"$f_{\rm PBH}$ (would-be DM fraction)")
ax.grid(True,which="major",ls=":",lw=0.5,alpha=0.4,zorder=0)
ax.legend(loc="lower left",fontsize=7.0,framealpha=0.95,edgecolor=GREY)
plt.tight_layout(); plt.savefig("fig3_constraints.pdf",bbox_inches="tight"); plt.close()

print("\nwrote fig1_lifetime.pdf, fig2_epochs.pdf, fig3_constraints.pdf")

