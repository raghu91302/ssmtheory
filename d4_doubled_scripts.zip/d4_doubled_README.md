# Geometric Wilson masses for doubled fermions on the FCC and D4 lattices

Verification scripts for the manuscript. NumPy only; each runs in under a minute.

- `d4_doubled_fcc_wilson_verify.py` — FCC bond-direction Dirac operator: gamma algebra,
  anti-Hermiticity, structure tensor S = 4*I, high-symmetry and L-scan gap tables,
  doubler census completeness, and the 6L+2 on-grid zero count.
- `d4_doubled_second_order_check.py` — second-order Clifford algebra: triangular-closure
  orientation cancellation (pure scalar), second-neighbor silencing, scalar Wilson assembly.
- `d4_doubled_d4_verify.py` — D4 root lattice: 4D gamma algebra, S = 6*I, closed forms,
  and L^4 grid scans confirming a single gapless cone with L-independent doubler gaps.

Run: `python3 d4_doubled_fcc_wilson_verify.py`  (requires `numpy`)
