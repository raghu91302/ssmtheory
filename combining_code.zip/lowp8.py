import json, time, numpy as np, pymatching, xx_explicit_mux as X, xx_pinned
X.find_xx_primitive_toric = xx_pinned.pinned_primitive
for mode in ('own_slot', 'xy_slot'):
    X.TRI_MODE = mode; t = time.time()
    c, *_ = X.build_xx_explicit_mux(8, 8, 0.002)
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    n = 0
    for b in range(6):
        ev, fl = c.compile_detector_sampler(seed=991000 + (0 if mode == 'own_slot' else 500) + b).sample(shots=20000, separate_observables=True)
        n += int(np.sum(m.decode_batch(ev) != fl))
    with open('xx_lowp_L8_p0.002.jsonl', 'a') as f: f.write(json.dumps(dict(L=8, p=0.002, mode=mode, n_shots=120000, n_err=n, rate=n/120000)) + '\n')
    print(mode, n, round(time.time() - t), flush=True)
print('DONE', flush=True)
