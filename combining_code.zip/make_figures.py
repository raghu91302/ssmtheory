"""Figures for the combined-architecture paper."""
import json, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

OUT = './'


def wilson(k, n, z=1.96):
    ph = k / n; d = 1 + z * z / n
    c = (ph + z * z / (2 * n)) / d
    h = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def fig_schedule():
    fig, ax = plt.subplots(figsize=(7.2, 2.6))
    rows = ['sheet $S_{xy}$', 'sheet $S_{xz}$', 'sheet $S_{yz}$', 'triangle ancillas']
    cols = ['A', 'B', 'C', 'D']
    active = {0: 0, 1: 1, 2: 2}
    for j, lab in enumerate(cols):
        for i in range(4):
            if i < 3:
                on = active[i] == j
                col = '#4c78a8' if on else ('#e8e8e8' if j < 3 else '#f4d9a6')
                txt = 'extract' if on else 'idle'
            else:
                on = j == 3
                col = '#e45756' if on else 'white'
                txt = 'measure' if on else ''
            ax.add_patch(Rectangle((j, 3 - i), 0.94, 0.86, color=col, ec='#999999', lw=0.6))
            ax.text(j + 0.47, 3 - i + 0.43, txt, ha='center', va='center', fontsize=8,
                    color='white' if on and i < 3 or (i == 3 and on) else '#555555')
    for j, lab in enumerate(['A', 'B', 'C', 'D*']):
        ax.text(j + 0.47, 4.05, 'sub-round ' + lab, ha='center', fontsize=8.5)
    for i, r in enumerate(rows):
        ax.text(-0.08, 3 - i + 0.43, r, ha='right', va='center', fontsize=8.5)
    ax.text(3.47, -0.12, '*merges only', ha='center', va='top', fontsize=7.5, color='#555555')
    ax.set_xlim(-1.35, 4.05); ax.set_ylim(-0.35, 4.35); ax.axis('off')
    plt.tight_layout(); plt.savefig(OUT + 'fig2_schedule.pdf', bbox_inches='tight'); plt.close()


def fig_thresholds():
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.0), sharey=True)
    cols = {4: '#4c78a8', 6: '#f58518', 8: '#54a24b'}
    for ax, (name, f, band) in zip(axes, [('$ZZ$ merge', 'zz_merge_hi_stats.jsonl', (0.756, 0.825)),
                                          ('$XX$ merge', 'xx_merge_hi_stats.jsonl', (0.680, 0.720))]):
        d = {}
        for l in open(OUT + f):
            r = json.loads(l); d.setdefault(r['L'], []).append(r)
        ax.axvspan(*band, color='#999999', alpha=0.22, lw=0, label='pairwise crossings')
        for L in sorted(d):
            rs = sorted(d[L], key=lambda r: r['p'])
            x = [100 * r['p'] for r in rs]; y = [r['rate'] for r in rs]
            lo = [r['rate'] - wilson(r['n_err'], r['n_shots'])[0] for r in rs]
            hi = [wilson(r['n_err'], r['n_shots'])[1] - r['rate'] for r in rs]
            ax.errorbar(x, y, yerr=[lo, hi], fmt='o-', color=cols[L], ms=4, lw=1.4,
                        capsize=2, label=f'$L={L}$')
        ax.set_title(name + ', full chip, fourth-slot schedule', fontsize=9.5)
        ax.set_xlabel('physical error rate $p$ (%)')
        ax.grid(alpha=0.3)
        for s in ('top', 'right'): ax.spines[s].set_visible(False)
    axes[0].set_ylabel('logical error rate per merge')
    axes[0].legend(frameon=False, fontsize=8, loc='upper left')
    plt.tight_layout(); plt.savefig(OUT + 'fig3_thresholds.pdf', bbox_inches='tight'); plt.close()


def fig_provisioning():
    fig, ax = plt.subplots(figsize=(6.0, 3.2))
    c = [i / 100 for i in range(0, 401)]
    ax.plot(c, [(4 + x) / 6 for x in c], color='#117733', lw=2, label='shared ancillas ($4L^3$) + triangles')
    ax.plot(c, [(6 + x) / 6 for x in c], color='#4c78a8', lw=2, ls='--', label='separate ancillas ($6L^3$) + triangles')
    ax.axhline(1.5, color='#cc6677', lw=1.8, label='rotated toric with routing bus')
    for x, lab in [(0, 'sparse\nworkload'), (1, 'all $ZZ$,\none pair'), (2, 'all $ZZ$,\nthree pairs'), (3.2, 'all $ZZ$ and $XX$,\nbest found')]:
        ax.axvline(x, color='#999999', lw=0.8, ls=':')
        ax.text(x + 0.05, 1.83, lab, fontsize=7.5, va='top', color='#555555')
    ax.set_xlabel('triangle ancillas provisioned, in units of $L^3$')
    ax.set_ylabel('physical qubits per logical qubit ($\\times L^2$)')
    ax.set_xlim(-0.05, 4.3); ax.set_ylim(0.55, 1.88)
    ax.legend(frameon=False, fontsize=7.8, loc='lower right')
    ax.grid(alpha=0.3)
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    plt.tight_layout(); plt.savefig(OUT + 'fig5_provisioning.pdf', bbox_inches='tight'); plt.close()




def fig_architecture():
    import numpy as np
    C = {'xy': '#4c78a8', 'xz': '#f58518', 'yz': '#54a24b'}
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 3.1))
    # (a) schematic: one shared vertex ancilla, four data qubits per sheet
    for g, s in enumerate(('xy', 'xz', 'yz')):
        for k in range(4):
            th = np.deg2rad(90 + 120 * g + (k - 1.5) * 22)
            x, y = np.cos(th), np.sin(th)
            a1.plot([0, x], [0, y], color=C[s], lw=1.6)
            a1.scatter(x, y, marker='s', s=70, color=C[s], edgecolor='k', lw=0.5, zorder=3)
        th = np.deg2rad(90 + 120 * g)
        a1.text(1.62 * np.cos(th), 1.62 * np.sin(th), f'sheet $S_{{{s}}}$\nsub-round ' + 'ABC'[g],
                ha='center', va='center', fontsize=8, color=C[s])
    a1.scatter(0, 0, marker='*', s=420, color='#e45756', edgecolor='k', lw=0.7, zorder=4)
    a1.text(0, -0.30, 'shared vertex\nancilla', ha='center', va='top', fontsize=7.5,
            bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.9), zorder=5)
    a1.set_title('(a) 12 couplers, 4 active per sub-round', fontsize=9)
    a1.set_xlim(-2.0, 2.0); a1.set_ylim(-1.75, 1.95); a1.set_aspect('equal'); a1.axis('off')
    # (b) a triangle: one edge per sheet, ancilla at the centroid
    P = np.array([(0, 0), (2, 0), (1, 1.732)])
    cen = P.mean(axis=0)
    for (a, b, s) in ((0, 1, 'xy'), (0, 2, 'xz'), (1, 2, 'yz')):
        a2.plot(*zip(P[a], P[b]), color=C[s], lw=2.6)
        m = (P[a] + P[b]) / 2
        a2.plot(*zip(cen, m), color='#555555', lw=1.0, ls='--', zorder=2)
        a2.scatter(*m, marker='s', s=80, color=C[s], edgecolor='k', lw=0.5, zorder=3)
        off = (m - cen) / np.linalg.norm(m - cen) * 0.38
        a2.text(*(m + off), f'$S_{{{s}}}$', ha='center', va='center', fontsize=8.5, color=C[s])
    a2.scatter(*P.T, s=36, color='#cccccc', edgecolor='k', lw=0.5, zorder=3)
    a2.scatter(*cen, marker='*', s=420, color='#b279a2', edgecolor='k', lw=0.7, zorder=4)
    a2.text(cen[0], cen[1] - 0.2, 'triangle ancilla', ha='center', va='top', fontsize=7.5)
    a2.set_title('(b) one data qubit in each sheet', fontsize=9)
    a2.set_xlim(-0.5, 2.5); a2.set_ylim(-0.6, 2.2); a2.set_aspect('equal'); a2.axis('off')
    plt.tight_layout(); plt.savefig(OUT + 'fig1_architecture.pdf', bbox_inches='tight'); plt.close()


def fig_orbit(L=4):
    import sys, numpy as np
    sys.path.insert(0, '.')
    from sheet_code_fcc_lattice import fcc_triangles, build_fcc_lattice
    from sheet_code_cached_surgery import get_or_build_primitive
    V, vidx, *_ = build_fcc_lattice(L); tris, B = fcc_triangles(L)
    coord = [np.array(V[i], float) for i in range(len(V))]
    key = {frozenset(t): i for i, t in enumerate(map(tuple, tris))}
    T0, _ = get_or_build_primitive(L); T0 = [int(t) for t in T0]
    trans = [(a, b, c) for a in range(L) for b in range(L) for c in range(L) if (a + b + c) % 2 == 0]
    def sh(v, t): return vidx[tuple(int((coord[v][k] + t[k]) % L) for k in range(3))]
    def centroid(ti):
        vs = [coord[v] for v in tris[ti]]; base = vs[0]
        un = [base] + [base + ((w - base + L / 2) % L - L / 2) for w in vs[1:]]
        return (np.mean(un, axis=0)) % L
    prims = {}
    for t in trans:
        img = frozenset(key[frozenset(sh(v, t) for v in tris[ti])] for ti in T0)
        prims.setdefault(img, t)
    fig, ax = plt.subplots(figsize=(4.0, 3.9))
    cmap = plt.get_cmap('tab20')
    seen = set()
    for k, img in enumerate(prims):
        pts = np.array([centroid(ti) for ti in img])
        assert not (seen & img); seen |= img
        ax.scatter(pts[:, 0], pts[:, 1], s=62, color=cmap(k % 20), edgecolor='k', lw=0.4, zorder=3)
    for x in range(L + 1):
        ax.axvline(x, color='#dddddd', lw=0.6, zorder=1); ax.axhline(x, color='#dddddd', lw=0.6, zorder=1)
    ax.set_xlim(0, L); ax.set_ylim(0, L); ax.set_aspect('equal')
    ax.set_xlabel('$x$ (periodic)'); ax.set_ylabel('$y$ (periodic)')
    ax.set_title(f'$L={L}$: {len(prims)} translated $ZZ$ primitives,\n{len(seen)} triangle positions, none shared', fontsize=9)
    plt.tight_layout(); plt.savefig(OUT + 'fig4_orbit.pdf', bbox_inches='tight'); plt.close()
    return len(prims), len(seen)


if __name__ == '__main__':
    fig_architecture(); fig_schedule(); fig_thresholds(); fig_orbit(4); fig_provisioning(); print('figures written')
