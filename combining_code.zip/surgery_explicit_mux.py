"""Run L=8 surgery using cached primitive.

The original build_surgery_circuit_v3 calls find_surgery_primitive every time,
which is O(n^2) and times out at L=8. This module loads the cached primitive
from JSON instead.
"""
import os
import sys
import json
import time
import numpy as np
import stim
import pymatching



from sheet_code_fcc_lattice import (build_fcc_lattice, vertex_Z_stabilizers,
                                     oct_void_X_stabilizers, fcc_triangles)


def get_or_build_primitive(L):
    """Load surgery primitive from cache, or compute and cache it."""
    cache_path = f'surgery_primitive_L{L}.json'
    if os.path.exists(cache_path):
        with open(cache_path) as f:
            cache = json.load(f)
        triangle_indices = np.array(cache['triangle_indices'])
        op = np.array(cache['op'], dtype=np.int8)
        return triangle_indices, op
    
    # Compute fresh
    print(f"  No cache for L={L}, computing primitive...")
    from sheet_code_find_primitive_fast import find_surgery_primitive_fast
    tris, op, B = find_surgery_primitive_fast(L, verbose=False)
    cache = {
        'L': L,
        'triangle_indices': [int(t) for t in tris],
        'op': [int(o) for o in op],
    }
    with open(cache_path, 'w') as f:
        json.dump(cache, f)
    return tris, op


IDLE_RATIO_PER_SUBROUND = 1.0

def build_explicit_mux(L, d_each, p):
    """Surgery circuit using cached primitive — avoids slow O(n^2) search at large L."""
    vertices, vidx, edges, edge_list, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)
    sheet_arr = np.array([{'xy': 0, 'xz': 1, 'yz': 2}[s] for s in edge_to_sheet])
    
    xy_cols = np.where(sheet_arr == 0)[0]
    xz_cols = np.where(sheet_arr == 1)[0]
    yz_cols = np.where(sheet_arr == 2)[0]
    n_xy, n_xz, n_yz = len(xy_cols), len(xz_cols), len(yz_cols)
    n_data = n_xz + n_yz + n_xy
    
    global_to_local = {}
    for i, c in enumerate(xz_cols): global_to_local[c] = i
    for i, c in enumerate(yz_cols): global_to_local[c] = n_xz + i
    for i, c in enumerate(xy_cols): global_to_local[c] = n_xz + n_yz + i
    
    HZ_full, Z_meta = vertex_Z_stabilizers(L)
    HX_full, X_meta = oct_void_X_stabilizers(L)
    
    sheet_Z_stabs = {'xz': [], 'yz': []}
    sheet_X_stabs = {'xz': [], 'yz': []}
    sheet_X_stabs_global_rows = {'xz': [], 'yz': []}
    
    for row_idx, (row, (s_label, pos)) in enumerate(zip(HZ_full, Z_meta)):
        if s_label not in sheet_Z_stabs:
            continue
        nonzero = np.where(row == 1)[0]
        if len(nonzero) == 0:
            continue
        local = [global_to_local[c] for c in nonzero]
        sheet_Z_stabs[s_label].append((local, pos))
    for row_idx, (row, (s_label, pos)) in enumerate(zip(HX_full, X_meta)):
        if s_label not in sheet_X_stabs:
            continue
        nonzero = np.where(row == 1)[0]
        if len(nonzero) == 0:
            continue
        local = [global_to_local[c] for c in nonzero]
        sheet_X_stabs[s_label].append((local, pos))
        sheet_X_stabs_global_rows[s_label].append(row_idx)
    
    n_Zxz = len(sheet_Z_stabs['xz'])
    n_Zyz = len(sheet_Z_stabs['yz'])
    n_Xxz = len(sheet_X_stabs['xz'])
    n_Xyz = len(sheet_X_stabs['yz'])
    
    triangle_indices, op_global = get_or_build_primitive(L)
    n_tri = len(triangle_indices)
    
    # Get B (triangle data qubit list) without computing find_surgery_primitive
    triangles, B = fcc_triangles(L)
    triangle_data_qubits = []
    for ti in triangle_indices:
        edges_in_T = np.where(B[ti] == 1)[0]
        data_qs = [global_to_local[c] for c in edges_in_T]
        triangle_data_qubits.append(data_qs)
    
    # Broken X-stabs
    broken_X_global = set()
    for ti in triangle_indices:
        tri_Z_op = B[ti]
        overlap = (HX_full @ tri_Z_op) % 2
        for x_idx in np.where(overlap == 1)[0]:
            broken_X_global.add(x_idx)
    
    broken_X_local = {'xz': set(), 'yz': set()}
    for sheet_name in ['xz', 'yz']:
        for local_idx, global_row in enumerate(sheet_X_stabs_global_rows[sheet_name]):
            if global_row in broken_X_global:
                broken_X_local[sheet_name].add(local_idx)
    
    Zxz_off = n_data
    Xxz_off = Zxz_off + n_Zxz
    Zyz_off = Xxz_off + n_Xxz
    Xyz_off = Zyz_off + n_Zyz
    Tri_off = Xyz_off + n_Xyz
    total_qubits = Tri_off + n_tri
    
    # ---- explicit multiplexed schedule: shared ancillas, three sub-rounds ----
    assert n_Zxz == n_Zyz and n_Xxz == n_Xyz, "vertex/void sets should coincide"
    Zsh_off = n_data; Xsh_off = Zsh_off + n_Zxz; Tri_off = Xsh_off + n_Xxz
    total_qubits = Tri_off + n_tri
    Z_sh = list(range(Zsh_off, Zsh_off + n_Zxz)); X_sh = list(range(Xsh_off, Xsh_off + n_Xxz))
    Tri_ancs = list(range(Tri_off, Tri_off + n_tri))
    xz_data = list(range(0, n_xz)); yz_data = list(range(n_xz, n_xz + n_yz))
    xy_data = list(range(n_xz + n_yz, n_data))
    c = stim.Circuit()
    all_data = list(range(n_data))
    c.append('R', all_data + Z_sh + X_sh + Tri_ancs)
    if p > 0:
        c.append('DEPOLARIZE1', all_data + Z_sh + X_sh + Tri_ancs, p)
    measurement_records = []
    total_measurements = 0
    P_IDLE = IDLE_RATIO_PER_SUBROUND * p

    def extract_sheet(sheet, record):
        nonlocal total_measurements
        c.append('R', Z_sh + X_sh)
        if p > 0: c.append('DEPOLARIZE1', Z_sh + X_sh, p)
        for slot in range(4):
            cn = []
            for k, (dq, _) in enumerate(sheet_Z_stabs[sheet]):
                if slot < len(dq): cn += [dq[slot], Zsh_off + k]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        if p > 0: c.append('X_ERROR', Z_sh, p)
        c.append('M', Z_sh)
        for k in range(n_Zxz): record[('Z', sheet, k)] = total_measurements + k
        total_measurements += n_Zxz
        c.append('H', X_sh)
        if p > 0: c.append('DEPOLARIZE1', X_sh, p)
        c.append('TICK')
        for slot in range(4):
            cn = []
            for k, (dq, _) in enumerate(sheet_X_stabs[sheet]):
                if slot < len(dq): cn += [Xsh_off + k, dq[slot]]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        c.append('H', X_sh)
        if p > 0: c.append('DEPOLARIZE1', X_sh, p)
        c.append('TICK')
        if p > 0: c.append('X_ERROR', X_sh, p)
        c.append('M', X_sh)
        for k in range(n_Xxz): record[('X', sheet, k)] = total_measurements + k
        total_measurements += n_Xxz

    def syndrome_round(round_idx, with_triangles):
        nonlocal total_measurements
        record = {}
        # sub-round A: sheet xz active; yz and the xy slot's qubits idle
        if P_IDLE > 0: c.append('DEPOLARIZE1', yz_data + xy_data, P_IDLE)
        extract_sheet('xz', record)
        # sub-round B: sheet yz active on the SAME ancillas; xz idles
        if P_IDLE > 0: c.append('DEPOLARIZE1', xz_data + xy_data, P_IDLE)
        extract_sheet('yz', record)
        # sub-round C: the third sheet's slot; xz and yz idle.
        # during a merge the triangle measurements are placed here.
        if P_IDLE > 0: c.append('DEPOLARIZE1', xz_data + yz_data, P_IDLE)
        if with_triangles:
            c.append('R', Tri_ancs)
            if p > 0: c.append('DEPOLARIZE1', Tri_ancs, p)
            for slot in range(3):
                cn = []
                for t, dq in enumerate(triangle_data_qubits):
                    if slot < len(dq): cn += [dq[slot], Tri_off + t]
                if cn:
                    c.append('CX', cn)
                    if p > 0: c.append('DEPOLARIZE2', cn, p)
                    c.append('TICK')
            if p > 0: c.append('X_ERROR', Tri_ancs, p)
            c.append('M', Tri_ancs)
            for t in range(n_tri): record[('T', t)] = total_measurements + t
            total_measurements += n_tri
        measurement_records.append(record)

    def add_detectors_for_round(round_idx, prev_with_tri, curr_with_tri):
        curr_records = measurement_records[round_idx]
        prev_records = measurement_records[round_idx - 1] if round_idx > 0 else None
        
        for sheet_name, n_Z in [('xz', n_Zxz), ('yz', n_Zyz)]:
            for i in range(n_Z):
                curr_m = curr_records[('Z', sheet_name, i)]
                if round_idx == 0:
                    rec_idx = curr_m - total_measurements
                    c.append('DETECTOR', [stim.target_rec(rec_idx)])
                else:
                    prev_m = prev_records[('Z', sheet_name, i)]
                    c.append('DETECTOR', [stim.target_rec(curr_m - total_measurements),
                                           stim.target_rec(prev_m - total_measurements)])
        
        if round_idx > 0:
            for sheet_name, n_X in [('xz', n_Xxz), ('yz', n_Xyz)]:
                for i in range(n_X):
                    is_broken = i in broken_X_local[sheet_name]
                    skip = is_broken and (prev_with_tri or curr_with_tri)
                    if skip:
                        continue
                    curr_m = curr_records[('X', sheet_name, i)]
                    prev_m = prev_records[('X', sheet_name, i)]
                    c.append('DETECTOR', [stim.target_rec(curr_m - total_measurements),
                                           stim.target_rec(prev_m - total_measurements)])
    
    for r in range(d_each):
        syndrome_round(r, with_triangles=False)
        add_detectors_for_round(r, prev_with_tri=False, curr_with_tri=False)
    
    for r in range(d_each):
        round_idx = d_each + r
        syndrome_round(round_idx, with_triangles=True)
        prev_with_tri = (r > 0)
        add_detectors_for_round(round_idx, prev_with_tri=prev_with_tri, curr_with_tri=True)
    
    for r in range(d_each):
        round_idx = 2 * d_each + r
        syndrome_round(round_idx, with_triangles=False)
        prev_with_tri = (r == 0)
        add_detectors_for_round(round_idx, prev_with_tri=prev_with_tri, curr_with_tri=False)
    
    if p > 0:
        c.append('X_ERROR', all_data, p)
    c.append('M', all_data)
    data_m_start = total_measurements
    total_measurements += n_data
    
    last_record = measurement_records[-1]
    for stab_idx, (data_qs, _) in enumerate(sheet_Z_stabs['xz']):
        data_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in data_qs]
        anc_rec_m = last_record[('Z', 'xz', stab_idx)]
        anc_rec = stim.target_rec(anc_rec_m - total_measurements)
        c.append('DETECTOR', data_recs + [anc_rec])
    for stab_idx, (data_qs, _) in enumerate(sheet_Z_stabs['yz']):
        data_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in data_qs]
        anc_rec_m = last_record[('Z', 'yz', stab_idx)]
        anc_rec = stim.target_rec(anc_rec_m - total_measurements)
        c.append('DETECTOR', data_recs + [anc_rec])
    
    op_data_qs = [global_to_local[c_idx] for c_idx in np.where(op_global == 1)[0]]
    obs_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in op_data_qs]
    c.append('OBSERVABLE_INCLUDE', obs_recs, 0)
    
    return c, total_qubits, n_tri, len(broken_X_global)



def run_point(L, d_each, p, n_shots, seed=None):
    import pymatching
    c, nq, n_tri, nb = build_explicit_mux(L, d_each, p)
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    ev, fl = c.compile_detector_sampler(seed=seed).sample(shots=n_shots, separate_observables=True)
    n = int(np.sum(m.decode_batch(ev) != fl))
    return dict(L=L, p=p, n_shots=n_shots, n_err=n, rate=n/n_shots, n_qubits=nq)
