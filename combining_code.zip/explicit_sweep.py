import json, time, surgery_explicit_mux as e
PS=[0.004,0.005,0.006,0.007,0.008,0.009,0.010]
SHOTS={4:6000,6:4000,8:2000}
for L in (4,6,8):
    for p in PS:
        t=time.time()
        r=e.run_point(L,L,p,SHOTS[L],seed=20260921+1000*L+int(round(p*1e6)))
        r['secs']=round(time.time()-t,1)
        with open('zz_merge_explicit_schedule.jsonl','a') as f: f.write(json.dumps(r)+'\n')
        print(L,p,r['rate'],r['secs'],flush=True)
print('DONE',flush=True)
