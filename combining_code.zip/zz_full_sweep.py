import json, sys, time, zz_full_mux as Z
Z.TRI_MODE = sys.argv[1]
_, nq, nt, nb, sh = Z.build_zz_full_mux(8, 1, 0.0)
print('L=8 merged sheets', sh, 'triangles', nt, flush=True)
PS=[0.004,0.005,0.006,0.007,0.008,0.009,0.010]
SHOTS={4:6000,6:4000,8:2000}
for L in (4,6,8):
    for p in PS:
        t=time.time(); rate,n=Z.run_point(L,p,SHOTS[L],seed=20260921+1000*L+int(round(p*1e6)))
        with open(f'zz_merge_fullchip_{"4th_slot" if Z.TRI_MODE == "own_slot" else "xy_slot"}.jsonl','a') as f: f.write(json.dumps(dict(L=L,p=p,n_shots=SHOTS[L],n_err=n,rate=rate,mode=Z.TRI_MODE))+'\n')
        print(L,p,rate,round(time.time()-t,1),flush=True)
print('DONE',flush=True)
