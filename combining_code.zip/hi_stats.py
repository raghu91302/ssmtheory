import json, sys, time
merge, L = sys.argv[1], int(sys.argv[2])
if merge == 'zz':
    import zz_full_mux as M; M.TRI_MODE = 'own_slot'
    run = lambda p, n, s: M.run_point(L, p, n, s)
else:
    import xx_explicit_mux as M, xx_pinned
    M.find_xx_primitive_toric = xx_pinned.pinned_primitive; M.TRI_MODE = 'own_slot'
    run = lambda p, n, s: M.run_point(L, p, n, s)
SHOTS = {4: 30000, 6: 20000, 8: 10000}[L]
import os
done=set()
if os.path.exists(f'{merge}_merge_hi_stats.jsonl'):
    for l in open(f'{merge}_merge_hi_stats.jsonl'):
        r=json.loads(l)
        if r['L']==L: done.add(round(r['p'],4))
for p in (0.005, 0.006, 0.007, 0.008, 0.009):
    if round(p,4) in done: continue
    t = time.time(); rate, n = run(p, SHOTS, 424242 + 1000*L + int(round(p*1e6)))
    with open(f'{merge}_merge_hi_stats.jsonl', 'a') as f:
        f.write(json.dumps(dict(L=L, p=p, n_shots=SHOTS, n_err=n, rate=rate)) + '\n')
    print(merge, L, p, rate, round(time.time()-t), flush=True)
print('DONE', merge, L, flush=True)
