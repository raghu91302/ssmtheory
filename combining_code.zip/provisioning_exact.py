"""Exact provisioning count: fewest triangle positions covering every reachable merge."""
import sys, numpy as np, xx_pinned
from sheet_code_fcc_lattice import fcc_triangles, build_fcc_lattice, vertex_Z_stabilizers, oct_void_X_stabilizers
from sheet_code_cached_surgery import get_or_build_primitive

def rref_basis(H):
    H = (H % 2).astype(np.uint8).copy(); piv = []; r = 0
    for c in range(H.shape[1]):
        rows = np.nonzero(H[r:, c])[0]
        if len(rows) == 0: continue
        p = r + rows[0]; H[[r, p]] = H[[p, r]]
        hit = np.nonzero(H[:, c])[0]; hit = hit[hit != r]; H[hit] ^= H[r]
        piv.append(c); r += 1
        if r == H.shape[0]: break
    return H[:r], piv
def reduce(v, R, piv):
    v = v.copy()
    for i, c in enumerate(piv):
        if v[c]: v ^= R[i]
    return v.tobytes()

def run(L):
    V, vidx, _e, edges, eidx, sheet = build_fcc_lattice(L)
    tris, B = fcc_triangles(L); B = (B % 2).astype(np.uint8)
    coord = [tuple(int(x) for x in V[i]) for i in range(len(V))]
    key = {frozenset(t): i for i, t in enumerate(map(tuple, tris))}
    HZ, _ = vertex_Z_stabilizers(L); HX, _ = oct_void_X_stabilizers(L)
    RZ, pZ = rref_basis(HZ); RX, pX = rref_basis(HX)
    trans = [(a, b, c) for a in range(L) for b in range(L) for c in range(L) if (a + b + c) % 2 == 0]
    def mapv(v, f): return vidx[tuple(x % L for x in f(coord[v]))]
    def img(T, f): return frozenset(key[frozenset(mapv(v, f) for v in tris[t])] for t in T)
    def op(T):
        o = np.zeros(B.shape[1], np.uint8)
        for t in T: o ^= B[t]
        return o
    def sheets(T): return tuple(sorted({sheet[q] for q in np.where(op(T) == 1)[0]}))
    zz0 = [int(t) for t in get_or_build_primitive(L)[0]]
    perms = {'identity': lambda p: p, 'swap x,z': lambda p: (p[2], p[1], p[0]), 'swap y,z': lambda p: (p[0], p[2], p[1])}
    fam = {}
    for nm, f in perms.items():
        T = img(zz0, f); fam[('ZZ', sheets(T))] = T
    for pair in (('xz', 'yz'), ('xy', 'xz'), ('xy', 'yz')):
        ts, _, _ = xx_pinned.pinned_primitive(L, pair=pair)
        T = frozenset(int(t) for t in np.where(ts == 1)[0]); fam[('XX', sheets(T))] = T
    classes = {}
    for (kind, sp), T in fam.items():
        R, piv = (RZ, pZ) if kind == 'ZZ' else (RX, pX)
        groups = {}
        for t in trans:
            P = img(T, lambda p, t=t: (p[0] + t[0], p[1] + t[1], p[2] + t[2]))
            groups.setdefault(reduce(op(P), R, piv), set()).add(P)
        classes[(kind, sp)] = groups
        sizes = sorted({len(g) for g in groups.values()})
        print(f"L={L} {kind} {sp}: {len(groups)} logical pairs; placements per pair {sizes}", flush=True)
    def cover(keys):
        chosen = set()
        todo = [g for k in keys for g in classes[k].values()]
        todo.sort(key=len)
        for g in todo:
            best = max(g, key=lambda P: len(P & chosen)); chosen |= best
        return chosen
    zz = [k for k in classes if k[0] == 'ZZ']; xx = [k for k in classes if k[0] == 'XX']
    for lab, keys in (('ZZ, one sheet pair', zz[:1]), ('ZZ, three sheet pairs', zz), ('XX, one sheet pair', xx[:1]),
                      ('XX, three sheet pairs', xx), ('ZZ and XX, three sheet pairs', zz + xx)):
        s = cover(keys); print(f"L={L} {lab:30s} {len(s):5d} positions = {len(s)/L**3:.2f} L^3 (of {len(tris)} = 4 L^3)", flush=True)

if __name__ == '__main__':
    for L in map(int, sys.argv[1:] or ['4', '6']): run(L)
