import json, sys, time, xx_explicit_mux as X, xx_pinned
X.find_xx_primitive_toric = xx_pinned.pinned_primitive
SHOTS = {6: 40000, 8: 24000}
for L in (6, 8):
    for p in (0.004, 0.003, 0.002):
        for mode in ('own_slot', 'xy_slot'):
            X.TRI_MODE = mode; t = time.time()
            rate, n = X.run_point(L, p, SHOTS[L], 777000 + 1000*L + int(round(p*1e6)) + (0 if mode == 'own_slot' else 500))
            with open('xx_lowp.jsonl', 'a') as f:
                f.write(json.dumps(dict(L=L, p=p, mode=mode, n_shots=SHOTS[L], n_err=n, rate=rate)) + '\n')
            print(L, p, mode, n, round(time.time()-t), flush=True)
print('DONE', flush=True)
