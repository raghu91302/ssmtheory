combining_code.zip
Code and data for: R. Kulkarni, "Combining Ancilla Sharing with Cross-Sheet
Surgery on the FCC Lattice: Explicit Schedules, Merge Thresholds and
Provisioning Cost."

HOW TO RUN
Unzip this archive into the root of the sheet-code archive fcc_code_only.zip
(https://github.com/raghu91302/ssmtheory), whose modules these scripts import.
Run each script from that directory with no arguments unless shown below.
Software: Stim 1.16.0, PyMatching 2.4.0, NumPy 2.4.4, Matplotlib, Python 3.12.
The sweep scripts append to their data files. Delete a data file before
rerunning its sweep, except hi_stats.py, which skips points already present.

CIRCUIT BUILDERS
surgery_mux.py            unshared ZZ merge with an optional averaged idle
                          term (IDLE_RATIO = 0 for the control, 2 for the
                          averaged model)
xx_mux_toric.py           unshared XX merge with the same option
surgery_explicit_mux.py   ZZ merge, two merged sheets, explicit schedule
zz_full_mux.py            ZZ merge, full chip, explicit schedule
xx_explicit_mux.py        XX merge, full chip, explicit schedule
                          (TRI_MODE = "own_slot" for the fourth sub-round,
                          "xy_slot" for sub-round A)

SCRIPT -> DATA FILE -> WHERE IT APPEARS IN THE PAPER
zz_r0_sweep.py            zz_merge_r0_control.jsonl         Sec. 4, control
mux_sweep.py              zz_merge_r2.jsonl                 Table 2, averaged
xx_mux_sweep.py           xx_merge_r2.jsonl                 Table 2, averaged
explicit_sweep.py         zz_merge_explicit_schedule.jsonl  Sec. 4
outlier.py                low_p_check.jsonl                 Sec. 4, 12000 shots
zz_full_sweep.py own_slot zz_merge_fullchip_4th_slot.jsonl  Table 2
zz_full_sweep.py xy_slot  zz_merge_fullchip_xy_slot.jsonl   Table 2
xx_explicit_sweep.py own_slot  xx_merge_explicit_4th_slot.jsonl  Table 2
xx_explicit_sweep.py xy_slot   xx_merge_explicit_xy_slot.jsonl   Table 2
hi_stats.py zz 4|6|8      zz_merge_hi_stats.jsonl           Tables 2, 3; Fig. 3
hi_stats.py xx 4|6|8      xx_merge_hi_stats.jsonl           Tables 2, 3; Fig. 3
lowp.py                   xx_lowp.jsonl                     Table 4
lowp8.py                  xx_lowp_L8_p0.002.jsonl           Table 4, last row

ANALYSIS
boot_analysis.py          bootstrap intervals on the crossings (Table 3);
                          output in bootstrap_results.txt
validation_checks.py      noiseless detector checks and circuit distances
                          (Sec. 4, Table 1), and the share of error
                          mechanisms that flip more than two detectors
                          (Sec. 3)
provisioning_exact.py     translation orbits, logical-pair grouping and
                          coverings (Sec. 6, Table 5); run as
                          python3 provisioning_exact.py 4 6
make_figures.py           Figures 1 to 5 (fig1_architecture.pdf ...
                          fig5_provisioning.pdf)

SEEDS
Sweeps: 20260921 + 1000 L + round(1e6 p). High statistics: 424242 + 1000 L +
round(1e6 p). Low noise: 777000 + 1000 L + round(1e6 p), plus 500 for the
sub-round-A placement; the 120000-shot point uses six batches seeded from
991000 (fourth sub-round) and 991500 (sub-round A).
