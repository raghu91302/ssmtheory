"""Reproduces Section 4: noiseless consistency and circuit-level distance.
Run from the root of fcc_code_only.zip with this archive's scripts alongside."""
import surgery_mux as ZO, zz_full_mux as Z, xx_explicit_mux as X, xx_pinned, sheet_code_xx_surgery_toric as XO
X.find_xx_primitive_toric = xx_pinned.pinned_primitive
XO.find_xx_primitive_toric = xx_pinned.pinned_primitive
ZO.IDLE_RATIO = 0.0

def shared(kind, mode, L, p):
    if kind == 'ZZ':
        Z.TRI_MODE = mode; return Z.build_zz_full_mux(L, L, p)[0]
    X.TRI_MODE = mode; return X.build_xx_explicit_mux(L, L, p)[0]

for L in (4, 6, 8):
    for kind in ('ZZ', 'XX'):
        for mode in ('own_slot', 'xy_slot'):
            fired = int(shared(kind, mode, L, 0.0).compile_detector_sampler().sample(20).sum())
            print(f"noiseless  L={L} {kind} {mode:8s}: detectors fired {fired}")
for L in (4, 6, 8):
    rows = [('ZZ unshared', ZO.build_surgery_circuit_cached(L, L, 0.001)[0]),
            ('XX unshared', XO.build_xx_surgery_circuit_v2(L, L, 0.001)[0])]
    rows += [(f'{k} shared {m}', shared(k, m, L, 0.001)) for k in ('ZZ', 'XX') for m in ('own_slot', 'xy_slot')]
    for name, c in rows:
        d = len(c.shortest_graphlike_error(ignore_ungraphlike_errors=False))
        print(f"distance   L={L} {name:20s}: {d}")

# Multi-detector error mechanisms (Section 3, Decoding)
def multi_detector_fraction(c):
    tot = hyper = 0; pt = ph = 0.0
    for inst in c.detector_error_model(decompose_errors=False).flattened():
        if inst.type != 'error': continue
        nd = sum(1 for t in inst.targets_copy() if t.is_relative_detector_id()); pr = inst.args_copy()[0]
        tot += 1; pt += pr
        if nd > 2: hyper += 1; ph += pr
    return hyper / tot, ph / pt
for L in (4, 6):
    for kind in ('ZZ', 'XX'):
        fm, fp = multi_detector_fraction(shared(kind, 'own_slot', L, 0.007))
        print(f"multi-detector L={L} {kind}: {100*fm:.1f}% of mechanisms, {100*fp:.1f}% of probability")
