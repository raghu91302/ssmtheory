import json, surgery_explicit_mux as e, surgery_mux as a
a.IDLE_RATIO=2.0
for L,p,n in ((8,0.004,12000),(8,0.003,12000),(6,0.004,12000)):
    re=e.run_point(L,L,p,n,seed=777+L+int(p*1e6))
    ra=a.run_point(L,L,p,n,seed=999+L+int(p*1e6))
    with open('low_p_check.jsonl','a') as f: f.write(json.dumps(dict(L=L,p=p,n=n,explicit=re['n_err'],averaged=ra['n_err']))+'\n')
    print(L,p,re['n_err'],ra['n_err'],flush=True)
print('DONE',flush=True)
