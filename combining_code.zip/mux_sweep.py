import json, time, sys, surgery_mux as m
m.IDLE_RATIO = 2.0
PS = [0.004,0.005,0.006,0.007,0.008,0.009,0.010]
SHOTS = {4: 6000, 6: 4000, 8: 2000}
for L in (4, 6, 8):
    for p in PS:
        t = time.time()
        r = m.run_point(L, L, p, SHOTS[L], seed=20260921 + 1000*L + int(round(p*1e6)))
        r['r'] = 2.0; r['secs'] = round(time.time()-t, 1)
        with open('zz_merge_r2.jsonl','a') as f: f.write(json.dumps({k:r[k] for k in ('L','p','n_shots','n_err','rate','r','secs')})+'\n')
        print(L, p, r['rate'], r['secs'], flush=True)
print('DONE', flush=True)
