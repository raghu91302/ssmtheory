"""ZZ merge on the full three-sheet chip, explicit multiplexed schedule.

Z-basis mirror of xx_explicit_mux.build_xx_explicit_mux:
  - all three sheets are full code blocks (every vertex and void stabilizer)
  - one shared vertex-ancilla set and one shared void-ancilla set: 4L^3 + L qubits
  - sub-rounds xy, xz, yz extract each sheet in turn; idle sheets get DEPOLARIZE1(p)
  - TRI_MODE "own_slot": Z-type triangle measurements in a 4th sub-round, merges only
            "xy_slot" : triangles inside xy's sub-round (exceeds the 4-coupler budget)
"""
import numpy as np, stim
from sheet_code_fcc_lattice import (build_fcc_lattice, vertex_Z_stabilizers,
                                    oct_void_X_stabilizers, fcc_triangles)
from sheet_code_cached_surgery import get_or_build_primitive

TRI_MODE = "own_slot"


def build_zz_full_mux(L, d_each, p):
    _v, _vi, _e, edge_list, _ei, edge_to_sheet = build_fcc_lattice(L)
    n_data = len(edge_list)
    HZ, Z_meta = vertex_Z_stabilizers(L)
    HX, X_meta = oct_void_X_stabilizers(L)
    triangles, B = fcc_triangles(L)
    tri_idx, op = get_or_build_primitive(L)
    tri_idx = [int(t) for t in tri_idx]
    n_tri = len(tri_idx)
    tri_data = [list(np.where(B[t] == 1)[0]) for t in tri_idx]
    op_sheets = sorted({edge_to_sheet[q] for q in np.where(op == 1)[0]})

    broken_X = set()
    for t in tri_idx:
        for x in np.where((HX @ B[t]) % 2 == 1)[0]:
            broken_X.add(int(x))

    n_Z, n_X = HZ.shape[0], HX.shape[0]
    Z_stab = [list(np.where(HZ[i] == 1)[0]) for i in range(n_Z)]
    X_stab = [list(np.where(HX[i] == 1)[0]) for i in range(n_X)]
    Zsheet = [lab for lab, _ in Z_meta]; Xsheet = [lab for lab, _ in X_meta]
    SHEETS = ('xy', 'xz', 'yz')
    Z_by = {s: [i for i in range(n_Z) if Zsheet[i] == s] for s in SHEETS}
    X_by = {s: [i for i in range(n_X) if Xsheet[i] == s] for s in SHEETS}
    nZs, nXs = len(Z_by['xy']), len(X_by['xy'])
    Zsh_off = n_data; Xsh_off = Zsh_off + nZs; Tri_off = Xsh_off + nXs
    total_qubits = Tri_off + n_tri
    Z_sh = list(range(Zsh_off, Zsh_off + nZs)); X_sh = list(range(Xsh_off, Xsh_off + nXs))
    Tri = list(range(Tri_off, Tri_off + n_tri))
    data_by = {s: [q for q in range(n_data) if edge_to_sheet[q] == s] for s in SHEETS}
    all_data = list(range(n_data))

    c = stim.Circuit()
    c.append('R', all_data + Z_sh + X_sh + Tri)
    if p > 0: c.append('DEPOLARIZE1', all_data + Z_sh + X_sh + Tri, p)
    recs = []
    tm = [0]

    def extract(sheet, rec):
        c.append('R', Z_sh + X_sh)
        if p > 0: c.append('DEPOLARIZE1', Z_sh + X_sh, p)
        for slot in range(4):
            cn = []
            for k, gi in enumerate(Z_by[sheet]):
                if slot < len(Z_stab[gi]): cn += [Z_stab[gi][slot], Zsh_off + k]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        if p > 0: c.append('X_ERROR', Z_sh, p)
        c.append('M', Z_sh)
        for k, gi in enumerate(Z_by[sheet]): rec[('Z', gi)] = tm[0] + k
        tm[0] += nZs
        c.append('H', X_sh)
        if p > 0: c.append('DEPOLARIZE1', X_sh, p)
        c.append('TICK')
        for slot in range(4):
            cn = []
            for k, gi in enumerate(X_by[sheet]):
                if slot < len(X_stab[gi]): cn += [Xsh_off + k, X_stab[gi][slot]]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        c.append('H', X_sh)
        if p > 0: c.append('DEPOLARIZE1', X_sh, p)
        c.append('TICK')
        if p > 0: c.append('X_ERROR', X_sh, p)
        c.append('M', X_sh)
        for k, gi in enumerate(X_by[sheet]): rec[('X', gi)] = tm[0] + k
        tm[0] += nXs

    def triangle_meas(rec):
        c.append('R', Tri)
        if p > 0: c.append('DEPOLARIZE1', Tri, p)
        for slot in range(3):
            cn = []
            for t, dq in enumerate(tri_data):
                if slot < len(dq): cn += [dq[slot], Tri_off + t]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        if p > 0: c.append('X_ERROR', Tri, p)
        c.append('M', Tri)
        for t in range(n_tri): rec[('T', t)] = tm[0] + t
        tm[0] += n_tri

    def syndrome_round(with_tri):
        rec = {}
        for s in SHEETS:
            idle = [q for s2 in SHEETS if s2 != s for q in data_by[s2]]
            if p > 0: c.append('DEPOLARIZE1', idle, p)
            extract(s, rec)
            if with_tri and TRI_MODE == 'xy_slot' and s == 'xy':
                triangle_meas(rec)
        if with_tri and TRI_MODE == 'own_slot':
            if p > 0: c.append('DEPOLARIZE1', all_data, p)
            triangle_meas(rec)
        recs.append(rec)

    def rt(m): return stim.target_rec(m - tm[0])

    def detectors(r, prev_tri, curr_tri):
        cur = recs[r]; prv = recs[r - 1] if r > 0 else None
        for i in range(n_Z):                       # Z-stabs deterministic from |0>
            if r == 0: c.append('DETECTOR', [rt(cur[('Z', i)])])
            else: c.append('DETECTOR', [rt(cur[('Z', i)]), rt(prv[('Z', i)])])
        if r > 0:
            for i in range(n_X):
                if i in broken_X and (prev_tri or curr_tri): continue
                c.append('DETECTOR', [rt(cur[('X', i)]), rt(prv[('X', i)])])

    r = 0
    for k in range(d_each): syndrome_round(False); detectors(r, False, False); r += 1
    for k in range(d_each): syndrome_round(True); detectors(r, k > 0, True); r += 1
    for k in range(d_each): syndrome_round(False); detectors(r, k == 0, False); r += 1

    if p > 0: c.append('X_ERROR', all_data, p)
    c.append('M', all_data)
    dstart = tm[0]; tm[0] += n_data
    last = recs[-1]
    for i in range(n_Z):
        c.append('DETECTOR', [rt(dstart + q) for q in Z_stab[i]] + [rt(last[('Z', i)])])
    c.append('OBSERVABLE_INCLUDE', [rt(dstart + q) for q in np.where(op == 1)[0]], 0)
    return c, total_qubits, n_tri, len(broken_X), op_sheets


def run_point(L, p, shots, seed):
    import pymatching
    c, *_ = build_zz_full_mux(L, L, p)
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    ev, fl = c.compile_detector_sampler(seed=seed).sample(shots=shots, separate_observables=True)
    n = int(np.sum(m.decode_batch(ev) != fl))
    return n / shots, n
