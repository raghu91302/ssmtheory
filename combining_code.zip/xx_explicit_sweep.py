import json, sys, time, xx_explicit_mux as E, xx_pinned
E.find_xx_primitive_toric = xx_pinned.pinned_primitive
E.TRI_MODE = sys.argv[1]
PS=[0.004,0.005,0.006,0.007,0.008,0.009]
SHOTS={4:6000,6:4000,8:2000}
for L in (4,6,8):
    for p in PS:
        t=time.time(); rate,n=E.run_point(L,p,SHOTS[L],seed=20260921+1000*L+int(round(p*1e6)))
        with open(f'xx_merge_explicit_{"4th_slot" if E.TRI_MODE == "own_slot" else "xy_slot"}.jsonl','a') as f: f.write(json.dumps(dict(L=L,p=p,n_shots=SHOTS[L],n_err=n,rate=rate,mode=E.TRI_MODE,secs=round(time.time()-t,1)))+'\n')
        print(L,p,rate,round(time.time()-t,1),flush=True)
print('DONE',flush=True)
