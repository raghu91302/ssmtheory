import json, numpy as np
rng = np.random.default_rng(20260921)
def load(f):
    d = {}
    for l in open(f):
        r = json.loads(l); d[(r['L'], round(r['p'], 4))] = (r['n_err'], r['n_shots'])
    return d
def cross(rate, a, b, P):
    prev = None
    for p in P:
        if (a, p) not in rate or (b, p) not in rate: continue
        x = rate[(a, p)] - rate[(b, p)]
        if prev is not None and prev[1] * x < 0:
            p0, x0 = prev; return p0 + (p - p0) * abs(x0) / (abs(x0) + abs(x))
        prev = (p, x)
    return None
for name, f in (('ZZ merge', 'zz_merge_hi_stats.jsonl'), ('XX merge', 'xx_merge_hi_stats.jsonl')):
    d = load(f); P = sorted({k[1] for k in d})
    rate = {k: e / n for k, (e, n) in d.items()}
    print(f"{name}  (full chip, 4th-slot design; shots {sorted({n for _, n in d.values()})})")
    pts = []
    for a, b in ((4, 6), (4, 8), (6, 8)):
        c0 = cross(rate, a, b, P); bs = []
        for _ in range(2000):
            rr = {k: rng.binomial(n, e / n) / n for k, (e, n) in d.items()}
            c = cross(rr, a, b, P)
            if c is not None: bs.append(c)
        lo, hi = np.percentile(bs, [2.5, 97.5])
        pts.append(c0)
        print(f"  L={a} vs L={b}: {100*c0:.3f}%   95% CI [{100*lo:.3f}, {100*hi:.3f}]   half-width {100*(hi-lo)/2:.3f} pp  ({len(bs)}/2000 resamples crossed)")
    print(f"  mean {100*np.mean(pts):.3f}%, half-range {100*(max(pts)-min(pts))/2:.3f} pp\n")
