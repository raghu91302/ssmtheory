"""Toric XX-merge surgery circuit (CSS dual of Z-surgery).

Z-surgery structure:
  - Triangle anc reset to |0>, CNOT(data→anc), measure anc in Z
  - Measures Z-product of triangle data qubits
  - Broken X-stabs: those whose X-product anticommutes with triangle Z-products

XX-surgery (this file):
  - Triangle anc reset to |+>, CNOT(anc→data), measure anc in X
  - Measures X-product of triangle data qubits
  - Broken Z-stabs: those whose Z-product anticommutes with triangle X-products
  - Each triangle individually breaks 6 Z-stabs (verified at L=4)
  - Net X-Op breaks 0 Z-stabs (cancellations) — Op is genuine X-logical of toric code
"""
import os
import sys
import json
import time
import numpy as np
import stim
import pymatching



from sheet_code_fcc_lattice import (
    build_fcc_lattice, fcc_triangles,
    vertex_Z_stabilizers, oct_void_X_stabilizers
)
from sheet_code_gf2 import gf2_rank, gf2_kernel


def find_xx_primitive_toric(L):
    """Find toric XX-merge primitive: min-weight non-trivial X-logical via triangles.
    
    Caches to JSON file once found.
    """
    cache_file = f'xx_primitive_L{L}_cache.json'
    if os.path.exists(cache_file):
        with open(cache_file) as f:
            d = json.load(f)
        if d.get('L') == L:
            triangle_set = np.array(d['triangle_set'], dtype=np.int8)
            op_x = np.array(d['op_x'], dtype=np.int8)
            return triangle_set, op_x, d['op_weight']
    
    HZ, _ = vertex_Z_stabilizers(L)
    HX, _ = oct_void_X_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    M_commute = (HZ @ B.T) % 2
    valid_sets = gf2_kernel(M_commute)
    ops = (valid_sets @ B) % 2
    weights = ops.sum(axis=1)
    rank_HX = gf2_rank(HX)
    
    sort_idx = np.argsort(weights)
    # For L=8 we may need to search deeper. Increase limit.
    max_check = min(5000, len(sort_idx))
    for idx in sort_idx[:max_check]:
        if weights[idx] == 0: continue
        op = ops[idx]
        test = np.vstack([HX, op.reshape(1, -1)])
        if gf2_rank(test) > rank_HX:
            ts = valid_sets[idx]
            with open(cache_file, 'w') as f:
                json.dump({
                    'L': L,
                    'triangle_set': ts.tolist(),
                    'op_x': op.tolist(),
                    'op_weight': int(weights[idx]),
                    'n_triangles': int(ts.sum()),
                }, f)
            return ts, op, int(weights[idx])
    raise RuntimeError(f"No XX-primitive found at L={L}")


def build_xx_surgery_circuit(L, d_each, p):
    """Build toric XX-merge surgery circuit."""
    vertices, vidx, edges, _, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)
    n_data = len(edges)
    
    HZ, Z_meta = vertex_Z_stabilizers(L)
    HX, X_meta = oct_void_X_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    # Get XX-primitive
    triangle_set, op_x_global, op_x_weight = find_xx_primitive_toric(L)
    triangle_indices = np.where(triangle_set == 1)[0]
    n_tri = len(triangle_indices)
    
    # Triangle data qubits
    triangle_data_qubits = []
    for ti in triangle_indices:
        edges_in_T = np.where(B[ti] == 1)[0]
        triangle_data_qubits.append(list(edges_in_T))
    
    # Broken Z-stabs: union of those each triangle's X-product anticommutes with
    broken_Z_global = set()
    for ti in triangle_indices:
        tri_X_op = B[ti]  # X-op support
        overlap = (HZ @ tri_X_op) % 2
        for z_idx in np.where(overlap == 1)[0]:
            broken_Z_global.add(z_idx)
    
    n_Z = HZ.shape[0]
    n_X = HX.shape[0]
    
    # Stabilizer data qubits
    Z_stab_data = [list(np.where(HZ[i] == 1)[0]) for i in range(n_Z)]
    X_stab_data = [list(np.where(HX[i] == 1)[0]) for i in range(n_X)]
    
    max_stab_weight = max(
        max(len(s) for s in Z_stab_data),
        max(len(s) for s in X_stab_data),
        max(len(s) for s in triangle_data_qubits),
    )
    
    # Qubit allocation
    Z_off = n_data
    X_off = Z_off + n_Z
    Tri_off = X_off + n_X
    total_qubits = Tri_off + n_tri
    
    c = stim.Circuit()
    all_data = list(range(n_data))
    Z_ancs = list(range(Z_off, Z_off + n_Z))
    X_ancs = list(range(X_off, X_off + n_X))
    Tri_ancs = list(range(Tri_off, Tri_off + n_tri))
    
    # Init: all in |0>
    c.append('R', all_data + Z_ancs + X_ancs + Tri_ancs)
    if p > 0:
        c.append('DEPOLARIZE1', all_data + Z_ancs + X_ancs + Tri_ancs, p)
    
    measurement_records = []
    total_measurements = 0
    
    def syndrome_round(round_idx, with_triangles):
        nonlocal total_measurements
        if round_idx > 0:
            c.append('R', Z_ancs + X_ancs)
            if p > 0:
                c.append('DEPOLARIZE1', Z_ancs + X_ancs, p)
            if with_triangles:
                c.append('R', Tri_ancs)
                if p > 0:
                    c.append('DEPOLARIZE1', Tri_ancs, p)
        
        # Z-syndrome: CNOT(data→anc), measure anc in Z
        for slot in range(max_stab_weight):
            cnots = []
            for stab_idx, data_qs in enumerate(Z_stab_data):
                if slot < len(data_qs):
                    cnots.extend([data_qs[slot], Z_off + stab_idx])
            if cnots:
                c.append('CX', cnots)
                if p > 0: c.append('DEPOLARIZE2', cnots, p)
                c.append('TICK')
        
        if p > 0: c.append('X_ERROR', Z_ancs, p)
        c.append('M', Z_ancs)
        
        record = {}
        for i in range(n_Z):
            record[('Z', i)] = total_measurements + i
        total_measurements += n_Z
        
        # X-syndrome: H, CNOT(anc→data), H, measure
        c.append('H', X_ancs)
        if p > 0: c.append('DEPOLARIZE1', X_ancs, p)
        if with_triangles:
            c.append('H', Tri_ancs)
            if p > 0: c.append('DEPOLARIZE1', Tri_ancs, p)
        c.append('TICK')
        
        for slot in range(max_stab_weight):
            cnots = []
            for stab_idx, data_qs in enumerate(X_stab_data):
                if slot < len(data_qs):
                    cnots.extend([X_off + stab_idx, data_qs[slot]])
            # Triangle X-product measurements: anc as control, data as target
            if with_triangles:
                for tri_idx, data_qs in enumerate(triangle_data_qubits):
                    if slot < len(data_qs):
                        cnots.extend([Tri_off + tri_idx, data_qs[slot]])
            if cnots:
                c.append('CX', cnots)
                if p > 0: c.append('DEPOLARIZE2', cnots, p)
                c.append('TICK')
        
        c.append('H', X_ancs)
        if p > 0: c.append('DEPOLARIZE1', X_ancs, p)
        if with_triangles:
            c.append('H', Tri_ancs)
            if p > 0: c.append('DEPOLARIZE1', Tri_ancs, p)
        c.append('TICK')
        
        ancs_to_measure_X = X_ancs + (Tri_ancs if with_triangles else [])
        if p > 0: c.append('X_ERROR', ancs_to_measure_X, p)
        c.append('M', ancs_to_measure_X)
        
        for i in range(n_X):
            record[('X', i)] = total_measurements + i
        if with_triangles:
            for i in range(n_tri):
                record[('T', i)] = total_measurements + n_X + i
        total_measurements += len(ancs_to_measure_X)
        
        measurement_records.append(record)
    
    def add_detectors(round_idx, prev_with_tri, curr_with_tri):
        """For X-basis surgery: X-stabs are deterministic for |0> init only AFTER first round.
        Wait — we init in |0> (Z eigenstate, not X eigenstate). So Z-stabs are deterministic in round 0,
        X-stabs are random in round 0.
        
        BUT: the OBSERVABLE we're tracking is an X-observable (X-Op). For this to make sense,
        we need to initialize in an X-eigenstate of the X-Op. 
        
        Since X-Op is a product of X's on some qubits, |0>^n has X-Op|0>^n = (X|0>)^... = |1...0>
        which is NOT an eigenstate. So |0>^n is the WRONG initial state for X-basis surgery.
        
        Correct: init in |+>^n (R + H on data), so X-Op|+>^n = |+>^n (eigenvalue +1).
        Then Z-stabs are random in round 0, X-stabs are deterministic.
        """
        curr_records = measurement_records[round_idx]
        prev_records = measurement_records[round_idx - 1] if round_idx > 0 else None
        
        # X-stab detectors: deterministic for |+>^n init
        for i in range(n_X):
            curr_m = curr_records[('X', i)]
            if round_idx == 0:
                rec_idx = curr_m - total_measurements
                c.append('DETECTOR', [stim.target_rec(rec_idx)])
            else:
                prev_m = prev_records[('X', i)]
                c.append('DETECTOR', [stim.target_rec(curr_m - total_measurements), stim.target_rec(prev_m - total_measurements)])
        
        # Z-stab detectors: random round 0, paired from round 1+. Skip "broken" ones during merge.
        if round_idx > 0:
            for i in range(n_Z):
                is_broken = i in broken_Z_global
                skip = is_broken and (prev_with_tri or curr_with_tri)
                if skip: continue
                curr_m = curr_records[('Z', i)]
                prev_m = prev_records[('Z', i)]
                c.append('DETECTOR', [stim.target_rec(curr_m - total_measurements), stim.target_rec(prev_m - total_measurements)])
    
    # Wait — let me reconsider initialization. The XX-merge measures X-Op. For the observable to be
    # deterministic at p=0, we need |+>^n init. Let me re-do the initialization.
    
    # Actually let me restart this function with the correct initialization order.
    raise NotImplementedError("Need to redo with |+> init")


# Restart with correct initialization

TRI_MODE = "own_slot"   # "own_slot": 4th sub-round during merges | "xy_slot": inside xy's sub-round

def build_xx_explicit_mux(L, d_each, p):
    """Build toric XX-merge surgery circuit with |+>^n initialization for X-basis memory."""
    vertices, vidx, _edges_dict, edge_list, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)
    n_data = len(edge_list)
    
    HZ, Z_meta = vertex_Z_stabilizers(L)
    HX, X_meta = oct_void_X_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    triangle_set, op_x_global, op_x_weight = find_xx_primitive_toric(L)
    triangle_indices = np.where(triangle_set == 1)[0]
    n_tri = len(triangle_indices)
    
    triangle_data_qubits = []
    for ti in triangle_indices:
        edges_in_T = np.where(B[ti] == 1)[0]
        triangle_data_qubits.append(list(edges_in_T))
    
    broken_Z_global = set()
    for ti in triangle_indices:
        tri_X_op = B[ti]
        overlap = (HZ @ tri_X_op) % 2
        for z_idx in np.where(overlap == 1)[0]:
            broken_Z_global.add(z_idx)
    
    n_Z = HZ.shape[0]
    n_X = HX.shape[0]
    
    Z_stab_data = [list(np.where(HZ[i] == 1)[0]) for i in range(n_Z)]
    X_stab_data = [list(np.where(HX[i] == 1)[0]) for i in range(n_X)]
    
    max_stab_weight = max(
        max(len(s) for s in Z_stab_data),
        max(len(s) for s in X_stab_data),
        max(len(s) for s in triangle_data_qubits),
    )
    

    # ---- explicit multiplexed schedule: one shared vertex set, one shared void set ----
    Zsheet = [lab for lab, _ in Z_meta]; Xsheet = [lab for lab, _ in X_meta]
    Z_by = {sh: [i for i in range(n_Z) if Zsheet[i] == sh] for sh in ('xy','xz','yz')}
    X_by = {sh: [i for i in range(n_X) if Xsheet[i] == sh] for sh in ('xy','xz','yz')}
    nZs = len(Z_by['xy']); nXs = len(X_by['xy'])
    assert all(len(Z_by[s]) == nZs for s in Z_by) and all(len(X_by[s]) == nXs for s in X_by)
    Zsh_off = n_data; Xsh_off = Zsh_off + nZs; Tri_off = Xsh_off + nXs
    total_qubits = Tri_off + n_tri
    Z_sh = list(range(Zsh_off, Zsh_off + nZs)); X_sh = list(range(Xsh_off, Xsh_off + nXs))
    Tri_ancs = list(range(Tri_off, Tri_off + n_tri))
    sheet_of_edge = list(edge_to_sheet)
    data_by = {sh: [q for q in range(n_data) if sheet_of_edge[q] == sh] for sh in ('xy','xz','yz')}
    c = stim.Circuit()
    all_data = list(range(n_data))
    c.append('R', all_data + Z_sh + X_sh + Tri_ancs)
    c.append('H', all_data)
    if p > 0: c.append('DEPOLARIZE1', all_data + Z_sh + X_sh + Tri_ancs, p)
    measurement_records = []
    total_measurements = 0
    P_IDLE = p

    def extract(sheet, record):
        nonlocal total_measurements
        c.append('R', Z_sh + X_sh)
        if p > 0: c.append('DEPOLARIZE1', Z_sh + X_sh, p)
        rows = Z_by[sheet]
        for slot in range(4):
            cn = []
            for k, gi in enumerate(rows):
                dq = Z_stab_data[gi]
                if slot < len(dq): cn += [dq[slot], Zsh_off + k]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        if p > 0: c.append('X_ERROR', Z_sh, p)
        c.append('M', Z_sh)
        for k, gi in enumerate(rows): record[('Z', gi)] = total_measurements + k
        total_measurements += nZs
        c.append('H', X_sh)
        if p > 0: c.append('DEPOLARIZE1', X_sh, p)
        c.append('TICK')
        rows = X_by[sheet]
        for slot in range(4):
            cn = []
            for k, gi in enumerate(rows):
                dq = X_stab_data[gi]
                if slot < len(dq): cn += [Xsh_off + k, dq[slot]]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        c.append('H', X_sh)
        if p > 0: c.append('DEPOLARIZE1', X_sh, p)
        c.append('TICK')
        if p > 0: c.append('X_ERROR', X_sh, p)
        c.append('M', X_sh)
        for k, gi in enumerate(rows): record[('X', gi)] = total_measurements + k
        total_measurements += nXs

    def triangles(record):
        nonlocal total_measurements
        c.append('R', Tri_ancs)
        if p > 0: c.append('DEPOLARIZE1', Tri_ancs, p)
        c.append('H', Tri_ancs)
        if p > 0: c.append('DEPOLARIZE1', Tri_ancs, p)
        c.append('TICK')
        for slot in range(3):
            cn = []
            for t, dq in enumerate(triangle_data_qubits):
                if slot < len(dq): cn += [Tri_off + t, dq[slot]]
            if cn:
                c.append('CX', cn)
                if p > 0: c.append('DEPOLARIZE2', cn, p)
                c.append('TICK')
        c.append('H', Tri_ancs)
        if p > 0: c.append('DEPOLARIZE1', Tri_ancs, p)
        if p > 0: c.append('X_ERROR', Tri_ancs, p)
        c.append('M', Tri_ancs)
        for t in range(n_tri): record[('T', t)] = total_measurements + t
        total_measurements += n_tri

    def syndrome_round(round_idx, with_triangles):
        record = {}
        for sheet in ('xy', 'xz', 'yz'):
            idle = [q for s2 in ('xy','xz','yz') if s2 != sheet for q in data_by[s2]]
            if P_IDLE > 0: c.append('DEPOLARIZE1', idle, P_IDLE)
            extract(sheet, record)
            if with_triangles and TRI_MODE == "xy_slot" and sheet == 'xy':
                triangles(record)
        if with_triangles and TRI_MODE == "own_slot":
            if P_IDLE > 0: c.append('DEPOLARIZE1', all_data, P_IDLE)   # everyone idles in slot 4
            triangles(record)
        measurement_records.append(record)

    def add_detectors(round_idx, prev_with_tri, curr_with_tri):
        """For |+>^n init: X-stabs deterministic in round 0; Z-stabs random."""
        curr_records = measurement_records[round_idx]
        prev_records = measurement_records[round_idx - 1] if round_idx > 0 else None
        
        # X-stab detectors (X-stabs and triangles use the X-syndrome measurements)
        for i in range(n_X):
            curr_m = curr_records[('X', i)]
            if round_idx == 0:
                rec_idx = curr_m - total_measurements
                c.append('DETECTOR', [stim.target_rec(rec_idx)])
            else:
                prev_m = prev_records[('X', i)]
                c.append('DETECTOR', [stim.target_rec(curr_m - total_measurements), stim.target_rec(prev_m - total_measurements)])
        
        # Z-stab detectors: paired from round 1+; skip broken during merge
        if round_idx > 0:
            for i in range(n_Z):
                is_broken = i in broken_Z_global
                skip = is_broken and (prev_with_tri or curr_with_tri)
                if skip: continue
                curr_m = curr_records[('Z', i)]
                prev_m = prev_records[('Z', i)]
                c.append('DETECTOR', [stim.target_rec(curr_m - total_measurements), stim.target_rec(prev_m - total_measurements)])
    
    for r in range(d_each):
        syndrome_round(r, with_triangles=False)
        add_detectors(r, prev_with_tri=False, curr_with_tri=False)
    
    for r in range(d_each):
        round_idx = d_each + r
        syndrome_round(round_idx, with_triangles=True)
        prev_with_tri = (r > 0)
        add_detectors(round_idx, prev_with_tri=prev_with_tri, curr_with_tri=True)
    
    for r in range(d_each):
        round_idx = 2 * d_each + r
        syndrome_round(round_idx, with_triangles=False)
        prev_with_tri = (r == 0)
        add_detectors(round_idx, prev_with_tri=prev_with_tri, curr_with_tri=False)
    
    # Final: measure in X-basis (H + M)
    c.append('H', all_data)
    if p > 0: c.append('X_ERROR', all_data, p)
    c.append('M', all_data)
    data_m_start = total_measurements
    total_measurements += n_data
    
    last_record = measurement_records[-1]
    
    # Final X-stab detectors: parity of data measurements (in X basis after H) should match last anc reading
    for stab_idx in range(n_X):
        data_qs = X_stab_data[stab_idx]
        data_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in data_qs]
        anc_rec_m = last_record[('X', stab_idx)]
        anc_rec = stim.target_rec(anc_rec_m - total_measurements)
        c.append('DETECTOR', data_recs + [anc_rec])
    
    # Observable: X-Op
    op_data_qs = list(np.where(op_x_global == 1)[0])
    obs_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in op_data_qs]
    c.append('OBSERVABLE_INCLUDE', obs_recs, 0)
    
    return c, total_qubits, n_tri, len(broken_Z_global), op_x_weight



def run_point(L, p, shots, seed):
    import pymatching
    c, *rest = build_xx_explicit_mux(L, L, p)
    m = pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
    ev, fl = c.compile_detector_sampler(seed=seed).sample(shots=shots, separate_observables=True)
    n = int(np.sum(m.decode_batch(ev) != fl))
    return n / shots, n
