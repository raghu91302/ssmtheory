import json, time, numpy as np, pymatching
import xx_mux_toric as XX
import xx_pinned
XX.IDLE_RATIO = 2.0
XX.find_xx_primitive_toric = xx_pinned.pinned_primitive
PS=[0.004,0.005,0.006,0.007,0.008,0.009]
SHOTS={4:6000,6:4000,8:2000}
for L in (4,6,8):
    for p in PS:
        t=time.time()
        c,*_=XX.build_xx_surgery_circuit_v2(L,L,p)
        m=pymatching.Matching.from_detector_error_model(c.detector_error_model(decompose_errors=True))
        ev,fl=c.compile_detector_sampler(seed=20260921+1000*L+int(round(p*1e6))).sample(shots=SHOTS[L],separate_observables=True)
        n=int(np.sum(m.decode_batch(ev)!=fl)); rate=n/SHOTS[L]
        with open('xx_merge_r2.jsonl','a') as f: f.write(json.dumps(dict(L=L,p=p,n_shots=SHOTS[L],n_err=n,rate=rate,r=2.0,secs=round(time.time()-t,1)))+'\n')
        print(L,p,rate,round(time.time()-t,1),flush=True)
print('DONE',flush=True)
