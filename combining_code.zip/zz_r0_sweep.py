import json, time, surgery_mux as m
m.IDLE_RATIO = 0.0
PS=[0.008,0.009,0.010,0.011,0.012]
SHOTS={4:6000,6:4000,8:2000}
for L in (4,6,8):
    for p in PS:
        r=m.run_point(L,L,p,SHOTS[L],seed=20260921+1000*L+int(round(p*1e6)))
        with open('zz_merge_r0_control.jsonl','a') as f: f.write(json.dumps({k:r[k] for k in ('L','p','n_shots','n_err','rate')})+'\n')
        print(L,p,r['rate'],flush=True)
print('DONE',flush=True)
