#!/usr/bin/env python3
"""Transfer of a logical state from a [[15,1,3]] tetrahedral colour code (block A)
into one logical qubit of the FCC sheet code (block B) by one-bit teleportation:

    B <- |+>_L ;  measure Z_A Z_B jointly (R rounds, ancilla-mediated) ;
    measure X_A transversally ;  frame: X_B^{m1} Z_B^{m2}.

A Clifford protocol that maps Z_A -> Z_B and X_A -> X_B with a tracked frame
transfers every state, so the |T> state is covered by checking the Z- and
X-basis truth tables.  Noise: uniform circuit-level depolarizing (DEPOLARIZE2
after every CNOT, DEPOLARIZE1 on idle data, X_ERROR on reset/measure), decoded
with BP+OSD on the full detector error model (the colour-code checks are not
graphlike).
"""
import sys, os, json, itertools, argparse
import numpy as np
import stim
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_css_isomorphism import build_sheet_code

# ----------------------------------------------------------------- GF(2) utils
def rref(M):
    M = M.copy() % 2; r = 0; piv = []
    for c in range(M.shape[1]):
        rows = np.nonzero(M[r:, c])[0]
        if len(rows) == 0: continue
        p = r + rows[0]; M[[r, p]] = M[[p, r]]
        for i in range(M.shape[0]):
            if i != r and M[i, c]: M[i] ^= M[r]
        piv.append(c); r += 1
        if r == M.shape[0]: break
    return M[:r], piv

def kernel(M):
    R, piv = rref(M); n = M.shape[1]
    free = [c for c in range(n) if c not in piv]; basis = []
    for f in free:
        v = np.zeros(n, dtype=np.int8); v[f] = 1
        for i, pc in enumerate(piv):
            if R[i, f]: v[pc] = 1
        basis.append(v)
    return np.array(basis, dtype=np.int8)

def in_span(M, v):
    if M.shape[0] == 0: return not v.any()
    return rref(M)[0].shape[0] == rref(np.vstack([M, v]))[0].shape[0]

# ----------------------------------------------------------------- [[15,1,3]]
def color_code_15():
    vecs = [v for v in itertools.product([0, 1], repeat=4) if any(v)]
    n = 15
    HX = np.array([[v[i] for v in vecs] for i in range(4)], dtype=np.int8)          # weight 8
    HZ = np.array([[v[i] for v in vecs] for i in range(4)] +
                  [[v[i] & v[j] for v in vecs] for i in range(4) for j in range(i+1, 4)], dtype=np.int8)  # weight 8 and 4
    assert not ((HX @ HZ.T) % 2).any()
    # Z-logical: min-weight element of ker(HX) not in rowspace(HZ)
    ZL = None
    for w in range(1, 8):
        for supp in itertools.combinations(range(n), w):
            v = np.zeros(n, dtype=np.int8); v[list(supp)] = 1
            if not ((HX @ v) % 2).any() and not in_span(HZ, v):
                ZL = v; break
        if ZL is not None: break
    XL = np.ones(n, dtype=np.int8)                       # all-ones commutes with HZ, not in rowspace(HX)
    assert not ((HZ @ XL) % 2).any() and not in_span(HX, XL)
    assert (XL @ ZL) % 2 == 1
    return HX, HZ, XL, ZL

# ----------------------------------------------------------------- sheet code B (one sheet)
def sheet_code(L, sheet='xy'):
    st = build_sheet_code(L)[0][sheet]
    HZ, HX = st['HZ'].astype(np.int8), st['HX'].astype(np.int8)
    # one Z-logical: min-weight kernel vector of HX not in rowspace(HZ) (weight L loop in one layer)
    kz = kernel(HX)
    best = None
    for v in kz:
        if not in_span(HZ, v) and (best is None or v.sum() < best.sum()): best = v
    # its conjugate X-logical: kernel vector of HZ anticommuting with ZL, min weight
    kx = kernel(HZ); bx = None
    for v in kx:
        if (v @ best) % 2 == 1 and not in_span(HX, v) and (bx is None or v.sum() < bx.sum()): bx = v
    # reduce weight of XL by adding X-stabilizers greedily (cheap local search)
    for _ in range(3):
        for r in HX:
            w = (bx + r) % 2
            if w.sum() < bx.sum(): bx = w
    return HZ, HX, bx.astype(np.int8), best.astype(np.int8)

def min_weight_logicals(Hcomm, Hspan, wmax=None):
    """All minimum-weight logical operators: vectors in ker(Hcomm) not in rowspace(Hspan)."""
    n = Hcomm.shape[1]; ker = kernel(Hcomm)
    best = min(int(v.sum()) for v in ker if not in_span(Hspan, v))
    if wmax is None: wmax = best
    out = []
    for supp in itertools.combinations(range(n), best):
        v = np.zeros(n, dtype=np.int8); v[list(supp)] = 1
        if not ((Hcomm @ v) % 2).any() and not in_span(Hspan, v): out.append(frozenset(supp))
    return out

def hook_safe_order(H, Hcomm, Hspan):
    """CNOT order per check so that the weight-2 hook (the last two data qubits of the
    cascade) is not contained in any minimum-weight logical of the hook's Pauli type."""
    logs = min_weight_logicals(Hcomm, Hspan)
    orders = []
    for r in range(H.shape[0]):
        qs = list(np.nonzero(H[r])[0]); chosen = None
        for perm in itertools.permutations(qs):
            tail = frozenset(perm[-2:])
            if not any(tail <= lg for lg in logs): chosen = list(perm); break
        orders.append(chosen if chosen is not None else qs)
    return orders

NOISE = dict(A_ext=True, joint=True, A_idle=True, A_read=True, B=True)   # diagnostic switches
# ----------------------------------------------------------------- circuit
def transfer_circuit(L, p, basis='Z', rounds=None, a_state=0, noiseless_prep_A=True,
                     baseline=False):
    """basis: 'Z' tests Z-basis transfer (A in |0>/|1>), 'X' tests X-basis (A in |+>/|->).
    baseline=True: B memory only (no A, no joint measurement) for the same number of rounds."""
    if rounds is None: rounds = L
    HXa, HZa, XLa, ZLa = color_code_15()
    HZb, HXb, XLb, ZLb = sheet_code(L)
    nA, nB = 15, HZb.shape[1]
    # qubit layout
    A = list(range(nA)); B = list(range(nA, nA + nB))
    q = nA + nB
    ancZb = list(range(q, q + HZb.shape[0])); q += HZb.shape[0]
    ancXb = list(range(q, q + HXb.shape[0])); q += HXb.shape[0]
    ancZa = list(range(q, q + HZa.shape[0])); q += HZa.shape[0]
    flagZa = list(range(q, q + HZa.shape[0])); q += HZa.shape[0]
    ancXa = list(range(q, q + HXa.shape[0])); q += HXa.shape[0]
    flagXa = list(range(q, q + HXa.shape[0])); q += HXa.shape[0]
    Jcat = list(range(q, q + 2)); q += 2          # joint ancilla and its flag
    ordZb = hook_safe_order(HZb, HXb, HZb)   # Z-check hooks are Z errors: avoid pairs inside a min-weight Z-logical
    ordXb = hook_safe_order(HXb, HZb, HXb)   # X-check hooks are X errors: avoid pairs inside a min-weight X-logical
    supp_ZLa = [A[i] for i in np.nonzero(ZLa)[0]]
    supp_ZLb = [B[i] for i in np.nonzero(ZLb)[0]]
    supp_XLa = A
    supp_XLb = [B[i] for i in np.nonzero(XLb)[0]]

    c = stim.Circuit()
    meas = []   # record of measurement labels -> index
    def M(qs, label):
        c.append("M", qs); 
        for k, qq in enumerate(qs): meas.append((label, qq))
    def MX(qs, label):
        c.append("MX", qs)
        for k, qq in enumerate(qs): meas.append((label, qq))
    def rec(label, qq):
        # index of most recent measurement with this label and qubit
        for i in range(len(meas) - 1, -1, -1):
            if meas[i] == (label, qq): return stim.target_rec(i - len(meas))
        raise KeyError((label, qq))
    def noisy1(qs):
        if p > 0: c.append("DEPOLARIZE1", qs, p)
    def cnot(pairs):
        flat = [x for pr in pairs for x in pr]
        c.append("CX", flat)
        if p > 0: c.append("DEPOLARIZE2", flat, p)

    def extract(H, data, anc, kind, label, noisy=True, order=None, flags=None):
        """CSS check extraction: reset ancillas, (H) CNOT cascade (H), measure.
        order[r] gives the CNOT order of check r (hook-aware, see hook_safe_order).
        flags: optional list of flag qubits, one per check (Chao-Reichardt): the flag
        is coupled after the first and before the last data CNOT and measured in the
        conjugate basis, so any ancilla fault that would propagate to >=2 data qubits
        flips it.  Flag outcomes become detectors."""
        pp = p if noisy else 0
        c.append("R", anc)
        if pp > 0: c.append("X_ERROR", anc, pp)
        if kind == 'X': c.append("H", anc)
        if flags is not None:
            c.append("RX" if kind == 'Z' else "R", flags)
            if pp > 0: c.append("Z_ERROR" if kind == 'Z' else "X_ERROR", flags, pp)
        seqs = [list(np.nonzero(H[r])[0]) if order is None else order[r] for r in range(H.shape[0])]
        maxw = max(len(q) for q in seqs)
        for k in range(maxw):
            pairs = []
            for r in range(H.shape[0]):
                if k < len(seqs[r]):
                    d = data[seqs[r][k]]
                    pairs.append((anc[r], d) if kind == 'X' else (d, anc[r]))
            flat = [x for pr in pairs for x in pr]
            c.append("CX", flat)
            if pp > 0: c.append("DEPOLARIZE2", flat, pp)
            if flags is not None and (k == 0 or k == maxw - 2):
                fl = [x for r in range(H.shape[0]) for x in ((flags[r], anc[r]) if kind == 'Z' else (anc[r], flags[r]))]
                c.append("CX", fl)
                if pp > 0: c.append("DEPOLARIZE2", fl, pp)
        if kind == 'X': c.append("H", anc)
        if pp > 0: c.append("X_ERROR", anc, pp)
        c.append("M", anc)
        for r in range(H.shape[0]): meas.append((label, r))
        if flags is not None:
            if pp > 0: c.append("Z_ERROR" if kind == 'Z' else "X_ERROR", flags, pp)
            c.append("MX" if kind == 'Z' else "M", flags)
            for r in range(H.shape[0]): meas.append((label + "_flag", r))

    def joint(noisy=True):
        """Joint Z_A Z_B parity: one ancilla J collecting CNOTs from every support
        qubit, with one flag qubit F (Chao-Reichardt).  F is prepared in |+>, coupled
        to J after the first data CNOT and again before the last; any Z fault on J
        in between (which would propagate as a Z string to the remaining data
        qubits) flips F's X outcome.  The flag outcome is a detector, so the
        decoder sees hook errors with their own signature instead of mistaking
        them for data errors.  A's three qubits go first so unflagged faults at
        the ends of the cascade touch at most one data qubit per block."""
        pp = p if noisy else 0
        # interleave A and B support qubits: any contiguous run of the cascade (the
        # support of a hook error, or its complement modulo the measured operator)
        # then contains at most ceil(w/2) qubits of either block, never a whole logical
        supp = []
        for a_, b_ in itertools.zip_longest(supp_ZLb, supp_ZLa):
            if a_ is not None: supp.append(a_)
            if b_ is not None: supp.append(b_)
        J, F = Jcat[0], Jcat[1]
        c.append("R", [J]); c.append("RX", [F])
        if pp > 0: c.append("X_ERROR", [J], pp); c.append("Z_ERROR", [F], pp)
        for k, d in enumerate(supp):
            c.append("CX", [d, J])
            if pp > 0: c.append("DEPOLARIZE2", [d, J], pp)
            if k == 0 or k == len(supp) - 2:
                c.append("CX", [F, J])
                if pp > 0: c.append("DEPOLARIZE2", [F, J], pp)
        if pp > 0: c.append("X_ERROR", [J], pp); c.append("Z_ERROR", [F], pp)
        c.append("M", [J]); meas.append(("J", 0))
        c.append("MX", [F]); meas.append(("F", 0))

    # ---------------- preparation
    # B in |+>_L : RX all, project Z-checks (random), X-checks deterministic (+1)
    # baseline memory prepares in the readout basis; transfer target is always |+>_L
    c.append("R" if (baseline and basis == 'Z') else "RX", B)
    noisy1(B)
    extract(HZb, B, ancZb, 'Z', "Zb", order=ordZb)
    extract(HXb, B, ancXb, 'X', "Xb", order=ordXb)
    if not baseline:
        # A in |0>_L (basis Z) or |+>_L (basis X); optional logical flip for a_state=1
        if basis == 'Z':
            c.append("R", A)
            extract(HXa, A, ancXa, 'X', "Xa", noisy=not noiseless_prep_A)
            extract(HZa, A, ancZa, 'Z', "Za", noisy=not noiseless_prep_A)
            if a_state: c.append("X", supp_XLa)
        else:
            c.append("RX", A)
            extract(HZa, A, ancZa, 'Z', "Za", noisy=not noiseless_prep_A)
            if a_state: c.append("Z", supp_ZLa)
        c.append("TICK")
        # ---------------- transfer rounds: joint ZZ + B checks + A Z-checks
        for t in range(rounds):
            joint(noisy=NOISE["joint"])
            noisy1(B)
            if NOISE["A_idle"]: noisy1(A)
            extract(HZb, B, ancZb, 'Z', "Zb", order=ordZb); extract(HXb, B, ancXb, 'X', "Xb", order=ordXb)
            # A's Z-checks are extracted with one flag per check: a weight-4 CNOT
            # cascade on a distance-3 block would otherwise produce unflagged hooks
            # of weight 2-3.  Z errors on A are caught by the X-syndrome of the final
            # transversal readout.
            extract(HZa, A, ancZa, 'Z', "Za", flags=flagZa, noisy=NOISE["A_ext"])
            extract(HXa, A, ancXa, 'X', "Xa", flags=flagXa, noisy=NOISE["A_ext"])
            c.append("TICK")
        # ---------------- readout of A in X basis
        if p > 0 and NOISE["A_read"]: c.append("Z_ERROR", A, p)
        MX(A, "Ax")
    # ---------------- B memory rounds after transfer
    for t in range(rounds):
        noisy1(B)
        extract(HZb, B, ancZb, 'Z', "Zb", order=ordZb); extract(HXb, B, ancXb, 'X', "Xb", order=ordXb)
        c.append("TICK")
    if basis == 'Z':
        if p > 0: c.append("X_ERROR", B, p)
        M(B, "Bz")
    else:
        if p > 0: c.append("Z_ERROR", B, p)
        MX(B, "Bx")
    return c, meas, dict(HZb=HZb, HXb=HXb, HZa=HZa, HXa=HXa, ZLb=ZLb, XLb=XLb, A=A, B=B,
                         supp_ZLa=supp_ZLa, supp_ZLb=supp_ZLb, supp_XLb=supp_XLb)


def add_detectors_and_observables(c, meas, info, basis, baseline):
    """Rebuild detectors/observables from the measurement log (cleaner than inline)."""
    # strip any DETECTOR instructions appended inline and re-add systematically
    body = stim.Circuit()
    for inst in c:
        if inst.name != "DETECTOR": body.append(inst)
    n = len(meas)
    def idx(label, r): return [i for i, m in enumerate(meas) if m == (label, r)]
    def rt(i): return stim.target_rec(i - n)
    # B checks: consecutive rounds of same check compare
    for lab, H in (("Zb", info["HZb"]), ("Xb", info["HXb"])):
        for r in range(H.shape[0]):
            ids = idx(lab, r)
            for a, b in zip(ids, ids[1:]): body.append("DETECTOR", [rt(a), rt(b)])
    # first-round deterministic checks of B: X-checks for |+> prep, Z-checks for |0> prep
    lab0 = "Zb" if (baseline and basis == 'Z') else "Xb"
    for r in range(info["HZb" if lab0 == "Zb" else "HXb"].shape[0]):
        body.append("DETECTOR", [rt(idx(lab0, r)[0])])
    if not baseline:
        for r in range(info["HZa"].shape[0]):
            ids = idx("Za", r)
            for a, b in zip(ids, ids[1:]): body.append("DETECTOR", [rt(a), rt(b)])
        for r in range(info["HZa"].shape[0]):
            for f in idx("Za_flag", r): body.append("DETECTOR", [rt(f)])
        for r in range(info["HXa"].shape[0]):
            for f in idx("Xa_flag", r): body.append("DETECTOR", [rt(f)])
            ids = idx("Xa", r)
            for a, b in zip(ids, ids[1:]): body.append("DETECTOR", [rt(a), rt(b)])
            if basis == 'X': body.append("DETECTOR", [rt(ids[0])])   # |+> prep: first X-check deterministic
        js = idx("J", 0)
        for a, b in zip(js, js[1:]): body.append("DETECTOR", [rt(a), rt(b)])
        for f in idx("F", 0): body.append("DETECTOR", [rt(f)])        # flag: +1 unless a hook occurred
        # final transversal X readout of A: X-check parities must equal prep values (Z basis)
        # or be deterministic +1 (X basis prep from |+>)
        ax_ids = {qq: i for i, (lab, qq) in enumerate(meas) if lab == "Ax"}
        for r in range(info["HXa"].shape[0]):
            s = [ax_ids[info["A"][k]] for k in np.nonzero(info["HXa"][r])[0]]
            tg = [rt(i) for i in s] + [rt(idx("Xa", r)[-1])]
            body.append("DETECTOR", tg)
    # final detectors: check parities reconstructed from the destructive data readout
    # must agree with the last ancilla measurement of that check
    lab, H, rl = ("Zb", info["HZb"], "Bz") if basis == 'Z' else ("Xb", info["HXb"], "Bx")
    ro = {qq: i for i, (l, qq) in enumerate(meas) if l == rl}
    for r in range(H.shape[0]):
        tg = [rt(ro[info["B"][k]]) for k in np.nonzero(H[r])[0]] + [rt(idx(lab, r)[-1])]
        body.append("DETECTOR", tg)
    # observable
    if basis == 'Z':
        bz = {qq: i for i, (lab, qq) in enumerate(meas) if lab == "Bz"}
        tg = [rt(bz[qq]) for qq in info["supp_ZLb"]]
        if not baseline:
            tg.append(rt(idx("J", 0)[0]))                           # m1 = first joint outcome
    else:
        bx = {qq: i for i, (lab, qq) in enumerate(meas) if lab == "Bx"}
        tg = [rt(bx[qq]) for qq in info["supp_XLb"]]
        if not baseline:
            ax_ids = {qq: i for i, (lab, qq) in enumerate(meas) if lab == "Ax"}
            tg += [rt(ax_ids[qq]) for qq in info["A"]]           # m2 = X_A = parity of all 15
    body.append("OBSERVABLE_INCLUDE", tg, 0)
    return body


def build(L, p, basis, a_state=0, baseline=False, rounds=None):
    c, meas, info = transfer_circuit(L, p, basis, rounds=rounds, a_state=a_state, baseline=baseline)
    return add_detectors_and_observables(c, meas, info, basis, baseline)

# ----------------------------------------------------------------- decoding (BP+OSD on DEM)
def dem_matrices(dem):
    H_rows, L_rows, pri = [], [], []
    nd, no = dem.num_detectors, dem.num_observables
    for inst in dem.flattened():
        if inst.type != "error": continue
        dets = [t.val for t in inst.targets_copy() if t.is_relative_detector_id()]
        obs = [t.val for t in inst.targets_copy() if t.is_logical_observable_id()]
        # a target may repeat (cancel); reduce mod 2
        dv = np.zeros(nd, dtype=np.uint8); ov = np.zeros(max(no, 1), dtype=np.uint8)
        for d in dets: dv[d] ^= 1
        for o in obs: ov[o] ^= 1
        H_rows.append(dv); L_rows.append(ov); pri.append(inst.args_copy()[0])
    return np.array(H_rows).T, np.array(L_rows).T, np.array(pri)

def run(circuit, shots, seed=0, osd_order=5):
    dem = circuit.detector_error_model(decompose_errors=False, allow_gauge_detectors=False)
    H, Lm, pri = dem_matrices(dem)
    from ldpc import BpOsdDecoder
    dec = BpOsdDecoder(H, error_channel=list(pri), max_iter=30, bp_method="minimum_sum",
                       ms_scaling_factor=0.9, osd_method="osd_cs", osd_order=osd_order)
    sampler = circuit.compile_detector_sampler(seed=seed)
    dets, obs = sampler.sample(shots, separate_observables=True)
    fails = 0
    for d, o in zip(dets, obs):
        e = dec.decode(d.astype(np.uint8))
        pred = (Lm @ e) % 2
        fails += int(pred[0] != o[0])
    return fails, shots, H.shape

# ----------------------------------------------------------------- main
def truth_table(L):
    """Noise-free check: every detector deterministic (DEM builds without gauge
    detectors) and the transferred logical value equals the prepared one."""
    print(f"== p=0 truth table, L={L} ==")
    ok = True
    for basis in ('Z', 'X'):
        for a in (0, 1):
            c = build(L, 0.0, basis, a_state=a)
            c.detector_error_model(allow_gauge_detectors=False)      # raises if any detector is random
            obs = [i for i in c if i.name == "OBSERVABLE_INCLUDE"][0]
            recs = [t.value for t in obs.targets_copy()]
            samp = c.compile_sampler(seed=1).sample(200)
            val = samp[:, recs].sum(1) % 2
            const = bool((val == val[0]).all())
            lab = ('01' if basis == 'Z' else '+-')[a]
            print(f"  A = |{lab}>_L : detectors deterministic, B logical constant={const}, "
                  f"value={int(val[0])} (expected {a})")
            ok &= const and int(val[0]) == a
    print("  TRUTH TABLE", "PASS" if ok else "FAIL")
    return ok

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--L", type=int, nargs="+", default=[4])
    ap.add_argument("--p", type=float, nargs="+", default=[0.001, 0.002, 0.003, 0.005])
    ap.add_argument("--shots", type=int, default=2000)
    ap.add_argument("--out", default="results_transfer.json")
    ap.add_argument("--basis", nargs="+", default=["Z", "X"])
    ap.add_argument("--osd", type=int, default=5)
    args = ap.parse_args()
    res = {}
    for L in args.L:
        if args.p and args.p[0] == 0.001: assert truth_table(L)
        for basis in args.basis:
            for p in args.p:
                for tag, bl in (("transfer", False), ("memory_only", True)):
                    c = build(L, p, basis, baseline=bl)
                    f, n, shape = run(c, args.shots, seed=int(1e6 * p) + L, osd_order=args.osd)
                    key = f"L{L}_{basis}_{tag}_p{p}"
                    res[key] = dict(L=L, basis=basis, tag=tag, p=p, fails=f, shots=n,
                                    rate=f / n, qubits=c.num_qubits, dem_shape=list(shape))
                    print(f"  L={L} {basis}-basis {tag:12s} p={p}: {f}/{n} = {f/n:.4f}   "
                          f"(qubits {c.num_qubits}, DEM {shape})", flush=True)
    json.dump(res, open(args.out, "w"), indent=1)
