#!/usr/bin/env python3
"""Figure 3: color-code -> sheet-code transfer. (a) protocol schematic, (b) per-transfer
logical error vs sheet memory, (c) noise-source ablation at p = 0.3%."""
import json, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch

plt.rcParams.update({'font.family': 'serif', 'font.size': 8, 'mathtext.fontset': 'cm'})

def wilson(f, n, z=1.96):
    p = f / n; d = 1 + z*z/n; c = (p + z*z/(2*n)) / d
    h = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n)) / d
    return c - h, c + h

res = json.load(open("results_transfer_cat.json"))
def get(basis, tag, p, r=None):
    k = f"L4_{basis}_{tag}_p{p}" + (f"_r{r}" if r else "")
    v = res[k]; return v["fails"], v["shots"]

fig = plt.figure(figsize=(7.2, 6.4))
gs = fig.add_gridspec(2, 2, height_ratios=[0.78, 1.0], hspace=0.28, wspace=0.38)
axA = fig.add_subplot(gs[0, :]); axB = fig.add_subplot(gs[1, 0]); axC = fig.add_subplot(gs[1, 1])

# ------------------------------------------------------------------ (a) schematic
ax = axA; ax.set_xlim(0, 10); ax.set_ylim(0, 4.6); ax.axis("off")
rows = {"A": 3.7, "J": 2.55, "F": 2.05, "B": 0.9}
labels = {"A": "block $A$\n$[[15,1,3]]$\n15 qubits", "J": "joint\nancilla $J$", "F": "flag $F$", "B": "sheet $S_{xy}$, $L=4$\n64 data + 64 ancilla\n(logical $B$ in one layer)"}
for k, y in rows.items():
    ax.plot([1.55, 9.6], [y, y], color="#404040", lw=1.0 if k != "B" else 1.6, zorder=1)
    ax.text(1.45, y, labels[k], ha="right", va="center", fontsize=6.8)
# prep
ax.add_patch(FancyBboxPatch((1.6, rows["B"]-0.28), 0.55, 0.56, boxstyle="round,pad=0.02", fc="#dce8f4", ec="#1f4060", lw=0.8))
ax.text(1.875, rows["B"], r"$|+\rangle_L$", ha="center", va="center", fontsize=7)
ax.add_patch(FancyBboxPatch((1.6, rows["A"]-0.28), 0.55, 0.56, boxstyle="round,pad=0.02", fc="#f6dfd0", ec="#7a3010", lw=0.8))
ax.text(1.875, rows["A"], r"$|\psi\rangle_L$", ha="center", va="center", fontsize=7)
# L transfer rounds
x0, w = 2.45, 4.1
ax.add_patch(Rectangle((x0, 0.45), w, 3.85, fc="none", ec="#808080", ls="--", lw=0.8))
ax.text(x0 + w/2, 4.42, r"repeat $L$ times", ha="center", va="bottom", fontsize=7, color="#404040")
# joint measurement cascade: CNOTs A(3) and B(4) interleaved into J, flag couplings
xs = [x0 + 0.35 + 0.28*i for i in range(7)]
order = ["B", "A", "B", "A", "B", "A", "B"]
for i, (x, src) in enumerate(zip(xs, order)):
    ax.plot([x, x], [rows[src], rows["J"]], color="#cc3030", lw=0.9)
    ax.plot(x, rows[src], "o", ms=3.2, color="#cc3030")
    ax.plot(x, rows["J"], "o", ms=5.5, mfc="white", mec="#cc3030", mew=0.9)
    ax.plot([x-0.055, x+0.055], [rows["J"], rows["J"]], color="#cc3030", lw=0.9)
    ax.plot([x, x], [rows["J"]-0.055, rows["J"]+0.055], color="#cc3030", lw=0.9)
for xf in (xs[0] + 0.14, xs[5] + 0.14):
    ax.plot([xf, xf], [rows["F"], rows["J"]], color="#2a7a2a", lw=0.9)
    ax.plot(xf, rows["F"], "o", ms=3.2, color="#2a7a2a")
    ax.plot(xf, rows["J"], "o", ms=5.5, mfc="white", mec="#2a7a2a", mew=0.9)
    ax.plot([xf-0.055, xf+0.055], [rows["J"], rows["J"]], color="#2a7a2a", lw=0.9)
    ax.plot([xf, xf], [rows["J"]-0.055, rows["J"]+0.055], color="#2a7a2a", lw=0.9)
xm = xs[-1] + 0.35
for k, lab in (("J", "$M_Z$"), ("F", "$M_X$")):
    ax.add_patch(Rectangle((xm-0.16, rows[k]-0.17), 0.32, 0.34, fc="white", ec="#404040", lw=0.8))
    ax.text(xm, rows[k], lab, ha="center", va="center", fontsize=6)
ax.text(x0 + 0.35 + 0.28*3, 1.55, r"$\bar Z_A \bar Z_B$ parity, A/B interleaved", ha="center", va="center", fontsize=6.5, color="#cc3030")
ax.text(xm + 0.02, rows["J"] + 0.32, "$m_1$", ha="center", fontsize=6.5)
ax.text(xm + 0.3, rows["F"], "flag\ndetector", ha="left", va="center", fontsize=5.8)
# per-block checks
xc = xm + 0.55
for k, txt, fc in (("A", "flagged\n$Z$, $X$ checks", "#f6dfd0"), ("B", "stabilizer\nround", "#dce8f4")):
    ax.add_patch(FancyBboxPatch((xc, rows[k]-0.33), 0.95, 0.66, boxstyle="round,pad=0.02", fc=fc, ec="#404040", lw=0.7))
    ax.text(xc + 0.475, rows[k], txt, ha="center", va="center", fontsize=6)
# readout of A
xr = x0 + w + 0.3
ax.add_patch(Rectangle((xr-0.2, rows["A"]-0.22), 0.4, 0.44, fc="white", ec="#7a3010", lw=0.9))
ax.text(xr, rows["A"], r"$M_X^{\otimes 15}$", ha="center", va="center", fontsize=5.8)
ax.text(xr + 0.45, rows["A"] + 0.28, "$m_2 = \\bar X_A$", ha="left", fontsize=6.5)
ax.text(xr + 0.45, rows["A"] - 0.28, "+ $X$-syndrome", ha="left", fontsize=6)
# B memory rounds and readout
xb = xr + 0.55
ax.add_patch(FancyBboxPatch((xb, rows["B"]-0.33), 1.05, 0.66, boxstyle="round,pad=0.02", fc="#dce8f4", ec="#404040", lw=0.7))
ax.text(xb + 0.525, rows["B"], "$L$ memory\nrounds", ha="center", va="center", fontsize=6)
ax.add_patch(Rectangle((xb + 1.3, rows["B"]-0.22), 0.5, 0.44, fc="white", ec="#1f4060", lw=0.9))
ax.text(xb + 1.55, rows["B"], "$M_{Z/X}$", ha="center", va="center", fontsize=6)
ax.text(xb + 1.3, rows["B"] + 0.55, "frame $\\bar X_B^{m_1}\\bar Z_B^{m_2}$", ha="center", fontsize=6.5)
ax.text(0.15, 4.35, "(a)", fontsize=9, fontweight="bold")

# ------------------------------------------------------------------ (b) cost vs memory
ax = axB
ps = [0.001, 0.002]; xpos = [0, 1]
series = [("Z", "transfer", "#1f77b4", "s", "$Z$ transfer"), ("Z", "memory", "#1f77b4", "o", "$Z$ memory"),
          ("X", "transfer", "#d62728", "s", "$X$ transfer"), ("X", "memory", "#d62728", "o", "$X$ memory")]
off = {("Z","transfer"): -0.24, ("Z","memory"): -0.08, ("X","transfer"): 0.08, ("X","memory"): 0.24}
for basis, tag, col, mk, lab in series:
    for x, p in zip(xpos, ps):
        f, n = get(basis, tag, p); lo, hi = wilson(f, n)
        y = f/n if f > 0 else hi   # zero-failure point plotted at its upper bound
        filled = (tag == "transfer")
        ax.errorbar(x + off[(basis, tag)], y, yerr=[[max(y-lo, 1e-9)], [max(hi-y, 1e-9)]], fmt=mk, ms=5,
                    color=col, mfc=col if filled else "white", mec=col, capsize=2, lw=1,
                    label=lab if x == 0 else None)
        if f == 0:
            ax.annotate("", xy=(x + off[(basis, tag)], y*0.45), xytext=(x + off[(basis, tag)], y),
                        arrowprops=dict(arrowstyle="->", color=col, lw=0.9))
# A-noiseless control
f, n = get("X", "transfer_Anoiseless", 0.001); lo, hi = wilson(f, n)
ax.errorbar(0.5, hi, fmt="^", ms=5, color="#2a7a2a", label="$X$ transfer, block $A$ noiseless")
ax.annotate("", xy=(0.5, hi*0.45), xytext=(0.5, hi), arrowprops=dict(arrowstyle="->", color="#2a7a2a", lw=0.9))
ax.set_yscale("log"); ax.set_ylim(2e-4, 0.3)
ax.set_xticks(xpos); ax.set_xticklabels([r"$10^{-3}$", r"$2\times10^{-3}$"]); ax.set_xlim(-0.55, 1.55)
ax.set_xlabel("physical error rate $p$"); ax.set_ylabel("logical error per run")
ax.legend(fontsize=5.8, loc="lower right", frameon=True, framealpha=0.9)
ax.grid(True, which="both", alpha=0.25)
ax.text(-0.12, 1.02, "(b)", fontsize=9, fontweight="bold", transform=ax.transAxes)

# ------------------------------------------------------------------ (c) ablation at p=0.3%
ax = axC
cats = ["all noise on", "joint meas.\nnoise off", "block $A$\nextraction off", "all block-$A$\nnoise off"]
vals = [(33, 250), (35, 250), (15, 250), (11, 250)]
cols = ["#404040", "#cc3030", "#7a3010", "#7a3010"]
for i, ((f, n), c) in enumerate(zip(vals, cols)):
    lo, hi = wilson(f, n); y = f/n
    ax.bar(i, y, color=c, alpha=0.85, width=0.6)
    ax.errorbar(i, y, yerr=[[y-lo], [hi-y]], fmt="none", ecolor="black", capsize=3, lw=1)
ax.axhline(0.044, color="#1f77b4", ls=":", lw=1)
ax.text(3.35, 0.047, "$\\approx$ memory", fontsize=6, color="#1f77b4", ha="right")
ax.set_xticks(range(4)); ax.set_xticklabels(cats, fontsize=6.5)
ax.set_ylabel("$X$-sector logical error at $p = 3\\times10^{-3}$"); ax.set_ylim(0, 0.2)
ax.text(-0.12, 1.02, "(c)", fontsize=9, fontweight="bold", transform=ax.transAxes)

fig.savefig("fig_transfer.pdf", bbox_inches="tight")
print("saved fig_transfer.pdf")
