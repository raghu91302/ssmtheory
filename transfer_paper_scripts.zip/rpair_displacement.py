#!/usr/bin/env python3
"""Periodic displacement between each data qubit (edge midpoint) of sheet S_xy and
its image under the rotation R:(x,y,z)->(y,z,x), in lattice units (NN spacing = sqrt 2)."""
import numpy as np, sys
sys.path.insert(0, ".")
from sheet_code_fcc_lattice import build_fcc_lattice
for L in (4, 6, 8):
    vertices, vidx, edges, edge_list, edge_to_idx, _ = build_fcc_lattice(L)
    def mid(e):
        a = np.array(vertices[e[0]], float); b = np.array(vertices[e[1]], float)
        d = (b - a + L/2) % L - L/2; return (a + d/2) % L
    R = lambda v: (v[1], v[2], v[0])
    ds = []
    for e in edges['xy']:
        ia, ib = vidx[R(vertices[e[0]])], vidx[R(vertices[e[1]])]
        e2 = (min(ia, ib), max(ia, ib)); assert e2 in edge_to_idx
        d = (mid(e2) - mid(e) + L/2) % L - L/2; ds.append(np.linalg.norm(d))
    ds = np.array(ds); nn = 2 ** 0.5
    print(f"L={L}: d_min={ds.min():.2f} d_mean={ds.mean():.2f} d_max={ds.max():.2f} lattice units "
          f"(= {ds.mean()/nn:.2f} / {ds.max()/nn:.2f} NN spacings mean/max); d_mean/L={ds.mean()/L:.3f}")
