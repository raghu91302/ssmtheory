import sys, json, os, transfer_color_to_sheet as t
L, basis, p, shots, tag = int(sys.argv[1]), sys.argv[2], float(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
rounds = int(sys.argv[6]) if len(sys.argv) > 6 else L
seed_off = int(sys.argv[7]) if len(sys.argv) > 7 else 0
c = t.build(L, p, basis, baseline=(tag == "memory"), rounds=rounds)
f, n, shape = t.run(c, shots, seed=int(1e6 * p) + L + (7 if basis == 'X' else 0) + 100 * rounds + seed_off, osd_order=5)
out = "results_transfer_cat.json"
res = json.load(open(out)) if os.path.exists(out) else {}
k = f"L{L}_{basis}_{tag}_p{p}" + (f"_r{rounds}" if rounds != L else ""); prev = res.get(k, {"fails": 0, "shots": 0})
res[k] = {"L": L, "basis": basis, "tag": tag, "p": p, "rounds": rounds, "fails": prev["fails"] + f, "shots": prev["shots"] + n, "qubits": c.num_qubits}
res[k]["rate"] = res[k]["fails"] / res[k]["shots"]
json.dump(res, open(out, "w"), indent=1)
print(f"{k}: {res[k]['fails']}/{res[k]['shots']} = {res[k]['rate']:.4f}")
