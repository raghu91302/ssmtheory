# Code for "Fault-Tolerant Transfer of Magic States from a Color-Code Factory into the FCC Sheet Code"

Run each script from this directory with Python 3.12. Install dependencies with
`pip install -r requirements.txt`.

| Script | Supports |
|---|---|
| `sheet_code_fcc_lattice.py`, `sheet_code_planar_lattice.py` | lattice and stabilizer construction (toric and planar) |
| `verify_css_isomorphism.py` | Computational Result 1 (R is a CSS isomorphism), L = 4, 6, 8 |
| `verify_layer_decomposition.py` | consistency check of Theorem 1 against the lattice module |
| `verify_cross_sheet_reachability.py` | consistency check of the 6L-3 reachability count, L = 4, 6 |
| `ribbon_construction.py`, `triangle_ribbon_analysis.py` | ribbon atom counts, Table 5 |
| `transfer_color_to_sheet.py` | Section 6.3: transfer circuit, p = 0 truth table, circuit-distance check, noisy sweep |
| `run_point.py` | runs one (L, basis, p, shots, transfer/memory, rounds) point and accumulates into `results_transfer_cat.json` |
| `results_transfer_cat.json` | every shot count behind Table 4 |
| `sweep_memory_threshold.py`, `sweep_zz_merge_threshold.py`, `sweep_transversal_cnot_threshold.py` | threshold sweep drivers (Section 5) |
| `make_fig_threshold.py`, `make_arch_fig.py`, `make_fig_transfer.py` | Figures 2, 1, and 3 |

The circuit builders and decoders for the Section 5 sweeps (`fcc_sheet_circuit.py`,
`fcc_feedforward_real.py`, `indep_checks.py`, `fcc_surgery_circuit.py`, `bposd_decode.py`,
`gen_data_surgery.py`) and their raw shot data are in the public repository named in the
paper's Code and Data Availability section, not in this bundle.

Example (transfer, one point):

    python3 run_point.py 4 X 0.001 300 transfer 4 0

Example (truth table and circuit distance only):

    python3 -c "import transfer_color_to_sheet as t; t.truth_table(4)"
