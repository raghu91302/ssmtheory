#!/usr/bin/env python3
"""For each layer of a sheet, check that the two logical Z classes admit
pairwise-disjoint weight-L representatives, so that 2L transfers (one per
logical) can use disjoint sheet data qubits.  Prints per-layer results at L=4,6,8."""
import numpy as np, itertools, sys
sys.path.insert(0, ".")
from transfer_color_to_sheet import kernel, in_span
from verify_css_isomorphism import build_sheet_code
from sheet_code_fcc_lattice import build_fcc_lattice

def check(L, sheet='xy'):
    st = build_sheet_code(L)[0][sheet]; HZ, HX = st['HZ'].astype(np.int8), st['HX'].astype(np.int8); n = HZ.shape[1]
    vertices, vidx, edges, _, _, _ = build_fcc_lattice(L); es = edges[sheet]
    ax = {'xy': 2, 'xz': 1, 'yz': 0}[sheet]
    layer = np.array([vertices[i][ax] for i, j in es])
    kb = list(kernel(HX)); cands = set()
    for v in kb:
        if v.sum() == L and not in_span(HZ, v): cands.add(tuple(np.nonzero(v)[0]))
    for a, b in itertools.combinations(kb, 2):
        v = (a + b) % 2
        if v.sum() == L and not in_span(HZ, v): cands.add(tuple(np.nonzero(v)[0]))
    out = []
    for z in range(L):
        cz = [set(c) for c in cands if all(layer[q] == z for q in c)]; found = None
        for a, b in itertools.combinations(cz, 2):
            if a & b: continue
            va = np.zeros(n, dtype=np.int8); va[list(a)] = 1; vb = np.zeros(n, dtype=np.int8); vb[list(b)] = 1
            if not in_span(np.vstack([HZ, va]), vb): found = (sorted(a), sorted(b)); break
        out.append((z, len(cz), found))
    return out

if __name__ == "__main__":
    for L in (4, 6, 8):
        r = check(L); ok = sum(f is not None for _, _, f in r)
        print(f"L={L}: {ok}/{L} layers admit two disjoint independent weight-{L} Z-logical representatives")
        for z, nc, f in r: print(f"   layer {z}: {nc} candidates, disjoint pair {'found' if f else 'NOT found'}")
