"""Architecture diagram: FCC sheet code memory + 3D color code factory."""
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
import numpy as np

mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Computer Modern Roman', 'Times', 'DejaVu Serif'],
    'text.usetex': False,
    'mathtext.fontset': 'cm',
    'font.size': 9,
    'axes.linewidth': 0.6,
    'pdf.fonttype': 42,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

fig, ax = plt.subplots(figsize=(7.5, 4.0))
ax.set_xlim(0, 10)
ax.set_ylim(0, 5.5)
ax.axis('off')

# Memory zone (left)
mem_x, mem_y, mem_w, mem_h = 0.3, 0.4, 5.2, 4.7
ax.add_patch(FancyBboxPatch((mem_x, mem_y), mem_w, mem_h,
                             boxstyle="round,pad=0.08",
                             facecolor='#e8f1f8', edgecolor='#1f6f9d',
                             linewidth=1.2))
ax.text(mem_x + mem_w/2, mem_y + mem_h - 0.25,
        'Memory zone:  FCC sheet code', fontsize=11, fontweight='bold',
        color='#1f4060', ha='center', va='top')

# Three sheets visualized as stacked 3D blocks
sheets = [
    {'pos': (1.0, 2.7), 'label': r'$S_{xy}$', 'color': '#5b8ec2'},
    {'pos': (2.4, 2.3), 'label': r'$S_{xz}$', 'color': '#a06aa6'},
    {'pos': (3.8, 1.9), 'label': r'$S_{yz}$', 'color': '#c2a05b'},
]
for s in sheets:
    x, y = s['pos']
    ax.add_patch(mpatches.Rectangle((x, y), 1.2, 1.0,
                                     facecolor=s['color'], edgecolor='black',
                                     linewidth=0.5, alpha=0.85))
    ax.add_patch(mpatches.Polygon([(x, y+1.0), (x+0.25, y+1.2),
                                    (x+1.45, y+1.2), (x+1.2, y+1.0)],
                                   facecolor=s['color'], edgecolor='black',
                                   linewidth=0.5, alpha=0.65))
    ax.add_patch(mpatches.Polygon([(x+1.2, y), (x+1.45, y+0.2),
                                    (x+1.45, y+1.2), (x+1.2, y+1.0)],
                                   facecolor=s['color'], edgecolor='black',
                                   linewidth=0.5, alpha=0.5))
    ax.text(x+0.6, y+0.5, s['label'], fontsize=11, ha='center', va='center',
            color='white', fontweight='bold')

# Rotation R arrow
ax.annotate('', xy=(2.4, 3.0), xytext=(1.8, 3.7),
            arrowprops=dict(arrowstyle='->', color='#cc3030', lw=1.4,
                            connectionstyle="arc3,rad=0.3"))
ax.text(1.4, 4.0, r'$R:(x,y,z)\to(y,z,x)$',
        fontsize=8.5, color='#cc3030', ha='left')
ax.text(1.4, 3.7, 'transversal CNOT', fontsize=8, color='#cc3030',
        ha='left', style='italic')

# Code params
ax.text(mem_x + mem_w/2, 1.05,
        r'$[[3L^3, 6L, L]]$    weight-4 stabilizers,  MWPM-decodable',
        fontsize=9, ha='center', color='#1f4060')
ax.text(mem_x + mem_w/2, 0.70,
        r'$2L$ logicals/sheet,  $24$ total at $L{=}4$,  $K{=}4$ connectivity',
        fontsize=9, ha='center', color='#1f4060')

# Factory zone (right)
fac_x, fac_y, fac_w, fac_h = 6.8, 0.4, 2.9, 4.7
ax.add_patch(FancyBboxPatch((fac_x, fac_y), fac_w, fac_h,
                             boxstyle="round,pad=0.08",
                             facecolor='#fef0e8', edgecolor='#cc6020',
                             linewidth=1.2))
ax.text(fac_x + fac_w/2, fac_y + fac_h - 0.25,
        'Factory:  3D color code', fontsize=9, fontweight='bold',
        color='#7a3010', ha='center', va='top')

for cx, cy in [(7.5, 3.5), (8.5, 3.5), (7.5, 2.5), (8.5, 2.5)]:
    diamond = mpatches.Polygon([(cx, cy+0.35), (cx+0.35, cy),
                                 (cx, cy-0.35), (cx-0.35, cy)],
                                facecolor='#e08850', edgecolor='black',
                                linewidth=0.5, alpha=0.85)
    ax.add_patch(diamond)
    ax.text(cx, cy, r'$[[15,1,3]]$', fontsize=6.5, ha='center', va='center', color='white')

ax.text(fac_x + fac_w/2, 1.75,
        '$15$-to-$1$ distillation', fontsize=9, ha='center', color='#7a3010')
ax.text(fac_x + fac_w/2, 1.40,
        'transversal $T$ on $[[15,1,3]]$ blocks',
        fontsize=7.5, ha='center', color='#7a3010', style='italic')
ax.text(fac_x + fac_w/2, 1.00,
        r'$|T\rangle$ output stream', fontsize=9, ha='center', color='#7a3010',
        fontweight='bold')

# Interface arrow
ax.annotate('', xy=(5.55, 2.6), xytext=(6.75, 2.6),
            arrowprops=dict(arrowstyle='->', color='#404040', lw=2.0))
ax.text(6.2, 3.10, 'transfer (Sec. 6.3)', fontsize=6.3, color='#404040',
        ha='center', style='italic')
ax.text(6.2, 2.85, 'then $R$-paired CNOT', fontsize=6.3, color='#404040',
        ha='center', style='italic')
ax.text(6.2, 2.35, r'$2L$ injections', fontsize=6.3, color='#404040', ha='center')
ax.text(6.2, 2.12, 'per layer', fontsize=6.3, color='#404040', ha='center')

ax.text(5.0, 0.12,
        r'$L{=}4$:  $\sim 384$ atoms memory  $+$  $\sim 100\text{--}200$ atoms factory',
        fontsize=8.5, ha='center', color='#404040', style='italic')

plt.savefig('fig_arch.pdf')
plt.savefig('fig_arch.png', dpi=200)
print("Architecture figure saved")
