#!/usr/bin/env python3
"""Exhaustive circuit-level fault search on the transfer circuit at L=4.

Takes the detector error model of the actual circuit with decompose_errors=False
(so every mechanism keeps its full detector signature, hyperedges included),
collects the distinct (detector-set, observable-flip) mechanisms, and checks
exhaustively whether any combination of 1, 2 or 3 distinct mechanisms is
undetectable (all detectors cancel) yet flips the observable.  Two copies of
the same mechanism cancel, so distinct mechanisms suffice.  A weight-w
undetected logical found by Stim's search is reported as the matching upper
bound.
"""
import sys, time, itertools
import stim, numpy as np
sys.path.insert(0, ".")
import transfer_color_to_sheet as t

def mechanisms(circuit):
    dem = circuit.detector_error_model(decompose_errors=False)
    seen = {}
    for inst in dem.flattened():
        if inst.type != "error": continue
        d = 0; o = 0
        for tg in inst.targets_copy():
            if tg.is_relative_detector_id(): d ^= (1 << tg.val)
            elif tg.is_logical_observable_id(): o ^= 1
        seen[(d, o)] = seen.get((d, o), 0) + 1   # duplicates already merged by Stim; keep count anyway
    return list(seen.keys())

def search(mechs, maxw=3):
    n = len(mechs)
    dets = [m[0] for m in mechs]; obs = [m[1] for m in mechs]
    # weight 1
    w1 = [i for i in range(n) if dets[i] == 0 and obs[i] == 1]
    # weight 2: two distinct mechanisms with equal detector pattern and different observable flip
    bypat = {}
    for i, d in enumerate(dets): bypat.setdefault(d, []).append(i)
    w2 = []
    for d, idx in bypat.items():
        os_ = {obs[i] for i in idx}
        if len(os_) == 2: w2.append((idx[0], next(j for j in idx if obs[j] != obs[idx[0]])))
    if maxw < 3: return w1, w2, None
    # weight 3: for i<j, need k with dets[k] = dets[i]^dets[j] and obs[k] = 1^obs[i]^obs[j], k not in {i,j}
    w3 = None; t0 = time.time()
    for i in range(n):
        di, oi = dets[i], obs[i]
        for j in range(i + 1, n):
            p = di ^ dets[j]
            lst = bypat.get(p)
            if lst is None: continue
            want = 1 ^ oi ^ obs[j]
            for k in lst:
                if k != i and k != j and obs[k] == want:
                    w3 = (i, j, k); break
            if w3: break
        if w3: break
    return w1, w2, w3, time.time() - t0

def weight4_exists(mechs):
    """Exhaustive weight-4 check: two disjoint pairs with equal detector pattern and different parity."""
    dets = [m[0] for m in mechs]; obs = [m[1] for m in mechs]; n = len(mechs); pairs = {}
    for i in range(n):
        for j in range(i + 1, n): pairs.setdefault(dets[i] ^ dets[j], []).append((i, j, obs[i] ^ obs[j]))
    for lst in pairs.values():
        ev = [x for x in lst if x[2] == 0]; od = [x for x in lst if x[2] == 1]
        for a in ev:
            for b in od:
                if len({a[0], a[1], b[0], b[1]}) == 4: return True
    return False

if __name__ == "__main__":
    L = 4; p = 0.001
    if len(sys.argv) > 1 and sys.argv[1] == "ribbon":
        # requires fcc_surgery_circuit.py from ssmtheory_repo_scripts.zip on the path
        import fcc_surgery_circuit as f
        c, info = f.build_zz_merge(L, p); m = mechanisms(c)
        w1, w2, w3, dt = search(m, 3)
        print(f"ribbon L={L}: {len(m)} mechanisms; weight-1: {len(w1)}, weight-2: {len(w2)}, weight-3 found: {w3 is not None}; weight-4 exists: {weight4_exists(m)}")
        sys.exit()
    for basis in ("Z", "X"):
        c = t.build(L, p, basis)
        m = mechanisms(c)
        print(f"== {basis} sector: {len(m)} distinct mechanisms, {c.num_detectors} detectors")
        w1, w2, w3, dt = search(m, 3)
        print(f"   weight-1 undetected logicals: {len(w1)}")
        print(f"   weight-2 undetected logicals: {len(w2)}")
        print(f"   weight-3 undetected logical found: {w3 is not None}   ({dt:.0f} s)")
        err = c.search_for_undetectable_logical_errors(
            dont_explore_detection_event_sets_with_size_above=6,
            dont_explore_edges_with_degree_above=9999,
            dont_explore_edges_increasing_symptom_degree=False, canonicalize_circuit_errors=True)
        print(f"   Stim search: undetected logical of weight {len(err)} exhibited")
