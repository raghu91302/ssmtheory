#!/usr/bin/env python3
"""THE GATE for a physics paper: does the D4 face code admit a Z (integer)
coefficient lift, so that its membrane invariant becomes SIGNED charge
(+1 vs -1) rather than mere Z2 parity?

The reviewer is right that F2 can only give Q in Z2. Signed electric
charge needs a Z or U(1) chain complex. The question: does the D4 face
code's boundary structure LIFT to Z -- i.e. can the cells be ORIENTED
consistently so that the boundary maps d2, d3 over Z satisfy d2 d3 = 0
with the SAME homology dimension (k=6) but now over Z, giving H_2(T^4;Z)=Z^6
and an INTEGER intersection pairing?

This is a real, decidable computation:
  1. orient every triangle and tetrahedron.
  2. build the boundary maps d3: C3->C2 and d2: C2->C1 over Z (signs from
     orientation).
  3. check d2 d3 = 0 over Z (not just mod 2).
  4. compute H_2 over Z = ker(d2)/im(d3): is it Z^6 (free, no torsion)?
  5. if free of rank 6, the intersection pairing H2 x H2 -> Z is integer-
     valued and SIGNED -- signed charge is available.
If instead d2 d3 != 0 over Z, or H_2 has torsion, the lift fails and the
code's physics ceiling is genuinely Z2.
"""
import numpy as np
from itertools import product, combinations

L=4
V=[v for v in product(range(L),repeat=4) if sum(v)%2==0]; Vi={v:i for i,v in enumerate(V)}
roots=[]
for i,j in combinations(range(4),2):
    for si in(1,-1):
        for sj in(1,-1):
            r=[0,0,0,0]; r[i]=si; r[j]=sj; roots.append(tuple(r))
def addv(v,d): return tuple((v[k]+d[k])%L for k in range(4))
E=set()
for v in V:
    for d in roots:
        w=addv(v,d)
        if w in Vi: E.add(frozenset((Vi[v],Vi[w])))
E=[tuple(sorted(e)) for e in E]; Ei={e:i for i,e in enumerate(E)}
adj={i:set() for i in range(len(V))}
for a,b in E: adj[a].add(b); adj[b].add(a)
F=set()
for a in range(len(V)):
    for b,c in combinations(sorted(adj[a]),2):
        if c in adj[b]: F.add(frozenset((a,b,c)))
F=[tuple(sorted(f)) for f in F]; Fi={f:i for i,f in enumerate(F)}
T=set()
for f in F:
    a,b,c=f
    for d in (adj[a]&adj[b]&adj[c]): T.add(frozenset((a,b,c,d)))
T=[tuple(sorted(t)) for t in T]; Ti={t:i for i,t in enumerate(T)}
print(f"complex {len(V)}V {len(E)}E {len(F)}F {len(T)}T")

# ORIENTED boundary maps over Z. Orient each simplex by its sorted vertex
# order; boundary sign = (-1)^position, standard simplicial boundary.
from scipy.sparse import lil_matrix
def d_map(cells_hi, idx_lo, lo_of):
    M=lil_matrix((len(idx_lo),len(cells_hi)))
    for ci,cell in enumerate(cells_hi):
        vs=sorted(cell)
        for p in range(len(vs)):
            face=tuple(vs[:p]+vs[p+1:])
            M[lo_of[face],ci]+=(-1)**p
    return M.tocsc()

# d3: tets(4 verts) -> triangles(3 verts) ; d2: triangles -> edges(2 verts)
d3=d_map(T,Fi,Fi)
d2=d_map(F,Ei,Ei)
# check d2 d3 = 0 over Z (integers)
prod=(d2@d3)
maxentry=abs(prod).max() if prod.nnz else 0
print(f"\n|| d2 d3 ||_max over Z = {maxentry}  "
      f"-> {'d2 d3 = 0 (chain complex lifts to Z)' if maxentry==0 else 'NONZERO: Z lift FAILS'}")

if maxentry==0:
    # H_2 over Q first (rank), then Smith normal form for torsion
    import numpy as np
    d2d=np.array(d2.todense()); d3d=np.array(d3.todense())
    rk2=np.linalg.matrix_rank(d2d)
    rk3=np.linalg.matrix_rank(d3d)
    betti2=(len(F)-rk2)-rk3
    print(f"rank d2={rk2}, rank d3={rk3}")
    print(f"H_2 rank over Q = (nF - rk d2) - rk d3 = {betti2}  "
          f"(expect 6)")
    print("=> if rank 6 and no torsion, H_2(T^4;Z)=Z^6, integer pairing,")
    print("   SIGNED charge available. Torsion check via Smith form next.")
else:
    print("The oriented simplicial boundary does NOT close over Z with this")
    print("orientation. Either a consistent orientation needs the DUAL")
    print("cell structure, or the lift genuinely fails. Investigating sign.")

# ---- TORSION: Smith normal form of d2 and d3 over Z ----
# H_2 = ker(d2)/im(d3). Torsion of H_2 comes from the invariant factors
# of d3 (the map whose image we quotient by) that are > 1, restricted to
# ker(d2). Standard result: torsion of H_n = coker structure; compute the
# nontrivial invariant factors of the boundary d3 landing in ker d2.
# Full Smith form of 4096x3072 is heavy; use the integer-rank + prime tests:
# H_2 is torsion-free iff d3 has all invariant factors equal to 1 up to its
# rank AND the same for d2. Equivalent practical test: the mod-p Betti
# number equals the rational Betti number for all primes p. If beta_2(F_p)
# = beta_2(Q) = 6 for several primes, there is no torsion in H_2.
import numpy as np
d2d=np.array(d2.todense()).astype(np.int64)
d3d=np.array(d3.todense()).astype(np.int64)

def rank_mod_p(M,p):
    M=M.copy()%p; M=M.astype(np.int64); rows,cols=M.shape; r=0
    for c in range(cols):
        piv=None
        for i in range(r,rows):
            if M[i,c]%p: piv=i;break
        if piv is None: continue
        M[[r,piv]]=M[[piv,r]]
        inv=pow(int(M[r,c]),p-2,p)
        M[r]=(M[r]*inv)%p
        for i in range(rows):
            if i!=r and M[i,c]%p:
                M[i]=(M[i]-M[i,c]*M[r])%p
        r+=1
        if r==rows: break
    return r

print("\nTORSION TEST: beta_2 over F_p for several primes")
print("(all equal to 6 => H_2(T^4;Z) is torsion-free = Z^6)")
betti_Q=6
ok=True
for p in (2,3,5,7,13):
    r2=rank_mod_p(d2d,p); r3=rank_mod_p(d3d,p)
    b2=(len(F)-r2)-r3
    flag='OK' if b2==betti_Q else 'TORSION!'
    if b2!=betti_Q: ok=False
    print(f"  p={p:2d}: rk d2={r2}, rk d3={r3}, beta_2={b2}  {flag}")

print("\n"+"="*60)
if ok:
    print("VERDICT: H_2(T^4;Z) = Z^6, TORSION-FREE.")
    print(" The D4 face code lifts to an INTEGER chain complex with a")
    print(" free rank-6 second homology. The intersection pairing")
    print("   H_2 x H_2 -> Z")
    print(" is integer-valued and SIGNED. Signed charge (+1 vs -1,")
    print(" electron vs positron) IS available on this lattice -- the")
    print(" Z2 ceiling was an artifact of the F2 CSS code, not the")
    print(" geometry. A physics construction can use the Z-lift.")
else:
    print("VERDICT: torsion present -- integer pairing obstructed.")
