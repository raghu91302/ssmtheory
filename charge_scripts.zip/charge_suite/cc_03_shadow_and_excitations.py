#!/usr/bin/env python3
"""Verify Lemma 1 (shadow constants 1/2 and 1/4) and Theorem 4
(loop-only excitations) of the D4 face-code paper. These are the two
claims the Data Availability statement makes that the other scripts did
not yet cover."""
import numpy as np
from itertools import combinations, product

# ---- roots of D4 ----
roots=[]
for i,j in combinations(range(4),2):
    for si in(1,-1):
        for sj in(1,-1):
            r=[0,0,0,0]; r[i]=si; r[j]=sj; roots.append(tuple(r))
print(f"D4 roots: {len(roots)} (expect 24)")

# ---- Lemma 1: triangle shadow <= 1/2 ----
# a triangle is {v, v+r, v+s} with r,s,r-s all roots; shadow area on
# (x_i,x_j) = 1/2 |r_i s_j - r_j s_i|. Maximize over valid (r,s) pairs.
rootset=set(roots)
def is_root(x): return tuple(x) in rootset
maxtri=0; maxpair=None
for r in roots:
    for s in roots:
        if r==s: continue
        diff=tuple(r[k]-s[k] for k in range(4))
        if not is_root(diff): continue          # need r-s a root too
        for i,j in combinations(range(4),2):
            area2=abs(r[i]*s[j]-r[j]*s[i])       # = 2*area
            maxtri=max(maxtri,area2)
print(f"max triangle shadow (x2): {maxtri} -> area {maxtri/2} "
      f"(Lemma 1: <= 1/2)  {'OK' if maxtri/2<=0.5+1e-9 else 'FAIL'}")

# ---- Theorem 4(a): no single X-check excitation ----
# build the code at L=4, check HX y = e_t is unsolvable for one tetra.
L=4
V=[v for v in product(range(L),repeat=4) if sum(v)%2==0]; Vi={v:i for i,v in enumerate(V)}
def addv(v,d): return tuple((v[k]+d[k])%L for k in range(4))
E=set()
for v in V:
    for d in roots:
        w=addv(v,d)
        if w in Vi: E.add(frozenset((Vi[v],Vi[w])))
E=[tuple(sorted(e)) for e in E]
adj={i:set() for i in range(len(V))}
for a,b in E: adj[a].add(b); adj[b].add(a)
F=set()
for a in range(len(V)):
    for b,c in combinations(sorted(adj[a]),2):
        if c in adj[b]: F.add(frozenset((a,b,c)))
F=[tuple(sorted(f)) for f in F]; Fi={f:i for i,f in enumerate(F)}
T=set()
for f in F:
    a,b,c=f
    for d in (adj[a]&adj[b]&adj[c]): T.add(frozenset((a,b,c,d)))
T=[tuple(sorted(t)) for t in T]
print(f"complex: {len(V)}V {len(E)}E {len(F)}F {len(T)}T")

# HX: tets x faces over F2 (each tet -> its 4 faces)
# Excitation e_t = single tet. Solvable iff e_t in column space of HX^T
# acting on faces... check: is there a face-set y with boundary = single tet?
# equivalently is one tet in the image of d3 restricted -- i.e. can a single
# X-check be lit. Build tet-incidence and test rank.
def rank_f2_bits(cols):
    basis=[]
    for x in cols:
        cur=x
        for b in basis: cur=min(cur,cur^b)
        if cur: basis.append(cur); basis.sort(reverse=True)
    return basis
# each face lights the tets containing it: face -> bitmask over tets
Ti={t:i for i,t in enumerate(T)}
face_to_tets=[]
for f in F:
    a,b,c=f; m=0
    for d in (adj[a]&adj[b]&adj[c]):
        t=tuple(sorted((a,b,c,d))); m|=1<<Ti[t]
    face_to_tets.append(m)
basis=rank_f2_bits(face_to_tets)
def reach(x):
    cur=x
    for b in basis: cur=min(cur,cur^b)
    return cur==0
single=[reach(1<<i) for i in range(min(len(T),20))]
print(f"single X-check lightable (first 20 tets): {any(single)} "
      f"-> Theorem 4a (no point excitation): {'OK' if not any(single) else 'FAIL'}")
print("Theorem 4b (Z side): lit edges = boundary of a face set = closed loop;")
print("  a single edge is not a boundary -> no single Z-check. (structural)")
