# Verification suite — D4 face code and electric charge

Python scripts reproducing every computational claim in the paper
*"A Four-Dimensional Toric Code on the D4 Lattice with Weight-4 Checks
and Distance 2L², and Electric Charge as the Linking of Its Membranes."*

Run everything:

    python run_all.py

Requires only `numpy` and `scipy`. Runs in a few minutes on a laptop.

## Load-bearing scripts (the paper's results)

| script | verifies | paper |
|--------|----------|-------|
| `cc_01_build_and_verify_code.py` | rebuilds the D4 face code from incidence; n=4096, rk(H_Z)=1405, rk(H_X)=2685, k=6=b₂(T⁴) | Theorem 1 |
| `cc_02_electron_membrane.py` | constructs the electron logical membrane; charge = intersection number, representative-independent (weight 278→282, unchanged) | §10 |
| `cc_03_shadow_and_excitations.py` | triangle shadow ≤ 1/2; no single-check (point) excitations | Lemma 1, Theorem 4 |
| `cc_04_coulomb_green.py` | FCC lattice Green function is 1/r (Coulomb) in form | §12 |
| `cc_05_coulomb_coefficient.py` | c=4 exact from the FCC structure tensor; geometric coefficient (NOT α) | §12, §13 |
| `cc_06_photon_dispersion.py` | two transverse polarizations, longitudinal pinned, linear isotropic dispersion | §12 |
| `cc_07_fractional_charge.py` | −1/3 forced by C₃ symmetry + neutrality; thirds from dimension | §9 |
| `cc_08_linking_quantization.py` | charge = codim-2 linking; quantized, loop-independent | §8 |

## `dead_ends/`

Scripts recording constructions that were tried and **failed**, kept for
honesty and to save others the detours: the strain-as-connection attempt
(carries continuous, not quantized, curvature), the point-electron
worldsheet (charge depends on arbitrary sheet choice), the fusion attempt
(the −1/3 is a geometric projection, not a linking fraction), and the
finite-box Coulomb solve (boundary artifacts — superseded by the Fourier
Green function in `cc_04`). Each script's header explains what went wrong.

## Notes on what is and is not established

The code half (`cc_01`, `cc_03`) is proved. The charge half is honest
about its limits: the electron charge is computed mod 2 (`cc_02`); the
fractional −1/3 is geometric, not topological (`cc_07`, and see
`dead_ends/38_fusion.py`); and the coupling coefficient is geometric but
is **not** the physical fine-structure constant (`cc_05`). See the
paper's "What is and is not shown" section.
