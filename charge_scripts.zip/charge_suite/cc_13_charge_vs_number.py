#!/usr/bin/env python3
"""The decisive question the reviewer forces: is there a channel that
gives DIFFERENT integers to different worldlines (electric charge), or
does the lattice only supply the 'count all worldlines' pairing
(particle number)?

Particle number = intersection of a worldline with the FUNDAMENTAL class
of a Cauchy 3-surface: every once-through-time worldline gives +1. That
is what cc_10 actually computed. Electric charge must instead be the
pairing of the worldline with a DIFFERENT, distinguished cohomology
class -- one that some worldlines see (charged) and others do not
(neutral).

H_1(T^4;Z) = Z^4: four worldline classes (three space + one time).
H^1(T^4;Z) = Z^4 dually: four 'charge-like' functionals a worldline can
be paired against. Particle number is ONE of them (the time functional).
The question: do the OTHER independent functionals give an assignment
that (a) is not just particle number, (b) can make some worldlines
neutral and others charged?

We test what structure is actually available:
  1. enumerate the worldline classes (H_1 generators).
  2. enumerate the independent linear functionals on them (H^1).
  3. ask: is there a functional under which the time-winding worldlines
     split into different values -- i.e. a real charge, not just number?
  4. HONEST CHECK: show that with NO further input, every functional is
     either 'count time-windings' (number) or 'count a spatial winding'
     (momentum), and NONE of them singles out an electric charge. This
     makes explicit what extra structure a charge would REQUIRE.
"""
import numpy as np

# H_1(T^4;Z) = Z^4, basis = windings along x1,x2,x3,x4(time)
# a worldline class is a vector n in Z^4.
# H^1(T^4;Z) = Z^4, basis = dual functionals f. Pairing f.n in Z.
# particle number = f_time = (0,0,0,1) . n = n_4.

worldlines={
 'electron at rest':   np.array([0,0,0,1]),
 'neutron at rest':    np.array([0,0,0,1]),
 'neutrino at rest':   np.array([0,0,0,1]),
 'up quark at rest':   np.array([0,0,0,1]),
 'positron at rest':   np.array([0,0,0,-1]),
 'moving electron':    np.array([1,0,0,1]),
}
print("Under the particle-NUMBER functional f=(0,0,0,1) [= Cauchy-surface")
print("intersection, what cc_10 computed]:")
for name,n in worldlines.items():
    print(f"  {name:20s} -> {int(np.array([0,0,0,1])@n):+d}")
print("\n=> electron, neutron, neutrino, up quark ALL give +1.")
print("   This is particle number, NOT electric charge. Reviewer is right.\n")

# Is there ANY functional in H^1 that separates them?
print("The four independent functionals on H_1(T^4;Z):")
for i,axis in enumerate(['x1','x2','x3','time']):
    f=np.eye(4,dtype=int)[i]
    vals=[int(f@n) for n in worldlines.values()]
    print(f"  f={axis:5s}: {vals}")
print("""
None of the four topological functionals distinguishes electron from
neutron from neutrino: they all have the same H_1 class (0,0,0,1). The
lattice's homology CANNOT, by itself, assign them different charges,
because they are the SAME worldline class topologically.

CONCLUSION (honest, and it is a real limitation):
 Electric charge is NOT a property of the worldline's homology class.
 Two particles with identical worldline topology (electron, neutron)
 must differ by some NON-topological internal label -- a coupling to a
 distinguished U(1) connection that is EXTRA data, not read off H_1.
 The integer lift (cc_09) makes signed INTEGER pairings available, and
 Gauss's law (cc_12) holds, but WHICH integer a given particle carries
 is not fixed by the code's topology. Charge requires specifying the
 U(1) bundle the worldline couples to -- exactly the 'distinguished
 cohomology class' that the D4 code does not, on its own, single out.

This converts the claim from 'the code derives electric charge' to the
correct, weaker statement: 'the code supplies the integer/Gauss-law
machinery in which a charge assignment CAN live, but the assignment
itself needs additional physical input (the U(1) coupling), which this
construction does not derive.'
""")
