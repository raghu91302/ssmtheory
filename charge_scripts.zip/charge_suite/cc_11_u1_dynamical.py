#!/usr/bin/env python3
"""The dynamical step: put a real U(1) gauge field on the Z-lift and show
the Gauss-surface flux is SOURCED by a worldline -- i.e. derive the
lattice Gauss law  (div E)(x) = rho(x)  with rho the worldline, not assert
the homology pairing.

Setup (lattice Maxwell electrostatics on FCC, the spatial slice):
  - gauge field A on edges, electric field E on edges (E = conjugate).
  - Gauss constraint at each vertex: sum_{edges at v} E = rho(v).
  - a static electron = a unit source rho = delta at one vertex (the
    worldline pierces the slice at that point).
  - solve for E, then MEASURE the flux of E through a closed surface
    (the Gauss surface) around the source.
The dynamical content: E is sourced by the DISCRETE curl/div operators of
the actual lattice, and the flux through ANY enclosing surface must equal
the enclosed charge -- Gauss's law as a THEOREM of the construction, not
an assumed pairing. Test:
  1. build the vertex-edge incidence (the div operator) on FCC.
  2. put rho = +1 at origin, -1/N background (neutralizing).
  3. solve div E = rho for E (least action, E = grad phi).
  4. flux of E through nested surfaces of increasing radius = enclosed
     charge = +1 for ALL of them (Gauss's law), independent of radius.
  5. two sources +1,-1: flux around each returns its own sign.
"""
import numpy as np
from itertools import product, combinations
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import cg

# FCC slice
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
    (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
R=6
V=[p for p in product(range(-R,R+1),repeat=3) if sum(p)%2==0]
Vi={p:i for i,p in enumerate(V)}; N=len(V)
# oriented edges
E=[]
for p in V:
    for d in NN:
        q=tuple(p[k]+d[k] for k in range(3))
        if q in Vi and Vi[p]<Vi[q]: E.append((Vi[p],Vi[q]))
print(f"FCC slice: {N} vertices, {len(E)} edges")

# div operator: d0^T, maps edge-field -> vertex divergence
# incidence matrix B (V x E): +1 at head, -1 at tail
B=lil_matrix((N,len(E)))
for ei,(a,b) in enumerate(E):
    B[a,ei]=-1; B[b,ei]=+1
B=csr_matrix(B)
# Laplacian = B B^T ; solve (B B^T) phi = rho, then E = B^T phi, div E = rho
Lap=B@B.T

def solve_E(rho):
    rho=rho-rho.mean()
    phi,_=cg(Lap,rho,rtol=1e-11,maxiter=20000)
    Efield=B.T@phi
    return Efield

# electron = unit source at origin
rho=np.zeros(N); rho[Vi[(0,0,0)]]=1.0
Ef=solve_E(rho)

# GAUSS LAW test: flux of E through a closed surface = sum of E on edges
# crossing the surface (from inside to outside), for nested spheres.
def gauss_flux(Ef, radius):
    """net outward flux = sum over edges crossing the sphere of E, signed
    by crossing direction."""
    def inside(vi): return np.linalg.norm(V[vi])<radius
    tot=0.0
    for ei,(a,b) in enumerate(E):
        ia,ib=inside(a),inside(b)
        if ia and not ib: tot+=Ef[ei]     # edge exits (tail in, head out)
        elif ib and not ia: tot-=Ef[ei]    # edge enters -> outward = -E
    return tot

print("\nGauss's law: outward flux of E through nested spheres")
print("(should equal enclosed charge = +1 for every radius):")
print(f"{'radius':>8}{'flux':>12}")
for rad in (1.5,2.5,3.5,4.5,5.5):
    print(f"{rad:8.1f}{gauss_flux(Ef,rad):12.5f}")

# two opposite charges: flux around each returns its sign
rho2=np.zeros(N); rho2[Vi[(0,0,0)]]=1.0; rho2[Vi[(4,0,0)]]=-1.0
Ef2=solve_E(rho2)
def flux_around(Ef,center,radius):
    def inside(vi): return np.linalg.norm(np.array(V[vi])-np.array(center))<radius
    tot=0.0
    for ei,(a,b) in enumerate(E):
        ia,ib=inside(a),inside(b)
        if ia and not ib: tot+=Ef[ei]
        elif ib and not ia: tot-=Ef[ei]
    return tot
print("\nTwo charges (+1 at origin, -1 at (4,0,0)); local Gauss surfaces:")
print(f"  flux around +1 source: {flux_around(Ef2,(0,0,0),1.5):+.4f} (expect +1)")
print(f"  flux around -1 source: {flux_around(Ef2,(4,0,0),1.5):+.4f} (expect -1)")

print("""
=== VERDICT ===
If the flux equals the enclosed charge for every radius (independent of
the surface), Gauss's law holds as a THEOREM of the lattice construction:
the electric field is sourced by the charge, the flux through any closed
surface counts the enclosed charge, sign included. This is the dynamical
content the kinematic pairing (cc_10) lacked: E is a real field solved
from div E = rho, not an assumed homology number. Combined with cc_09
(Z-lift exists) and cc_10 (electron=worldline, signed charge), this is a
genuine lattice electrostatics with signed, integer, Gauss-law charge.

STILL OPEN: the full 4D covariant Maxwell (magnetic sector coupled),
and the coupling constant / alpha (cc_05: geometric, not physical alpha).
""")
