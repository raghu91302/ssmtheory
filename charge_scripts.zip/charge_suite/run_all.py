#!/usr/bin/env python3
"""Master runner for the charge-paper verification suite.
Runs the eight load-bearing scripts in order and reports pass/fail.
Reproduces every claim in the paper's Data Availability statement."""
import subprocess, sys, glob, time
scripts=sorted(glob.glob("cc_0*.py"))
print("="*64)
print("D4 face code + charge paper -- verification suite")
print("="*64)
t0=time.time()
fails=[]
for s in scripts:
    print(f"\n----- {s} -----")
    r=subprocess.run([sys.executable,s],capture_output=True,text=True,timeout=1200)
    out=r.stdout.strip()
    print(out[-1500:] if len(out)>1500 else out)
    if r.returncode!=0 or "FAIL" in out:
        fails.append(s); print(f"  !! {s} reported a problem")
print("\n"+"="*64)
print(f"done in {time.time()-t0:.0f}s.  "
      f"{'ALL PASS' if not fails else 'PROBLEMS: '+', '.join(fails)}")
print("="*64)
