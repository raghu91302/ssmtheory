#!/usr/bin/env python3
"""COMPUTE 4/4: is there a magnetic sector -- a propagating photon -- or
only static Coulomb?

Electromagnetism needs more than a 1/r potential: it needs a transverse
propagating mode (the photon) with a linear dispersion omega = c|k|. The
static Coulomb we found is just the longitudinal/scalar sector. Test
whether the FCC lattice supports a transverse vector mode with linear
dispersion -- i.e. whether a genuine dynamical photon lives here.

We build the lattice curl-curl operator (the discrete Maxwell wave
operator on edge variables) and ask for its dispersion: does it have a
branch omega ~ |k| (photon) and are there transverse polarizations?
"""
import numpy as np
NN=np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),
    (-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)],float)

# On a lattice, a vector field A_mu(k) has wave operator from the
# Maxwell action ~ (curl A)^2. In Fourier space the curl-curl operator is
# M(k)_ij = |k~|^2 delta_ij - k~_i k~_j  (continuum), where k~ is the
# lattice momentum k~_a = sum over bonds ... For a cubic-symmetric lattice
# at small k, k~ -> k and we recover the photon. The test: does the
# lattice vector Laplacian have (a) a gapless branch, (b) linear
# dispersion, (c) two transverse polarizations?
def latt_k(k):
    """lattice 'sin-momentum' vector from the FCC bond structure"""
    # k~_a = sum_delta delta_a sin(k.delta) / normalization
    s=np.array([sum(d[a]*np.sin(k@d) for d in NN) for a in range(3)])
    return s

def dispersion(k):
    kt=latt_k(k)
    k2=kt@kt
    # curl-curl eigenvalues: longitudinal (0) + 2 transverse (k2)
    # build M = k2 I - outer(kt,kt)
    M=k2*np.eye(3)-np.outer(kt,kt)
    w=np.sort(np.linalg.eigvalsh(M))
    return w, kt

print("Vector (photon) dispersion on FCC:")
print(f"{'|k|':>8} {'long':>10} {'trans1':>10} {'trans2':>10}")
for eps in (0.05,0.1,0.2,0.4):
    k=np.array([eps,0,0])
    w,kt=dispersion(k)
    print(f"{eps:8.2f} {w[0]:10.5f} {w[1]:10.5f} {w[2]:10.5f}")

# check linear dispersion: sqrt(transverse eigenvalue) ~ |k| ?
print("\nlinear dispersion check: sqrt(transverse)/|k| (const => photon):")
for eps in (0.4,0.2,0.1,0.05,0.025):
    k=np.array([eps,0,0]); w,_=dispersion(k)
    trans=w[2]
    print(f" |k|={eps:.3f}: sqrt(w_T)/|k| = {np.sqrt(trans)/eps:.4f}")

print("\nisotropy of photon speed (x vs 111):")
for kdir,name in (((1,0,0),'x'),((1,1,1),'111')):
    k=0.1*np.array(kdir,float)/np.linalg.norm(kdir)
    w,_=dispersion(k); print(f" {name}: v = sqrt(w_T)/|k| = {np.sqrt(w[2])/0.1:.4f}")

print("""
Reading. If there are exactly 2 gapless transverse branches with
sqrt(w_T) ~ |k| (constant ratio) and 1 longitudinal branch pinned at 0,
the FCC lattice supports a genuine photon: 2 transverse polarizations,
linear dispersion, a propagating EM wave. Isotropic speed => Lorentz-
compatible at long wavelength.
""")
