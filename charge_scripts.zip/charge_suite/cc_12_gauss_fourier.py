#!/usr/bin/env python3
"""Clean Gauss's law: Fourier space, no box, no jellium. Show the flux of
E through a closed surface equals the enclosed charge EXACTLY and
independent of the surface -- the radius-independence cc_11 could not show
because of the neutralizing background.

The clean statement is exact and needs no solve. On an infinite lattice
the electrostatic field of a point source rho = delta_0 is
    E = grad G,   Lap G = -delta_0,   G(x) = (1/V_BZ) int e^{ik.x}/D(k) d^3k
The outward flux through any closed surface S enclosing the origin is,
by the discrete divergence theorem,
    Phi(S) = sum_{v inside S} (div E)(v) = sum_{v inside S} (-Lap G)(v)
           = sum_{v inside S} delta_0(v) = 1,
for EVERY S enclosing the origin, and 0 for every S not enclosing it.
This is Gauss's law as an identity. The point cc_11 got wrong was adding a
background; on the infinite lattice there is none, and the divergence
theorem is exact.

We VERIFY this directly: build G by Fourier quadrature (no box, no
background), form E = grad G on edges, and check the discrete divergence
(div E)(v) = -delta_0(v) at every vertex -- if div E is a clean delta at
the origin and zero elsewhere, Gauss's law holds exactly by summation.
"""
import numpy as np
from itertools import product

NN=np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),
    (-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)],float)

def D(k): return np.sum(1.0-np.cos(k@NN.T),axis=-1)

# Green function on a set of FCC points by BZ quadrature
def G_points(points, ng=48):
    ks=(np.arange(ng)+0.5)/ng*2*np.pi-np.pi
    KX,KY,KZ=np.meshgrid(ks,ks,ks,indexing='ij')
    K=np.stack([KX.ravel(),KY.ravel(),KZ.ravel()],1)
    d=D(K); m=d>1e-9; Km=K[m]; dm=d[m]
    out={}
    for p in points:
        out[p]=np.mean(np.cos(Km@np.array(p,float))/dm)*(m.sum()/len(K))
    return out

# vertices in a small ball + their neighbours (need G on x and x+delta)
R=4
Vball=[p for p in product(range(-R,R+1),repeat=3) if sum(p)%2==0]
need=set(Vball)
for p in Vball:
    for d in NN.astype(int):
        need.add(tuple(p+d))
Gv=G_points(list(need),ng=56)

# div E at a vertex v: E on edge (v,w) = G(w)-G(v) (E=grad G, discrete).
# div E (v) = sum_w [E(v->w)] with outward sign = sum_w (G(w)-G(v))
#           = (sum_w G(w)) - 12 G(v)  = -(Lap G)(v)
# Gauss: this should be -delta_0  -> = -1 at origin, 0 elsewhere (up to
# the overall normalization of G; we report the RATIO to the origin value).
def divE(v):
    s=sum(Gv[tuple(np.array(v)+d)] for d in NN.astype(int))
    return s-12*Gv[v]

d0=divE((0,0,0))
print("discrete (div E)(v) = -(Lap G)(v), normalized to origin = -1:")
print(f"{'vertex':<16}{'div E / |div E(0)|':>20}")
for v in [(0,0,0),(1,1,0),(2,0,0),(2,2,0),(4,0,0),(3,1,0)]:
    print(f"{str(v):<16}{divE(v)/abs(d0):>20.5f}")

# Gauss's law by summation: total enclosed div over a ball = flux through
# its surface. Sum div E over all vertices strictly inside radius r.
print("\nGauss's law: enclosed sum of (div E) vs radius (normalized):")
print(f"{'radius':>8}{'enclosed / origin':>20}")
for r in (1.5,2.5,3.5,4.5):
    tot=sum(divE(v) for v in Vball if np.linalg.norm(v)<r)
    print(f"{r:8.1f}{tot/d0:20.5f}")
print("""
Reading: if (div E) is a clean spike at the origin (=-1 there, ~0
elsewhere) and the enclosed sum is CONSTANT = 1 for every radius that
contains the origin, Gauss's law holds exactly, independent of the
surface -- no background, no leak. This is the radius-independence cc_11
failed to show, now clean because there is no jellium on the infinite
lattice. Signed charge (cc_10) + this = lattice electrostatics obeying
Gauss's law with signed integer sources.
""")
