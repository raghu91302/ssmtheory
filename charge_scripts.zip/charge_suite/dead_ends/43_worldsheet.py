#!/usr/bin/env python3
"""COMPUTE 3/4: is the electron's charge sheet DERIVED, or did I pick it?

In script 36 I chose the z-t plane by hand. The honest question: does the
framework FORCE the electron's charge locus to be a specific 2D sheet?

The claim to test: the electron is the minimal point defect; its only
distinguished directions are (i) time (its worldline) and (ii) ... what?
A point in space has NO distinguished spatial direction -- it is
spherically symmetric. So a 2D sheet = time x (a spatial direction)
requires SELECTING a spatial direction, which the isotropic electron
does not have. This is a REAL problem for the construction.

Test it directly: compute the linking of the electron worldline with a
loop, for sheets built on DIFFERENT spatial directions, and check
whether the charge depends on the choice (bad -- not derived) or not
(good -- the choice is gauge).
"""
import numpy as np
def link(loop, nb):
    n1,n2=[np.array(v,float) for v in nb]
    P=[np.array(p,float) for p in loop]; tot=0
    for i in range(len(P)-1):
        a=np.array([P[i]@n1,P[i]@n2]); b=np.array([P[i+1]@n1,P[i+1]@n2])
        if np.linalg.norm(a)<1e-9 or np.linalg.norm(b)<1e-9: continue
        tot+=np.arctan2(a[0]*b[1]-a[1]*b[0],a@b)
    return tot/(2*np.pi)

# electron worldline = t-axis. Candidate charge sheets: t x xhat, t x yhat,
# t x (diagonal). Normal plane to each sheet, and a spatial measurement
# loop. If the linking is the SAME (=1) for every sheet choice, the choice
# is immaterial (gauge) and charge is well-defined. If it differs, the
# construction is ill-defined.
spatial_loop=[(2,0,0,0),(0,2,0,0),(-2,0,0,0),(0,-2,0,0),(2,0,0,0)]
sheets={
 't x xhat (normal y-z... no, normal=x,y? )':((1,0,0,0),(0,1,0,0)),
 't x yhat':((0,1,0,0),(1,0,0,0)),
 't x diagonal':((1,1,0,0),(0,0,1,0)),
}
print("Electron charge for different sheet choices (spatial loop):")
for name,nb in sheets.items():
    # orthonormalize
    n1=np.array(nb[0],float); n1/=np.linalg.norm(n1)
    n2=np.array(nb[1],float); n2=n2-(n2@n1)*n1; n2/=np.linalg.norm(n2)
    print(f"  {name:28s}: linking = {link(spatial_loop,(n1,n2)):+.3f}")

print("""
Reading. The spatial measurement loop lies in the x-y plane. Its linking
depends on which 2-plane we project onto (the sheet's normal). This is
exactly the problem: the electron, being spatially isotropic, does not
select a sheet, so the 'charge sheet' is NOT derived -- it is a choice.

HONEST CONCLUSION: the electron worldsheet construction of script 36 does
NOT derive the sheet; it assumes one. The proton's charge (spatial anchor
line) IS well-defined because the anchor bond is a genuine distinguished
direction. The electron's is not. So the codim-2 linking mechanism is
solid for the ANCHOR-SELECTED (charged, structured) defects, and
incomplete for the point electron. This must be stated as a limitation,
not hidden.
""")
