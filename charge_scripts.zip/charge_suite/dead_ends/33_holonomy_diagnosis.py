#!/usr/bin/env python3
"""Diagnose script 32: is 'strain = connection' curl-free in principle?

A length-deviation 1-form theta_e = |x_a - x_b| - L, to LINEAR order in
displacements u, is:
    theta_e ~ u_ab . nhat_ab      (nhat = unit bond direction)
which is exactly a DISCRETE GRADIENT of nothing -- it is the symmetric
strain projected on the bond. The question is whether this 1-form is
exact (theta = grad phi => zero holonomy always) or has genuine curl.

Key fact: theta_e = f(a) - f(b) for some node function f  <=>  theta is
exact <=> zero holonomy. For a RADIAL displacement u(x)=g(|x|) xhat,
theta_e is NOT generally exact, but its curl comes from the
NONLINEARITY, which is a lattice artifact, not a topological charge.

This script separates the two cleanly:
  (1) LINEAR strain 1-form  theta = u_ab . nhat   -> check exactness
  (2) full nonlinear length deviation             -> check curl
If (1) is exact (curl 0) and (2) is not, the 'holonomy' in script 32
is pure nonlinear lattice noise, NOT a charge. That is the honest
negative result.
"""
import numpy as np
from itertools import product, combinations
L=np.sqrt(2.0)
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
    (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
pts=set(p for p in product(range(-3,4),repeat=3) if sum(p)%2==0)
def nbrs(v): return [tuple(v[i]+d[i] for i in range(3)) for d in NN
                     if tuple(v[i]+d[i] for i in range(3)) in pts]
def plaq():
    seen=set(); out=[]
    for a in pts:
        for b,c in combinations(nbrs(a),2):
            for x in (set(nbrs(b))&set(nbrs(c))):
                if x!=a and frozenset([a,b,x,c]) not in seen:
                    seen.add(frozenset([a,b,x,c])); out.append((a,b,x,c))
    return out
PL=plaq()

def radial_u(scale=0.1):
    u={}
    for v in pts:
        r=np.linalg.norm(v)
        u[v]=np.zeros(3) if r<1e-9 else -scale*np.array(v,float)/r*np.exp(-r)
    return u

u=radial_u()
# (1) linear strain 1-form
def theta_lin(a,b):
    n=np.array(b,float)-np.array(a,float); n/=np.linalg.norm(n)
    return (u[b]-u[a])@n
# (2) nonlinear
def theta_nl(a,b):
    return np.linalg.norm((np.array(b,float)+u[b])-(np.array(a,float)+u[a]))-L

for name,fn in (("LINEAR strain (u.nhat)",theta_lin),
                ("NONLINEAR length dev",theta_nl)):
    worst=0.0
    for (a,b,x,c) in PL:
        loop=[(a,b),(b,x),(x,c),(c,a)]
        f=sum(fn(*e) for e in loop)
        worst=max(worst,abs(f))
    print(f"{name:26s}: max |curl| = {worst:.2e}  "
          f"({'EXACT (curl-free)' if worst<1e-9 else 'has curl'})")

print("\nConclusion:")
print(" If linear=exact and nonlinear=has-curl, script 32's 'holonomy'")
print(" was nonlinear lattice noise, scaling with displacement^2, not a")
print(" topological charge. The strain 1-form does NOT carry the winding.")
print(" Charge, if it exists here, is NOT the strain connection.")

# scaling test: halve displacement, curl should drop 4x if it's nonlinear noise
def maxcurl(scale):
    global u; u=radial_u(scale)
    w=0.0
    for (a,b,x,c) in PL:
        w=max(w,abs(sum(theta_nl(*e) for e in [(a,b),(b,x),(x,c),(c,a)])))
    return w
c1=maxcurl(0.10); c2=maxcurl(0.05)
print(f"\n scaling check: curl(0.10)={c1:.2e}, curl(0.05)={c2:.2e}, "
      f"ratio={c1/c2:.2f} (4.0 => pure quadratic noise)")
