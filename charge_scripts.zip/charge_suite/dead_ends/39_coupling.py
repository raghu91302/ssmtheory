#!/usr/bin/env python3
"""THE GATE: do two topological charges attract/repel by 1/r?

Linking number = charge QUANTUM. This tests whether it is charge's
FORCE. We put an actual U(1) gauge connection on the lattice, source it
with the defects' codim-2 loci (the objects that carry the linking),
solve discrete Maxwell, and measure the interaction energy vs
separation. Pass = energy ~ q1*q2/r (Coulomb). Fail = no 1/r, and then
the framework does NOT give electromagnetism.

MODEL (honest discrete electrostatics, nothing about charge assumed):
  - Scalar potential phi on FCC sites (we test the electrostatic limit;
    a full gauge field is not needed to see whether the coupling is
    Coulombic -- the static sector is exactly the scalar Laplacian).
  - Discrete Poisson: (lattice Laplacian phi)(x) = -rho(x), rho sourced
    at the defect sites with strength = their topological charge.
  - Two defects charge q1,q2 at separation r. Interaction energy
    U(r) = q1 * phi_2(x1)  (potential of defect 2 at defect 1).
  - Measure U(r) vs r. Coulomb <=> U ~ q1 q2 / r in 3D.

We do NOT insert 1/r. The lattice Green function of the discrete
Laplacian gives whatever it gives; the TEST is whether it is 1/r at
large separation (it must be, for a local lattice Laplacian in 3D --
and THAT is the point: if the framework's charge sources the ordinary
lattice Laplacian, EM follows; the real question is whether the
topological charge is what sources it, with the right sign structure).
"""
import numpy as np
from itertools import product
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import cg

NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
    (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
RNG=10
sites=[p for p in product(range(-RNG,RNG+1),repeat=3) if sum(p)%2==0]
idx={p:i for i,p in enumerate(sites)}
N=len(sites)
print(f"lattice sites: {N}")

# discrete FCC Laplacian
Lap=lil_matrix((N,N))
for p in sites:
    i=idx[p]; deg=0
    for d in NN:
        q=tuple(p[k]+d[k] for k in range(3))
        if q in idx:
            Lap[i,idx[q]]=-1; deg+=1
    Lap[i,i]=deg
Lap=csr_matrix(Lap)

def potential(source_site, charge):
    rho=np.zeros(N); rho[idx[source_site]]=charge
    # solve Lap phi = rho with a uniform neutralizing background
    rho=rho-rho.mean()
    phi,info=cg(Lap,rho,rtol=1e-10,maxiter=5000)
    return phi

# potential of a unit charge at origin, sampled along a lattice ray
phi=potential((0,0,0),1.0)
print("\nPotential of unit charge vs distance (test for 1/r):")
print(f"{'r':>6} {'phi(r)':>12} {'phi*r':>12}")
ray=[(2,2,0),(4,4,0),(6,6,0),(8,8,0),(10,10,0)]
vals=[]
for p in ray:
    r=np.sqrt(sum(c*c for c in p))
    val=phi[idx[p]]
    vals.append((r,val))
    print(f"{r:6.2f} {val:12.6f} {val*r:12.6f}")

# fit phi ~ A/r + C : check phi*r -> const
rs=np.array([v[0] for v in vals]); ph=np.array([v[1] for v in vals])
# linear fit of phi vs 1/r
A=np.polyfit(1/rs,ph,1)
print(f"\nfit phi = {A[0]:.4f}*(1/r) + {A[1]:.4f}")
print(f"  => {'1/r Coulomb CONFIRMED' if abs(A[0])>0.1 else 'NOT 1/r'}"
      f" (slope = coefficient of 1/r)")

# --- interaction energy of two charges vs separation ---
print("\nInteraction energy U(r) of two unit charges (expect ~1/r):")
print(f"{'r':>6} {'U(r)':>12} {'U*r':>12}")
for sep in [(2,2,0),(4,4,0),(6,6,0),(8,8,0)]:
    r=np.sqrt(sum(c*c for c in sep))
    U=phi[idx[sep]]      # potential of charge@origin at the other site
    print(f"{r:6.2f} {U:12.6f} {U*r:12.6f}")

print("\n=== VERDICT ===")
print("If phi*r -> constant and U*r -> constant, the topological charge")
print("sources a Coulomb 1/r interaction: the linking number IS electric")
print("charge, not merely a quantum number. If flat fails, EM does not")
print("follow and the charge claim stays incomplete.")

# sign test: opposite charges attract?
print("\nsign/superposition check (q=+1 at origin, probe charge sign):")
print(" U>0 for like charges (repulsive), U<0 for opposite -> add a -1.")
phi_neg=potential((0,0,0),-1.0)
print(f" potential of -1 charge at (4,4,0): {phi_neg[idx[(4,4,0)]]:.6f}"
      f" (should be -1x the +1 case {phi[idx[(4,4,0)]]:.6f})")
