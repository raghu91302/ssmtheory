#!/usr/bin/env python3
"""Electron charge = linking of a LOOP with a 2D SHEET in R^4 (codim 2).

Corrected topology (script 35 wrongly tried to link a 1D worldline in
R^4, which is codim 3 -> unlinkable). In R^4 the linkable object is a
2-SHEET: R^4 minus a 2-plane has pi_1 = Z, exactly like R^3 minus a
line. A loop links the sheet = winding of the loop's projection onto
the 2-plane NORMAL to the sheet.

Setup:
  sheet = the electron's charge sheet. The electron is a point at rest;
  its worldline is the t-axis. The minimal charge-bearing sheet
  containing that worldline, in the D4 picture, is a worldSHEET in the
  H_2 sector: the t-axis times ONE spatial direction swept by the
  defect's internal structure. Take sheet = {(0,0,s,u)} spanned by the
  z and t axes (a 2-plane through the origin). Its normal 2-plane is
  the x-y plane.
  A loop links this sheet <=> its projection onto the x-y plane winds
  around the origin.

VALIDATION FIRST (known answers), THEN the electron.
"""
import numpy as np

def link_loop_sheet(loop, sheet_normal_basis):
    """linking number of a closed loop with a 2-plane through origin in
    R^4, given an orthonormal basis (n1,n2) of the plane NORMAL to the
    sheet. = winding of the loop's (n1,n2)-projection around origin."""
    n1,n2=[np.array(v,float) for v in sheet_normal_basis]
    P=[np.array(p,float) for p in loop]
    tot=0.0
    for i in range(len(P)-1):
        a=np.array([P[i]@n1,P[i]@n2]); b=np.array([P[i+1]@n1,P[i+1]@n2])
        na,nb=np.linalg.norm(a),np.linalg.norm(b)
        if na<1e-9 or nb<1e-9: continue
        cross=a[0]*b[1]-a[1]*b[0]; dot=a@b
        tot+=np.arctan2(cross,dot)
    return tot/(2*np.pi)

# sheet spanned by z,t axes => normal plane spanned by x,y axes
xhat=(1,0,0,0); yhat=(0,1,0,0)
NB=(xhat,yhat)

print("=== VALIDATION (known answers) ===")
# 1) loop winding once around origin in x-y plane -> links (=1)
loop_link=[(2,0,0,0),(0,2,0,0),(-2,0,0,0),(0,-2,0,0),(2,0,0,0)]
# 2) loop in z-t plane (lies IN the sheet direction) -> misses (=0)
loop_in_sheet=[(0,0,2,0),(0,0,0,2),(0,0,-2,0),(0,0,0,-2),(0,0,2,0)]
# 3) loop off to the side in x-y, not around origin -> 0
loop_miss=[(4,0,0,0),(6,2,0,0),(8,0,0,0),(6,-2,0,0),(4,0,0,0)]
# 4) loop winding twice -> 2
import math
loop_twice=[(2*math.cos(2*math.pi*k/16*2),2*math.sin(2*math.pi*k/16*2),0,0)
            for k in range(17)]
for name,lp in (("winds once (x-y)",loop_link),
                ("lies in sheet (z-t)",loop_in_sheet),
                ("off to side",loop_miss),
                ("winds twice",loop_twice)):
    print(f"  {name:22s}: linking = {link_loop_sheet(lp,NB):+.3f}")

print("\n=== ELECTRON ===")
# electron charge sheet = z-t plane (worldline t swept with one internal
# spatial direction z). A physical 'measurement loop' encircles the
# electron in space AND time: a loop in the x-y plane (pure space) at
# fixed t encircles the worldline's spatial position.
# Does it link the z-t sheet? Its projection onto x-y (the normal plane)
# winds once -> yes.
electron_loops={
 'spatial ring around e':[(2,0,0,0),(0,2,0,0),(-2,0,0,0),(0,-2,0,0),(2,0,0,0)],
 'larger spatial ring'  :[(4,0,0,0),(0,4,0,0),(-4,0,0,0),(0,-4,0,0),(4,0,0,0)],
 'skewed in x-y-t'      :[(2,0,1,0),(0,2,0,1),(-2,0,-1,0),(0,-2,0,-1),(2,0,1,0)],
 'loop missing e'       :[(4,0,0,0),(6,2,0,0),(8,0,0,0),(6,-2,0,0),(4,0,0,0)],
}
for name,lp in electron_loops.items():
    print(f"  {name:24s}: linking = {link_loop_sheet(lp,NB):+.3f}")

print("\nReading:")
print(" If validation row 1=1, row2=0, row3=0, row4=2, the linking")
print(" number is correct. Then the electron's spatial measurement")
print(" rings all give the SAME integer independent of size/skew, and")
print(" the missing loop gives 0 -> the electron carries a quantized,")
print(" loop-independent charge = linking with its z-t worldsheet.")
print(" SAME Z quantum as the proton -- unified as codim-2 linking.")
