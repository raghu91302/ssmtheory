#!/usr/bin/env python3
"""Genuine lattice U(1) test: is the defect's holonomy FORCED to be
quantized by the code's structure, or is integer winding an assumption?

No assumed source this time. We build an actual U(1) connection and ask
whether the DEFECT'S OWN BOND STRUCTURE forces a quantized holonomy.

CONSTRUCTION (honest, no answer inserted):
  - U(1) connection = a real phase theta_e on each FCC edge e.
  - Curvature on a plaquette P = sum of theta_e around P (mod 2pi).
  - A defect modifies the lattice: the matter paper's proton is an
    anchor bond singled out, breaking S4->S3; the excess node's bonds
    are COMPRESSED (shorter than L). We model the connection as the
    geometric phase each bond acquires from its length deviation:
        theta_e = alpha * (|e| - L)
    i.e. the connection IS the strain field, which is the only
    lattice-intrinsic 1-form the defect actually produces. This is not
    an assumption about charge -- it is reading the connection off the
    ACTUAL geometry the matter paper specifies.
  - Holonomy around a loop = sum theta_e. Quantized charge <=> this is
    an integer multiple of a fixed quantum for EVERY loop enclosing the
    defect, forced, not tuned.

Then the real question: compute the holonomy for the electron (point,
symmetric compression) and proton (anchor-selected, ONE bond
distinguished). Does the anchor selection -- the S4->S3 breaking the
matter paper needs for charge -- actually produce a nonzero quantized
holonomy, while the symmetric electron produces zero? If yes, the
framework EARNS the +2/3,-1/3 structure from geometry. If the strain
1-form is curl-free (a pure gradient), holonomy is ZERO for everything
and winding is NOT captured by the connection -- a negative result.
"""
import numpy as np
from itertools import product, combinations

L=np.sqrt(2.0)
NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
    (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]
pts=set(p for p in product(range(-4,5),repeat=3) if sum(p)%2==0)
def nbrs(v): return [tuple(v[i]+d[i] for i in range(3)) for d in NN
                     if tuple(v[i]+d[i] for i in range(3)) in pts]

def plaquettes():
    """all rhombic 4-cycles a-b-x-c of the FCC nn-graph"""
    seen=set(); out=[]
    for a in pts:
        for b,c in combinations(nbrs(a),2):
            common=set(nbrs(b))&set(nbrs(c))
            for x in common:
                if x!=a:
                    key=frozenset([a,b,x,c])
                    if len(key)==4 and (key,) not in seen:
                        seen.add((key,)); out.append((a,b,x,c))
    return out

PL=plaquettes()
print(f"plaquettes in graph: {len(PL)}")

def displaced_positions(defect):
    """return a dict node->displaced position under the defect.
    electron: origin node present but lattice relaxed symmetrically
      (radial inward pull) -> pure gradient displacement.
    proton: anchor-selected -> ONE bond direction singled out, the
      excess node pulled toward the anchor vertex (asymmetric)."""
    disp={v:np.array(v,float) for v in pts}
    if defect=='electron':
        # symmetric compression: origin's neighbours pulled inward equally
        o=np.array((0,0,0),float)
        for n in nbrs((0,0,0)):
            d=np.array(n,float)-o; u=d/np.linalg.norm(d)
            disp[n]=np.array(n,float)-0.1*u   # radial, curl-free
    elif defect=='proton':
        # anchor selection: pick anchor direction, distinguish it.
        anchor=nbrs((0,0,0))[0]
        av=np.array(anchor,float); av/=np.linalg.norm(av)
        for n in nbrs((0,0,0)):
            d=np.array(n,float); u=d/np.linalg.norm(d)
            # transverse (azimuthal) twist about the anchor axis:
            tw=np.cross(av,u)*0.1                  # NONzero curl part
            disp[n]=np.array(n,float)+tw
    return disp

def connection(disp):
    """theta_e = signed length deviation of each edge under displacement.
    Returned as antisymmetric dict (u,v)->theta."""
    th={}
    verts=set(disp)
    for a in verts:
        for b in nbrs(a):
            if b in disp and (b,a) not in th:
                la=np.linalg.norm(disp[a]-disp[b])
                th[(a,b)]=(la-L); th[(b,a)]=-(la-L)
    return th

def curvature(th):
    """max |sum theta around a plaquette| -- nonzero => genuine curl."""
    worst=0.0; total=0.0; n=0
    for (a,b,x,c) in PL:
        loop=[(a,b),(b,x),(x,c),(c,a)]
        if all(e in th for e in loop):
            f=sum(th[e] for e in loop)
            worst=max(worst,abs(f)); total+=abs(f); n+=1
    return worst, (total/n if n else 0)

for defect in ('electron','proton'):
    disp=displaced_positions(defect)
    th=connection(disp)
    worst,mean=curvature(th)
    print(f"\n{defect}:")
    print(f"  max plaquette curvature |curl theta| = {worst:.5f}")
    print(f"  mean plaquette curvature             = {mean:.5f}")
    verdict = ("CURL-FREE (pure gradient): connection carries NO holonomy,"
               "\n     winding is NOT captured -- negative result"
               if worst<1e-9 else
               "NONZERO CURL: connection carries holonomy -- a charge-like"
               "\n     invariant EXISTS; test quantization next")
    print(f"  => {verdict}")
