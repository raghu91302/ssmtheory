#!/usr/bin/env python3
"""Is charge a TOPOLOGICAL invariant (electron = proton, forced) or a
GEOMETRIC one (size-dependent, => charge non-universality, falsified)?

The make-or-break test for turning the matter paper's winding NUMBER
into a charge COUPLING. In the matter paper charge is Q = -1 + W with
W the integer winding of a defect's bonds under the bulk Bravais
translation group. For that to be a real (universal) electric charge,
the winding must be a HOLONOMY that depends only on the wrapping class
of a loop enclosing the defect -- NOT on the defect's size or shape.

Test: put a U(1) connection on FCC edges sourced by a defect, then
measure the holonomy (loop integral of the connection) around loops of
different sizes and shapes enclosing:
  (e) a POINT defect  -- the electron, one excess node at a vertex
  (p) a 3-SHEET defect -- the proton, engaging an FCC coordination
      cluster (the 36-edge / 51-cell object of Part II)

If the holonomy is topological, every enclosing loop gives the SAME
value for a given defect, and the electron and proton give the SAME
unit -- charge is universal, the framework earns quantized charge.
If it depends on loop size/shape or differs between e and p, the
framework predicts non-universal charge, which experiment excludes at
1 part in 1e21.

MODEL. Discrete U(1) lattice gauge analogue: the defect is a source of
"winding flux". We assign each FCC edge a connection a_e = phase such
that the lattice curl (flux through each plaquette) integrates, around
any loop enclosing the defect, to 2*pi*(winding). We then check whether
the enclosed winding is loop-independent -- i.e. whether the discrete
Stokes theorem holds with a source of fixed integer strength
regardless of how the defect is spatially extended.
"""
import numpy as np
from itertools import product, combinations

# FCC in even-parity integer coords, a=2, L=sqrt(2)
def fcc(rng=4):
    return [p for p in product(range(-rng, rng+1), repeat=3) if sum(p)%2==0]

NN=[(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),(-1,0,1),
    (-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)]

pts=set(fcc(4))

def nbrs(v): return [tuple(v[i]+d[i] for i in range(3)) for d in NN
                     if tuple(v[i]+d[i] for i in range(3)) in pts]

# ---- Defects ----
# electron: single excess node at origin (a vertex). Its "charge cloud"
#   is the set of edges incident to the origin.
# proton: 3-sheet on the coordination cluster of the origin -- the 12
#   FCC neighbours plus origin, engaging the cluster's edges.
ORIG=(0,0,0)
e_support = {frozenset((ORIG,n)) for n in nbrs(ORIG)}       # 12 edges
cluster = [ORIG]+nbrs(ORIG)
p_support = {frozenset((a,b)) for a in cluster for b in nbrs(a)
             if b in cluster}                                # cluster edges

print(f"electron support: {len(e_support)} edges (star of one vertex)")
print(f"proton support:   {len(p_support)} edges (coordination cluster)")

# ---- Winding as holonomy ----
# We model the defect as carrying an integer "winding charge" q0, and
# assign a connection whose loop integral around ANY loop enclosing the
# defect equals 2*pi*q0 IF winding is topological. To TEST rather than
# assume this, we build the connection from the defect's actual bond
# structure (a source term on its support edges) and numerically
# integrate holonomy on loops of increasing radius, WITHOUT imposing
# the answer.
#
# Discrete construction: solve for a 1-form 'a' on edges minimizing
# sum a_e^2 subject to (d a)(plaquette) = flux, where total flux
# through any surface capping a loop = number of support-edges pierced.
# Then holonomy(loop) = sum of a_e around the loop = (by discrete
# Stokes) total flux through a cap = # support edges crossing the cap.
#
# The physically meaningful test reduces to a clean combinatorial
# question: does the number of support-edges piercing a capping surface
# depend only on whether the defect is enclosed (topological), or on
# the loop's size/shape (geometric)?

def winding_through_sphere(support, R):
    """Count support-edges crossing a sphere of radius R about origin:
    edges with one endpoint inside, one outside. This is the discrete
    flux = holonomy around the sphere's equatorial loop (Stokes)."""
    def inside(v): return np.linalg.norm(v) < R
    c=0
    for e in support:
        a,b=tuple(e)
        if inside(a)!=inside(b): c+=1
    return c

print("\nHolonomy (support-edges crossing an enclosing sphere) vs radius:")
print(f"{'R':>5} {'electron':>10} {'proton':>10}")
for R in (0.9, 1.2, 1.6, 2.0, 2.6, 3.2):
    we=winding_through_sphere(e_support,R)
    wp=winding_through_sphere(p_support,R)
    print(f"{R:5.1f} {we:10d} {wp:10d}")

print("\nInterpretation:")
print(" - If a column is CONSTANT in R once the defect is enclosed,")
print("   its holonomy is topological (loop-independent).")
print(" - If electron and proton columns settle to the SAME constant,")
print("   charge is universal. If different, non-universal (falsified).")
