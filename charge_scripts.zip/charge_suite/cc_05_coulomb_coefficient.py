#!/usr/bin/env python3
"""COMPUTE 1/4: pin the Coulomb coefficient (alpha) analytically.

Script 40 got 1/r in form but the coefficient only to ~2x, from k-grid
under-resolution. The clean route is the ANALYTIC small-k limit plus a
high-resolution BZ integral for the lattice Green function at the origin
region -- no fitting.

The FCC Laplacian symbol: D(k) = sum_nn (1 - cos k.delta), 12 neighbours.
Small k: D(k) -> c |k|^2 with c computed exactly below. The continuum
Green function of -c nabla^2 is G(r) = 1/(4 pi c r). So the Coulomb
coefficient is 1/(4 pi c) in lattice units. c is exact; the ONLY
subtlety is the lattice-to-physical normalization, which we state
explicitly rather than fit.
"""
import numpy as np
NN=np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0),(1,0,1),(1,0,-1),
    (-1,0,1),(-1,0,-1),(0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1)],float)

# exact c: D(k) = sum (1-cos k.d) ~ sum (1/2)(k.d)^2 = (1/2) k^T (sum d d^T) k
M=sum(np.outer(d,d) for d in NN)
print("structure tensor sum(d d^T):")
print(M, "\n -> = 4*I means isotropic with c = 4*(1/2)=... let's derive")
# (1/2) k^T M k with M = 4 I  => D ~ (1/2)*4*|k|^2 = 2|k|^2. So c=2? check:
for eps in (1e-2,1e-3):
    k=np.array([eps,0,0]); approx=np.sum(1-np.cos(k@NN.T))
    print(f" |k|={eps}: D={approx:.6e}, D/|k|^2={approx/eps**2:.4f}")
c=0.5*M[0,0]
print(f"\n exact c = (1/2)*M[0,0] = {c}")
print(f" continuum Green coefficient 1/(4 pi c) = {1/(4*np.pi*c):.6f} (lattice units)")

# high-res lattice Green function to confirm G(r)*r -> 1/(4 pi c)
def green(x,ng):
    ks=(np.arange(ng)+0.5)/ng*2*np.pi-np.pi
    KX,KY,KZ=np.meshgrid(ks,ks,ks,indexing='ij')
    K=np.stack([KX.ravel(),KY.ravel(),KZ.ravel()],1)
    d=np.sum(1-np.cos(K@NN.T),axis=1)
    m=d>1e-9
    return np.mean(np.cos(K[m]@np.array(x,float))/d[m])*(m.sum()/len(K))

print("\n high-res Green function, G*r vs continuum 1/(4 pi c):")
print(f"{'r':>6} {'ng=100':>12} {'ng=140':>12}")
for p in [(4,0,0),(8,0,0),(12,0,0),(16,0,0)]:
    r=np.sqrt(sum(v*v for v in p))
    g100=green(p,100)*r; g140=green(p,140)*r
    print(f"{r:6.1f} {g100:12.6f} {g140:12.6f}")
print(f" continuum target: {1/(4*np.pi*c):.6f}")

# The framework's alpha: in the SSM/MEI dictionary, the elementary charge
# is one linking quantum, and the Coulomb energy between two unit charges
# at the nearest physical separation sets e^2/(hbar c) = alpha. Without a
# separate normalization of the lattice spacing to physical units, the
# DIMENSIONLESS ratio the lattice fixes is the geometric coefficient
# 1/(4 pi c). State it honestly:
print("\n=== HONEST STATEMENT ===")
print(f" The lattice fixes the geometric Coulomb coefficient 1/(4 pi c)")
print(f" = {1/(4*np.pi*c):.5f} (c={c} exact from the FCC structure tensor).")
print(" This is NOT yet the physical alpha=1/137: extracting alpha needs")
print(" the normalization of one linking quantum to the physical electron")
print(" charge, which the framework does not fix without an independent")
print(" input. What IS derived: the coefficient is geometric, isotropic,")
print(" and finite. alpha = 1/137 is NOT derived. Do not claim it.")
