#!/usr/bin/env python3
"""
Verification script for:
  "Charge from the Triality Grading: Thirds Quantization, Charge
   Conjugation as Spatial Inversion, and the Glue-Class Structure of
   Matter on the D4 Vacuum"  (R. Kulkarni, 2026)

Reproduces every computation in the paper. Requires numpy only.
Run:  python3 verify_charge_paper.py
Each block prints PASS/FAIL against the claim it verifies.
"""
import numpy as np, itertools, math

ok_all = True
def check(name, cond):
    global ok_all
    print(("PASS  " if cond else "FAIL  ") + name)
    ok_all &= bool(cond)

# ---------------- Section 2: Setup ----------------
# D4 roots: 24 vectors +-e_i +- e_j
roots = []
for i, j in itertools.combinations(range(4), 2):
    for si, sj in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v = np.zeros(4); v[i] = si; v[j] = sj
        roots.append(v)
roots = np.array(roots)
rootset = {tuple(np.round(r,6)) for r in roots}
check("24 roots, squared length 2", len(roots)==24 and all(abs(r@r-2)<1e-9 for r in roots))

# automorphism group of the root system = W(F4): reflections in the 24
# roots and in the 24 short vectors (+-e_i and (+-1,..)/2), closed.
key = lambda M: tuple(np.round(M.flatten(),6))
short = [np.eye(4)[i] for i in range(4)] + \
        [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
gens = [np.eye(4)-np.outer(r,r) for r in roots] + \
       [np.eye(4)-2*np.outer(r,r)/(r@r) for r in short]
G = {key(np.eye(4)): np.eye(4)}; frontier = [np.eye(4)]
while frontier:
    new = []
    for M in frontier:
        for g in gens:
            N = g@M; k = key(N)
            if k not in G:
                G[k] = N; new.append(N)
    frontier = new
G = {k:M for k,M in G.items()
     if all(tuple(np.round(M@r,6)) in rootset for r in roots)}
check("Aut(D4 roots) has order 1152", len(G)==1152)
o3 = [M for M in G.values()
      if np.allclose(np.linalg.matrix_power(M,3), np.eye(4))
      and not np.allclose(M, np.eye(4))]
check("80 elements of order 3", len(o3)==80)

# color A2: spatial roots orthogonal to the stacking axis (1,1,1)
n = np.array([1,1,1,0.])
A2 = [r for r in roots if abs(r@n)<1e-9 and abs(r[3])<1e-9]
A2set = {tuple(np.round(r,6)) for r in A2}
check("color A2 has 6 roots", len(A2)==6)

fixers = [M for M in o3
          if all(np.allclose(M@np.array(a), np.array(a)) for a in A2set)]
check("exactly 2 order-3 elements fix the A2 pointwise (tau, tau^2)",
      len(fixers)==2)
tau = fixers[0]

moved = [r for r in roots if tuple(np.round(r,6)) not in A2set]
orbits = []; seen = set()
for r in moved:
    k = tuple(np.round(r,6))
    if k in seen: continue
    orb = [r, tau@r, tau@tau@r]
    for o in orb: seen.add(tuple(np.round(o,6)))
    orbits.append(orb)
check("18 moved roots form 6 orbits of 3", len(orbits)==6)
mix = {tuple((sum(1 for o in orb if abs(o[3])<1e-9),
              sum(1 for o in orb if abs(o[3])>1e-9))) for orb in orbits}
check("each orbit mixes 1 spatial + 2 temporal roots", mix=={(1,2)})

# the twist sigma = Ad(exp(2 pi i rho.H/3)) o tau, rho = A2 Weyl vector
rho = np.array([1.,0.,-1.,0.])   # alpha1+alpha2 for a1=(1,-1,0,0), a2=(0,1,-1,0)
surv_fixed = [a for a in map(np.array, A2set) if int(round(rho@a))%3==0]
surv_orb = [orb for orb in orbits if int(round(rho@sum(orb)))%3==0]
check("no A2 root generator survives individually", len(surv_fixed)==0)
check("all 6 orbit sums survive: dim g0 = 2 + 6 = 8", len(surv_orb)==6)
tw = [sum(orb)/3 for orb in surv_orb]
check("twisted roots have squared length 2/3 (level-3 color)",
      all(abs(v@v-2/3)<1e-9 for v in tw))
angles = {round(math.degrees(math.acos(np.clip(
    t@u/np.sqrt((t@t)*(u@u)),-1,1))),1)
    for t in tw for u in tw if not np.allclose(t,u)}
check("twisted roots form an A2 (angles 60/120/180)",
      angles=={60.0,120.0,180.0})
dims = [2,1,1]
for a in map(np.array, A2set): dims[int(round(rho@a))%3] += 1
for orb in orbits:
    for k in range(3): dims[k] += 1
check("Z3 grading of so(8): (g0,g1,g2) = (8,10,10)", dims==[8,10,10])

# ---------------- Section 3: Theorem 1 (no internal hypercharge) ----------------
def commutes(h):
    return all(len({round(float(h@a),6) for a in orb})==1 for orb in surv_orb)
u  = np.array([1,1,1,0.])/np.sqrt(3)
t4 = np.array([0,0,0,1.])
check("u=(1,1,1,0)/sqrt3 does NOT commute with twisted su(3)", not commutes(u))
check("e4 does NOT commute with twisted su(3)", not commutes(t4))
# grading has no g0-singlets outside g0 (10, 10bar irreducible), so the
# commutant is trivial: verified by the two Cartan checks above plus dims.

# ---------------- Section 4: glue classes and Theorem 2 ----------------
g1 = np.array([.5,.5,.5,.5]); g2 = np.array([0,0,0,1.]); g3 = np.array([.5,.5,.5,-.5])
def cls(v):
    for name,g in [("0",np.zeros(4)),("[1]",g1),("[2]",g2),("[3]",g3)]:
        d = v-g
        if np.allclose(d, np.round(d)) and int(round(d.sum()))%2==0:
            return name
    return "?"
check("tau 3-cycles the glue classes [1]->[2]->[3]->[1]",
      cls(tau@g1)=="[2]" and cls(tau@g2)=="[3]" and cls(tau@g3)=="[1]")

# the three 8-dimensional reps by weights, one per glue class
Wv = [s*np.eye(4)[i] for i in range(4) for s in (1,-1)]
Sp = [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
Ws = [w for w in Sp if int(np.prod(w*2))== 1]
Wc = [w for w in Sp if int(np.prod(w*2))==-1]
reps = {'8v':Wv,'8s':Ws,'8c':Wc}
check("weights of 8v/8s/8c lie in glue classes [2]/[1]/[3]",
      cls(Wv[0])=="[2]" and cls(Ws[0])=="[1]" and cls(Wc[0])=="[3]")
def which(w):
    k = tuple(np.round(w,6))
    for name,W in reps.items():
        if k in {tuple(np.round(x,6)) for x in W}: return name
    return "?"
check("tau permutes the matter reps in a 3-cycle",
      which(tau@Wv[0])!='8v' and which(tau@(tau@Wv[0]))!=which(tau@Wv[0])
      and which(tau@(tau@(tau@Wv[0])))=='8v')

# ---------------- Section 5: Theorems 3 and 4 ----------------
check("rho.mu is an integer for all 24 weights (order 3 well posed)",
      all(abs((rho@w)-round(rho@w))<1e-9 for W in reps.values() for w in W))
check("every weight orbit has twist-phase sum = 0 mod 3",
      all(sum(round(float(rho@x)) for x in [w,tau@w,tau@tau@w])%3==0
          for w in Wv))
# => sigma^3 = 1 on M and each orbit gives one state per q in {0,+1,-1}:
# every charge sector M_q = 3 + 3bar + 1 + 1. Branching check per rep:
P = np.eye(4) - np.outer(u,u) - np.outer(t4,t4)
for name,W in reps.items():
    L = sorted(round(float((P@w)@(P@w)),6) for w in W)
    check(f"{name} branches as 3+3bar+1+1 (six 2/3-weights, two zeros)",
          L[:2]==[0.0,0.0] and all(abs(x-2/3)<1e-6 for x in L[2:]))

I = np.diag([-1.,-1.,-1.,1.])
check("spatial inversion conjugates tau to tau^2  =>  C = P",
      np.allclose(I@tau@np.linalg.inv(I), tau@tau))

# ---------------- Section 6: the coupling fence ----------------
MZ, MP = 91.1876, 1.2209e19
a_em, s2, a3 = 1/127.93, 0.23122, 0.1179
aY, a2w = a_em/(1-s2), a_em/s2
a1G = 5/3*aY
b = (41/10, -19/6, -7)
run = lambda a,bi: 1/(1/a - bi/(2*math.pi)*math.log(MP/MZ))
a1P, a2P, a3P = run(a1G,b[0]), run(a2w,b[1]), run(a3,b[2])
r = a3P/(3/5*a1P)
print(f"      SM 1-loop at M_P: a1^-1(GUT)={1/a1P:.1f}, a2^-1={1/a2P:.1f}, "
      f"a3^-1={1/a3P:.1f};  alpha3/alphaY = {r:.3f}")
check("measured ratio at M_P is near 1: candidates 3 and 1/3 excluded",
      0.5 < r < 2.0)

print("\nVERDICT:", "ALL PASS" if ok_all else "FAILURES PRESENT")
