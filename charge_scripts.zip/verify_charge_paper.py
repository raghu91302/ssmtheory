#!/usr/bin/env python3
"""
Verification script for:
  "From D4 to F4: Color, Matter, and Charge from One Triality Twist"
  (R. Kulkarni, 2026), Sections 2-5

Reproduces every computation in the paper. Requires numpy only.
Run:  python3 verify_charge_paper.py
Each block prints PASS/FAIL against the claim it verifies.
"""
import numpy as np, itertools, math

ok_all = True
def check(name, cond):
    global ok_all
    print(("PASS  " if cond else "FAIL  ") + name)
    ok_all &= bool(cond)

# ---------------- Section 2: Setup ----------------
# D4 roots: 24 vectors +-e_i +- e_j
roots = []
for i, j in itertools.combinations(range(4), 2):
    for si, sj in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v = np.zeros(4); v[i] = si; v[j] = sj
        roots.append(v)
roots = np.array(roots)
rootset = {tuple(np.round(r,6)) for r in roots}
check("24 roots, squared length 2", len(roots)==24 and all(abs(r@r-2)<1e-9 for r in roots))

# automorphism group of the root system = W(F4): reflections in the 24
# roots and in the 24 short vectors (+-e_i and (+-1,..)/2), closed.
key = lambda M: tuple(np.round(M.flatten(),6))
short = [np.eye(4)[i] for i in range(4)] + \
        [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
gens = [np.eye(4)-np.outer(r,r) for r in roots] + \
       [np.eye(4)-2*np.outer(r,r)/(r@r) for r in short]
G = {key(np.eye(4)): np.eye(4)}; frontier = [np.eye(4)]
while frontier:
    new = []
    for M in frontier:
        for g in gens:
            N = g@M; k = key(N)
            if k not in G:
                G[k] = N; new.append(N)
    frontier = new
G = {k:M for k,M in G.items()
     if all(tuple(np.round(M@r,6)) in rootset for r in roots)}
check("Aut(D4 roots) has order 1152", len(G)==1152)
o3 = [M for M in G.values()
      if np.allclose(np.linalg.matrix_power(M,3), np.eye(4))
      and not np.allclose(M, np.eye(4))]
check("80 elements of order 3", len(o3)==80)

# color A2: spatial roots orthogonal to the stacking axis (1,1,1)
n = np.array([1,1,1,0.])
A2 = [r for r in roots if abs(r@n)<1e-9 and abs(r[3])<1e-9]
A2set = {tuple(np.round(r,6)) for r in A2}
check("color A2 has 6 roots", len(A2)==6)

fixers = [M for M in o3
          if all(np.allclose(M@np.array(a), np.array(a)) for a in A2set)]
check("exactly 2 order-3 elements fix the A2 pointwise (tau, tau^2)",
      len(fixers)==2)
tau = fixers[0]

moved = [r for r in roots if tuple(np.round(r,6)) not in A2set]
orbits = []; seen = set()
for r in moved:
    k = tuple(np.round(r,6))
    if k in seen: continue
    orb = [r, tau@r, tau@tau@r]
    for o in orb: seen.add(tuple(np.round(o,6)))
    orbits.append(orb)
check("18 moved roots form 6 orbits of 3", len(orbits)==6)
mix = {tuple((sum(1 for o in orb if abs(o[3])<1e-9),
              sum(1 for o in orb if abs(o[3])>1e-9))) for orb in orbits}
check("each orbit mixes 1 spatial + 2 temporal roots", mix=={(1,2)})

# the twist sigma = Ad(exp(2 pi i rho.H/3)) o tau, rho = A2 Weyl vector
rho = np.array([1.,0.,-1.,0.])   # alpha1+alpha2 for a1=(1,-1,0,0), a2=(0,1,-1,0)
surv_fixed = [a for a in map(np.array, A2set) if int(round(rho@a))%3==0]
surv_orb = [orb for orb in orbits if int(round(rho@sum(orb)))%3==0]
check("no A2 root generator survives individually", len(surv_fixed)==0)
check("all 6 orbit sums survive: dim g0 = 2 + 6 = 8", len(surv_orb)==6)
tw = [sum(orb)/3 for orb in surv_orb]
check("twisted roots have squared length 2/3 (level-3 color)",
      all(abs(v@v-2/3)<1e-9 for v in tw))
angles = {round(math.degrees(math.acos(np.clip(
    t@u/np.sqrt((t@t)*(u@u)),-1,1))),1)
    for t in tw for u in tw if not np.allclose(t,u)}
check("twisted roots form an A2 (angles 60/120/180)",
      angles=={60.0,120.0,180.0})
dims = [2,1,1]
for a in map(np.array, A2set): dims[int(round(rho@a))%3] += 1
for orb in orbits:
    for k in range(3): dims[k] += 1
check("Z3 grading of so(8): (g0,g1,g2) = (8,10,10)", dims==[8,10,10])

# ---------------- Section 3: Theorem 1 (no internal hypercharge) ----------------
u  = np.array([1,1,1,0.])/np.sqrt(3)
t4 = np.array([0,0,0,1.])
P  = np.eye(4) - np.outer(u,u) - np.outer(t4,t4)       # projector onto the color plane
# step 1: the commutant lies in the zero-weight space of the color Cartan;
# no root is orthogonal to the color plane, so that space is the 4-dim Cartan
check("no D4 root is orthogonal to the color plane (zero-weight space = Cartan)",
      all(np.linalg.norm(P@r)>1e-9 for r in roots))
# step 2: h commutes with an orbit generator iff <h,alpha>=0 on all three roots;
# the 18 moved roots span R^4, so only h=0 survives
moved = np.array([x for orb in orbits for x in orb])
check("18 moved roots span R^4 (rank 4) => commutant trivial",
      np.linalg.matrix_rank(moved)==4)

# ---------------- Section 4: glue classes and Theorem 2 ----------------
g1 = np.array([.5,.5,.5,.5]); g2 = np.array([0,0,0,1.]); g3 = np.array([.5,.5,.5,-.5])
def cls(v):
    for name,g in [("0",np.zeros(4)),("[1]",g1),("[2]",g2),("[3]",g3)]:
        d = v-g
        if np.allclose(d, np.round(d)) and int(round(d.sum()))%2==0:
            return name
    return "?"
check("tau 3-cycles the glue classes [1]->[2]->[3]->[1]",
      cls(tau@g1)=="[2]" and cls(tau@g2)=="[3]" and cls(tau@g3)=="[1]")

# the three 8-dimensional reps by weights, one per glue class
Wv = [s*np.eye(4)[i] for i in range(4) for s in (1,-1)]
Sp = [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
Ws = [w for w in Sp if int(np.prod(w*2))== 1]
Wc = [w for w in Sp if int(np.prod(w*2))==-1]
reps = {'8v':Wv,'8s':Ws,'8c':Wc}
check("weights of 8v/8s/8c lie in glue classes [2]/[1]/[3]",
      cls(Wv[0])=="[2]" and cls(Ws[0])=="[1]" and cls(Wc[0])=="[3]")
def which(w):
    k = tuple(np.round(w,6))
    for name,W in reps.items():
        if k in {tuple(np.round(x,6)) for x in W}: return name
    return "?"
check("tau permutes the matter reps in a 3-cycle",
      which(tau@Wv[0])!='8v' and which(tau@(tau@Wv[0]))!=which(tau@Wv[0])
      and which(tau@(tau@(tau@Wv[0])))=='8v')

# void correspondence: project weights onto the FCC slice (bond vectors (+-1,+-1,0))
sites=[np.array(v,float) for v in itertools.product(range(-3,4),repeat=3) if sum(v)%2==0]
def vtype(p):
    d=sorted(np.linalg.norm(p-q) for q in sites)
    if d[0]<1e-9: return "site"
    return {4:"tet",6:"oct"}.get(sum(1 for x in d if abs(x-d[0])<1e-9),"other")
spin8={k:reps[k] for k in reps if k!="8v"}
check("8s and 8c each project bijectively onto a node's 8 tetrahedral voids",
      all(len({tuple(np.round(w[:3],6)) for w in W})==8 and {vtype(w[:3]) for w in W}=={"tet"}
          for W in spin8.values()))
check("8v: spatial weights -> 6 octahedral voids, temporal weights -> the node",
      {vtype(w[:3]) for w in reps["8v"] if abs(w[3])<1e-9}=={"oct"} and
      {vtype(w[:3]) for w in reps["8v"] if abs(w[3])>0.5}=={"site"})

# the eight voids form two FCC void classes; each receives 4 weights of 8s and 4 of 8c
inD3=lambda v: np.allclose(v,np.round(v)) and int(round(v.sum()))%2==0
vA=np.array([.5,.5,.5]); vcl=lambda p: "A" if inD3(p-vA) else "B"
split={(nm,c):sum(1 for w in reps[nm] if vcl(w[:3])==c) for nm in ("8s","8c") for c in ("A","B")}
check("each tetrahedral void class carries 4 weights of 8s and 4 of 8c",
      all(v==4 for v in split.values()))

# ---------------- Section 5: Theorems 3 and 4 ----------------
check("rho.mu is an integer for all 24 weights (order 3 well posed)",
      all(abs((rho@w)-round(rho@w))<1e-9 for W in reps.values() for w in W))
check("every weight orbit has twist-phase sum = 0 mod 3",
      all(sum(round(float(rho@x)) for x in [w,tau@w,tau@tau@w])%3==0
          for w in Wv))
# Theorem 3 branching. Counting weight norms cannot separate 8 from 3+3bar+1+1;
# instead: the nonzero projected weights must EQUAL the roots of g0 (adjoint)
twset={tuple(np.round(v,6)) for v in tw}
for name,W in reps.items():
    nz={tuple(np.round(P@w,6)) for w in W if np.linalg.norm(P@w)>1e-9}
    zeros=sum(1 for w in W if np.linalg.norm(P@w)<1e-9)
    check(f"{name}: nonzero weights = the 6 roots of g0, plus 2 zeros  =>  adjoint 8",
          nz==twset and zeros==2)

I = np.diag([-1.,-1.,-1.,1.])
check("Theorem 4, root level: I tau I^-1 = tau^2 (algebra-level C = P: f4_scripts.zip)",
      np.allclose(I@tau@np.linalg.inv(I), tau@tau))

# ---------------- Section 6: the coupling fence ----------------
MZ, MP = 91.1876, 1.2209e19
a_em, s2, a3 = 1/127.93, 0.23122, 0.1179
aY, a2w = a_em/(1-s2), a_em/s2
a1G = 5/3*aY
b = (41/10, -19/6, -7)
run = lambda a,bi: 1/(1/a - bi/(2*math.pi)*math.log(MP/MZ))
a1P, a2P, a3P = run(a1G,b[0]), run(a2w,b[1]), run(a3,b[2])
r = a3P/(3/5*a1P)
print(f"      SM 1-loop at M_P: a1^-1(GUT)={1/a1P:.1f}, a2^-1={1/a2P:.1f}, "
      f"a3^-1={1/a3P:.1f};  alpha3/alphaY = {r:.3f}")
check("measured ratio at M_P is near 1: candidates 3 and 1/3 excluded",
      0.5 < r < 2.0)
# the exclusion is insensitive to the matching scale: lower it by up to a factor 3
runS = lambda a,bi,mu: 1/(1/a - bi/(2*math.pi)*math.log(mu/MZ))
rng_r=[]
for f in (1.0,1.5,2.0,2.5,3.0):
    A1,A3=runS(a1G,b[0],MP/f),runS(a3,b[2],MP/f)
    rng_r.append((A3/(3/5*A1), A3/A1))
rY=[x[0] for x in rng_r]; rG=[x[1] for x in rng_r]
print(f"      matching scale M_P/3 .. M_P: alpha3/alphaY in [{min(rY):.3f}, {max(rY):.3f}], alpha3/alpha1 in [{min(rG):.3f}, {max(rG):.3f}]")
check("Section 9: ratios stay in 1.06-1.11 (hypercharge) and 0.64-0.66 (GUT) for scales M_P/3..M_P",
      1.05<min(rY) and max(rY)<1.115 and 0.63<min(rG) and max(rG)<0.67)

# ---------------- Theorems 3 and 5 on the explicit matrix algebra ----------------
# so(8) as 8x8 matrices preserving J=[[0,I],[I,0]]; Cartan diag(a,-a)
def E_(i,j):
    M=np.zeros((8,8),complex); M[i,j]=1; return M
def rootvec(r):
    i,j=[k for k in range(4) if abs(r[k])>0.5]; si,sj=int(round(r[i])),int(round(r[j]))
    if (si,sj)==(1,-1): return E_(i,j)-E_(j+4,i+4)
    if (si,sj)==(-1,1): return E_(j,i)-E_(i+4,j+4)
    if (si,sj)==(1,1):  return E_(i,j+4)-E_(j,i+4)
    return E_(i+4,j)-E_(j+4,i)
Hm=lambda h: np.diag(np.concatenate([h,-h])).astype(complex)
br=lambda a,b: a@b-b@a
simple=[np.array(v,float) for v in ([1,-1,0,0],[0,1,-1,0],[0,0,1,-1],[0,0,1,1])]
def cheval(a):
    e=rootvec(a); f=rootvec(-a); h=br(e,f)
    lam=np.trace(br(h,e)@e.conj().T)/np.trace(e@e.conj().T)
    f=f*2/lam; return e,f,br(e,f)
Ch=[cheval(a) for a in simple]; Ct=[cheval(tau@a) for a in simple]
def words():
    out=[(tuple(np.round(a,6)),(i,)) for i,a in enumerate(simple)]; fr=list(out)
    while fr:
        nf=[]
        for r,w in fr:
            for i,a in enumerate(simple):
                nr=tuple(np.round(np.array(r)+a,6))
                if nr in rootset and nr not in [q[0] for q in out]:
                    out.append((nr,w+(i,))); nf.append((nr,w+(i,)))
        fr=nf
    return out
def ev(w,gen,k):
    X=gen[w[0]][k]
    for i in w[1:]: X=br(gen[i][k],X)
    return X
src=[];dst=[]
for r,w in words():
    for k in (0,1): src.append(ev(w,Ch,k)); dst.append(ev(w,Ct,k))
for i in range(4): src.append(Ch[i][2]); dst.append(Ct[i][2])
S=np.array([x.flatten() for x in src]).T; D=np.array([x.flatten() for x in dst]).T
Tm=D@np.linalg.pinv(S)
T=lambda X:(Tm@X.flatten()).reshape(8,8)
Dph=np.diag(np.exp(2j*np.pi*np.concatenate([rho,-rho])/3))
sig=lambda X: Dph@T(X)@np.linalg.inv(Dph)
rng=np.random.default_rng(1)
rnd=lambda: sum(rng.normal()*b for b in src)
x,y=rnd(),rnd()
check("explicit twist is a Lie-algebra automorphism of order 3",
      np.allclose(T(br(x,y)),br(T(x),T(y))) and np.allclose(sig(sig(sig(x))),x))
Bs=np.array([b.flatten() for b in src])
Cm=np.linalg.lstsq(Bs.T,np.array([sig(b).flatten() for b in src]).T,rcond=None)[0]
U_,sv,Vt=np.linalg.svd(Cm-np.eye(28)); g0=[(v@Bs).reshape(8,8) for v in Vt[np.abs(sv)<1e-8].conj()]
def commutant_dim(alg):
    M=np.vstack([np.kron(np.eye(8),a)-np.kron(a.T,np.eye(8)) for a in alg])
    return 64-np.linalg.matrix_rank(M,1e-8)
check("explicit fixed subalgebra g0 has dimension 8", len(g0)==8)
check("Theorem 3: commutant of g0 on C^8 is 1-dim  =>  8v is the irreducible octet",
      commutant_dim(g0)==1)
regA2=[rootvec(r) for r in A2]+[Hm(r) for r in A2]
check("control: regular A2 commutant on C^8 is 6-dim  =>  3+3bar+1+1",
      commutant_dim(regA2)==6)
w3=np.exp(2j*np.pi/3)
def sig_eig(r):
    X=rootvec(r); Y=sig(X); return np.vdot(X.flatten(),Y.flatten())/np.vdot(X.flatten(),X.flatten())
check("Theorem 5: geometric A2 root generators have sigma-eigenvalue w or w^2 (label +-1/3)",
      all(min(abs(sig_eig(r)-w3),abs(sig_eig(r)-w3*w3))<1e-8 for r in A2))
check("Theorem 5: index 1 for geometric A2 (roots length^2 2), index 3 for g0 (2/3)",
      all(abs(r@r-2)<1e-9 for r in A2) and all(abs(v@v-2/3)<1e-9 for v in tw))

# Section 2: eight tau's across the four stacking axes
tot=0
for axv in ([1,1,1],[1,1,-1],[1,-1,1],[-1,1,1]):
    axv=np.array(axv+[0.])
    A=[r for r in roots if abs(r[3])<1e-9 and abs(r@axv)<1e-9]
    tot+=sum(1 for M in o3 if all(np.allclose(M@r,r) for r in A))
check("eight order-3 elements across the four stacking axes (one pair per axis)", tot==8)
# Section 3 clarification: commutant of the geometric (regular) A2 inside so(8) is u(1)+u(1)
def so8_commutant_dim(alg):
    Bs_=np.array([b.flatten() for b in src])          # 28 basis elements of so(8)
    M=np.array([[np.vdot(0,0)]]) if False else None
    cols=[]
    for b in src:
        cols.append(np.concatenate([br(b,a).flatten() for a in alg]))
    A_=np.array(cols).T
    return 28-np.linalg.matrix_rank(A_,1e-8)
check("geometric A2 has commutant u(1)+u(1) in so(8) (dim 2); twisted su(3) has none (dim 0)",
      so8_commutant_dim(regA2)==2 and so8_commutant_dim(g0)==0)

# Figure 2: spatial inversion fixes the vector class [2] and exchanges [1] <-> [3]
Iinv=np.diag([-1.,-1.,-1.,1.])
check("Figure 2: inversion fixes [2] (8v) and exchanges [1] (8s) <-> [3] (8c)",
      cls(Iinv@g1)=="[3]" and cls(Iinv@g2)=="[2]" and cls(Iinv@g3)=="[1]")

print("\nVERDICT:", "ALL PASS" if ok_all else "FAILURES PRESENT")
