Verification scripts for:
  "Charge from the Triality Grading: Thirds Quantization, Charge
   Conjugation as Spatial Inversion, and the Glue-Class Structure of
   Matter on the D4 Vacuum"  (R. Kulkarni, 2026)

Contents:
  verify_charge_paper.py   reproduces every computation in the paper
                           (24 labeled checks keyed to the sections
                           and theorems), plus the renormalization-
                           group comparison of Section 6.

Requirements: Python 3 with numpy. No other dependencies.
Run:          python3 verify_charge_paper.py
Expected:     24x PASS, the running-coupling line, then ALL PASS.
Runtime:      a few seconds (the automorphism-group closure dominates).
