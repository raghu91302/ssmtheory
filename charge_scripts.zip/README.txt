Verification scripts for:
  "Quantum Numbers of Color and Charge from the Full F4 Algebra of a
   Bell-Pair Lattice Vacuum"
  (R. Kulkarni, 2026), Sections 2, 3, 5, 6.1 and 7
  (Sections 4-6 and 9: f4_scripts.zip)

Contents:
  verify_charge_paper.py   37 labeled checks keyed to the sections and
                           theorems: the twist on the D4 lift
                           (Section 2), the glue classes and the void
                           correspondence (Section 3, Theorem 1), thirds
                           quantization and the root-level C = P
                           (Section 5, Theorems 5 and 6), the bond-only
                           corollary on the explicit so(8) matrix
                           algebra (Section 6.1, Theorem 9, with the
                           regular-A2 control), and the
                           renormalization-group comparison
                           (Section 7).

Requirements: Python 3 with numpy. No other dependencies.
Run:          python3 verify_charge_paper.py
Expected:     37x PASS, the running-coupling line, then ALL PASS.
Runtime:      a few seconds.
