Verification scripts for:
  "From D4 to F4: Color, Matter, and Charge from One Triality Twist"
  (R. Kulkarni, 2026), Sections 2-5  (Sections 6-8: f4_scripts.zip)

Contents:
  verify_charge_paper.py   reproduces every computation in the paper
                           (37 labeled checks keyed to the sections and
                           theorems), including the explicit so(8)
                           matrix-algebra construction of the twist, the
                           commutant test that identifies each matter 8
                           as a color octet (with the regular-A2 control),
                           the color-charge fence, the void
                           correspondence, and the renormalization-group
                           comparison of Section 6.

Requirements: Python 3 with numpy. No other dependencies.
Run:          python3 verify_charge_paper.py
Expected:     37x PASS, the running-coupling line, then ALL PASS.
Runtime:      a few seconds.
