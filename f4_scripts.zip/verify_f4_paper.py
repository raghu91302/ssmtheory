#!/usr/bin/env python3
"""
Verification script for:
  "The Vacuum-Matter Algebra Is f4: Inner Triality, Charge as a
   Coweight, and an Emergent Second su(3)"  (R. Kulkarni, 2026)
Reproduces every computation in the paper. Requires numpy only.
Run: python3 verify_f4_paper.py
"""
import numpy as np, itertools

ok=True
def check(name,c):
    global ok; print(("PASS  " if c else "FAIL  ")+name); ok&=bool(c)

# --- Theorem 1: closure -------------------------------------------------
longr=[]
for i,j in itertools.combinations(range(4),2):
    for si,sj in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v=np.zeros(4); v[i]=si; v[j]=sj; longr.append(v)
shortr=[s*np.eye(4)[i] for i in range(4) for s in(1,-1)] + \
       [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
F4=np.array(longr+shortr)
F4set={tuple(np.round(r,6)) for r in F4}
check("48 roots, lengths {1,2}", len(F4set)==48 and
      {round(float(r@r),4) for r in F4}=={1.0,2.0})
refl=lambda r: np.eye(4)-2*np.outer(r,r)/(r@r)
check("closed under all 48 reflections (F4 root system)",
      all(tuple(np.round(refl(r)@s,6)) in F4set for r in F4 for s in F4))
Wv=[s*np.eye(4)[i] for i in range(4) for s in(1,-1)]
Sp=[np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
check("short roots == matter weights 8v+8s+8c",
      {tuple(np.round(w,6)) for w in Wv+Sp}==
      {tuple(np.round(r,6)) for r in shortr})

# --- bracket sector rules ----------------------------------------------
def rep(w):
    w=np.array(w)
    if abs(abs(w).max()-1)<1e-9 and np.count_nonzero(np.abs(w)>1e-9)==1:
        return 'v'
    if abs(abs(w).max()-0.5)<1e-9:
        return 's' if np.prod(np.sign(w))>0 else 'c'
    return 'L'
pat=set()
for a in shortr:
    for b in shortr:
        s=np.array(a)+b
        if tuple(np.round(s,6)) in F4set: pat.add((rep(a),rep(b),rep(s)))
check("[same rep, same rep] -> long only (annihilation)",
      all(p[2]=='L' for p in pat if p[0]==p[1]))
check("[8x, 8y] -> third rep only (triality fusion)",
      all(p[2]=={'v','s','c'}.difference({p[0],p[1]}).pop()
          for p in pat if p[0]!=p[1]))
check("[gauge, matter] -> matter only",
      all(rep(np.array(a)+b)!='L' for a in longr for b in shortr
          if tuple(np.round(np.array(a)+b,6)) in F4set))

# --- Theorem 2: triality inner -----------------------------------------
key=lambda M: tuple(np.round(M.flatten(),6))
G={key(np.eye(4)):np.eye(4)}; fr=[np.eye(4)]
gens=[refl(r) for r in F4]
while fr:
    new=[]
    for M in fr:
        for g in gens:
            N=g@M; k=key(N)
            if k not in G: G[k]=N; new.append(N)
    fr=new
check("reflection group of the 48 roots has order 1152 = W(F4)",
      len(G)==1152)
n=np.array([1,1,1,0.])
A2set={tuple(np.round(r,6)) for r in longr
       if abs(np.array(r)@n)<1e-9 and abs(r[3])<1e-9}
fixers=[M for M in G.values()
        if np.allclose(np.linalg.matrix_power(M,3),np.eye(4))
        and not np.allclose(M,np.eye(4))
        and all(np.allclose(M@np.array(a),np.array(a)) for a in A2set)]
check("the twist rotation tau lies inside W(F4) (triality is inner)",
      len(fixers)==2)
tau=fixers[0]

# --- Theorem 3: grading and coweight charge ----------------------------
rho=np.array([1.,0.,-1.,0.])
dims=[2,1,1]
for a in map(np.array,A2set): dims[int(round(rho@a))%3]+=1
seen=set()
for r in list(longr)+list(shortr):
    k=tuple(np.round(r,6))
    if k in A2set or k in seen: continue
    orb=[np.array(r),tau@np.array(r),tau@tau@np.array(r)]
    for o in orb: seen.add(tuple(np.round(o,6)))
    assert sum(round(float(rho@x)) for x in orb)%3==0
    for kk in range(3): dims[kk]+=1
check("sigma-grading of the 52 has dimensions (16,18,18)", dims==[16,18,18])
a1=np.array([0,1,-1,0.]); a2=np.array([0,0,1,-1.])
a3=np.array([0,0,0,1.]);  a4=np.array([1,-1,-1,-1.])/2
S=np.array([a1,a2,a3,a4]).T
c=np.linalg.solve(S,np.array([1,1,0,0.]))
check("highest root e1+e2 has marks (2,3,4,2)", np.allclose(c,[2,3,4,2]))
counts={0:0,1:0,2:0}
for r in F4:
    m=np.linalg.solve(S,r)
    assert np.allclose(m,np.round(m))
    counts[int(round(m[1]))%3]+=1
check("mark-3 coweight counting gives roots (12,18,18): charge = "
      "alpha2-coefficient mod 3",
      counts=={0:12,1:18,2:18} and
      (counts[0]+4,counts[1],counts[2])==(16,18,18))

# --- fixed subalgebra su(3)+su(3): rank and root-vector count ----------
zero_proj=[r for r in shortr
           if np.allclose((np.eye(4)-np.outer(n/np.sqrt(3),n/np.sqrt(3))
           -np.outer(a3,a3))@np.array(r),0)]
check("rank-4 zero-weight sector: 2 Cartan + 2 short zero-projection "
      "orbits (6 roots)", len(zero_proj)==6)
check("g0 = 4 (Cartan) + 12 (root vectors) = 16 = su(3)+su(3)",
      dims[0]==16)

# --- 26-branching under su(3)+su(3) ------------------------------------
from collections import Counter
th=np.array([1,1,0,0.]); b1=np.array([0,1,-1,0.])
b3=np.array([0,0,0,1.]); b4=np.array([1,-1,-1,-1.])/2
pair=lambda mu,b: round(2*float(mu@b)/float(b@b))
W26=[np.array(w) for w in shortr]+[np.zeros(4),np.zeros(4)]
w3=[(1,0),(-1,1),(0,-1)]; w3b=[(-a,-b) for a,b in w3]
blocks={'3':Counter(),'3b':Counter(),'1':Counter()}
for mu in W26:
    cl=(pair(mu,b1),pair(mu,-th)); h=(pair(mu,b3),pair(mu,b4))
    tkey='3' if cl in w3 else ('3b' if cl in w3b else '1')
    blocks[tkey][h]+=1
w8=Counter([(1,1),(2,-1),(-1,2),(-2,1),(1,-2),(-1,-1),(0,0),(0,0)])
check("26 branching: colored blocks are irreducible bifundamentals "
      "(3,3bar)+(3bar,3)",
      blocks['3']==Counter({k:3 for k in w3b}) and
      blocks['3b']==Counter({k:3 for k in w3}))
check("26 branching: color singlets form the horizontal 8",
      blocks['1']==w8)
Sm=np.array([b1,np.array([0,0,1,-1.]),b3,b4]).T
qof=lambda mu: int(round(np.linalg.solve(Sm,mu)[1]))%3
check("charge table: (3,3bar) at q=2 (Q=-1/3), conjugate at q=1, "
      "octet at q=0",
      all(qof(mu)==2 for mu in W26 if (pair(mu,b1),pair(mu,-th)) in w3) and
      all(qof(mu)==1 for mu in W26 if (pair(mu,b1),pair(mu,-th)) in w3b) and
      all(qof(mu)==0 for mu in W26 if (pair(mu,b1),pair(mu,-th)) not in w3+w3b))

print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
