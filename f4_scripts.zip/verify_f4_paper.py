#!/usr/bin/env python3
"""
Verification script for:
  "From D4 to F4: Color, Matter, and Charge from One Triality Twist"
  (R. Kulkarni, 2026), Sections 6-8
Reproduces every computation in the paper. Requires numpy only.
Run: python3 verify_f4_paper.py
"""
import numpy as np, itertools

ok=True
def check(name,c):
    global ok; print(("PASS  " if c else "FAIL  ")+name); ok&=bool(c)

# --- Theorem 1: closure -------------------------------------------------
longr=[]
for i,j in itertools.combinations(range(4),2):
    for si,sj in [(1,1),(1,-1),(-1,1),(-1,-1)]:
        v=np.zeros(4); v[i]=si; v[j]=sj; longr.append(v)
shortr=[s*np.eye(4)[i] for i in range(4) for s in(1,-1)] + \
       [np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
F4=np.array(longr+shortr)
F4set={tuple(np.round(r,6)) for r in F4}
check("48 roots, lengths {1,2}", len(F4set)==48 and
      {round(float(r@r),4) for r in F4}=={1.0,2.0})
refl=lambda r: np.eye(4)-2*np.outer(r,r)/(r@r)
check("closed under all 48 reflections (F4 root system)",
      all(tuple(np.round(refl(r)@s,6)) in F4set for r in F4 for s in F4))
Wv=[s*np.eye(4)[i] for i in range(4) for s in(1,-1)]
Sp=[np.array(s)/2. for s in itertools.product([1,-1],repeat=4)]
check("short roots == matter weights 8v+8s+8c",
      {tuple(np.round(w,6)) for w in Wv+Sp}==
      {tuple(np.round(r,6)) for r in shortr})

# --- bracket sector rules ----------------------------------------------
def rep(w):
    w=np.array(w)
    if abs(abs(w).max()-1)<1e-9 and np.count_nonzero(np.abs(w)>1e-9)==1:
        return 'v'
    if abs(abs(w).max()-0.5)<1e-9:
        return 's' if np.prod(np.sign(w))>0 else 'c'
    return 'L'
pat=set()
for a in shortr:
    for b in shortr:
        s=np.array(a)+b
        if tuple(np.round(s,6)) in F4set: pat.add((rep(a),rep(b),rep(s)))
check("[same rep, same rep] -> long root or zero only",
      all(p[2]=='L' for p in pat if p[0]==p[1]))
check("[8x, 8y] -> third rep only (triality fusion)",
      all(p[2]=={'v','s','c'}.difference({p[0],p[1]}).pop()
          for p in pat if p[0]!=p[1]))
check("[bond, matter] -> matter only",
      all(rep(np.array(a)+b)!='L' for a in longr for b in shortr
          if tuple(np.round(np.array(a)+b,6)) in F4set))

# --- Theorem 2: triality inner -----------------------------------------
key=lambda M: tuple(np.round(M.flatten(),6))
G={key(np.eye(4)):np.eye(4)}; fr=[np.eye(4)]
gens=[refl(r) for r in F4]
while fr:
    new=[]
    for M in fr:
        for g in gens:
            N=g@M; k=key(N)
            if k not in G: G[k]=N; new.append(N)
    fr=new
check("reflection group of the 48 roots has order 1152 = W(F4)",
      len(G)==1152)
n=np.array([1,1,1,0.])
A2set={tuple(np.round(r,6)) for r in longr
       if abs(np.array(r)@n)<1e-9 and abs(r[3])<1e-9}
fixers=[M for M in G.values()
        if np.allclose(np.linalg.matrix_power(M,3),np.eye(4))
        and not np.allclose(M,np.eye(4))
        and all(np.allclose(M@np.array(a),np.array(a)) for a in A2set)]
check("the twist rotation tau lies inside W(F4) (triality is inner)",
      len(fixers)==2)
tau=fixers[0]

# --- Theorem 3: grading and coweight charge ----------------------------
rho=np.array([1.,0.,-1.,0.])
dims=[2,1,1]
for a in map(np.array,A2set): dims[int(round(rho@a))%3]+=1
seen=set()
for r in list(longr)+list(shortr):
    k=tuple(np.round(r,6))
    if k in A2set or k in seen: continue
    orb=[np.array(r),tau@np.array(r),tau@tau@np.array(r)]
    for o in orb: seen.add(tuple(np.round(o,6)))
    assert sum(round(float(rho@x)) for x in orb)%3==0
    for kk in range(3): dims[kk]+=1
check("sigma-grading of the 52 has dimensions (16,18,18)", dims==[16,18,18])
a1=np.array([0,1,-1,0.]); a2=np.array([0,0,1,-1.])
a3=np.array([0,0,0,1.]);  a4=np.array([1,-1,-1,-1.])/2
S=np.array([a1,a2,a3,a4]).T
c=np.linalg.solve(S,np.array([1,1,0,0.]))
check("highest root e1+e2 has marks (2,3,4,2)", np.allclose(c,[2,3,4,2]))
counts={0:0,1:0,2:0}
for r in F4:
    m=np.linalg.solve(S,r)
    assert np.allclose(m,np.round(m))
    counts[int(round(m[1]))%3]+=1
check("mark-3 coweight counting gives roots (12,18,18): charge = "
      "alpha2-coefficient mod 3",
      counts=={0:12,1:18,2:18} and
      (counts[0]+4,counts[1],counts[2])==(16,18,18))

# --- fixed subalgebra su(3)+su(3): rank and root-vector count ----------
zero_proj=[r for r in shortr
           if np.allclose((np.eye(4)-np.outer(n/np.sqrt(3),n/np.sqrt(3))
           -np.outer(a3,a3))@np.array(r),0)]
check("rank-4 zero-weight sector: 2 Cartan + 2 short zero-projection "
      "orbits (6 roots)", len(zero_proj)==6)
check("h0 = 4 (Cartan) + 12 (root vectors) = 16 = su(3)+su(3)",
      dims[0]==16)

# --- 26-branching under su(3)+su(3) ------------------------------------
from collections import Counter
th=np.array([1,1,0,0.]); b1=np.array([0,1,-1,0.])
b3=np.array([0,0,0,1.]); b4=np.array([1,-1,-1,-1.])/2
pair=lambda mu,b: round(2*float(mu@b)/float(b@b))
W26=[np.array(w) for w in shortr]+[np.zeros(4),np.zeros(4)]
w3=[(1,0),(-1,1),(0,-1)]; w3b=[(-a,-b) for a,b in w3]
blocks={'3':Counter(),'3b':Counter(),'1':Counter()}
for mu in W26:
    cl=(pair(mu,b1),pair(mu,-th)); h=(pair(mu,b3),pair(mu,b4))
    tkey='3' if cl in w3 else ('3b' if cl in w3b else '1')
    blocks[tkey][h]+=1
w8=Counter([(1,1),(2,-1),(-1,2),(-2,1),(1,-2),(-1,-1),(0,0),(0,0)])
check("26 branching: colored blocks are irreducible bifundamentals "
      "(3,3bar)+(3bar,3)",
      blocks['3']==Counter({k:3 for k in w3b}) and
      blocks['3b']==Counter({k:3 for k in w3}))
check("26 branching: color singlets form the horizontal 8",
      blocks['1']==w8)
Sm=np.array([b1,np.array([0,0,1,-1.]),b3,b4]).T
qof=lambda mu: int(round(np.linalg.solve(Sm,mu)[1]))%3
check("charge table: (3,3bar) at q=2 (Q=-1/3), conjugate at q=1, "
      "octet at q=0",
      all(qof(mu)==2 for mu in W26 if (pair(mu,b1),pair(mu,-th)) in w3) and
      all(qof(mu)==1 for mu in W26 if (pair(mu,b1),pair(mu,-th)) in w3b) and
      all(qof(mu)==0 for mu in W26 if (pair(mu,b1),pair(mu,-th)) not in w3+w3b))


# ======================================================================
# Sections 6-8 on the EXPLICIT algebra f4 = so(9) + 16 (spinor)
# ======================================================================
def explicit_f4():
    X=np.array([[0,1],[1,0.]]); Z=np.array([[1,0],[0,-1.]]); I2=np.eye(2); E=np.array([[0,1],[-1,0.]])
    mats={'I':I2,'X':X,'Z':Z,'E':E}
    def kr(ws):
        r=np.array([[1.]])
        for w in ws: r=np.kron(r,mats[w])
        return r
    cands=[w for w in itertools.product('IXZE',repeat=4) if w.count('E')%2==0 and w!=('I',)*4]
    M_={w:kr(w) for w in cands}
    anti=lambda a,b: np.allclose(M_[a]@M_[b]+M_[b]@M_[a],0)
    best=[]
    def search(ch,st):
        nonlocal best
        if len(ch)>len(best): best=list(ch)
        if len(best)==9: return True
        for k in range(st,len(cands)):
            w=cands[k]
            if all(anti(w,c) for c in ch):
                ch.append(w)
                if search(ch,k+1): return True
                ch.pop()
        return False
    search([],0); G=[M_[w] for w in best]
    check("9 real symmetric anticommuting 16x16 gamma matrices",
          len(G)==9 and all(np.allclose(g,g.T) and np.allclose(g@g,np.eye(16)) for g in G)
          and all(np.allclose(a@b+b@a,0) for a,b in itertools.combinations(G,2)))
    pairs=list(itertools.combinations(range(9),2)); nS=len(pairs); DIM=nS+16
    def L(a,b):
        m=np.zeros((9,9)); m[a,b]=1; m[b,a]=-1; return m
    Lm=[L(a,b) for a,b in pairs]; Sm=[0.25*(G[a]@G[b]-G[b]@G[a]) for a,b in pairs]
    def unpack(v): return sum(v[k]*Lm[k] for k in range(nS)), v[nS:]
    cso9=lambda A: np.array([A[a,b] for a,b in pairs])
    rhoS=lambda A: sum(A[a,b]*Sm[k] for k,(a,b) in enumerate(pairs))
    def br(u,v):
        A,p=unpack(u); B,q=unpack(v)
        so=A@B-B@A+sum((p@Sm[k]@q)*Lm[k] for k in range(nS))
        return np.concatenate([cso9(so),rhoS(A)@q-rhoS(B)@p])
    rng=np.random.default_rng(3)
    jac=max(np.abs(br(x,br(y,z))+br(y,br(z,x))+br(z,br(x,y))).max()
            for x,y,z in [(rng.normal(size=DIM),rng.normal(size=DIM),rng.normal(size=DIM)) for _ in range(4)])
    check("f4 = so(9)+16 satisfies the Jacobi identity", jac<1e-10)
    ad=lambda u: np.array([br(u,np.eye(DIM)[k]) for k in range(DIM)]).T
    AD=[ad(b) for b in np.eye(DIM)]
    K=np.array([[np.trace(AD[i]@AD[j]) for j in range(DIM)] for i in range(DIM)])
    check("explicit algebra is semisimple (Killing form rank 52)", np.linalg.matrix_rank(K)==DIM)
    kidx=lambda a,b: pairs.index((a,b))
    Hs=[np.eye(DIM)[kidx(0,1)],np.eye(DIM)[kidx(2,3)],np.eye(DIM)[kidx(4,5)],np.eye(DIM)[kidx(6,7)]]
    Hads=[ad(h) for h in Hs]
    w,V=np.linalg.eig(sum(c*h for c,h in zip([1.0,0.37,0.1123,0.0419],Hads)))
    roots=[];vecs=[]
    for k in range(DIM):
        if abs(w[k])<1e-8: continue
        v=V[:,k]; roots.append(np.real(np.array([(Hads[i]@v)@v.conj()/(v@v.conj()) for i in range(4)])/1j)); vecs.append(v)
    roots=np.array(roots)
    want={tuple(np.round(r,6)) for r in longr+shortr}
    check("explicit roots are exactly the 48 roots of F4", {tuple(np.round(r,6)) for r in roots}==want)
    rootvec={tuple(np.round(r,6)):v for r,v in zip(roots,vecs)}
    Rt=lambda a: rootvec[tuple(np.round(np.array(a,float),6))]
    # tau in W(F4) fixing the color plane A2
    gens=[np.eye(4)-2*np.outer(a,a)/(a@a) for a in longr+shortr]
    key=lambda m: tuple(np.round(m,6).flatten()); Gp={key(np.eye(4)):np.eye(4)}; fr=[np.eye(4)]
    while fr:
        nw=[]
        for m in fr:
            for g in gens:
                Y=g@m
                if key(Y) not in Gp: Gp[key(Y)]=Y; nw.append(Y)
        fr=nw
    def order(m):
        Q=np.eye(4)
        for n in range(1,13):
            Q=Q@m
            if np.allclose(Q,np.eye(4)): return n
    ax=np.array([1,1,1,0.])
    A2=[r for r in longr if abs(r[3])<1e-9 and abs(r@ax)<1e-9]
    tau=[m for m in Gp.values() if order(m)==3 and all(np.allclose(m@r,r) for r in A2)][0]
    simple=[np.array(v,float) for v in ([0,1,-1,0],[0,0,1,-1],[0,0,0,1],[.5,-.5,-.5,-.5])]
    def cheval(a):
        e=Rt(a); f=Rt(-a); h=br(e,f); lam=(br(h,e)@e.conj())/(e@e.conj()); f=f*2/lam; return e,f,br(e,f)
    Ch=[cheval(a) for a in simple]; Ct=[cheval(tau@a) for a in simple]; rset=set(rootvec)
    out=[(tuple(np.round(a,6)),(i,)) for i,a in enumerate(simple)]; frn=list(out)
    while frn:
        nf=[]
        for r,w_ in frn:
            for i,a in enumerate(simple):
                nr=tuple(np.round(np.array(r)+a,6))
                if nr in rset and nr not in [q_[0] for q_ in out]:
                    out.append((nr,w_+(i,))); nf.append((nr,w_+(i,)))
        frn=nf
    def ev(w_,gen,k):
        x=gen[w_[0]][k]
        for i in w_[1:]: x=br(gen[i][k],x)
        return x
    src=[];dst=[]
    for r,w_ in out:
        for k in (0,1): src.append(ev(w_,Ch,k)); dst.append(ev(w_,Ct,k))
    for i in range(4): src.append(Ch[i][2]); dst.append(Ct[i][2])
    Tm=np.array(dst).T@np.linalg.inv(np.array(src).T)
    rho=np.array([1,0,-1,0.])
    Bm=np.array([*vecs,*[np.array(h,complex) for h in Hs]]).T
    Sig=Bm@np.diag(np.concatenate([np.exp(2j*np.pi*(roots@rho)/3),np.ones(4)]))@np.linalg.inv(Bm)@Tm
    x=rng.normal(size=DIM)+0j; y=rng.normal(size=DIM)+0j
    check("sigma is an automorphism of f4 of order 3",
          np.allclose(Sig@br(x,y),br(Sig@x,Sig@y)) and np.allclose(np.linalg.matrix_power(Sig,3),np.eye(DIM)))
    wq=np.exp(2j*np.pi/3); ev_=np.linalg.eigvals(Sig)
    check("explicit sigma-grading of f4 is (16,18,18)",
          tuple(int(np.sum(np.abs(ev_-z)<1e-6)) for z in (1,wq,wq*wq))==(16,18,18))
    so8=[kidx(a,b) for a,b in pairs if b<8]
    evso=np.linalg.eigvals(Sig[np.ix_(so8,so8)])
    check("sigma preserves so(8) and grades it (8,10,10)",
          np.allclose(Sig[np.ix_([k for k in range(DIM) if k not in so8],so8)],0)
          and tuple(int(np.sum(np.abs(evso-z)<1e-6)) for z in (1,wq,wq*wq))==(8,10,10))
    evs,EV=np.linalg.eig(Sig); F0,_=np.linalg.qr(EV[:,np.abs(evs-1)<1e-6]); n0=F0.shape[1]
    co=lambda v: np.linalg.lstsq(F0,v,rcond=None)[0]
    adF0=[np.array([co(br(F0[:,i],F0[:,j])) for j in range(n0)]).T for i in range(n0)]
    cols=[]
    for a in range(n0):
        for b in range(n0):
            Xm=np.zeros((n0,n0),complex); Xm[a,b]=1
            cols.append(np.concatenate([(Xm@A-A@Xm).flatten() for A in adF0]))
    Mm=np.array(cols).T; _,sv,Vt=np.linalg.svd(Mm); r_=np.linalg.matrix_rank(Mm,1e-8)
    comm=[v.conj().reshape(n0,n0) for v in Vt[r_:]]
    Cc=sum(np.random.default_rng(5).normal()*c for c in comm); cw,cv=np.linalg.eig(Cc)
    grp=np.isclose(cw,cw[0],atol=1e-6); ideals=[F0@cv[:,grp],F0@cv[:,~grp]]
    isideal=all(max(np.linalg.norm(br(F0[:,i],I[:,j])-I@np.linalg.lstsq(I,br(F0[:,i],I[:,j]),rcond=None)[0])
                    for i in range(n0) for j in range(I.shape[1]))<1e-8 for I in ideals)
    check("fixed algebra h0 = two commuting simple 8-dim ideals (su(3)+su(3))",
          len(comm)==2 and [I.shape[1] for I in ideals]==[8,8] and isideal and
          max(np.linalg.norm(br(ideals[0][:,i],ideals[1][:,j])) for i in range(8) for j in range(8))<1e-8)
    rng2=np.random.default_rng(11); ratio=[]
    for I in ideals:
        rs=[]
        for _ in range(3):
            xx=I@rng2.normal(size=8); Xa=ad(xx); a0=np.array([co(br(xx,F0[:,j])) for j in range(n0)]).T
            rs.append((np.trace(Xa@Xa)/np.trace(a0@a0)).real)
        ratio.append(np.mean(rs))
    check("embedding indices of the two factors are 1 and 2 (trace ratios 3 and 6)",
          sorted(np.round(ratio,6))==[3.0,6.0])
    Pso=np.zeros((DIM,DIM)); Pso[so8,so8]=1; Pm=np.eye(DIM)-Pso
    k0=n0-np.linalg.matrix_rank(Pm@F0,1e-8)
    g0=F0@np.linalg.svd(Pm@F0)[2][-k0:].conj().T
    cg=np.linalg.lstsq(np.hstack(ideals),g0,rcond=None)[0]
    check("Theorem (diagonal): h0 cap so(8) is 8-dim and projects isomorphically onto BOTH factors",
          k0==8 and np.linalg.matrix_rank(cg[:8],1e-8)==8 and np.linalg.matrix_rank(cg[8:],1e-8)==8)
    # ---- Theorem 4 (C = P) at the level of the algebra ----
    Rm=np.eye(9)
    for a_ in (1,3,5): Rm[a_,a_]=-1
    Spin=G[1]@G[3]@G[5]
    Ipin=np.array([np.concatenate([cso9(Rm@unpack(e_)[0]@Rm.T), Spin@unpack(e_)[1]]) for e_ in np.eye(DIM)]).T
    Iw=np.diag([-1,-1,-1,1.])
    def acts_as_I(Mx):
        return all(np.allclose(Mx@Rt(r), ((Mx@Rt(r))@Rt(Iw@r).conj())/(Rt(Iw@r)@Rt(Iw@r).conj())*Rt(Iw@r)) for r in roots)
    check("Pin(9) lift of spatial inversion is an automorphism acting as I on the roots, but not an involution",
          np.allclose(Ipin@br(x,y),br(Ipin@x,Ipin@y)) and acts_as_I(Ipin) and not np.allclose(Ipin@Ipin,np.eye(DIM)))
    Tt=Sig@Ipin@Sig@np.linalg.inv(Ipin)
    check("Pin(9) lift conjugates sigma to sigma^-1 only up to a Cartan phase (not exactly)",
          not np.allclose(Ipin@Sig@np.linalg.inv(Ipin),np.linalg.inv(Sig)) and
          all(np.allclose(Tt@Rt(r), ((Tt@Rt(r))@Rt(r).conj())/(Rt(r)@Rt(r).conj())*Rt(r)) for r in roots))
    AdT=lambda v: Bm@np.diag(np.concatenate([np.exp(1j*(roots@v)),np.ones(4)]))@np.linalg.inv(Bm)
    angs=np.array([np.angle((((Tt@Rt(a))@Rt(a).conj())/(Rt(a)@Rt(a).conj()))) for a in simple])
    phi_=np.linalg.solve(np.array(simple),angs); cow_=np.linalg.inv(np.array(simple))
    Cm=None
    for sg in (1,-1):
        for n in itertools.product(range(-3,4),repeat=4):
            rep=sg*phi_+2*np.pi*(cow_@np.array(n,float))
            for Mx in (tau-np.eye(4), np.eye(4)-tau):
                u_=np.linalg.lstsq(Mx,rep,rcond=None)[0]
                if not np.allclose(Mx@u_,rep,atol=1e-9): continue
                C_=AdT(u_)@Ipin
                if np.allclose(C_@Sig@np.linalg.inv(C_),np.linalg.inv(Sig)) and np.allclose(C_@C_,np.eye(DIM)):
                    Cm=C_; break
            if Cm is not None: break
        if Cm is not None: break
    ev3,EV3=np.linalg.eig(Sig); sc3={q_:EV3[:,np.abs(ev3-wq**q_)<1e-6] for q_ in (0,1,2)}
    mp=lambda A_,B_: np.linalg.matrix_rank(np.hstack([B_,Cm@A_]),1e-7)==np.linalg.matrix_rank(B_,1e-7)
    matidx=[k for k in range(DIM) if k not in so8]
    check("Theorem 4: an involutive lift C of inversion exists with C sigma C^-1 = sigma^-1 exactly",
          Cm is not None and acts_as_I(Cm))
    check("Theorem 4: C maps h_q onto h_-q and preserves the bond and matter sectors",
          Cm is not None and mp(sc3[0],sc3[0]) and mp(sc3[1],sc3[2]) and mp(sc3[2],sc3[1]) and
          np.allclose(np.eye(DIM)[matidx,:]@Cm@np.eye(DIM)[:,so8],0) and np.allclose(np.eye(DIM)[so8,:]@Cm@np.eye(DIM)[:,matidx],0))
    Lng=ideals[int(np.argmin(ratio))]
    def comm_dim(space,alg):
        M=np.vstack([np.array([br(space[:,k],alg[:,j]) for k in range(space.shape[1])]).T for j in range(alg.shape[1])])
        return space.shape[1]-np.linalg.matrix_rank(M,1e-8)
    check("Section 3 (twist frame): color su(3)_L has trivial commutant in so(8), and commutant su(3)_S (dim 8) in f4",
          comm_dim(np.eye(DIM)[:,so8],Lng)==0 and comm_dim(np.eye(DIM),Lng)==8)
    check("color su(3)_L combines bond and matter generators (both parts rank 8)",
          np.linalg.matrix_rank(Pso@Lng,1e-8)==8 and np.linalg.matrix_rank(Pm@Lng,1e-8)==8)

    # ---- Section 8: the two gradings (twist sigma vs mark-3 coweight) on the same bond-matter split ----
    SIMP=np.array(simple).T
    c2=np.array([round(np.linalg.solve(SIMP,r)[1]) for r in roots])
    Kc=Bm@np.diag(np.concatenate([wq**c2,np.ones(4)]))@np.linalg.inv(Bm)
    evK=np.linalg.eigvals(Kc)
    # Section 2: tau is outer on so(8) (not in the Weyl group of D4)
    def close4(gens):
        kf=lambda M: tuple(np.round(M,6).flatten()); Gp={kf(np.eye(4)):np.eye(4)}; fr=[np.eye(4)]
        while fr:
            nw=[]
            for M in fr:
                for g in gens:
                    Y=g@M
                    if kf(Y) not in Gp: Gp[kf(Y)]=Y; nw.append(Y)
            fr=nw
        return Gp
    rf4=lambda a: np.eye(4)-2*np.outer(a,a)/(a@a)
    WD4=close4([rf4(a) for a in longr])
    check("Section 2: |W(D4)|=192, [Aut(D4):W(D4)]=6, and tau lies outside W(D4) (outer/triality)",
          len(WD4)==192 and tuple(np.round(tau,6).flatten()) not in WD4)
    A2g=[r for r in longr if abs(r[3])<1e-9 and abs(r@np.array([1,1,1,0.]))<1e-9]
    uu=np.array([1,1,1,0])/np.sqrt(3); e4v=np.eye(4)[3]
    Mp=np.array([[uu@tau@uu, uu@tau@e4v],[e4v@tau@uu, e4v@tau@e4v]])
    Pc4=np.eye(4)-np.outer(uu,uu)-np.outer(e4v,e4v)
    orb=[r for r in longr if not any(np.allclose(r,a) for a in A2g)]
    check("Section 2: tau fixes the geometric A2 pointwise and rotates the orthogonal plane by 120 degrees",
          len(A2g)==6 and all(np.allclose(tau@r,r) for r in A2g) and abs(Mp[0,0]+0.5)<1e-9 and abs(abs(Mp[0,1])-np.sqrt(3)/2)<1e-9)
    check("Section 2: orbit sums are the color-plane projections, of squared length 2/3",
          all(np.allclose((r+tau@r+tau@tau@r)/3, Pc4@r) for r in orb) and abs((Pc4@orb[0])@(Pc4@orb[0])-2/3)<1e-9)
    check("Section 8: coweight grading is an order-3 automorphism grading f4 as (16,18,18), like sigma",
          np.allclose(Kc@br(x,y),br(Kc@x,Kc@y)) and np.allclose(np.linalg.matrix_power(Kc,3),np.eye(DIM))
          and tuple(int(np.sum(np.abs(evK-z)<1e-6)) for z in (1,wq,wq*wq))==(16,18,18))
    gso=lambda Op: tuple(int(np.sum(np.abs(np.linalg.eigvals(Op[np.ix_(so8,so8)])-z)<1e-6)) for z in (1,wq,wq*wq))
    check("Section 8: on so(8) the twist grades (8,10,10), the coweight grades (10,9,9)",
          gso(Sig)==(8,10,10) and gso(Kc)==(10,9,9))
    Chir=G[0]@G[1]@G[2]@G[3]@G[4]@G[5]@G[6]@G[7]; ew_,evc_=np.linalg.eigh(Chir)
    V8=np.zeros((DIM,8),complex); V8[[kidx(a_,8) for a_ in range(8)],range(8)]=1
    S8=np.zeros((DIM,8),complex); S8[nS:,:]=evc_[:,ew_>0]
    C8=np.zeros((DIM,8),complex); C8[nS:,:]=evc_[:,ew_<0]
    ins=lambda A_,B_: np.linalg.matrix_rank(np.hstack([B_,A_]),1e-7)==np.linalg.matrix_rank(B_,1e-7)
    def perm(Op):
        out={}
        for nm_,B_ in (("v",V8),("s",S8),("c",C8)):
            t_=[t for t,B2 in (("v",V8),("s",S8),("c",C8)) if ins(Op@B_,B2)]
            out[nm_]=t_[0] if t_ else "?"
        return out
    check("Section 8: the twist cycles 8v->8c->8s->8v; the coweight grading leaves each 8 in place",
          perm(Sig)=={"v":"c","s":"v","c":"s"} and perm(Kc)=={"v":"v","s":"s","c":"c"})
    EK,EVK=np.linalg.eig(Kc); F0k,_=np.linalg.qr(EVK[:,np.abs(EK-1)<1e-6]); nk=F0k.shape[1]
    cok=lambda v: np.linalg.lstsq(F0k,v,rcond=None)[0]
    adk=[np.array([cok(br(F0k[:,i],F0k[:,j])) for j in range(nk)]).T for i in range(nk)]
    colk=[]
    for a_ in range(nk):
        for b_ in range(nk):
            X_=np.zeros((nk,nk),complex); X_[a_,b_]=1
            colk.append(np.concatenate([(X_@A_-A_@X_).flatten() for A_ in adk]))
    Mk=np.array(colk).T; _,svk,Vtk=np.linalg.svd(Mk); rk=np.linalg.matrix_rank(Mk,1e-8)
    commk=[v.conj().reshape(nk,nk) for v in Vtk[rk:]]
    Ck=sum(np.random.default_rng(5).normal()*c for c in commk); cwk,cvk=np.linalg.eig(Ck)
    gk=np.isclose(cwk,cwk[0],atol=1e-6); idk=[F0k@cvk[:,gk],F0k@cvk[:,~gk]]
    rr=[]
    for I_ in idk:
        xx=I_@np.random.default_rng(2).normal(size=I_.shape[1]); Xa=ad(xx); a0=np.array([cok(br(xx,F0k[:,j])) for j in range(nk)]).T
        rr.append((np.trace(Xa@Xa)/np.trace(a0@a0)).real)
    Lk=idk[int(np.argmin(rr))]
    Psok=np.zeros((DIM,DIM)); Psok[so8,so8]=1; Pmk=np.eye(DIM)-Psok
    check("Section 8: under the coweight grading, color (the long factor) lies entirely inside so(8)",
          abs(min(rr)-3)<1e-6 and np.linalg.matrix_rank(Pmk@Lk,1e-8)==0 and np.linalg.matrix_rank(Psok@Lk,1e-8)==8)
    check("Section 3 (coweight frame): color's commutant is u(1)+u(1) (dim 2) in so(8), su(3)_S (dim 8) in f4",
          comm_dim(np.eye(DIM)[:,so8],Lk)==2 and comm_dim(np.eye(DIM),Lk)==8)

explicit_f4()

# ---- Theorem (color is the long factor): 26 branching under each candidate ----
from collections import Counter
aS=[np.array([0,1,-1,0.]),np.array([0,0,1,-1.]),np.array([0,0,0,1.]),np.array([.5,-.5,-.5,-.5])]
SmB=np.array(aS).T; qlab=lambda w: int(round(np.linalg.solve(SmB,w)[1]))%3
W26=list(shortr)+[np.zeros(4),np.zeros(4)]
cor=lambda r: 2*r/(r@r)
tab={(0,0):[(0,0)],(1,0):[(1,0),(-1,1),(0,-1)],(0,1):[(0,1),(1,-1),(-1,0)],
     (1,1):[(1,1),(-1,2),(2,-1),(0,0),(0,0),(1,-2),(-2,1),(-1,-1)]}
nm={(0,0):'1',(1,0):'3',(0,1):'3b',(1,1):'8'}
def dec(r1,r2,ws):
    C=Counter((int(round(w@cor(r1))),int(round(w@cor(r2)))) for w in ws); o=[]
    while sum(C.values()):
        hw=max((d for d in C if C[d]>0),key=lambda d:3*d[0]+3*d[1])
        for x_ in tab[hw]: C[x_]-=1
        o.append(nm[hw])
    return dict(Counter(o))
Lr=(np.array([0,1,-1,0.]),np.array([-1,-1,0,0.])); Sr=(np.array([0,0,0,1.]),np.array([.5,-.5,-.5,-.5]))
blk={k:[w for w in W26 if qlab(w)==k] for k in (0,1,2)}
check("long factor: Q=-1/3 -> 3 triplets, Q=+1/3 -> 3 antitriplets, Q=0 -> 8 singlets",
      dec(*Lr,blk[2])=={'3':3} and dec(*Lr,blk[1])=={'3b':3} and dec(*Lr,blk[0])=={'1':8})
check("short factor: neutral sector is a color octet (rejected as color)", dec(*Sr,blk[0])=={'8':1})
from fractions import Fraction as Fr
tri={'1':0,'3':1,'3b':2,'8':0}
qrep={2:-1,1:1,0:0}
rel=all((Fr(qrep[k],3)-Fr(-tri[c],3))%1==0 for k in (0,1,2) for c in dec(*Lr,blk[k]))
check("Sections 8,10: under su(3)_L every block of the 26 obeys Q = -t/3 (mod 1), the SM charge-triality relation", rel)
diag_viol=any((Fr(qrep[k],3)-Fr(-tri[c],3))%1!=0 for k in (1,2) for c in ('8',))
check("within the bond algebra (twisted su(3): octets, t=0, at Q=+-1/3) the relation is violated", diag_viol)
Pc=lambda vv: (lambda B: B@B.T)(np.linalg.qr(np.array(vv).T)[0][:,:2])
Tidx=lambda vv,r2: sum((Pc(vv)@w)@(Pc(vv)@w) for w in W26)/(2*r2)
uu=np.array([1,1,1,0])/np.sqrt(3); ee=np.eye(4)[3]; cpl=np.linalg.svd(np.eye(4)-np.outer(uu,uu)-np.outer(ee,ee))[0][:,:2]
check("indices on the 26: long 3, short 6, twisted su(3) 9 = 3+6 (the diagonal)",
      abs(Tidx(list(Lr),2)-3)<1e-9 and abs(Tidx(list(Sr),1)-6)<1e-9 and abs(Tidx([cpl[:,0],cpl[:,1]],2/3)-9)<1e-9)
# Section 8 "Where matter lives": the 26 is the smallest irrep; the adjoint's charged sectors are also color triplets
tab6={**tab,(2,0):[(2,0),(0,1),(-2,2),(1,-1),(-1,0),(0,-2)],(0,2):[(0,2),(1,0),(2,-2),(-1,1),(0,-1),(-2,0)]}
nm6={**nm,(2,0):'6',(0,2):'6b'}
def dec2(ws):
    C=Counter(tuple(int(round(w@cor(r))) for r in (Lr[0],Lr[1],Sr[0],Sr[1])) for w in ws); o=[]
    while sum(C.values()):
        hw=max((d for d in C if C[d]>0),key=lambda d:(3*d[0]+3*d[1])*100+(3*d[2]+3*d[3]))
        for x_ in tab6[hw[:2]]:
            for y_ in tab6[hw[2:]]: C[(x_[0],x_[1],y_[0],y_[1])]-=1
        o.append((nm6[hw[:2]],nm6[hw[2:]]))
    return sorted(o)
W52=list(longr)+list(shortr)+[np.zeros(4)]*4
b52={k:dec2([w for w in W52 if qlab(w)==k]) for k in (0,1,2)}
check("adjoint 52 by label: q=0 (8,1)+(1,8); q=-1 (3,6); q=+1 (3b,6b)",
      b52[0]==[('1','8'),('8','1')] and b52[2]==[('3','6')] and b52[1]==[('3b','6b')])
pos=[r for r in list(longr)+list(shortr) if (np.linalg.solve(SmB,r)>-1e-9).all()]; rhoF=sum(pos)/2
corF=[2*x/(x@x) for x in aS]; fwF=[np.linalg.solve(np.array(corF),np.eye(4)[:,i]) for i in range(4)]
dimF=lambda lam: round(np.prod([((lam+rhoF)@r)/(rhoF@r) for r in pos]))
dims=[dimF(w) for w in fwF]
check("Weyl dimensions of the fundamentals are 52, 1274, 273, 26: the 26 is the smallest irrep",
      sorted(dims)==[26,52,273,1274])
check("the 26's highest weight is a short root: its nonzero weights are the matter weights",
      any(np.allclose(fwF[dims.index(26)],r) for r in shortr))
# Section 10: isotropy is protected to sixth order (invariant degrees of the point groups)
def close_group(gens):
    kf=lambda M: tuple(np.round(M,6).flatten()); Gp={kf(np.eye(4)):np.eye(4)}; fr=[np.eye(4)]
    while fr:
        nw=[]
        for M in fr:
            for g in gens:
                Y=g@M
                if kf(Y) not in Gp: Gp[kf(Y)]=Y; nw.append(Y)
        fr=nw
    return list(Gp.values())
rf=lambda a: np.eye(4)-2*np.outer(a,a)/(a@a)
WF4=close_group([rf(a) for a in list(longr)+list(shortr)])
WB4=close_group([rf(np.eye(4)[i]) for i in range(4)]+[rf(np.eye(4)[i]-np.eye(4)[j]) for i,j in itertools.permutations(range(4),2)])
def molien(Gp,N=7):
    c=np.zeros(N)
    for g in Gp:
        ser=np.zeros(N,dtype=complex); ser[0]=1
        for lam in np.linalg.eigvals(g):
            ser=np.convolve(ser,np.array([lam**k for k in range(N)]))[:N]
        c=c+np.real(ser)
    return np.round(c/len(Gp)).astype(int)
mf,mb=molien(WF4),molien(WB4)
from itertools import combinations_with_replacement as cwr_
def inv_dim_brute(Gp,deg):
    mons=list(cwr_(range(4),deg)); idx={m:i for i,m in enumerate(mons)}; n=len(mons)
    P=np.zeros((n,n))
    for g in Gp:
        Mm=np.zeros((n,n))
        for j,m in enumerate(mons):
            poly={(): 1.0}
            for var in m:
                new={}
                for mono,c in poly.items():
                    for k in range(4):
                        if abs(g[var,k])<1e-12: continue
                        nm=tuple(sorted(mono+(k,))); new[nm]=new.get(nm,0.0)+c*g[var,k]
                poly=new
            for mono,c in poly.items(): Mm[idx[mono],j]+=c
        P+=Mm
    return int(round(np.trace(P/len(Gp))))
check("Section 11 proof: brute-force averaging over monomials agrees with the Molien series for W(F4) (degrees 2,4,6)",
      (inv_dim_brute(WF4,2),inv_dim_brute(WF4,4),inv_dim_brute(WF4,6))==(mf[2],mf[4],mf[6]))
check("Section 11: Aut(D4)=W(F4) has order 1152 and the hypercubic group W(B4) has order 384",
      len(WF4)==1152 and len(WB4)==384)
check("Section 11: invariants of W(F4) in degrees 2,4,6 are 1,1,2 - no quartic anisotropy on D4",
      (mf[2],mf[4],mf[6])==(1,1,2))
# Section 11: the 3D slice is cubic-anisotropic at fourth order; the 24 D4 roots are isotropic
def beta_of(bonds,dim):
    T=np.zeros((dim,)*4)
    for n in bonds: T+=np.einsum('i,j,k,l->ijkl',n,n,n,n)
    return T[0,0,0,0]-3*T[0,0,1,1], T[0,0,0,0], T[0,0,1,1]
fcc12=[np.array(v,float)/np.sqrt(2) for v in [(a,b,0) for a in(1,-1) for b in(1,-1)]+[(a,0,b) for a in(1,-1) for b in(1,-1)]+[(0,a,b) for a in(1,-1) for b in(1,-1)]]
d4_24=[r/np.linalg.norm(r) for r in longr]
b3,t3a,t3b=beta_of(fcc12,3); b4,t4a,t4b=beta_of(d4_24,4)
# Section 11: triality is what protects isotropy; W(D4) alone admits a quartic anisotropy
WD4r=close_group([rf(a) for a in longr])
mD=molien(WD4r)
check("Section 11: without triality (W(D4), order 192) the invariants in degrees 2,4,6 are 1,3,4: quartic anisotropy exists",
      len(WD4r)==192 and (mD[2],mD[4],mD[6])==(1,3,4))
check("Section 11: W(F4) basic invariant degrees 2,6,8,12 multiply to the group order 1152",
      2*6*8*12==1152 and len(WF4)==1152)

check("Section 11: the 12 FCC slice bonds are cubic-anisotropic at fourth order (beta=-1)",
      abs(t3a-2)<1e-9 and abs(t3b-1)<1e-9 and abs(b3+1)<1e-9)
check("Section 11: all 24 D4 roots are isotropic at fourth order (beta=0): the temporal bonds cancel it",
      abs(t4a-3)<1e-9 and abs(t4b-1)<1e-9 and abs(b4)<1e-9)
check("Section 11: invariants of W(B4) in degrees 2,4,6 are 1,2,3 - the cubic lattice admits quartic anisotropy",
      (mb[2],mb[4],mb[6])==(1,2,3))

# conjugacy of color to the geometric A2: all long-root A2 subsystems form one W(F4) orbit
K_=lambda r: tuple(np.round(r,6))
subs=set()
for x_,y_ in itertools.combinations(longr,2):
    if abs(x_@y_+1)<1e-9: subs.add(frozenset(K_(v) for v in (x_,-x_,y_,-y_,x_+y_,-(x_+y_))))
gensW=[np.eye(4)-2*np.outer(a,a)/(a@a) for a in longr+shortr]
keyW=lambda m: tuple(np.round(m,6).flatten()); GW={keyW(np.eye(4)):np.eye(4)}; frW=[np.eye(4)]
while frW:
    nw=[]
    for m in frW:
        for g in gensW:
            Y=g@m
            if keyW(Y) not in GW: GW[keyW(Y)]=Y; nw.append(Y)
    frW=nw
st=next(iter(subs)); orb={frozenset(K_(m@np.array(v)) for v in st) for m in GW.values()}
geo=frozenset(K_(r) for r in longr if abs(r[3])<1e-9 and abs(r@np.array([1,1,1,0.]))<1e-9)
check("16 long-root A2's form one W(F4) orbit containing the geometric A2 and the long factor",
      len(subs)==16 and orb==subs and geo in subs)

print("\nVERDICT:","ALL PASS" if ok else "FAILURES PRESENT")
