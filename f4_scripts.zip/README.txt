Verification script for Sections 4-6 (with Theorem 6, and checks for
Sections 2, 8 and 9) of:
  "Quantum Numbers of Color and Charge from the Full F4 Algebra of a
   Bell-Pair Lattice Vacuum"
  (R. Kulkarni, 2026)

verify_f4_paper.py   57 labeled checks: closure of bonds and matter
                     into the F4 root system, inner triality, the
                     sigma- and coweight gradings, and, on an explicit
                     realization f4 = so(9)+16, the fixed subalgebra
                     su(3)_L + su(3)_S, the twisted su(3) as its
                     diagonal, color as the long factor, the 26
                     branching, the conjugacy of color to the
                     geometric A2, the comparison of the twist and
                     coweight gradings (Section 6), and the isotropy
                     invariants (Section 9).

Requirements: Python 3 with numpy.   Run: python3 verify_f4_paper.py
Expected:     57x PASS, then ALL PASS.   Runtime: under a minute.
Sections 2, 3, 5, 6.1 and 7 are checked by charge_scripts.zip.
