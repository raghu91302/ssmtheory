Verification scripts for:
  "The Vacuum-Matter Algebra Is f4: Inner Triality, Charge as a
   Coweight, and an Emergent Second su(3)"  (R. Kulkarni, 2026)

Contents:
  verify_f4_paper.py   reproduces every computation in the paper
                       (13 labeled checks keyed to the theorems).

Requirements: Python 3 with numpy. No other dependencies.
Run:          python3 verify_f4_paper.py
Expected:     13x PASS, then ALL PASS.
Runtime:      under a minute (the 48x48 reflection closure and the
              W(F4) generation dominate).
