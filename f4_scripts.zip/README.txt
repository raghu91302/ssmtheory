Verification script for Sections 6-8 (and the algebra-level
form of Theorem 4) of:
  "From D4 to F4: Color, Matter, and Charge from One Triality Twist"
  (R. Kulkarni, 2026)

verify_f4_paper.py   46 labeled checks: closure of bonds and matter
                     into the F4 root system, inner triality, the
                     sigma- and coweight gradings, and, on an explicit
                     realization f4 = so(9)+16, the fixed subalgebra
                     su(3)_L + su(3)_S, the twisted su(3) as its
                     diagonal, color as the long factor, the 26
                     branching, the conjugacy of color to the
                     geometric A2, and the comparison of the twist
                     and coweight gradings (Section 8).

Requirements: Python 3 with numpy.   Run: python3 verify_f4_paper.py
Expected:     46x PASS, then ALL PASS.   Runtime: under a minute.
Sections 2-5 are checked by charge_scripts.zip.
