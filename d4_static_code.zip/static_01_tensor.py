#!/usr/bin/env python3
"""Section 2, Table 1: rank-four bond tensors.

Shows that neither the FCC in-slice bonds nor the projected cross-slice bonds are
rank-four isotropic, and that their sum -- the static D4 operator -- is isotropic
exactly.  Also reproduces the deviations of the three control lattices.

    python3 static_01_tensor.py
"""
import numpy as np, itertools as it

def T4(V):
    V = np.asarray(V, float)
    return np.einsum('ni,nj,nk,nl->ijkl', V, V, V, V)

def deviation(V):
    T = T4(V); d = np.eye(3)
    S = (np.einsum('ij,kl->ijkl', d, d) + np.einsum('ik,jl->ijkl', d, d)
         + np.einsum('il,jk->ijkl', d, d))
    a = T[0, 0, 0, 0] / 3.0
    return T[0, 0, 0, 0], T[0, 0, 1, 1], np.abs(T - a * S).max()

# D4 nearest neighbours, split by the temporal component (x_4 designated as time)
N = []
for mu, nu in it.combinations(range(4), 2):
    for s1 in (1, -1):
        for s2 in (1, -1):
            v = [0, 0, 0, 0]; v[mu] = s1; v[nu] = s2; N.append(v)
N = np.array(N, float)
inslice = np.array([n[:3] for n in N if n[3] == 0])
cross = np.array([n[:3] for n in N if n[3] != 0])

print("D4 nearest neighbours: %d = %d in-slice + %d cross-slice"
      % (len(N), len(inslice), len(cross)))
print()
print("TABLE 1  rank-four bond tensors")
print("  %-42s %6s %8s %8s %10s" % ("bond set", "count", "T_1111", "T_1122", "|T-aS|max"))
for lab, V in (("FCC in-slice, +-e_i+-e_j", inslice),
               ("cross-slice projections, +-e_i (weight 2)", cross),
               ("static D4, both", np.vstack([inslice, cross]))):
    a, b, dev = deviation(V)
    print("  %-42s %6d %8.1f %8.1f %10.3f" % (lab, len(V), a, b, dev))
print()
print("  isotropy requires T_1111 = 3 T_1122; the sum satisfies it exactly.")
print()
print("CONTROL LATTICES (Table 2)")
ctl = {'sc':  [d for d in it.product((-1,0,1), repeat=3) if sum(abs(x) for x in d) == 1],
       'bcc': [d for d in it.product((-1,1), repeat=3)],
       'fcc': [d for d in it.product((-1,0,1), repeat=3) if sum(abs(x) for x in d) == 2]}
for k in ('sc', 'bcc', 'fcc'):
    a, b, dev = deviation(ctl[k])
    print("  %-4s K=%2d  T_1111=%5.1f  T_1122=%5.1f  Delta = |T-aS|/T_1111 = %.4f"
          % (k.upper(), len(ctl[k]), a, b, dev / a))
