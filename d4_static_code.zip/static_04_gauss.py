#!/usr/bin/env python3
"""Section 5: the monopole equals the integrated source, however distributed.

Solves the lattice Poisson equation on the FCC slice for the same total weight
arranged three different ways, and shows the 1/r coefficient is identical.

    python3 static_04_gauss.py
"""
import numpy as np, itertools as it
import scipy.sparse as sp, scipy.sparse.linalg as spl

def fcc_ball(R):
    pts = [v for v in it.product(range(-R-1, R+2), repeat=3)
           if sum(v) % 2 == 0 and sum(x*x for x in v) <= R*R]
    P = np.array(sorted(pts), float)
    idx = {tuple(map(int, p)): i for i, p in enumerate(P)}
    nb = [d for d in it.product((-1,0,1), repeat=3) if sum(abs(x) for x in d) == 2]
    rows=[];cols=[];vals=[]
    for i, p in enumerate(P):
        deg = 0
        for d in nb:
            q = tuple(int(p[k])+d[k] for k in range(3))
            if q in idx:
                rows.append(i); cols.append(idx[q]); vals.append(1.0); deg += 1
        rows.append(i); cols.append(i); vals.append(-float(deg))
    L = sp.coo_matrix((vals, (rows, cols)), shape=(len(P), len(P))).tocsr()
    return P, idx, L, np.linalg.norm(P, axis=1)

if __name__ == "__main__":
    P, idx, L, r = fcc_ball(14)
    n = len(P); outer = r >= 12.4; free = np.where(~outer)[0]
    solve = spl.factorized(L[free][:, free].tocsc())
    def monopole(sites, ws):
        rho = np.zeros(n)
        for s, w in zip(sites, ws): rho[s] += w
        phi = np.zeros(n); phi[free] = solve(rho[free])
        sel = (r > 4) & (r < 9) & (~outer)
        A = np.vstack([1.0/r[sel], np.ones(sel.sum())]).T
        c, *_ = np.linalg.lstsq(A, phi[sel], rcond=None)
        return c[0], rho.sum()
    c0 = idx[(0,0,0)]
    tet = [c0] + [idx[t] for t in [(1,1,0),(1,0,1),(0,1,1)] if t in idx]
    print("GAUSS'S LAW ON THE LATTICE: monopole vs how the source is distributed")
    print("   configuration                        total     A (1/r coefficient)")
    for lab, ss, ws in (("unit point source",        [c0], [1.0]),
                        ("weight 1836 at one site",  [c0], [1836.0]),
                        ("1836 spread evenly over 4",tet,  [459.0]*len(tet)),
                        ("1836 spread 1000/500/300/36", tet, [1000.,500.,300.,36.])):
        A, tot = monopole(ss, ws)
        print("   %-34s %9.1f   %11.5f" % (lab, tot, A))
    print()
    print("   the coefficient depends on the total and on nothing else.")
