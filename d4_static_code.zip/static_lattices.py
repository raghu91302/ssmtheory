import numpy as np, itertools as it
import scipy.sparse as sp, scipy.sparse.linalg as spl

def build(kind,R):
    if kind=='fcc':
        pts=[v for v in it.product(range(-R-1,R+2),repeat=3)
             if sum(v)%2==0 and sum(x*x for x in v)<=R*R]
        nb=[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==2]
        scale=np.sqrt(2.0)
    elif kind=='sc':
        pts=[v for v in it.product(range(-R-1,R+2),repeat=3) if sum(x*x for x in v)<=R*R]
        nb=[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==1]
        scale=1.0
    elif kind=='d4s':
        # static D4: FCC sites, in-slice bonds (+-ei+-ej) AND the spatial
        # projections of the 12 cross-slice bonds (+-ei, each twice)
        pts=[v for v in it.product(range(-R-1,R+2),repeat=3)
             if sum(v)%2==0 and sum(x*x for x in v)<=R*R]
        nb=[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==2]
        scale=np.sqrt(2.0)
    elif kind=='bcc':
        pts=[v for v in it.product(range(-R-1,R+2),repeat=3)
             if (v[0]%2)==(v[1]%2)==(v[2]%2) and sum(x*x for x in v)<=R*R]
        nb=[d for d in it.product((-1,1),repeat=3)]
        scale=np.sqrt(3.0)
    P=np.array(sorted(pts),float); idx={tuple(map(int,p)):i for i,p in enumerate(P)}
    extra=[]
    if kind=='d4s':
        # cross-slice bonds project to +-e_i but connect DIFFERENT slices; within a
        # single slice their static contribution is a hop of +-e_i with weight 2.
        # +-e_i leaves the FCC sublattice, so the static operator acts on the full
        # integer lattice; we therefore realise it on Z^3 with both bond sets.
        pass
    rows=[];cols=[];vals=[]
    for i,p in enumerate(P):
        deg=0
        for d in nb:
            q=tuple(int(p[k])+d[k] for k in range(3))
            if q in idx: rows.append(i);cols.append(idx[q]);vals.append(1.0); deg+=1
        rows.append(i);cols.append(i);vals.append(-float(deg))
    L=sp.coo_matrix((vals,(rows,cols)),shape=(len(P),len(P))).tocsr()
    return P,idx,L,np.linalg.norm(P,axis=1),len(nb),scale

def rank4(kind):
    if kind=='fcc': N=[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==2]
    if kind=='sc':  N=[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==1]
    if kind=='bcc': N=[d for d in it.product((-1,1),repeat=3)]
    N=np.array(N,float)
    T=np.einsum('ni,nj,nk,nl->ijkl',N,N,N,N)
    d=np.eye(3)
    S=np.einsum('ij,kl->ijkl',d,d)+np.einsum('ik,jl->ijkl',d,d)+np.einsum('il,jk->ijkl',d,d)
    a=T[0,0,0,0]/S[0,0,0,0]
    return T[0,0,0,0], T[0,0,1,1], T[0,0,0,0]/max(T[0,0,1,1],1e-30), np.abs(T-a*S).max()

def anis(kind,R,bands=((3,5),(5,7),(7,9),(9,12))):
    P,idx,L,r,K,scale=build(kind,R)
    n=len(P); Rb=R-1.6; outer=r>=Rb; free=np.where(~outer)[0]
    solve=spl.factorized(L[free][:,free].tocsc())
    rho=np.zeros(n); rho[idx[(0,0,0)]]=1.0
    phi=np.zeros(n); phi[free]=solve(rho[free])
    out=[]
    for lo,hi in bands:
        sel=(r>lo)&(r<hi)&(~outer)
        if sel.sum()<60: out.append(None); continue
        X=np.vstack([1.0/r[sel],np.ones(sel.sum())]).T
        c,*_=np.linalg.lstsq(X,phi[sel],rcond=None)
        res=phi[sel]-X@c
        out.append((0.5*(lo+hi),c[0],np.std(res)/np.abs(phi[sel]).mean(),sel.sum()))
    return out,K
