#!/usr/bin/env python3
"""Sections 4: the Newtonian potential of the static D4 operator, and the
control series over SC, BCC and the bare FCC slice.

    python3 static_03_potential.py        # a few minutes at R=24
"""
import numpy as np, itertools as it
import scipy.sparse as sp, scipy.sparse.linalg as spl

def build_d4static(R):
    """Static (omega=0) D4 operator on a time-independent field.
    Lives on Z^3: FCC bonds +-ei+-ej weight 1 (same parity),
    plus projected cross-slice bonds +-ei weight 2 (opposite parity)."""
    pts=[v for v in it.product(range(-R-1,R+2),repeat=3) if sum(x*x for x in v)<=R*R]
    P=np.array(sorted(pts),float); idx={tuple(map(int,p)):i for i,p in enumerate(P)}
    nb12=[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==2]
    nb6 =[d for d in it.product((-1,0,1),repeat=3) if sum(abs(x) for x in d)==1]
    rows=[];cols=[];vals=[]
    for i,p in enumerate(P):
        deg=0.0
        for d in nb12:
            q=tuple(int(p[k])+d[k] for k in range(3))
            if q in idx: rows.append(i);cols.append(idx[q]);vals.append(1.0); deg+=1.0
        for d in nb6:
            q=tuple(int(p[k])+d[k] for k in range(3))
            if q in idx: rows.append(i);cols.append(idx[q]);vals.append(2.0); deg+=2.0
        rows.append(i);cols.append(i);vals.append(-deg)
    L=sp.coo_matrix((vals,(rows,cols)),shape=(len(P),len(P))).tocsr()
    return P,idx,L,np.linalg.norm(P,axis=1)

def anis_d4(R,bands=((4,6),(6,8),(8,10),(10,12),(12,15))):
    P,idx,L,r=build_d4static(R)
    n=len(P); Rb=R-1.6; outer=r>=Rb; free=np.where(~outer)[0]
    solve=spl.factorized(L[free][:,free].tocsc())
    rho=np.zeros(n); rho[idx[(0,0,0)]]=1.0
    phi=np.zeros(n); phi[free]=solve(rho[free])
    out=[]
    for lo,hi in bands:
        sel=(r>lo)&(r<hi)&(~outer)
        if sel.sum()<60: continue
        X=np.vstack([1.0/r[sel],np.ones(sel.sum())]).T
        c,*_=np.linalg.lstsq(X,phi[sel],rcond=None)
        res=phi[sel]-X@c
        out.append((0.5*(lo+hi),c[0],np.std(res)/np.abs(phi[sel]).mean(),int(sel.sum())))
    return out


if __name__ == "__main__":
    import sys
    from static_lattices import anis, rank4
    print("STATIC D4 OPERATOR (ball R=24)")
    print("    r        A          anisotropy")
    for o in anis_d4(24, bands=((4,6),(6,8),(8,10),(10,13))):
        print("  %5.1f   %10.5f   %.3e" % (o[0], o[1], o[2]))
    print()
    print("CONTROL LATTICES (ball R=20)")
    for k in ('fcc','sc','bcc'):
        out, K = anis(k, 20, bands=((4,6),(6,8),(8,10),(10,12)))
        dev = rank4(k)[3]/rank4(k)[0]
        s = "  ".join("r~%.0f:%.2e" % (o[0], o[2]) for o in out if o)
        print("  %-4s K=%2d Delta=%.3f   %s" % (k.upper(), K, dev, s))
