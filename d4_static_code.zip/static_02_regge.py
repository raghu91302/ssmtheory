#!/usr/bin/env python3
"""Section 3: the Regge action reduces to the static D4 Laplacian.

Evaluates the second variation of the Regge action on a static conformal
perturbation and compares it with the quadratic form of the static (omega=0)
D4 operator.  The ratio tends to -1; off-axis deviations fall as |k|^4.

    python3 static_02_regge.py          # L = 6, 8, 10 (a few minutes at L=10)
"""
import numpy as np, itertools as it, sys
from static_d4_complex import PeriodicD4
from static_d4_engine import PeriodicEngine

N = []
for mu, nu in it.combinations(range(4), 2):
    for s1 in (1, -1):
        for s2 in (1, -1):
            v = [0, 0, 0, 0]; v[mu] = s1; v[nu] = s2; N.append(np.array(v, float))
TS = [4, 1, 0]

def ratios(L, dirs=([1,0,0,0], [1,1,0,0], [1,1,1,0], [1,1,1,1])):
    cx = PeriodicD4(L=L, spine='axis0')
    pe = PeriodicEngine(cx).build_derivs()
    pts = np.array([list(v) for v in cx.verts], float)
    X = np.zeros((pe.ne, 4))
    for i, (a, b, d) in enumerate(cx.edges):
        X[i] = pts[a] + np.array(d) / 2.0
    L0 = cx.L0

    def S2(x):
        v = x[pe.pair]; dA = pe.dA[pe.owner]
        return float((np.einsum('pi,pi->p', dA, v[:, TS])
                      * (-np.einsum('pi,pi->p', pe.dth, v))).sum())

    out = []
    for kv in dirs:
        k = 2 * np.pi / L * np.array(kv, float)
        s = S2(2 * np.cos(X @ k) * L0) / cx.nv                  # Regge, static conformal
        lam = sum(np.cos(k @ n) - 1 for n in N)                 # static D4 Laplacian
        out.append((str(kv), float(np.linalg.norm(k)), s / lam))
    return out

if __name__ == "__main__":
    Ls = [int(a) for a in sys.argv[1:]] or [6, 8, 10]
    store = {}
    print("S2_Regge / (phi^T L_stat phi)   -- should tend to -1")
    for L in Ls:
        rows = ratios(L); store[L] = rows
        print("  L=%2d (k_min=%.4f): " % (L, 2 * np.pi / L)
              + "  ".join("%s %.6f" % (r[0], r[2]) for r in rows), flush=True)
    print()
    print("off-axis power law (the O(k^4) that rank-four isotropy predicts):")
    for name in ('[1, 1, 0, 0]', '[1, 1, 1, 0]'):
        ks = []; ds = []
        for L in Ls:
            for r in store[L]:
                if r[0] == name:
                    ks.append(r[1]); ds.append(abs(r[2] + 1))
        if len(ks) > 1:
            p = np.polyfit(np.log(ks), np.log(ds), 1)
            print("   %-14s deviation ~ |k|^(%.3f)" % (name, p[0]))
