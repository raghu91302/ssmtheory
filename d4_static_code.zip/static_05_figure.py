import json, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],
 'mathtext.fontset':'dejavuserif','font.size':9,'axes.labelsize':9,'axes.titlesize':9.5,
 'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'axes.linewidth':0.7,
 'lines.linewidth':1.3,'figure.dpi':200,'savefig.dpi':400,'axes.grid':True,
 'grid.alpha':0.18,'grid.linewidth':0.5})
NAVY,RED,GREEN,GREY='#1f4e79','#c0392b','#1e8449','#8a8a8a'
d=json.load(open('newton_data.json'))
d4=json.load(open('d4_anis.json'))
rat=json.load(open('ratio.json'))
fig,ax=plt.subplots(1,3,figsize=(9.6,2.9))

# (a) ratio -> -1 : off-axis deviation vs |k|, power law k^4
for name,c,m,lab in (('[1, 1, 0, 0]',NAVY,'s','$k\\parallel[1100]$'),
                     ('[1, 1, 1, 0]',GREEN,'o','$k\\parallel[1110]$')):
    kk=[];vv=[]
    for L in ('6','8','10'):
        for r in rat[L]:
            if r[0]==name: kk.append(r[1]); vv.append(abs(r[2]+1))
    o=np.argsort(kk); kk=np.array(kk)[o]; vv=np.array(vv)[o]
    ax[0].loglog(kk,vv,m+'-',color=c,ms=5,mec='white',mew=0.6,label=lab)
xs=np.linspace(0.85,1.85,40)
ax[0].loglog(xs,1.35e-2*(xs/1.481)**4,'--',color='0.5',lw=1.0,label=r'$\propto|k|^{4}$')
ax[0].set_xlabel(r'$|k|$')
ax[0].set_ylabel('deviation of the ratio from $-1$')
ax[0].set_title('(a) Regge static sector $=$\nstatic $D_4$ Laplacian')
ax[0].legend(frameon=False,loc='lower right',handletextpad=0.4,labelspacing=0.25)
ax[0].text(0.88,2.2e-2,r'exact along $[1000]$, $[1111]$',fontsize=7.3,color='0.35')

# (b) anisotropy of the potential
for k,c,m,lab in (('fcc',NAVY,'s','FCC slice only'),('sc',GREY,'v','SC'),('bcc',RED,'^','BCC')):
    r=np.array(d[k]['r']); a=np.array(d[k]['anis'])
    ax[1].loglog(r,a,m+'-',color=c,ms=4.2,mec='white',mew=0.5,label=lab,alpha=0.85)
r4=np.array(d4['r']); a4=np.array(d4['anis'])
ax[1].loglog(r4,a4,'o-',color=GREEN,ms=5,mec='white',mew=0.7,label=r'static $D_4$',zorder=5)
ax[1].set_xlabel(r'$r$  (lattice units)'); ax[1].set_ylabel('angular anisotropy of $\\phi$')
ax[1].set_title('(b) isotropy of the\nNewtonian potential')
ax[1].legend(frameon=False,loc='lower left',handletextpad=0.4,labelspacing=0.25)

# (c) anisotropy vs rank-4 deviation
dev=[d[k]['dev'] for k in ('fcc','sc','bcc')]+[0.0]
an9=[d[k]['anis'][int(np.argmin(np.abs(np.array(d[k]['r'])-9)))] for k in ('fcc','sc','bcc')]
an9=an9+[float(a4[int(np.argmin(np.abs(r4-9)))])]
cols=[NAVY,GREY,RED,GREEN]; mk=['s','v','^','o']; labs=['FCC','SC','BCC',r'static $D_4$']
for x,y,c,m,l in zip(dev,an9,cols,mk,labs):
    ax[2].plot(x,y,m,color=c,ms=8,mec='white',mew=0.8,label=l)
xs=np.linspace(0,0.72,50)
sl=np.mean([y/x for x,y in zip(dev[:3],an9[:3])])
ax[2].plot(xs,sl*xs,'-',color='0.55',lw=1.0,zorder=0)
ax[2].set_xlim(-0.03,0.72); ax[2].set_ylim(-3e-4,6.3e-3)
ax[2].set_xlabel(r'rank-four deviation $\Delta$')
ax[2].set_ylabel(r'anisotropy at $r\simeq9$')
ax[2].set_title(r'(c) $\varepsilon=c\,\Delta$, and'+'\n'+r'$\Delta=0$ for static $D_4$')
ax[2].legend(frameon=False,loc='upper left',handletextpad=0.4,labelspacing=0.25)
fig.tight_layout(pad=0.6)
fig.savefig('fig_final.pdf',bbox_inches='tight')
print('written; slope %.5f'%sl)
