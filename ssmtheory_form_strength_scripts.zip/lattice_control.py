#!/usr/bin/env python3
"""Control for cov_memory.py: the same memoryless operator (Gaussian weight in current proper distance, smooth cut
(1-d^2/rc^2)^3 at rc=3.2) on the D4 lattice points instead of a sprinkling. Usage: python3 lattice_control.py Lb"""
import numpy as np, itertools, sys
from cov_memory import pairs, f_blend, resp
Lb=int(sys.argv[1]) if len(sys.argv)>1 else 6
X=np.array([x for x in itertools.product(range(Lb),repeat=4) if sum(x)%2==0],float); N=len(X)
from cov_memory import S
P,dx=pairs(X,Lb,3.2*S*1.15)
H1=np.diag([1,-1,1,-1.])/2; H2=np.zeros((4,4)); H2[0,1]=H2[1,0]=2**-.5
for name,H in (('diagonal shear',H1),('off-diagonal shear',H2)):
    K,k1=resp(lambda g: f_blend(P,dx,N,g,0.0),H)
    print('D4 lattice N=%d %s: K=%.4f -kappa1=%.4f R=%.4f'%(N,name,K,-k1,K/(-k1)))
