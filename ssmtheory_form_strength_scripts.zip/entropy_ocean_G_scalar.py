#!/usr/bin/env python3
"""Induced Einstein-Hilbert coefficient of a minimal scalar on a sprinkled torus (Euclidean, one loop).
Graph Laplacian with weights w = exp(-d^2/2 sig^2) inside a hard cut |dx| < rc, where d is the distance between two
points in the metric g = 1 + h of a TT wave. Pi(p) is the second-order coefficient of 1/2 ln det per proper volume per
<tr h^2>; its p^2 slope is 1/(64 pi G) for one scalar.
Usage: python3 entropy_ocean_G_scalar.py L seed [dist] [rcfac] [check]
  dist = mid  : d^2 = dx^T g(midpoint) dx
         line : d^2 = integral of g along the straight segment
         geo  : straight-segment integral plus the second-order geodesic correction (the true proper distance to O(h^2))
  rcfac = cut in units of sig (default 2.5).
Environment: OCEAN_SIG = kernel width (default 0.7); OCEAN_TAPER=1 multiplies the Gaussian by (1-d^2/rc^2)^3,
a smooth cut in proper distance (default: hard cut in coordinate distance)."""
import numpy as np, sys, time
from scipy.spatial import cKDTree
import scipy.sparse as sp
import os
SIG=float(os.environ.get('OCEAN_SIG','0.7')); TAPER=os.environ.get('OCEAN_TAPER','0')=='1'
def kern(D,rc):
    """kernel of the squared proper distance D: Gaussian, optionally times the smooth taper (1-D/rc^2)^3 (zero beyond rc)"""
    w=np.exp(-D/(2*SIG**2))
    if TAPER: w=w*np.clip(1-D/rc**2,0,None)**3
    return w
L=int(sys.argv[1]); seed=int(sys.argv[2])
dist=sys.argv[3] if len(sys.argv)>3 else 'mid'; rcf=float(sys.argv[4]) if len(sys.argv)>4 else 2.5
CHECK=len(sys.argv)>5 and sys.argv[5]=='check'
rho=1.0; sig=SIG; rc=rcf*sig; mu=0.02
rng=np.random.default_rng(seed); N=int(rho*L**4); X=rng.random((N,4))*L
T=cKDTree(X,boxsize=L); P=np.array(sorted(T.query_pairs(rc*(1.1 if TAPER else 1.02))))
dx=X[P[:,1]]-X[P[:,0]]; dx-=L*np.round(dx/L); x0=X[P[:,0]]; mid=x0+dx/2
i,j=P[:,0],P[:,1]; d2=np.sum(dx*dx,1); inside=np.ones(len(d2),bool) if TAPER else d2<rc**2
tq,wq=np.polynomial.legendre.leggauss(10); tq=(tq+1)/2; wq=wq/2
Gq=np.minimum.outer(tq,tq)*(1-np.maximum.outer(tq,tq))      # Green function of -d^2/dt^2 on [0,1]
def lap(w):
    A=sp.coo_matrix((np.r_[-w,-w],(np.r_[i,j],np.r_[j,i])),shape=(N,N)).tocsr()
    return A+sp.diags(-np.asarray(A.sum(1)).ravel())
def weights(A,p,H,ph,kind):
    """weights for the metric 1 + A H f(p.x+ph), f = cos or sin"""
    f=np.cos if kind=='c' else np.sin; df=(lambda a:-np.sin(a)) if kind=='c' else np.cos
    q=np.einsum('ma,ab,mb->m',dx,H,dx)
    if dist=='mid': D=d2+A*q*f(mid@p+ph)
    else:
        th=(x0@p+ph)[:,None]+np.outer(dx@p,tq)
        D=d2+A*q*(f(th)@wq)
        if dist=='geo':
            Hy=dx@H; py=dx@p
            J=A*df(th)[:,:,None]*(p[None,None,:]*q[:,None,None]-2*py[:,None,None]*Hy[:,None,:])
            Jw=J*wq[None,:,None]
            D=D-0.25*np.einsum('mtb,ts,msb->m',Jw,Gq,Jw)
    return kern(D,rc)*inside
w0=kern(d2,rc)*inside
def tt(n):
    p=np.array(n,float); pn=p/np.linalg.norm(p); B=np.linalg.svd(np.outer(pn,pn))[0][:,1:]
    H=np.outer(B[:,0],B[:,1]); H=H+H.T; return H/np.sqrt(np.trace(H@H))
def pi_of_p(G,n,eps=1e-3):
    Gd=np.diag(G); p=2*np.pi*np.array(n,float)/L; H=tt(n)
    Lc=(weights(2*eps,p,H,0,'c')-weights(-2*eps,p,H,0,'c'))/2; Ls=(weights(2*eps,p,H,0,'s')-weights(-2*eps,p,H,0,'s'))/2
    Xp=(Lc+1j*Ls)/2; Xm=(Lc-1j*Ls)/2
    X2=sum(((weights(2*eps,p,H,ph,'c')+weights(-2*eps,p,H,ph,'c'))/2-w0)/4 for ph in (0,np.pi/2,np.pi,1.5*np.pi))
    tr1=np.sum(X2*(Gd[i]+Gd[j]-2*G[i,j]))
    GA=np.asarray((lap(Xp).T.dot(G.T)).T); GB=np.asarray((lap(Xm).T.dot(G.T)).T)
    return (0.5*(tr1-np.sum(GA*GB.T))/eps**2/(N/rho)/2).real
def fd(n,eps=1e-3):
    p=2*np.pi*np.array(n,float)/L; H=tt(n); ld=lambda w: np.linalg.slogdet((lap(w)+mu*sp.eye(N)).toarray())[1]
    l0=ld(w0); tot=0
    for ph in (0,np.pi/2,np.pi,1.5*np.pi):
        tot+=0.5*(ld(weights(2*eps,p,H,ph,'c'))+ld(weights(-2*eps,p,H,ph,'c'))-2*l0)/(2*eps**2)/4
    return tot/(N/rho)/2
if __name__=='__main__':
    t=time.time(); G=np.linalg.inv((lap(w0)+mu*sp.eye(N)).toarray())
    print('N=%d nbrs/pt=%.1f dist=%s cut=%.2f sig, inverse %.0fs'%(N,2*inside.sum()/N,dist,rcf,time.time()-t),flush=True)
    ns=[[1,0,0,0],[0,0,1,0],[1,1,0,0],[0,1,0,1],[2,0,0,0],[0,0,0,2]]
    if CHECK:
        for n in ns[:2]: print(n,'pert %.6f fd %.6f'%(pi_of_p(G,n),fd(n)),flush=True)
    else:
        p2=[];v=[]
        for n in ns:
            p2.append((2*np.pi/L)**2*np.sum(np.array(n)**2)); v.append(pi_of_p(G,n)); print('n=%s p^2=%.3f Pi=%.6f'%(n,p2[-1],v[-1]),flush=True)
        print('linear slope (1/64 pi G per scalar) = %.3e'%np.polyfit(p2,v,1)[0])
        c=np.polyfit(p2,v,2); print('quadratic fit: slope %.3e, curvature %.3e'%(c[1],c[0]))
