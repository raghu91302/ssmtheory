#!/usr/bin/env python3
"""Maximum-entropy ocean around a defect: N points uniform in a periodic 4-box of side Lb, excluded from a ball of radius a
(the defect's volume). Radial density profile, averaged over realizations, in units of the far density."""
import numpy as np, sys
Lb=6.0; a=0.6; N=int(Lb**4/2); nreal=400; rng=np.random.default_rng(3)
edges=np.linspace(0,2.8,15); cnt=np.zeros(len(edges)-1)
c=np.full(4,Lb/2)
for r in range(nreal):
    X=rng.random((int(N*1.2),4))*Lb; d=np.linalg.norm(X-c,axis=1); X=X[d>a][:N]; d=np.linalg.norm(X-c,axis=1)
    cnt+=np.histogram(d,edges)[0]
vol=np.pi**2/2*(edges[1:]**4-edges[:-1]**4); n=cnt/nreal/vol
nfar=N/(Lb**4-np.pi**2/2*a**4)
for lo,hi,x in zip(edges[:-1],edges[1:],n/nfar): print('r=%.2f-%.2f  n/n_far=%.4f'%(lo,hi,x))
