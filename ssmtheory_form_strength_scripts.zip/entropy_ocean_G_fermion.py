#!/usr/bin/env python3
"""Usage: python3 entropy_ocean_G_fermion.py L seed mass r [check]
Induced Einstein-Hilbert coefficient of a Wilson-Dirac fermion on a sprinkled torus (Euclidean, one loop).
(D psi)_i = sum_j w_ij [ gamma.(g^1/2 dx)/sig U_ij psi_j ] + r sum_j w_ij a_ij [ psi_i - U_ij psi_j ] + m psi_i,
w = exp(-d^2/2 sig^2) with proper distance d, a = (det g)^(1/8), U = spin transporter from the Levi-Civita connection.
Pi(p) per proper volume per <tr h^2> for a TT wave; its p^2 slope is 1/(64 pi G) for one Dirac fermion (4 dof).
Environment: OCEAN_SIG (kernel width, default 0.7), OCEAN_CUT (cut in widths, default 2.5), OCEAN_TAPER=1 (smooth cut
in proper distance), OCEAN_DIST=geo (geodesic distance in the weight, vierbein averaged along the segment and
path-ordered spin transport; default mid: midpoint metric and transport)."""
import numpy as np, sys, time
from scipy.spatial import cKDTree
import scipy.sparse as sp
import os
SIG=float(os.environ.get('OCEAN_SIG','0.7')); TAPER=os.environ.get('OCEAN_TAPER','0')=='1'
GEO=os.environ.get('OCEAN_DIST','mid')=='geo'; PATH=GEO
def kern(D,rc):
    w=np.exp(-D/(2*SIG**2))
    if TAPER: w=w*np.clip(1-D/rc**2,0,None)**3
    return w
L=int(sys.argv[1]); seed=int(sys.argv[2]); MF=float(sys.argv[3]); RW=float(sys.argv[4])
rho=1.0; sig=SIG; rc=float(os.environ.get('OCEAN_CUT','2.5'))*sig
rng=np.random.default_rng(seed); N=int(rho*L**4); X=rng.random((N,4))*L
T=cKDTree(X,boxsize=L); P=np.array(sorted(T.query_pairs(rc*(1.1 if TAPER else 1.02))))
dx=X[P[:,1]]-X[P[:,0]]; dx-=L*np.round(dx/L); mid=X[P[:,0]]+dx/2; I_,J_=P[:,0],P[:,1]; M=len(P)
inside=np.ones(len(dx),bool) if TAPER else np.sum(dx*dx,1)<rc**2
s1=np.array([[0,1],[1,0]],complex); s2=np.array([[0,-1j],[1j,0]]); s3=np.array([[1,0],[0,-1]],complex); I2=np.eye(2)
GAM=np.array([np.kron(s1,s) for s in (s1,s2,s3)]+[np.kron(s2,I2)]); GG=np.einsum('aij,bjk->abik',GAM,GAM)
def bsqrt(g):
    w,V=np.linalg.eigh(g); return np.einsum('mij,mj,mkj->mik',V,np.sqrt(w),V), np.einsum('mij,mj,mkj->mik',V,1/np.sqrt(w),V)
class Wave:
    def __init__(s,H,p,amp,ph,kind): s.H,s.p,s.A,s.ph,s.k=H,p,amp,ph,kind
    def h(s,x):
        a=x@s.p+s.ph; f=np.cos(a) if s.k=='c' else np.sin(a); return s.A*f[:,None,None]*s.H[None]
    def dh(s,x):
        a=x@s.p+s.ph; f=-np.sin(a) if s.k=='c' else np.cos(a)
        return s.A*f[:,None,None,None]*s.p[None,:,None,None]*s.H[None,None]
tq,wq=np.polynomial.legendre.leggauss(10); tq=(tq+1)/2; wq=wq/2
Gq=np.minimum.outer(tq,tq)*(1-np.maximum.outer(tq,tq))
def geod2(wave):
    A,p,H,ph,kind=wave.A,wave.p,wave.H,wave.ph,wave.k
    f=np.cos if kind=='c' else np.sin; df=(lambda a:-np.sin(a)) if kind=='c' else np.cos
    x0=X[I_]; q=np.einsum('ma,ab,mb->m',dx,H,dx); th=(x0@p+ph)[:,None]+np.outer(dx@p,tq)
    D=np.sum(dx*dx,1)+A*q*(f(th)@wq); Hy=dx@H; py=dx@p
    J=A*df(th)[:,:,None]*(p[None,None,:]*q[:,None,None]-2*py[:,None,None]*Hy[:,None,:]); Jw=J*wq[None,:,None]
    return D-0.25*np.einsum('mtb,ts,msb->m',Jw,Gq,Jw)
NSUB=6
def omega_at(wave,x):
    g=np.eye(4)[None]+wave.h(x); e,Ei=bsqrt(g); gi=np.linalg.inv(g); dg=wave.dh(x)
    Gam=0.5*(np.einsum('mnr,mjrl->mnjl',gi,dg)+np.einsum('mnr,mlrj->mnjl',gi,dg)-np.einsum('mnr,mrjl->mnjl',gi,dg))
    om=np.zeros((len(x),4,4,4)); dl=1e-5
    for mu in range(4):
        sh=np.zeros(4); sh[mu]=dl
        _,Ep=bsqrt(np.eye(4)[None]+wave.h(x+sh)); _,Em=bsqrt(np.eye(4)[None]+wave.h(x-sh)); dE=(Ep-Em)/(2*dl)
        om[:,mu]=np.einsum('man,mnb->mab',e,dE+np.einsum('mnl,mlb->mnb',Gam[:,:,mu,:],Ei))
    return om,e
def expm_ah(Om):
    lam,V=np.linalg.eigh(1j*Om); return np.einsum('mij,mj,mkj->mik',V,np.exp(-1j*lam),V.conj())
def path_parts(wave):
    """vierbein averaged along the straight segment, and the path-ordered spin transporter U_ij (frame at j -> frame at i)"""
    n=np.zeros((M,4)); U=np.broadcast_to(np.eye(4),(M,4,4)).astype(complex).copy()
    for k in range(NSUB):          # sub-segment midpoints, ordered from i to j
        x=X[I_]+dx*(k+0.5)/NSUB
        om,e=omega_at(wave,x); n+=np.einsum('mab,mb->ma',e,dx)/NSUB
        Om=0.25*np.einsum('mab,abij->mij',np.einsum('mu,muab->mab',dx/NSUB,om),GG)
        U=np.einsum('mij,mjk->mik',U,expm_ah(Om))
    return n,U
def parts(wave):
    """returns (Ba, Bw, sw): anti-Hermitian hop block, Wilson hop block r w a U, Wilson diagonal weight r w a"""
    g=np.broadcast_to(np.eye(4),(M,4,4)).copy() if wave is None else np.eye(4)[None]+wave.h(mid)
    d2=np.einsum('ma,mab,mb->m',dx,g,dx)
    if GEO and wave is not None: d2=geod2(wave)
    w=kern(d2,rc)*inside
    e,Ei=bsqrt(g); n=np.einsum('mab,mb->ma',e,dx); a=np.linalg.det(g)**0.125
    if wave is None: U=np.broadcast_to(np.eye(4),(M,4,4)).astype(complex)
    elif PATH: n,U=path_parts(wave)
    else:
        gi=np.linalg.inv(g); dg=wave.dh(mid)
        Gam=0.5*(np.einsum('mnr,mjrl->mnjl',gi,dg)+np.einsum('mnr,mlrj->mnjl',gi,dg)-np.einsum('mnr,mrjl->mnjl',gi,dg))
        om=np.zeros((M,4,4,4)); dl=1e-5
        for mu in range(4):
            sh=np.zeros(4); sh[mu]=dl
            _,Ep=bsqrt(np.eye(4)[None]+wave.h(mid+sh)); _,Em=bsqrt(np.eye(4)[None]+wave.h(mid-sh)); dE=(Ep-Em)/(2*dl)
            om[:,mu]=np.einsum('man,mnb->mab',e,dE+np.einsum('mnl,mlb->mnb',Gam[:,:,mu,:],Ei))
        Om=0.25*np.einsum('mab,abij->mij',np.einsum('mu,muab->mab',dx,om),GG)
        lam,V=np.linalg.eigh(1j*Om); U=np.einsum('mij,mj,mkj->mik',V,np.exp(-1j*lam),V.conj())
    gn=np.einsum('ma,aij->mij',n,GAM)
    Ba=(w/sig)[:,None,None]*np.einsum('mij,mjk->mik',gn,U); Bw=(RW*w*a)[:,None,None]*U; sw=RW*w*a
    return Ba,Bw,sw
def assemble(X1,X2=None):
    """operator from pair parts X1 (row i, col j) and conjugate partner X2 (row j, col i gets -(Ba2)^dag - (Bw2)^dag);
    diagonal Wilson weight: sw1 on row i, conj(sw2) on row j."""
    if X2 is None: X2=X1
    Ba,Bw,sw=X1; Ca,Cw,cw=X2; rows=[];cols=[];vals=[]
    for a in range(4):
        for b in range(4):
            rows+=[4*I_+a,4*J_+a]; cols+=[4*J_+b,4*I_+b]; vals+=[Ba[:,a,b]-Bw[:,a,b],-Ca[:,b,a].conj()-Cw[:,b,a].conj()]
        rows+=[4*I_+a,4*J_+a]; cols+=[4*I_+a,4*J_+a]; vals+=[sw.astype(complex),np.conj(cw).astype(complex)]
    return sp.coo_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(4*N,4*N)).tocsr()
def sub(Xa,Xb,f=1.0): return tuple(f*(a-b) for a,b in zip(Xa,Xb))
def add(Xa,Xb): return tuple(a+b for a,b in zip(Xa,Xb))
def lin(Xc,Xs,sgn): return tuple((c+sgn*1j*s)/2 for c,s in zip(Xc,Xs))
X0=parts(None); D0=assemble(X0)
t=time.time(); G0=np.linalg.inv(D0.toarray()+MF*np.eye(4*N)); print('N=%d 4N=%d m=%.2f r=%.2f inverse %.0fs'%(N,4*N,MF,RW,time.time()-t),flush=True)
def tt(n):
    p=np.array(n,float); pn=p/np.linalg.norm(p); Bv=np.linalg.svd(np.outer(pn,pn))[0][:,1:]
    H=np.outer(Bv[:,0],Bv[:,1]); H=H+H.T; return H/np.sqrt(np.trace(H@H))
def pi_of_p(n,eps=1e-3):
    p=2*np.pi*np.array(n,float)/L; H=tt(n)
    Lc=sub(parts(Wave(H,p,2*eps,0,'c')),parts(Wave(H,p,-2*eps,0,'c')),0.5)
    Ls=sub(parts(Wave(H,p,2*eps,0,'s')),parts(Wave(H,p,-2*eps,0,'s')),0.5)
    Xp=lin(Lc,Ls,+1); Xm=lin(Lc,Ls,-1)
    X2=tuple(0*a for a in X0)
    for ph in (0,np.pi/2,np.pi,1.5*np.pi):
        A=parts(Wave(H,p,2*eps,ph,'c')); B=parts(Wave(H,p,-2*eps,ph,'c'))
        X2=add(X2,tuple(((a+b)/2-c)/4 for a,b,c in zip(A,B,X0)))
    Ap=assemble(Xp,Xm); Am=assemble(Xm,Xp); D2=assemble(X2)
    tr1=(D2.multiply(G0.T)).sum()
    GA=np.asarray((Ap.T.dot(G0.T)).T); GB=np.asarray((Am.T.dot(G0.T)).T); tr2=np.sum(GA*GB.T)
    return (-(tr1-tr2)/eps**2/(N/rho)/2).real
def lndet(X): return np.linalg.slogdet(assemble(X).toarray()+MF*np.eye(4*N))[1]
def fd(n,eps=1e-3):
    p=2*np.pi*np.array(n,float)/L; H=tt(n); l0=lndet(X0); tot=0
    for ph in (0,np.pi/2,np.pi,1.5*np.pi):
        tot+=(lndet(parts(Wave(H,p,2*eps,ph,'c')))+lndet(parts(Wave(H,p,-2*eps,ph,'c')))-2*l0)/2/eps**2/4
    return -tot/(N/rho)/2
if __name__=='__main__':
    mode=sys.argv[5] if len(sys.argv)>5 else 'run'
    ns=[[1,0,0,0],[0,1,0,0],[1,1,0,0],[0,0,1,1],[2,0,0,0]]
    if mode=='check':
        for n in ns[:2]: print(n,'pert %.6f fd %.6f'%(pi_of_p(n),fd(n)),flush=True)
    else:
        p2=[];v=[]
        for n in ns:
            p2.append((2*np.pi/L)**2*np.sum(np.array(n)**2)); v.append(pi_of_p(n)); print('n=%s p^2=%.3f Pi=%.6f'%(n,p2[-1],v[-1]),flush=True)
        c=np.polyfit(p2,v,1); print('slope (1/64 pi G per Dirac) = %.3e'%c[0])
