#!/usr/bin/env python3
"""Figure 4: (a) shear response relative to covariant against memory (blend.log, graph.log); (b) density around an excluded ball (excluded.log)."""
import re, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
def read(fn,key):
    x=[];y=[];e=[]
    for l in open(fn):
        m=re.search(key+r'=([\d.]+).*R=K/\(-kappa1\)=([\d.]+) \+- ([\d.]+)',l)
        if m: x.append(float(m.group(1)));y.append(float(m.group(2)));e.append(float(m.group(3)))
    return np.array(x),np.array(y),np.array(e)
fig,ax=plt.subplots(1,2,figsize=(9,3.4))
x,y,e=read('blend.log','mu'); ax[0].errorbar(x,y,e,fmt='o',color='C0',label=r'blend: metric $(1-\mu)g+\mu g_0$')
xx=np.linspace(0,1,50); ax[0].plot(xx,1-xx,'-',color='C0',lw=0.8,label=r'$1-\mu$')
x,y,e=read('graph.log','phi'); ax[0].errorbar(x,y,e,fmt='s',color='C3',label=r'remembered neighbors, fraction $\phi$')
ax[0].axhline(1,color='k',ls=':',lw=0.8); ax[0].set_xlabel(r'memory $\mu$ or $\phi$'); ax[0].set_ylabel(r'shear response / covariant value')
ax[0].set_ylim(0,1.1); ax[0].legend(fontsize=7,loc='lower left'); ax[0].set_title('(a) memory breaks covariance',fontsize=9)
r=[];n=[]
for l in open('excluded.log'):
    m=re.search(r'r=([\d.]+)-([\d.]+)\s+n/n_far=([\d.]+)',l); r.append((float(m.group(1))+float(m.group(2)))/2); n.append(float(m.group(3)))
ax[1].plot(r,n,'o-',color='C2',ms=4,label='maximum-entropy ocean')
rr=np.linspace(0.6,2.8,100); ax[1].plot(rr,1-0.6/rr,'--',color='gray',lw=0.8,label=r'a $1/r$ halo, for comparison')
ax[1].axvspan(0,0.6,color='0.85'); ax[1].text(0.08,0.5,'defect',fontsize=8)
ax[1].set_xlabel('distance from the defect (half-cells)'); ax[1].set_ylabel(r'density / far density'); ax[1].set_ylim(0,1.2)
ax[1].legend(fontsize=7,loc='lower right'); ax[1].set_title('(b) no halo around a defect',fontsize=9)
plt.tight_layout(); plt.savefig('fig_covariance.pdf'); print('ok')
