#!/usr/bin/env python3
"""Figure 7: the bond model. (a) entanglement per unit area s/a against the dual area a (p = 1, h/J0 = 0.691):
its maximum is the vacuum, where d ln s/d ln a = 1; (b) local Newton constant against stretch for p = 1, 1.5, 2,
with the neutron-star bound G_loc/G < 1.08."""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import minimize_scalar
def s_of(J,h=1.0):
    H=np.array([[-J-2*h,-J],[-J,-J+2*h]]); w,v=np.linalg.eigh(H); q=v[:,0]**2; q=q[q>1e-300]; return -(q*np.log(q)).sum()
fig,ax=plt.subplots(1,2,figsize=(9,3.3))
a0=minimize_scalar(lambda a:-s_of(a)/a,bounds=(1e-3,50),method='bounded').x
x=np.linspace(0.15,4,300); y=np.array([s_of(a0*t)/(a0*t) for t in x]); y0=s_of(a0)/a0
ax[0].plot(x,y/y0,color='C0'); ax[0].axvline(1,color='gray',ls=':',lw=0.8); ax[0].set_xlabel(r'dual area $a/a_0$'); ax[0].set_ylabel(r'entanglement per area, $(s/a)/(s_0/a_0)$')
ax[0].set_title(r'(a) the vacuum sits at the maximum of $s/a$',fontsize=9)
for p,col in ((1,'C0'),(1.5,'C1'),(2,'C3')):
    b0=minimize_scalar(lambda a:-s_of(a**p)/a,bounds=(1e-3,50),method='bounded').x; J0=b0**p
    ds=lambda t,d=1e-5:(s_of(J0*(t+d)**p)-s_of(J0*(t-d)**p))/(2*d)
    st=np.linspace(1.0,1.5,60); G=[ds(1)/ds(t) for t in st]
    ax[1].plot((st-1)*100,G,color=col,label=r'$p=%g$'%p)
ax[1].axhline(1.08,color='k',ls='--',lw=0.8); ax[1].text(49,1.045,'neutron-star bound',fontsize=7,ha='right')
ax[1].set_ylim(0.95,2.0); ax[1].set_xlabel('stretch of the dual area (%)'); ax[1].set_ylabel(r'$G_{\rm loc}/G$'); ax[1].legend(fontsize=8)
ax[1].set_title('(b) local Newton constant if bonds hold the stretch',fontsize=9)
plt.tight_layout(); plt.savefig('fig_bond.pdf'); print('a0',a0)
