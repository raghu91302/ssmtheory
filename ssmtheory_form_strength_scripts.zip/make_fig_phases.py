#!/usr/bin/env python3
"""Figure 3: a two-dimensional cartoon of the two phases.
(a) the ocean: Poisson points with no orientation;
(b) the frozen phase: a lattice of bonds, with the ocean around it;
(c) a trapped node in a void: the bonds near it change length (curvature), while the ocean is
    excluded only from the node's own volume and is uniform elsewhere."""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rng = np.random.default_rng(5)
W, S = 6.0, 1.2                                   # panel size, bond length
def nodes():
    P = {}
    for i in range(-1, 7):
        for j in range(-1, 7):
            P[(i, j)] = np.array([i + 0.5 * (j % 2), j * np.sqrt(3) / 2]) * S + np.array([0.3, 0.3])
    return P
def nbrs(i, j):
    return [(i + 1, j), (i, j + 1), (i - 1, j + 1)] if j % 2 == 0 else [(i + 1, j), (i, j + 1), (i + 1, j + 1)]
def draw_lattice(a, P):
    for (i, j), p in P.items():
        for k in nbrs(i, j):
            if k in P:
                q = P[k]; a.plot([p[0], q[0]], [p[1], q[1]], color='#444', lw=1.1, zorder=2)
    X = np.array(list(P.values())); a.scatter(X[:, 0], X[:, 1], s=14, color='#222', zorder=3)
def draw_ocean(a, hole=None, n=230):
    X = rng.random((n, 2)) * W
    if hole is not None: X = X[np.linalg.norm(X - hole[0], axis=1) > hole[1]]
    a.scatter(X[:, 0], X[:, 1], s=5, color='#7fb3d5', zorder=1)
fig, ax = plt.subplots(1, 3, figsize=(10, 3.5))
draw_ocean(ax[0]); ax[0].set_title('(a) the ocean', fontsize=10)
draw_ocean(ax[1]); draw_lattice(ax[1], nodes()); ax[1].set_title('(b) frozen ocean: the lattice', fontsize=10)
P = nodes(); tri = [(2, 2), (3, 2), (2, 3)]        # a triangular void near the middle
c = np.mean([P[k] for k in tri], axis=0)
for k, p in P.items():                             # bonds near the defect change length
    d = p - c; r = np.linalg.norm(d)
    P[k] = c + d * (1 - 0.10 * np.exp(-r / 1.5))
draw_ocean(ax[2], hole=(c, 0.35)); draw_lattice(ax[2], P)
for k in tri: ax[2].plot([c[0], P[k][0]], [c[1], P[k][1]], color='#c0392b', lw=1.8, zorder=4)
ax[2].scatter(*c, s=45, color='#c0392b', zorder=5)
ax[2].set_title('(c) a trapped node: the bonds bend', fontsize=10)
for a in ax: a.set_xlim(0, W); a.set_ylim(0, W); a.set_aspect('equal'); a.axis('off')
plt.tight_layout(); plt.savefig('fig_phases.pdf'); print('ok')
