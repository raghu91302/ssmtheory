#!/usr/bin/env python3
"""Figure 6: entanglement equilibrium on the solved trapped-node slice, from equilibrium.log."""
import re, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R=[];A=[];K=[]
for l in open('equilibrium.log'):
    m=re.match(r'\s*([\d.]+)\s+(-?[\d.e+-]+)\s+(-?[\d.e+-]+)\s+([\d.]+)\s*$',l)
    if m: R.append(float(m.group(1))); A.append(-float(m.group(2))); K.append(-float(m.group(3)))
R=np.array(R);A=np.array(A);K=np.array(K)
fig,ax=plt.subplots(1,2,figsize=(9,3.3))
ax[0].plot(R,K,'s-',color='C1',label=r'matter side, $8\pi G\,\delta\langle K\rangle$')
ax[0].plot(R,A,'o',color='C0',label=r'geometry side, $-\delta A|_V$')
ax[0].set_xlabel(r'ball radius $R_B$ (half-cells)'); ax[0].set_ylabel('magnitude'); ax[0].legend(fontsize=8)
ax[0].set_title('(a) the two sides of the equilibrium condition',fontsize=9)
ax[1].plot(R,A/K,'o-',color='C2'); ax[1].axhline(1,color='k',ls=':',lw=0.8)
ax[1].axvline(2*np.sqrt(2),color='gray',ls='--',lw=0.8); ax[1].text(2*np.sqrt(2)+0.08,0.86,'two lattice\nspacings',fontsize=7,color='gray')
ax[1].set_ylim(0.8,1.03); ax[1].set_xlabel(r'ball radius $R_B$ (half-cells)'); ax[1].set_ylabel('ratio')
ax[1].set_title('(b) geometry side / matter side',fontsize=9)
plt.tight_layout(); plt.savefig('fig_equilibrium.pdf'); print(np.round(A/K,4))
