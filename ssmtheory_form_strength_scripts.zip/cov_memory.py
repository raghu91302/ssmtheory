#!/usr/bin/env python3
"""Covariance and memory on a sprinkled ocean (Euclidean, scalar, one loop).
Points X are a Poisson sprinkling (comoving with a uniform strain g = I + h) in a periodic 4-box of side Lb, density 1/2.
Formation metric g0 = I.  f(g) = (1/N) ln det' L(g), L the graph Laplacian.
Covariance <=> shear response K = d^2f/dt^2 (g = I + tH, H traceless, tr H^2 = 1) equals -kappa1, kappa1 = (1/4) df/deps (g=(1+eps)I).
We report the ratio R = K / (-kappa1)  (covariant: R = 1).
Model 'blend': weights see the metric g' = (1-mu) g + mu g0 (memory mu of the formation geometry).
Model 'graph': w_ij = exp(-d_g^2/2s^2) * c(d_m), c(d) = (1-d^2/rc^2)^3 for d<rc (smooth neighbor selection);
               for a random fraction phi of pairs the selection distance d_m is the formation distance d0 (remembered),
               for the rest it is the current proper distance d_g.
Usage: python3 cov_memory.py blend|graph Lb nreal seed values..."""
import numpy as np, sys, os
S=float(os.environ.get("OCEAN_SIG","1.0"))
from scipy.spatial import cKDTree
def pairs(X,Lb,rmax):
    T=cKDTree(X,boxsize=Lb); P=np.array(sorted(T.query_pairs(rmax)))
    dx=X[P[:,1]]-X[P[:,0]]; dx-=Lb*np.round(dx/Lb); return P,dx
def fdet(P,w,N):
    L=np.zeros((N,N)); L[P[:,0],P[:,1]]=-w; L[P[:,1],P[:,0]]=-w; L[np.arange(N),np.arange(N)]=-L.sum(1)
    ev=np.linalg.eigvalsh(L); return np.sum(np.log(ev[1:]))/N
def d2(dx,g): return np.einsum('ma,ab,mb->m',dx,g,dx)
def f_blend(P,dx,N,g,mu,s=None,rc=None):
    s=S if s is None else s; rc=3.2*s if rc is None else rc
    gp=(1-mu)*g+mu*np.eye(4); q=d2(dx,gp); w=np.exp(-q/(2*s*s))*np.clip(1-q/rc**2,0,None)**3
    return fdet(P,w,N)
def f_graph(P,dx,N,g,mask,s=1.0,rc=2.0):
    q=d2(dx,g); q0=d2(dx,np.eye(4)); qm=np.where(mask,q0,q)
    w=np.exp(-q/(2*s*s))*np.clip(1-qm/rc**2,0,None)**3
    return fdet(P,w,N)
def resp(fun,H,t=0.02):
    I=np.eye(4); f0=fun(I)
    K=(fun(I+t*H)-2*f0+fun(I-t*H))/t**2
    k1=(fun((1+t)*I)-fun((1-t)*I))/(2*t)/4
    return K,k1
if __name__=='__main__':
    model=sys.argv[1]; Lb=int(sys.argv[2]); nreal=int(sys.argv[3]); rng=np.random.default_rng(int(sys.argv[4]))
    vals=[float(v) for v in sys.argv[5:]]
    N=Lb**4//2; rmax=(3.2*S if model=="blend" else 2.0)*1.15
    res={v:[] for v in vals}
    for r in range(nreal):
        X=rng.random((N,4))*Lb; P,dx=pairs(X,Lb,rmax)
        Q=np.linalg.qr(rng.normal(size=(4,4)))[0]; H=Q@np.diag([1,-1,1,-1.])@Q.T/2
        u=rng.random(len(P))
        for v in vals:
            if model=='blend': fun=lambda g: f_blend(P,dx,N,g,v)
            else: m=u<v; fun=lambda g: f_graph(P,dx,N,g,m)
            K,k1=resp(fun,H); res[v].append((K,-k1))
    for v in vals:
        a=np.array(res[v]); R=a[:,0]/a[:,1]
        print('%s  %s=%.2f  K=%.4f  -kappa1=%.4f  R=K/(-kappa1)=%.4f +- %.4f'%(model,'mu' if model=='blend' else 'phi',v,a[:,0].mean(),a[:,1].mean(),R.mean(),R.std()/np.sqrt(len(R))),flush=True)
