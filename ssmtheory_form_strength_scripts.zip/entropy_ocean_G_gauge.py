#!/usr/bin/env python3
"""Usage: python3 entropy_ocean_G_gauge.py L seed mu [run|check] [dist] [ricci]
  dist  = mid (d^2 = dx^T g(midpoint) dx) or geo (proper distance to O(h^2): straight-segment integral plus geodesic correction)
  ricci = multiplier of the c_L Ric term (1 = included, 0 = omitted)
Induced Einstein-Hilbert coefficient of a gauge field (Feynman gauge, two ghosts) on a sprinkled torus.
Vector operator on frame components: (V v)_i = sum_j w_ij (v_i - R_ij v_j) + c_L Ric(x_i) v_i, R_ij = exp(dx^mu omega_mu)
(Levi-Civita transport), Ric in the orthonormal frame, c_L = (rho/8) int w r^2 d^4r the graph Laplacian's continuum constant.
Ghosts: two scalar graph Laplacians. Gamma = 1/2 ln det(V+mu) - ln det(L+mu)."""
import numpy as np, sys, time
from scipy.spatial import cKDTree
import scipy.sparse as sp
from scipy.integrate import quad
import os
SIG=float(os.environ.get('OCEAN_SIG','0.7')); TAPER=os.environ.get('OCEAN_TAPER','0')=='1'
def kern(D,rc):
    """kernel of the squared proper distance D: Gaussian, optionally times the smooth taper (1-D/rc^2)^3 (zero beyond rc)"""
    w=np.exp(-D/(2*SIG**2))
    if TAPER: w=w*np.clip(1-D/rc**2,0,None)**3
    return w
L=int(sys.argv[1]); seed=int(sys.argv[2]); mu=float(sys.argv[3]) if len(sys.argv)>3 else 0.02
rho=1.0; sig=SIG; rc=float(os.environ.get('OCEAN_CUT','2.5'))*sig
rng=np.random.default_rng(seed); N=int(rho*L**4); X=rng.random((N,4))*L
T=cKDTree(X,boxsize=L); P=np.array(sorted(T.query_pairs(rc*(1.1 if TAPER else 1.02))))
dx=X[P[:,1]]-X[P[:,0]]; dx-=L*np.round(dx/L); mid=X[P[:,0]]+dx/2; I_,J_=P[:,0],P[:,1]; M=len(P)
inside=np.ones(len(dx),bool) if TAPER else np.sum(dx*dx,1)<rc**2
GEO=(sys.argv[5]=='geo') if len(sys.argv)>5 else False
RICM=float(sys.argv[6]) if len(sys.argv)>6 else 1.0
cL=rho/8*quad(lambda r: kern(r*r,rc)*r**2*2*np.pi**2*r**3,0,rc)[0]
def bsqrt(g):
    w,V=np.linalg.eigh(g); return np.einsum('mij,mj,mkj->mik',V,np.sqrt(w),V), np.einsum('mij,mj,mkj->mik',V,1/np.sqrt(w),V)
class Wave:
    def __init__(s,H,p,amp,ph,kind): s.H,s.p,s.A,s.ph,s.k=H,p,amp,ph,kind
    def h(s,x):
        a=x@s.p+s.ph; f=np.cos(a) if s.k=='c' else np.sin(a); return s.A*f[:,None,None]*s.H[None]
    def dh(s,x):
        a=x@s.p+s.ph; f=-np.sin(a) if s.k=='c' else np.cos(a)
        return s.A*f[:,None,None,None]*s.p[None,:,None,None]*s.H[None,None]
def christ(wave,x):
    g=np.eye(4)[None]+wave.h(x); gi=np.linalg.inv(g); dg=wave.dh(x)
    return 0.5*(np.einsum('mnr,mjrl->mnjl',gi,dg)+np.einsum('mnr,mlrj->mnjl',gi,dg)-np.einsum('mnr,mrjl->mnjl',gi,dg))  # [m,nu,mu,lam]
def omega(wave,x):
    g=np.eye(4)[None]+wave.h(x); e,Ei=bsqrt(g); Gam=christ(wave,x); om=np.zeros((len(x),4,4,4)); dl=1e-5
    for m_ in range(4):
        sh=np.zeros(4); sh[m_]=dl
        _,Ep=bsqrt(np.eye(4)[None]+wave.h(x+sh)); _,Em=bsqrt(np.eye(4)[None]+wave.h(x-sh)); dE=(Ep-Em)/(2*dl)
        om[:,m_]=np.einsum('man,mnb->mab',e,dE+np.einsum('mnl,mlb->mnb',Gam[:,:,m_,:],Ei))
    return om
def ricci_frame(wave,x,dl=1e-4):
    Gam=christ(wave,x)                                           # [m,lam,mu,nu] = Gamma^lam_{mu nu}
    dG=np.zeros((len(x),4)+Gam.shape[1:])
    for s_ in range(4):
        sh=np.zeros(4); sh[s_]=dl; dG[:,s_]=(christ(wave,x+sh)-christ(wave,x-sh))/(2*dl)   # d_s Gamma^lam_{mu nu}
    # R_{mu nu} = d_lam Gam^lam_{mu nu} - d_nu Gam^lam_{mu lam} + Gam^lam_{lam s} Gam^s_{mu nu} - Gam^lam_{nu s} Gam^s_{mu lam}
    t1=np.einsum('mllab->mab',dG)
    t2=np.zeros_like(t1)
    for a in range(4):
        for b in range(4):
            t2[:,a,b]=np.stack([dG[:,b,l,a,l] for l in range(4)],1).sum(1)
    t3=np.einsum('mlls,msab->mab',Gam,Gam)
    t4=np.einsum('mlbs,msal->mab',Gam,Gam)
    Ric=t1-t2+t3-t4
    g=np.eye(4)[None]+wave.h(x); _,Ei=bsqrt(g)
    return np.einsum('mua,muv,mvb->mab',Ei,Ric,Ei)

tq,wq=np.polynomial.legendre.leggauss(10); tq=(tq+1)/2; wq=wq/2
Gq=np.minimum.outer(tq,tq)*(1-np.maximum.outer(tq,tq))
def geod2(wave):
    A,p,H,ph,kind=wave.A,wave.p,wave.H,wave.ph,wave.k
    f=np.cos if kind=='c' else np.sin; df=(lambda a:-np.sin(a)) if kind=='c' else np.cos
    x0=X[I_]; q=np.einsum('ma,ab,mb->m',dx,H,dx); th=(x0@p+ph)[:,None]+np.outer(dx@p,tq)
    D=np.sum(dx*dx,1)+A*q*(f(th)@wq); Hy=dx@H; py=dx@p
    J=A*df(th)[:,:,None]*(p[None,None,:]*q[:,None,None]-2*py[:,None,None]*Hy[:,None,:]); Jw=J*wq[None,:,None]
    return D-0.25*np.einsum('mtb,ts,msb->m',Jw,Gq,Jw)
def parts(wave):
    """pair blocks -w R_ij (row i col j) and site blocks (Ricci) ; also scalar weights for the ghosts"""
    g=np.broadcast_to(np.eye(4),(M,4,4)).copy() if wave is None else np.eye(4)[None]+wave.h(mid)
    d2=np.einsum('ma,mab,mb->m',dx,g,dx)
    if GEO and wave is not None: d2=geod2(wave)
    w=kern(d2,rc)*inside
    if wave is None: Rt=np.broadcast_to(np.eye(4),(M,4,4)).copy(); Ric=np.zeros((N,4,4))
    else:
        om=omega(wave,mid); A=np.einsum('mu,muab->mab',dx,om)    # antisymmetric
        lam,V=np.linalg.eigh(1j*A); Rt=np.einsum('mij,mj,mkj->mik',V,np.exp(-1j*lam),V.conj()).real
        Ric=ricci_frame(wave,X)
    return w,w[:,None,None]*Rt,Ric
def assemble_vec(w,Rt,Ric,w2=None,Rt2=None,Ric2=None):
    if w2 is None: w2,Rt2,Ric2=w,Rt,Ric
    rows=[];cols=[];vals=[]
    for a in range(4):
        for b in range(4):
            rows+=[4*I_+a,4*J_+a]; cols+=[4*J_+b,4*I_+b]; vals+=[-Rt[:,a,b],-np.conj(Rt2[:,b,a])]
        rows+=[4*I_+a,4*J_+a]; cols+=[4*I_+a,4*J_+a]; vals+=[w.astype(complex),np.conj(w2).astype(complex)]
    Rs=0.5*(Ric+np.conj(Ric2).transpose(0,2,1))
    ii=np.repeat(np.arange(N),16); aa=np.tile(np.repeat(np.arange(4),4),N); bb=np.tile(np.tile(np.arange(4),4),N)
    rows.append(4*ii+aa); cols.append(4*ii+bb); vals.append(RICM*cL*Rs.reshape(-1).astype(complex))
    return sp.coo_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(4*N,4*N)).tocsr()
def assemble_sc(w,w2=None):
    if w2 is None: w2=w
    A=sp.coo_matrix((np.r_[-w,-np.conj(w2)],(np.r_[I_,J_],np.r_[J_,I_])),shape=(N,N)).tocsr()
    d=sp.coo_matrix((np.r_[w,np.conj(w2)].astype(complex),(np.r_[I_,J_],np.r_[I_,J_])),shape=(N,N)).tocsr()
    return A+d
X0=parts(None)
t=time.time(); Gv=np.linalg.inv(assemble_vec(*X0).toarray()+mu*np.eye(4*N)); Gs=np.linalg.inv(assemble_sc(X0[0]).toarray()+mu*np.eye(N))
print('N=%d cL=%.4f dist=%s ricci=%g inverse %.0fs'%(N,cL,'geo' if GEO else 'mid',RICM,time.time()-t),flush=True)
def tt(n):
    p=np.array(n,float); pn=p/np.linalg.norm(p); Bv=np.linalg.svd(np.outer(pn,pn))[0][:,1:]
    H=np.outer(Bv[:,0],Bv[:,1]); H=H+H.T; return H/np.sqrt(np.trace(H@H))
def gam2(G,Ap,Am,D2):
    tr1=(D2.multiply(G.T)).sum(); GA=np.asarray((Ap.T.dot(G.T)).T); GB=np.asarray((Am.T.dot(G.T)).T)
    return tr1-np.sum(GA*GB.T)          # second-order coefficient of ln det
def pi_of_p(n,eps=1e-3,which='both'):
    p=2*np.pi*np.array(n,float)/L; H=tt(n)
    P_=lambda k,a,ph=0: parts(Wave(H,p,a,ph,k))
    Lc=[(a-b)/2 for a,b in zip(P_('c',2*eps),P_('c',-2*eps))]; Ls=[(a-b)/2 for a,b in zip(P_('s',2*eps),P_('s',-2*eps))]
    Xp=[(c+1j*s)/2 for c,s in zip(Lc,Ls)]; Xm=[(c-1j*s)/2 for c,s in zip(Lc,Ls)]
    X2=[0*a for a in X0]
    for ph in (0,np.pi/2,np.pi,1.5*np.pi):
        A=P_('c',2*eps,ph); B=P_('c',-2*eps,ph); X2=[x+((a+b)/2-c)/4 for x,a,b,c in zip(X2,A,B,X0)]
    gv=gam2(Gv,assemble_vec(*Xp,*Xm),assemble_vec(*Xm,*Xp),assemble_vec(*X2))
    gs=gam2(Gs,assemble_sc(Xp[0],Xm[0]),assemble_sc(Xm[0],Xp[0]),assemble_sc(X2[0]))
    G2=0.5*gv-gs                         # Gamma = 1/2 ln det V - ln det L_ghost
    return (G2/eps**2/(N/rho)/2).real, (0.5*gv/eps**2/(N/rho)/2).real, (gs/eps**2/(N/rho)/2).real
def lndet_tot(Xw):
    V=assemble_vec(*Xw).toarray()+mu*np.eye(4*N); S=assemble_sc(Xw[0]).toarray()+mu*np.eye(N)
    return 0.5*np.linalg.slogdet(V)[1]-np.linalg.slogdet(S)[1]
def fd(n,eps=1e-3):
    p=2*np.pi*np.array(n,float)/L; H=tt(n); l0=lndet_tot(X0); tot=0
    for ph in (0,np.pi/2,np.pi,1.5*np.pi):
        tot+=(lndet_tot(parts(Wave(H,p,2*eps,ph,'c')))+lndet_tot(parts(Wave(H,p,-2*eps,ph,'c')))-2*l0)/2/eps**2/4
    return tot/(N/rho)/2
if __name__=='__main__':
    mode=sys.argv[4] if len(sys.argv)>4 else 'run'
    ns=[[1,0,0,0],[0,1,0,0],[1,1,0,0],[0,0,1,1],[2,0,0,0]]
    if mode=='check':
        for n in ns[:2]: print(n,'pert %.6f fd %.6f'%(pi_of_p(n)[0],fd(n)),flush=True)
    else:
        p2=[];v=[];vv=[];vg=[]
        for n in ns:
            p2.append((2*np.pi/L)**2*np.sum(np.array(n)**2)); a,b,c=pi_of_p(n); v.append(a); vv.append(b); vg.append(c)
            print('n=%s p^2=%.3f Pi_gauge=%.6f (vector %.6f, ghosts %.6f)'%(n,p2[-1],a,b,-c),flush=True)
        print('linear slope gauge field (1/64 pi G) = %.3e ; vector part %.3e ; ghosts %.3e'%(np.polyfit(p2,v,1)[0],np.polyfit(p2,vv,1)[0],-np.polyfit(p2,vg,1)[0]))
        c=np.polyfit(p2,v,2); print('quadratic fit: slope %.3e, curvature %.3e'%(c[1],c[0]))
