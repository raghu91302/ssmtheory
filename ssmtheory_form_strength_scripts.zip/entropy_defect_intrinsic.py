#!/usr/bin/env python3
"""
Library: the defected FCC complex and Regge deficits from edge labels.

Simplicial complex: FCC tetrahedral-octahedral honeycomb on a periodic box,
octahedra subdivided by a center vertex (8 tets each, 6 auxiliary edges of
flat length L0/sqrt2).  One tetrahedral void is replaced by four tets
around a trapped node c with four spokes.

build_complex(L) returns the edges, tetrahedra (as edge-index sextuples),
flat labels and node data; deficits(l, tedge, nE) returns 2 pi minus the sum
of dihedral angles at every edge.  Used by all defect scripts.
"""
import sys, numpy as np
from itertools import combinations
from scipy.optimize import least_squares
from entropy_fcc_real_harmonic import build_lattice

L0 = np.sqrt(2.0)

def dihedrals(sq):
    """sq: (nT,6) squared lengths ordered (01,02,03,12,13,23).
    Returns (nT,6) interior dihedral angles at those edges."""
    a = np.sqrt(sq[:,0]); b = np.sqrt(sq[:,1]); c = np.sqrt(sq[:,3])
    p0 = np.zeros((len(sq),3)); p1 = np.stack([a,0*a,0*a],1)
    x2 = (a*a + b*b - c*c)/(2*a); y2 = np.sqrt(np.maximum(b*b-x2*x2,1e-300))
    p2 = np.stack([x2,y2,0*a],1)
    d = np.sqrt(sq[:,2]); e = np.sqrt(sq[:,4]); f = np.sqrt(sq[:,5])
    x3 = (a*a + d*d - e*e)/(2*a)
    y3 = ((x3-x2)**2 + d*d - x3*x3 - f*f + y2*y2)/(2*y2)
    z3 = np.sqrt(np.maximum(d*d - x3*x3 - y3*y3, 1e-300))
    p3 = np.stack([x3,y3,z3],1)
    P = [p0,p1,p2,p3]
    out = np.zeros((len(sq),6)); k = 0
    for i,j in [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]:
        kk,ll = [m for m in range(4) if m not in (i,j)]
        u = P[j]-P[i]; u /= np.linalg.norm(u,axis=1)[:,None]
        vk = P[kk]-P[i]; vk -= (vk*u).sum(1)[:,None]*u
        vl = P[ll]-P[i]; vl -= (vl*u).sum(1)[:,None]*u
        cs = (vk*vl).sum(1)/np.linalg.norm(vk,axis=1)/np.linalg.norm(vl,axis=1)
        out[:,k] = np.arccos(np.clip(cs,-1,1)); k += 1
    return out

def wrapd(p,q,L):
    d=np.abs(np.array(p,float)-np.array(q,float)); d=np.minimum(d,L-d); return np.sqrt((d**2).sum())

def build_complex(L, defect=True):
    nodes,nidx,edges,eidx,octs = build_lattice(L)
    n = len(nodes)
    E = list(edges); Eidx = dict(eidx)
    phys = [True]*len(E)
    def add_edge(u,v,is_phys):
        key=tuple(sorted((u,v)))
        if key not in Eidx:
            Eidx[key]=len(E); E.append(key); phys.append(is_phys)
        return Eidx[key]
    tets = []
    # octahedra with center vertex
    cid = n
    for nb in octs:
        o = cid; cid += 1
        for v in nb.values(): add_edge(o,v,False)
        ax = {'x':((1,0,0),(-1,0,0)),'y':((0,1,0),(0,-1,0)),'z':((0,0,1),(0,0,-1))}
        for sx in ax['x']:
            for sy in ax['y']:
                for sz in ax['z']:
                    tets.append((o, nb[sx], nb[sy], nb[sz]))
    # tetrahedral voids
    c0 = (0.5,0.5,0.5); cdef = cid; cid += 1
    for cx in np.arange(0.5,L,1.0):
        for cy in np.arange(0.5,L,1.0):
            for cz in np.arange(0.5,L,1.0):
                bnd=[i for i,p in enumerate(nodes) if abs(wrapd((cx,cy,cz),p,L)-np.sqrt(3)/2)<1e-9]
                if len(bnd)!=4: continue
                if defect and (cx,cy,cz)==c0:
                    for v in bnd: add_edge(cdef,v,True)
                    for tri in combinations(bnd,3): tets.append((cdef,)+tri)
                else:
                    tets.append(tuple(bnd))
    nv = cid
    tets = np.array(tets)
    # edge index per tet, ordered (01,02,03,12,13,23)
    tedge = np.zeros((len(tets),6),int)
    for t,T in enumerate(tets):
        for k,(i,j) in enumerate([(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]):
            tedge[t,k] = add_edge(T[i],T[j],phys[Eidx[tuple(sorted((T[i],T[j])))]] if tuple(sorted((T[i],T[j]))) in Eidx else False)
    phys = np.array(phys)
    # flat labels
    lflat = np.zeros(len(E))
    for k,(u,v) in enumerate(E):
        pu = nodes[u] if u<n else None
        lflat[k] = 0  # filled below
    # positions of all vertices in the flat embedding (for flat labels only)
    pos = {i:np.array(nodes[i],float) for i in range(n)}
    cid = n
    for nb in octs:
        vs=[pos[v] for v in nb.values()]
        # center: the odd-parity point; reconstruct from minimum image around first vertex
        ref=vs[0]; ctr=np.mean([ref+(((v-ref)+L/2)%L-L/2) for v in vs],0); pos[cid]=ctr%L; cid+=1
    pos[cdef]=np.array(c0)
    for k,(u,v) in enumerate(E):
        lflat[k] = wrapd(pos[u],pos[v],L)
    return E, phys, tets, tedge, lflat, nodes, cdef, n

def deficits(l, tedge, nE):
    th = dihedrals((l[tedge])**2)
    s = np.zeros(nE); np.add.at(s, tedge.ravel(), th.ravel())
    return 2*np.pi - s
