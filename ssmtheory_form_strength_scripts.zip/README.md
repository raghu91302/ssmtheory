# Scripts for "The Form and the Strength of Induced Gravity on the Selection–Stitch Lattice"

Python 3 with numpy, scipy and matplotlib. All random numbers come from fixed seeds. Logs of the runs used in the paper are included.

| script | what it computes | paper |
|---|---|---|
| entropy_fig_ssm.py | schematic figures of the SSM | Figs. 1-2 |
| make_fig_phases.py | two-dimensional cartoon of the ocean, the lattice, and a trapped node | Fig. 3 |
| cov_memory.py | shear response R = K/(-kappa1) on a Poisson sprinkling; models `blend` (metric (1-mu)g + mu g0) and `graph` (remembered neighbors) | Tables 1-2 |
| lattice_control.py | the same memoryless operator on the D4 lattice points | Table 1 |
| entropy_ocean_delaunay_shear.py | fixed Delaunay triangulation with finite-element Laplacian from current edge lengths (R = 1.96) | Section 5 |
| excluded.py | density of a maximum-entropy ocean around an excluded ball | Fig. 4b |
| make_fig.py | Figure 4 from blend.log, graph.log, excluded.log | Fig. 4 |
| entropy_id_solve.py | trapped node as time-symmetric Regge initial data: vertex constraint on a conformally flat slice; spoke deficit and far-field mass; writes id_L{L}_q{q}.npy | Section 8 |
| entropy_defect_intrinsic.py, entropy_fcc_real_harmonic.py | complex, edge lengths and deficit routine used by entropy_id_solve.py | Section 8 |
| entropy_fig_defect.py | the trapped node and the curvature around it (needs id_L16_q0.1.npy) | Fig. 5 |
| entropy_equilibrium_slice.py | entanglement equilibrium of the solved slice, ball by ball, and source-free balls | Fig. 6 |
| make_fig_equilibrium.py | Figure 6 from equilibrium.log | Fig. 6 |
| entropy_bond_coupling.py | two-qubit bond model; maximum of s/a; local Newton constant under stretch; calibration and the consistency condition on C | Tables 3-4, Eq. (12) |
| make_fig_bond.py | Figure 7 | Fig. 7 |
| entropy_ocean_G_scalar.py, entropy_ocean_G_fermion.py, entropy_ocean_G_gauge.py, entropy_ocean_G_spinor.py | species weights of the induced Newton constant on a covariant sprinkled ocean (scalar, Wilson fermion, gauge field with ghosts, fermion from D^dag D) | Section 10 |

Commands:

    # figures of the SSM and the phases
    python3 entropy_fig_ssm.py
    python3 make_fig_phases.py

    # covariance and memory (seconds to a minute each)
    python3 cov_memory.py blend 6 20 11 0 0.25 0.5 0.75 0.9   > blend.log
    python3 cov_memory.py graph 6 20 12 0 0.25 0.5 0.75 1     > graph.log
    OCEAN_SIG=0.7 python3 cov_memory.py blend 8 10 21 0       # sprinkled row of Table 1
    OCEAN_SIG=0.7 python3 lattice_control.py 8                # lattice row, sigma = 0.7
    python3 lattice_control.py 8                              # lattice row, sigma = 1
    python3 entropy_ocean_delaunay_shear.py 5 2
    python3 excluded.py > excluded.log
    python3 make_fig.py

    # defect slice and equilibrium (a few minutes)
    python3 entropy_id_solve.py 16 7.6 0.001,0.1 > idsolve16.log
    python3 entropy_fig_defect.py
    python3 entropy_equilibrium_slice.py 16 7.6 0.01 > equilibrium.log
    python3 make_fig_equilibrium.py

    # bond model (seconds)
    python3 entropy_bond_coupling.py
    python3 make_fig_bond.py

    # sprinkled-ocean species weights (about 1 h each for the fermions and gauge fields)
    for s in 0.55 0.7 0.8; do
      OCEAN_TAPER=1 OCEAN_SIG=$s python3 entropy_ocean_G_scalar.py 8 1 geo 3.5
      OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=$s OCEAN_DIST=geo python3 entropy_ocean_G_fermion.py 6 2 0.1 1.0
      for ric in 1 0; do OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=$s python3 entropy_ocean_G_gauge.py 6 1 0.02 run geo $ric; done
    done
    for l in 1 0; do OCEAN_TAPER=1 OCEAN_CUT=3.5 OCEAN_SIG=0.7 python3 entropy_ocean_G_spinor.py 6 1 0.02 run geo $l; done
