"""Trapped node as time-symmetric Regge initial data.
Unknowns: conformal factor psi_v at every vertex (lattice nodes, octahedron centers, trapped node);
edge lengths l_e = psi_u psi_v l0_e. Equations (Hamiltonian constraint, one per interior vertex):
    sum_{e at v} l_e delta_e = 16 pi G m_v .
Source: a rest mass spread over the four spokes, mass per unit length mu;
each spoke gives half its proper mass mu*l_s to each end.  Q = 8 pi G mu sum_s l_s (proper source),
q = 8 pi G mu (input).  Vertices with r >= Rw from the void center are held at psi = 1.
Run: python3 entropy_id_solve.py L Rw q1,q2,... [line|node]   (line: q = 8 pi G mu; node: q = 8 pi G M with all mass at c)"""
import sys, time, numpy as np, scipy.sparse as sp
import entropy_defect_intrinsic as I
from scipy.optimize import least_squares

def setup(L, defect=True):
    E, phys, tets, tedge, lflat, nodes, cdef, n = I.build_complex(L, defect=defect)
    nodes_l, nidx, edges, eidx, octs = I.build_lattice(L)
    nE=len(E); nv=cdef+1
    P=np.zeros((nv,3))
    for i in range(n): P[i]=nodes[i]
    for j,nb in enumerate(octs):
        P[n+j]=(np.array(nodes[nb[(1,0,0)]],float)-np.array([1,0,0]))%L
    P[cdef]=(0.5,0.5,0.5)
    c0=np.array([.5,.5,.5]); dv=(P-c0+L/2)%L-L/2; r=np.linalg.norm(dv,axis=1)
    Eu=np.array([u for u,v in E]); Ev=np.array([v for u,v in E])
    return dict(E=E,tedge=tedge,lflat=lflat,cdef=cdef,n=n,nv=nv,r=r,Eu=Eu,Ev=Ev,nE=nE,P=P,dv=dv)

def build(C, Rw):
    nv,nE=C['nv'],C['nE']
    free=C['r']<Rw; idx=-np.ones(nv,int); idx[free]=np.arange(free.sum())
    # incidence vertex-edge
    A=sp.coo_matrix((np.ones(2*nE),(np.r_[C['Eu'],C['Ev']],np.r_[np.arange(nE),np.arange(nE)])),shape=(nv,nE)).tocsr()
    rows=[];cols=[]
    for T in C['tedge']:
        for a in T:
            for b in T: rows.append(a); cols.append(b)
    T=sp.coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(nE,nE)).tocsr()
    S=(A@T@A.T).tocsr(); S=S[free][:,free]; S.data[:]=1
    sp_e=np.array([k for k,(u,v) in enumerate(C['E']) if C['cdef'] in (u,v)])
    return free,idx,A,S,sp_e

def lengths(C,psi): return psi[C['Eu']]*psi[C['Ev']]*C['lflat']

MODE='line'   # 'line': mass mu per unit spoke length, half of each spoke to each end; 'node': fixed rest mass all at the trapped node (q is then 8 pi G M)
def residual(z,C,free,A,sp_e,q):
    psi=np.ones(C['nv']); psi[free]=z
    l=lengths(C,psi); d=I.deficits(l,C['tedge'],C['nE'])
    lhs=A@(l*d)
    m=np.zeros(C['nv'])            # 16 pi G m_v = 2 * 8 pi G m_v ; spoke s gives mu*l_s/2 to each end
    if MODE=='node':
        m[C['cdef']]=q
    else:
        for k in sp_e:
            m[C['Eu'][k]]+=q*l[k]/2; m[C['Ev'][k]]+=q*l[k]/2
    return (lhs-2*m)[free]

if __name__=="__main__":
    L=int(sys.argv[1]); Rw=float(sys.argv[2]); qs=[float(x) for x in sys.argv[3].split(',')]
    if len(sys.argv)>4: MODE=sys.argv[4]
    t=time.time(); C=setup(L); free,idx,A,S,sp_e=build(C,Rw)
    print(f"L={L} Rw={Rw}: vertices {C['nv']} free {free.sum()} edges {C['nE']} setup {time.time()-t:.0f}s",flush=True)
    z=np.ones(free.sum())
    for q in qs:
        t=time.time()
        sol=least_squares(residual,z,args=(C,free,A,sp_e,q),jac_sparsity=S,method='trf',xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=200)
        z=sol.x; res=np.abs(residual(z,C,free,A,sp_e,q)).max()
        psi=np.ones(C['nv']); psi[free]=z; l=lengths(C,psi); d=I.deficits(l,C['tedge'],C['nE'])
        Q=q*l[sp_e].sum() if MODE=='line' else q
        r=C['r']; n=C['n']; sel=(np.arange(C['nv'])<n)&(r>3)&(r<Rw-2)
        X=np.c_[1/r[sel],np.ones(sel.sum())]; coef=np.linalg.lstsq(X,psi[sel]-1,rcond=None)[0]
        Madm=2*coef[0]*8*np.pi        # psi-1 = G M/(2r) -> 8 pi G M = 16 pi coef
        np.save(f"id_L{L}_q{q}{'' if MODE=='line' else '_node'}.npy",psi)
        print(f" q={q:.3g}: resid {res:.1e} [{time.time()-t:.0f}s] Q=8piG*mu*sum l_s={Q:.5g} sum(l d)={np.sum(l*d):.5g} "
              f"8piG*M_far(fit)={Madm:.5g} ratio far/Q {Madm/Q:.4f} | psi_c {psi[C['cdef']]:.4f} spoke l/L0 {(l[sp_e]/I.L0).mean():.4f} "
              f"d_spoke {np.degrees(d[sp_e]).mean():.3f} max|d| other {np.degrees(np.abs(np.delete(d,sp_e)).max()):.3f}",flush=True)
