"""Fig. 5: (a) the trapped-node defect; (b) curvature around it in the initial-data solution
(largest |deficit| per shell of edge midpoints, in units of the spoke deficit q).
Needs id_L16_q0.1.npy from entropy_id_solve.py 16 7.6 ... ; run: python3 entropy_fig_defect.py"""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import entropy_defect_intrinsic as I, entropy_id_solve as R
plt.rcParams.update({"font.size":10,"axes.edgecolor":"#888"})
fig=plt.figure(figsize=(10,4))
ax=fig.add_subplot(1,2,1,projection='3d')
V=np.array([[0,0,0],[1,1,0],[1,0,1],[0,1,1]],float); c=V.mean(0)
for i in range(4):
    for j in range(i+1,4): ax.plot(*V[[i,j]].T,color="#2a5ea8",lw=2)
    ax.plot(*np.array([c,V[i]]).T,color="#c0392b",lw=2.5)
ax.scatter(*V.T,s=40,color="#222"); ax.scatter(*c,s=60,color="#c0392b")
for p,t in zip(V,"ABCD"): ax.text(*(p+(p-c)*0.18),t,fontsize=11)
ax.text(*(c+np.array([0.08,-0.05,0.08])),"c",fontsize=11,color="#c0392b")
ax.set_axis_off(); ax.view_init(18,30); ax.set_title("(a) trapped node: spokes (red), cage (blue)",fontsize=10,loc='left')
L=16; q=0.1; C=R.setup(L); psi=np.load(f"id_L{L}_q{q}.npy"); l=R.lengths(C,psi); d=I.deficits(l,C['tedge'],C['nE'])
P=C['dv']; mid=np.linalg.norm(P[C['Eu']]+((P[C['Ev']]-P[C['Eu']]+L/2)%L-L/2)/2,axis=1)
sp_e=np.array([k for k,(u,v) in enumerate(C['E']) if C['cdef'] in (u,v)])
other=np.ones(C['nE'],bool); other[sp_e]=False
bins=np.arange(0.2,6.61,0.8); rb=[];mx=[]
for a,b in zip(bins[:-1],bins[1:]):
    s=other&(mid>=a)&(mid<b)
    if s.any(): rb.append((a+b)/2); mx.append(np.abs(d[s]).max()/q)
ax2=fig.add_subplot(1,2,2)
ax2.loglog(rb,mx,'-o',color="#2a5ea8",lw=2,ms=4)
rr=np.array([1.2,5.5]); ax2.loglog(rr,mx[2]*(rr/rb[2])**-3,':',color="#999",lw=1); ax2.text(4,mx[2]*(4/rb[2])**-3*1.6,r"$r^{-3}$",color="#777")
ax2.set_xlabel("distance of edge midpoint from void center (half-cells)"); ax2.set_ylabel(r"largest $|\delta_e|\,/\,\delta_{\rm spoke}$")
from matplotlib.ticker import FixedLocator, NullFormatter, FixedFormatter
ax2.xaxis.set_major_locator(FixedLocator([0.6,1,2,3,4,6])); ax2.xaxis.set_major_formatter(FixedFormatter(['0.6','1','2','3','4','6'])); ax2.xaxis.set_minor_formatter(NullFormatter())
ax2.set_title(r"(b) curvature off the spokes ($q=0.1$)",fontsize=10,loc='left'); ax2.grid(alpha=0.25,which='both',lw=0.5)
for s in ("top","right"): ax2.spines[s].set_visible(False)
fig.tight_layout(); fig.savefig('fig_defect.pdf'); fig.savefig('fig_defect.png',dpi=110)
print(list(zip(np.round(rb,2),np.round(mx,4))))
