"""
xx_pinned.py: XX-merge threshold with the merged sheet pair held fixed.

The primitive search in sheet_code_xx_surgery_toric.find_xx_primitive_toric
returns whichever valid operator has least weight, without constraining which
two sheets it joins. At L = 8 the global minimum is a weight-16 operator on
{xy, xz}, while at L = 4 and L = 6 it lands on {xz, yz}; a weight-20 operator
spanning all three sheets also exists at L = 8. Comparing sizes that merge
different sheet pairs, or that merge three sheets instead of two, is not a
like-for-like threshold measurement.

This module pins the pair to {xz, yz} at every L, so the same operation is
measured at every size, and re-runs the sweep.
"""
from __future__ import annotations
import sys, json, argparse
import numpy as np
import pymatching

import sheet_code_xx_surgery_toric as XX
from sheet_code_fcc_lattice import (build_fcc_lattice, vertex_Z_stabilizers,
                                    oct_void_X_stabilizers, fcc_triangles)
from sheet_code_gf2 import gf2_rank, gf2_kernel

PAIR = ('xz', 'yz')
_cache = {}


def pinned_primitive(L, pair=PAIR):
    """Least-weight valid XX primitive whose support lies in exactly `pair`."""
    key = (L, pair)
    if key in _cache:
        return _cache[key]
    _, _, _, _, _, e2s = build_fcc_lattice(L)
    HZ, _ = vertex_Z_stabilizers(L)
    HX, _ = oct_void_X_stabilizers(L)
    tris, B = fcc_triangles(L)
    valid = gf2_kernel((HZ @ B.T) % 2)
    ops = (valid @ B) % 2
    wts = ops.sum(axis=1)
    rk = gf2_rank(HX)
    want = set(pair)
    for i in np.argsort(wts):
        if wts[i] == 0:
            continue
        op = ops[i]
        sup = np.where(op == 1)[0]
        if {e2s[int(e)] for e in sup} != want:
            continue
        if gf2_rank(np.vstack([HX, op.reshape(1, -1)])) <= rk:
            continue
        out = (valid[i], op, int(wts[i]))
        _cache[key] = out
        return out
    raise RuntimeError(f"no primitive on {pair} at L={L}")


def run_point(L, p, shots, seed):
    XX.find_xx_primitive_toric = pinned_primitive          # pin the search
    c, *_ = XX.build_xx_surgery_circuit_v2(L, L, p)
    dem = c.detector_error_model(decompose_errors=True)
    m = pymatching.Matching.from_detector_error_model(dem)
    ev, fl = c.compile_detector_sampler(seed=seed).sample(
        shots=shots, separate_observables=True)
    n = int(np.sum(m.decode_batch(ev) != fl))
    return n / shots, n


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("L", type=int)
    ap.add_argument("shots", type=int)
    ap.add_argument("ps", type=float, nargs="+")
    ap.add_argument("--seed", type=int, default=20260827)
    a = ap.parse_args()
    ts, op, w = pinned_primitive(a.L)
    print(f"L={a.L}: pinned primitive on {PAIR}, weight {w} (2L={2*a.L}), "
          f"{int(ts.sum())} triangles", flush=True)
    for p in a.ps:
        r, n = run_point(a.L, p, a.shots, a.seed + int(round(p * 1e6)))
        with open("xx_pinned.jsonl", "a") as f:
            f.write(json.dumps({"L": a.L, "p": p, "rate": r,
                                "n_err": n, "n_shots": a.shots,
                                "weight": w, "pair": list(PAIR)}) + "\n")
        print(f"  p={p:.4f}  rate {r:.5f}  ({n}/{a.shots})", flush=True)
