"""Analyze CNOT LER sweep data and produce a publication figure."""
import json, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Load data
files = {
    4: '/home/claude/cnot_ler_dL_L4.json',
    6: '/home/claude/cnot_ler_dL_L6.json',
    8: '/home/claude/cnot_ler_dL_L8.json',
}

data = {}
for L, f in files.items():
    try:
        d = json.load(open(f))
        ps = np.array([r['p'] for r in d])
        lers = np.array([r['ler'] for r in d])
        ses = np.array([r['ler_se'] for r in d])
        ns = np.array([r['n_shots'] for r in d])
        data[L] = {'p': ps, 'ler': lers, 'ler_se': ses, 'n_shots': ns}
    except Exception as e:
        print(f'L={L}: {e}')

# Find pairwise crossings (where LER curves intersect, indicating threshold)
def find_crossing(p_a, ler_a, p_b, ler_b):
    """Find p where LER_a == LER_b, by linear interpolation."""
    # Need common p grid
    common_p = sorted(set(p_a) & set(p_b))
    if len(common_p) < 2:
        return None
    diffs = []
    for p in common_p:
        i_a = list(p_a).index(p)
        i_b = list(p_b).index(p)
        diffs.append((p, ler_a[i_a] - ler_b[i_b]))
    # Find sign change
    for i in range(len(diffs) - 1):
        p1, d1 = diffs[i]
        p2, d2 = diffs[i+1]
        if d1 * d2 < 0:
            # Linear interp
            p_cross = p1 - d1 * (p2 - p1) / (d2 - d1)
            return p_cross
    return None

# L=4 vs L=6
if 4 in data and 6 in data:
    p_th_46 = find_crossing(data[4]['p'], data[4]['ler'], data[6]['p'], data[6]['ler'])
    print(f"L=4 vs L=6 crossing: {p_th_46:.4f} ({p_th_46*100:.3f}%)" if p_th_46 else "no crossing")

# L=6 vs L=8
if 6 in data and 8 in data:
    p_th_68 = find_crossing(data[6]['p'], data[6]['ler'], data[8]['p'], data[8]['ler'])
    print(f"L=6 vs L=8 crossing: {p_th_68:.4f} ({p_th_68*100:.3f}%)" if p_th_68 else "no clear crossing")

# Plot
fig, ax = plt.subplots(figsize=(6, 4.5), dpi=120)
colors = {4: '#1f77b4', 6: '#ff7f0e', 8: '#2ca02c'}
markers = {4: 'o', 6: 's', 8: '^'}
for L in sorted(data.keys()):
    d = data[L]
    ax.errorbar(d['p']*100, d['ler'], yerr=d['ler_se'],
                marker=markers[L], color=colors[L],
                label=f'L={L}, d={L}', markersize=7,
                linewidth=1.5, capsize=3)

ax.set_xscale('log')
ax.set_yscale('log')
ax.set_xlabel('Physical error rate $p$ (%)')
ax.set_ylabel('Logical error rate per CNOT (any of $\\mathrm{Obs}_0$, $\\mathrm{Obs}_1$ flipped)')
ax.set_title('Three-sheet Horsman CNOT under depolarizing noise\n(MWPM decoding, $d_{\\mathrm{each}}=L$)')
ax.grid(True, which='both', alpha=0.3)
ax.legend(loc='lower right')
if p_th_46:
    ax.axvline(p_th_46*100, ls='--', color='gray', alpha=0.5)
    ax.text(p_th_46*100*1.05, 0.02, f'$L=4$↔$L=6$ crossing\n$p\\approx {p_th_46*100:.2f}\\%$',
            fontsize=8, color='gray')
plt.tight_layout()
plt.savefig('/home/claude/fig_cnot_ler.pdf', bbox_inches='tight')
plt.savefig('/home/claude/fig_cnot_ler.png', bbox_inches='tight', dpi=150)
print(f"\nSaved figure to /home/claude/fig_cnot_ler.pdf and .png")

# Print summary table
print("\n\nSummary table:")
print(f"{'p (%)':<10}{'L=4':<25}{'L=6':<25}{'L=8':<25}")
all_p = sorted(set(p for d in data.values() for p in d['p']))
for p in all_p:
    row = f"{p*100:<10.3f}"
    for L in [4, 6, 8]:
        if L in data and p in data[L]['p']:
            i = list(data[L]['p']).index(p)
            ler = data[L]['ler'][i]
            se = data[L]['ler_se'][i]
            row += f"{ler:.4f} ± {se:.4f}    "
        else:
            row += " " * 25
    print(row)
