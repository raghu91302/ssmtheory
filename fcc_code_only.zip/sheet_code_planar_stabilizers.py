"""Planar v4: rough boundary on z for ALL sheets (so triangle chains extending in z reach rough boundaries)."""
import sys
import numpy as np
from itertools import product


from sheet_code_fcc_lattice import NN_DISPLACEMENTS, SHEETS
from sheet_code_gf2 import gf2_rank, gf2_kernel
from sheet_code_planar_lattice import build_fcc_lattice_planar
from sheet_code_planar_lattice import fcc_triangles_planar


def planar_stabs_v4(L):
    """Rough on z for all sheets, smooth on x and y.
    
    Actually wait — for each sheet, only TWO directions are in-plane.
    - S_xy is planar in (x, y); its boundary directions are +x, -x, +y, -y
    - S_xz is planar in (x, z); boundary directions are +x, -x, +z, -z
    - S_yz is planar in (y, z); boundary directions are +y, -y, +z, -z
    
    Each sheet needs rough boundary in some direction and smooth in the other.
    
    For triangle chain extending in z:
    - The xy-edges cancel (we need them to)
    - S_xz: triangle chain extends in z → need rough boundary on z direction of S_xz
    - S_yz: triangle chain extends in z → need rough boundary on z direction of S_yz
    - S_xy: doesn't matter for this primitive (xy edges cancel)
    
    So choose:
    - S_xy: rough x, smooth y (arbitrary choice — xy primitive doesn't go through this sheet)
    - S_xz: rough z, smooth x
    - S_yz: rough z, smooth y
    """
    vertices, vidx, edges, _, edge_to_idx, edge_to_sheet = build_fcc_lattice_planar(L)
    n = len(edges)
    
    # Rough-boundary direction for each sheet (drop X-stabs on this direction's boundary)
    # Smooth-boundary direction (drop Z-stabs on this direction's boundary)
    rough_dir = {'xy': 'x', 'xz': 'z', 'yz': 'z'}
    smooth_dir = {'xy': 'y', 'xz': 'x', 'yz': 'y'}
    
    def is_on_dir_boundary(pos, direction):
        idx = {'x': 0, 'y': 1, 'z': 2}[direction]
        return pos[idx] == 0 or pos[idx] == L-1
    
    Z_rows, Z_meta = [], []
    X_rows, X_meta = [], []
    
    for vi, v_pos in enumerate(vertices):
        x1, y1, z1 = v_pos
        for sheet in SHEETS:
            row = np.zeros(n, dtype=np.int8)
            count = 0
            for d in NN_DISPLACEMENTS[sheet]:
                x2, y2, z2 = x1+d[0], y1+d[1], z1+d[2]
                if not (0 <= x2 < L and 0 <= y2 < L and 0 <= z2 < L):
                    continue
                v2 = (x2, y2, z2)
                if v2 not in vidx:
                    continue
                i1, i2 = vi, vidx[v2]
                e = (min(i1, i2), max(i1, i2))
                if e in edge_to_idx:
                    row[edge_to_idx[e]] = 1
                    count += 1
            if count == 0:
                continue
            
            # Z-stab: keep weight-4 (bulk) or weight-2 on rough boundary, drop on smooth boundary
            keep = False
            if count == 4:
                keep = True
            elif count == 2:
                on_rough = is_on_dir_boundary(v_pos, rough_dir[sheet])
                on_smooth = is_on_dir_boundary(v_pos, smooth_dir[sheet])
                keep = on_rough and not on_smooth
            
            if keep:
                Z_rows.append(row)
                Z_meta.append((sheet, v_pos, count))
    
    oct_centers = [(x, y, z) for x, y, z in product(range(L), repeat=3) if (x+y+z) % 2 == 1]
    
    for c in oct_centers:
        cx, cy, cz = c
        for sheet in SHEETS:
            if sheet == 'xy':
                pairs = [((cx+1, cy, cz), (cx, cy+1, cz)), ((cx+1, cy, cz), (cx, cy-1, cz)),
                         ((cx-1, cy, cz), (cx, cy+1, cz)), ((cx-1, cy, cz), (cx, cy-1, cz))]
            elif sheet == 'xz':
                pairs = [((cx+1, cy, cz), (cx, cy, cz+1)), ((cx+1, cy, cz), (cx, cy, cz-1)),
                         ((cx-1, cy, cz), (cx, cy, cz+1)), ((cx-1, cy, cz), (cx, cy, cz-1))]
            else:
                pairs = [((cx, cy+1, cz), (cx, cy, cz+1)), ((cx, cy+1, cz), (cx, cy, cz-1)),
                         ((cx, cy-1, cz), (cx, cy, cz+1)), ((cx, cy-1, cz), (cx, cy, cz-1))]
            
            row = np.zeros(n, dtype=np.int8)
            count = 0
            for ap, bp in pairs:
                if not (0 <= ap[0] < L and 0 <= ap[1] < L and 0 <= ap[2] < L): continue
                if not (0 <= bp[0] < L and 0 <= bp[1] < L and 0 <= bp[2] < L): continue
                if ap not in vidx or bp not in vidx: continue
                ai, bi = vidx[ap], vidx[bp]
                e = (min(ai, bi), max(ai, bi))
                if e in edge_to_idx:
                    row[edge_to_idx[e]] = 1
                    count += 1
            if count == 0:
                continue
            
            # X-stab: keep weight-4 or weight-2 on smooth boundary, drop on rough boundary
            keep = False
            if count == 4:
                keep = True
            elif count == 2:
                on_rough = is_on_dir_boundary(c, rough_dir[sheet])
                on_smooth = is_on_dir_boundary(c, smooth_dir[sheet])
                keep = on_smooth and not on_rough
            
            if keep:
                X_rows.append(row)
                X_meta.append((sheet, c, count))
    
    return (np.array(Z_rows, dtype=np.int8), Z_meta,
            np.array(X_rows, dtype=np.int8), X_meta)


if __name__ == '__main__':
    for L in [4, 6]:
        print(f"\n=== Planar v4 (rough z for xz/yz) at L = {L} ===")
        vertices, _, edges, _, _, _ = build_fcc_lattice_planar(L)
        n = len(edges)
        HZ, Z_meta, HX, X_meta = planar_stabs_v4(L)
    
        css = (HX @ HZ.T) % 2
        n_anticomm = int(np.sum(css))
        rank_Z = gf2_rank(HZ)
        rank_X = gf2_rank(HX)
        k = n - rank_Z - rank_X
        print(f"  HZ: {HZ.shape}, HX: {HX.shape}")
        print(f"  anticomm={n_anticomm}, rank_Z={rank_Z}, rank_X={rank_X}, k={k}")
    
        # Check for primitive
        triangles, B = fcc_triangles_planar(L)
        M_commute = (HX @ B.T) % 2
        valid_sets = gf2_kernel(M_commute)
        print(f"  {len(triangles)} triangles, {valid_sets.shape[0]} valid sets")
    
        # Find min-weight non-trivial logical from valid sets (+ pairs)
        rank_HZ = gf2_rank(HZ)
        best = None
        min_w = float('inf')
        for i, vs in enumerate(valid_sets):
            op = (vs @ B) % 2
            w = int(op.sum())
            if w == 0:
                continue
            test = np.vstack([HZ, op.reshape(1, -1)])
            if gf2_rank(test) > rank_HZ and w < min_w:
                min_w = w
                best = (vs, op, w, i)
    
        if best:
            vs, op, w, idx = best
            n_tri = int(vs.sum())
            print(f"  Min-weight primitive: {n_tri} triangles, Op weight {w} (set index {idx})")
        else:
            print(f"  NO primitive found from single valid sets, trying pairs...")
            for i in range(valid_sets.shape[0]):
                for j in range(i+1, valid_sets.shape[0]):
                    combo = (valid_sets[i] + valid_sets[j]) % 2
                    op = (combo @ B) % 2
                    w = int(op.sum())
                    if w == 0: continue
                    test = np.vstack([HZ, op.reshape(1, -1)])
                    if gf2_rank(test) > rank_HZ and w < min_w:
                        min_w = w
                        best = (combo, op, w, (i, j))
            if best:
                combo, op, w, ij = best
                n_tri = int(combo.sum())
                print(f"  Found via pair: {n_tri} triangles, Op weight {w}, sets {ij}")
            else:
                print(f"  NO primitive found at all")
