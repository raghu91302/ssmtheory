"""Find CSS-paired Z-logical for a given X-logical (and vice versa) in a sheet.

The key property: for a code with multiple logical qubits, X_i and Z_j satisfy
[X_i, Z_j] = 0 if i != j and {X_i, Z_j} = 0 (overlap exactly 1 mod 2) if i == j.

For our purposes, we want Z_T paired with the specific X_T from the XX-primitive.
Z_T must:
  (a) commute with all Z-stabs (be in HX kernel)
  (b) NOT be in HZ rowspan (non-trivial)
  (c) anticommute with X_T at exactly odd overlap (overlap = 1 canonical)
  (d) commute with ALL OTHER X-logicals (overlap even with them)

Implementation: build a basis of X-logicals of the sheet. Z_T is dual to X_T in this basis.
"""
import numpy as np
from sheet_code_gf2 import gf2_rank, gf2_kernel


def find_logical_basis(H_dual, H_self):
    """Find a basis of logical operators in the given sheet.
    
    H_dual: parity check matrix that logicals must commute with (e.g., HZ for X-logicals)
    H_self: parity check matrix whose rowspan defines trivial operators
    
    Returns: list of basis vectors (n-element arrays), one per logical qubit.
    
    Fast implementation using a single Gauss-Jordan pass.
    """
    kernel = gf2_kernel(H_dual)
    if kernel.shape[0] == 0:
        return []
    
    if H_self.shape[0] == 0:
        return [k.copy() for k in kernel]
    
    n_self = H_self.shape[0]
    n_cols = H_self.shape[1]
    
    # Build augmented matrix [H_self; kernel] and Gauss-Jordan tracking row origin
    aug = np.vstack([H_self.astype(np.uint8), kernel.astype(np.uint8)])
    row_ids = list(range(n_self + kernel.shape[0]))
    new_pivot_kernel_indices = []
    pivot_row = 0
    for col in range(n_cols):
        # Prefer H_self rows as pivots
        piv_idx = None
        for k in range(pivot_row, aug.shape[0]):
            if aug[k, col] == 1 and row_ids[k] < n_self:
                piv_idx = k
                break
        if piv_idx is None:
            for k in range(pivot_row, aug.shape[0]):
                if aug[k, col] == 1:
                    piv_idx = k
                    break
        if piv_idx is None:
            continue
        if piv_idx != pivot_row:
            aug[[pivot_row, piv_idx]] = aug[[piv_idx, pivot_row]]
            row_ids[pivot_row], row_ids[piv_idx] = row_ids[piv_idx], row_ids[pivot_row]
        if row_ids[pivot_row] >= n_self:
            new_pivot_kernel_indices.append(row_ids[pivot_row] - n_self)
        col_vals = aug[:, col].copy()
        col_vals[pivot_row] = 0
        mask = col_vals == 1
        aug[mask] = (aug[mask] + aug[pivot_row]) % 2
        pivot_row += 1
    
    return [kernel[i].copy() for i in new_pivot_kernel_indices]


def find_paired_Z_logical(HZ_sheet, HX_sheet, X_target):
    """Find Z-logical in the sheet that pairs with X_target (CSS partner).
    
    Approach: find a basis of X-logicals, identify which basis vector X_target
    'covers', replace that basis vector with X_target, then find Z dual to X_target
    in the modified basis (anticommutes with X_target, commutes with the rest).
    """
    n = HX_sheet.shape[1]
    
    # First check X_target is a valid X-logical
    if ((HZ_sheet @ X_target) % 2).any():
        return None  # doesn't commute with Z-stabs
    
    rank_HX = gf2_rank(HX_sheet)
    test_xt = np.vstack([HX_sheet, X_target.reshape(1, -1)])
    if gf2_rank(test_xt) <= rank_HX:
        return None  # X_target is trivial (in HX rowspan)
    
    # Find basis of X-logicals (each independent of HX_sheet and prior basis vectors)
    x_basis = find_logical_basis(HZ_sheet, HX_sheet)
    if len(x_basis) == 0:
        return None
    
    # Find which basis vector X_target 'covers' by trying to add X_target without it
    # The idea: x_basis[i] is the one to replace iff removing it and adding X_target keeps the span.
    # Equivalent: X_target is independent of x_basis without index i (modulo HX).
    replace_idx = None
    for i in range(len(x_basis)):
        # Build basis without x_basis[i], plus HX_sheet
        without_i = HX_sheet.copy()
        for j, x in enumerate(x_basis):
            if j != i:
                without_i = np.vstack([without_i, x.reshape(1, -1)])
        # Check X_target independent of this
        rank_without = gf2_rank(without_i)
        rank_with_xt = gf2_rank(np.vstack([without_i, X_target.reshape(1, -1)]))
        if rank_with_xt > rank_without:
            replace_idx = i
            break
    if replace_idx is None:
        return None
    
    # Build new basis: replace x_basis[replace_idx] with X_target
    new_x_basis = list(x_basis)
    new_x_basis[replace_idx] = X_target.copy()
    
    # Now find Z dual to X_target: anticommutes with X_target, commutes with other new_x_basis
    z_basis = find_logical_basis(HX_sheet, HZ_sheet)
    if len(z_basis) == 0:
        return None
    
    # Solve for coefficients a such that Z = sum a_i z_basis[i] satisfies:
    #   Z · X_target = 1
    #   Z · new_x_basis[j] = 0 for j != replace_idx
    # M[k, i] = z_basis[i] · new_x_basis[k] (mod 2). Want M^T @ a = e_{replace_idx} (standard basis vec)
    n_logicals = len(new_x_basis)
    n_z = len(z_basis)
    M = np.zeros((n_logicals, n_z), dtype=np.int8)
    for k in range(n_logicals):
        for i in range(n_z):
            M[k, i] = (z_basis[i] * new_x_basis[k]).sum() % 2
    target = np.zeros(n_logicals, dtype=np.int8)
    target[replace_idx] = 1
    
    # Solve M @ a = target  (where M is n_logicals x n_z, both should be 8 for L=4 toric)
    # Use Gauss-Jordan
    aug = np.hstack([M.copy(), target.reshape(-1, 1)])
    rows, cols = aug.shape
    r = 0
    pivot_cols = []
    for c in range(cols - 1):
        for k in range(r, rows):
            if aug[k, c] == 1:
                aug[[r, k]] = aug[[k, r]]
                for k2 in range(rows):
                    if k2 != r and aug[k2, c] == 1:
                        aug[k2] = (aug[k2] + aug[r]) % 2
                pivot_cols.append(c)
                r += 1
                break
        if r >= rows:
            break
    
    # Check consistency
    for k in range(r, rows):
        if aug[k, -1] == 1:
            return None
    
    # Particular solution
    a = np.zeros(n_z, dtype=np.int8)
    for pi, pc in enumerate(pivot_cols):
        a[pc] = aug[pi, -1]
    
    # Z = sum a_i z_basis[i]
    Z = np.zeros(n, dtype=np.int8)
    for i, ai in enumerate(a):
        if ai == 1:
            Z = (Z + z_basis[i]) % 2
    
    # Verify
    overlap_target = int((Z * X_target).sum() % 2)
    if overlap_target != 1:
        return None
    for j, x in enumerate(new_x_basis):
        if j != replace_idx:
            if int((Z * x).sum() % 2) != 0:
                return None
    
    return Z


if __name__ == '__main__':
    from sheet_code_fcc_lattice import (
        build_fcc_lattice, fcc_triangles,
        vertex_Z_stabilizers, oct_void_X_stabilizers
    )
    from find_3sheet_primitives import find_z_primitives_by_sheet_pair, find_x_primitives_by_sheet_pair
    
    L = 4
    _, _, _, edges, _, edge_to_sheet = build_fcc_lattice(L)
    HZ, _ = vertex_Z_stabilizers(L)
    HX, _ = oct_void_X_stabilizers(L)
    
    xs = find_x_primitives_by_sheet_pair(L)
    # Use X-prim spanning xy, yz → T=xy or yz, A=yz or xy
    for sheets, (xt, xo, _) in xs.items():
        if sheets == frozenset(['xy', 'yz']):
            X_op = xo
            break
    
    T_sheet = 'xy'  # T's sheet
    T_idxs = np.array([i for i, s in enumerate(edge_to_sheet) if s == T_sheet], dtype=int)
    HZ_T = HZ[:, T_idxs]
    HX_T = HX[:, T_idxs]
    
    # X_T local in T_sheet
    X_T_local = np.zeros(len(T_idxs), dtype=np.int8)
    for i, idx in enumerate(T_idxs):
        if X_op[idx] == 1:
            X_T_local[i] = 1
    
    print(f"X_T weight in T_sheet: {int(X_T_local.sum())}")
    
    Z_T_local = find_paired_Z_logical(HZ_T, HX_T, X_T_local)
    if Z_T_local is None:
        print("FAILED to find paired Z_T")
    else:
        print(f"Z_T weight: {int(Z_T_local.sum())}")
        print(f"Overlap with X_T: {int((Z_T_local * X_T_local).sum() % 2)}")
        # Check commutes with all other X-logicals
        x_basis = find_logical_basis(HZ_T, HX_T)
        print(f"X-basis has {len(x_basis)} logicals")
        for i, x in enumerate(x_basis):
            overlap = int((Z_T_local * x).sum() % 2)
            target_overlap = int((X_T_local * x).sum() % 2)
            print(f"  X-basis[{i}]: Z_T overlap = {overlap}, X_T overlap = {target_overlap}")
