"""FSS diagnostics requested in review, built on the author's own fit routine."""
from __future__ import annotations
import numpy as np
from scipy.optimize import curve_fit
from sheet_code_formal_fss_fit import load_results, fss_model


def fit(merged, p_range, p0, drop_L=None, drop_p=None, keep_L=None):
    P, L, R, S = [], [], [], []
    for (l, p), v in merged.items():
        if not (p_range[0] <= p <= p_range[1]):            continue
        if v['n_err'] < 5:                                  continue
        if drop_L is not None and l == drop_L:              continue
        if keep_L is not None and l not in keep_L:          continue
        if drop_p is not None and abs(p - drop_p) < 1e-12:  continue
        r = v['n_err'] / v['n_shots']
        P.append(p); L.append(l); R.append(r)
        S.append(max(np.sqrt(r * (1 - r) / v['n_shots']), 1e-4))
    if len(P) < 6:
        return None
    P, L, R, S = map(np.array, (P, L, R, S))
    try:
        popt, pcov = curve_fit(fss_model, (P, L), R, sigma=S, p0=p0,
                               absolute_sigma=True, maxfev=40000)
    except Exception:
        return None
    perr = np.sqrt(np.diag(pcov))
    chi2 = float(np.sum(((R - fss_model((P, L), *popt)) / S) ** 2))
    return dict(p_th=popt[0], p_th_err=perr[0], nu=popt[1], nu_err=perr[1],
                chi2=chi2, dof=len(P) - 5, n=len(P))


def report(label, path, p_range, p0):
    merged = load_results(path)
    print(f"\n{'='*76}\n  {label}\n{'='*76}")
    print("  ansatz  P_L(p) = A + Bx + Cx^2,  x = (p - p_th) L^(1/nu)")
    print("  free parameters: 5 (p_th, nu, A, B, C); points with >=5 failures only")
    print(f"  window  p in [{p_range[0]:.3f}, {p_range[1]:.3f}]")
    print(f"\n  {'variant':<28}{'p_th (%)':>18}{'nu':>16}{'n':>4}{'chi2/dof':>10}")
    print("  " + "-"*72)
    def row(tag, f):
        if f is None:
            print(f"  {tag:<28}{'did not converge':>18}"); return None
        print(f"  {tag:<28}{100*f['p_th']:>10.3f} +/-{100*f['p_th_err']:<6.3f}"
              f"{f['nu']:>9.2f} +/-{f['nu_err']:<6.2f}{f['n']:>4}"
              f"{f['chi2']/f['dof']:>10.2f}")
        return f
    base = row("all sizes (manuscript)", fit(merged, p_range, p0))
    sizes = sorted({l for l, _ in merged})
    for L in sizes:
        row(f"without L = {L}", fit(merged, p_range, p0, drop_L=L))
    row(f"only L = {sizes[-2]}, {sizes[-1]}",
        fit(merged, p_range, p0, keep_L=set(sizes[-2:])))
    ps = sorted({p for (_, p) in merged if p_range[0] <= p <= p_range[1]})
    vals = [f['p_th'] for f in (fit(merged, p_range, p0, drop_p=q) for q in ps) if f]
    print("  " + "-"*72)
    if vals:
        print(f"  leave-one-p-out ({len(vals)}/{len(ps)} converged): p_th spans "
              f"{100*min(vals):.3f}% to {100*max(vals):.3f}%, "
              f"spread {100*(max(vals)-min(vals)):.3f} pp")
    if base:
        s = (base['chi2']/base['dof'])**0.5
        print(f"  chi2/dof = {base['chi2']/base['dof']:.2f} -> inflating the quoted "
              f"error by {s:.2f} gives {100*base['p_th']:.3f} "
              f"+/- {100*base['p_th_err']*s:.3f}%")


if __name__ == "__main__":
    report("ZZ-merge, toric", "surgery_threshold_results.json",
           (0.007, 0.015), [0.010, 1.5, 0.30, 5.0, 0.0])
    report("Planar, boundary-aware", "planar_ba_threshold_results.json",
           (0.004, 0.012), [0.008, 1.5, 0.20, 5.0, 0.0])
    report("XX-merge, toric (pinned pair)", "xx_surgery_results_pinned.json",
           (0.005, 0.015), [0.008, 1.5, 0.25, 5.0, 0.0])
