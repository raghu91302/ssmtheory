"""Full Horsman CNOT truth table verification for the toric sheet code.

Protocol: merge-split-merge with Pauli-frame tracking via OBSERVABLE_INCLUDE.

Three logical qubits in three sheets of one toric FCC sheet code at L=4:
  - C in S_xz (one specific Z-logical)
  - A in S_yz (initialized in |+>_L, will be measured in X-basis at end)
  - T in S_xy (one specific Z-logical)

Phases:
  1. Pre-merge: d rounds of standard syndrome extraction
  2. ZZ-merge: d rounds with Z-triangles active (measures Z_C tensor Z_A)
  3. Split-1: d rounds, no triangles (gauge stabilizers restored)
  4. XX-merge: d rounds with X-triangles active (measures X_A tensor X_T)
  5. Split-2: d rounds, no triangles
  6. Destructive measurement: all data in Z-basis

For computational basis input |c>|t>:
  - Initialize data in |0>, then apply X_T-string if t=1 and X_C-string if c=1
  - A's data: apply H to put each in |+> (so logical A is in |+>)
  
Observable definitions for the truth table:
  Obs 0 (Z_C output) = parity of data qubits in Z_C string at end
                     - should equal c (no correction needed in Z basis)
  Obs 1 (Z_T output) = parity of Z_T string at end XOR (sum of X-merge triangle outcomes)
                     - the X-correction from m_XX flips Z_T readout
                     - should equal c XOR t

If both observables are deterministic at p=0 and match the truth table for all 4 inputs,
the Horsman CNOT is verified.
"""
import sys
import os
import json
import numpy as np
import stim

from sheet_code_fcc_lattice import (
    build_fcc_lattice, fcc_triangles,
    vertex_Z_stabilizers, oct_void_X_stabilizers
)
from sheet_code_gf2 import gf2_rank, gf2_kernel
from find_3sheet_primitives_fast import (
    find_z_primitives_by_sheet_pair_fast as find_z_primitives_by_sheet_pair,
    find_x_primitives_by_sheet_pair_fast as find_x_primitives_by_sheet_pair,
)
from css_dual import find_paired_Z_logical


def pick_3sheet_decomposition(L):
    """Return (z_ts, z_op, x_ts, x_op, C_sheet, A_sheet, T_sheet) at L.
    
    Searches over Z- and X-primitive candidates (multiple low-weight options per
    sheet-pair) to find a decomposition where the two primitives:
      - span 3 distinct sheets sharing exactly A's sheet,
      - share zero triangles (no contradictory measurement basis), AND
      - share exactly one data qubit (the CSS-pair anchor of A's logicals).
    """
    zs = find_z_primitives_by_sheet_pair(L)
    xs = find_x_primitives_by_sheet_pair(L)
    for z_sheets, z_candidates in zs.items():
        if len(z_sheets) != 2: continue
        for x_sheets, x_candidates in xs.items():
            if len(x_sheets) != 2: continue
            shared = z_sheets & x_sheets
            if len(shared) != 1: continue
            A = next(iter(shared))
            C = next(iter(z_sheets - {A}))
            T = next(iter(x_sheets - {A}))
            for z_ts, z_op, zw in z_candidates:
                for x_ts, x_op, xw in x_candidates:
                    # Triangle overlap must be zero
                    tri_overlap = int((z_ts * x_ts).sum())
                    if tri_overlap != 0: continue
                    # Data overlap must be 1 (CSS-pair anchor)
                    data_overlap = int((z_op * x_op).sum() % 2)
                    if data_overlap != 1: continue
                    return z_ts, z_op, x_ts, x_op, C, A, T
    raise RuntimeError(
        f"No 3-sheet decomposition with 0 triangle overlap and 1 data-qubit overlap "
        f"found at L={L} from default candidate set. Increase n_per_pair in "
        f"_find_primitives_fast or search higher-weight primitives."
    )


def identify_sheet_data(L, edge_to_sheet, edges):
    """Identify which data-qubit indices belong to each sheet."""
    n = len(edges)
    sheet_data = {'xy': [], 'xz': [], 'yz': []}
    for ei, s in enumerate(edge_to_sheet):
        sheet_data[s].append(ei)
    return {k: np.array(v, dtype=int) for k, v in sheet_data.items()}


def decompose_primitive_by_sheet(op_string, sheet_data):
    """Split a Z-primitive (or X-primitive) data-string into per-sheet pieces."""
    pieces = {}
    for sheet, idxs in sheet_data.items():
        piece = np.zeros(len(op_string), dtype=np.int8)
        for i in idxs:
            if op_string[i] == 1:
                piece[i] = 1
        pieces[sheet] = piece
    return pieces


def build_cnot_circuit(L, d_each, p, c_input=0, t_input=0):
    """Build full CNOT truth-table circuit at L, d_each rounds per phase, error rate p.
    
    Returns (circuit, info_dict).
    """
    vertices, vidx, _, edge_list, edge_to_idx, edge_to_sheet = build_fcc_lattice(L)
    n_data = len(edge_list)
    
    HZ, Z_meta = vertex_Z_stabilizers(L)
    HX, X_meta = oct_void_X_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    # Find primitives spanning 3 distinct sheets (C, A, T)
    z_ts, z_op, x_ts, x_op, C_sheet, A_sheet, T_sheet = pick_3sheet_decomposition(L)
    z_tri_idxs = list(np.where(z_ts == 1)[0])
    x_tri_idxs = list(np.where(x_ts == 1)[0])
    n_z_tri = len(z_tri_idxs)
    n_x_tri = len(x_tri_idxs)
    
    z_tri_data = [list(np.where(B[ti] == 1)[0]) for ti in z_tri_idxs]
    x_tri_data = [list(np.where(B[ti] == 1)[0]) for ti in x_tri_idxs]
    
    sheet_data = identify_sheet_data(L, edge_to_sheet, edge_list)
    z_op_pieces = decompose_primitive_by_sheet(z_op, sheet_data)
    x_op_pieces = decompose_primitive_by_sheet(x_op, sheet_data)
    
    print(f"  C sheet = {C_sheet}, A sheet = {A_sheet}, T sheet = {T_sheet}")
    print(f"  Z-prim weight {int(z_op.sum())}, {n_z_tri} triangles in sheets {sorted([s for s,p in z_op_pieces.items() if p.sum()>0])}")
    print(f"  X-prim weight {int(x_op.sum())}, {n_x_tri} triangles in sheets {sorted([s for s,p in x_op_pieces.items() if p.sum()>0])}")
    
    # Check triangle / data overlap
    tri_overlap = set(z_tri_idxs) & set(x_tri_idxs)
    z_data_set = set(np.where(z_op == 1)[0])
    x_data_set = set(np.where(x_op == 1)[0])
    data_overlap = z_data_set & x_data_set
    print(f"  Triangle overlap between Z- and X-prim: {len(tri_overlap)}")
    print(f"  Data-qubit overlap between Z- and X-prim: {len(data_overlap)}")
    
    # Define logical strings
    Z_C_string = z_op_pieces[C_sheet]  # initial-state flip for c=1
    Z_T_string = x_op_pieces[T_sheet]  # used for end-of-circuit Z_T readout AND init flip
    Z_A_string = z_op_pieces[A_sheet]  # part of Z_C tensor Z_A; A's Z-logical
    X_A_string = x_op_pieces[A_sheet]  # part of X_A tensor X_T; A's X-logical
    
    # For initial-state preparation:
    # - For c=1: apply X gates on Z_C string (this flips C's logical Z eigenvalue)
    # - For t=1: we want to flip T's Z-logical. But Z_T_string is X-side of XX-merge.
    #   That isn't a Z-string; it's a string used as X_T. To flip Z_T (logical Z of T),
    #   we need a Z_T string. Need to find a separate Z-logical in T_sheet.
    #
    # Wait: the ZZ-primitive measures Z_C tensor Z_A; both Z_C and Z_A are Z-logicals.
    # The XX-primitive measures X_A tensor X_T; both are X-logicals.
    # So Z_T (the Z-logical of T that we want to read out) is a DIFFERENT string from X_T.
    # Specifically Z_T is a Z-string in T's sheet such that {Z_T, X_T} = 0 (anticommute).
    #
    # For CSS code, X_T and Z_T are strings that intersect at exactly 1 data qubit.
    # We need to find a Z-string in T's sheet that anticommutes with X_T.
    
    # Find Z_T: CSS partner of X_T in T_sheet (uses symplectic-dual approach)
    T_idxs = sheet_data[T_sheet]
    HX_T = HX[:, T_idxs]
    HZ_T = HZ[:, T_idxs]
    
    X_T_local_T_only = x_op_pieces[T_sheet][T_idxs]
    Z_T_local = find_paired_Z_logical(HZ_T, HX_T, X_T_local_T_only)
    if Z_T_local is None:
        raise RuntimeError(f"Could not find CSS-paired Z_T in {T_sheet}")
    Z_T_string = np.zeros(n_data, dtype=np.int8)
    for i, idx in enumerate(T_idxs):
        if Z_T_local[i] == 1:
            Z_T_string[idx] = 1
    
    # Find X_C: CSS partner of Z_C in C_sheet (using same dual approach but Z-side)
    C_idxs = sheet_data[C_sheet]
    HX_C = HX[:, C_idxs]
    HZ_C = HZ[:, C_idxs]
    Z_C_local = z_op_pieces[C_sheet][C_idxs]
    # Use find_paired_Z_logical with HX, HZ swapped to find X partner of Z
    X_C_local = find_paired_Z_logical(HX_C, HZ_C, Z_C_local)
    if X_C_local is None:
        raise RuntimeError(f"Could not find CSS-paired X_C in {C_sheet}")
    X_C_string = np.zeros(n_data, dtype=np.int8)
    for i, idx in enumerate(C_idxs):
        if X_C_local[i] == 1:
            X_C_string[idx] = 1
    
    # Find X_T: CSS partner of Z_T in T_sheet
    X_T_paired_local = find_paired_Z_logical(HX_T, HZ_T, Z_T_local)
    if X_T_paired_local is None:
        raise RuntimeError(f"Could not find CSS-paired X_T in {T_sheet}")
    X_T_string = np.zeros(n_data, dtype=np.int8)
    for i, idx in enumerate(T_idxs):
        if X_T_paired_local[i] == 1:
            X_T_string[idx] = 1
    
    Z_T_data = list(np.where(Z_T_string == 1)[0])
    Z_C_data = list(np.where(Z_C_string == 1)[0])
    X_C_data = list(np.where(X_C_string == 1)[0])
    X_T_data = list(np.where(X_T_string == 1)[0])
    
    # Verify CSS pairing
    assert (X_C_string * z_op_pieces[C_sheet]).sum() % 2 == 1, "X_C must anticommute with Z_C"
    assert (X_T_string * Z_T_string).sum() % 2 == 1, "X_T must anticommute with Z_T"
    
    print(f"  |Z_C|={len(Z_C_data)}, |Z_T|={len(Z_T_data)}, |X_C|={len(X_C_data)}, |X_T|={len(X_T_data)}")
    
    # Initial flips: apply X gates on X_C string for c=1, on X_T string for t=1
    c_init_flips = X_C_data if c_input == 1 else []
    t_init_flips = X_T_data if t_input == 1 else []
    
    # A's data qubits: initialize in |+> via H gates
    A_data_qubits = list(sheet_data[A_sheet])
    
    print(f"  |Z_C string| = {len(Z_C_data)}, |Z_T string| = {len(Z_T_data)}")
    print(f"  |A sheet data| = {len(A_data_qubits)}")
    
    # Compute broken stabilizers
    broken_X = set()
    for ti in z_tri_idxs:
        for x_idx in np.where((HX @ B[ti]) % 2 == 1)[0]:
            broken_X.add(int(x_idx))
    broken_Z = set()
    for ti in x_tri_idxs:
        for z_idx in np.where((HZ @ B[ti]) % 2 == 1)[0]:
            broken_Z.add(int(z_idx))
    
    n_Z = HZ.shape[0]
    n_X = HX.shape[0]
    Z_stab_data = [list(np.where(HZ[i] == 1)[0]) for i in range(n_Z)]
    X_stab_data = [list(np.where(HX[i] == 1)[0]) for i in range(n_X)]
    
    max_stab_weight = 4
    for s in Z_stab_data + X_stab_data:
        max_stab_weight = max(max_stab_weight, len(s))
    
    # Qubit layout
    Z_off = n_data
    X_off = Z_off + n_Z
    Tri_Z_off = X_off + n_X
    Tri_X_off = Tri_Z_off + n_z_tri
    total_qubits = Tri_X_off + n_x_tri
    
    c = stim.Circuit()
    all_data = list(range(n_data))
    Z_ancs = list(range(Z_off, Z_off + n_Z))
    X_ancs = list(range(X_off, X_off + n_X))
    Tri_Z_ancs = list(range(Tri_Z_off, Tri_Z_off + n_z_tri))
    Tri_X_ancs = list(range(Tri_X_off, Tri_X_off + n_x_tri))
    
    # === Initialization ===
    c.append('R', all_data + Z_ancs + X_ancs + Tri_Z_ancs + Tri_X_ancs)
    # A's data in |+> (after R, all data in |0>, apply H on A's data)
    if A_data_qubits:
        c.append('H', A_data_qubits)
    # Flip C and T if c_input/t_input
    if c_init_flips:
        c.append('X', c_init_flips)
    if t_init_flips:
        c.append('X', t_init_flips)
    
    measurement_records = []
    total_measurements = 0
    x_merge_triangle_records = []
    # Per-round Z-merge triangle records: list of (round_idx, [rec_idx, ...]).
    z_merge_round_records = []
    
    def syndrome_round(round_idx, with_z_triangles=False, with_x_triangles=False):
        """One full syndrome round."""
        nonlocal total_measurements
        if round_idx > 0:
            c.append('R', Z_ancs + X_ancs)
            if p > 0: c.append('DEPOLARIZE1', Z_ancs + X_ancs, p)
            if with_z_triangles:
                c.append('R', Tri_Z_ancs)
                if p > 0: c.append('DEPOLARIZE1', Tri_Z_ancs, p)
            if with_x_triangles:
                c.append('R', Tri_X_ancs)
                if p > 0: c.append('DEPOLARIZE1', Tri_X_ancs, p)
        
        # Z-syndrome: data→anc CNOTs (incl Z-merge triangles)
        for slot in range(max_stab_weight):
            cnots = []
            for stab_idx, dq in enumerate(Z_stab_data):
                if slot < len(dq):
                    cnots.extend([dq[slot], Z_off + stab_idx])
            if with_z_triangles:
                for tri_idx, dq in enumerate(z_tri_data):
                    if slot < len(dq):
                        cnots.extend([dq[slot], Tri_Z_off + tri_idx])
            if cnots:
                c.append('CX', cnots)
                if p > 0: c.append('DEPOLARIZE2', cnots, p)
                c.append('TICK')
        
        z_ancs_to_measure = list(Z_ancs)
        if with_z_triangles:
            z_ancs_to_measure += Tri_Z_ancs
        if p > 0: c.append('X_ERROR', z_ancs_to_measure, p)
        c.append('M', z_ancs_to_measure)
        
        record = {}
        for i in range(n_Z):
            record[('Z', i)] = total_measurements + i
        if with_z_triangles:
            this_round_z_tri_recs = []
            for i in range(n_z_tri):
                rec_idx = total_measurements + n_Z + i
                record[('TZ', i)] = rec_idx
                this_round_z_tri_recs.append(rec_idx)
            z_merge_round_records.append((round_idx, this_round_z_tri_recs))
        total_measurements += len(z_ancs_to_measure)
        
        # X-syndrome: H on X-ancs, data CNOTs, H back
        c.append('H', X_ancs)
        if p > 0: c.append('DEPOLARIZE1', X_ancs, p)
        if with_x_triangles:
            c.append('H', Tri_X_ancs)
            if p > 0: c.append('DEPOLARIZE1', Tri_X_ancs, p)
        c.append('TICK')
        
        for slot in range(max_stab_weight):
            cnots = []
            for stab_idx, dq in enumerate(X_stab_data):
                if slot < len(dq):
                    cnots.extend([X_off + stab_idx, dq[slot]])
            if cnots:
                c.append('CX', cnots)
                if p > 0: c.append('DEPOLARIZE2', cnots, p)
                c.append('TICK')
        
        if with_x_triangles:
            for slot in range(max_stab_weight):
                cnots = []
                for tri_idx, dq in enumerate(x_tri_data):
                    if slot < len(dq):
                        cnots.extend([Tri_X_off + tri_idx, dq[slot]])
                if cnots:
                    c.append('CX', cnots)
                    if p > 0: c.append('DEPOLARIZE2', cnots, p)
                    c.append('TICK')
        
        c.append('H', X_ancs)
        if p > 0: c.append('DEPOLARIZE1', X_ancs, p)
        if with_x_triangles:
            c.append('H', Tri_X_ancs)
            if p > 0: c.append('DEPOLARIZE1', Tri_X_ancs, p)
        c.append('TICK')
        
        x_ancs_to_measure = list(X_ancs)
        if with_x_triangles:
            x_ancs_to_measure += Tri_X_ancs
        if p > 0: c.append('X_ERROR', x_ancs_to_measure, p)
        c.append('M', x_ancs_to_measure)
        
        for i in range(n_X):
            record[('X', i)] = total_measurements + i
        if with_x_triangles:
            for i in range(n_x_tri):
                rec_idx = total_measurements + n_X + i
                record[('TX', i)] = rec_idx
                x_merge_triangle_records.append(rec_idx)
        total_measurements += len(x_ancs_to_measure)
        
        measurement_records.append(record)
    
    def add_detectors(round_idx, prev_wz, curr_wz, prev_wx, curr_wx):
        """Detector emission with broken-stab suppression."""
        curr = measurement_records[round_idx]
        prev = measurement_records[round_idx - 1] if round_idx > 0 else None
        
        # Z-stab detectors:
        # Round 0: ALWAYS skip (random — data init isn't a Z-stab eigenstate because A's sheet is in |+>)
        # Round >0: normal pairing, but skip broken Z-stabs during X-merge phases
        if round_idx > 0:
            for i in range(n_Z):
                # Skip Z-stabs that include A's data (since A's data is in X-basis state, Z-stabs random)
                # Actually — once we're past round 1, the X-stab measurements have projected A's
                # data into a definite X-stab eigenstate, but Z-stabs containing A's data are still random.
                # Z-stabs that are entirely in C's or T's sheet are deterministic.
                # Z-stabs that touch A's sheet need to be checked.
                stab_data = Z_stab_data[i]
                touches_A = any(d in set(A_data_qubits) for d in stab_data)
                # Actually for the standard CSS init in mixed |0>/|+> state:
                # Z-stabs touching A's |+> data have random eigenvalue initially.
                # After one round of measurement, the value gets fixed (by projection).
                # So pairing from round 2 onwards works.
                # For simplicity, skip Z-stabs touching A's data in round 1.
                if round_idx == 1 and touches_A:
                    continue
                is_broken = i in broken_Z
                skip = is_broken and (prev_wx or curr_wx)
                if skip: continue
                curr_m = curr[('Z', i)]
                prev_m = prev[('Z', i)]
                c.append('DETECTOR',
                    [stim.target_rec(curr_m - total_measurements),
                     stim.target_rec(prev_m - total_measurements)])
        
        # X-stab detectors:
        # Round 0: X-stabs are random (data in mix of |0>/|+>); skip
        # Round 1+: pair, skip broken during Z-merge
        if round_idx > 0:
            for i in range(n_X):
                is_broken = i in broken_X
                skip = is_broken and (prev_wz or curr_wz)
                if skip: continue
                curr_m = curr[('X', i)]
                prev_m = prev[('X', i)]
                c.append('DETECTOR',
                    [stim.target_rec(curr_m - total_measurements),
                     stim.target_rec(prev_m - total_measurements)])
    
    # === Phase 1: pre-merge ===
    for r in range(d_each):
        syndrome_round(r, with_z_triangles=False, with_x_triangles=False)
        add_detectors(r, False, False, False, False)
    
    # === Phase 2: ZZ-merge ===
    for r in range(d_each):
        ri = d_each + r
        syndrome_round(ri, with_z_triangles=True, with_x_triangles=False)
        prev_wz = (r > 0)
        add_detectors(ri, prev_wz, True, False, False)
    
    # === Phase 3: split-1 ===
    for r in range(d_each):
        ri = 2 * d_each + r
        syndrome_round(ri, with_z_triangles=False, with_x_triangles=False)
        prev_wz = (r == 0)
        add_detectors(ri, prev_wz, False, False, False)
    
    # === Phase 4: XX-merge ===
    for r in range(d_each):
        ri = 3 * d_each + r
        syndrome_round(ri, with_z_triangles=False, with_x_triangles=True)
        prev_wx = (r > 0)
        add_detectors(ri, False, False, prev_wx, True)
    
    # === Phase 5: split-2 ===
    for r in range(d_each):
        ri = 4 * d_each + r
        syndrome_round(ri, with_z_triangles=False, with_x_triangles=False)
        prev_wx = (r == 0)
        add_detectors(ri, False, False, prev_wx, False)
    
    # === Destructive Z-basis measurement of all data ===
    if p > 0: c.append('X_ERROR', all_data, p)
    c.append('M', all_data)
    data_m_start = total_measurements
    total_measurements += n_data
    
    # Final Z-stab detectors: parity of data inside stab vs ancilla last value
    last = measurement_records[-1]
    for i in range(n_Z):
        stab_data = Z_stab_data[i]
        # Z-stabs touching A's data have random value — skip
        touches_A = any(d in set(A_data_qubits) for d in stab_data)
        if touches_A:
            continue
        data_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in stab_data]
        anc_rec = stim.target_rec(last[('Z', i)] - total_measurements)
        c.append('DETECTOR', data_recs + [anc_rec])
    
    # === Observables ===
    # Final stabs (after Z-basis measurement of A's data) are derivable from the joint stab
    # Z_C * Z_A * Z_T = (-1)^(m_ZZ + t).  So Z_T_eigenvalue = c + t + m_ZZ + Z_A_parity (mod 2).
    # And Z_C_eigenvalue = c (unchanged).
    
    # Z_A_string is needed for Pauli-frame tracking. Take Z_A = z_op_pieces[A_sheet]
    Z_A_string = z_op_pieces[A_sheet]
    Z_A_data = list(np.where(Z_A_string == 1)[0])
    
    # Obs 0: Z_C parity at end. Should equal c_input deterministically.
    obs0_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in Z_C_data]
    c.append('OBSERVABLE_INCLUDE', obs0_recs, 0)
    
    # ===  Pauli frame correction for Obs1  ===
    # The naive expression Z_T_par XOR Z_A_par XOR m_ZZ doesn't quite work because:
    # the X-merge consists of n_x_tri INDIVIDUAL X-triangle measurements, and the cumulative
    # anticommutation of Z_C·Z_A·Z_T with these triangles is even (0 mod 2). When 2k > 0
    # X-tris anticommute with Z_C·Z_A·Z_T, their joint random outcome leaks into Obs1.
    # To cancel, include a set of BROKEN Z-stab Phase-5 measurements whose XORed
    # anticommutation pattern with X-triangles matches that target subset, AND whose
    # combined support doesn't touch A-sheet (deterministic pre-XX-merge value).
    
    # Compute the target X-triangle anticommutation pattern for Z_C·Z_A·Z_T
    combined_Z = np.zeros(n_data, dtype=np.int8)
    for dq in Z_C_data: combined_Z[dq] = 1
    Z_A_full = z_op_pieces[A_sheet]
    for i in range(n_data):
        if Z_A_full[i] == 1: combined_Z[i] ^= 1
    for dq in Z_T_data: combined_Z[dq] ^= 1
    target_pattern = np.array(
        [int((B[ti] * combined_Z).sum() % 2) for ti in x_tri_idxs], dtype=np.int8)
    
    # Find a linear combination of NON-A-touching broken Z-stabs whose patterns XOR to target.
    # Setup linear system: M @ x = target where M[i,j] = j-th non-A broken Z-stab's anticomm with i-th X-tri.
    A_data_set = set(A_data_qubits)
    candidate_z = []
    for z in broken_Z:
        supp = list(np.where(HZ[z] == 1)[0])
        if any(d in A_data_set for d in supp):
            continue  # skip Z-stabs touching A-sheet (random pre-value)
        pattern_z = np.array(
            [int((HZ[z] * B[ti]).sum() % 2) for ti in x_tri_idxs], dtype=np.int8)
        candidate_z.append((z, pattern_z))
    
    # Solve over GF(2): find subset S of candidate_z whose patterns XOR to target_pattern
    correction_z_indices = []
    if target_pattern.sum() > 0 and candidate_z:
        # Build matrix: each column = one candidate's pattern
        M = np.array([cp for _, cp in candidate_z], dtype=np.int8).T  # (n_x_tri, n_candidates)
        # Gauss-Jordan on augmented [M | target]
        aug = np.hstack([M, target_pattern.reshape(-1, 1)])
        rows, cols = aug.shape
        r = 0
        pivot_cols = []
        for col in range(cols - 1):
            piv = None
            for k in range(r, rows):
                if aug[k, col] == 1:
                    piv = k
                    break
            if piv is None: continue
            aug[[r, piv]] = aug[[piv, r]]
            for k in range(rows):
                if k != r and aug[k, col] == 1:
                    aug[k] = (aug[k] + aug[r]) % 2
            pivot_cols.append(col)
            r += 1
        # Check consistency
        consistent = True
        for k in range(r, rows):
            if aug[k, -1] == 1:
                consistent = False
                break
        if consistent:
            sol = np.zeros(len(candidate_z), dtype=np.int8)
            for pi, pc in enumerate(pivot_cols):
                sol[pc] = aug[pi, -1]
            correction_z_indices = [candidate_z[i][0] for i in range(len(sol)) if sol[i] == 1]
    
    if correction_z_indices:
        print(f"  Pauli-frame correction: Z-stabs {correction_z_indices} "
              f"(target anti pattern {tuple(target_pattern)})")
    elif target_pattern.sum() == 0:
        print(f"  No Pauli-frame correction needed (target pattern is zero)")
    else:
        print(f"  WARNING: target pattern {tuple(target_pattern)} not expressible "
              f"as XOR of non-A broken Z-stabs — Obs1 may be non-deterministic")
    
    # Obs 1: Z_T parity XOR Z_A parity XOR m_ZZ (last round) XOR (Pauli-frame correction stabs)
    obs1_recs = [stim.target_rec(data_m_start + dq - total_measurements) for dq in Z_T_data]
    obs1_recs += [stim.target_rec(data_m_start + dq - total_measurements) for dq in Z_A_data]
    if z_merge_round_records:
        _, last_round_z_tris = z_merge_round_records[-1]
        obs1_recs += [stim.target_rec(r - total_measurements) for r in last_round_z_tris]
    for z_idx in correction_z_indices:
        # First round of Phase 5 = round index 4*d_each
        phase5_r0_record = measurement_records[4 * d_each][('Z', z_idx)]
        obs1_recs.append(stim.target_rec(phase5_r0_record - total_measurements))
    c.append('OBSERVABLE_INCLUDE', obs1_recs, 1)
    
    info = {
        'L': L, 'd_each': d_each, 'p': p, 'c': c_input, 't': t_input,
        'total_qubits': total_qubits, 'n_data': n_data,
        'n_z_tri': n_z_tri, 'n_x_tri': n_x_tri,
        'broken_X': len(broken_X), 'broken_Z': len(broken_Z),
        'C_sheet': C_sheet, 'A_sheet': A_sheet, 'T_sheet': T_sheet,
        'Z_C_weight': len(Z_C_data), 'Z_T_weight': len(Z_T_data),
        'x_merge_records': len(x_merge_triangle_records),
        'expected_obs0': c_input,
        'expected_obs1': (c_input ^ t_input),
    }
    return c, info


if __name__ == '__main__':
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    d_each = int(sys.argv[2]) if len(sys.argv) > 2 else L
    p = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
    n_shots = int(sys.argv[4]) if len(sys.argv) > 4 else 200
    
    print(f"=== Horsman CNOT truth table at L={L}, d_each={d_each}, p={p}, n_shots={n_shots} ===\n")
    print("Note: Stim's compile_detector_sampler returns the FLIP indicator (XOR with the")
    print("deterministic expected value). At p=0, flip=0 always means observable IS")
    print("deterministic AND matches Stim's tableau-computed expected value.\n")
    
    results = {}
    for c_input in [0, 1]:
        for t_input in [0, 1]:
            label = f"|{c_input}>|{t_input}>"
            print(f"--- Input {label} ---")
            try:
                circ, info = build_cnot_circuit(L, d_each, p, c_input, t_input)
                expected = (info['expected_obs0'], info['expected_obs1'])
                print(f"  Circuit: {info['total_qubits']} qubits, "
                      f"{info['n_z_tri']} Z-tri, {info['n_x_tri']} X-tri")
                print(f"  Expected (Obs0, Obs1) = ({expected[0]}, {expected[1]})")
                
                # Verify DEM builds (means observables are deterministic at p=0)
                if p == 0.0:
                    try:
                        dem = circ.detector_error_model()
                        det_ok = (dem.num_observables == 2)
                        print(f"  DEM at p=0: builds, observables deterministic ✓")
                    except Exception as e:
                        msg = str(e).split('\n')[0]
                        print(f"  DEM error: {msg}")
                        det_ok = False
                
                # Sample raw and compute Obs0, Obs1 manually to confirm values
                sampler = circ.compile_sampler(seed=42 + c_input*2 + t_input)
                raw = sampler.sample(shots=n_shots)
                total = raw.shape[1]
                
                # Re-derive the observable structure by parsing the circuit
                import re
                circ_str = str(circ)
                obs0_recs = []
                obs1_recs = []
                for m in re.finditer(r'OBSERVABLE_INCLUDE\((\d+)\)\s+([^\n]+)', circ_str):
                    obs_id = int(m.group(1))
                    recs = [int(x.replace('rec[', '').replace(']', '')) for x in m.group(2).strip().split()]
                    if obs_id == 0: obs0_recs = recs
                    elif obs_id == 1: obs1_recs = recs
                
                def xor_recs(recs):
                    r = np.zeros(n_shots, dtype=np.uint8)
                    for rec in recs: r ^= raw[:, total + rec].astype(np.uint8)
                    return r
                obs0_raw = xor_recs(obs0_recs)
                obs1_raw = xor_recs(obs1_recs)
                
                obs0_match = (obs0_raw == expected[0]).mean()
                obs1_match = (obs1_raw == expected[1]).mean()
                print(f"  Obs0 raw value: {np.bincount(obs0_raw, minlength=2)} (truth-table expects {expected[0]})")
                print(f"  Obs1 raw value: {np.bincount(obs1_raw, minlength=2)} (truth-table expects {expected[1]})")
                print(f"  Truth-table match: Obs0={obs0_match*100:.1f}%, Obs1={obs1_match*100:.1f}%")
                
                results[(c_input, t_input)] = (obs0_match, obs1_match)
                
            except Exception as e:
                print(f"  ERROR: {e}")
                import traceback; traceback.print_exc()
            print()
    
    print("=== Truth-Table Summary ===")
    print(f"{'Input':<10} {'Expected':<24} {'Obs0 match':<15} {'Obs1 match':<15}")
    all_pass = True
    for (c_in, t_in), (m0, m1) in results.items():
        label = f"|{c_in}>|{t_in}>"
        exp = (c_in, c_in ^ t_in)
        passes = (m0 > 0.99 and m1 > 0.99)
        status = '✓' if passes else '✗'
        all_pass = all_pass and passes
        print(f"{label:<10}  ({exp[0]}, {exp[1]})                  {m0*100:.1f}%          {m1*100:.1f}% {status}")
    
    if p == 0.0 and all_pass:
        print(f"\n*** Horsman CNOT truth table VERIFIED at L={L}, d_each={d_each} ***")
