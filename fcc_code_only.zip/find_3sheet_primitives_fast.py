"""Fast 3-sheet primitive finder.

The original finder calls gf2_rank inside a loop of ~1343 iterations at L=8.
Each call takes ~0.24s → 320s total per primitive search, x2 for Z and X = 640s.

This module does a single Gauss-Jordan pass on [HZ; ops_sorted_by_weight]
and reports which ops introduce new pivots — those are the non-trivial primitives.
"""
import os, json, sys
import numpy as np

from sheet_code_fcc_lattice import (
    build_fcc_lattice, fcc_triangles,
    vertex_Z_stabilizers, oct_void_X_stabilizers
)
from sheet_code_gf2 import gf2_rank, gf2_kernel


def _find_primitives_fast(L, side='Z', n_per_pair=8):
    """Returns dict: frozenset({s1, s2}) -> list of (triangle_set, op_string, weight).
    
    Returns up to n_per_pair primitives per sheet-pair, sorted by weight ascending.
    
    side='Z' finds Z-primitives (triangle products commuting with HX, not in HZ rowspan)
    side='X' finds X-primitives (triangle products commuting with HZ, not in HX rowspan)
    """
    _, _, _, edge_list, _, edge_to_sheet = build_fcc_lattice(L)
    HX, _ = oct_void_X_stabilizers(L)
    HZ, _ = vertex_Z_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    if side == 'Z':
        M = (HX @ B.T) % 2
        H_self = HZ.astype(np.uint8)
    else:
        M = (HZ @ B.T) % 2
        H_self = HX.astype(np.uint8)
    
    valid = gf2_kernel(M)
    ops = (valid @ B) % 2
    weights = ops.sum(axis=1)
    
    nonzero = weights > 0
    valid = valid[nonzero]
    ops = ops[nonzero]
    weights = weights[nonzero]
    sort_idx = np.argsort(weights)
    valid = valid[sort_idx]
    ops = ops[sort_idx].astype(np.uint8)
    weights = weights[sort_idx]
    
    n_self = H_self.shape[0]
    n_ops = ops.shape[0]
    n_cols = H_self.shape[1]
    
    aug = np.vstack([H_self, ops])
    row_ids = list(range(n_self + n_ops))
    new_pivot_op_indices = []
    pivot_row = 0
    for col in range(n_cols):
        piv_idx = None
        for k in range(pivot_row, aug.shape[0]):
            if aug[k, col] == 1:
                if row_ids[k] < n_self:
                    piv_idx = k
                    break
        if piv_idx is None:
            for k in range(pivot_row, aug.shape[0]):
                if aug[k, col] == 1:
                    piv_idx = k
                    break
        if piv_idx is None:
            continue
        if piv_idx != pivot_row:
            aug[[pivot_row, piv_idx]] = aug[[piv_idx, pivot_row]]
            row_ids[pivot_row], row_ids[piv_idx] = row_ids[piv_idx], row_ids[pivot_row]
        if row_ids[pivot_row] >= n_self:
            op_idx = row_ids[pivot_row] - n_self
            new_pivot_op_indices.append(op_idx)
        col_vals = aug[:, col].copy()
        col_vals[pivot_row] = 0
        mask = col_vals == 1
        aug[mask] = (aug[mask] + aug[pivot_row]) % 2
        pivot_row += 1
    
    # Bin non-trivial primitives by sheet coverage, keep n_per_pair lowest-weight per pair
    found = {}
    for op_idx in new_pivot_op_indices:
        op = ops[op_idx]
        sheets = frozenset(edge_to_sheet[i] for i in range(n_cols) if op[i] == 1)
        if len(sheets) < 2:
            continue
        if sheets not in found:
            found[sheets] = []
        if len(found[sheets]) < n_per_pair:
            found[sheets].append((valid[op_idx], op, int(weights[op_idx])))
    return found


def find_z_primitives_by_sheet_pair_fast(L):
    cache_path = f"/home/claude/_z_prims_L{L}.json"
    if os.path.exists(cache_path):
        with open(cache_path) as f:
            d = json.load(f)
        return {
            frozenset(k.split(',')): [
                (np.array(item[0], dtype=np.uint8),
                 np.array(item[1], dtype=np.uint8),
                 int(item[2]))
                for item in v
            ]
            for k, v in d.items()
        }
    found = _find_primitives_fast(L, side='Z')
    with open(cache_path, 'w') as f:
        json.dump({
            ','.join(sorted(k)): [[ts.tolist(), op.tolist(), w]
                                  for ts, op, w in v]
            for k, v in found.items()
        }, f)
    return found


def find_x_primitives_by_sheet_pair_fast(L):
    cache_path = f"/home/claude/_x_prims_L{L}.json"
    if os.path.exists(cache_path):
        with open(cache_path) as f:
            d = json.load(f)
        return {
            frozenset(k.split(',')): [
                (np.array(item[0], dtype=np.uint8),
                 np.array(item[1], dtype=np.uint8),
                 int(item[2]))
                for item in v
            ]
            for k, v in d.items()
        }
    found = _find_primitives_fast(L, side='X')
    with open(cache_path, 'w') as f:
        json.dump({
            ','.join(sorted(k)): [[ts.tolist(), op.tolist(), w]
                                  for ts, op, w in v]
            for k, v in found.items()
        }, f)
    return found


if __name__ == '__main__':
    import time
    L = int(sys.argv[1])
    t0 = time.time()
    zs = find_z_primitives_by_sheet_pair_fast(L)
    print(f"L={L} Z-primitives in {time.time()-t0:.1f}s:")
    for sh, (_, op, w) in zs.items():
        print(f"  {sorted(sh)}: weight {w}")
    t1 = time.time()
    xs = find_x_primitives_by_sheet_pair_fast(L)
    print(f"L={L} X-primitives in {time.time()-t1:.1f}s:")
    for sh, (_, op, w) in xs.items():
        print(f"  {sorted(sh)}: weight {w}")
