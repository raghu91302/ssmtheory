"""Formal finite-size scaling fit for the surgery threshold.

Standard FSS ansatz (Wang et al., Phys. Rev. A 2003):
    p_L(p) = A + B·x + C·x², where x = (p - p_th) · L^(1/ν)

All L curves should collapse onto a single universal curve when plotted vs x.

We fit p_th, ν, A, B, C simultaneously via least-squares, then report
p_th with statistical uncertainty from the fit covariance matrix.
"""
import json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def load_results(json_path):
    """Load and merge by (L, p)."""
    with open(json_path) as f:
        results = json.load(f)
    merged = {}
    for r in results:
        key = (r['L'], r['p'])
        merged.setdefault(key, {'n_err': 0, 'n_shots': 0})
        merged[key]['n_err'] += r['n_err']
        merged[key]['n_shots'] += r['n_shots']
    return merged


def fss_model(X, p_th, nu, A, B, C):
    """Universal scaling function: p_L(p) = A + B·x + C·x², x = (p-p_th)·L^(1/ν)."""
    p_vals, L_vals = X
    x = (p_vals - p_th) * L_vals**(1.0/nu)
    return A + B*x + C*x*x


def fit_threshold(merged, p_range=None, label="toric"):
    """Fit FSS ansatz across L = 4, 6, 8 with near-threshold data."""
    # Default p_range: near-threshold (where the scaling ansatz is valid)
    if p_range is None:
        if 'toric' in label:
            p_range = (0.007, 0.015)
        else:
            p_range = (0.004, 0.012)
    
    # Build (p, L, rate, sigma) arrays for points in range with enough errors
    p_list, L_list, rate_list, sigma_list = [], [], [], []
    for (L, p), v in merged.items():
        if not (p_range[0] <= p <= p_range[1]):
            continue
        if v['n_err'] < 5:  # exclude very low-statistics points
            continue
        rate = v['n_err'] / v['n_shots']
        sigma = max(np.sqrt(rate * (1 - rate) / v['n_shots']), 1e-4)
        p_list.append(p)
        L_list.append(L)
        rate_list.append(rate)
        sigma_list.append(sigma)
    
    p_arr = np.array(p_list)
    L_arr = np.array(L_list)
    rate_arr = np.array(rate_list)
    sigma_arr = np.array(sigma_list)
    
    print(f"\n=== FSS fit for {label} ===")
    print(f"  p_range: {p_range}, {len(p_arr)} data points")
    
    if len(p_arr) < 6:
        print(f"  Not enough points for fit")
        return None
    
    # Initial guess
    if 'toric' in label:
        p0 = [0.010, 1.5, 0.30, 5.0, 0.0]
    else:
        p0 = [0.008, 1.5, 0.20, 5.0, 0.0]
    
    # Fit
    try:
        popt, pcov = curve_fit(
            fss_model, (p_arr, L_arr), rate_arr,
            sigma=sigma_arr, p0=p0,
            absolute_sigma=True,
            maxfev=20000,
        )
        p_th, nu, A, B, C = popt
        perr = np.sqrt(np.diag(pcov))
        p_th_err, nu_err, A_err, B_err, C_err = perr
        
        # Chi² statistic
        residuals = (rate_arr - fss_model((p_arr, L_arr), *popt)) / sigma_arr
        chi2 = np.sum(residuals**2)
        dof = len(p_arr) - 5
        chi2_per_dof = chi2 / dof
        
        print(f"  p_th = {p_th*100:.3f}% ± {p_th_err*100:.3f}%")
        print(f"  ν    = {nu:.3f} ± {nu_err:.3f}")
        print(f"  A    = {A:.4f} ± {A_err:.4f}")
        print(f"  B    = {B:.2f} ± {B_err:.2f}")
        print(f"  C    = {C:.1f} ± {C_err:.1f}")
        print(f"  χ²/DOF = {chi2:.2f}/{dof} = {chi2_per_dof:.2f}")
        
        return {
            'label': label,
            'p_th': p_th, 'p_th_err': p_th_err,
            'nu': nu, 'nu_err': nu_err,
            'A': A, 'B': B, 'C': C,
            'chi2': chi2, 'dof': dof,
            'data': (p_arr, L_arr, rate_arr, sigma_arr),
            'popt': popt,
        }
    except Exception as e:
        print(f"  Fit failed: {e}")
        return None


def plot_collapse(fit_result, save_path):
    """Plot data collapse: all L curves on the same universal x-axis."""
    p_arr, L_arr, rate_arr, sigma_arr = fit_result['data']
    p_th, nu = fit_result['p_th'], fit_result['nu']
    A, B, C = fit_result['A'], fit_result['B'], fit_result['C']
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    colors = {4: '#1f77b4', 6: '#d62728', 8: '#2ca02c'}
    markers = {4: 'o', 6: 's', 8: '^'}
    
    # Left: raw data
    for L in [4, 6, 8]:
        mask = L_arr == L
        if not mask.any():
            continue
        ax1.errorbar(p_arr[mask]*100, rate_arr[mask], yerr=sigma_arr[mask],
                     fmt=markers[L]+'-', color=colors[L], label=f'L = {L}',
                     markersize=8, capsize=4)
    ax1.set_xlabel('Physical error rate $p$ (%)', fontsize=12)
    ax1.set_ylabel('Logical error rate', fontsize=12)
    ax1.set_title(f"Raw data ({fit_result['label']})")
    ax1.axvline(p_th*100, color='k', linestyle='--', alpha=0.5,
                label=f'$p_{{\\rm th}}$ = {p_th*100:.3f}%')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Right: collapsed
    for L in [4, 6, 8]:
        mask = L_arr == L
        if not mask.any():
            continue
        x = (p_arr[mask] - p_th) * L**(1.0/nu)
        ax2.errorbar(x, rate_arr[mask], yerr=sigma_arr[mask],
                     fmt=markers[L], color=colors[L], label=f'L = {L}',
                     markersize=8, capsize=4)
    # Universal curve
    x_smooth = np.linspace(min((p_arr - p_th) * L_arr**(1.0/nu)),
                           max((p_arr - p_th) * L_arr**(1.0/nu)), 100)
    ax2.plot(x_smooth, A + B*x_smooth + C*x_smooth**2, 'k--', alpha=0.6,
             label='Universal fit')
    ax2.set_xlabel(f'$(p - p_{{\\rm th}}) \\cdot L^{{1/\\nu}}$  ($\\nu$ = {nu:.2f})', fontsize=12)
    ax2.set_ylabel('Logical error rate', fontsize=12)
    ax2.set_title(f"FSS collapse: $p_{{\\rm th}}$ = {p_th*100:.3f} ± {fit_result['p_th_err']*100:.3f}%")
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, bbox_inches='tight')
    print(f"  Saved {save_path}")


if __name__ == '__main__':
    # Toric fit
    merged_toric = load_results('./surgery_threshold_results.json')
    fit_toric = fit_threshold(merged_toric, label='toric')
    if fit_toric:
        plot_collapse(fit_toric, './fig_fss_toric.pdf')
    
    # Planar boundary-aware fit
    merged_planar = load_results('./planar_ba_threshold_results.json')
    fit_planar = fit_threshold(merged_planar, label='planar boundary-aware')
    if fit_planar:
        plot_collapse(fit_planar, './fig_fss_planar.pdf')
    
    # Summary
    print("\n=== SUMMARY ===")
    if fit_toric:
        print(f"Toric:   p_th = {fit_toric['p_th']*100:.3f}% ± {fit_toric['p_th_err']*100:.3f}%, ν = {fit_toric['nu']:.2f} ± {fit_toric['nu_err']:.2f}")
    if fit_planar:
        print(f"Planar:  p_th = {fit_planar['p_th']*100:.3f}% ± {fit_planar['p_th_err']*100:.3f}%, ν = {fit_planar['nu']:.2f} ± {fit_planar['nu_err']:.2f}")
