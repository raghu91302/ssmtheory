FCC Sheet Code: reference implementation and data
=================================================

Companion archive for "Inter-Sheet Joint Pauli Measurements on the FCC
Lattice: A Cross-Block Fault-Tolerant Primitive at K=4 Connectivity".

Requirements: Python 3.10+, numpy, scipy, matplotlib. The Stim-based
runners also need stim and pymatching.


Quick start
-----------

    python3 sheet_code_test_construction.py     # all analytical claims
    python3 sheet_code_generate_figures.py      # regenerates all six figures

The first prints a pass line for each analytical claim in the paper:
edge count, CSS validity, k = 6L across three sheets, triangle count
4L^3, triangle-reachable logicals, and distance preservation under merge
at L = 4 and L = 6. It needs no simulation and finishes in seconds.


Files
-----

Lattice and analytical tests (Sections 2 to 6)
  sheet_code_fcc_lattice.py        lattice, stabilizers, triangles
  sheet_code_gf2.py                GF(2) utilities
  sheet_code_surgery.py            logical analysis
  sheet_code_test_construction.py  unit tests for every analytical claim

Toric threshold (Section 7)
  sheet_code_custom_surgery.py     two-sheet surgery circuit
  sheet_code_custom_stim.py        circuit construction helpers
  sheet_code_cached_surgery.py     accelerated L = 8 runner
  sheet_code_surgery_threshold.py  sweep driver
  sheet_code_sweep_one.py          single-point runner
  sheet_code_run_threshold.py      threshold entry point
  sheet_code_fss_analysis.py       finite-size-scaling analysis

Planar variant (Section 9)
  sheet_code_planar_stabilizers.py  planar lattice, rough z-boundary
  sheet_code_planar_verify.py       verification at L = 4, 6, 8
  sheet_code_planar_ba_surgery.py   boundary-aware ribbon primitive
  planar_ba_threshold_results.json  planar shot data

XX-merge and three-sheet CNOT (Sections 10, 11)
  sheet_code_xx_surgery_toric.py    XX-merge primitive
  xx_surgery_results.json           XX shot data
  find_3sheet_primitives.py         CSS-compatible primitive enumerator
  find_3sheet_primitives_fast.py    batch Gauss-Jordan version
  css_dual.py                       symplectic-dual finder
  sheet_code_cnot_full.py           three-sheet Horsman CNOT
  cnot_truth_table_results.json     truth-table verification
  cnot_ler_sweep.py                 CNOT LER sweeps
  analyze_cnot_ler.py               CNOT LER analysis
  cnot_ler_dL_L4.json               CNOT LER, d_each = L
  cnot_ler_dL_L6.json
  cnot_ler_dL_L8.json
  cnot_ler_L4_d8.json               depth diagnostic at L = 4

Finite-size scaling
  sheet_code_formal_fss_fit.py      toric and planar data-collapse fits

Other runners
  sheet_code_run_distance.py       distance checks
  sheet_code_run_gates.py          gate-level checks
  sheet_code_find_primitive_fast.py  primitive search

Figures
  sheet_code_generate_figures.py   regenerates Figures 1 to 6 from the
                                   data files below

Data
  surgery_primitive_L8.json        cached L = 8 surgery primitive
  surgery_threshold_results.json   per-run raw shot data
  threshold_summary.csv            aggregate over all runs


Which data file to use
----------------------

threshold_summary.csv is the authoritative aggregate and is the source
of the toric tables in the paper. surgery_threshold_results.json and
xx_surgery_results.json are earlier per-run subsets: they have fewer
shots at some points and do not cover every p reported in the tables.
Where both exist they agree within statistical error, except one L = 4
XX point that differs by about 3 sigma. Use the CSV for toric data.


Reproducibility
---------------

All sweep runners accept --seed and --dump-dir. The --dump-dir option
writes representative .stim and .dem artifacts at any chosen (L, p).


REVISION v2.0 ADDITIONS
=======================

xx_pinned.py
    XX-merge threshold with the merged sheet pair pinned to (xz, yz) at every
    lattice size. The original search in sheet_code_xx_surgery_toric.py picks
    the globally lightest valid operator without constraining which sheets it
    joins; at L = 8 that returns a weight-20 operator spanning all three
    sheets, which is a different operation from the two-sheet merges at L = 4
    and 6. Pinning gives weight 2L at every size and restores sub-threshold
    ordering. Produces the 0.91% +/- 0.04% XX threshold and the Section 9.3
    tables. Usage: python3 xx_pinned.py L SHOTS p1 p2 ... [--seed N]

xx_surgery_results_pinned.json
    The dataset behind the reported XX threshold, 31 points at L = 4, 6, 8.
    The earlier xx_surgery_results.json is retained for comparison only and
    should not be used: its L = 8 points came from the unpinned three-sheet
    operator and cannot be reproduced by the current code.

fss_diagnostics.py
    Finite-size-scaling diagnostics built on sheet_code_formal_fss_fit.py:
    ansatz, parameter count, point counts, window, leave-one-size-out,
    leave-one-p-out, and chi^2/DOF. Reproduces the fit-diagnostics table.

sheet_code_formal_fss_fit.py
    Now importable (main block guarded) and with paths made relative. The
    covariance errors it prints (+/-0.033%, +/-0.018%) are scaled in the
    manuscript by sqrt(chi^2/DOF) to +/-0.055% and +/-0.026%.
