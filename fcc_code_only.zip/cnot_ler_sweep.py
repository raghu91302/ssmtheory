"""Logical error rate sweep for the three-sheet Horsman CNOT.

For each (L, d_each, p), build the CNOT circuit, sample many shots, decode each
with MWPM (PyMatching) on the DEM detector graph, and count logical errors
(either Obs0 or Obs1 flipped from its noise-free expectation).
"""
import sys, os, json, time, argparse
import numpy as np
import stim
import pymatching

from sheet_code_cnot_full import build_cnot_circuit


def run_one_point(L, d_each, p, n_shots, seed=42):
    """Run n_shots at (L, d_each, p), aggregating both observables.
    
    Returns: dict with keys p, L, d_each, n_shots, logical_errors, ler, ler_se, time
    """
    t0 = time.time()
    # Build circuit once per (L, d_each, p, c, t) and average across all 4 inputs
    total_errors = 0
    total_shots = 0
    for c_input in [0, 1]:
        for t_input in [0, 1]:
            circ, info = build_cnot_circuit(L, d_each, p, c_input, t_input)
            try:
                dem = circ.detector_error_model(decompose_errors=True)
            except Exception as e:
                # Some shots might not decompose; try without
                dem = circ.detector_error_model()
            matcher = pymatching.Matching.from_detector_error_model(dem)
            
            sampler = circ.compile_detector_sampler(seed=seed + 13*L + 7*d_each + 3*c_input + t_input)
            shots_per_input = max(1, n_shots // 4)
            detection_events, flips = sampler.sample(
                shots=shots_per_input, separate_observables=True
            )
            predicted = matcher.decode_batch(detection_events)
            # `flips` and `predicted` are (n_shots, n_observables)
            # logical error when actual flip != predicted
            errors_per_shot = (flips != predicted).any(axis=1)
            total_errors += int(errors_per_shot.sum())
            total_shots += shots_per_input
    
    ler = total_errors / total_shots
    ler_se = np.sqrt(ler * (1 - ler) / total_shots) if total_shots > 0 else 0.0
    return {
        'L': L, 'd_each': d_each, 'p': p,
        'n_shots': total_shots, 'logical_errors': total_errors,
        'ler': ler, 'ler_se': ler_se,
        'time_s': time.time() - t0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--L', type=int, nargs='+', default=[4, 6])
    parser.add_argument('--d_each', type=int, default=2)
    parser.add_argument('--p', type=float, nargs='+',
                        default=[0.001, 0.002, 0.003, 0.005, 0.007, 0.01])
    parser.add_argument('--shots', type=int, default=1000)
    parser.add_argument('--out', type=str, default='/home/claude/cnot_ler_sweep.json')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    
    print(f"CNOT LER sweep: L={args.L}, d_each={args.d_each}, "
          f"p={args.p}, shots={args.shots}")
    
    results = []
    for L in args.L:
        for p in args.p:
            print(f"\n--- L={L}, p={p} ---", flush=True)
            r = run_one_point(L, args.d_each, p, args.shots, seed=args.seed)
            print(f"  LER = {r['ler']:.4f} ± {r['ler_se']:.4f} "
                  f"({r['logical_errors']}/{r['n_shots']}), "
                  f"{r['time_s']:.1f}s")
            results.append(r)
            # Save incrementally
            with open(args.out, 'w') as f:
                json.dump(results, f, indent=2)
    
    print(f"\nResults saved to {args.out}")
    return results


if __name__ == '__main__':
    main()
