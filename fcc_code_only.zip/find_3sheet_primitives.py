"""Find Z-primitive and X-primitive at specified sheet-pair coverage.

For a 3-sheet CNOT we need:
  Z-prim spanning sheets {C_sheet, A_sheet}
  X-prim spanning sheets {A_sheet, T_sheet}
where {C, A, T} are 3 distinct sheets. The two primitives must share exactly
one sheet (A's), not two.
"""
import os, json, sys
import numpy as np

from sheet_code_fcc_lattice import (
    build_fcc_lattice, fcc_triangles,
    vertex_Z_stabilizers, oct_void_X_stabilizers
)
from sheet_code_gf2 import gf2_rank, gf2_kernel


def sheet_label(edge_to_sheet, op_string):
    """Return sorted set of sheets that op_string spans."""
    sheets = set()
    for i, v in enumerate(op_string):
        if v == 1:
            sheets.add(edge_to_sheet[i])
    return frozenset(sheets)


def find_z_primitives_by_sheet_pair(L, max_search=5000):
    """Find one valid Z-merge primitive for each possible sheet-pair coverage.
    
    Returns dict: frozenset({s1, s2}) -> (triangle_set, op_string, weight)
    """
    _, _, _, edge_list, _, edge_to_sheet = build_fcc_lattice(L)
    HX, _ = oct_void_X_stabilizers(L)
    HZ, _ = vertex_Z_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    M = (HX @ B.T) % 2
    valid = gf2_kernel(M)
    ops = (valid @ B) % 2
    weights = ops.sum(axis=1)
    rank_HZ = gf2_rank(HZ)
    
    sort_idx = np.argsort(weights)
    found = {}
    for idx in sort_idx[:max_search]:
        if weights[idx] == 0:
            continue
        op = ops[idx]
        test = np.vstack([HZ, op.reshape(1, -1)])
        if gf2_rank(test) > rank_HZ:
            sheets = sheet_label(edge_to_sheet, op)
            if len(sheets) >= 2 and sheets not in found:
                found[sheets] = (valid[idx], op, int(weights[idx]))
                if len(found) >= 6:  # 3 pairs of sheets + maybe 3-sheet
                    break
    return found


def find_x_primitives_by_sheet_pair(L, max_search=5000):
    """Find one valid X-merge primitive for each possible sheet-pair coverage.
    
    By CSS duality, this is symmetric to find_z_primitives_by_sheet_pair
    with HX and HZ swapped.
    """
    _, _, _, edge_list, _, edge_to_sheet = build_fcc_lattice(L)
    HX, _ = oct_void_X_stabilizers(L)
    HZ, _ = vertex_Z_stabilizers(L)
    triangles, B = fcc_triangles(L)
    
    # X-primitive: triangle products whose X-product commutes with HZ stabs
    # but is not in HX rowspan. So we use HZ in the commutation, HX as the "other".
    M = (HZ @ B.T) % 2
    valid = gf2_kernel(M)
    ops = (valid @ B) % 2
    weights = ops.sum(axis=1)
    rank_HX = gf2_rank(HX)
    
    sort_idx = np.argsort(weights)
    found = {}
    for idx in sort_idx[:max_search]:
        if weights[idx] == 0:
            continue
        op = ops[idx]
        test = np.vstack([HX, op.reshape(1, -1)])
        if gf2_rank(test) > rank_HX:
            sheets = sheet_label(edge_to_sheet, op)
            if len(sheets) >= 2 and sheets not in found:
                found[sheets] = (valid[idx], op, int(weights[idx]))
                if len(found) >= 6:
                    break
    return found


if __name__ == '__main__':
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    print(f"=== Searching primitives at L={L} ===")
    zs = find_z_primitives_by_sheet_pair(L)
    print(f"\nZ-primitives by sheet coverage:")
    for sheets, (ts, op, w) in zs.items():
        print(f"  {sorted(sheets)}: {int(ts.sum())} triangles, weight {w}")
    
    xs = find_x_primitives_by_sheet_pair(L)
    print(f"\nX-primitives by sheet coverage:")
    for sheets, (ts, op, w) in xs.items():
        print(f"  {sorted(sheets)}: {int(ts.sum())} triangles, weight {w}")
    
    # Find a valid {C, A, T} assignment
    print(f"\nLooking for compatible (Z-prim, X-prim) sharing exactly 1 sheet (= A's sheet):")
    all_sheets = {'xy', 'xz', 'yz'}
    for z_sheets, (_, _, zw) in zs.items():
        for x_sheets, (_, _, xw) in xs.items():
            shared = z_sheets & x_sheets
            if len(shared) == 1:
                A = next(iter(shared))
                C_choices = z_sheets - {A}
                T_choices = x_sheets - {A}
                if C_choices and T_choices:
                    C = next(iter(C_choices))
                    T = next(iter(T_choices))
                    print(f"  Z-prim {sorted(z_sheets)} (w={zw}) + X-prim {sorted(x_sheets)} (w={xw})")
                    print(f"    => C in {C}, A in {A}, T in {T}")
