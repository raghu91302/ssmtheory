# FCC Sheet Code — Code & Data

This archive contains all Python code and data files supporting the paper
"Three Sheets, One Architecture: Inter-Sheet Logical Gates for K=4 Quantum
Error Correction" (Kulkarni, 2026).

## Quick reference

| File | Purpose |
|---|---|
| `sheet_code_fcc_lattice.py` | FCC lattice, stabilizer matrices, triangles |
| `sheet_code_gf2.py` | GF(2) rank and kernel utilities |
| `sheet_code_surgery.py` | Logical analysis and distance verification |
| `sheet_code_test_construction.py` | Unit tests (verifies all L=4,6 analytical claims) |
| `sheet_code_custom_surgery.py` | 2-sheet ZZ-merge circuit (toric) |
| `sheet_code_cached_surgery.py` | Accelerated L=8 runner |
| `sheet_code_surgery_threshold.py` | Toric ZZ threshold sweep driver |
| `sheet_code_planar_stabilizers.py` | Planar lattice with rough z-boundary |
| `sheet_code_planar_verify.py` | Planar verification at L=4,6,8 |
| `sheet_code_planar_ba_surgery.py` | Planar boundary-aware ribbon primitive |
| `sheet_code_xx_surgery_toric.py` | XX-merge (CSS dual) |
| `find_3sheet_primitives.py` | CSS-compatible 3-sheet primitive enumerator |
| `find_3sheet_primitives_fast.py` | Batch Gauss-Jordan, ~30x speedup for L=8 |
| `css_dual.py` | Symplectic-dual finder for CSS-paired logicals |
| `sheet_code_cnot_full.py` | Three-sheet Horsman CNOT with Pauli-frame correction |
| `cnot_ler_sweep.py` | CNOT LER sweep with PyMatching MWPM |
| `analyze_cnot_ler.py` | LER analysis and Figure 7 generator |
| `sheet_code_formal_fss_fit.py` | FSS data-collapse fitting |

## Data files
- `surgery_threshold_results.json` — toric ZZ raw shot data
- `planar_ba_threshold_results.json` — planar boundary-aware raw shot data
- `xx_surgery_results.json` — toric XX raw shot data
- `surgery_primitive_L8.json` — cached L=8 Z-primitive
- `cnot_truth_table_results.json` — CNOT truth-table verification
- `cnot_ler_dL_L{4,6,8}.json` — CNOT LER sweep data at d_each=L
- `cnot_ler_L4_d8.json` — non-FT diagnostic (d_each=8 at L=4)

## Reproducibility

All sweep runners accept `--seed <int>` for reproducible sampling and
`--dump-dir <path>` for writing `.stim` and `.dem` artifacts.

Running `sheet_code_test_construction.py` reproduces every analytical claim;
the per-variant runners reproduce every numerical entry in the paper.

## Dependencies

Python 3.10+ with: `numpy`, `stim>=1.13`, `pymatching>=2.0`, `scipy`, `matplotlib`.

## Repository

Live mirror with full history: https://github.com/raghu91302/ssmtheory
