"""Verify planar at L=8 and look at primitive scaling."""
import sys
import time
import numpy as np


from sheet_code_gf2 import gf2_rank, gf2_kernel
from sheet_code_planar_lattice import build_fcc_lattice_planar
from sheet_code_planar_stabilizers import planar_stabs_v4
from sheet_code_planar_lattice import fcc_triangles_planar


for L in [4, 6, 8]:
    t0 = time.time()
    print(f"\n=== Planar L = {L} ===")
    vertices, _, edges, _, _, _ = build_fcc_lattice_planar(L)
    n = len(edges)
    print(f"  n = {n} ({time.time()-t0:.1f}s)")
    
    HZ, Z_meta, HX, X_meta = planar_stabs_v4(L)
    css = (HX @ HZ.T) % 2
    n_ac = int(np.sum(css))
    rank_Z = gf2_rank(HZ)
    rank_X = gf2_rank(HX)
    k = n - rank_Z - rank_X
    print(f"  HZ: {HZ.shape}, HX: {HX.shape}, anticomm: {n_ac}, k = {k} ({time.time()-t0:.1f}s)")
    
    triangles, B = fcc_triangles_planar(L)
    print(f"  {len(triangles)} triangles ({time.time()-t0:.1f}s)")
    
    M_commute = (HX @ B.T) % 2
    valid_sets = gf2_kernel(M_commute)
    print(f"  {valid_sets.shape[0]} valid triangle sets ({time.time()-t0:.1f}s)")
    
    # Min-weight primitive
    rank_HZ = rank_Z
    ops = (valid_sets @ B) % 2
    weights = ops.sum(axis=1)
    sort_idx = np.argsort(weights)
    
    best = None
    min_weight = float('inf')
    for idx in sort_idx[:50]:
        if weights[idx] == 0:
            continue
        op = ops[idx]
        test = np.vstack([HZ, op.reshape(1, -1)])
        if gf2_rank(test) > rank_HZ:
            best = (valid_sets[idx], op, int(weights[idx]))
            break
    
    if best:
        vs, op, w = best
        n_tri = int(vs.sum())
        print(f"  Min planar primitive: {n_tri} triangles, Op weight {w}  ({time.time()-t0:.1f}s)")
    else:
        print(f"  No primitive in first 50 valid sets")
