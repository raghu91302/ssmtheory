"""Generate the four figures for the paper:

  fig1_triangle.pdf   - FCC triangle structure (3 sheets)
  fig2_primitive.pdf  - L=4 surgery primitive (4 triangles + ancillas)
  fig3_threshold.pdf  - log-log threshold plot
  fig4_comparison.pdf - logical qubits at fixed distance, code comparison

All figures are saved as PDF (vector graphics) in the current directory.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
import warnings
warnings.filterwarnings('ignore')


SHEET_COLORS = {'xy': '#1f77b4', 'xz': '#ff7f0e', 'yz': '#2ca02c'}


# ---------- Figure 1: FCC triangle in 3D ----------

def fig_triangle():
    fig = plt.figure(figsize=(6.5, 4.8))
    ax = fig.add_subplot(111, projection='3d')

    # Three vertices forming an FCC triangle
    v0 = np.array([0, 0, 0])
    v1 = np.array([0, 1, 1])
    v2 = np.array([1, 0, 1])

    # Edges, labeled by sheet
    edges = [
        (v0, v1, 'yz', '$(0,1,1) \\in S_{yz}$'),
        (v0, v2, 'xz', '$(1,0,1) \\in S_{xz}$'),
        (v1, v2, 'xy', '$(1,\\!-\\!1,0) \\in S_{xy}$'),
    ]
    for a, b, sheet, lab in edges:
        ax.plot([a[0], b[0]], [a[1], b[1]], [a[2], b[2]],
                color=SHEET_COLORS[sheet], linewidth=3.5, zorder=3)
        m = (a + b) / 2.0
        off = {'yz': (-0.10, 0.0, 0.16), 'xz': (0.10, -0.12, -0.16),
               'xy': (0.12, 0.10, 0.14)}[sheet]
        ax.text(m[0] + off[0], m[1] + off[1], m[2] + off[2], lab, fontsize=8.5,
                color=SHEET_COLORS[sheet], ha='center', zorder=6,
                bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none',
                          alpha=0.85))

    # Vertex markers
    for v, label in [(v0, '$v_a$'), (v1, '$v_b$'), (v2, '$v_c$')]:
        ax.scatter(*v, s=130, color='black', zorder=5)
        ax.text(v[0]+0.06, v[1]+0.06, v[2]+0.08, label,
                fontsize=12, ha='left')

    # Triangle face
    pts = np.array([v0, v1, v2, v0])
    ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], '-',
            color='gray', linewidth=0.5, alpha=0.3, zorder=1)

    # Legend
    patches = [mpatches.Patch(color=SHEET_COLORS[s], label=f'sheet $S_{{{s}}}$')
               for s in ['xy', 'xz', 'yz']]
    ax.legend(handles=patches, loc='upper left', fontsize=10,
              bbox_to_anchor=(0.0, 1.0))

    ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_zlabel('z')
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1]); ax.set_zticks([0, 1])
    ax.view_init(elev=18, azim=-55)
    ax.set_title('Every FCC triangle has one edge per triad sheet',
                 fontsize=11, pad=10)
    plt.tight_layout()
    plt.savefig('fig1_triangle.pdf', bbox_inches='tight', dpi=150)
    plt.close()
    print("  fig1_triangle.pdf")


# ---------- Figure 2: surgery primitive at L=4 ----------

def fig_primitive():
    fig = plt.figure(figsize=(9.2, 5.4))
    ax = fig.add_subplot(111, projection='3d')

    # 4-triangle surgery primitive at L=4, periodic in z with circumference 4.
    # T4 closes the chain through the periodic boundary: its edges from v0
    # reach v3 and v9 at z = -1, the periodic images of z = 3.
    V = {
        0: (0, 0, 0), 1: (0, 0, 2), 2: (0, 1, 1), 3: (0, 1, 3),
        8: (1, 0, 1), 9: (1, 0, 3),
    }
    IMG = {3: (0, 1, -1), 9: (1, 0, -1)}      # periodic images used by T4

    triangles = [                              # (name, verts, uses images?)
        ('T0',  [0, 2, 8], False),
        ('T4',  [0, 3, 9], True),
        ('T24', [1, 2, 8], False),
        ('T28', [1, 3, 9], False),
    ]
    def pos(v, img):
        return np.array(IMG[v] if (img and v in IMG) else V[v], float)

    # edges: (u, v, sheet, wraps)
    edges = [
        (0, 2, 'yz', False), (0, 8, 'xz', False), (2, 8, 'xy', False),   # T0
        (0, 3, 'yz', True),  (0, 9, 'xz', True),  (3, 9, 'xy', False),   # T4
        (1, 2, 'yz', False), (1, 8, 'xz', False),                        # T24
        (1, 3, 'yz', False), (1, 9, 'xz', False),                        # T28
    ]
    drawn = set()
    for u, v, sheet, wraps in edges:
        key = (tuple(sorted([u, v])), wraps)
        if key in drawn:
            continue
        drawn.add(key)
        a, b = pos(u, wraps), pos(v, wraps)
        ax.plot([a[0], b[0]], [a[1], b[1]], [a[2], b[2]],
                color=SHEET_COLORS[sheet], linewidth=2.5,
                linestyle='--' if wraps else '-', zorder=2)

    for v_id, p in V.items():
        ax.scatter(*p, s=80, color='black', zorder=5)
        ax.text(p[0]+0.05, p[1]+0.05, p[2]+0.1, f'$v_{{{v_id}}}$', fontsize=9)
    for v_id, p in IMG.items():                # hollow markers for images
        ax.scatter(*p, s=80, facecolor='white', edgecolor='black',
                   linewidths=1.2, zorder=5)
        ax.text(p[0]+0.05, p[1]+0.05, p[2]-0.35, f"$v_{{{v_id}}}'$", fontsize=9)

    for name, verts, img in triangles:
        c = np.mean([pos(v, img) for v in verts], axis=0)
        ax.scatter(*c, s=140, marker='*', color='red', zorder=6,
                   edgecolor='black', linewidths=0.8)
        ax.text(c[0]+0.05, c[1]+0.05, c[2]+0.1, name, fontsize=9, color='darkred')

    patches = [mpatches.Patch(color=SHEET_COLORS[s], label=f'$S_{{{s}}}$')
               for s in ['xy', 'xz', 'yz']]
    patches.append(plt.Line2D([0], [0], marker='*', color='w',
                              markerfacecolor='red', markeredgecolor='black',
                              markersize=10, linestyle='', label='triangle ancilla'))
    patches.append(plt.Line2D([0], [0], color='gray', linestyle='--',
                              label='edge through periodic boundary'))
    patches.append(plt.Line2D([0], [0], marker='o', color='w',
                              markerfacecolor='white', markeredgecolor='black',
                              markersize=8, linestyle='', label="periodic image ($v'$)"))
    ax.legend(handles=patches, loc='center left', fontsize=8.5,
              bbox_to_anchor=(1.02, 0.55), frameon=True)

    ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_zlabel('z')
    ax.set_zlim(-1.2, 3.3)
    ax.view_init(elev=15, azim=-55)
    ax.set_title('Surgery primitive at $L=4$: 4 triangles spanning two sheets\n'
                 '(weight-8 joint $Z_A\\otimes Z_B$ measurement)',
                 fontsize=10, pad=8)
    plt.tight_layout()
    plt.savefig('fig2_primitive.pdf', bbox_inches='tight', dpi=150)
    plt.close()
    print("  fig2_primitive.pdf")


# ---------- Figure 3: threshold log-log plot ----------

def fig_threshold():
    """Toric ZZ-surgery threshold, plotted from threshold_summary.csv, the
    authoritative aggregate that also feeds the table in the manuscript."""
    import csv, os
    src = 'threshold_summary.csv'
    if not os.path.exists(src):
        print("  fig3_threshold.pdf SKIPPED (threshold_summary.csv missing)")
        return
    data = {}
    for r in csv.DictReader(open(src)):
        data.setdefault(int(r['L']), {})[float(r['p'])] = (
            float(r['rate']), int(r['n_shots']))

    cols = {4: '#4c78a8', 6: '#f58518', 8: '#54a24b'}
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.4, 4.1))

    # -- left: full sweep, log-log --
    for L in sorted(data):
        ps = sorted(data[L])
        y = [data[L][p][0] for p in ps]
        # Wilson 95% intervals: asymmetric, never negative, correct at low counts
        def wilson(k, n, z=1.96):
            ph = k / n; d = 1 + z*z/n
            c = (ph + z*z/(2*n)) / d
            h = z * ((ph*(1-ph)/n + z*z/(4*n*n)) ** 0.5) / d
            return max(0.0, c-h), min(1.0, c+h)
        # zero-failure points cannot sit on a log axis: draw their 95% upper
        # bound as an open marker with a down arrow, and keep them off the line
        nz = [p for p in ps if data[L][p][0] > 0]
        zp = [p for p in ps if data[L][p][0] == 0]
        y = [data[L][p][0] for p in nz]
        lo, hi = [], []
        for p in nz:
            r, n = data[L][p]; a, b = wilson(round(r*n), n)
            lo.append(max(r - a, 0.0)); hi.append(max(b - r, 0.0))
        e = [lo, hi]
        for p in zp:
            ub = wilson(0, data[L][p][1])[1]
            ax1.plot(p * 100, ub, marker='v', markerfacecolor='white',
                     markeredgecolor=cols[L], markersize=6, linestyle='',
                     zorder=4)
        ps = nz
        ax1.errorbar([p * 100 for p in ps], y, yerr=e, fmt='o-',
                     color=cols[L], ms=5, lw=1.6, capsize=2.5,
                     label=f'$L = {L}$')
    ax1.axvspan(1.024, 1.109, color='#999999', alpha=0.22, lw=0)
    ax1.set_xscale('log'); ax1.set_yscale('log')
    ax1.plot([], [], marker='v', markerfacecolor='white', markeredgecolor='gray',
             markersize=6, linestyle='', label='0 failures: 95% upper bound')
    ax1.set_xlabel('Physical error rate $p$ (%)')
    ax1.set_ylabel('Logical error rate per surgery')
    ax1.set_title('Joint-$ZZ$ surgery, toric variant')
    ax1.legend(frameon=False, loc='lower right')
    ax1.grid(alpha=0.3, which='both')

    # -- right: zoom on the crossing region, linear --
    for L in sorted(data):
        ps = [p for p in sorted(data[L]) if 0.006 <= p <= 0.013]
        if not ps:
            continue
        y = [data[L][p][0] for p in ps]
        e = [(data[L][p][0] * (1 - data[L][p][0]) / data[L][p][1]) ** 0.5
             for p in ps]
        ax2.errorbar([p * 100 for p in ps], y, yerr=e, fmt='o-',
                     color=cols[L], ms=5, lw=1.6, capsize=2.5,
                     label=f'$L = {L}$')
    ax2.axvspan(1.024, 1.109, color='#999999', alpha=0.22, lw=0,
                label='pairwise crossings')
    for x, lab in [(1.024, '6--8'), (1.069, '4--8'), (1.109, '4--6')]:
        ax2.axvline(x, color='#555555', ls=':', lw=0.9)
        ax2.text(x, 0.355, lab, rotation=90, fontsize=7.5, ha='right',
                 va='top', color='#555555')
    ax2.set_xlabel('Physical error rate $p$ (%)')
    ax2.set_ylabel('Logical error rate per surgery')
    ax2.set_title('Crossing region: $1.024\\%$ to $1.109\\%$')
    ax2.legend(frameon=False, loc='upper left', fontsize=8.5)
    ax2.grid(alpha=0.3)
    ax2.set_ylim(0, 0.38)

    for ax in (ax1, ax2):
        for sp in ('top', 'right'):
            ax.spines[sp].set_visible(False)
    plt.tight_layout()
    plt.savefig('fig3_threshold.pdf', bbox_inches='tight')
    plt.close()
    print("  fig3_threshold.pdf")


# ---------- Figure 4: code comparison ----------

def fig_comparison():
    """Qubits per logical at MATCHED distance -- the only fair density axis --
    with the cross-block primitive annotated as the actual differentiator."""
    d = 8
    codes = [
        ('Rotated surface',            d*d/1,       '4',        'Adjacent patches only'),
        ('Unrotated 2D toric',         2*d*d/2,     '4 + wraps','Adjacent patches only'),
        ('Rotated 2D toric',           d*d/2,       '4 + wraps','Adjacent patches only'),
        ('Sheet code (3 sheets)',      3*d**3/(6*d),'4 + wraps','Structured cross-sheet pairs'),
        ('Gross BB ($d{=}12$)',        144/12,      '6 + long', 'Active development'),
    ]
    fig, ax = plt.subplots(figsize=(8.4, 3.4))
    names = [c[0] for c in codes]
    vals  = [c[1] for c in codes]
    cols  = ['#888888', '#888888', '#4c78a8', '#117733', '#cc6677']
    ax.barh(range(len(codes)), vals, color=cols, edgecolor='black',
            linewidth=0.5, height=0.62)
    for i, (nm, v, K, xb) in enumerate(codes):
        ax.text(v + max(vals)*0.015, i, f'  $K{{=}}{K}$   |   {xb}',
                va='center', fontsize=8.5)
    ax.set_yticks(range(len(codes)))
    ax.set_yticklabels(names, fontsize=9.5)
    ax.set_xlabel('Data qubits per logical qubit at matched distance '
                  '($d=8$; BB at its native $d=12$)', fontsize=9.5)
    ax.set_xlim(0, max(vals) * 1.75)
    ax.set_title('Density parity, and the primitive that differs',
                 fontsize=10.5)
    ax.invert_yaxis()
    ax.grid(True, axis='x', alpha=0.3)
    ax.get_yticklabels()[3].set_fontweight('bold')
    ax.get_yticklabels()[2].set_fontweight('bold')
    # annotate the parity
    ax.annotate('', xy=(d*d/2, 2.32), xytext=(3*d**3/(6*d), 2.68),
                arrowprops=dict(arrowstyle='<->', color='#117733', lw=1.1))
    ax.text(d*d/2 + 1.5, 2.5, 'identical', fontsize=8.5, color='#117733',
            style='italic')
    plt.tight_layout()
    plt.savefig('fig4_comparison.pdf', bbox_inches='tight', dpi=150)
    plt.close()
    print("  fig4_comparison.pdf")





# ---------- Figure 5: planar-boundary surgery threshold ----------

def fig_planar_threshold():
    """Planar boundary-aware surgery threshold, plotted from
    planar_ba_threshold_results.json, the same data the crossings come from.
    Runs at the same (L, p) are merged. Error bars are Wilson 95% intervals."""
    import json, os
    src = 'planar_ba_threshold_results.json'
    if not os.path.exists(src):
        print("  fig5_planar_threshold.pdf SKIPPED (json missing)")
        return
    acc = {}
    for r in json.load(open(src)):
        k = (int(r['L']), round(float(r['p']), 6))
        m = acc.setdefault(k, [0, 0])
        m[0] += r.get('n_err', round(r['rate'] * r['n_shots'])); m[1] += r['n_shots']
    data = {}
    for (L, p), (e, n) in acc.items():
        data.setdefault(L, {})[p] = (e / n, n, e)

    def wilson(k, n, z=1.96):
        ph = k / n; d = 1 + z*z/n
        c = (ph + z*z/(2*n)) / d
        h = z * ((ph*(1-ph)/n + z*z/(4*n*n)) ** 0.5) / d
        return max(0.0, c-h), min(1.0, c+h)

    cols = {4: '#4c78a8', 6: '#f58518', 8: '#54a24b'}
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    ax.axvspan(0.725, 0.812, color='#999999', alpha=0.22, lw=0,
               label='pairwise crossings')
    for L in sorted(data):
        ps = sorted(p for p in data[L] if data[L][p][0] > 0)
        y = [data[L][p][0] for p in ps]
        lo, hi = [], []
        for p in ps:
            r, n, e = data[L][p]; a, b = wilson(e, n)
            lo.append(max(r - a, 0)); hi.append(max(b - r, 0))
        ax.errorbar([p * 100 for p in ps], y, yerr=[lo, hi], fmt='o-',
                    color=cols[L], ms=4.5, lw=1.6, capsize=2.5,
                    label=f'$L = {L}$')
        for p in sorted(p for p in data[L] if data[L][p][0] == 0):
            ax.plot(p * 100, wilson(0, data[L][p][1])[1], marker='v',
                    markerfacecolor='white', markeredgecolor=cols[L],
                    markersize=6, linestyle='', zorder=4)
    ax.set_xlabel('Physical error rate $p$ (%)')
    ax.set_ylabel('Logical error rate per surgery')
    ax.set_yscale('log')
    ax.set_title('Planar-boundary surgery threshold '
                 r'($p_{\mathrm{th}} = 0.76\% \pm 0.05\%$)', fontsize=11)
    ax.legend(frameon=False, fontsize=9)
    ax.grid(alpha=0.3, which='both')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    plt.tight_layout()
    plt.savefig('fig5_planar_threshold.pdf', bbox_inches='tight')
    plt.close()
    print("  fig5_planar_threshold.pdf")


# ---------- Figure 6: CNOT LER diagnostic ----------

def fig_cnot_ler():
    """Regenerated from cnot_ler_dL_L{4,6,8}.json and cnot_ler_L4_d8.json."""
    import json, os
    files = {
        '$L=4$, $d_{\\mathrm{each}}=4$':  ('cnot_ler_dL_L4.json', '#4c78a8', 'o-'),
        '$L=6$, $d_{\\mathrm{each}}=6$':  ('cnot_ler_dL_L6.json', '#f58518', 's-'),
        '$L=8$, $d_{\\mathrm{each}}=8$':  ('cnot_ler_dL_L8.json', '#54a24b', 'D-'),
        '$L=4$, $d_{\\mathrm{each}}=8$ (diagnostic)':
                                        ('cnot_ler_L4_d8.json', '#b279a2', '^--'),
    }
    fig, ax = plt.subplots(figsize=(6.6, 4.2))
    for lab, (fn, col, st) in files.items():
        if not os.path.exists(fn):
            continue
        rows = sorted(json.load(open(fn)), key=lambda r: r['p'])
        xs = [r['p'] for r in rows]
        ys = [r['ler'] for r in rows]
        # Wilson 95% intervals rather than symmetric SE; matters at L=8 (100 shots)
        def wilson(k, n, z=1.96):
            ph = k / n; d = 1 + z*z/n
            c = (ph + z*z/(2*n)) / d
            h = z * ((ph*(1-ph)/n + z*z/(4*n*n)) ** 0.5) / d
            return max(0.0, c-h), min(1.0, c+h)
        lo, hi = [], []
        for r in rows:
            n = int(r.get('n_shots', r.get('shots', 0))); k = round(r['ler'] * n) if 'ler' in r else round(r['rate'] * n)
            a, b = wilson(k, n); y0 = r.get('ler', r.get('rate'))
            lo.append(max(y0 - a, 0)); hi.append(max(b - y0, 0))
        es = [lo, hi]
        ax.errorbar(xs, ys, yerr=es, fmt=st, color=col, ms=5, lw=1.6,
                    capsize=3, label=lab)
    ax.annotate("$4.2\\sigma$ improvement\nwith distance",
                xy=(1e-3, 0.154), xytext=(1.05e-4, 0.30), fontsize=8.5,
                arrowprops=dict(arrowstyle='->', lw=0.9, color='#333333'))
    ax.annotate("deeper merge is worse:\nnot fault tolerant",
                xy=(2e-3, 0.4375), xytext=(1.6e-4, 0.50), fontsize=8.5,
                color='#b279a2',
                arrowprops=dict(arrowstyle='->', lw=0.9, color='#b279a2'))
    ax.set_xlabel('Physical error rate $p$')
    ax.set_ylabel('CNOT logical error rate')
    ax.set_xscale('log')
    ax.set_ylim(0, 0.62)
    ax.set_title('Three-sheet CNOT: distance suppression, but no depth '
                 'suppression', fontsize=10.5)
    ax.legend(frameon=False, fontsize=8.5, loc='lower right',
              bbox_to_anchor=(1.0, 0.0))
    ax.grid(alpha=0.3, which='both')
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    plt.tight_layout()
    plt.savefig('fig6_cnot_ler.pdf', bbox_inches='tight')
    plt.close()
    print("  fig6_cnot_ler.pdf")


if __name__ == '__main__':
    print("Generating figures...")
    fig_triangle()
    fig_primitive()
    fig_threshold()
    fig_comparison()
    fig_planar_threshold()
    fig_cnot_ler()
    print("\nAll figures generated.")
